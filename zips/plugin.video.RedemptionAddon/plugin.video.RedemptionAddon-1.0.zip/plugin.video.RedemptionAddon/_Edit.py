import xbmcaddon

MainBase = 'http://redemptionbuild.16mb.com/Redemption/CHRISTINE/home.txt'
addon = xbmcaddon.Addon('plugin.video.RedemptionAddon')