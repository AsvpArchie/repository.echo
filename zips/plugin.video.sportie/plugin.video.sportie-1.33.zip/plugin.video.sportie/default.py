import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , hashlib
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluX21lbnUueG1s' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = xbmc . translatePath ( 'special://home/addons/program.plexus' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
Oooo000o = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oo0O = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
OOo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
Ii1IIii11 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 55 - 55: i1111 - i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
oO000OoOoo00o = "true"
iiiI11 = "false"
OOooO = "false"
try :
 oO000OoOoo00o = plugintools . get_setting ( "scrape1" )
 iiiI11 = plugintools . get_setting ( "scrape2" )
 OOooO = plugintools . get_setting ( "scrape3" )
except :
 oO000OoOoo00o = "true"
 iiiI11 = "false"
 OOooO = "false"
 if 58 - 58: i11iiII + OooooO0oOO + oOo0 / oo0Ooo0
I1I11I1I1I = IiiIII111iI + '|SPLIT|' + o0O
checker . check ( I1I11I1I1I )
if 90 - 90: i1IIiiiii + i1iIIIiI1I - OoO000 % OooOoO0Oo + iiIIiIiIi
if not os . path . exists ( IiII ) :
 os . makedirs ( IiII )
 if 38 - 38: i1IIiiiii / I11i1i11i1I
if not os . path . isfile ( i1i1II ) :
 OooO0 = open ( i1i1II , 'w' )
 if 35 - 35: oOo0 % OooOoO0Oo % i11iIiiIii / i111I
if not os . path . isfile ( iI1Ii11111iIi ) :
 OooO0 = open ( iI1Ii11111iIi , 'w' )
 if 13 - 13: II1Ii1iI1i - i1IIiiiii % OooooO0oOO / ooO0oo0oO0 % i1iIIIiI1I
if not os . path . isfile ( O0oo0OO0 ) :
 OooO0 = open ( O0oo0OO0 , 'w' )
 if 97 - 97: i11iIiiIii
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 32 - 32: I11i1i11i1I * oooO0oo0oOOOO % OooooO0oOO % i1IIiiiii . OoO000
class o0OOOOO00o0O0 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 71 - 71: iiIIiIiIi % i1iIIIiI1I / oo0ooO0oOOOOo
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 49 - 49: i1111 % i1iIIIiI1I * oooO0oo0oOOOO
oOOo0oo = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 80 - 80: oo0Ooo0 * i11iIiiIii / OooOoO0Oo
class I11II1i :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 23 - 23: i11iiII / oo0ooO0oOOOOo + oo0Ooo0 + oo0Ooo0 / i1111
  if 26 - 26: i111I
  if 12 - 12: i111I % OOO0O / iiIIiIiIi % oo0ooO0oOOOOo
  if 29 - 29: i111I
def iI ( ) :
 I1i1I1II = 5
 i1 = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 IiIiiI = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 31 - 31: i1IIiiiii . i1IIiiiii - oo0ooO0oOOOOo / oo + iiIIiIiIi * i1IIi11111i
 O0ooOooooO = [ ]
 if 60 - 60: oo0Ooo0 / oo0Ooo0
 for I1II1III11iii in range ( I1i1I1II ) :
  O0ooOooooO . append ( I11II1i ( i1 [ I1II1III11iii ] , IiIiiI [ I1II1III11iii ] ) )
  if 75 - 75: ooO0oo0oO0 / oOo0 % oo0ooO0oOOOOo * OOO0O
 return O0ooOooooO
 if 9 - 9: oo
def i11 ( ) :
 if 58 - 58: oOo0 * i11iIiiIii / OOO0O % OooOoO0Oo - i11iiII / OooooO0oOO
 ii11i1 = IIIii1II1II ( OOo )
 if len ( ii11i1 ) > 1 :
  i1I1iI = i1i1II
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 83 - 83: i11iiII / iiIIiIiIi
 ii11i1 = IIIii1II1II ( iiI1iIiI )
 if len ( ii11i1 ) > 1 :
  i1I1iI = iI1Ii11111iIi
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 49 - 49: oo0ooO0oOOOOo
 ii11i1 = IIIii1II1II ( Ii1IIii11 )
 if len ( ii11i1 ) > 1 :
  i1I1iI = O0oo0OO0
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 35 - 35: OOO0O - i111I / i11iiII % II1Ii1iI1i
 o00OO00OoO = OOOO0OOoO0O0 ( II1 )
 O0Oo000ooO00 = II1
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 62 - 62: ooO0oo0oO0 * OOO0O
  if "<mamahd>" in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo = re . compile ( '<mamahd>(.+?)</mamahd>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 300 , Oo0OoO00oOO0o , OOO00O , '' )
   if 98 - 98: i1iIIIiI1I * i1iIIIiI1I / i1iIIIiI1I + oo0Ooo0
  elif "<bigsports>" in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo = re . compile ( '<bigsports>(.+?)</bigsports>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 301 , Oo0OoO00oOO0o , OOO00O , '' )
   if 34 - 34: iiIIiIiIi
  elif "<cricbox>" in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo = re . compile ( '<cricbox>(.+?)</cricbox>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 302 , Oo0OoO00oOO0o , OOO00O , '' )
   if 15 - 15: oo0Ooo0 * iiIIiIiIi * I11i1i11i1I % i11iIiiIii % OOO0O - oOo0
  elif "<cricfree>" in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo = re . compile ( '<cricfree>(.+?)</cricfree>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 303 , Oo0OoO00oOO0o , OOO00O , '' )
   if 68 - 68: OooOoO0Oo % II1Ii1iI1i . OoO000 . i11iiII
  elif "<sports4u>" in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo = re . compile ( '<sports4u>(.+?)</sports4u>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 304 , Oo0OoO00oOO0o , OOO00O , '' )
   if 92 - 92: i1iIIIiI1I . OooOoO0Oo
  elif "<sports4ulive>" in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , "url" , 305 , Oo0OoO00oOO0o , OOO00O , '' )
   if 31 - 31: OooOoO0Oo . OOO0O / oooO0oo0oOOOO
  elif '<search>display</search>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 89 - 89: OOO0O
  elif '<arenavision>display</arenavision>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   if os . path . exists ( oO00oOo ) : OOoOO0oo0ooO ( i1OOO , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : OO0oOoOO0oOO0 ( '[COLOR darkgray]' + i1OOO + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 86 - 86: oOo0
   if 55 - 55: I11i1i11i1I + ooO0oo0oO0 / OOO0O * OooooO0oOO - i11iIiiIii - i1IIiiiii
  elif '<vip>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 25 - 25: i11iiII
  elif '<divider>null</divider>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OO0oOoOO0oOO0 ( i1OOO , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 7 - 7: II1Ii1iI1i / i1IIi11111i * OooOoO0Oo . OoO000 . ooO0oo0oO0
   if 13 - 13: oOo0 / i11iIiiIii
   if 2 - 2: i1IIi11111i / oooO0oo0oOOOO / oo0ooO0oOOOOo % OOO0O % i1IIiiiii
   if 52 - 52: oo0ooO0oOOOOo
   if 95 - 95: i1IIiiiii
   if 87 - 87: iiIIiIiIi + OOO0O . oOo0 + OOO0O
  elif '<m3ulists>display</m3ulists>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( i1OOO , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 91 - 91: oooO0oo0oOOOO
   if 61 - 61: i1111
   if 64 - 64: iiIIiIiIi / OOO0O - oooO0oo0oOOOO - oo0Ooo0
   if 86 - 86: oo0Ooo0 % OOO0O / i1IIi11111i / OOO0O
   if 42 - 42: oo
   if 67 - 67: OooOoO0Oo . i1iIIIiI1I . oooO0oo0oOOOO
   if 10 - 10: i11iiII % i11iiII - ooO0oo0oO0 / oOo0 + i1IIiiiii
   if 87 - 87: OooooO0oOO * i11iiII + oOo0 / ooO0oo0oO0 / i1iIIIiI1I
   if 37 - 37: i1iIIIiI1I - iiIIiIiIi * OooooO0oOO % i11iIiiIii - OooOoO0Oo
   if 83 - 83: oo0Ooo0 / i1IIi11111i
   if 34 - 34: OoO000
   if 57 - 57: OooooO0oOO . oo0Ooo0 . II1Ii1iI1i
   if 42 - 42: oo0Ooo0 + i11iiII % oooO0oo0oOOOO
   if 6 - 6: OooooO0oOO
   if 68 - 68: OOO0O - oo
   if 28 - 28: oo . oOo0 / oOo0 + I11i1i11i1I . i11iiII
   if 1 - 1: ooO0oo0oO0 / i1111
   if 33 - 33: oo0Ooo0
   if 18 - 18: oo0ooO0oOOOOo % i1iIIIiI1I * oooO0oo0oOOOO
   if 87 - 87: i11iIiiIii
   if 93 - 93: i11iiII - oo % i11iIiiIii . i1iIIIiI1I / i1iIIIiI1I - OooOoO0Oo
   if 9 - 9: i11iiII / I11i1i11i1I - i1IIi11111i / i111I / ooO0oo0oO0 - oo0ooO0oOOOOo
  elif '<sportsdevil>' in Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 )
   if len ( o00oooO0Oo ) == 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0oOOo = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    o0O0OOO0Ooo = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iiIiI = o0O0OOO0Ooo
    I1 = "/"
    if not iiIiI . endswith ( I1 ) :
     OOO00O0O = iiIiI + "/"
    else :
     OOO00O0O = iiIiI
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( i1OOO ) + '%26url=' + Oo0oOOo
    Oo0oOOo = o00OO00OoO + '%26referer=' + OOO00O0O
    OO0oOoOO0oOO0 ( i1OOO , Oo0oOOo , 4 , Oo0OoO00oOO0o , OOO00O )
   elif len ( o00oooO0Oo ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    OO0oOoOO0oOO0 ( i1OOO , O0Oo000ooO00 + 'NOTPLAY' , 8 , Oo0OoO00oOO0o , OOO00O )
  elif '<plexus>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OOO00O = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : OO0oOoOO0oOO0 ( i1OOO , O0Oo000ooO00 + 'NOTPLAY' , 7 , Oo0OoO00oOO0o , OOO00O )
   else : OO0oOoOO0oOO0 ( '[COLOR darkgray]' + i1OOO + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 33 - 33: oooO0oo0oOOOO . OoO000 . i1IIi11111i
  elif '<rutubeplaylist>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OOO00O = O0O0OO0O0O0
   OOoOO0oo0ooO ( i1OOO , O0Oo000ooO00 , 90 , Oo0OoO00oOO0o , OOO00O )
  elif '<folder>' in Ii1iIiII1ii1 :
   OoOO = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for i1OOO , Oo0oOOo , Oo0OoO00oOO0o , OOO00O in OoOO :
    OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 1 , Oo0OoO00oOO0o , OOO00O )
  elif '<m3u>' in Ii1iIiII1ii1 :
   OoOO = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for i1OOO , Oo0oOOo , Oo0OoO00oOO0o , OOO00O in OoOO :
    OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 10 , Oo0OoO00oOO0o , OOO00O )
  else :
   o00oooO0Oo = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 )
   if len ( o00oooO0Oo ) == 1 :
    OoOO = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
    ooOOO0 = len ( oO0 )
    for i1OOO , Oo0oOOo , Oo0OoO00oOO0o , OOO00O in OoOO :
     OO0oOoOO0oOO0 ( i1OOO , Oo0oOOo , 2 , Oo0OoO00oOO0o , OOO00O )
   elif len ( o00oooO0Oo ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    OO0oOoOO0oOO0 ( i1OOO , II1 , 3 , Oo0OoO00oOO0o , OOO00O )
    if 65 - 65: oooO0oo0oOOOO
 oO00OOoO00 = open ( IIi1IiiiI1Ii ) . read ( )
 IiI111111IIII = oO00OOoO00 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 oO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IiI111111IIII ) )
 for Ii1iIiII1ii1 in oO0 :
  i1Ii = float ( Ii1iIiII1ii1 )
 oO00OOoO00 = open ( I11i11Ii ) . read ( )
 IiI111111IIII = oO00OOoO00 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 oO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IiI111111IIII ) )
 for Ii1iIiII1ii1 in oO0 :
  ii111iI1iIi1 = float ( Ii1iIiII1ii1 )
  if 78 - 78: oo . oOo0 + oo / oo0Ooo0 / oo
 OO0oOoOO0oOO0 ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 OO0oOoOO0oOO0 ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 OO0oOoOO0oOO0 ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 OO0oOoOO0oOO0 ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( "[COLOR dodgerblue]Sportie Testing Section[/COLOR]" , 'http://echocoder.com/private/addons/sportie/test/testmenu.xml' , 1 , iiiii , OOO00O , '' )
 OO0oOoOO0oOO0 ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( i1Ii ) + "[/COLOR]" , 'url' , 999 , iiiii , OOO00O , '' )
 OO0oOoOO0oOO0 ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( ii111iI1iIi1 ) + "[/COLOR]" , 'url' , 999 , iiiii , OOO00O , '' )
 if 54 - 54: OOO0O % i1iIIIiI1I
 IIiII111iiI1I = Ii1i1iI1iIIi ( )
 if 6 - 6: iiIIiIiIi / i11iIiiIii + i1iIIIiI1I * OooooO0oOO
 if IIiII111iiI1I == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IIiII111iiI1I == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 80 - 80: i1111
def O0O ( name , url ) :
 if 1 - 1: i1111
 hash = [ ]
 O0Oo000ooO00 = url
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 if 84 - 84: oo0ooO0oOOOOo % i1111 . i11iIiiIii / oo
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 80 - 80: OooOoO0Oo . i11iIiiIii - oo0ooO0oOOOOo
  if "<mamahd>" in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<mamahd>(.+?)</mamahd>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( name , url , 300 , Oo0OoO00oOO0o , OOO00O , '' )
   if 25 - 25: oo
  elif "<bigsports>" in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<bigsports>(.+?)</bigsports>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( name , url , 301 , Oo0OoO00oOO0o , OOO00O , '' )
   if 62 - 62: oOo0 + oooO0oo0oOOOO
  elif "<cricbox>" in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<cricbox>(.+?)</cricbox>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( name , url , 302 , Oo0OoO00oOO0o , OOO00O , '' )
   if 98 - 98: oo0ooO0oOOOOo
  elif "<cricfree>" in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<cricfree>(.+?)</cricfree>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( name , url , 303 , Oo0OoO00oOO0o , OOO00O , '' )
   if 51 - 51: I11i1i11i1I - OooooO0oOO + i1111 * i1IIiiiii . oo0Ooo0 + OooooO0oOO
  elif "<sports4u>" in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<sports4u>(.+?)</sports4u>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( name , url , 304 , Oo0OoO00oOO0o , OOO00O , '' )
   if 78 - 78: i11iIiiIii / i1iIIIiI1I - i1IIiiiii / oOo0 + OooooO0oOO
  elif "<sports4ulive>" in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOoOO0oo0ooO ( name , "url" , 305 , Oo0OoO00oOO0o , OOO00O , '' )
   if 82 - 82: i1IIiiiii
  elif '<search>' in Ii1iIiII1ii1 :
   if 46 - 46: i111I . i11iIiiIii
   o00oooO0Oo = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
   if len ( o00oooO0Oo ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = name + "!" + url + "!" + Oo0OoO00oOO0o
    name = '[COLOR white]' + name + '[/COLOR]'
    OOoOO0oo0ooO ( name , url , 20 , Oo0OoO00oOO0o , Oo0OoO00oOO0o )
    if 94 - 94: oo0ooO0oOOOOo * i1IIiiiii / I11i1i11i1I / i1IIiiiii
   elif len ( o00oooO0Oo ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = O0Oo000ooO00 + "!" + name + "!" + Oo0OoO00oOO0o
    name = '[COLOR white]' + name + '[/COLOR]'
    OOoOO0oo0ooO ( name , url , 22 , Oo0OoO00oOO0o , Oo0OoO00oOO0o )
    if 87 - 87: I11i1i11i1I . OoO000
  elif '<fightclubsearch>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<fightclubsearch>(.+?)</fightclubsearch>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = 'true|SPLIT|' + url
   OOoOO0oo0ooO ( name , url , 222 , iiiii , O0O0OO0O0O0 )
   if 75 - 75: iiIIiIiIi + OOO0O + oo0ooO0oOOOOo * oo0Ooo0 % OooooO0oOO . i1iIIIiI1I
  elif '<fightclubterms>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<fightclubterms>(.+?)</fightclubterms>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = 'false|SPLIT|' + url + '|SPLIT|' + O0Oo000ooO00 + '|SPLIT|' + name
   OOoOO0oo0ooO ( name , url , 222 , iiiii , O0O0OO0O0O0 )
   if 55 - 55: oOo0 . i1IIi11111i
  elif '<arenavision>display</arenavision>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   if os . path . exists ( oO00oOo ) : OOoOO0oo0ooO ( name , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : OO0oOoOO0oOO0 ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 61 - 61: I11i1i11i1I % OoO000 . I11i1i11i1I
  elif '<divider>null</divider>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OO0oOoOO0oOO0 ( name , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 100 - 100: OooOoO0Oo * oooO0oo0oOOOO
  elif '<regex>' in Ii1iIiII1ii1 :
   o00oO0oo0OO = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Ii1iIiII1ii1 )
   o00oO0oo0OO = '' . join ( o00oO0oo0OO )
   O0O0OOOOoo = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( o00oO0oo0OO )
   o00oO0oo0OO = urllib . quote_plus ( o00oO0oo0OO )
   if 74 - 74: i11iiII + i1111 / oo
   oOo0O0Oo00oO = hashlib . md5 ( )
   for I111I1Iiii1i in o00oO0oo0OO : oOo0O0Oo00oO . update ( str ( I111I1Iiii1i ) )
   oOo0O0Oo00oO = str ( oOo0O0Oo00oO . hexdigest ( ) )
   if 56 - 56: i11iiII % oooO0oo0oOOOO - i1IIi11111i
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Ii1iIiII1ii1 = re . sub ( '<regex>.+?</regex>' , '' , Ii1iIiII1ii1 )
   Ii1iIiII1ii1 = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Ii1iIiII1ii1 )
   Ii1iIiII1ii1 = re . sub ( '<link></link>' , '' , Ii1iIiII1ii1 )
   if 100 - 100: i1IIiiiii - oooO0oo0oOOOO % OooooO0oOO * oOo0 + i1IIi11111i
   name = re . sub ( '<meta>.+?</meta>' , '' , Ii1iIiII1ii1 )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 88 - 88: i111I - oo * oooO0oo0oOOOO * i111I . i111I
   try : I111iI = re . findall ( '<date>(.+?)</date>' , Ii1iIiII1ii1 ) [ 0 ]
   except : I111iI = ''
   if re . search ( r'\d+' , I111iI ) : name += ' [COLOR red] Updated %s[/COLOR]' % I111iI
   if 56 - 56: i1IIi11111i
   try : O0oO = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Ii1iIiII1ii1 ) [ 0 ]
   except : O0oO = iiiii
   if 73 - 73: i11iiII * i11iIiiIii % OooooO0oOO . i11iiII
   try : OOOOo0 = re . findall ( '<fanart>(.+?)</fanart>' , Ii1iIiII1ii1 ) [ 0 ]
   except : OOOOo0 = O0O0OO0O0O0
   if 49 - 49: i1111 % oooO0oo0oOOOO . OOO0O + OooooO0oOO / i1IIi11111i
   try : O0oOOoOooooO = re . findall ( '<meta>(.+?)</meta>' , Ii1iIiII1ii1 ) [ 0 ]
   except : O0oOOoOooooO = '0'
   if 62 - 62: i111I * i1IIi11111i
   try : url = re . findall ( '<link>(.+?)</link>' , Ii1iIiII1ii1 ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % O0oOOoOooooO )
   url = '<preset>search</preset>%s' % O0oOOoOooooO if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % O0oOOoOooooO )
   url = '<preset>searchsd</preset>%s' % O0oOOoOooooO if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 58 - 58: OOO0O % oo0ooO0oOOOOo
   if not o00oO0oo0OO == '' :
    hash . append ( { 'regex' : oOo0O0Oo00oO , 'response' : o00oO0oo0OO } )
    url += '|regex=%s' % o00oO0oo0OO
    if 50 - 50: OooOoO0Oo . oo0ooO0oOOOOo
   OO0oOoOO0oOO0 ( name , url , 30 , O0oO , OOOOo0 )
   if 97 - 97: oooO0oo0oOOOO + OOO0O
  elif '<sportsdevil>' in Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 )
   if len ( o00oooO0Oo ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     o0O0OOO0Ooo = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : o0O0OOO0Ooo = "None"
    Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OOO00O = O0O0OO0O0O0
    iiIiI = o0O0OOO0Ooo
    I1 = "/"
    if not iiIiI . endswith ( I1 ) :
     OOO00O0O = iiIiI + "/"
    else :
     OOO00O0O = iiIiI
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = o00OO00OoO + '%26referer=' + OOO00O0O
    OO0oOoOO0oOO0 ( name , url , 2 , Oo0OoO00oOO0o , OOO00O )
    if 89 - 89: oo0ooO0oOOOOo + oo * oo0Ooo0 * i1IIiiiii
   elif len ( o00oooO0Oo ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OOO00O = O0O0OO0O0O0
    OO0oOoOO0oOO0 ( name , O0Oo000ooO00 + 'NOTPLAY' , 8 , Oo0OoO00oOO0o , OOO00O )
    if 37 - 37: i111I - oooO0oo0oOOOO - oo0ooO0oOOOOo
  elif '<plexus>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OOO00O = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : OO0oOoOO0oOO0 ( name , O0Oo000ooO00 + 'NOTPLAY' , 7 , Oo0OoO00oOO0o , OOO00O )
   else : OO0oOoOO0oOO0 ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 77 - 77: oOo0 * ooO0oo0oO0
  elif '<rutubeplaylist>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OOO00O = O0O0OO0O0O0
   OOoOO0oo0ooO ( name , O0Oo000ooO00 , 90 , Oo0OoO00oOO0o , OOO00O )
   if 98 - 98: i1IIi11111i % i1IIiiiii * i111I
  elif '<folder>' in Ii1iIiII1ii1 :
   OoOO = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , Oo0OoO00oOO0o , OOO00O in OoOO :
    OOoOO0oo0ooO ( name , url , 1 , Oo0OoO00oOO0o , OOO00O )
    if 51 - 51: ooO0oo0oO0 . OOO0O / OooooO0oOO + oo0ooO0oOOOOo
  elif '<m3u>' in Ii1iIiII1ii1 :
   OoOO = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , Oo0OoO00oOO0o , OOO00O in OoOO :
    OOoOO0oo0ooO ( name , url , 10 , Oo0OoO00oOO0o , OOO00O )
    if 33 - 33: iiIIiIiIi . i1111 % i1iIIIiI1I + oo0ooO0oOOOOo
  elif '<rutube>' in Ii1iIiII1ii1 :
   OoOO = re . compile ( '<title>(.+?)</title>.+?rutube>(.+?)</rutube>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , Oo0OoO00oOO0o , OOO00O in OoOO :
    O0Oo000ooO00 = 'https://rutube.ru/play/embed/' + url + '?wmode=opaque&fakeFullscreen=1'
    OOoOO0oo0ooO ( name , O0Oo000ooO00 , 2 , Oo0OoO00oOO0o , OOO00O )
  else :
   o00oooO0Oo = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 )
   if len ( o00oooO0Oo ) == 1 :
    OoOO = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
    ooOOO0 = len ( oO0 )
    for name , url , Oo0OoO00oOO0o , OOO00O in OoOO :
     OO0oOoOO0oOO0 ( name , url , 2 , Oo0OoO00oOO0o , OOO00O )
   elif len ( o00oooO0Oo ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OOO00O = O0O0OO0O0O0
    OO0oOoOO0oOO0 ( name , O0Oo000ooO00 , 3 , Oo0OoO00oOO0o , OOO00O )
    if 71 - 71: I11i1i11i1I % oOo0
 IIiII111iiI1I = Ii1i1iI1iIIi ( )
 if 98 - 98: oo0Ooo0 % i11iIiiIii % iiIIiIiIi + i1IIiiiii
 if IIiII111iiI1I == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IIiII111iiI1I == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 78 - 78: i11iiII % OooooO0oOO / i1iIIIiI1I - ooO0oo0oO0
def ooooo0O0000oo ( name , url , iconimage ) :
 iIii1II11 = [ ]
 OooOo0ooo = [ ]
 o00oo0 = [ ]
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I11ii1IIiIi = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11ii1IIiIi ) [ 0 ]
 o00oooO0Oo = re . compile ( '<link>(.+?)</link>' ) . findall ( I11ii1IIiIi )
 I111I1Iiii1i = 1
 for OoOOo0OOoO in o00oooO0Oo :
  ooO0O00Oo0o = OoOOo0OOoO
  if '(' in OoOOo0OOoO :
   OoOOo0OOoO = OoOOo0OOoO . split ( '(' ) [ 0 ]
   OOO = str ( ooO0O00Oo0o . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   iIii1II11 . append ( OoOOo0OOoO )
   OooOo0ooo . append ( OOO )
  else :
   iIii1II11 . append ( OoOOo0OOoO )
   OooOo0ooo . append ( 'Link ' + str ( I111I1Iiii1i ) )
  I111I1Iiii1i = I111I1Iiii1i + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 Oo0o00OO0000 = O00ooooo00 . select ( name , OooOo0ooo )
 if Oo0o00OO0000 < 0 :
  quit ( )
 else :
  url = iIii1II11 [ Oo0o00OO0000 ]
  print url
  if 1 - 1: iiIIiIiIi . iiIIiIiIi / OOO0O - OooOoO0Oo
 url = iIii1II11 [ Oo0o00OO0000 ]
 name = OooOo0ooo [ Oo0o00OO0000 ]
 oooO ( name , url , iiiii )
 if 26 - 26: i1IIiiiii % i11iiII
def o00Oo0oooooo ( name , url , iconimage ) :
 if 76 - 76: oo0Ooo0 / oOo0 . oooO0oo0oOOOO % i1IIi11111i . oo0ooO0oOOOOo + OoO000
 iIii1II11 = [ ]
 OooOo0ooo = [ ]
 o00oo0 = [ ]
 o0o = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I11ii1IIiIi = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 o00oooO0Oo = re . compile ( '<plexus>(.+?)</plexus>' ) . findall ( I11ii1IIiIi )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11ii1IIiIi ) [ 0 ]
 if 62 - 62: i111I . oo0Ooo0
 oOOOoo00 = "plugin://program.plexus/?url="
 iiIiIIIiiI = "&mode=1&name=acestream+"
 I111I1Iiii1i = 0
 if 12 - 12: oooO0oo0oOOOO - oo0ooO0oOOOOo
 for OoOOo0OOoO in o00oooO0Oo :
  I111I1Iiii1i = I111I1Iiii1i + 1
  if 81 - 81: OOO0O - OOO0O . i1iIIIiI1I
  ooO0O00Oo0o = OoOOo0OOoO
  if '(' in OoOOo0OOoO :
   OoOOo0OOoO = OoOOo0OOoO . split ( '(' ) [ 0 ]
   OOO = str ( ooO0O00Oo0o . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   iIii1II11 . append ( OoOOo0OOoO )
   OooOo0ooo . append ( OOO )
   o0o . append ( 'Stream ' + str ( I111I1Iiii1i ) )
  else :
   iIii1II11 . append ( OoOOo0OOoO )
   OooOo0ooo . append ( 'Link ' + str ( I111I1Iiii1i ) )
   OOO = name
   if 73 - 73: oo0Ooo0 % i11iIiiIii - i1IIi11111i
   if 7 - 7: oooO0oo0oOOOO * i11iIiiIii * i1IIiiiii + iiIIiIiIi % oo - iiIIiIiIi
 if I111I1Iiii1i > 1 :
  O00ooooo00 = xbmcgui . Dialog ( )
  Oo0o00OO0000 = O00ooooo00 . select ( name , OooOo0ooo )
  if Oo0o00OO0000 < 0 :
   quit ( )
  else :
   II1IIIIiII1i = iIii1II11 [ Oo0o00OO0000 ]
   if not 'acestream://' in II1IIIIiII1i :
    II1IIIIiII1i = 'acestream://' + II1IIIIiII1i
   url = oOOOoo00 + II1IIIIiII1i + iiIiIIIiiI + OooOo0ooo [ Oo0o00OO0000 ]
   name = OooOo0ooo [ Oo0o00OO0000 ]
 else :
  II1IIIIiII1i = OoOOo0OOoO
  if not 'acestream://' in II1IIIIiII1i :
   II1IIIIiII1i = 'acestream://' + II1IIIIiII1i
  url = oOOOoo00 + II1IIIIiII1i + iiIiIIIiiI + OOO
  name = OOO
  if 1 - 1: i1111
 oooO ( name , url , iiiii )
 if 68 - 68: i1iIIIiI1I - i1IIi11111i / OooOoO0Oo / oo0Ooo0
def I11iiii ( name , url , iconimage ) :
 if 60 - 60: oo0Ooo0 . II1Ii1iI1i + OoO000 / oo0ooO0oOOOOo . i1111
 iIii1II11 = [ ]
 OooOo0ooo = [ ]
 o00oo0 = [ ]
 o0o = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I11ii1IIiIi = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 o00oooO0Oo = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( I11ii1IIiIi )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11ii1IIiIi ) [ 0 ]
 if 82 - 82: i11iiII / i1IIi11111i % ooO0oo0oO0 / II1Ii1iI1i - i1IIi11111i
 I1III1111iIi = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 38 - 38: i1iIIIiI1I + oo0Ooo0 / OooOoO0Oo % iiIIiIiIi - i11iiII
 I111I1Iiii1i = 1
 if 14 - 14: OooooO0oOO / OooOoO0Oo
 for OoOOo0OOoO in o00oooO0Oo :
  ooO0O00Oo0o = OoOOo0OOoO
  if '(' in OoOOo0OOoO :
   OoOOo0OOoO = OoOOo0OOoO . split ( '(' ) [ 0 ]
   OOO = str ( ooO0O00Oo0o . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   iIii1II11 . append ( OoOOo0OOoO )
   OooOo0ooo . append ( OOO )
   o0o . append ( 'Stream ' + str ( I111I1Iiii1i ) )
  else :
   iIii1II11 . append ( OoOOo0OOoO )
   OooOo0ooo . append ( 'Link ' + str ( I111I1Iiii1i ) )
   if 85 - 85: oo0Ooo0
  I111I1Iiii1i = I111I1Iiii1i + 1
  if 20 - 20: OooooO0oOO % OoO000
 name = '[COLOR red]' + name + '[/COLOR]'
 if 19 - 19: i11iiII % OoO000 + iiIIiIiIi / OooOoO0Oo . iiIIiIiIi
 O00ooooo00 = xbmcgui . Dialog ( )
 Oo0o00OO0000 = O00ooooo00 . select ( name , OooOo0ooo )
 if Oo0o00OO0000 < 0 :
  quit ( )
 else :
  iiIiI = OooOo0ooo [ Oo0o00OO0000 ]
  I1 = "/"
  if not iiIiI . endswith ( I1 ) :
   OOO00O0O = iiIiI + "/"
  else :
   OOO00O0O = iiIiI
  url = I1III1111iIi + iIii1II11 [ Oo0o00OO0000 ] + "%26referer=" + OOO00O0O
  if 12 - 12: II1Ii1iI1i + II1Ii1iI1i - i11iiII * I11i1i11i1I % I11i1i11i1I - i1111
 name = OooOo0ooo [ Oo0o00OO0000 ]
 oooO ( name , url , iiiii )
 if 52 - 52: iiIIiIiIi . i1iIIIiI1I + OooOoO0Oo
def iiii1IIi ( name , url , iconimage ) :
 if 33 - 33: OOO0O * oOo0 - i1111
 OOo0o0O0O = [ ]
 o0 = [ ]
 if 95 - 95: oo % II1Ii1iI1i * i11iIiiIii % I11i1i11i1I - OooooO0oOO
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I11ii1IIiIi = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 o00oooO0Oo = re . compile ( '<rutubeplaylist>(.+?)</rutubeplaylist>' ) . findall ( I11ii1IIiIi )
 if 67 - 67: OOO0O + i11iiII . oo0ooO0oOOOOo . i1111
 for OoOOo0OOoO in o00oooO0Oo :
  ooO0O00Oo0o = OoOOo0OOoO
  if '(' in OoOOo0OOoO :
   OoOOo0OOoO = OoOOo0OOoO . split ( '(' ) [ 0 ]
   OOO = str ( ooO0O00Oo0o . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   OOo0o0O0O . append ( OOO )
   o0 . append ( OoOOo0OOoO )
   o000ooooO0o = list ( zip ( OOo0o0O0O , o0 ) )
   if 40 - 40: i11iiII + II1Ii1iI1i * oOo0
 O0oOOoooOO0O = sorted ( o000ooooO0o )
 if 86 - 86: oo0ooO0oOOOOo
 for i1Iii11Ii1i1 , url in O0oOOoooOO0O :
  OOooo0O0o0 = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   II1iI1I11I = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
   if i1Iii11Ii1i1 . lower ( ) == "all" :
    II1iI1I11I = II1iI1I11I . replace ( '.' , ' ' )
    OO0oOoOO0oOO0 ( II1iI1I11I , url , 2 , iconimage , iconimage , '' )
   elif i1Iii11Ii1i1 . lower ( ) in II1iI1I11I . lower ( ) :
    II1iI1I11I = II1iI1I11I . replace ( '.' , ' ' )
    OO0oOoOO0oOO0 ( II1iI1I11I , url , 2 , iconimage , iconimage , '' )
    if 78 - 78: i1111
 try :
  oO0 = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( OOooo0O0o0 )
  o0O0Oo = str ( oO0 )
  Ooo0O0oooo = re . compile ( 'href="(.+?)"' ) . findall ( o0O0Oo ) [ 1 ]
  url = Ooo0O0oooo + "|SPLIT|" + i1Iii11Ii1i1
  OOoOO0oo0ooO ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 36 - 36: i111I . oo
def oO ( name , url , iconimage ) :
 if 10 - 10: I11i1i11i1I / I11i1i11i1I / OooOoO0Oo . OooOoO0Oo
 url , i1Iii11Ii1i1 = url . split ( "|SPLIT|" )
 if 98 - 98: I11i1i11i1I / i1IIi11111i . oooO0oo0oOOOO + oo
 OOooo0O0o0 = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 for Ii1iIiII1ii1 in oO0 :
  II1iI1I11I = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
  if i1Iii11Ii1i1 . lower ( ) == "all" :
   II1iI1I11I = II1iI1I11I . replace ( '.' , ' ' )
   OO0oOoOO0oOO0 ( II1iI1I11I , url , 2 , iconimage , iconimage , '' )
  elif i1Iii11Ii1i1 . lower ( ) in II1iI1I11I . lower ( ) :
   II1iI1I11I = II1iI1I11I . replace ( '.' , ' ' )
   OO0oOoOO0oOO0 ( II1iI1I11I , url , 2 , iconimage , iconimage , '' )
   if 43 - 43: i1111 . OooooO0oOO / i11iiII
 try :
  oO0 = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( OOooo0O0o0 )
  o0O0Oo = str ( oO0 )
  Ooo0O0oooo = re . compile ( 'href="(.+?)"' ) . findall ( o0O0Oo ) [ 1 ]
  url = Ooo0O0oooo + "|SPLIT|" + i1Iii11Ii1i1
  OOoOO0oo0ooO ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 20 - 20: i1IIi11111i
def o0oO000oo ( url ) :
 if 95 - 95: iiIIiIiIi / iiIIiIiIi
 try :
  IIiI1Ii , url = url . split ( '|SPLIT|' )
 except : IIiI1Ii , url , O0Oo000ooO00 , i1OOO = url . split ( '|SPLIT|' )
 if 57 - 57: oOo0 - iiIIiIiIi - oo0Ooo0 + oo
 if IIiI1Ii == 'true' :
  o0O0Oo = ''
  I1IIIiI11i1 = xbmc . Keyboard ( o0O0Oo , 'Enter Search Term' )
  I1IIIiI11i1 . doModal ( )
  if I1IIIiI11i1 . isConfirmed ( ) :
   o0O0Oo = I1IIIiI11i1 . getText ( )
   if len ( o0O0Oo ) > 1 :
    i1Iii11Ii1i1 = o0O0Oo . lower ( )
   else : quit ( )
   if 48 - 48: OooOoO0Oo - oo0ooO0oOOOOo % i1IIiiiii
  IIi1IIIi = [ ]
  O00Ooo = [ ]
  OOOO0OOO = [ ]
  o000ooooO0o = [ ]
  if 3 - 3: oo
  I1IiiI . create ( Oo0Ooo , "[COLOR white]We are searching for " + i1Iii11Ii1i1 + ".[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
  I1IiiI . update ( 0 )
  if 97 - 97: OooOoO0Oo
  I111I1Iiii1i = 1
  iiIII1i = 0
  OOooo0O0o0 = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '<search>(.+?)</search>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  I1I = len ( oO0 )
  for Ii1iIiII1ii1 in oO0 :
   ooooO0oOoOOoO = 100 * int ( I111I1Iiii1i ) / int ( I1I )
   I1IiiI . update ( ooooO0oOoOOoO , '' , '[COLOR blue]Searching list ' + str ( I111I1Iiii1i ) + ' of ' + str ( I1I ) + '[/COLOR]' )
   I1i11i = OOOO0OOoO0O0 ( Ii1iIiII1ii1 )
   oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( I1i11i )
   for IiIi in oO0 :
    II1iI1I11I = re . compile ( 'title="(.+?)"' ) . findall ( IiIi ) [ 0 ]
    url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( IiIi ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( IiIi ) [ 0 ]
    Oo0OoO00oOO0o = "https://pic.rutube.ru" + Oo0OoO00oOO0o + "size=l"
    II1iI1I11I = II1iI1I11I . replace ( '.' , ' ' )
    if i1Iii11Ii1i1 in II1iI1I11I . lower ( ) :
     iiIII1i = iiIII1i + 1
     IIi1IIIi . append ( II1iI1I11I )
     O00Ooo . append ( url )
     OOOO0OOO . append ( Oo0OoO00oOO0o )
     o000ooooO0o = list ( zip ( IIi1IIIi , O00Ooo , OOOO0OOO ) )
     if 87 - 87: i11iiII - i11iiII - i1iIIIiI1I + OooooO0oOO
   I111I1Iiii1i = I111I1Iiii1i + 1
   if 82 - 82: OooooO0oOO / ooO0oo0oO0 . i1IIi11111i . oOo0 / oo0ooO0oOOOOo
  O0oOOoooOO0O = sorted ( o000ooooO0o )
  OO0oOoOO0oOO0 ( '[B][COLOR dodgerblue]We found ' + str ( iiIII1i ) + ' matches for ' + i1Iii11Ii1i1 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  OO0oOoOO0oOO0 ( '#######################################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  for i1OOO , url , Oo0OoO00oOO0o in O0oOOoooOO0O :
   OO0oOoOO0oOO0 ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 2 , Oo0OoO00oOO0o , Oo0OoO00oOO0o , '' )
   if 42 - 42: I11i1i11i1I
   if 19 - 19: OooooO0oOO % i11iiII * ooO0oo0oO0 + i1IIi11111i
   if 46 - 46: I11i1i11i1I
 else :
  if 1 - 1: i1iIIIiI1I
  IIi1IIIi = [ ]
  O00Ooo = [ ]
  OOOO0OOO = [ ]
  o000ooooO0o = [ ]
  if 97 - 97: oOo0 + i1iIIIiI1I + oooO0oo0oOOOO + i11iIiiIii
  I1IiiI . create ( Oo0Ooo , "[COLOR white]We are searching for " + i1OOO + ".[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
  I1IiiI . update ( 0 )
  if 77 - 77: oo0ooO0oOOOOo / i111I
  I111I1Iiii1i = 1
  iiIII1i = 0
  OOooo0O0o0 = OOOO0OOoO0O0 ( O0Oo000ooO00 )
  I11ii1IIiIi = re . compile ( '<title>' + re . escape ( i1OOO ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( OOooo0O0o0 ) [ 0 ]
  o00oooO0Oo = re . compile ( '<term>(.+?)</term>' ) . findall ( I11ii1IIiIi )
  I1i11i = OOOO0OOoO0O0 ( url )
  IIii11I1i1I = re . compile ( '<search>(.+?)</search>' , re . DOTALL ) . findall ( I1i11i )
  I1I = len ( IIii11I1i1I )
  for Ii1iIiII1ii1 in IIii11I1i1I :
   ooooO0oOoOOoO = 100 * int ( I111I1Iiii1i ) / int ( I1I )
   I1IiiI . update ( ooooO0oOoOOoO , '' , '[COLOR blue]Searching list ' + str ( I111I1Iiii1i ) + ' of ' + str ( I1I ) + '[/COLOR]' )
   I1i11i = OOOO0OOoO0O0 ( Ii1iIiII1ii1 )
   oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( I1i11i )
   for IiIi in oO0 :
    II1iI1I11I = re . compile ( 'title="(.+?)"' ) . findall ( IiIi ) [ 0 ]
    url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( IiIi ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( IiIi ) [ 0 ]
    Oo0OoO00oOO0o = "https://pic.rutube.ru" + Oo0OoO00oOO0o + "size=l"
    II1iI1I11I = II1iI1I11I . replace ( '.' , ' ' )
    for i1Iii11Ii1i1 in o00oooO0Oo :
     if i1Iii11Ii1i1 . lower ( ) in II1iI1I11I . lower ( ) :
      iiIII1i = iiIII1i + 1
      IIi1IIIi . append ( II1iI1I11I )
      O00Ooo . append ( url )
      OOOO0OOO . append ( Oo0OoO00oOO0o )
      o000ooooO0o = list ( zip ( IIi1IIIi , O00Ooo , OOOO0OOO ) )
      if 99 - 99: i1iIIIiI1I
   I111I1Iiii1i = I111I1Iiii1i + 1
   if 76 - 76: oo * i1IIi11111i
  O0oOOoooOO0O = sorted ( o000ooooO0o )
  OO0oOoOO0oOO0 ( '[B][COLOR dodgerblue]' + i1OOO + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  OO0oOoOO0oOO0 ( '#######################################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  for i1OOO , url , Oo0OoO00oOO0o in O0oOOoooOO0O :
   OO0oOoOO0oOO0 ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 2 , Oo0OoO00oOO0o , Oo0OoO00oOO0o , '' )
   if 82 - 82: i1IIiiiii * i1iIIIiI1I / i11iiII
def IiiiiiIiI ( url ) :
 if 33 - 33: i1111 / iiIIiIiIi * oooO0oo0oOOOO % i1IIiiiii * OooOoO0Oo
 try :
  o00OO00OoO = OOOO0OOoO0O0 ( url ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  i1OOO = url . split ( '/' ) [ 2 ]
  i1OOO = i1OOO . replace ( '.html' , '' )
  O0o = re . compile ( '<div class="schedule">(.+?)<br><div id="pagination">' ) . findall ( o00OO00OoO ) [ 0 ]
  O0OOoOOO0oO = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( O0o )
  for url , Oo0OoO00oOO0o , I1ii11 , oOoOoOoo0 in O0OOoOOO0oO :
   url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + Oo0OoO00oOO0o
   OO0oOoOO0oOO0 ( '[COLOR white]' + I1ii11 + ' vs ' + oOoOoOoo0 + '[/COLOR]' , url , 2 , Oo0OoO00oOO0o , O0O0OO0O0O0 , '' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 34 - 34: OOO0O - oOo0 + oooO0oo0oOOOO . i1IIiiiii
def iIi1i1iIi1iI ( url ) :
 if 26 - 26: i111I * i1IIi11111i + oOo0
 try :
  o00OO00OoO = OOOO0OOoO0O0 ( url )
  O0OOoOOO0oO = re . compile ( "<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?" , re . DOTALL ) . findall ( o00OO00OoO )
  for IiIii1i111 , url in O0OOoOOO0oO :
   url = url . replace ( "'" , '' )
   url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iiiii
   OO0oOoOO0oOO0 ( '[COLOR white]' + IiIii1i111 + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 43 - 43: oooO0oo0oOOOO
def Ii1 ( url ) :
 if 14 - 14: ooO0oo0oO0 % ooO0oo0oO0 * i11iIiiIii - oo - oo0Ooo0
 try :
  o00oo0oooooOOO000Oo = "http://cricbox.tv/"
  o00OO00OoO = OOOO0OOoO0O0 ( url )
  O0OOoOOO0oO = re . compile ( '<td><i class=".+?<td style="font-weight:bold;font-family: Calibri;"><a href="(.+?)">.+?<span style=".+?">(.+?)</span>.+?</a></td>' , re . DOTALL ) . findall ( o00OO00OoO )
  for url , Ooo00OoOOO in O0OOoOOO0oO :
   url = o00oo0oooooOOO000Oo + url
   url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iiiii
   OO0oOoOO0oOO0 ( '[COLOR white]' + Ooo00OoOOO + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 98 - 98: ooO0oo0oO0 * i11iiII * oOo0 + iiIIiIiIi % i11iIiiIii % oooO0oo0oOOOO
def i1OO0oOOoo ( url ) :
 if 52 - 52: oo0ooO0oOOOOo % I11i1i11i1I
 try :
  o00OO00OoO = OOOO0OOoO0O0 ( url )
  O0OOoOOO0oO = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( o00OO00OoO )
  for url , Ooo00OoOOO in O0OOoOOO0oO :
   url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iiiii
   OO0oOoOO0oOO0 ( '[COLOR white]' + Ooo00OoOOO + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 64 - 64: oooO0oo0oOOOO % oo0Ooo0 % oooO0oo0oOOOO * oo . OooooO0oOO + i1IIi11111i
def O00 ( url ) :
 if 17 - 17: i1IIiiiii - i111I % i1IIiiiii . OoO000 / i11iIiiIii % i1iIIIiI1I
 I111I1Iiii1i = 0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0OOoOOO0oO = re . compile ( '<!-- Watch link. -->.+?<a href="(.+?)" title="live (.+?)" target="_blank"> ' , re . DOTALL ) . findall ( o00OO00OoO )
 for url , IiIii1i111 in O0OOoOOO0oO :
  I111I1Iiii1i = I111I1Iiii1i + 1
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iiiii
  OO0oOoOO0oOO0 ( '[COLOR white]' + IiIii1i111 + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 28 - 28: oo0Ooo0
 if I111I1Iiii1i == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 58 - 58: OOO0O
def iIiiI1iI ( ) :
 if 5 - 5: OOO0O / i111I + OoO000 * OooOoO0Oo - oo % i1IIi11111i
 o00OO00OoO = OOOO0OOoO0O0 ( "http://sports4u.live" )
 oO0 = re . compile ( '<h4>Watch live</h4>(.+?)</div>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 IiII1 = re . compile ( '<ul><li>(.+?)</ul></li>' , re . DOTALL ) . findall ( o00OO00OoO )
 for IiIi in IiII1 :
  Oo0oOOo = re . compile ( '<a href="(.+?)">' ) . findall ( IiIi ) [ 0 ]
  I1iIi1iIiiIiI = re . compile ( 'src="(.+?)"' ) . findall ( IiIi ) [ 0 ]
  i1OOO = Oo0oOOo . split ( "channel/" ) [ 1 ]
  i1OOO = i1OOO . split ( "-live" ) [ 0 ]
  i1OOO = i1OOO . replace ( "-" , " " )
  Oo0OoO00oOO0o = 'http://sports4u.live' + I1iIi1iIiiIiI
  OO0oOoOO0oOO0 ( '[COLOR white]' + i1OOO . title ( ) + '[/COLOR]' , Oo0oOOo , 306 , Oo0OoO00oOO0o , O0O0OO0O0O0 , '' )
  if 47 - 47: i1IIiiiii + OooOoO0Oo / II1Ii1iI1i % i11iIiiIii
def i111iI ( name , url , iconimage ) :
 if 85 - 85: oo0ooO0oOOOOo . OOO0O / iiIIiIiIi . oooO0oo0oOOOO % OooOoO0Oo
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="watch-stream">(.+?)</div>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 url = re . compile ( 'src="(.+?)" name="iframe_a"' , re . DOTALL ) . findall ( oO0 ) [ 0 ]
 url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iconimage + '%26title=' + name
 oooO ( name , url , iconimage )
 if 90 - 90: I11i1i11i1I % oooO0oo0oOOOO * ooO0oo0oO0 . i1iIIIiI1I
def I1iii11 ( name , url , iconimage ) :
 if 74 - 74: oooO0oo0oOOOO / II1Ii1iI1i
 oo0OooOOo0 , I1II1III11iii = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 oo0OooOOo0 += urllib . unquote_plus ( I1II1III11iii )
 url = regex . resolve ( oo0OooOOo0 )
 if 78 - 78: i111I . oo + iiIIiIiIi - II1Ii1iI1i
 oooO ( name , url , iconimage )
 if 31 - 31: i111I . oOo0
def O0 ( ) :
 if 33 - 33: II1Ii1iI1i
 OO0oOoOO0oOO0 ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 OO0oOoOO0oOO0 ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 OO0oOoOO0oOO0 ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 OOoOO0oo0ooO ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 OOoOO0oo0ooO ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 36 - 36: i1111 % i11iIiiIii * OOO0O + oo0Ooo0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 25 - 25: ooO0oo0oO0 % i1iIIIiI1I . iiIIiIiIi
def IIIIi1 ( ) :
 if 3 - 3: OooOoO0Oo
 OOoOO0oo0ooO ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 45 - 45: OooOoO0Oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 83 - 83: OOO0O . i111I
def Oo0ooo ( ) :
 if 28 - 28: OooooO0oOO . i1111 / i11iiII + i1111 . i111I . OoO000
 OOoOO0oo0ooO ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 53 - 53: i1IIiiiii % i1IIiiiii * oo0ooO0oOOOOo + OOO0O
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 92 - 92: i111I + II1Ii1iI1i / i1IIiiiii * oooO0oo0oOOOO
def O00oOo00o0o ( ) :
 if 85 - 85: i1iIIIiI1I + i111I * i1iIIIiI1I - OooOoO0Oo % i11iIiiIii
 I111I1Iiii1i = 0
 OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 for Ii1iIiII1ii1 in oO0 :
  I111I1Iiii1i = I111I1Iiii1i + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  Oo0oOOo = Ii1iIiII1ii1
  OOoOO0oo0ooO ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( I111I1Iiii1i ) + '[/COLOR]' , Oo0oOOo , 12 , iiiii , O0O0OO0O0O0 )
  if 71 - 71: i11iiII - iiIIiIiIi / OOO0O * OOO0O / II1Ii1iI1i . II1Ii1iI1i
 OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 for Ii1iIiII1ii1 in oO0 :
  I111I1Iiii1i = I111I1Iiii1i + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  Oo0oOOo = Ii1iIiII1ii1
  OOoOO0oo0ooO ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( I111I1Iiii1i ) + '[/COLOR]' , Oo0oOOo , 12 , iiiii , O0O0OO0O0O0 )
  if 53 - 53: OooOoO0Oo
 OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 for Ii1iIiII1ii1 in oO0 :
  I111I1Iiii1i = I111I1Iiii1i + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  Oo0oOOo = Ii1iIiII1ii1
  OOoOO0oo0ooO ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( I111I1Iiii1i ) + '[/COLOR]' , Oo0oOOo , 12 , iiiii , O0O0OO0O0O0 )
  if 21 - 21: oo0Ooo0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 92 - 92: i11iIiiIii / OooOoO0Oo - i1iIIIiI1I % iiIIiIiIi * OooOoO0Oo + I11i1i11i1I
def ii1 ( url ) :
 if 80 - 80: i111I - oOo0 * i1IIiiiii * i11iiII / i1IIi11111i / oOo0
 OOooo0O0o0 = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 if 13 - 13: OooOoO0Oo * iiIIiIiIi + i11iIiiIii * OooOoO0Oo - iiIIiIiIi
 for Ii1iIiII1ii1 in oO0 :
  i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  Oo0OoO00oOO0o = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  OOoOO0oo0ooO ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , Oo0OoO00oOO0o , O0O0OO0O0O0 )
  if 23 - 23: ooO0oo0oO0 * II1Ii1iI1i % i111I * OoO000
 try :
  I1Iiiiiii = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( OOooo0O0o0 ) [ 0 ]
  OOoOO0oo0ooO ( '[COLOR yellow]Next Page -->[/COLOR]' , I1Iiiiiii , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 39 - 39: OoO000 * I11i1i11i1I + ooO0oo0oO0 - OoO000 + oOo0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 69 - 69: oooO0oo0oOOOO
def o0ooO ( ) :
 if 74 - 74: oooO0oo0oOOOO * OooooO0oOO - i11iIiiIii + OooOoO0Oo
 OOooo0O0o0 = OOOO0OOoO0O0 ( 'http://arenavision.in/schedule' )
 oO0 = re . compile ( '<tr><td class="auto-style3"(.+?)</tr>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 if 17 - 17: ooO0oo0oO0 . i111I / oo0Ooo0 % i1111 % II1Ii1iI1i / i11iIiiIii
 for Ii1iIiII1ii1 in oO0 :
  try :
   I111iI = re . compile ( '190px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   time = re . compile ( '182px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOOIiiiii1iI = re . compile ( '188px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   IIi = re . compile ( '685px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   ooOooo0 = re . compile ( '317px">(.+?) ' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo = IIi + '|SPLIT|' + ooOooo0
   OO0oOoOO0oOO0 ( '[COLOR blue][B]' + IIi + '[/B][/COLOR] - [COLOR white]' + I111iI + ' | [COLOR orangered][B]' + time + '[/B][/COLOR] | ' + OOOIiiiii1iI + '[/COLOR]' , Oo0oOOo , 97 , iiiii , O0O0OO0O0O0 )
  except : pass
 IIiII111iiI1I = Ii1i1iI1iIIi ( )
 if 67 - 67: i1IIi11111i
 if IIiII111iiI1I == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IIiII111iiI1I == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 55 - 55: i11iiII - i1iIIIiI1I * oo0ooO0oOOOOo + OOO0O * OOO0O * oooO0oo0oOOOO
def O000Oo0o ( name , url , iconimage ) :
 if 99 - 99: ooO0oo0oO0 % iiIIiIiIi + iiIIiIiIi + i1iIIIiI1I - OooOoO0Oo / OooOoO0Oo
 name , url = url . split ( '|SPLIT|' )
 if 7 - 7: i1IIi11111i + OOO0O / OoO000
 OOOoO000 = "null"
 oOOOO = "null"
 if 49 - 49: i1111 . OooooO0oOO . i11iIiiIii % OoO000
 if "-" in url :
  OOOoO000 , oOOOO = url . split ( '-' )
  if 34 - 34: OooOoO0Oo % OoO000
  IiI1i = O00ooooo00 . select ( "[COLOR red]Please select an stream[/COLOR]" , [ '[COLOR white]Link 1[/COLOR]' , '[COLOR white]Link 2[/COLOR]' ] )
  if 87 - 87: iiIIiIiIi
  if IiI1i == 0 : url = 'http://arenavision.in/av' + OOOoO000
  elif IiI1i == 1 : url = 'http://arenavision.in/av' + oOOOO
  else : quit ( )
  if 45 - 45: oo / i111I - i1iIIIiI1I / i1IIiiiii % OoO000
 else : url = 'http://arenavision.in/av' + url
 if 83 - 83: i1IIi11111i . ooO0oo0oO0 - OoO000 * i11iIiiIii
 IiI11i1IIiiI ( name , url , iconimage )
 if 60 - 60: i11iiII * i1IIi11111i
 if 17 - 17: oOo0 % I11i1i11i1I / i11iiII . OoO000 * oOo0 - i1111
def IiI11i1IIiiI ( name , url , iconimage ) :
 if 41 - 41: i1IIiiiii
 try :
  OOooo0O0o0 = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( 'this.loadPlayer(.+?),' , re . DOTALL ) . findall ( OOooo0O0o0 ) [ 0 ]
  url = oO0 . replace ( '(' , '' ) . replace ( ')' , '' ) . replace ( '"' , '' ) . replace ( ' ' , '' )
  if 77 - 77: OooOoO0Oo
  O0Oo000ooO00 = 'plugin://program.plexus/?url=acestream://' + str ( url ) + '&mode=1&name=acestream+' + str ( name )
  if 65 - 65: i1111 . i1IIi11111i % OooooO0oOO * oo
  oooO ( name , O0Oo000ooO00 , iconimage )
 except : quit ( )
 if 38 - 38: OOO0O / i1iIIIiI1I % I11i1i11i1I
def I1IIIiii1 ( url ) :
 if 65 - 65: oo0Ooo0 / i1111 * i1IIiiiii . i1iIIIiI1I * OooooO0oOO % oOo0
 OOooo0O0o0 = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 for Ii1iIiII1ii1 in oO0 :
  try :
   i1OOO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except :
   i1OOO = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  OOoOO0oo0ooO ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 69 - 69: iiIIiIiIi - oo / i11iIiiIii + i11iiII % i111I
def o000O000 ( url ) :
 if 19 - 19: ooO0oo0oO0
 OOooo0O0o0 = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( OOooo0O0o0 )
 Ii1IiI1i1ii = 0
 for Ii1iIiII1ii1 in oO0 :
  try :
   i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : Ii1IiI1i1ii = 1
  if 30 - 30: OoO000 + OooOoO0Oo - OoO000 . OoO000 - i1111 + oooO0oo0oOOOO
  if Ii1IiI1i1ii == 0 :
   OOoOO0oo0ooO ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , Oo0OoO00oOO0o , O0O0OO0O0O0 )
  Ii1IiI1i1ii = 0
  if 86 - 86: II1Ii1iI1i
 try :
  I1Iiiiiii = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( OOooo0O0o0 ) [ 0 ]
  OOoOO0oo0ooO ( '[COLOR yellow]Next Page -->[/COLOR]' , I1Iiiiiii , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 41 - 41: OOO0O * oo0Ooo0 / OOO0O % OooooO0oOO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 18 - 18: i1111 . i111I % OOO0O % i1IIiiiii
def II1IiiIii ( url ) :
 if 84 - 84: OooooO0oOO % II1Ii1iI1i
 oOO = datetime . date . today ( )
 Ii1II = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 89 - 89: OooOoO0Oo + i111I + OooOoO0Oo * II1Ii1iI1i + ooO0oo0oO0 % oo0Ooo0
 OO0oOoOO0oOO0 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( Ii1II ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 OO0oOoOO0oOO0 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 59 - 59: oOo0 + i11iIiiIii
 OOooo0O0o0 = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( OOooo0O0o0 )
 Ii1IiI1i1ii = 0
 I111I1Iiii1i = 0
 for Ii1iIiII1ii1 in oO0 :
  try :
   II1iI1I11I = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    oo0OOo0O = re . compile ( '<p>(.+?)</p>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : oo0OOo0O = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<img src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : Ii1IiI1i1ii = 1
  if 39 - 39: i111I + OooooO0oOO % oOo0 / oOo0
  if Ii1IiI1i1ii == 0 :
   if 'vs' in II1iI1I11I :
    i1OOO = '[COLOR dodgerblue]' + II1iI1I11I + ' - ' + '[/COLOR][COLOR blue]' + oo0OOo0O + '[/COLOR]'
    I111I1Iiii1i = I111I1Iiii1i + 1
    OO0oOoOO0oOO0 ( i1OOO , url , 206 , Oo0OoO00oOO0o , O0O0OO0O0O0 , '' )
  Ii1IiI1i1ii = 0
  if 27 - 27: i1iIIIiI1I . oo0Ooo0 . ooO0oo0oO0 . ooO0oo0oO0
 if I111I1Iiii1i == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 20 - 20: oo0ooO0oOOOOo / II1Ii1iI1i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 71 - 71: OOO0O . II1Ii1iI1i
def o0OooO0ooo0o ( name , url , iconimage ) :
 if 47 - 47: i111I
 OOooo0O0o0 = OOOO0OOoO0O0 ( url )
 ii1i1i1IiII = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( OOooo0O0o0 ) [ 0 ]
 if 63 - 63: i1iIIIiI1I . oo / i1111 * OoO000 + OooooO0oOO % i1IIiiiii
 if not "http" in ii1i1i1IiII :
  ii1i1i1IiII = ii1i1i1IiII . replace ( "//" , "" )
  url = "http://" + ii1i1i1IiII
 else :
  url = ii1i1i1IiII
  if 12 - 12: OooOoO0Oo . oo . i1iIIIiI1I - i111I % I11i1i11i1I
 i11i1iIiii = url
 if 71 - 71: i11iiII % iiIIiIiIi - i1IIi11111i % oo0Ooo0 - oooO0oo0oOOOO
 o0O0O0 = OOOO0OOoO0O0 ( url )
 ii1i1i1IiII = re . compile ( "atob(.+?)," ) . findall ( o0O0O0 ) [ 0 ]
 ii1i1i1IiII = ii1i1i1IiII . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( ii1i1i1IiII )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + i11i1iIiii + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 oooO ( name , url , iconimage )
 if 6 - 6: i1iIIIiI1I . OoO000 * OOO0O . II1Ii1iI1i
def oOOo ( url ) :
 if 46 - 46: OoO000 + ooO0oo0oO0 + oOo0 + oo . i11iiII
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 1 - 1: OooooO0oOO
  if '<display>eWVz</display>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OOO00O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   url = base64 . b64decode ( url )
   Oo0OoO00oOO0o = base64 . b64decode ( Oo0OoO00oOO0o )
   OOO00O = base64 . b64decode ( OOO00O )
   OOoOO0oo0ooO ( i1OOO , url , 220 , Oo0OoO00oOO0o , OOO00O , '' )
   if 62 - 62: II1Ii1iI1i - oOo0
def ooIII1i1iI1 ( url ) :
 if 97 - 97: oo0Ooo0 - i11iIiiIii
 OOooo0O0o0 = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 if 17 - 17: oo0Ooo0
 for Ii1iIiII1ii1 in oO0 :
  i1OOO = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   oo0OO00oO = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : oo0OO00oO = "SD"
  oo0OO00oO = '[COLOR yellow]' + oo0OO00oO + '[/COLOR]'
  Oo0OoO00oOO0o = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  i1OOO = i1OOO . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 93 - 93: i1IIiiiii - oOo0 + ooO0oo0oO0 * oo0ooO0oOOOOo + OooOoO0Oo . i1iIIIiI1I
  OO0oOoOO0oOO0 ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR] - ' + oo0OO00oO , url , 212 , Oo0OoO00oOO0o , O0O0OO0O0O0 , '' )
  if 49 - 49: i111I * oo0Ooo0 - I11i1i11i1I . OooooO0oOO
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( OOooo0O0o0 ) [ 0 ]
  Ooo0O0oooo = 'http://www.fmovies.se/' + url
  OOoOO0oo0ooO ( "Next Page -->" , Ooo0O0oooo , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 89 - 89: iiIIiIiIi + i1IIiiiii * iiIIiIiIi / iiIIiIiIi
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 46 - 46: oo
def O0000 ( url ) :
 if 64 - 64: i1111 - i1IIi11111i
 OOooo0O0o0 = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 if 68 - 68: iiIIiIiIi - oOo0 - ooO0oo0oO0 / OOO0O + oOo0 - oo
 if 75 - 75: i1iIIIiI1I / oo0ooO0oOOOOo % ooO0oo0oO0 . i111I % i111I % i1111
def Ii1i1i1111 ( url ) :
 if 57 - 57: i1IIiiiii % i1111
 if "iptvembed" in url :
  OOooo0O0o0 = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = Ii1iIiII1ii1
   if 67 - 67: iiIIiIiIi + i1IIi11111i * i11iIiiIii - OooooO0oOO / OoO000 % i1iIIIiI1I
 if "sourcetv" in url :
  OOooo0O0o0 = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = Ii1iIiII1ii1
   if 92 - 92: i1IIiiiii - OooooO0oOO - iiIIiIiIi % i111I / oOo0
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 ooo = [ ]
 for OOOO0oooo , oooooOo0 , url in iIIIiIii :
  O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : url }
  ooo . append ( O0o0O0OO00o )
 list = [ ]
 for ooOooo0 in ooo :
  O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
  iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
  for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
   O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
  list . append ( O0o0O0OO00o )
  if 98 - 98: OooOoO0Oo - i111I % i1IIi11111i + oooO0oo0oOOOO . i1IIiiiii
 OoOOiIII1I1i1i = 0
 for ooOooo0 in list :
  OoOOiIII1I1i1i = 1
  i1OOO = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
  url = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   OO0oOoOO0oOO0 ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   OOoOO0oo0ooO ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 15 - 15: i1IIiiiii * I11i1i11i1I % i11iiII * ooO0oo0oO0 - i11iIiiIii
 if OoOOiIII1I1i1i == 0 :
  OO0oOoOO0oOO0 ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 60 - 60: i1IIi11111i * OooOoO0Oo % oo + OooooO0oOO
def o0oo ( url ) :
 if 80 - 80: OooOoO0Oo * OOO0O * i1111 - oooO0oo0oOOOO . OOO0O % i1IIi11111i
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = url
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 13 - 13: OooooO0oOO . i1IIi11111i * OooooO0oOO + i1IIi11111i
  o00oooO0Oo = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
  if len ( o00oooO0Oo ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + Oo0OoO00oOO0o
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   OOoOO0oo0ooO ( i1OOO , url , 20 , Oo0OoO00oOO0o , Oo0OoO00oOO0o )
   if 59 - 59: i1IIi11111i + i11iIiiIii + II1Ii1iI1i / oo0Ooo0
  elif len ( o00oooO0Oo ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = O0Oo000ooO00 + "!" + i1OOO + "!" + Oo0OoO00oOO0o
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   OOoOO0oo0ooO ( i1OOO , url , 22 , Oo0OoO00oOO0o , Oo0OoO00oOO0o )
   if 44 - 44: oo0Ooo0 . OOO0O * i1IIi11111i + i111I - i1iIIIiI1I - OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 15 - 15: OoO000 / oooO0oo0oOOOO . oo0ooO0oOOOOo . i11iIiiIii
def o0OO0O0Oo ( url ) :
 if 78 - 78: OOO0O / I11i1i11i1I - oOo0 - i1iIIIiI1I * OooooO0oOO
 oOO = datetime . date . today ( )
 Ii1II = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 17 - 17: i111I + oOo0 * oo0Ooo0 * OOO0O
 OO0oOoOO0oOO0 ( '[COLOR dodgerblue]EVENTS FOR ' + str ( Ii1II ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 OO0oOoOO0oOO0 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 36 - 36: oooO0oo0oOOOO + I11i1i11i1I
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = url
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 5 - 5: I11i1i11i1I * OOO0O
  o00oooO0Oo = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
  if len ( o00oooO0Oo ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + Oo0OoO00oOO0o
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   OOoOO0oo0ooO ( i1OOO , url , 20 , Oo0OoO00oOO0o , Oo0OoO00oOO0o )
   if 46 - 46: iiIIiIiIi
  elif len ( o00oooO0Oo ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0OoO00oOO0o = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = O0Oo000ooO00 + "!" + i1OOO + "!" + Oo0OoO00oOO0o
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   OOoOO0oo0ooO ( i1OOO , url , 22 , Oo0OoO00oOO0o , Oo0OoO00oOO0o )
   if 33 - 33: i1iIIIiI1I - i1111 * i111I - I11i1i11i1I - oOo0
def O0OO0O ( ) :
 if 49 - 49: ooO0oo0oO0 - oooO0oo0oOOOO . II1Ii1iI1i - i111I
 oOO = datetime . date . today ( )
 Ii1II = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 37 - 37: II1Ii1iI1i . oo0Ooo0 % OOO0O + i111I / i1iIIIiI1I
 OO0oOoOO0oOO0 ( '[COLOR dodgerblue]EVENTS FOR ' + str ( Ii1II ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 OO0oOoOO0oOO0 ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 3 - 3: i11iiII
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 oO0 = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( o00OO00OoO )
 o0O0Oo = str ( oO0 )
 IIii11I1i1I = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( o0O0Oo )
 for Ii1iIiII1ii1 in IIii11I1i1I :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in Ii1iIiII1ii1 :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    II1iI1I11I = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    Oo0OoO00oOO0o = re . compile ( 'src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     II = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
     II = i1II ( II )
    except : II = "null"
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + II1iI1I11I + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    i1OOO = IiiI11i1I ( i1OOO )
    Oo0oOOo = II1iI1I11I + "!" + II . lower ( ) + "!" + Oo0OoO00oOO0o
    OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 20 , Oo0OoO00oOO0o , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    II1iI1I11I = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     II = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : II = "null"
    Oo0OoO00oOO0o = re . compile ( 'src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + II1iI1I11I + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    i1OOO = IiiI11i1I ( i1OOO )
    Oo0oOOo = II1iI1I11I + "!" + II . lower ( ) + "!" + Oo0OoO00oOO0o
    OOoOO0oo0ooO ( i1OOO , Oo0oOOo , 20 , Oo0OoO00oOO0o , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 80 - 80: oOo0 / oo0Ooo0 / OOO0O + II1Ii1iI1i - I11i1i11i1I
def iIIiiIIi1IiI ( name , url , iconimage ) :
 if 14 - 14: OoO000 % OooooO0oOO % I11i1i11i1I - i11iIiiIii
 try :
  url , o0OO000ooOo , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 86 - 86: oo * i111I
 OooO0oOo = [ ]
 if 66 - 66: oo * I11i1i11i1I
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I11ii1IIiIi = re . compile ( '<title>' + re . escape ( o0OO000ooOo ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11ii1IIiIi ) [ 0 ]
 o00oooO0Oo = re . compile ( '<search>(.+?)</search>' ) . findall ( I11ii1IIiIi )
 for OoOOo0OOoO in o00oooO0Oo :
  OooO0oOo . append ( OoOOo0OOoO )
  if 28 - 28: oo % OOO0O % i11iiII + i1IIi11111i / i1IIi11111i
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 71 - 71: oOo0 * oo % i111I % oo / i1IIi11111i
 Oo0ooo0Ooo = 0
 if 9 - 9: I11i1i11i1I
 IIi1IIIi = [ ]
 O00Ooo = [ ]
 O0O00OOo = [ ]
 I1IiiI . update ( 0 )
 OoOOo = 0
 if 17 - 17: II1Ii1iI1i
 if oO000OoOoo00o == "true" :
  OoOOo = 1
  OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   if Oo0ooo0Ooo < 100 :
    I1IiiI . update ( Oo0ooo0Ooo )
    Oo0ooo0Ooo = Oo0ooo0Ooo + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ooo = [ ]
   for OOOO0oooo , oooooOo0 , url in iIIIiIii :
    O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : url }
    ooo . append ( O0o0O0OO00o )
   i1IIII1iii11I = [ ]
   for ooOooo0 in ooo :
    O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
    iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
    for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
     O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
    i1IIII1iii11I . append ( O0o0O0OO00o )
    if 97 - 97: i111I - OooOoO0Oo
   for ooOooo0 in i1IIII1iii11I :
    name = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
    url = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIi1IIIi . append ( name )
    O00Ooo . append ( url )
    if "hd" in name . lower ( ) :
     O0O00OOo . append ( "1" )
    else :
     O0O00OOo . append ( "0" )
    o000ooooO0o = list ( zip ( O0O00OOo , IIi1IIIi , O00Ooo ) )
    if 58 - 58: ooO0oo0oO0 + oooO0oo0oOOOO
 if iiiI11 == "true" :
  OoOOo = 1
  OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   if Oo0ooo0Ooo < 100 :
    I1IiiI . update ( Oo0ooo0Ooo )
    Oo0ooo0Ooo = Oo0ooo0Ooo + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ooo = [ ]
   for OOOO0oooo , oooooOo0 , url in iIIIiIii :
    O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : url }
    ooo . append ( O0o0O0OO00o )
   i1IIII1iii11I = [ ]
   for ooOooo0 in ooo :
    O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
    iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
    for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
     O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
    i1IIII1iii11I . append ( O0o0O0OO00o )
    if 30 - 30: iiIIiIiIi % i1iIIIiI1I * oOo0 - i11iiII * i1IIiiiii % iiIIiIiIi
   for ooOooo0 in i1IIII1iii11I :
    name = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
    url = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIi1IIIi . append ( name )
    O00Ooo . append ( url )
    if "hd" in name . lower ( ) :
     O0O00OOo . append ( "1" )
    else :
     O0O00OOo . append ( "0" )
    o000ooooO0o = list ( zip ( O0O00OOo , IIi1IIIi , O00Ooo ) )
    if 46 - 46: i11iIiiIii - oooO0oo0oOOOO . OooooO0oOO
 if OOooO == "true" :
  OoOOo = 1
  OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   if Oo0ooo0Ooo < 100 :
    I1IiiI . update ( Oo0ooo0Ooo )
    Oo0ooo0Ooo = Oo0ooo0Ooo + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ooo = [ ]
   for OOOO0oooo , oooooOo0 , url in iIIIiIii :
    O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : url }
    ooo . append ( O0o0O0OO00o )
   i1IIII1iii11I = [ ]
   for ooOooo0 in ooo :
    O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
    iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
    for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
     O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
    i1IIII1iii11I . append ( O0o0O0OO00o )
    if 100 - 100: i1IIi11111i / oo0ooO0oOOOOo * i1iIIIiI1I . oooO0oo0oOOOO / oOo0
   for ooOooo0 in i1IIII1iii11I :
    name = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
    url = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIi1IIIi . append ( name )
    O00Ooo . append ( url )
    if "hd" in name . lower ( ) :
     O0O00OOo . append ( "1" )
    else :
     O0O00OOo . append ( "0" )
    o000ooooO0o = list ( zip ( O0O00OOo , IIi1IIIi , O00Ooo ) )
    if 83 - 83: OooOoO0Oo
 if OoOOo == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 48 - 48: i1111 * oOo0 * OooOoO0Oo
 O0oOOoooOO0O = sorted ( o000ooooO0o , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 i1iiiIii11 = sorted ( OooO0oOo )
 if 67 - 67: oo0ooO0oOOOOo % OOO0O . OOO0O - iiIIiIiIi
 oO00OOoO00 = 0
 if 90 - 90: iiIIiIiIi + i1111 * i11iiII / i1IIiiiii . oo0ooO0oOOOOo + oo0ooO0oOOOOo
 I1IiiI . update ( 100 )
 if 40 - 40: iiIIiIiIi / OOO0O % i11iIiiIii % i11iiII / i1IIi11111i
 OO0oOoOO0oOO0 ( '[COLOR dodgerblue][B]LINKS FOR ' + o0OO000ooOo . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 OO0oOoOO0oOO0 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 62 - 62: II1Ii1iI1i - OOO0O
 if 62 - 62: II1Ii1iI1i + I11i1i11i1I % OoO000
 for II in i1iiiIii11 :
  if 28 - 28: i11iiII . II1Ii1iI1i
  OO0oOoOO0oOO0 ( '[COLOR orangered][B]' + II . upper ( ) + ' LINKS[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 10 - 10: oo / I11i1i11i1I
  o0O0Oo = II . split ( ' ' )
  if 15 - 15: i1iIIIiI1I . OOO0O / i1iIIIiI1I * oo0Ooo0 - i1IIi11111i % i11iiII
  for oo0OOOOOO0 , name , url in O0oOOoooOO0O :
   if 26 - 26: ooO0oo0oO0
   OOOo = 0
   if 79 - 79: OOO0O % OoO000 % I11i1i11i1I
   for Ii1I1iiiiii in o0O0Oo :
    if 65 - 65: OoO000 + I11i1i11i1I
    if not Ii1I1iiiiii . lower ( ) in name . lower ( ) :
     OOOo = 1
     if 59 - 59: i111I + oo0Ooo0 . OooOoO0Oo - oooO0oo0oOOOO % ooO0oo0oO0 / oooO0oo0oOOOO
   if OOOo == 0 :
    oO00OOoO00 = oO00OOoO00 + 1
    if "hd" in name . lower ( ) :
     OO0oOoOO0oOO0 ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( oO00OOoO00 ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     OO0oOoOO0oOO0 ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( oO00OOoO00 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 88 - 88: I11i1i11i1I . oooO0oo0oOOOO % i111I / oOo0
  if oO00OOoO00 == 0 :
   OO0oOoOO0oOO0 ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 89 - 89: i1111 / OooooO0oOO
  o0O0Oo = ""
  if 14 - 14: oOo0 . i1IIi11111i * iiIIiIiIi + i1111 - iiIIiIiIi + oOo0
 I1IiiI . close ( )
 if 18 - 18: OooooO0oOO - oo0ooO0oOOOOo - i1IIi11111i - i1IIi11111i
def OOooo00 ( name , url , iconimage ) :
 if 35 - 35: OooOoO0Oo . OOO0O * i11iIiiIii
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 44 - 44: i11iIiiIii / I11i1i11i1I
 Oo0ooo0Ooo = 0
 try :
  o0OO000ooOo , II , iconimage = url . split ( '!' )
 except :
  try :
   II , iconimage = url . split ( '!' )
   o0OO000ooOo = II
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 42 - 42: i111I + I11i1i11i1I % i1111 + oo
 I11i11I1iiII = 0
 if 28 - 28: i11iIiiIii / oo0ooO0oOOOOo . ooO0oo0oO0 / i1111
 if "all " in name . lower ( ) :
  II = II . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  o0OO000ooOo = o0OO000ooOo . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  I11i11I1iiII = 1
  if 72 - 72: i111I / i1IIi11111i + i1IIiiiii / OOO0O * i1IIiiiii
 IIi1IIIi = [ ]
 O00Ooo = [ ]
 O0O00OOo = [ ]
 I1IiiI . update ( 0 )
 OoOOo = 0
 if oO000OoOoo00o == "true" :
  OoOOo = 1
  OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   if Oo0ooo0Ooo < 100 :
    I1IiiI . update ( Oo0ooo0Ooo )
    Oo0ooo0Ooo = Oo0ooo0Ooo + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ooo = [ ]
   for OOOO0oooo , oooooOo0 , url in iIIIiIii :
    O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : url }
    ooo . append ( O0o0O0OO00o )
   i1IIII1iii11I = [ ]
   for ooOooo0 in ooo :
    O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
    iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
    for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
     O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
    i1IIII1iii11I . append ( O0o0O0OO00o )
    if 34 - 34: oooO0oo0oOOOO * oooO0oo0oOOOO % i111I + i1iIIIiI1I * ooO0oo0oO0 % i1IIiiiii
   for ooOooo0 in i1IIII1iii11I :
    name = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
    url = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIi1IIIi . append ( name )
    O00Ooo . append ( url )
    if "hd" in name . lower ( ) :
     O0O00OOo . append ( "1" )
    else :
     O0O00OOo . append ( "0" )
    o000ooooO0o = list ( zip ( O0O00OOo , IIi1IIIi , O00Ooo ) )
    if 25 - 25: oo0Ooo0 + OOO0O . oo0ooO0oOOOOo % OOO0O * oOo0
 if iiiI11 == "true" :
  OoOOo = 1
  OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   if Oo0ooo0Ooo < 100 :
    I1IiiI . update ( Oo0ooo0Ooo )
    Oo0ooo0Ooo = Oo0ooo0Ooo + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ooo = [ ]
   for OOOO0oooo , oooooOo0 , url in iIIIiIii :
    O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : url }
    ooo . append ( O0o0O0OO00o )
   i1IIII1iii11I = [ ]
   for ooOooo0 in ooo :
    O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
    iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
    for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
     O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
    i1IIII1iii11I . append ( O0o0O0OO00o )
    if 32 - 32: i11iIiiIii - OooOoO0Oo
   for ooOooo0 in i1IIII1iii11I :
    name = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
    url = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIi1IIIi . append ( name )
    O00Ooo . append ( url )
    if "hd" in name . lower ( ) :
     O0O00OOo . append ( "1" )
    else :
     O0O00OOo . append ( "0" )
    o000ooooO0o = list ( zip ( O0O00OOo , IIi1IIIi , O00Ooo ) )
    if 53 - 53: i111I - OoO000
 if OOooO == "true" :
  OoOOo = 1
  OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
  for Ii1iIiII1ii1 in oO0 :
   if Oo0ooo0Ooo < 100 :
    I1IiiI . update ( Oo0ooo0Ooo )
    Oo0ooo0Ooo = Oo0ooo0Ooo + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ooo = [ ]
   for OOOO0oooo , oooooOo0 , url in iIIIiIii :
    O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : url }
    ooo . append ( O0o0O0OO00o )
   i1IIII1iii11I = [ ]
   for ooOooo0 in ooo :
    O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
    iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
    for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
     O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
    i1IIII1iii11I . append ( O0o0O0OO00o )
    if 87 - 87: OooooO0oOO . i1IIi11111i
   for ooOooo0 in i1IIII1iii11I :
    name = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
    url = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIi1IIIi . append ( name )
    O00Ooo . append ( url )
    if "hd" in name . lower ( ) :
     O0O00OOo . append ( "1" )
    else :
     O0O00OOo . append ( "0" )
    o000ooooO0o = list ( zip ( O0O00OOo , IIi1IIIi , O00Ooo ) )
    if 17 - 17: i1IIiiiii . i11iIiiIii
 if OoOOo == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 5 - 5: i11iiII + oooO0oo0oOOOO + oooO0oo0oOOOO . OooOoO0Oo - iiIIiIiIi
 O0oOOoooOO0O = sorted ( o000ooooO0o , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 if 63 - 63: OooooO0oOO
 oO00OOoO00 = 0
 if 71 - 71: II1Ii1iI1i . i1IIiiiii * i1iIIIiI1I % i111I + oOo0
 I1IiiI . update ( 100 )
 if 36 - 36: OoO000
 OO0oOoOO0oOO0 ( '[COLOR dodgerblue][B]LINKS FOR ' + o0OO000ooOo . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 OO0oOoOO0oOO0 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 o0O0Oo = II . split ( ' ' )
 for oo0OOOOOO0 , name , url in O0oOOoooOO0O :
  if I11i11I1iiII == 1 :
   i1iiI = name
   if 74 - 74: OooOoO0Oo % i11iiII
  OOOo = 0
  if 7 - 7: i1111
  for Ii1I1iiiiii in o0O0Oo :
   if 27 - 27: OooooO0oOO . i111I + i11iIiiIii
   if not Ii1I1iiiiii . lower ( ) in name . lower ( ) :
    OOOo = 1
    if 86 - 86: oo0Ooo0 / oo0ooO0oOOOOo - oo0ooO0oOOOOo + i11iiII + OooooO0oOO
  if OOOo == 0 :
   oO00OOoO00 = oO00OOoO00 + 1
   if I11i11I1iiII == 1 :
    if "hd" in name . lower ( ) :
     OO0oOoOO0oOO0 ( '[COLOR blue] ' + str ( i1iiI ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     OO0oOoOO0oOO0 ( '[COLOR blue] ' + str ( i1iiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     OO0oOoOO0oOO0 ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( oO00OOoO00 ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     OO0oOoOO0oOO0 ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( oO00OOoO00 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 33 - 33: oo0ooO0oOOOOo . i1iIIIiI1I . OoO000 . II1Ii1iI1i
 if oO00OOoO00 == 0 :
  OO0oOoOO0oOO0 ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 49 - 49: i11iiII
 I1IiiI . close ( )
 if 84 - 84: oo0Ooo0 - I11i1i11i1I / oooO0oo0oOOOO - OooOoO0Oo
def ii1iI1II11ii ( term ) :
 if 8 - 8: iiIIiIiIi * oooO0oo0oOOOO
 iIii1II11 = [ ]
 OooOo0ooo = [ ]
 if 73 - 73: oo0ooO0oOOOOo / OooooO0oOO / oo0Ooo0 / oo
 OOooo0O0o0 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooo0O0o0 )
 for Ii1iIiII1ii1 in oO0 :
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  Oo0oOOo = Ii1iIiII1ii1
  if 11 - 11: OOO0O + OoO000 - i111I / oo
  Oo0oOOo = Oo0oOOo . replace ( '#AAASTREAM:' , '#A:' )
  Oo0oOOo = Oo0oOOo . replace ( '#EXTINF:' , '#A:' )
  iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( Oo0oOOo )
  ooo = [ ]
  for OOOO0oooo , oooooOo0 , Oo0oOOo in iIIIiIii :
   O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : Oo0oOOo }
   ooo . append ( O0o0O0OO00o )
  list = [ ]
  for ooOooo0 in ooo :
   O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
   iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
   for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
    O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
   list . append ( O0o0O0OO00o )
   if 34 - 34: iiIIiIiIi
  for ooOooo0 in list :
   i1OOO = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
   Oo0oOOo = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
   Oo0oOOo = Oo0oOOo . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in i1OOO . lower ( ) :
    iIii1II11 . append ( Oo0oOOo )
    OooOo0ooo . append ( i1OOO )
    if 45 - 45: iiIIiIiIi / I11i1i11i1I / i1IIiiiii
 O00ooooo00 = xbmcgui . Dialog ( )
 Oo0o00OO0000 = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , OooOo0ooo )
 if Oo0o00OO0000 < 0 :
  quit ( )
  if 44 - 44: i11iiII - i1IIiiiii / i1111 * oo * I11i1i11i1I
 Oo0oOOo = iIii1II11 [ Oo0o00OO0000 ]
 i1OOO = OooOo0ooo [ Oo0o00OO0000 ]
 oooO ( i1OOO , Oo0oOOo , iiiii )
 if 73 - 73: oo0ooO0oOOOOo - i1IIi11111i * II1Ii1iI1i / i11iIiiIii * oOo0 % i1111
def OooOoOOo0oO00 ( name , url , iconimage ) :
 if 73 - 73: i1iIIIiI1I / i11iiII % i11iiII * oo0Ooo0 / i11iiII
 list = iI1I11iIIi1 ( url )
 if 39 - 39: oo0ooO0oOOOOo . ooO0oo0oO0
 o0iIiiIiiIi = 0
 OooO0 = open ( iI1Ii11111iIi , mode = 'r' ) ; i1iiIIIi = OooO0 . read ( ) ; OooO0 . close ( )
 i1iiIIIi = i1iiIIIi . replace ( '\n' , '' )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( i1iiIIIi )
 OoOOiIII1I1i1i = 0
 for Ii1iIiII1ii1 in oO0 :
  if 62 - 62: oooO0oo0oOOOO / i1IIi11111i % oooO0oo0oOOOO * oo % i1IIi11111i
  Ii = re . compile ( '<url>(.+?)</url>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  if 99 - 99: oo * i11iIiiIii . i111I % I11i1i11i1I
  if url == Ii :
   o0iIiiIiiIi = 1
   if 76 - 76: oooO0oo0oOOOO . OooOoO0Oo * i1iIIIiI1I * oOo0 . OOO0O . i11iIiiIii
 for ooOooo0 in list :
  name = o0OIIiI1I1 ( ooOooo0 [ "display_name" ] )
  url = o0OIIiI1I1 ( ooOooo0 [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if o0iIiiIiiIi == 1 :
   if 21 - 21: oo0ooO0oOOOOo / OOO0O / ooO0oo0oO0 % oOo0
   OooO0 = open ( i1i1II , mode = 'r' ) ; i1iiIIIi = OooO0 . read ( ) ; OooO0 . close ( )
   i1iiIIIi = i1iiIIIi . replace ( '\n' , '' )
   oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( i1iiIIIi )
   for Ii1iIiII1ii1 in oO0 :
    if 2 - 2: i11iIiiIii - i1111 / OooooO0oOO % oooO0oo0oOOOO
    oo0O0o = re . compile ( '<name>(.+?)</name>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    if 87 - 87: I11i1i11i1I / oooO0oo0oOOOO * OoO000 / oo0ooO0oOOOOo
    I1iiIII = oo0O0o . replace ( ' ' , '' )
    iIi1I1 = name . replace ( ' ' , '' )
    if I1iiIII . lower ( ) in iIi1I1 . lower ( ) :
     if 63 - 63: i1iIIIiI1I * i11iiII . i111I / oOo0 * I11i1i11i1I . iiIIiIiIi
     OooO0 = open ( O0oo0OO0 , mode = 'r' ) ; i1iiIIIi = OooO0 . read ( ) ; OooO0 . close ( )
     i1iiIIIi = i1iiIIIi . replace ( '\n' , '' )
     oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( i1iiIIIi )
     for Ii1iIiII1ii1 in oO0 :
      if 62 - 62: II1Ii1iI1i / iiIIiIiIi . i1IIi11111i * oo0ooO0oOOOOo
      i11i1Ii1 = re . compile ( '<replace>(.+?)</replace>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
      if 98 - 98: OooOoO0Oo
      name = name . lower ( ) . replace ( i11i1Ii1 , '' )
      if 92 - 92: OooOoO0Oo - ooO0oo0oO0
     OO0oOoOO0oOO0 ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 32 - 32: i1IIiiiii % oo * oo + OoO000 * i1111 * i1IIiiiii
  else : OO0oOoOO0oOO0 ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 11 - 11: OooooO0oOO % i1111
def iI1I11iIIi1 ( url ) :
 if 57 - 57: oOo0 / I11i1i11i1I
 oO0O0Ooo = IIIii1II1II ( url )
 oO0O0Ooo = oO0O0Ooo . replace ( '#AAASTREAM:' , '#A:' )
 oO0O0Ooo = oO0O0Ooo . replace ( '#EXTINF:' , '#A:' )
 iIIIiIii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( oO0O0Ooo )
 ooo = [ ]
 for OOOO0oooo , oooooOo0 , url in iIIIiIii :
  O0o0O0OO00o = { "params" : OOOO0oooo , "display_name" : oooooOo0 , "url" : url }
  ooo . append ( O0o0O0OO00o )
 list = [ ]
 for ooOooo0 in ooo :
  O0o0O0OO00o = { "display_name" : ooOooo0 [ "display_name" ] , "url" : ooOooo0 [ "url" ] }
  iIIIiIii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooOooo0 [ "params" ] )
  for OOo00O , o0Ii1Iii111IiI1 in iIIIiIii :
   O0o0O0OO00o [ OOo00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = o0Ii1Iii111IiI1 . strip ( )
  list . append ( O0o0O0OO00o )
  if 4 - 4: i1111 . oo0Ooo0 + i1IIiiiii * OooOoO0Oo . iiIIiIiIi
 return list
 if 87 - 87: OOO0O / oo / i11iIiiIii
 if 74 - 74: OooooO0oOO / i11iiII % oo0ooO0oOOOOo
def OO0o0OO0 ( ) :
 if 56 - 56: i11iIiiIii - I11i1i11i1I / i1iIIIiI1I / OOO0O
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 43 - 43: oo0ooO0oOOOOo . i1iIIIiI1I . oo0Ooo0 + ooO0oo0oO0
def OoOOoO0oOo ( name , url , iconimage ) :
 if 70 - 70: oo0Ooo0 % ooO0oo0oO0 . I11i1i11i1I + I11i1i11i1I - oo0ooO0oOOOOo % OooOoO0Oo
 i1IIi1i1Ii1 = datetime . datetime . now ( )
 o00oo0oooooOOO000Oo = i1IIi1i1Ii1 . day
 if 45 - 45: ooO0oo0oO0 . OooooO0oOO / OOO0O / OoO000
 ooOOOoOoOOO0 = o00oo0oooooOOO000Oo
 if 5 - 5: oOo0
 I1i1iIi1I1 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OOO0 = datetime . datetime . strftime ( I1i1iIi1I1 , '%A - %d %B %Y' )
 iIiIIi = 'http://www.predictz.com/predictions/'
 if 14 - 14: oo0ooO0oOOOOo / oOo0 - ooO0oo0oO0 - OooooO0oOO % iiIIiIiIi
 I1iIiI1IiIIII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1iiIi111I = datetime . datetime . strftime ( I1iIiI1IiIIII , '%A - %d %B %Y' )
 Iiii1iIii = datetime . datetime . strftime ( I1iIiI1IiIIII , '%d' )
 oOoooO000O = 'http://www.predictz.com/predictions/tomorrow/'
 if 49 - 49: oo0ooO0oOOOOo * i1IIiiiii + oo0Ooo0 + i1iIIIiI1I
 IIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooo0O0OOO000o = datetime . datetime . strftime ( IIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iiI1iii = datetime . datetime . strftime ( IIi11 , '%y%m%d' )
 OOoOOo00O0o0 = 'http://www.predictz.com/predictions/20' + str ( iiI1iii )
 if 83 - 83: ooO0oo0oO0 % OOO0O % oo0ooO0oOOOOo % OooOoO0Oo . i11iiII % oooO0oo0oOOOO
 iIiIi1ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iiiiiII = datetime . datetime . strftime ( iIiIi1ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii1ii = datetime . datetime . strftime ( iIiIi1ii , '%y%m%d' )
 IIiI1i = 'http://www.predictz.com/predictions/20' + str ( ii1ii )
 if 6 - 6: i11iiII / i1iIIIiI1I - oOo0
 o00O00Oo00O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IIii1I1I1I = datetime . datetime . strftime ( o00O00Oo00O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoOOOo0 = datetime . datetime . strftime ( o00O00Oo00O , '%y%m%d' )
 o00 = 'http://www.predictz.com/predictions/20' + str ( OoOOOo0 )
 if 33 - 33: oo0ooO0oOOOOo % oo + oo0ooO0oOOOOo - iiIIiIiIi
 if 39 - 39: i11iiII % oo % i1IIiiiii
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOO0 ) + '[/B][/COLOR]' , iIiIIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1iiIi111I ) + '[/B][/COLOR]' , oOoooO000O , 41 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( ooo0O0OOO000o ) , OOoOOo00O0o0 , 41 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( iiiiiII ) , IIiI1i , 41 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( IIii1I1I1I ) , o00 , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 55 - 55: oooO0oo0oOOOO - OooOoO0Oo
def oOO0o0oo0 ( name , url , iconimage ) :
 if 78 - 78: oOo0 + i1iIIIiI1I . OoO000
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 o0O0Oo = str ( oO0 )
 IIii11I1i1I = re . compile ( '<tr(.+?)</tr>' ) . findall ( o0O0Oo )
 for Ii1iIiII1ii1 in IIii11I1i1I :
  try :
   oo0OOo0O = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR red][B]' + oo0OOo0O + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   II1iI1I11I = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OoIIi1iI = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   II1iI1I11I = oO0Ooo0OooOOo ( II1iI1I11I )
   OoIIi1iI = oO0Ooo0OooOOo ( OoIIi1iI )
   OO0oOoOO0oOO0 ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + OoIIi1iI + ' [/B][/COLOR]| [COLOR mediumpurple]' + II1iI1I11I + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 71 - 71: OoO000 + II1Ii1iI1i * I11i1i11i1I % I11i1i11i1I / I11i1i11i1I
def OoO00o0 ( name , url , iconimage ) :
 if 68 - 68: oooO0oo0oOOOO
 i1IIi1i1Ii1 = datetime . datetime . now ( )
 o00oo0oooooOOO000Oo = i1IIi1i1Ii1 . day
 if 2 - 2: oo + oooO0oo0oOOOO * oo - i1IIiiiii + OooooO0oOO
 ooOOOoOoOOO0 = o00oo0oooooOOO000Oo
 if 43 - 43: i11iiII - OOO0O
 I1i1iIi1I1 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OOO0 = datetime . datetime . strftime ( I1i1iIi1I1 , '%A - %d %B %Y' )
 iIiIIi = 'http://www.predictz.com/predictions/'
 if 36 - 36: i11iiII - i1iIIIiI1I
 I1iIiI1IiIIII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1iiIi111I = datetime . datetime . strftime ( I1iIiI1IiIIII , '%A - %d %B %Y' )
 Iiii1iIii = datetime . datetime . strftime ( I1iIiI1IiIIII , '%d' )
 oOoooO000O = 'http://www.predictz.com/predictions/tomorrow/'
 if 24 - 24: oo0ooO0oOOOOo + iiIIiIiIi + oo0Ooo0 - ooO0oo0oO0
 IIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooo0O0OOO000o = datetime . datetime . strftime ( IIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iiI1iii = datetime . datetime . strftime ( IIi11 , '%y%m%d' )
 OOoOOo00O0o0 = 'http://www.predictz.com/predictions/20' + str ( iiI1iii )
 if 49 - 49: oo0Ooo0 . iiIIiIiIi * OOO0O % OoO000 . oooO0oo0oOOOO
 iIiIi1ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iiiiiII = datetime . datetime . strftime ( iIiIi1ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii1ii = datetime . datetime . strftime ( iIiIi1ii , '%y%m%d' )
 IIiI1i = 'http://www.predictz.com/predictions/20' + str ( ii1ii )
 if 48 - 48: oooO0oo0oOOOO * i1IIiiiii - oooO0oo0oOOOO / i1IIiiiii + OOO0O
 o00O00Oo00O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IIii1I1I1I = datetime . datetime . strftime ( o00O00Oo00O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoOOOo0 = datetime . datetime . strftime ( o00O00Oo00O , '%y%m%d' )
 o00 = 'http://www.predictz.com/predictions/20' + str ( OoOOOo0 )
 if 52 - 52: oo % i1IIiiiii * i1111
 if 4 - 4: oo0Ooo0 % oooO0oo0oOOOO - i111I + iiIIiIiIi . OooooO0oOO % i1111
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOO0 ) + '[/B][/COLOR]' , iIiIIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1iiIi111I ) + '[/B][/COLOR]' , oOoooO000O , 51 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( ooo0O0OOO000o ) , OOoOOo00O0o0 , 51 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( iiiiiII ) , IIiI1i , 51 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( IIii1I1I1I ) , o00 , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 9 - 9: i1111 * i1111 . i11iIiiIii * ooO0oo0oO0
def II1I11Iii1 ( name , url , iconimage ) :
 if 16 - 16: i1IIiiiii * oo / OooooO0oOO
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 o0O0Oo = str ( oO0 )
 IIii11I1i1I = re . compile ( '<tr(.+?)</tr>' ) . findall ( o0O0Oo )
 for Ii1iIiII1ii1 in IIii11I1i1I :
  try :
   oo0OOo0O = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR red][B]' + oo0OOo0O + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   II1iI1I11I = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   II1iiI = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   III1Ii1i1I1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   O0O00OooO = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   II1iI1I11I = oO0Ooo0OooOOo ( II1iI1I11I )
   OO0oOoOO0oOO0 ( '[COLOR mediumpurple][B]' + II1iI1I11I + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + II1iiI + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + III1Ii1i1I1 + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + O0O00OooO + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 40 - 40: oo0Ooo0 % i111I - oOo0 + oo0ooO0oOOOOo / oOo0
def ooO ( name , url , iconimage ) :
 if 22 - 22: i11iIiiIii / oooO0oo0oOOOO
 i1IIi1i1Ii1 = datetime . datetime . now ( )
 o00oo0oooooOOO000Oo = i1IIi1i1Ii1 . day
 if 94 - 94: iiIIiIiIi * oo0Ooo0 - OoO000 . ooO0oo0oO0
 ooOOOoOoOOO0 = o00oo0oooooOOO000Oo
 if 66 - 66: iiIIiIiIi - oOo0 * OOO0O / OooooO0oOO * i1111 * oo
 I1i1iIi1I1 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OOO0 = datetime . datetime . strftime ( I1i1iIi1I1 , '%A - %d %B %Y' )
 iIiIIi = 'http://www.predictz.com/predictions/'
 if 91 - 91: i111I / i1IIiiiii . i1IIi11111i + iiIIiIiIi . i1111
 I1iIiI1IiIIII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1iiIi111I = datetime . datetime . strftime ( I1iIiI1IiIIII , '%A - %d %B %Y' )
 Iiii1iIii = datetime . datetime . strftime ( I1iIiI1IiIIII , '%d' )
 oOoooO000O = 'http://www.predictz.com/predictions/tomorrow/'
 if 45 - 45: OooooO0oOO * OOO0O / ooO0oo0oO0
 IIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooo0O0OOO000o = datetime . datetime . strftime ( IIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iiI1iii = datetime . datetime . strftime ( IIi11 , '%y%m%d' )
 OOoOOo00O0o0 = 'http://www.predictz.com/predictions/20' + str ( iiI1iii )
 if 77 - 77: OooOoO0Oo - oo0Ooo0
 iIiIi1ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iiiiiII = datetime . datetime . strftime ( iIiIi1ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii1ii = datetime . datetime . strftime ( iIiIi1ii , '%y%m%d' )
 IIiI1i = 'http://www.predictz.com/predictions/20' + str ( ii1ii )
 if 11 - 11: i11iiII
 o00O00Oo00O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IIii1I1I1I = datetime . datetime . strftime ( o00O00Oo00O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoOOOo0 = datetime . datetime . strftime ( o00O00Oo00O , '%y%m%d' )
 o00 = 'http://www.predictz.com/predictions/20' + str ( OoOOOo0 )
 if 26 - 26: ooO0oo0oO0 * OooOoO0Oo - oOo0
 if 27 - 27: i11iiII * OooOoO0Oo - oo + i1IIiiiii * i1IIiiiii
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOO0 ) + '[/B][/COLOR]' , iIiIIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1iiIi111I ) + '[/B][/COLOR]' , oOoooO000O , 61 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( ooo0O0OOO000o ) , OOoOOo00O0o0 , 61 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( iiiiiII ) , IIiI1i , 61 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( IIii1I1I1I ) , o00 , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 55 - 55: iiIIiIiIi
def o0O0OO0o ( name , url , iconimage ) :
 if 54 - 54: OOO0O . OooooO0oOO % i11iIiiIii / i111I + OoO000 % OooooO0oOO
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 o0O0Oo = str ( oO0 )
 IIii11I1i1I = re . compile ( '<tr(.+?)</tr>' ) . findall ( o0O0Oo )
 for Ii1iIiII1ii1 in IIii11I1i1I :
  try :
   oo0OOo0O = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR red][B]' + oo0OOo0O + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   II1iI1I11I = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO00OOoO00 , IiI111111IIII = II1iI1I11I . split ( ' v ' )
   i1ii1IIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   II1ii1ii11I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   o0ooOO0o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   ooo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 3 ]
   i1iI1i1I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 4 ]
   O0Oo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 5 ]
   OOooO0OO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 6 ]
   iI1iIiiiI1I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 7 ]
   OOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 8 ]
   OoI1IiiiIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 9 ]
   if 77 - 77: i1IIiiiii / i1111 - i1IIiiiii / oOo0
   if i1ii1IIiI == "W" :
    i1ii1IIiI = '[COLOR lime]W[/COLOR]'
   elif i1ii1IIiI == "D" :
    i1ii1IIiI = '[COLOR yellow]D[/COLOR]'
   else : i1ii1IIiI = '[COLOR red]L[/COLOR]'
   if 97 - 97: oOo0 / OooooO0oOO . i1111
   if II1ii1ii11I1 == "W" :
    II1ii1ii11I1 = '[COLOR lime]W[/COLOR]'
   elif II1ii1ii11I1 == "D" :
    II1ii1ii11I1 = '[COLOR yellow]D[/COLOR]'
   else : II1ii1ii11I1 = '[COLOR red]L[/COLOR]'
   if 44 - 44: i1IIiiiii % oo0Ooo0 . OooOoO0Oo
   if o0ooOO0o == "W" :
    o0ooOO0o = '[COLOR lime]W[/COLOR]'
   elif o0ooOO0o == "D" :
    o0ooOO0o = '[COLOR yellow]D[/COLOR]'
   else : o0ooOO0o = '[COLOR red]L[/COLOR]'
   if 18 - 18: ooO0oo0oO0 + oo0Ooo0 * i1IIi11111i - oOo0 / i1IIi11111i
   if ooo0 == "W" :
    ooo0 = '[COLOR lime]W[/COLOR]'
   elif ooo0 == "D" :
    ooo0 = '[COLOR yellow]D[/COLOR]'
   else : ooo0 = '[COLOR red]L[/COLOR]'
   if 78 - 78: oo0Ooo0 . OoO000
   if i1iI1i1I1 == "W" :
    i1iI1i1I1 = '[COLOR lime]W[/COLOR]'
   elif i1iI1i1I1 == "D" :
    i1iI1i1I1 = '[COLOR yellow]D[/COLOR]'
   else : i1iI1i1I1 = '[COLOR red]L[/COLOR]'
   if 38 - 38: OOO0O + OoO000
   if O0Oo0 == "W" :
    O0Oo0 = '[COLOR lime]W[/COLOR]'
   elif O0Oo0 == "D" :
    O0Oo0 = '[COLOR yellow]D[/COLOR]'
   else : O0Oo0 = '[COLOR red]L[/COLOR]'
   if 15 - 15: I11i1i11i1I + oo0Ooo0 . iiIIiIiIi - ooO0oo0oO0 / oooO0oo0oOOOO % ooO0oo0oO0
   if OOooO0OO0 == "W" :
    OOooO0OO0 = '[COLOR lime]W[/COLOR]'
   elif OOooO0OO0 == "D" :
    OOooO0OO0 = '[COLOR yellow]D[/COLOR]'
   else : OOooO0OO0 = '[COLOR red]L[/COLOR]'
   if 86 - 86: i1IIi11111i / OooooO0oOO * i1IIiiiii
   if iI1iIiiiI1I1 == "W" :
    iI1iIiiiI1I1 = '[COLOR lime]W[/COLOR]'
   elif iI1iIiiiI1I1 == "D" :
    iI1iIiiiI1I1 = '[COLOR yellow]D[/COLOR]'
   else : iI1iIiiiI1I1 = '[COLOR red]L[/COLOR]'
   if 64 - 64: iiIIiIiIi / oooO0oo0oOOOO * OOO0O * iiIIiIiIi
   if OOOO == "W" :
    OOOO = '[COLOR lime]W[/COLOR]'
   elif OOOO == "D" :
    OOOO = '[COLOR yellow]D[/COLOR]'
   else : OOOO = '[COLOR red]L[/COLOR]'
   if 60 - 60: oo0Ooo0 / II1Ii1iI1i % i11iiII / i11iiII * i11iiII . i11iIiiIii
   if OoI1IiiiIiI == "W" :
    OoI1IiiiIiI = '[COLOR lime]W[/COLOR]'
   elif OoI1IiiiIiI == "D" :
    OoI1IiiiIiI = '[COLOR yellow]D[/COLOR]'
   else : OoI1IiiiIiI = '[COLOR red]L[/COLOR]'
   if 99 - 99: OOO0O
   oO00OOoO00 = oO0Ooo0OooOOo ( oO00OOoO00 )
   IiI111111IIII = oO0Ooo0OooOOo ( IiI111111IIII )
   OO0oOoOO0oOO0 ( '[COLOR mediumpurple][B]' + oO00OOoO00 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[B]' + i1ii1IIiI + '  ' + II1ii1ii11I1 + '  ' + o0ooOO0o + '  ' + ooo0 + '  ' + i1iI1i1I1 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR mediumpurple][B]' + IiI111111IIII + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[B]' + O0Oo0 + '  ' + OOooO0OO0 + '  ' + iI1iIiiiI1I1 + '  ' + OOOO + '  ' + OoI1IiiiIiI + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 77 - 77: oo0ooO0oOOOOo
def IIiIi11iiIi ( name , url , iconimage ) :
 if 48 - 48: OoO000 % oo0Ooo0
 i1IIi1i1Ii1 = datetime . datetime . now ( )
 o00oo0oooooOOO000Oo = i1IIi1i1Ii1 . day
 if 3 - 3: OoO000 % i1IIiiiii + I11i1i11i1I
 ooOOOoOoOOO0 = o00oo0oooooOOO000Oo
 if 47 - 47: oooO0oo0oOOOO * i1IIi11111i * oo . i1111
 I1i1iIi1I1 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OOO0 = datetime . datetime . strftime ( I1i1iIi1I1 , '%A - %d %B %Y' )
 iIiIIi = 'http://www.predictz.com/predictions/'
 if 95 - 95: i1IIiiiii % OoO000 . oooO0oo0oOOOO % OooOoO0Oo
 I1iIiI1IiIIII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1iiIi111I = datetime . datetime . strftime ( I1iIiI1IiIIII , '%A - %d %B %Y' )
 Iiii1iIii = datetime . datetime . strftime ( I1iIiI1IiIIII , '%d' )
 oOoooO000O = 'http://www.predictz.com/predictions/tomorrow/'
 if 68 - 68: I11i1i11i1I . I11i1i11i1I - i11iiII / oo0Ooo0 . iiIIiIiIi / II1Ii1iI1i
 IIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooo0O0OOO000o = datetime . datetime . strftime ( IIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iiI1iii = datetime . datetime . strftime ( IIi11 , '%y%m%d' )
 OOoOOo00O0o0 = 'http://www.predictz.com/predictions/20' + str ( iiI1iii )
 if 12 - 12: i11iiII * II1Ii1iI1i * oo0Ooo0
 iIiIi1ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iiiiiII = datetime . datetime . strftime ( iIiIi1ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii1ii = datetime . datetime . strftime ( iIiIi1ii , '%y%m%d' )
 IIiI1i = 'http://www.predictz.com/predictions/20' + str ( ii1ii )
 if 23 - 23: oOo0 / oooO0oo0oOOOO / i1IIi11111i
 o00O00Oo00O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IIii1I1I1I = datetime . datetime . strftime ( o00O00Oo00O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoOOOo0 = datetime . datetime . strftime ( o00O00Oo00O , '%y%m%d' )
 o00 = 'http://www.predictz.com/predictions/20' + str ( OoOOOo0 )
 if 49 - 49: oo0Ooo0 . oo0ooO0oOOOOo % OooooO0oOO / i1IIiiiii
 if 95 - 95: oooO0oo0oOOOO * OOO0O * OoO000 . iiIIiIiIi / ooO0oo0oO0
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOO0 ) + '[/B][/COLOR]' , iIiIIi , 71 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1iiIi111I ) + '[/B][/COLOR]' , oOoooO000O , 71 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( ooo0O0OOO000o ) , OOoOOo00O0o0 , 71 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( iiiiiII ) , IIiI1i , 71 , iiiii , O0O0OO0O0O0 , '' )
 OOoOO0oo0ooO ( str ( IIii1I1I1I ) , o00 , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 28 - 28: OoO000 + OooooO0oOO - iiIIiIiIi / ooO0oo0oO0 - i1IIi11111i
def Ii1i1 ( name , url , iconimage ) :
 if 65 - 65: OooooO0oOO + i11iiII / oOo0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 o0O0Oo = str ( oO0 )
 IIii11I1i1I = re . compile ( '<tr(.+?)</tr>' ) . findall ( o0O0Oo )
 for Ii1iIiII1ii1 in IIii11I1i1I :
  try :
   oo0OOo0O = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR red][B]' + oo0OOo0O + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   II1iI1I11I = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO00OOoO00 , IiI111111IIII = II1iI1I11I . split ( ' v ' )
   if 85 - 85: ooO0oo0oO0 / i111I % i1111
   OoIIi1iI = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   II1iiI = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   III1Ii1i1I1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   O0O00OooO = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   i1ii1IIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   II1ii1ii11I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   o0ooOO0o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   ooo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 3 ]
   i1iI1i1I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 4 ]
   O0Oo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 5 ]
   OOooO0OO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 6 ]
   iI1iIiiiI1I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 7 ]
   OOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 8 ]
   OoI1IiiiIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 9 ]
   if 49 - 49: i11iIiiIii % OOO0O + OooOoO0Oo . i1111 % i1iIIIiI1I * oOo0
   if i1ii1IIiI == "W" :
    i1ii1IIiI = '[COLOR lime]W[/COLOR]'
   elif i1ii1IIiI == "D" :
    i1ii1IIiI = '[COLOR yellow]D[/COLOR]'
   else : i1ii1IIiI = '[COLOR red]L[/COLOR]'
   if 67 - 67: II1Ii1iI1i
   if II1ii1ii11I1 == "W" :
    II1ii1ii11I1 = '[COLOR lime]W[/COLOR]'
   elif II1ii1ii11I1 == "D" :
    II1ii1ii11I1 = '[COLOR yellow]D[/COLOR]'
   else : II1ii1ii11I1 = '[COLOR red]L[/COLOR]'
   if 5 - 5: i1111 . i111I
   if o0ooOO0o == "W" :
    o0ooOO0o = '[COLOR lime]W[/COLOR]'
   elif o0ooOO0o == "D" :
    o0ooOO0o = '[COLOR yellow]D[/COLOR]'
   else : o0ooOO0o = '[COLOR red]L[/COLOR]'
   if 57 - 57: i1IIi11111i
   if ooo0 == "W" :
    ooo0 = '[COLOR lime]W[/COLOR]'
   elif ooo0 == "D" :
    ooo0 = '[COLOR yellow]D[/COLOR]'
   else : ooo0 = '[COLOR red]L[/COLOR]'
   if 35 - 35: i111I - OooOoO0Oo / oo
   if i1iI1i1I1 == "W" :
    i1iI1i1I1 = '[COLOR lime]W[/COLOR]'
   elif i1iI1i1I1 == "D" :
    i1iI1i1I1 = '[COLOR yellow]D[/COLOR]'
   else : i1iI1i1I1 = '[COLOR red]L[/COLOR]'
   if 50 - 50: OOO0O
   if O0Oo0 == "W" :
    O0Oo0 = '[COLOR lime]W[/COLOR]'
   elif O0Oo0 == "D" :
    O0Oo0 = '[COLOR yellow]D[/COLOR]'
   else : O0Oo0 = '[COLOR red]L[/COLOR]'
   if 33 - 33: oo0Ooo0
   if OOooO0OO0 == "W" :
    OOooO0OO0 = '[COLOR lime]W[/COLOR]'
   elif OOooO0OO0 == "D" :
    OOooO0OO0 = '[COLOR yellow]D[/COLOR]'
   else : OOooO0OO0 = '[COLOR red]L[/COLOR]'
   if 98 - 98: OOO0O % i1111
   if iI1iIiiiI1I1 == "W" :
    iI1iIiiiI1I1 = '[COLOR lime]W[/COLOR]'
   elif iI1iIiiiI1I1 == "D" :
    iI1iIiiiI1I1 = '[COLOR yellow]D[/COLOR]'
   else : iI1iIiiiI1I1 = '[COLOR red]L[/COLOR]'
   if 95 - 95: ooO0oo0oO0 - OooOoO0Oo - oOo0 + OooOoO0Oo % i11iiII . i1IIi11111i
   if OOOO == "W" :
    OOOO = '[COLOR lime]W[/COLOR]'
   elif OOOO == "D" :
    OOOO = '[COLOR yellow]D[/COLOR]'
   else : OOOO = '[COLOR red]L[/COLOR]'
   if 41 - 41: oooO0oo0oOOOO + OooooO0oOO . II1Ii1iI1i - i1111 * oo0ooO0oOOOOo . oo
   if OoI1IiiiIiI == "W" :
    OoI1IiiiIiI = '[COLOR lime]W[/COLOR]'
   elif OoI1IiiiIiI == "D" :
    OoI1IiiiIiI = '[COLOR yellow]D[/COLOR]'
   else : OoI1IiiiIiI = '[COLOR red]L[/COLOR]'
   if 68 - 68: oo0ooO0oOOOOo
   oO00OOoO00 = oO0Ooo0OooOOo ( oO00OOoO00 )
   IiI111111IIII = oO0Ooo0OooOOo ( IiI111111IIII )
   II1iI1I11I = oO0Ooo0OooOOo ( II1iI1I11I )
   OoIIi1iI = oO0Ooo0OooOOo ( OoIIi1iI )
   OO0oOoOO0oOO0 ( '[COLOR blue][B]' + II1iI1I11I + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + OoIIi1iI + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR orange]' + oO00OOoO00 + ' Form: - [/COLOR][B]' + i1ii1IIiI + '  ' + II1ii1ii11I1 + '  ' + o0ooOO0o + '  ' + ooo0 + '  ' + i1iI1i1I1 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR orange]' + IiI111111IIII + ' Form - [/COLOR][B]' + O0Oo0 + '  ' + OOooO0OO0 + '  ' + iI1iIiiiI1I1 + '  ' + OOOO + '  ' + OoI1IiiiIiI + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR orange]' + oO00OOoO00 + ' Win[/COLOR][COLOR dodgerblue][B] (' + II1iiI + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + III1Ii1i1I1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '[COLOR orange]' + IiI111111IIII + ' Win[/COLOR][COLOR dodgerblue][B] (' + O0O00OooO + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   OO0oOoOO0oOO0 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 20 - 20: OooOoO0Oo - OooOoO0Oo
  except : pass
  if 37 - 37: OoO000
def iI11i ( name , url , iconimage ) :
 if 73 - 73: i1iIIIiI1I * i1iIIIiI1I / iiIIiIiIi
 IIii1i11iI1II11 = [ ]
 iIi11i = [ ]
 ooIII1II1iii1i = [ ]
 O0OO0oOO = [ ]
 ooooO = [ ]
 if 92 - 92: oo0ooO0oOOOOo / oo0ooO0oOOOOo * i1IIiiiii
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.livescores.com' )
 oO0 = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( o00OO00OoO )
 o0O0Oo = str ( oO0 )
 IIii11I1i1I = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( o0O0Oo )
 for Ii1iIiII1ii1 in IIii11I1i1I :
  iI111i11iI1 = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  III1ii = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   OoIIi1iI = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except :
   OoIIi1iI = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 23 - 23: OooooO0oOO * i1iIIIiI1I
  if "minute" in time . lower ( ) :
   ooooO . append ( '3' )
  elif "ht" in time . lower ( ) :
   ooooO . append ( '3' )
  elif "ft" in time . lower ( ) :
   ooooO . append ( '2' )
  else : ooooO . append ( '1' )
  if 53 - 53: i1IIiiiii - OOO0O . i1iIIIiI1I . OooOoO0Oo
  IIii1i11iI1II11 . append ( iI111i11iI1 )
  iIi11i . append ( III1ii )
  ooIII1II1iii1i . append ( OoIIi1iI )
  O0OO0oOO . append ( time )
  o000ooooO0o = list ( zip ( ooooO , IIii1i11iI1II11 , iIi11i , ooIII1II1iii1i , O0OO0oOO ) )
  if 48 - 48: i1iIIIiI1I + OoO000
 OO0oOoOO0oOO0 ( '[COLOR dodgerblue][B]The scores will update every 10 seconds.[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 OO0oOoOO0oOO0 ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 60 - 60: oo0Ooo0 + i1iIIIiI1I . OoO000 / II1Ii1iI1i . ooO0oo0oO0
 O0oOOoooOO0O = sorted ( o000ooooO0o , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 i1i11ii1Ii = 0
 i1Oo0oOo000OoO0 = 0
 IIii1I1i = 0
 for IIII1iIIii , Iii , OooooOo0 , I1ii1 , I1Ii in O0oOOoooOO0O :
  if IIII1iIIii == "3" :
   if i1i11ii1Ii == 0 :
    OO0oOoOO0oOO0 ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    i1i11ii1Ii = 1
  elif IIII1iIIii == "2" :
   if i1Oo0oOo000OoO0 == 0 :
    OO0oOoOO0oOO0 ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    i1Oo0oOo000OoO0 = 1
  elif IIII1iIIii == "1" :
   if IIii1I1i == 0 :
    OO0oOoOO0oOO0 ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    IIii1I1i = 1
  I1Ii = I1Ii . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  I1ii1 = I1ii1 . replace ( " " , "" )
  OO0oOoOO0oOO0 ( '[COLOR red][B]' + I1Ii + "[/B][/COLOR]- [COLOR blue]" + I1ii1 + "[/COLOR] | [COLOR white]" + Iii + "vs" + OooooOo0 + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 44 - 44: ooO0oo0oO0 . i11iiII + OooOoO0Oo . iiIIiIiIi
def II1i11 ( ) :
 if 28 - 28: i1111 - OooooO0oOO % OOO0O + oo - OOO0O
 o0O0Oo = ''
 I1IIIiI11i1 = xbmc . Keyboard ( o0O0Oo , 'Enter Search Term' )
 I1IIIiI11i1 . doModal ( )
 if I1IIIiI11i1 . isConfirmed ( ) :
  o0O0Oo = I1IIIiI11i1 . getText ( )
  if len ( o0O0Oo ) > 1 :
   Oo0oOOo = o0O0Oo + "!" + iiiii
   OOooo00 ( "all " + o0O0Oo , Oo0oOOo , iiiii )
  else : quit ( )
  if 28 - 28: i1111 . OooooO0oOO + oooO0oo0oOOOO . oooO0oo0oOOOO . oOo0
def ooOoo000oO ( name , url , iconimage ) :
 if 50 - 50: OoO000 + oo0ooO0oOOOOo
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 96 - 96: oo
def IiiI11i1I ( text ) :
 if 92 - 92: I11i1i11i1I / i11iIiiIii + i11iiII
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 87 - 87: OOO0O % ooO0oo0oO0
 return text
 if 72 - 72: oOo0 . oOo0 - i11iiII
def oO0Ooo0OooOOo ( text ) :
 if 48 - 48: I11i1i11i1I - iiIIiIiIi + I11i1i11i1I - i1IIi11111i * i11iIiiIii . i1iIIIiI1I
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 35 - 35: OoO000 . oooO0oo0oOOOO + I11i1i11i1I + oOo0 + II1Ii1iI1i
 return text
 if 65 - 65: oooO0oo0oOOOO * i1IIi11111i / i1IIi11111i . OOO0O
def i1II ( text ) :
 if 87 - 87: i1111 * i11iiII % I11i1i11i1I * I11i1i11i1I
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 58 - 58: oOo0 . oo0ooO0oOOOOo + i1IIi11111i % I11i1i11i1I - oo
 return text
 if 50 - 50: i1iIIIiI1I % i1111 - iiIIiIiIi . II1Ii1iI1i + oooO0oo0oOOOO % i1iIIIiI1I
def oooO ( name , url , iconimage ) :
 if 10 - 10: i1iIIIiI1I . II1Ii1iI1i + i1IIiiiii
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]Opening link...[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 66 - 66: oo % oo0ooO0oOOOOo
 if "pl_type=user" in url :
  OOooo0O0o0 = OOOO0OOoO0O0 ( url )
  url = re . compile ( '<meta property="og:video:iframe" content="(.+?)">' ) . findall ( OOooo0O0o0 ) [ 0 ]
  if 21 - 21: OOO0O - i111I % i11iIiiIii
 if not "plugin" in url :
  try :
   if not 'http' in url : url = 'http://' + url
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 71 - 71: II1Ii1iI1i - oo0Ooo0 * OooOoO0Oo + OooooO0oOO - oo % i11iiII
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 63 - 63: ooO0oo0oO0 + oOo0 . oo / i1IIi11111i
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  oO0O = urlresolver . HostedMediaFile ( url ) . resolve ( )
  Iiii1I = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  Iiii1I . setPath ( oO0O )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( oO0O , Iiii1I , False )
  quit ( )
 else :
  oO0O = url
  Iiii1I = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  Iiii1I . setPath ( oO0O )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( oO0O , Iiii1I , False )
  quit ( )
  if 56 - 56: i11iIiiIii - ooO0oo0oO0 . i1111
def Ii1i1iI1iIIi ( ) :
 if 81 - 81: OoO000 / OOO0O * OoO000 . oooO0oo0oOOOO
 OOOOo00oo00O = xbmc . getInfoLabel ( "System.BuildVersion" )
 Oo0oo0oOO0oOo = float ( OOOOo00oo00O [ : 4 ] )
 if Oo0oo0oOO0oOo >= 11.0 and Oo0oo0oOO0oOo <= 11.9 :
  IiIII1i = 'Eden'
 elif Oo0oo0oOO0oOo >= 12.0 and Oo0oo0oOO0oOo <= 12.9 :
  IiIII1i = 'Frodo'
 elif Oo0oo0oOO0oOo >= 13.0 and Oo0oo0oOO0oOo <= 13.9 :
  IiIII1i = 'Gotham'
 elif Oo0oo0oOO0oOo >= 14.0 and Oo0oo0oOO0oOo <= 14.9 :
  IiIII1i = 'Helix'
 elif Oo0oo0oOO0oOo >= 15.0 and Oo0oo0oOO0oOo <= 15.9 :
  IiIII1i = 'Isengard'
 elif Oo0oo0oOO0oOo >= 16.0 and Oo0oo0oOO0oOo <= 16.9 :
  IiIII1i = 'Jarvis'
 elif Oo0oo0oOO0oOo >= 17.0 and Oo0oo0oOO0oOo <= 17.9 :
  IiIII1i = 'Krypton'
 else : IiIII1i = "Decline"
 if 43 - 43: OoO000 * I11i1i11i1I * i1iIIIiI1I % iiIIiIiIi . OooooO0oOO
 return IiIII1i
 if 85 - 85: oOo0 * II1Ii1iI1i % i1IIi11111i - iiIIiIiIi
def OOOO0OOoO0O0 ( url ) :
 if 37 - 37: OoO000 . I11i1i11i1I * I11i1i11i1I * i1111 * oooO0oo0oOOOO
 o00O = urllib2 . Request ( url )
 o00O . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 oO0O0Ooo = urllib2 . urlopen ( o00O )
 o00OO00OoO = oO0O0Ooo . read ( )
 oO0O0Ooo . close ( )
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return o00OO00OoO
 if 88 - 88: i11iIiiIii + i1iIIIiI1I * OOO0O * i1iIIIiI1I + oo0Ooo0
def IIIii1II1II ( url ) :
 if 88 - 88: oOo0 % I11i1i11i1I - i1iIIIiI1I - OOO0O % i11iIiiIii
 o00O = urllib2 . Request ( url )
 o00O . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 oO0O0Ooo = urllib2 . urlopen ( o00O )
 o00OO00OoO = oO0O0Ooo . read ( )
 oO0O0Ooo . close ( )
 return o00OO00OoO
 if 6 - 6: i1IIiiiii - oo . i1IIi11111i - oooO0oo0oOOOO
def o0OIIiI1I1 ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 16 - 16: i1iIIIiI1I * i1iIIIiI1I % i1IIiiiii % i1IIi11111i
 if 48 - 48: oOo0 / i1IIiiiii % oo / OoO000 / OooOoO0Oo
 if 89 - 89: OooOoO0Oo * OooooO0oOO
 if 63 - 63: i111I * i111I % oo + oooO0oo0oOOOO / OooOoO0Oo + ooO0oo0oO0
 if 72 - 72: OOO0O * ooO0oo0oO0 % oo0Ooo0
def IiIi1I1i1II ( ) :
 if 15 - 15: OooooO0oOO / OooOoO0Oo
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 37 - 37: i11iIiiIii + i1IIi11111i . oOo0 % oo0Ooo0 % oo0Ooo0
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for ii , I11I1iiIiII1I , o00ooOoo in os . walk ( IiIi11iIIi1Ii ) :
   i111i1I1ii1i = 0
   i111i1I1ii1i += len ( o00ooOoo )
   if i111i1I1ii1i > 0 :
    for OooO0 in o00ooOoo :
     try :
      if ( OooO0 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( ii , OooO0 ) )
     except :
      pass
    for O0Oooo in I11I1iiIiII1I :
     try :
      shutil . rmtree ( os . path . join ( ii , O0Oooo ) )
     except :
      pass
      if 27 - 27: iiIIiIiIi + i11iIiiIii * oo0Ooo0 + OOO0O + i1iIIIiI1I
   else :
    pass
    if 87 - 87: oooO0oo0oOOOO
 if os . path . exists ( Oo0O ) == True :
  for ii , I11I1iiIiII1I , o00ooOoo in os . walk ( Oo0O ) :
   i111i1I1ii1i = 0
   i111i1I1ii1i += len ( o00ooOoo )
   if i111i1I1ii1i > 0 :
    for OooO0 in o00ooOoo :
     try :
      if ( OooO0 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( ii , OooO0 ) )
     except :
      pass
    for O0Oooo in I11I1iiIiII1I :
     try :
      shutil . rmtree ( os . path . join ( ii , O0Oooo ) )
     except :
      pass
      if 87 - 87: oo0ooO0oOOOOo / i1111
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  O0OOOo000 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 3 - 3: I11i1i11i1I % iiIIiIiIi - i111I * i1iIIIiI1I . oOo0
  for ii , I11I1iiIiII1I , o00ooOoo in os . walk ( O0OOOo000 ) :
   i111i1I1ii1i = 0
   i111i1I1ii1i += len ( o00ooOoo )
   if 46 - 46: i11iIiiIii - oOo0 * i1IIi11111i * oo0Ooo0 % i11iiII * II1Ii1iI1i
   if i111i1I1ii1i > 0 :
    for OooO0 in o00ooOoo :
     os . unlink ( os . path . join ( ii , OooO0 ) )
    for O0Oooo in I11I1iiIiII1I :
     shutil . rmtree ( os . path . join ( ii , O0Oooo ) )
     if 5 - 5: oooO0oo0oOOOO / iiIIiIiIi . I11i1i11i1I + i111I
   else :
    pass
  O0ooOoOO0o0oO0 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 52 - 52: OOO0O * oo - i1IIiiiii
  for ii , I11I1iiIiII1I , o00ooOoo in os . walk ( O0ooOoOO0o0oO0 ) :
   i111i1I1ii1i = 0
   i111i1I1ii1i += len ( o00ooOoo )
   if 82 - 82: oo + i1IIi11111i . II1Ii1iI1i + oOo0
   if i111i1I1ii1i > 0 :
    for OooO0 in o00ooOoo :
     os . unlink ( os . path . join ( ii , OooO0 ) )
    for O0Oooo in I11I1iiIiII1I :
     shutil . rmtree ( os . path . join ( ii , O0Oooo ) )
     if 16 - 16: oo0ooO0oOOOOo - oo / OooOoO0Oo
   else :
    pass
    if 48 - 48: ooO0oo0oO0
 O0ooOooooO = iI ( )
 if 91 - 91: i1111 - oooO0oo0oOOOO . ooO0oo0oO0 . oooO0oo0oOOOO + i11iiII - i1111
 for iiIiiIi1 in O0ooOooooO :
  I1Ii11i = xbmc . translatePath ( iiIiiIi1 . path )
  if os . path . exists ( I1Ii11i ) == True :
   for ii , I11I1iiIiII1I , o00ooOoo in os . walk ( I1Ii11i ) :
    i111i1I1ii1i = 0
    i111i1I1ii1i += len ( o00ooOoo )
    if i111i1I1ii1i > 0 :
     for OooO0 in o00ooOoo :
      os . unlink ( os . path . join ( ii , OooO0 ) )
     for O0Oooo in I11I1iiIiII1I :
      shutil . rmtree ( os . path . join ( ii , O0Oooo ) )
      if 19 - 19: OoO000 - oo0ooO0oOOOOo . ooO0oo0oO0 . OOO0O / oOo0
    else :
     pass
     if 87 - 87: OOO0O - iiIIiIiIi - oOo0 + I11i1i11i1I % ooO0oo0oO0 / i11iIiiIii
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 12 - 12: iiIIiIiIi
def oOOO0ooOO ( ) :
 i11IiI1iiI11 = [ ]
 OOoOOOO00 = sys . argv [ 2 ]
 if len ( OOoOOOO00 ) >= 2 :
  OOOO0oooo = sys . argv [ 2 ]
  IIii1III = OOOO0oooo . replace ( '?' , '' )
  if ( OOOO0oooo [ len ( OOOO0oooo ) - 1 ] == '/' ) :
   OOOO0oooo = OOOO0oooo [ 0 : len ( OOOO0oooo ) - 2 ]
  ooooOoo0OO = IIii1III . split ( '&' )
  i11IiI1iiI11 = { }
  for I111I1Iiii1i in range ( len ( ooooOoo0OO ) ) :
   Oo0 = { }
   Oo0 = ooooOoo0OO [ I111I1Iiii1i ] . split ( '=' )
   if ( len ( Oo0 ) ) == 2 :
    i11IiI1iiI11 [ Oo0 [ 0 ] ] = Oo0 [ 1 ]
 return i11IiI1iiI11
 if 96 - 96: oo0Ooo0 % i1IIiiiii % OooooO0oOO * oo0Ooo0 / oOo0
def OOoOO0oo0ooO ( name , url , mode , iconimage , fanart , description = '' ) :
 if 13 - 13: ooO0oo0oO0 - oo
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 ooo0i1iiIIiiiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 Ii1I1 = True
 Iiii1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 Iiii1I . setProperty ( "fanart_Image" , fanart )
 Iiii1I . setProperty ( "icon_Image" , iconimage )
 Ii1I1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo0i1iiIIiiiII , listitem = Iiii1I , isFolder = True )
 return Ii1I1
 if 71 - 71: OOO0O + ooO0oo0oO0 * OooooO0oOO . OooOoO0Oo % i11iIiiIii % ooO0oo0oO0
def OO0oOoOO0oOO0 ( name , url , mode , iconimage , fanart , description = '' ) :
 if 63 - 63: i111I * oo / oo0Ooo0 - OooooO0oOO . ooO0oo0oO0 + i1iIIIiI1I
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 ooo0i1iiIIiiiII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 Ii1I1 = True
 Iiii1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 Iiii1I . setProperty ( "fanart_Image" , fanart )
 Iiii1I . setProperty ( "icon_Image" , iconimage )
 Ii1I1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooo0i1iiIIiiiII , listitem = Iiii1I , isFolder = False )
 return Ii1I1
 if 44 - 44: II1Ii1iI1i % i1IIi11111i % oo0ooO0oOOOOo
OOOO0oooo = oOOO0ooOO ( ) ; Oo0oOOo = None ; i1OOO = None ; iIIi1Ii1III = None ; Oooo00 = None ; Oo0OoO00oOO0o = None ; OOO00O = None
try : Oooo00 = urllib . unquote_plus ( OOOO0oooo [ "site" ] )
except : pass
try : Oo0oOOo = urllib . unquote_plus ( OOOO0oooo [ "url" ] )
except : pass
try : i1OOO = urllib . unquote_plus ( OOOO0oooo [ "name" ] )
except : pass
try : iIIi1Ii1III = int ( OOOO0oooo [ "mode" ] )
except : pass
try : Oo0OoO00oOO0o = urllib . unquote_plus ( OOOO0oooo [ "iconimage" ] )
except : pass
try : OOO00O = urllib . unquote_plus ( OOOO0oooo [ "fanart" ] )
except : pass
if 9 - 9: i111I * oooO0oo0oOOOO
if iIIi1Ii1III == None or Oo0oOOo == None or len ( Oo0oOOo ) < 1 : i11 ( )
elif iIIi1Ii1III == 1 : O0O ( i1OOO , Oo0oOOo )
elif iIIi1Ii1III == 2 : oooO ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 3 : ooooo0O0000oo ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 4 : PLAYSD ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 7 : o00Oo0oooooo ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 8 : I11iiii ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 9 : AUTO_UPDATER ( i1OOO )
elif iIIi1Ii1III == 10 : OooOoOOo0oO00 ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 11 : O0 ( )
elif iIIi1Ii1III == 12 : Ii1i1i1111 ( Oo0oOOo )
elif iIIi1Ii1III == 19 : o0oo ( Oo0oOOo )
elif iIIi1Ii1III == 20 : OOooo00 ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 21 : o0OO0O0Oo ( Oo0oOOo )
elif iIIi1Ii1III == 22 : iIIiiIIi1IiI ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 23 : O0OO0O ( )
elif iIIi1Ii1III == 24 : IIIIi1 ( )
elif iIIi1Ii1III == 25 : Oo0ooo ( )
elif iIIi1Ii1III == 26 : OO0o0OO0 ( )
elif iIIi1Ii1III == 30 : I1iii11 ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 40 : OoOOoO0oOo ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 41 : oOO0o0oo0 ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 50 : OoO00o0 ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 51 : II1I11Iii1 ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 60 : ooO ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 61 : o0O0OO0o ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 70 : IIiIi11iiIi ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 71 : Ii1i1 ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 80 : iI11i ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 90 : iiii1IIi ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 91 : oO ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 95 : o0ooO ( )
elif iIIi1Ii1III == 96 : IiI11i1IIiiI ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 97 : O000Oo0o ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 100 : II1i11 ( )
elif iIIi1Ii1III == 500 : IiIi1I1i1II ( )
elif iIIi1Ii1III == 201 : O00oOo00o0o ( )
elif iIIi1Ii1III == 202 : ii1 ( Oo0oOOo )
elif iIIi1Ii1III == 203 : I1IIIiii1 ( Oo0oOOo )
elif iIIi1Ii1III == 204 : o000O000 ( Oo0oOOo )
elif iIIi1Ii1III == 205 : II1IiiIii ( Oo0oOOo )
elif iIIi1Ii1III == 206 : o0OooO0ooo0o ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 210 : oOOo ( Oo0oOOo )
elif iIIi1Ii1III == 220 : ooIII1i1iI1 ( Oo0oOOo )
elif iIIi1Ii1III == 221 : O0000 ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 222 : o0oO000oo ( Oo0oOOo )
elif iIIi1Ii1III == 300 : IiiiiiIiI ( Oo0oOOo )
elif iIIi1Ii1III == 301 : iIi1i1iIi1iI ( Oo0oOOo )
elif iIIi1Ii1III == 302 : Ii1 ( Oo0oOOo )
elif iIIi1Ii1III == 303 : i1OO0oOOoo ( Oo0oOOo )
elif iIIi1Ii1III == 304 : O00 ( Oo0oOOo )
elif iIIi1Ii1III == 305 : iIiiI1iI ( )
elif iIIi1Ii1III == 306 : i111iI ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 800 : ooOoo000oO ( i1OOO , Oo0oOOo , Oo0OoO00oOO0o )
elif iIIi1Ii1III == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 76 - 76: OooOoO0Oo - OooooO0oOO . oOo0 % oo0ooO0oOOOOo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if iIIi1Ii1III == 80 :
 xbmc . sleep ( 10000 )
 xbmc . executebuiltin ( 'Container.Refresh' )