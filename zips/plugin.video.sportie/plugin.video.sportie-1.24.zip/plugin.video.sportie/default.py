import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
if 41 - 41: I1II1
Ooo0OO0oOO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
oooO0oo0oOOOO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
if 53 - 53: o0oo0o / OoI1Ii11I1Ii1i + ooO - OOoO / ooo0Oo0 * oo
O0Oooo00 = plugintools . get_setting ( "scrape1" )
Ooo0 = plugintools . get_setting ( "scrape2" )
oo00000o0 = plugintools . get_setting ( "scrape3" )
if 34 - 34: O0o00 % o0ooo / OOO0O / I1ii * oOOOo0o0O + OOoOoo00oo
iiI11 = o0O + '|SPLIT|' + Oo
checker . check ( iiI11 )
if 91 - 91: oOOOO / i1iiIII111ii + iiIIi1IiIi11 . i1Ii
if not os . path . isfile ( ooo0OO ) :
 plugintools . open_settings_dialog ( )
 if 25 - 25: OO00O0O0O00Oo + OOoooooO / ooO . oOOOO % O0o00 . OOO0O
if not os . path . exists ( IiiIII111iI ) :
 os . makedirs ( IiiIII111iI )
 if 42 - 42: OO00O0O0O00Oo + I1ii
if not os . path . isfile ( iI1Ii11111iIi ) :
 OOoO000O0OO = open ( iI1Ii11111iIi , 'w' )
 if 23 - 23: i11iIiiIii + ooo0Oo0
if not os . path . isfile ( IiII ) :
 OOoO000O0OO = open ( IiII , 'w' )
 if 68 - 68: o0ooo . oOOOo0o0O . i11iIiiIii
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 40 - 40: oOOOo0o0O . o0ooo . oo . ooO
class I11iii ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 54 - 54: OOoOoo00oo + OOoOoo00oo % OO00O0O0O00Oo % i11iIiiIii / o0oo0o . OOoOoo00oo
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 57 - 57: i1iiIII111ii % OoI1Ii11I1Ii1i
O00 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 11 - 11: ooo0Oo0
class O0o0Oo :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 78 - 78: o0oo0o - i1iiIII111ii * O0o00 + OOO0O + iiIIi1IiIi11 + iiIIi1IiIi11
  if 11 - 11: iiIIi1IiIi11 - O0o00 % OOoooooO % iiIIi1IiIi11 / o0ooo - O0o00
  if 74 - 74: iiIIi1IiIi11 * I1II1
  if 89 - 89: oOOOo0o0O + oo
def Ii1I ( ) :
 Oo0o0 = 5
 III1ii1iII = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 oo0oooooO0 = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 19 - 19: oOOOO + OOoooooO
 ooo = [ ]
 if 18 - 18: OOO0O
 for I1i1I1II in range ( Oo0o0 ) :
  ooo . append ( O0o0Oo ( III1ii1iII [ I1i1I1II ] , oo0oooooO0 [ I1i1I1II ] ) )
  if 45 - 45: OO00O0O0O00Oo . o0ooo
 return ooo
 if 83 - 83: oOOOo0o0O . o0oo0o . I1ii
def I1I ( ) :
 if 80 - 80: o0ooo - O0o00
 OOO00 = iiiiiIIii ( oooO0oo0oOOOO )
 if len ( OOO00 ) > 1 :
  O000OO0 = iI1Ii11111iIi
  I11iii1Ii = open ( O000OO0 )
  I1IIiiIiii = I11iii1Ii . read ( )
  if I1IIiiIiii == OOO00 : pass
  else :
   O000oo0O = open ( O000OO0 , "w" )
   O000oo0O . write ( OOO00 )
   O000oo0O . close ( )
   if 66 - 66: I1ii / o0ooo - ooo0Oo0 . OOoOoo00oo / ooo0Oo0 * OOoOoo00oo
 OOO00 = iiiiiIIii ( Ooo0OO0oOO )
 if len ( OOO00 ) > 1 :
  O000OO0 = IiII
  I11iii1Ii = open ( O000OO0 )
  I1IIiiIiii = I11iii1Ii . read ( )
  if I1IIiiIiii == OOO00 : pass
  else :
   O000oo0O = open ( O000OO0 , "w" )
   O000oo0O . write ( OOO00 )
   O000oo0O . close ( )
   if 29 - 29: I1ii % ooo0Oo0 + OOoooooO / OOO0O + OOoOoo00oo * OOO0O
 i1I1iI = oo0OooOOo0 ( II1 )
 i1I1iI = base64 . b64decode ( i1I1iI )
 i1I1iI = i1I1iI . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 o0OO00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( i1I1iI )
 for I11i1I1I in o0OO00oO :
  if 83 - 83: I1ii / OOoooooO
  if '<search>ZGlzcGxheQ==</search>' in I11i1I1I :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   iIIIIii1 = base64 . b64decode ( iIIIIii1 )
   oo000OO00Oo ( iIIIIii1 , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 51 - 51: i1Ii * OOO0O + oOOOO + O0o00
  elif '<vip>' in I11i1I1I :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   iIIIIii1 = base64 . b64decode ( iIIIIii1 )
   oo000OO00Oo ( iIIIIii1 , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 66 - 66: o0ooo
  elif '<divider>bnVsbA==</divider>' in I11i1I1I :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   oO000Oo000 ( iIIIIii1 , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 4 - 4: oOOOo0o0O
   if 93 - 93: O0o00 % oOOOo0o0O . O0o00 * OO00O0O0O00Oo % i1iiIII111ii . OOoO
   if 38 - 38: OOO0O
   if 57 - 57: I1II1 / oOOOo0o0O * OO00O0O0O00Oo / o0ooo . OOoO
   if 26 - 26: iiIIi1IiIi11
   if 91 - 91: O0o00 . I1ii + O0o00 - iiIIi1IiIi11 / OoI1Ii11I1Ii1i
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in I11i1I1I :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   iIIIIii1 = base64 . b64decode ( iIIIIii1 )
   oo000OO00Oo ( iIIIIii1 , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 39 - 39: I1ii / OOoooooO - OOoO
   if 98 - 98: I1ii / oOOOO % oOOOo0o0O . o0ooo
   if 91 - 91: oOOOo0o0O % oo
   if 64 - 64: oOOOO % iiIIi1IiIi11 - OO00O0O0O00Oo - oOOOo0o0O
   if 31 - 31: oOOOO - OOoO . oOOOO
   if 18 - 18: OOO0O
   if 98 - 98: iiIIi1IiIi11 * iiIIi1IiIi11 / iiIIi1IiIi11 + oOOOO
   if 34 - 34: OOoooooO
   if 15 - 15: oOOOO * OOoooooO * oo % i11iIiiIii % o0ooo - OOoOoo00oo
   if 68 - 68: OO00O0O0O00Oo % ooO . i1Ii . I1ii
   if 92 - 92: iiIIi1IiIi11 . OO00O0O0O00Oo
   if 31 - 31: OO00O0O0O00Oo . o0ooo / I1II1
   if 89 - 89: o0ooo
   if 68 - 68: O0o00 * OoI1Ii11I1Ii1i % I1II1 + O0o00 + OOoooooO
   if 4 - 4: OOoooooO + I1II1 * OOoOoo00oo
   if 55 - 55: oo + o0oo0o / o0ooo * oOOOo0o0O - i11iIiiIii - i1iiIII111ii
   if 25 - 25: I1ii
   if 7 - 7: ooO / ooo0Oo0 * OO00O0O0O00Oo . i1Ii . o0oo0o
   if 13 - 13: OOoOoo00oo / i11iIiiIii
   if 2 - 2: ooo0Oo0 / I1II1 / OOO0O % o0ooo % i1iiIII111ii
   if 52 - 52: OOO0O
   if 95 - 95: i1iiIII111ii
  elif '<sportsdevil>' in I11i1I1I :
   O0oOO0O = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( I11i1I1I )
   if len ( O0oOO0O ) == 1 :
    iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
    oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
    iIi1IIIi1 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( I11i1I1I ) [ 0 ]
    O0oOoOOOoOO = re . compile ( '<referer>(.+?)</referer>' ) . findall ( I11i1I1I ) [ 0 ]
    iIIIIii1 = base64 . b64decode ( iIIIIii1 )
    oO = base64 . b64decode ( oO )
    iIi1IIIi1 = base64 . b64decode ( iIi1IIIi1 )
    O0oOoOOOoOO = base64 . b64decode ( O0oOoOOOoOO )
    ii1ii11IIIiiI = O0oOoOOOoOO
    O00OOOoOoo0O = "/"
    if not ii1ii11IIIiiI . endswith ( O00OOOoOoo0O ) :
     O000OOo00oo = ii1ii11IIIiiI + "/"
    else :
     O000OOo00oo = ii1ii11IIIiiI
    i1I1iI = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( iIIIIii1 ) + '%26url=' + iIi1IIIi1
    iIi1IIIi1 = i1I1iI + '%26referer=' + O000OOo00oo
    oO000Oo000 ( iIIIIii1 , iIi1IIIi1 , 4 , oO , oo0OOo )
   elif len ( O0oOO0O ) > 1 :
    iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
    oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
    iIIIIii1 = base64 . b64decode ( iIIIIii1 )
    oO = base64 . b64decode ( oO )
    oO000Oo000 ( iIIIIii1 , url2 + 'NOTPLAY' , 8 , oO , oo0OOo )
    if 64 - 64: oOOOO
  elif '<folder>' in I11i1I1I :
   iI11Ii = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( I11i1I1I )
   for iIIIIii1 , iIi1IIIi1 , oO , oo0OOo in iI11Ii :
    iIIIIii1 = base64 . b64decode ( iIIIIii1 )
    iIi1IIIi1 = base64 . b64decode ( iIi1IIIi1 )
    oO = base64 . b64decode ( oO )
    oo0OOo = base64 . b64decode ( oo0OOo )
    oo000OO00Oo ( iIIIIii1 , iIi1IIIi1 , 1 , oO , oo0OOo )
  elif '<m3u>' in I11i1I1I :
   iI11Ii = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( I11i1I1I )
   for iIIIIii1 , iIi1IIIi1 , oO , oo0OOo in iI11Ii :
    iIIIIii1 = base64 . b64decode ( iIIIIii1 )
    iIi1IIIi1 = base64 . b64decode ( iIi1IIIi1 )
    oO = base64 . b64decode ( oO )
    oo0OOo = base64 . b64decode ( oo0OOo )
    oo000OO00Oo ( iIIIIii1 , iIi1IIIi1 , 10 , oO , oo0OOo )
  else :
   O0oOO0O = re . compile ( '<link>(.+?)</link>' ) . findall ( I11i1I1I )
   if len ( O0oOO0O ) == 1 :
    iI11Ii = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( I11i1I1I )
    i1iIIIi1i = len ( o0OO00oO )
    for iIIIIii1 , iIi1IIIi1 , oO , oo0OOo in iI11Ii :
     iIIIIii1 = base64 . b64decode ( iIIIIii1 )
     iIi1IIIi1 = base64 . b64decode ( iIi1IIIi1 )
     oO = base64 . b64decode ( oO )
     oo0OOo = base64 . b64decode ( oo0OOo )
     oO000Oo000 ( iIIIIii1 , iIi1IIIi1 , 2 , oO , oo0OOo )
   elif len ( O0oOO0O ) > 1 :
    iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
    oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
    oo0OOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( I11i1I1I ) [ 0 ]
    iIIIIii1 = base64 . b64decode ( iIIIIii1 )
    oO = base64 . b64decode ( oO )
    oo0OOo = base64 . b64decode ( oo0OOo )
    oO000Oo000 ( iIIIIii1 , II1 , 3 , oO , oo0OOo )
    if 43 - 43: o0ooo % OOoOoo00oo
 iiiiiiii1 = open ( IIi1IiiiI1Ii ) . read ( )
 iI11i1ii11 = iiiiiiii1 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 o0OO00oO = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iI11i1ii11 ) )
 for I11i1I1I in o0OO00oO :
  OOooo0O00o = float ( I11i1I1I )
 iiiiiiii1 = open ( I11i11Ii ) . read ( )
 iI11i1ii11 = iiiiiiii1 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 o0OO00oO = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iI11i1ii11 ) )
 for I11i1I1I in o0OO00oO :
  oOOoOooOo = float ( I11i1I1I )
  if 51 - 51: oOOOO + iiIIi1IiIi11 % o0oo0o / oOOOo0o0O / OOoOoo00oo % OoI1Ii11I1Ii1i
 oO000Oo000 ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 oo000OO00Oo ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 oo000OO00Oo ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 oo000OO00Oo ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 oo000OO00Oo ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 oo000OO00Oo ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 oO000Oo000 ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 oO000Oo000 ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 oO000Oo000 ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 oO000Oo000 ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( OOooo0O00o ) + "[/COLOR]" , 'url' , 999 , iiiii , oo0OOo , '' )
 oO000Oo000 ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( oOOoOooOo ) + "[/COLOR]" , 'url' , 999 , iiiii , oo0OOo , '' )
 if 78 - 78: i1iiIII111ii % OO00O0O0O00Oo + I1ii
 OOooOoooOoOo = o0OOOO00O0Oo ( )
 if 48 - 48: I1II1
 if OOooOoooOoOo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOooOoooOoOo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 11 - 11: oOOOO + OoI1Ii11I1Ii1i - O0o00 / OOO0O + oo . OOoO
def i1Iii1i1I ( name , url ) :
 if 91 - 91: I1ii + ooo0Oo0 . OOoOoo00oo * I1ii + ooo0Oo0 * oo
 hash = [ ]
 O000OOOOOo = url
 i1I1iI = oo0OooOOo0 ( url )
 if 22 - 22: ooO + I1II1 . o0oo0o * iiIIi1IiIi11 % i11iIiiIii * ooo0Oo0
 o0OO00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( i1I1iI )
 for I11i1I1I in o0OO00oO :
  if 77 - 77: oo
  if '<search>' in I11i1I1I :
   if 17 - 17: iiIIi1IiIi11 % O0o00 . OOoOoo00oo + O0o00 / OOoO
   O0oOO0O = re . compile ( '<search>(.+?)</search>' ) . findall ( I11i1I1I )
   if len ( O0oOO0O ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( I11i1I1I ) [ 0 ]
    oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
    url = name + "!" + url + "!" + oO
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    oo000OO00Oo ( name , url , 20 , oO , oO )
    if 75 - 75: ooo0Oo0 - o0ooo % iiIIi1IiIi11
   elif len ( O0oOO0O ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
    oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
    url = O000OOOOOo + "!" + name + "!" + oO
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    oo000OO00Oo ( name , url , 22 , oO , oO )
    if 37 - 37: o0ooo * oo / OOoooooO - iiIIi1IiIi11 % OOoO . oOOOo0o0O
  elif '<regex>' in I11i1I1I :
   O00I1iI1 = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( I11i1I1I )
   O00I1iI1 = '' . join ( O00I1iI1 )
   iiiIi1 = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( O00I1iI1 )
   O00I1iI1 = urllib . quote_plus ( O00I1iI1 )
   if 38 - 38: OO00O0O0O00Oo
   Ooo00o0Oooo = hashlib . md5 ( )
   for OOooooO0Oo in O00I1iI1 : Ooo00o0Oooo . update ( str ( OOooooO0Oo ) )
   Ooo00o0Oooo = str ( Ooo00o0Oooo . hexdigest ( ) )
   if 91 - 91: OOO0O . o0oo0o / oOOOo0o0O + ooO
   I11i1I1I = I11i1I1I . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   I11i1I1I = re . sub ( '<regex>.+?</regex>' , '' , I11i1I1I )
   I11i1I1I = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , I11i1I1I )
   I11i1I1I = re . sub ( '<link></link>' , '' , I11i1I1I )
   if 42 - 42: OOoooooO . OOO0O . OOoooooO - I1ii
   name = re . sub ( '<meta>.+?</meta>' , '' , I11i1I1I )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 40 - 40: OOoooooO - i11iIiiIii / i1iiIII111ii
   try : I11iiI1i1 = re . findall ( '<date>(.+?)</date>' , I11i1I1I ) [ 0 ]
   except : I11iiI1i1 = ''
   if re . search ( r'\d+' , I11iiI1i1 ) : name += ' [COLOR red] Updated %s[/COLOR]' % I11iiI1i1
   if 47 - 47: iiIIi1IiIi11 - i1iiIII111ii . OOoO + OoI1Ii11I1Ii1i . i11iIiiIii
   try : OOo0oO00ooO00 = re . findall ( '<thumbnail>(.+?)</thumbnail>' , I11i1I1I ) [ 0 ]
   except : OOo0oO00ooO00 = iiiii
   if 90 - 90: o0ooo * OO00O0O0O00Oo + OOO0O
   try : OO = re . findall ( '<fanart>(.+?)</fanart>' , I11i1I1I ) [ 0 ]
   except : OO = O0O0OO0O0O0
   if 83 - 83: I1II1 / ooo0Oo0 - O0o00 - OOoOoo00oo
   try : iI1i11iII111 = re . findall ( '<meta>(.+?)</meta>' , I11i1I1I ) [ 0 ]
   except : iI1i11iII111 = '0'
   if 15 - 15: i11iIiiIii % i1iiIII111ii . oo + I1ii
   try : url = re . findall ( '<link>(.+?)</link>' , I11i1I1I ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % iI1i11iII111 )
   url = '<preset>search</preset>%s' % iI1i11iII111 if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % iI1i11iII111 )
   url = '<preset>searchsd</preset>%s' % iI1i11iII111 if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 61 - 61: oo * I1ii % oo - ooO - o0oo0o
   if not O00I1iI1 == '' :
    hash . append ( { 'regex' : Ooo00o0Oooo , 'response' : O00I1iI1 } )
    url += '|regex=%s' % O00I1iI1
    if 74 - 74: I1ii + OOoO / O0o00
   oO000Oo000 ( name , url , 30 , OOo0oO00ooO00 , OO )
   if 100 - 100: o0ooo * o0oo0o
  elif '<sportsdevil>' in I11i1I1I :
   O0oOO0O = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( I11i1I1I )
   if len ( O0oOO0O ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( I11i1I1I ) [ 0 ]
    try :
     O0oOoOOOoOO = re . compile ( '<referer>(.+?)</referer>' ) . findall ( I11i1I1I ) [ 0 ]
    except : O0oOoOOOoOO = "None"
    oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
    try :
     oo0OOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( I11i1I1I ) [ 0 ]
    except : oo0OOo = O0O0OO0O0O0
    ii1ii11IIIiiI = O0oOoOOOoOO
    O00OOOoOoo0O = "/"
    if not ii1ii11IIIiiI . endswith ( O00OOOoOoo0O ) :
     O000OOo00oo = ii1ii11IIIiiI + "/"
    else :
     O000OOo00oo = ii1ii11IIIiiI
    i1I1iI = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = i1I1iI + '%26referer=' + O000OOo00oo
    oO000Oo000 ( name , url , 2 , oO , oo0OOo )
    if 86 - 86: O0o00 * OOoOoo00oo . iiIIi1IiIi11
   elif len ( O0oOO0O ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
    oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
    try :
     oo0OOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( I11i1I1I ) [ 0 ]
    except : oo0OOo = O0O0OO0O0O0
    oO000Oo000 ( name , O000OOOOOo + 'NOTPLAY' , 8 , oO , oo0OOo )
    if 32 - 32: OOO0O . i1Ii * oOOOO
  elif '<folder>' in I11i1I1I :
   iI11Ii = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( I11i1I1I )
   for name , url , oO , oo0OOo in iI11Ii :
    oo000OO00Oo ( name , url , 1 , oO , oo0OOo )
    if 93 - 93: OOO0O % ooO . i1iiIII111ii . i11iIiiIii
  elif '<m3u>' in I11i1I1I :
   iI11Ii = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( I11i1I1I )
   for name , url , oO , oo0OOo in iI11Ii :
    oo000OO00Oo ( name , url , 10 , oO , oo0OOo )
    if 56 - 56: I1ii % I1II1 - ooo0Oo0
  else :
   O0oOO0O = re . compile ( '<link>(.+?)</link>' ) . findall ( I11i1I1I )
   if len ( O0oOO0O ) == 1 :
    iI11Ii = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( I11i1I1I )
    i1iIIIi1i = len ( o0OO00oO )
    for name , url , oO , oo0OOo in iI11Ii :
     oO000Oo000 ( name , url , 2 , oO , oo0OOo )
   elif len ( O0oOO0O ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
    oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
    try :
     oo0OOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( I11i1I1I ) [ 0 ]
    except : oo0OOo = O0O0OO0O0O0
    oO000Oo000 ( name , O000OOOOOo , 3 , oO , oo0OOo )
    if 100 - 100: i1iiIII111ii - I1II1 % oOOOo0o0O * OOoOoo00oo + ooo0Oo0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 88 - 88: OoI1Ii11I1Ii1i - O0o00 * I1II1 * OoI1Ii11I1Ii1i . OoI1Ii11I1Ii1i
def I111iI ( name , url , iconimage ) :
 oOOo0 = [ ]
 II1I1iiIII = [ ]
 oOOo0O00o = [ ]
 i1I1iI = oo0OooOOo0 ( url )
 iIiIi11 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( i1I1iI ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iIiIi11 ) [ 0 ]
 O0oOO0O = re . compile ( '<link>(.+?)</link>' ) . findall ( iIiIi11 )
 OOooooO0Oo = 1
 for OOO in O0oOO0O :
  iiiiI = OOO
  if '(' in OOO :
   OOO = OOO . split ( '(' ) [ 0 ]
   oooOo0OOOoo0 = str ( iiiiI . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   oOOo0 . append ( OOO )
   II1I1iiIII . append ( oooOo0OOOoo0 )
  else :
   oOOo0 . append ( OOO )
   II1I1iiIII . append ( 'Link ' + str ( OOooooO0Oo ) )
  OOooooO0Oo = OOooooO0Oo + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 OOoOOO0O000 = O00ooooo00 . select ( name , II1I1iiIII )
 if OOoOOO0O000 < 0 :
  quit ( )
 else :
  url = oOOo0 [ OOoOOO0O000 ]
  print url
  if 37 - 37: OoI1Ii11I1Ii1i - I1II1 - OOO0O
 url = oOOo0 [ OOoOOO0O000 ]
 name = II1I1iiIII [ OOoOOO0O000 ]
 o0o0O0O00oOOo ( name , url , iiiii )
 if 14 - 14: o0ooo + oOOOo0o0O
def oo00oO0O0 ( name , url , iconimage ) :
 if 30 - 30: OOoOoo00oo + I1ii * oOOOO % i11iIiiIii % o0ooo
 oOOo0 = [ ]
 II1I1iiIII = [ ]
 oOOo0O00o = [ ]
 OO0OoOO0o0o = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 i1I1iI = oo0OooOOo0 ( url )
 iIiIi11 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( i1I1iI ) [ 0 ]
 O0oOO0O = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iIiIi11 )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iIiIi11 ) [ 0 ]
 if 95 - 95: i11iIiiIii
 iI1111iiii = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 67 - 67: OoI1Ii11I1Ii1i / ooo0Oo0 * i1iiIII111ii + oOOOO
 OOooooO0Oo = 1
 if 65 - 65: OoI1Ii11I1Ii1i - I1ii / OOoooooO / OOoO / ooO
 for OOO in O0oOO0O :
  iiiiI = OOO
  if '(' in OOO :
   OOO = OOO . split ( '(' ) [ 0 ]
   oooOo0OOOoo0 = str ( iiiiI . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   oOOo0 . append ( OOO )
   II1I1iiIII . append ( oooOo0OOOoo0 )
   OO0OoOO0o0o . append ( 'Stream ' + str ( OOooooO0Oo ) )
  else :
   oOOo0 . append ( OOO )
   II1I1iiIII . append ( 'Link ' + str ( OOooooO0Oo ) )
   if 71 - 71: OO00O0O0O00Oo + i1iiIII111ii
  OOooooO0Oo = OOooooO0Oo + 1
  if 28 - 28: OOoOoo00oo
 name = '[COLOR red]' + name + '[/COLOR]'
 if 38 - 38: OOoooooO % OOoO % oOOOO / O0o00 + o0ooo / ooO
 O00ooooo00 = xbmcgui . Dialog ( )
 OOoOOO0O000 = O00ooooo00 . select ( name , II1I1iiIII )
 if OOoOOO0O000 < 0 :
  quit ( )
 else :
  ii1ii11IIIiiI = II1I1iiIII [ OOoOOO0O000 ]
  O00OOOoOoo0O = "/"
  if not ii1ii11IIIiiI . endswith ( O00OOOoOoo0O ) :
   O000OOo00oo = ii1ii11IIIiiI + "/"
  else :
   O000OOo00oo = ii1ii11IIIiiI
  url = iI1111iiii + oOOo0 [ OOoOOO0O000 ] + "%26referer=" + O000OOo00oo
  if 54 - 54: o0oo0o % I1ii - OOoOoo00oo / oOOOo0o0O - O0o00 . oOOOO
 name = II1I1iiIII [ OOoOOO0O000 ]
 o0o0O0O00oOOo ( name , url , iiiii )
 if 11 - 11: I1ii . O0o00 * i1Ii * OoI1Ii11I1Ii1i + OOoooooO
def IiII111i1i11 ( name , url , iconimage ) :
 if 40 - 40: OOoooooO * i1Ii * i11iIiiIii
 I11iii1Ii , I1i1I1II = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 I11iii1Ii += urllib . unquote_plus ( I1i1I1II )
 url = regex . resolve ( I11iii1Ii )
 if 57 - 57: OOoooooO
 o0o0O0O00oOOo ( name , url , iconimage )
 if 29 - 29: o0ooo - i1Ii * OoI1Ii11I1Ii1i + OoI1Ii11I1Ii1i . OOoO + OoI1Ii11I1Ii1i
def O0o000Oo ( ) :
 if 67 - 67: ooo0Oo0 . ooO
 oO000Oo000 ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 oO000Oo000 ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 oO000Oo000 ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 oo000OO00Oo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 oo000OO00Oo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 27 - 27: OOoooooO % ooo0Oo0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 73 - 73: OOoOoo00oo
def ooOOoo0oOooo0 ( ) :
 if 61 - 61: o0ooo - OOoOoo00oo - ooO
 oo000OO00Oo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 25 - 25: I1II1 * oOOOO + I1ii . OOO0O . OOO0O
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 58 - 58: ooo0Oo0
def oOoO ( ) :
 if 81 - 81: o0ooo - o0ooo . iiIIi1IiIi11
 oo000OO00Oo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 73 - 73: oOOOO % i11iIiiIii - ooo0Oo0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 7 - 7: I1II1 * i11iIiiIii * i1iiIII111ii + OOoooooO % O0o00 - OOoooooO
def II1IIIIiII1i ( ) :
 if 1 - 1: OOoO
 OOooooO0Oo = 0
 O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
 for I11i1I1I in o0OO00oO :
  OOooooO0Oo = OOooooO0Oo + 1
  I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
  iIi1IIIi1 = I11i1I1I
  oo000OO00Oo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( OOooooO0Oo ) + '[/COLOR]' , iIi1IIIi1 , 12 , iiiii , O0O0OO0O0O0 )
  if 81 - 81: i1Ii % ooO . o0oo0o
 O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
 for I11i1I1I in o0OO00oO :
  OOooooO0Oo = OOooooO0Oo + 1
  I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
  iIi1IIIi1 = I11i1I1I
  oo000OO00Oo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( OOooooO0Oo ) + '[/COLOR]' , iIi1IIIi1 , 12 , iiiii , O0O0OO0O0O0 )
  if 4 - 4: i11iIiiIii % O0o00 % ooO / i1Ii
 O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
 for I11i1I1I in o0OO00oO :
  OOooooO0Oo = OOooooO0Oo + 1
  I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
  iIi1IIIi1 = I11i1I1I
  oo000OO00Oo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( OOooooO0Oo ) + '[/COLOR]' , iIi1IIIi1 , 12 , iiiii , O0O0OO0O0O0 )
  if 6 - 6: iiIIi1IiIi11 / ooo0Oo0 % OOoOoo00oo - ooo0Oo0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 31 - 31: OOoOoo00oo
def i1 ( url ) :
 if 88 - 88: O0o00 - OOoooooO + OOoOoo00oo * ooo0Oo0 % o0oo0o + oo
 O0oOo00o = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
 if 76 - 76: ooo0Oo0 * iiIIi1IiIi11 % OO00O0O0O00Oo
 for I11i1I1I in o0OO00oO :
  iIIIIii1 = re . compile ( 'title="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
  oO = re . compile ( '<img.+?src="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
  oo000OO00Oo ( '[COLOR dodgerblue]' + iIIIIii1 + '[/COLOR]' , url , 12 , oO , O0O0OO0O0O0 )
  if 57 - 57: o0oo0o - ooO / OO00O0O0O00Oo - I1II1 * OoI1Ii11I1Ii1i % OOoO
 try :
  Oo00OO0o0o00 = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( O0oOo00o ) [ 0 ]
  oo000OO00Oo ( '[COLOR yellow]Next Page -->[/COLOR]' , Oo00OO0o0o00 , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 12 - 12: ooO + ooO - I1ii * oo % oo - OOoO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 52 - 52: OOoooooO . iiIIi1IiIi11 + OO00O0O0O00Oo
def iiii1IIi ( url ) :
 if 33 - 33: o0ooo * OOoOoo00oo - OOoO
 O0oOo00o = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( O0oOo00o )
 for I11i1I1I in o0OO00oO :
  try :
   iIIIIii1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
  except :
   iIIIIii1 = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
  oo000OO00Oo ( '[COLOR dodgerblue]' + iIIIIii1 + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 83 - 83: o0ooo - i1iiIII111ii / oOOOO / OO00O0O0O00Oo + oOOOo0o0O - I1II1
def I11I1i1iIII1I ( url ) :
 if 49 - 49: I1ii . OOO0O . OOoO
 O0oOo00o = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( O0oOo00o )
 o000ooooO0o = 0
 for I11i1I1I in o0OO00oO :
  try :
   iIIIIii1 = re . compile ( 'title="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
   oO = re . compile ( '<img.+?src="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
  except : o000ooooO0o = 1
  if 40 - 40: I1ii + ooO * OOoOoo00oo
  if o000ooooO0o == 0 :
   oo000OO00Oo ( '[COLOR dodgerblue]' + iIIIIii1 + '[/COLOR]' , url , 12 , oO , O0O0OO0O0O0 )
  o000ooooO0o = 0
  if 85 - 85: i1iiIII111ii * oo . I1II1 - i11iIiiIii
 try :
  Oo00OO0o0o00 = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( O0oOo00o ) [ 0 ]
  oo000OO00Oo ( '[COLOR yellow]Next Page -->[/COLOR]' , Oo00OO0o0o00 , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 18 - 18: i1iiIII111ii + i1Ii - I1II1
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 53 - 53: ooO
def Ooo00Oo ( url ) :
 if 93 - 93: I1ii * i1iiIII111ii
 ooI1i1i1 = datetime . date . today ( )
 OoO0O00O0oo0O = datetime . datetime . strftime ( ooI1i1i1 , '%A %d %B %Y' )
 if 36 - 36: OOoOoo00oo + I1II1 - i1iiIII111ii - I1II1 % oOOOO . oOOOo0o0O
 oO000Oo000 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( OoO0O00O0oo0O ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO000Oo000 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 74 - 74: i11iIiiIii . ooo0Oo0
 O0oOo00o = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( O0oOo00o )
 o000ooooO0o = 0
 OOooooO0Oo = 0
 for I11i1I1I in o0OO00oO :
  try :
   iiI = re . compile ( 'title="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
   try :
    oOIIiIi = re . compile ( '<p>(.+?)</p>' ) . findall ( I11i1I1I ) [ 0 ]
   except : oOIIiIi = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( I11i1I1I ) [ 0 ]
   oO = re . compile ( '<img src="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
  except : o000ooooO0o = 1
  if 91 - 91: I1ii * oo / ooo0Oo0 . I1II1 + O0o00 + o0ooo
  if o000ooooO0o == 0 :
   if 'vs' in iiI :
    iIIIIii1 = '[COLOR dodgerblue]' + iiI + ' - ' + '[/COLOR][COLOR green]' + oOIIiIi + '[/COLOR]'
    OOooooO0Oo = OOooooO0Oo + 1
    oO000Oo000 ( iIIIIii1 , url , 206 , oO , O0O0OO0O0O0 , '' )
  o000ooooO0o = 0
  if 8 - 8: oOOOo0o0O / I1ii
 if OOooooO0Oo == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 20 - 20: ooo0Oo0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 95 - 95: iiIIi1IiIi11 - ooo0Oo0
def I1ii1ii11i1I ( name , url , iconimage ) :
 if 58 - 58: iiIIi1IiIi11 + oo
 O0oOo00o = oo0OooOOo0 ( url )
 II1I1I1Ii = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( O0oOo00o ) [ 0 ]
 if 70 - 70: O0o00 % oOOOo0o0O + OOoOoo00oo / i1iiIII111ii % I1II1
 if not "http" in II1I1I1Ii :
  II1I1I1Ii = II1I1I1Ii . replace ( "//" , "" )
  url = "http://" + II1I1I1Ii
 else :
  url = II1I1I1Ii
  if 100 - 100: OOO0O + OOoOoo00oo * OOO0O
 oOOo0OOOo00O = url
 if 76 - 76: i11iIiiIii + OOO0O / I1ii - O0o00 - i1iiIII111ii + I1ii
 ooI1i = oo0OooOOo0 ( url )
 II1I1I1Ii = re . compile ( "atob(.+?)," ) . findall ( ooI1i ) [ 0 ]
 II1I1I1Ii = II1I1I1Ii . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( II1I1I1Ii )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + oOOo0OOOo00O + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 o0o0O0O00oOOo ( name , url , iconimage )
 if 32 - 32: o0ooo / O0o00 + OOoOoo00oo
def ii1I1i1iiiI ( url ) :
 if 96 - 96: OoI1Ii11I1Ii1i + oOOOo0o0O
 i1I1iI = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( i1I1iI )
 for I11i1I1I in o0OO00oO :
  if 44 - 44: oOOOo0o0O
  if '<display>eWVz</display>' in I11i1I1I :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( I11i1I1I ) [ 0 ]
   oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
   oo0OOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( I11i1I1I ) [ 0 ]
   iIIIIii1 = base64 . b64decode ( iIIIIii1 )
   url = base64 . b64decode ( url )
   oO = base64 . b64decode ( oO )
   oo0OOo = base64 . b64decode ( oo0OOo )
   oo000OO00Oo ( iIIIIii1 , url , 220 , oO , oo0OOo , '' )
   if 20 - 20: oOOOO + i1iiIII111ii / I1II1 % o0oo0o
def oOo0O ( url ) :
 if 64 - 64: I1ii - iiIIi1IiIi11 + iiIIi1IiIi11 - oOOOO
 O0oOo00o = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( O0oOo00o )
 if 30 - 30: o0oo0o . ooo0Oo0 . OOoOoo00oo / OOO0O
 for I11i1I1I in o0OO00oO :
  iIIIIii1 = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( I11i1I1I ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( I11i1I1I ) [ 0 ]
  try :
   iiI1I1 = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( I11i1I1I ) [ 0 ]
  except : iiI1I1 = "SD"
  iiI1I1 = '[COLOR yellow]' + iiI1I1 + '[/COLOR]'
  oO = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
  iIIIIii1 = iIIIIii1 . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 56 - 56: ooo0Oo0 . I1II1 + oo
  oO000Oo000 ( '[COLOR mediumpurple]' + iIIIIii1 + '[/COLOR] - ' + iiI1I1 , url , 212 , oO , O0O0OO0O0O0 , '' )
  if 1 - 1: iiIIi1IiIi11
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( O0oOo00o ) [ 0 ]
  O0O0Ooo = 'http://www.fmovies.se/' + url
  oo000OO00Oo ( "Next Page -->" , O0O0Ooo , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 77 - 77: OOO0O / OoI1Ii11I1Ii1i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 46 - 46: OOO0O % o0oo0o . iiIIi1IiIi11 % iiIIi1IiIi11 + i11iIiiIii
def Oo00o0OO0O00o ( url ) :
 if 82 - 82: oOOOO + OoI1Ii11I1Ii1i - ooO . ooO
 O0oOo00o = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( O0oOo00o )
 if 6 - 6: OOO0O / oOOOO / OOoO
 if 27 - 27: OOoOoo00oo * OOoooooO . OO00O0O0O00Oo % i1Ii * i1Ii . ooO
def O0OOoOOO0oO ( url ) :
 if 28 - 28: OOoooooO + i11iIiiIii / oOOOO % o0ooo % oo - I1II1
 if "iptvembed" in url :
  O0oOo00o = oo0OooOOo0 ( url )
  o0OO00oO = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( O0oOo00o )
  for I11i1I1I in o0OO00oO :
   I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
   I11i1I1I = I11i1I1I . replace ( '</pre>' , '' )
   url = I11i1I1I
   if 54 - 54: ooO + OOoO
 if "sourcetv" in url :
  O0oOo00o = oo0OooOOo0 ( url )
  o0OO00oO = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( O0oOo00o )
  for I11i1I1I in o0OO00oO :
   I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
   I11i1I1I = I11i1I1I . replace ( '</pre>' , '' )
   url = I11i1I1I
   if 83 - 83: I1ii - ooo0Oo0 + OOoOoo00oo
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 IIiI1 = [ ]
 for i1iI1 , ii1 , url in iIi1Ii1i1iI :
  I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : url }
  IIiI1 . append ( I1IiiI1ii1i )
 list = [ ]
 for O0o in IIiI1 :
  I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
  iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
  for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
   I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
  list . append ( I1IiiI1ii1i )
  if 61 - 61: iiIIi1IiIi11 % ooo0Oo0 - OOO0O - OOoO % I1II1
 OoOOO00 = 0
 for O0o in list :
  OoOOO00 = 1
  iIIIIii1 = oOO0000ooooo ( O0o [ "display_name" ] )
  url = oOO0000ooooo ( O0o [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   oO000Oo000 ( '[COLOR mediumpurple]' + iIIIIii1 + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   oo000OO00Oo ( '[COLOR mediumpurple]' + iIIIIii1 + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 79 - 79: OOO0O - oOOOO + OOO0O . oOOOo0o0O
 if OoOOO00 == 0 :
  oO000Oo000 ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 28 - 28: ooO - iiIIi1IiIi11
def o00o000oo ( url ) :
 if 44 - 44: ooo0Oo0 - oOOOO % o0oo0o
 i1I1iI = oo0OooOOo0 ( url )
 O000OOOOOo = url
 o0OO00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( i1I1iI )
 for I11i1I1I in o0OO00oO :
  if 71 - 71: OOoooooO . i1iiIII111ii - OoI1Ii11I1Ii1i % i1iiIII111ii . OOoO
  O0oOO0O = re . compile ( '<search>(.+?)</search>' ) . findall ( I11i1I1I )
  if len ( O0oOO0O ) == 1 :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( I11i1I1I ) [ 0 ]
   oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
   url = iIIIIii1 + "!" + url + "!" + oO
   iIIIIii1 = '[COLOR mediumpurple]' + iIIIIii1 + '[/COLOR]'
   oo000OO00Oo ( iIIIIii1 , url , 20 , oO , oO )
   if 89 - 89: iiIIi1IiIi11 . I1II1 / I1ii % o0ooo . oo
  elif len ( O0oOO0O ) > 1 :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
   url = O000OOOOOo + "!" + iIIIIii1 + "!" + oO
   iIIIIii1 = '[COLOR mediumpurple]' + iIIIIii1 + '[/COLOR]'
   oo000OO00Oo ( iIIIIii1 , url , 22 , oO , oO )
   if 50 - 50: OOoO + I1ii . ooO % OOO0O
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 5 - 5: o0ooo / OoI1Ii11I1Ii1i + i1Ii * OO00O0O0O00Oo - O0o00 % ooo0Oo0
def IiII1 ( url ) :
 if 18 - 18: OOoooooO * o0ooo . iiIIi1IiIi11 / I1ii / i11iIiiIii
 ooI1i1i1 = datetime . date . today ( )
 OoO0O00O0oo0O = datetime . datetime . strftime ( ooI1i1i1 , '%A %d %B %Y' )
 if 21 - 21: oOOOo0o0O / I1ii + i1iiIII111ii + OoI1Ii11I1Ii1i
 oO000Oo000 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( OoO0O00O0oo0O ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO000Oo000 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 91 - 91: i11iIiiIii / ooO + iiIIi1IiIi11 + OOoooooO * i11iIiiIii
 i1I1iI = oo0OooOOo0 ( url )
 O000OOOOOo = url
 o0OO00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( i1I1iI )
 for I11i1I1I in o0OO00oO :
  if 66 - 66: o0oo0o % ooO - I1II1 + oOOOO * OO00O0O0O00Oo . i1Ii
  O0oOO0O = re . compile ( '<search>(.+?)</search>' ) . findall ( I11i1I1I )
  if len ( O0oOO0O ) == 1 :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( I11i1I1I ) [ 0 ]
   oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
   url = iIIIIii1 + "!" + url + "!" + oO
   iIIIIii1 = '[COLOR mediumpurple]' + iIIIIii1 + '[/COLOR]'
   oo000OO00Oo ( iIIIIii1 , url , 20 , oO , oO )
   if 52 - 52: OOoooooO + I1II1 . iiIIi1IiIi11 . I1ii . O0o00
  elif len ( O0oOO0O ) > 1 :
   iIIIIii1 = re . compile ( '<title>(.+?)</title>' ) . findall ( I11i1I1I ) [ 0 ]
   oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I11i1I1I ) [ 0 ]
   url = O000OOOOOo + "!" + iIIIIii1 + "!" + oO
   iIIIIii1 = '[COLOR mediumpurple]' + iIIIIii1 + '[/COLOR]'
   oo000OO00Oo ( iIIIIii1 , url , 22 , oO , oO )
   if 97 - 97: ooo0Oo0 / iiIIi1IiIi11
def Oooo0 ( ) :
 if 59 - 59: OoI1Ii11I1Ii1i
 ooI1i1i1 = datetime . date . today ( )
 OoO0O00O0oo0O = datetime . datetime . strftime ( ooI1i1i1 , '%A %d %B %Y' )
 if 47 - 47: OOoooooO - ooo0Oo0 / OOoO
 oO000Oo000 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( OoO0O00O0oo0O ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO000Oo000 ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 12 - 12: OOoOoo00oo
 i1I1iI = oo0OooOOo0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 o0OO00oO = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( i1I1iI )
 O0 = str ( o0OO00oO )
 iII1 = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( O0 )
 for I11i1I1I in iII1 :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in I11i1I1I :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( I11i1I1I ) [ 0 ]
    iiI = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
    oO = re . compile ( 'src="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( I11i1I1I ) [ 0 ]
    try :
     II = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
     II = II1i ( II )
    except : II = "null"
    iIIIIii1 = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + iiI + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    iIIIIii1 = Ii1IIIIi1ii1I ( iIIIIii1 )
    iIi1IIIi1 = iiI + "!" + II . lower ( ) + "!" + oO
    oo000OO00Oo ( iIIIIii1 , iIi1IIIi1 , 20 , oO , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( I11i1I1I ) [ 0 ]
    iiI = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
    try :
     II = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
    except : II = "null"
    oO = re . compile ( 'src="(.+?)"' ) . findall ( I11i1I1I ) [ 0 ]
    iIIIIii1 = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + iiI + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    iIIIIii1 = Ii1IIIIi1ii1I ( iIIIIii1 )
    iIi1IIIi1 = iiI + "!" + II . lower ( ) + "!" + oO
    oo000OO00Oo ( iIIIIii1 , iIi1IIIi1 , 20 , oO , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 13 - 13: ooo0Oo0 % o0ooo . I1ii / oo % OOoOoo00oo . OoI1Ii11I1Ii1i
def i1iIi ( name , url , iconimage ) :
 if 30 - 30: I1II1 - o0oo0o / OoI1Ii11I1Ii1i
 try :
  url , O0000OOO0 , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 51 - 51: ooo0Oo0 / i1Ii / i1iiIII111ii
 I111iIi1 = [ ]
 if 92 - 92: OOoooooO
 i1I1iI = oo0OooOOo0 ( url )
 iIiIi11 = re . compile ( '<title>' + re . escape ( O0000OOO0 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( i1I1iI ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iIiIi11 ) [ 0 ]
 O0oOO0O = re . compile ( '<search>(.+?)</search>' ) . findall ( iIiIi11 )
 for OOO in O0oOO0O :
  I111iIi1 . append ( OOO )
  if 22 - 22: oo % iiIIi1IiIi11 * I1ii / OOoOoo00oo % i11iIiiIii * oOOOO
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 95 - 95: OoI1Ii11I1Ii1i - i1Ii * ooo0Oo0 + o0ooo
 iIi1 = 0
 if 21 - 21: oOOOO
 OoO00 = [ ]
 OO0Ooooo000Oo = [ ]
 O0oOoo0o000O0 = [ ]
 I1IiiI . update ( 0 )
 o00oO0o0o = 0
 if 99 - 99: I1II1 * oOOOO
 if O0Oooo00 == "true" :
  o00oO0o0o = 1
  O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
  for I11i1I1I in o0OO00oO :
   if iIi1 < 100 :
    I1IiiI . update ( iIi1 )
    iIi1 = iIi1 + 3
   I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
   url = I11i1I1I
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1 , url in iIi1Ii1i1iI :
    I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : url }
    IIiI1 . append ( I1IiiI1ii1i )
   Ooooooo = [ ]
   for O0o in IIiI1 :
    I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
    for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
     I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
    Ooooooo . append ( I1IiiI1ii1i )
    if 39 - 39: i1Ii * oo + o0oo0o - i1Ii + OOoOoo00oo
   for O0o in Ooooooo :
    name = oOO0000ooooo ( O0o [ "display_name" ] )
    url = oOO0000ooooo ( O0o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OoO00 . append ( name )
    OO0Ooooo000Oo . append ( url )
    if "hd" in name . lower ( ) :
     O0oOoo0o000O0 . append ( "1" )
    else :
     O0oOoo0o000O0 . append ( "0" )
    o0 = list ( zip ( O0oOoo0o000O0 , OoO00 , OO0Ooooo000Oo ) )
    if 30 - 30: I1II1 * OoI1Ii11I1Ii1i
 if Ooo0 == "true" :
  o00oO0o0o = 1
  O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
  for I11i1I1I in o0OO00oO :
   if iIi1 < 100 :
    I1IiiI . update ( iIi1 )
    iIi1 = iIi1 + 3
   I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
   url = I11i1I1I
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1 , url in iIi1Ii1i1iI :
    I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : url }
    IIiI1 . append ( I1IiiI1ii1i )
   Ooooooo = [ ]
   for O0o in IIiI1 :
    I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
    for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
     I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
    Ooooooo . append ( I1IiiI1ii1i )
    if 38 - 38: i1Ii - I1ii . o0ooo - OO00O0O0O00Oo . OoI1Ii11I1Ii1i
   for O0o in Ooooooo :
    name = oOO0000ooooo ( O0o [ "display_name" ] )
    url = oOO0000ooooo ( O0o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OoO00 . append ( name )
    OO0Ooooo000Oo . append ( url )
    if "hd" in name . lower ( ) :
     O0oOoo0o000O0 . append ( "1" )
    else :
     O0oOoo0o000O0 . append ( "0" )
    o0 = list ( zip ( O0oOoo0o000O0 , OoO00 , OO0Ooooo000Oo ) )
    if 89 - 89: o0oo0o
 if oo00000o0 == "true" :
  o00oO0o0o = 1
  O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
  for I11i1I1I in o0OO00oO :
   if iIi1 < 100 :
    I1IiiI . update ( iIi1 )
    iIi1 = iIi1 + 3
   I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
   url = I11i1I1I
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1 , url in iIi1Ii1i1iI :
    I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : url }
    IIiI1 . append ( I1IiiI1ii1i )
   Ooooooo = [ ]
   for O0o in IIiI1 :
    I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
    for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
     I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
    Ooooooo . append ( I1IiiI1ii1i )
    if 21 - 21: oOOOO % oOOOO
   for O0o in Ooooooo :
    name = oOO0000ooooo ( O0o [ "display_name" ] )
    url = oOO0000ooooo ( O0o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OoO00 . append ( name )
    OO0Ooooo000Oo . append ( url )
    if "hd" in name . lower ( ) :
     O0oOoo0o000O0 . append ( "1" )
    else :
     O0oOoo0o000O0 . append ( "0" )
    o0 = list ( zip ( O0oOoo0o000O0 , OoO00 , OO0Ooooo000Oo ) )
    if 27 - 27: i11iIiiIii / I1ii
 if o00oO0o0o == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 84 - 84: oo
 iIiiiii1i = sorted ( o0 , key = lambda I1i1I1II : int ( I1i1I1II [ 0 ] ) , reverse = True )
 iiIi1IIiI = sorted ( I111iIi1 )
 if 23 - 23: i1iiIII111ii . OOoOoo00oo
 iiiiiiii1 = 0
 if 9 - 9: OOoooooO - I1ii - iiIIi1IiIi11
 I1IiiI . update ( 100 )
 if 82 - 82: i1Ii - i1Ii + o0ooo
 oO000Oo000 ( '                    [COLOR yellow][I]LINKS FOR ' + O0000OOO0 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 oO000Oo000 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 8 - 8: OOO0O % iiIIi1IiIi11 * oOOOo0o0O % i1iiIII111ii . OOoooooO / OOoooooO
 if 81 - 81: O0o00
 for II in iiIi1IIiI :
  if 99 - 99: oOOOo0o0O * OOoO * OO00O0O0O00Oo
  oO000Oo000 ( '                                  [COLOR mediumpurple][I]' + II . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 92 - 92: oo
  O0 = II . split ( ' ' )
  if 40 - 40: o0ooo / i1Ii
  for OOOoO000 , name , url in iIiiiii1i :
   if 57 - 57: OOoO
   oOOOoo = 0
   if 15 - 15: i11iIiiIii % ooo0Oo0 * oOOOO / OO00O0O0O00Oo
   for oooO0o0o0O0 in O0 :
    if 27 - 27: OoI1Ii11I1Ii1i - iiIIi1IiIi11 / oOOOO
    if not oooO0o0o0O0 . lower ( ) in name . lower ( ) :
     oOOOoo = 1
     if 76 - 76: OOO0O % ooo0Oo0 . o0oo0o - i1Ii * OoI1Ii11I1Ii1i . iiIIi1IiIi11
   if oOOOoo == 0 :
    iiiiiiii1 = iiiiiiii1 + 1
    if "hd" in name . lower ( ) :
     oO000Oo000 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( iiiiiiii1 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO000Oo000 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( iiiiiiii1 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 84 - 84: OO00O0O0O00Oo + oOOOO
  if iiiiiiii1 == 0 :
   oO000Oo000 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 28 - 28: oOOOo0o0O - i11iIiiIii . I1ii + i1Ii / I1ii
  O0 = ""
  if 35 - 35: i1Ii
 I1IiiI . close ( )
 if 75 - 75: oo / I1ii . i1Ii * OOoOoo00oo - OOoO
def i1i1IIii1i1 ( name , url , iconimage ) :
 if 65 - 65: ooo0Oo0 + o0ooo / OOoOoo00oo
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 83 - 83: OOO0O . iiIIi1IiIi11 - oo
 iIi1 = 0
 try :
  O0000OOO0 , II , iconimage = url . split ( '!' )
 except :
  try :
   II , iconimage = url . split ( '!' )
   O0000OOO0 = II
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 65 - 65: o0oo0o / OOoooooO . i1Ii - OOoO
 Oo000 = 0
 if 81 - 81: OOoOoo00oo - OOoOoo00oo % OOoO * O0o00
 if "all " in name . lower ( ) :
  II = II . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  O0000OOO0 = O0000OOO0 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  Oo000 = 1
  if 39 - 39: oOOOO
 OoO00 = [ ]
 OO0Ooooo000Oo = [ ]
 O0oOoo0o000O0 = [ ]
 I1IiiI . update ( 0 )
 o00oO0o0o = 0
 if O0Oooo00 == "true" :
  o00oO0o0o = 1
  O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
  for I11i1I1I in o0OO00oO :
   if iIi1 < 100 :
    I1IiiI . update ( iIi1 )
    iIi1 = iIi1 + 3
   I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
   url = I11i1I1I
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1 , url in iIi1Ii1i1iI :
    I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : url }
    IIiI1 . append ( I1IiiI1ii1i )
   Ooooooo = [ ]
   for O0o in IIiI1 :
    I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
    for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
     I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
    Ooooooo . append ( I1IiiI1ii1i )
    if 58 - 58: ooO % OOO0O
   for O0o in Ooooooo :
    name = oOO0000ooooo ( O0o [ "display_name" ] )
    url = oOO0000ooooo ( O0o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OoO00 . append ( name )
    OO0Ooooo000Oo . append ( url )
    if "hd" in name . lower ( ) :
     O0oOoo0o000O0 . append ( "1" )
    else :
     O0oOoo0o000O0 . append ( "0" )
    o0 = list ( zip ( O0oOoo0o000O0 , OoO00 , OO0Ooooo000Oo ) )
    if 79 - 79: OOO0O % iiIIi1IiIi11 * OoI1Ii11I1Ii1i * o0oo0o . iiIIi1IiIi11 / i1iiIII111ii
 if Ooo0 == "true" :
  o00oO0o0o = 1
  O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
  for I11i1I1I in o0OO00oO :
   if iIi1 < 100 :
    I1IiiI . update ( iIi1 )
    iIi1 = iIi1 + 3
   I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
   url = I11i1I1I
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1 , url in iIi1Ii1i1iI :
    I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : url }
    IIiI1 . append ( I1IiiI1ii1i )
   Ooooooo = [ ]
   for O0o in IIiI1 :
    I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
    for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
     I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
    Ooooooo . append ( I1IiiI1ii1i )
    if 19 - 19: I1II1 + oOOOO + i1iiIII111ii / OOoO / OOoO
   for O0o in Ooooooo :
    name = oOO0000ooooo ( O0o [ "display_name" ] )
    url = oOO0000ooooo ( O0o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OoO00 . append ( name )
    OO0Ooooo000Oo . append ( url )
    if "hd" in name . lower ( ) :
     O0oOoo0o000O0 . append ( "1" )
    else :
     O0oOoo0o000O0 . append ( "0" )
    o0 = list ( zip ( O0oOoo0o000O0 , OoO00 , OO0Ooooo000Oo ) )
    if 86 - 86: I1ii * I1II1 * i1Ii
 if oo00000o0 == "true" :
  o00oO0o0o = 1
  O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
  for I11i1I1I in o0OO00oO :
   if iIi1 < 100 :
    I1IiiI . update ( iIi1 )
    iIi1 = iIi1 + 3
   I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
   url = I11i1I1I
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1 , url in iIi1Ii1i1iI :
    I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : url }
    IIiI1 . append ( I1IiiI1ii1i )
   Ooooooo = [ ]
   for O0o in IIiI1 :
    I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
    for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
     I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
    Ooooooo . append ( I1IiiI1ii1i )
    if 51 - 51: OOoO + i1Ii . ooO . I1ii + o0ooo * ooo0Oo0
   for O0o in Ooooooo :
    name = oOO0000ooooo ( O0o [ "display_name" ] )
    url = oOO0000ooooo ( O0o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OoO00 . append ( name )
    OO0Ooooo000Oo . append ( url )
    if "hd" in name . lower ( ) :
     O0oOoo0o000O0 . append ( "1" )
    else :
     O0oOoo0o000O0 . append ( "0" )
    o0 = list ( zip ( O0oOoo0o000O0 , OoO00 , OO0Ooooo000Oo ) )
    if 72 - 72: oOOOo0o0O + oOOOo0o0O / OOoO . OoI1Ii11I1Ii1i % i1iiIII111ii
 if o00oO0o0o == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 49 - 49: oOOOo0o0O . O0o00 - oo * OoI1Ii11I1Ii1i . oo
 iIiiiii1i = sorted ( o0 , key = lambda I1i1I1II : int ( I1i1I1II [ 0 ] ) , reverse = True )
 if 2 - 2: OoI1Ii11I1Ii1i % OOoOoo00oo
 iiiiiiii1 = 0
 if 63 - 63: ooo0Oo0 % o0oo0o
 I1IiiI . update ( 100 )
 if 39 - 39: iiIIi1IiIi11 / OOoO / I1ii % ooo0Oo0
 oO000Oo000 ( '                                [COLOR yellow][I]LINKS FOR ' + O0000OOO0 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 oO000Oo000 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O0 = II . split ( ' ' )
 for OOOoO000 , name , url in iIiiiii1i :
  if Oo000 == 1 :
   O0Oo00 = name
   if 41 - 41: o0oo0o % oOOOO
  oOOOoo = 0
  if 59 - 59: OOoOoo00oo + i11iIiiIii
  for oooO0o0o0O0 in O0 :
   if 88 - 88: i11iIiiIii - OOoooooO
   if not oooO0o0o0O0 . lower ( ) in name . lower ( ) :
    oOOOoo = 1
    if 67 - 67: OOoOoo00oo . oo + o0ooo - OoI1Ii11I1Ii1i
  if oOOOoo == 0 :
   iiiiiiii1 = iiiiiiii1 + 1
   if Oo000 == 1 :
    if "hd" in name . lower ( ) :
     oO000Oo000 ( '                                          [COLOR blue] ' + str ( O0Oo00 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO000Oo000 ( '                                          [COLOR blue] ' + str ( O0Oo00 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     oO000Oo000 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( iiiiiiii1 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO000Oo000 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( iiiiiiii1 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 70 - 70: OOoOoo00oo / OOoO - o0oo0o - iiIIi1IiIi11
 if iiiiiiii1 == 0 :
  oO000Oo000 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 11 - 11: o0oo0o . OoI1Ii11I1Ii1i . OOoO / ooO - oOOOO
 I1IiiI . close ( )
 if 30 - 30: o0ooo
def Ii111 ( term ) :
 if 67 - 67: I1II1
 oOOo0 = [ ]
 II1I1iiIII = [ ]
 if 52 - 52: OOoO . OOoooooO / o0ooo / OoI1Ii11I1Ii1i . i11iIiiIii
 O0oOo00o = oo0OooOOo0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 o0OO00oO = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOo00o )
 for I11i1I1I in o0OO00oO :
  I11i1I1I = I11i1I1I . replace ( '<br />' , '\n' )
  iIi1IIIi1 = I11i1I1I
  if 30 - 30: oOOOO / i1iiIII111ii . i1Ii . OoI1Ii11I1Ii1i - oo
  iIi1IIIi1 = iIi1IIIi1 . replace ( '#AAASTREAM:' , '#A:' )
  iIi1IIIi1 = iIi1IIIi1 . replace ( '#EXTINF:' , '#A:' )
  iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( iIi1IIIi1 )
  IIiI1 = [ ]
  for i1iI1 , ii1 , iIi1IIIi1 in iIi1Ii1i1iI :
   I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : iIi1IIIi1 }
   IIiI1 . append ( I1IiiI1ii1i )
  list = [ ]
  for O0o in IIiI1 :
   I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
   iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
   for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
    I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
   list . append ( I1IiiI1ii1i )
   if 44 - 44: I1II1 * OoI1Ii11I1Ii1i % OOoooooO + OOoO
  for O0o in list :
   iIIIIii1 = oOO0000ooooo ( O0o [ "display_name" ] )
   iIi1IIIi1 = oOO0000ooooo ( O0o [ "url" ] )
   iIi1IIIi1 = iIi1IIIi1 . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in iIIIIii1 . lower ( ) :
    oOOo0 . append ( iIi1IIIi1 )
    II1I1iiIII . append ( iIIIIii1 )
    if 39 - 39: oOOOo0o0O % o0oo0o % I1II1 % OoI1Ii11I1Ii1i * I1ii + iiIIi1IiIi11
 O00ooooo00 = xbmcgui . Dialog ( )
 OOoOOO0O000 = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , II1I1iiIII )
 if OOoOOO0O000 < 0 :
  quit ( )
  if 68 - 68: oo + i11iIiiIii
 iIi1IIIi1 = oOOo0 [ OOoOOO0O000 ]
 iIIIIii1 = II1I1iiIII [ OOoOOO0O000 ]
 o0o0O0O00oOOo ( iIIIIii1 , iIi1IIIi1 , iiiii )
 if 69 - 69: o0oo0o * o0oo0o * i11iIiiIii + ooo0Oo0 / OOoOoo00oo % i1iiIII111ii
def O0OO0oOoO0O0O ( name , url , iconimage ) :
 if 99 - 99: oOOOo0o0O
 list = I1iIi1iiIIiI ( url )
 if 81 - 81: O0o00 * o0ooo . OOoOoo00oo
 iiiIIiIi = 0
 OOoO000O0OO = open ( IiII , mode = 'r' ) ; OooOOO = OOoO000O0OO . read ( ) ; OOoO000O0OO . close ( )
 OooOOO = OooOOO . replace ( '\n' , '' )
 o0OO00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( OooOOO )
 OoOOO00 = 0
 for I11i1I1I in o0OO00oO :
  if 48 - 48: o0oo0o % ooO % iiIIi1IiIi11 + OOoooooO
  Iiii11iIi1 = re . compile ( '<url>(.+?)</url>' ) . findall ( I11i1I1I ) [ 0 ]
  if 40 - 40: oOOOO % O0o00 . OO00O0O0O00Oo
  if url == Iiii11iIi1 :
   iiiIIiIi = 1
   if 84 - 84: o0ooo % OOoooooO - o0ooo . OOO0O
 for O0o in list :
  name = oOO0000ooooo ( O0o [ "display_name" ] )
  url = oOO0000ooooo ( O0o [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if iiiIIiIi == 1 :
   if 5 - 5: o0ooo * OO00O0O0O00Oo - I1ii / o0oo0o % oOOOo0o0O + i1Ii
   OOoO000O0OO = open ( iI1Ii11111iIi , mode = 'r' ) ; OooOOO = OOoO000O0OO . read ( ) ; OOoO000O0OO . close ( )
   OooOOO = OooOOO . replace ( '\n' , '' )
   o0OO00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( OooOOO )
   for I11i1I1I in o0OO00oO :
    if 51 - 51: OO00O0O0O00Oo * OOoO % OOoooooO
    oO0 = re . compile ( '<name>(.+?)</name>' ) . findall ( I11i1I1I ) [ 0 ]
    if 75 - 75: i1Ii % oOOOO
    OOoOO0O0ooOOO = oO0 . replace ( ' ' , '' )
    o0o00Ooo0o = name . replace ( ' ' , '' )
    if OOoOO0O0ooOOO . lower ( ) in o0o00Ooo0o . lower ( ) :
     oO000Oo000 ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else : oO000Oo000 ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 76 - 76: OOoO
def I1iIi1iiIIiI ( url ) :
 if 26 - 26: OOoO % i11iIiiIii % o0oo0o % oOOOO * oOOOO * I1ii
 IiI1I11iIii = iiiiiIIii ( url )
 IiI1I11iIii = IiI1I11iIii . replace ( '#AAASTREAM:' , '#A:' )
 IiI1I11iIii = IiI1I11iIii . replace ( '#EXTINF:' , '#A:' )
 iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IiI1I11iIii )
 IIiI1 = [ ]
 for i1iI1 , ii1 , url in iIi1Ii1i1iI :
  I1IiiI1ii1i = { "params" : i1iI1 , "display_name" : ii1 , "url" : url }
  IIiI1 . append ( I1IiiI1ii1i )
 list = [ ]
 for O0o in IIiI1 :
  I1IiiI1ii1i = { "display_name" : O0o [ "display_name" ] , "url" : O0o [ "url" ] }
  iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o [ "params" ] )
  for oO0OoO00o , II1iiiiII in iIi1Ii1i1iI :
   I1IiiI1ii1i [ oO0OoO00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = II1iiiiII . strip ( )
  list . append ( I1IiiI1ii1i )
  if 63 - 63: iiIIi1IiIi11 * oOOOO * i1iiIII111ii - oOOOo0o0O - i1iiIII111ii
 return list
 if 97 - 97: OOoOoo00oo / OoI1Ii11I1Ii1i
 if 18 - 18: O0o00 + o0oo0o - OOoO - ooo0Oo0
def oooOOOO0oooo ( ) :
 if 51 - 51: I1II1 - ooO / ooo0Oo0
 oo000OO00Oo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 oo000OO00Oo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 oo000OO00Oo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 oo000OO00Oo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 37 - 37: OOO0O % OOoooooO
def O0II11i11II ( name , url , iconimage ) :
 if 29 - 29: oo % O0o00 % i1Ii . OOO0O / OoI1Ii11I1Ii1i * OOoooooO
 o0OoO000O = datetime . datetime . now ( )
 OOo = o0OoO000O . day
 if 9 - 9: i1iiIII111ii
 OoOO = OOo
 if 44 - 44: OOoOoo00oo
 O0O0o0o0o = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 IIIIIiI = datetime . datetime . strftime ( O0O0o0o0o , '%A - %d %B %Y' )
 Oo0000O0OOooO = 'http://www.predictz.com/predictions/'
 if 54 - 54: oOOOO / ooo0Oo0 * oOOOo0o0O + OoI1Ii11I1Ii1i - iiIIi1IiIi11 / OoI1Ii11I1Ii1i
 I111IIiii1Ii = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 II1iiIIIiIii = datetime . datetime . strftime ( I111IIiii1Ii , '%A - %d %B %Y' )
 I1i11II = datetime . datetime . strftime ( I111IIiii1Ii , '%d' )
 II11 = 'http://www.predictz.com/predictions/tomorrow/'
 if 15 - 15: i1Ii / I1II1 . OOO0O . i11iIiiIii
 o0OO0O0Oo = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 OOOOO = datetime . datetime . strftime ( o0OO0O0Oo , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OOoOOo0O00O = datetime . datetime . strftime ( o0OO0O0Oo , '%y%m%d' )
 iiIii1I = 'http://www.predictz.com/predictions/20' + str ( OOoOOo0O00O )
 if 47 - 47: OOoooooO . oOOOO / OOO0O
 OOoOO = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 OO0OO0OO = datetime . datetime . strftime ( OOoOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ooo = datetime . datetime . strftime ( OOoOO , '%y%m%d' )
 oO0o = 'http://www.predictz.com/predictions/20' + str ( Ooo )
 if 24 - 24: o0ooo % ooO + iiIIi1IiIi11 . i11iIiiIii . I1ii
 IIi1II = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IiiI11i1I = datetime . datetime . strftime ( IIi1II , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OOo0 = datetime . datetime . strftime ( IIi1II , '%y%m%d' )
 iiIii1IIi = 'http://www.predictz.com/predictions/20' + str ( OOo0 )
 if 10 - 10: i11iIiiIii - OOO0O % o0oo0o
 if 49 - 49: oOOOo0o0O
 oo000OO00Oo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IIIIIiI ) + '[/B][/COLOR]' , Oo0000O0OOooO , 41 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( II1iiIIIiIii ) + '[/B][/COLOR]' , II11 , 41 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( OOOOO ) , iiIii1I , 41 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( OO0OO0OO ) , oO0o , 41 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( IiiI11i1I ) , iiIii1IIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 83 - 83: oOOOo0o0O % oo - OOO0O . iiIIi1IiIi11 / oo % I1ii
def OooOo0o0Oo ( name , url , iconimage ) :
 if 71 - 71: o0oo0o - OOoOoo00oo . ooo0Oo0 % OoI1Ii11I1Ii1i + OOoOoo00oo
 i1I1iI = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( i1I1iI )
 O0 = str ( o0OO00oO )
 iII1 = re . compile ( '<tr(.+?)</tr>' ) . findall ( O0 )
 for I11i1I1I in iII1 :
  try :
   oOIIiIi = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( I11i1I1I ) [ 0 ]
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR red][B]' + oOIIiIi + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iiI = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
   IIi11I1 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( I11i1I1I ) [ 0 ]
   iiI = iiiI111I ( iiI )
   IIi11I1 = iiiI111I ( IIi11I1 )
   oO000Oo000 ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + IIi11I1 + ' [/B][/COLOR]| [COLOR mediumpurple]' + iiI + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 75 - 75: OoI1Ii11I1Ii1i % O0o00 / ooo0Oo0
def Oo0ooo0Ooo ( name , url , iconimage ) :
 if 9 - 9: oo
 o0OoO000O = datetime . datetime . now ( )
 OOo = o0OoO000O . day
 if 99 - 99: oOOOO - OO00O0O0O00Oo - oOOOo0o0O % O0o00
 OoOO = OOo
 if 21 - 21: OOoO % I1ii . ooO - OoI1Ii11I1Ii1i
 O0O0o0o0o = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 IIIIIiI = datetime . datetime . strftime ( O0O0o0o0o , '%A - %d %B %Y' )
 Oo0000O0OOooO = 'http://www.predictz.com/predictions/'
 if 4 - 4: OoI1Ii11I1Ii1i . OOoooooO
 I111IIiii1Ii = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 II1iiIIIiIii = datetime . datetime . strftime ( I111IIiii1Ii , '%A - %d %B %Y' )
 I1i11II = datetime . datetime . strftime ( I111IIiii1Ii , '%d' )
 II11 = 'http://www.predictz.com/predictions/tomorrow/'
 if 78 - 78: I1ii + oOOOO - I1II1
 o0OO0O0Oo = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 OOOOO = datetime . datetime . strftime ( o0OO0O0Oo , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OOoOOo0O00O = datetime . datetime . strftime ( o0OO0O0Oo , '%y%m%d' )
 iiIii1I = 'http://www.predictz.com/predictions/20' + str ( OOoOOo0O00O )
 if 10 - 10: OO00O0O0O00Oo % ooo0Oo0
 OOoOO = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 OO0OO0OO = datetime . datetime . strftime ( OOoOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ooo = datetime . datetime . strftime ( OOoOO , '%y%m%d' )
 oO0o = 'http://www.predictz.com/predictions/20' + str ( Ooo )
 if 97 - 97: OoI1Ii11I1Ii1i - OO00O0O0O00Oo
 IIi1II = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IiiI11i1I = datetime . datetime . strftime ( IIi1II , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OOo0 = datetime . datetime . strftime ( IIi1II , '%y%m%d' )
 iiIii1IIi = 'http://www.predictz.com/predictions/20' + str ( OOo0 )
 if 58 - 58: o0oo0o + I1II1
 if 30 - 30: OOoooooO % iiIIi1IiIi11 * OOoOoo00oo - I1ii * i1iiIII111ii % OOoooooO
 oo000OO00Oo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IIIIIiI ) + '[/B][/COLOR]' , Oo0000O0OOooO , 51 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( II1iiIIIiIii ) + '[/B][/COLOR]' , II11 , 51 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( OOOOO ) , iiIii1I , 51 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( OO0OO0OO ) , oO0o , 51 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( IiiI11i1I ) , iiIii1IIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 46 - 46: i11iIiiIii - I1II1 . oOOOo0o0O
def Oo0OIi11 ( name , url , iconimage ) :
 if 8 - 8: oo + OOoO * OOoOoo00oo * o0ooo * oOOOO / i1Ii
 i1I1iI = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( i1I1iI )
 O0 = str ( o0OO00oO )
 iII1 = re . compile ( '<tr(.+?)</tr>' ) . findall ( O0 )
 for I11i1I1I in iII1 :
  try :
   oOIIiIi = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( I11i1I1I ) [ 0 ]
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR red][B]' + oOIIiIi + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iiI = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
   iIii = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
   OO0OoOOO0 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( I11i1I1I ) [ 1 ]
   O00ooOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( I11i1I1I ) [ 2 ]
   iiI = iiiI111I ( iiI )
   oO000Oo000 ( '[COLOR mediumpurple][B]' + iiI + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + iIii + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + OO0OoOOO0 + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + O00ooOo + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 80 - 80: OOO0O - OOoOoo00oo + OoI1Ii11I1Ii1i
def O0ooOoO ( name , url , iconimage ) :
 if 26 - 26: o0ooo / oo - ooO + oOOOO
 o0OoO000O = datetime . datetime . now ( )
 OOo = o0OoO000O . day
 if 38 - 38: OoI1Ii11I1Ii1i / I1ii . I1II1 / ooO / oo + o0oo0o
 OoOO = OOo
 if 96 - 96: iiIIi1IiIi11
 O0O0o0o0o = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 IIIIIiI = datetime . datetime . strftime ( O0O0o0o0o , '%A - %d %B %Y' )
 Oo0000O0OOooO = 'http://www.predictz.com/predictions/'
 if 18 - 18: iiIIi1IiIi11 * oOOOO - i1iiIII111ii
 I111IIiii1Ii = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 II1iiIIIiIii = datetime . datetime . strftime ( I111IIiii1Ii , '%A - %d %B %Y' )
 I1i11II = datetime . datetime . strftime ( I111IIiii1Ii , '%d' )
 II11 = 'http://www.predictz.com/predictions/tomorrow/'
 if 31 - 31: oo - I1II1 % o0ooo % oOOOo0o0O
 o0OO0O0Oo = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 OOOOO = datetime . datetime . strftime ( o0OO0O0Oo , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OOoOOo0O00O = datetime . datetime . strftime ( o0OO0O0Oo , '%y%m%d' )
 iiIii1I = 'http://www.predictz.com/predictions/20' + str ( OOoOOo0O00O )
 if 45 - 45: I1ii + OOoO * i11iIiiIii
 OOoOO = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 OO0OO0OO = datetime . datetime . strftime ( OOoOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ooo = datetime . datetime . strftime ( OOoOO , '%y%m%d' )
 oO0o = 'http://www.predictz.com/predictions/20' + str ( Ooo )
 if 13 - 13: OoI1Ii11I1Ii1i * oOOOo0o0O - i1iiIII111ii / OOoOoo00oo + oOOOO + i1Ii
 IIi1II = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IiiI11i1I = datetime . datetime . strftime ( IIi1II , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OOo0 = datetime . datetime . strftime ( IIi1II , '%y%m%d' )
 iiIii1IIi = 'http://www.predictz.com/predictions/20' + str ( OOo0 )
 if 39 - 39: o0oo0o - OoI1Ii11I1Ii1i
 if 81 - 81: I1ii - I1II1 * OoI1Ii11I1Ii1i
 oo000OO00Oo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IIIIIiI ) + '[/B][/COLOR]' , Oo0000O0OOooO , 61 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( II1iiIIIiIii ) + '[/B][/COLOR]' , II11 , 61 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( OOOOO ) , iiIii1I , 61 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( OO0OO0OO ) , oO0o , 61 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( IiiI11i1I ) , iiIii1IIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 23 - 23: OOoO / oOOOo0o0O
def iII1Iii1I11i ( name , url , iconimage ) :
 if 17 - 17: I1II1
 i1I1iI = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( i1I1iI )
 O0 = str ( o0OO00oO )
 iII1 = re . compile ( '<tr(.+?)</tr>' ) . findall ( O0 )
 for I11i1I1I in iII1 :
  try :
   oOIIiIi = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( I11i1I1I ) [ 0 ]
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR red][B]' + oOIIiIi + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iiI = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
   iiiiiiii1 , iI11i1ii11 = iiI . split ( ' v ' )
   OOooO0o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 0 ]
   ii1iI1iI1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 1 ]
   o00oOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 2 ]
   OoOO0OOoo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 3 ]
   IIIi11IiIiii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 4 ]
   iIi1IIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 5 ]
   I11i11I1iiII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 6 ]
   IiiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 7 ]
   i11ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 8 ]
   i11I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 9 ]
   if 34 - 34: I1II1 * I1II1 % OoI1Ii11I1Ii1i + iiIIi1IiIi11 * o0oo0o % i1iiIII111ii
   if OOooO0o == "W" :
    OOooO0o = '[COLOR lime]W[/COLOR]'
   elif OOooO0o == "D" :
    OOooO0o = '[COLOR yellow]D[/COLOR]'
   else : OOooO0o = '[COLOR red]L[/COLOR]'
   if 25 - 25: oOOOO + o0ooo . OOO0O % o0ooo * OOoOoo00oo
   if ii1iI1iI1 == "W" :
    ii1iI1iI1 = '[COLOR lime]W[/COLOR]'
   elif ii1iI1iI1 == "D" :
    ii1iI1iI1 = '[COLOR yellow]D[/COLOR]'
   else : ii1iI1iI1 = '[COLOR red]L[/COLOR]'
   if 32 - 32: i11iIiiIii - OO00O0O0O00Oo
   if o00oOOO == "W" :
    o00oOOO = '[COLOR lime]W[/COLOR]'
   elif o00oOOO == "D" :
    o00oOOO = '[COLOR yellow]D[/COLOR]'
   else : o00oOOO = '[COLOR red]L[/COLOR]'
   if 53 - 53: OoI1Ii11I1Ii1i - i1Ii
   if OoOO0OOoo == "W" :
    OoOO0OOoo = '[COLOR lime]W[/COLOR]'
   elif OoOO0OOoo == "D" :
    OoOO0OOoo = '[COLOR yellow]D[/COLOR]'
   else : OoOO0OOoo = '[COLOR red]L[/COLOR]'
   if 87 - 87: oOOOo0o0O . ooo0Oo0
   if IIIi11IiIiii == "W" :
    IIIi11IiIiii = '[COLOR lime]W[/COLOR]'
   elif IIIi11IiIiii == "D" :
    IIIi11IiIiii = '[COLOR yellow]D[/COLOR]'
   else : IIIi11IiIiii = '[COLOR red]L[/COLOR]'
   if 17 - 17: i1iiIII111ii . i11iIiiIii
   if iIi1IIiI == "W" :
    iIi1IIiI = '[COLOR lime]W[/COLOR]'
   elif iIi1IIiI == "D" :
    iIi1IIiI = '[COLOR yellow]D[/COLOR]'
   else : iIi1IIiI = '[COLOR red]L[/COLOR]'
   if 5 - 5: I1ii + I1II1 + I1II1 . OO00O0O0O00Oo - OOoooooO
   if I11i11I1iiII == "W" :
    I11i11I1iiII = '[COLOR lime]W[/COLOR]'
   elif I11i11I1iiII == "D" :
    I11i11I1iiII = '[COLOR yellow]D[/COLOR]'
   else : I11i11I1iiII = '[COLOR red]L[/COLOR]'
   if 63 - 63: oOOOo0o0O
   if IiiI == "W" :
    IiiI = '[COLOR lime]W[/COLOR]'
   elif IiiI == "D" :
    IiiI = '[COLOR yellow]D[/COLOR]'
   else : IiiI = '[COLOR red]L[/COLOR]'
   if 71 - 71: ooO . i1iiIII111ii * iiIIi1IiIi11 % OoI1Ii11I1Ii1i + OOoOoo00oo
   if i11ii == "W" :
    i11ii = '[COLOR lime]W[/COLOR]'
   elif i11ii == "D" :
    i11ii = '[COLOR yellow]D[/COLOR]'
   else : i11ii = '[COLOR red]L[/COLOR]'
   if 36 - 36: i1Ii
   if i11I1 == "W" :
    i11I1 = '[COLOR lime]W[/COLOR]'
   elif i11I1 == "D" :
    i11I1 = '[COLOR yellow]D[/COLOR]'
   else : i11I1 = '[COLOR red]L[/COLOR]'
   if 49 - 49: OOoOoo00oo / OoI1Ii11I1Ii1i / ooo0Oo0
   iiiiiiii1 = iiiI111I ( iiiiiiii1 )
   iI11i1ii11 = iiiI111I ( iI11i1ii11 )
   oO000Oo000 ( '[COLOR mediumpurple][B]' + iiiiiiii1 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[B]' + OOooO0o + '  ' + ii1iI1iI1 + '  ' + o00oOOO + '  ' + OoOO0OOoo + '  ' + IIIi11IiIiii + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR mediumpurple][B]' + iI11i1ii11 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[B]' + iIi1IIiI + '  ' + I11i11I1iiII + '  ' + IiiI + '  ' + i11ii + '  ' + i11I1 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 74 - 74: OO00O0O0O00Oo % I1ii
def iiIiI ( name , url , iconimage ) :
 if 38 - 38: i1Ii . i1iiIII111ii
 o0OoO000O = datetime . datetime . now ( )
 OOo = o0OoO000O . day
 if 24 - 24: OOO0O - OOO0O + I1ii + ooo0Oo0 - oOOOo0o0O
 OoOO = OOo
 if 12 - 12: iiIIi1IiIi11 . i1Ii . o0ooo / I1II1
 O0O0o0o0o = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 IIIIIiI = datetime . datetime . strftime ( O0O0o0o0o , '%A - %d %B %Y' )
 Oo0000O0OOooO = 'http://www.predictz.com/predictions/'
 if 58 - 58: OOO0O - OOoO % oOOOo0o0O + OO00O0O0O00Oo . o0ooo / i1Ii
 I111IIiii1Ii = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 II1iiIIIiIii = datetime . datetime . strftime ( I111IIiii1Ii , '%A - %d %B %Y' )
 I1i11II = datetime . datetime . strftime ( I111IIiii1Ii , '%d' )
 II11 = 'http://www.predictz.com/predictions/tomorrow/'
 if 8 - 8: I1ii . O0o00 * oOOOO + OOoO % i11iIiiIii
 o0OO0O0Oo = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 OOOOO = datetime . datetime . strftime ( o0OO0O0Oo , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OOoOOo0O00O = datetime . datetime . strftime ( o0OO0O0Oo , '%y%m%d' )
 iiIii1I = 'http://www.predictz.com/predictions/20' + str ( OOoOOo0O00O )
 if 8 - 8: OOoooooO * I1II1
 OOoOO = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 OO0OO0OO = datetime . datetime . strftime ( OOoOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ooo = datetime . datetime . strftime ( OOoOO , '%y%m%d' )
 oO0o = 'http://www.predictz.com/predictions/20' + str ( Ooo )
 if 73 - 73: OOO0O / oOOOo0o0O / oOOOO / O0o00
 IIi1II = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IiiI11i1I = datetime . datetime . strftime ( IIi1II , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OOo0 = datetime . datetime . strftime ( IIi1II , '%y%m%d' )
 iiIii1IIi = 'http://www.predictz.com/predictions/20' + str ( OOo0 )
 if 11 - 11: o0ooo + i1Ii - OoI1Ii11I1Ii1i / O0o00
 if 34 - 34: OOoooooO
 oo000OO00Oo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IIIIIiI ) + '[/B][/COLOR]' , Oo0000O0OOooO , 71 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( II1iiIIIiIii ) + '[/B][/COLOR]' , II11 , 71 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( OOOOO ) , iiIii1I , 71 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( OO0OO0OO ) , oO0o , 71 , iiiii , O0O0OO0O0O0 , '' )
 oo000OO00Oo ( str ( IiiI11i1I ) , iiIii1IIi , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 45 - 45: OOoooooO / oo / i1iiIII111ii
def IIi11i1II ( name , url , iconimage ) :
 if 73 - 73: OOO0O - ooo0Oo0 * ooO / i11iIiiIii * OOoOoo00oo % OOoO
 i1I1iI = oo0OooOOo0 ( url )
 o0OO00oO = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( i1I1iI )
 O0 = str ( o0OO00oO )
 iII1 = re . compile ( '<tr(.+?)</tr>' ) . findall ( O0 )
 for I11i1I1I in iII1 :
  try :
   oOIIiIi = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( I11i1I1I ) [ 0 ]
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR red][B]' + oOIIiIi + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iiI = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
   iiiiiiii1 , iI11i1ii11 = iiI . split ( ' v ' )
   if 56 - 56: OoI1Ii11I1Ii1i * oo . oo . I1ii
   IIi11I1 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( I11i1I1I ) [ 0 ]
   iIii = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
   OO0OoOOO0 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( I11i1I1I ) [ 1 ]
   O00ooOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( I11i1I1I ) [ 2 ]
   OOooO0o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 0 ]
   ii1iI1iI1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 1 ]
   o00oOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 2 ]
   OoOO0OOoo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 3 ]
   IIIi11IiIiii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 4 ]
   iIi1IIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 5 ]
   I11i11I1iiII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 6 ]
   IiiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 7 ]
   i11ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 8 ]
   i11I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( I11i1I1I ) [ 9 ]
   if 24 - 24: oo . oOOOO * i1iiIII111ii % iiIIi1IiIi11 / OOoOoo00oo
   if OOooO0o == "W" :
    OOooO0o = '[COLOR lime]W[/COLOR]'
   elif OOooO0o == "D" :
    OOooO0o = '[COLOR yellow]D[/COLOR]'
   else : OOooO0o = '[COLOR red]L[/COLOR]'
   if 58 - 58: ooo0Oo0 - I1ii % I1II1 . ooo0Oo0 % O0o00 % i1Ii
   if ii1iI1iI1 == "W" :
    ii1iI1iI1 = '[COLOR lime]W[/COLOR]'
   elif ii1iI1iI1 == "D" :
    ii1iI1iI1 = '[COLOR yellow]D[/COLOR]'
   else : ii1iI1iI1 = '[COLOR red]L[/COLOR]'
   if 87 - 87: oOOOo0o0O - i11iIiiIii
   if o00oOOO == "W" :
    o00oOOO = '[COLOR lime]W[/COLOR]'
   elif o00oOOO == "D" :
    o00oOOO = '[COLOR yellow]D[/COLOR]'
   else : o00oOOO = '[COLOR red]L[/COLOR]'
   if 78 - 78: i11iIiiIii / o0oo0o - OOO0O
   if OoOO0OOoo == "W" :
    OoOO0OOoo = '[COLOR lime]W[/COLOR]'
   elif OoOO0OOoo == "D" :
    OoOO0OOoo = '[COLOR yellow]D[/COLOR]'
   else : OoOO0OOoo = '[COLOR red]L[/COLOR]'
   if 23 - 23: oOOOO
   if IIIi11IiIiii == "W" :
    IIIi11IiIiii = '[COLOR lime]W[/COLOR]'
   elif IIIi11IiIiii == "D" :
    IIIi11IiIiii = '[COLOR yellow]D[/COLOR]'
   else : IIIi11IiIiii = '[COLOR red]L[/COLOR]'
   if 40 - 40: OOO0O - OOoO / oo
   if iIi1IIiI == "W" :
    iIi1IIiI = '[COLOR lime]W[/COLOR]'
   elif iIi1IIiI == "D" :
    iIi1IIiI = '[COLOR yellow]D[/COLOR]'
   else : iIi1IIiI = '[COLOR red]L[/COLOR]'
   if 14 - 14: I1ii
   if I11i11I1iiII == "W" :
    I11i11I1iiII = '[COLOR lime]W[/COLOR]'
   elif I11i11I1iiII == "D" :
    I11i11I1iiII = '[COLOR yellow]D[/COLOR]'
   else : I11i11I1iiII = '[COLOR red]L[/COLOR]'
   if 5 - 5: OOO0O . o0oo0o % o0oo0o
   if IiiI == "W" :
    IiiI = '[COLOR lime]W[/COLOR]'
   elif IiiI == "D" :
    IiiI = '[COLOR yellow]D[/COLOR]'
   else : IiiI = '[COLOR red]L[/COLOR]'
   if 56 - 56: OoI1Ii11I1Ii1i - oOOOO - ooO
   if i11ii == "W" :
    i11ii = '[COLOR lime]W[/COLOR]'
   elif i11ii == "D" :
    i11ii = '[COLOR yellow]D[/COLOR]'
   else : i11ii = '[COLOR red]L[/COLOR]'
   if 8 - 8: OO00O0O0O00Oo / OOoOoo00oo . ooo0Oo0 + I1ii / i11iIiiIii
   if i11I1 == "W" :
    i11I1 = '[COLOR lime]W[/COLOR]'
   elif i11I1 == "D" :
    i11I1 = '[COLOR yellow]D[/COLOR]'
   else : i11I1 = '[COLOR red]L[/COLOR]'
   if 31 - 31: OOoooooO - o0oo0o + iiIIi1IiIi11 . oo / i1Ii % o0oo0o
   iiiiiiii1 = iiiI111I ( iiiiiiii1 )
   iI11i1ii11 = iiiI111I ( iI11i1ii11 )
   iiI = iiiI111I ( iiI )
   IIi11I1 = iiiI111I ( IIi11I1 )
   oO000Oo000 ( '[COLOR blue][B]' + iiI + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + IIi11I1 + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR orange]' + iiiiiiii1 + ' Form: - [/COLOR][B]' + OOooO0o + '  ' + ii1iI1iI1 + '  ' + o00oOOO + '  ' + OoOO0OOoo + '  ' + IIIi11IiIiii + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR orange]' + iI11i1ii11 + ' Form - [/COLOR][B]' + iIi1IIiI + '  ' + I11i11I1iiII + '  ' + IiiI + '  ' + i11ii + '  ' + i11I1 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR orange]' + iiiiiiii1 + ' Win[/COLOR][COLOR dodgerblue][B] (' + iIii + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + OO0OoOOO0 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '[COLOR orange]' + iI11i1ii11 + ' Win[/COLOR][COLOR dodgerblue][B] (' + O00ooOo + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO000Oo000 ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 6 - 6: i1Ii * i11iIiiIii % o0oo0o % i11iIiiIii + OOO0O / ooO
  except : pass
  if 53 - 53: oOOOO + o0oo0o
def oOooo0Oo ( name , url , iconimage ) :
 if 66 - 66: oo
 I1i1IiI1i = [ ]
 IiII1iiI = [ ]
 iII = [ ]
 oO0O000oOoo0O = [ ]
 iIIiii11iIiiI = [ ]
 if 81 - 81: oOOOO / o0oo0o - OOoooooO * OO00O0O0O00Oo . ooo0Oo0 * I1ii
 i1I1iI = oo0OooOOo0 ( 'http://www.livescores.com' )
 o0OO00oO = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( i1I1iI )
 O0 = str ( o0OO00oO )
 iII1 = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( O0 )
 for I11i1I1I in iII1 :
  o0000 = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( I11i1I1I ) [ 0 ]
  i111i1i = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( I11i1I1I ) [ 0 ]
  try :
   IIi11I1 = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( I11i1I1I ) [ 0 ]
  except :
   IIi11I1 = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( I11i1I1I ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( I11i1I1I ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( I11i1I1I ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 19 - 19: OOoO - ooO - OOoOoo00oo / OOoOoo00oo + o0ooo
  if "minute" in time . lower ( ) :
   iIIiii11iIiiI . append ( '3' )
  elif "ht" in time . lower ( ) :
   iIIiii11iIiiI . append ( '3' )
  elif "ft" in time . lower ( ) :
   iIIiii11iIiiI . append ( '2' )
  else : iIIiii11iIiiI . append ( '1' )
  if 51 - 51: oo % o0ooo * OoI1Ii11I1Ii1i . i11iIiiIii
  I1i1IiI1i . append ( o0000 )
  IiII1iiI . append ( i111i1i )
  iII . append ( IIi11I1 )
  oO0O000oOoo0O . append ( time )
  o0 = list ( zip ( iIIiii11iIiiI , I1i1IiI1i , IiII1iiI , iII , oO0O000oOoo0O ) )
  if 77 - 77: OOoO
 iIiiiii1i = sorted ( o0 , key = lambda I1i1I1II : int ( I1i1I1II [ 0 ] ) , reverse = True )
 I1i111IiIiIi1 = 0
 i1II11II1 = 0
 II1IIIii = 0
 for iIIIiIi1I1i , OoOOoO0oOo , O0ooOOOO0O0 , i1IIi1i1Ii1 , Iii in iIiiiii1i :
  if iIIIiIi1I1i == "3" :
   if I1i111IiIiIi1 == 0 :
    oO000Oo000 ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    I1i111IiIiIi1 = 1
  elif iIIIiIi1I1i == "2" :
   if i1II11II1 == 0 :
    oO000Oo000 ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    i1II11II1 = 1
  elif iIIIiIi1I1i == "1" :
   if II1IIIii == 0 :
    oO000Oo000 ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    II1IIIii = 1
  Iii = Iii . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  i1IIi1i1Ii1 = i1IIi1i1Ii1 . replace ( " " , "" )
  oO000Oo000 ( '[COLOR red][B]' + Iii + "[/B][/COLOR]- [COLOR blue]" + i1IIi1i1Ii1 + "[/COLOR] | [COLOR white]" + OoOOoO0oOo + "vs" + O0ooOOOO0O0 + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 63 - 63: i1Ii + OOO0O
def IIII ( ) :
 if 8 - 8: OOO0O / I1ii - i11iIiiIii % o0oo0o
 O0 = ''
 o00o0oOo0O0O = xbmc . Keyboard ( O0 , 'Enter Search Term' )
 o00o0oOo0O0O . doModal ( )
 if o00o0oOo0O0O . isConfirmed ( ) :
  O0 = o00o0oOo0O0O . getText ( )
  if len ( O0 ) > 1 :
   iIi1IIIi1 = O0 + "!" + iiiii
   i1i1IIii1i1 ( "all " + O0 , iIi1IIIi1 , iiiii )
  else : quit ( )
  if 79 - 79: I1ii + OO00O0O0O00Oo
def iIiIIi ( name , url , iconimage ) :
 if 14 - 14: OOO0O / OOoOoo00oo - o0oo0o - oOOOo0o0O % OOoooooO
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 49 - 49: OOoooooO * oOOOo0o0O / OOO0O / oo * o0oo0o
def Ii1IIIIi1ii1I ( text ) :
 if 57 - 57: o0ooo - oOOOo0o0O / OOoooooO % i11iIiiIii
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 3 - 3: iiIIi1IiIi11 . OOoooooO % ooo0Oo0 + I1ii
 return text
 if 64 - 64: ooO
def iiiI111I ( text ) :
 if 29 - 29: OOO0O / i11iIiiIii / ooo0Oo0 % oOOOo0o0O % i11iIiiIii
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 18 - 18: OOoOoo00oo + OO00O0O0O00Oo
 return text
 if 80 - 80: oOOOo0o0O + OOO0O * i1iiIII111ii + O0o00
def II1i ( text ) :
 if 75 - 75: oOOOO / OOO0O / OOoOoo00oo / i1Ii % OOoooooO + OOoO
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 4 - 4: iiIIi1IiIi11 - oo - i1Ii - oOOOO % i11iIiiIii / O0o00
 return text
 if 50 - 50: OOoooooO + ooO
def o0o0O0O00oOOo ( name , url , iconimage ) :
 if 31 - 31: i1iiIII111ii
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 78 - 78: i11iIiiIii + OOO0O + OO00O0O0O00Oo / OOO0O % o0oo0o % i1Ii
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 83 - 83: o0oo0o % o0ooo % OOO0O % OO00O0O0O00Oo . I1ii % I1II1
 iIiIi1ii = url
 iiiiiII = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 iiiiiII . setProperty ( "IsPlayable" , "true" )
 iiiiiII . setPath ( iIiIi1ii )
 xbmc . Player ( ) . play ( iIiIi1ii , iiiiiII , False )
 quit ( )
 if 21 - 21: o0oo0o / OOoO % ooO
def o0OOOO00O0Oo ( ) :
 if 8 - 8: O0o00 + o0ooo . o0oo0o % I1II1
 iI11Ii111 = xbmc . getInfoLabel ( "System.BuildVersion" )
 OOo00OO00Oo = float ( iI11Ii111 [ : 4 ] )
 if OOo00OO00Oo >= 11.0 and OOo00OO00Oo <= 11.9 :
  I1I1I11Ii = 'Eden'
 elif OOo00OO00Oo >= 12.0 and OOo00OO00Oo <= 12.9 :
  I1I1I11Ii = 'Frodo'
 elif OOo00OO00Oo >= 13.0 and OOo00OO00Oo <= 13.9 :
  I1I1I11Ii = 'Gotham'
 elif OOo00OO00Oo >= 14.0 and OOo00OO00Oo <= 14.9 :
  I1I1I11Ii = 'Helix'
 elif OOo00OO00Oo >= 15.0 and OOo00OO00Oo <= 15.9 :
  I1I1I11Ii = 'Isengard'
 elif OOo00OO00Oo >= 16.0 and OOo00OO00Oo <= 16.9 :
  I1I1I11Ii = 'Jarvis'
 elif OOo00OO00Oo >= 17.0 and OOo00OO00Oo <= 17.9 :
  I1I1I11Ii = 'Krypton'
 else : I1I1I11Ii = "Decline"
 if 48 - 48: OoI1Ii11I1Ii1i + oOOOo0o0O % o0oo0o
 return I1I1I11Ii
 if 11 - 11: ooo0Oo0 % i1iiIII111ii - O0o00 - oOOOo0o0O + OOO0O
def oo0OooOOo0 ( url ) :
 if 98 - 98: iiIIi1IiIi11 + i1iiIII111ii - O0o00
 OOo0oOO0o0oo0 = urllib2 . Request ( url )
 OOo0oOO0o0oo0 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 IiI1I11iIii = urllib2 . urlopen ( OOo0oOO0o0oo0 )
 i1I1iI = IiI1I11iIii . read ( )
 IiI1I11iIii . close ( )
 i1I1iI = i1I1iI . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return i1I1iI
 if 78 - 78: OOoOoo00oo + iiIIi1IiIi11 . i1Ii
def iiiiiIIii ( url ) :
 if 91 - 91: o0oo0o . OOO0O . I1ii + OoI1Ii11I1Ii1i
 OOo0oOO0o0oo0 = urllib2 . Request ( url )
 OOo0oOO0o0oo0 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 IiI1I11iIii = urllib2 . urlopen ( OOo0oOO0o0oo0 )
 i1I1iI = IiI1I11iIii . read ( )
 IiI1I11iIii . close ( )
 return i1I1iI
 if 69 - 69: OO00O0O0O00Oo - ooo0Oo0
def oOO0000ooooo ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 95 - 95: ooo0Oo0 * i11iIiiIii . OOoooooO
 if 41 - 41: OOoO
 if 37 - 37: oOOOO . oo % i1Ii * ooO
 if 71 - 71: oo / OOO0O + OOoOoo00oo
 if 48 - 48: OO00O0O0O00Oo + iiIIi1IiIi11
def Iiii1II1iI ( ) :
 if 42 - 42: oOOOo0o0O % OoI1Ii11I1Ii1i + OOO0O
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 56 - 56: OoI1Ii11I1Ii1i + I1ii - iiIIi1IiIi11
 if os . path . exists ( Oooo000o ) == True :
  for III1I1 , ii1111Ii1i , IiI1iiI1III1I in os . walk ( Oooo000o ) :
   Oo000ooo00Oo = 0
   Oo000ooo00Oo += len ( IiI1iiI1III1I )
   if Oo000ooo00Oo > 0 :
    for OOoO000O0OO in IiI1iiI1III1I :
     try :
      if ( OOoO000O0OO . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( III1I1 , OOoO000O0OO ) )
     except :
      pass
    for Iiii1iiiIiI1 in ii1111Ii1i :
     try :
      shutil . rmtree ( os . path . join ( III1I1 , Iiii1iiiIiI1 ) )
     except :
      pass
      if 27 - 27: i1iiIII111ii + ooo0Oo0 * o0oo0o . OoI1Ii11I1Ii1i * o0ooo
   else :
    pass
    if 100 - 100: O0o00 / ooO - ooo0Oo0 % i1iiIII111ii - o0oo0o
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for III1I1 , ii1111Ii1i , IiI1iiI1III1I in os . walk ( IiIi11iIIi1Ii ) :
   Oo000ooo00Oo = 0
   Oo000ooo00Oo += len ( IiI1iiI1III1I )
   if Oo000ooo00Oo > 0 :
    for OOoO000O0OO in IiI1iiI1III1I :
     try :
      if ( OOoO000O0OO . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( III1I1 , OOoO000O0OO ) )
     except :
      pass
    for Iiii1iiiIiI1 in ii1111Ii1i :
     try :
      shutil . rmtree ( os . path . join ( III1I1 , Iiii1iiiIiI1 ) )
     except :
      pass
      if 17 - 17: oOOOO / OOO0O % oo
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  o0o = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 93 - 93: OOoooooO % i11iIiiIii % OO00O0O0O00Oo
  for III1I1 , ii1111Ii1i , IiI1iiI1III1I in os . walk ( o0o ) :
   Oo000ooo00Oo = 0
   Oo000ooo00Oo += len ( IiI1iiI1III1I )
   if 64 - 64: OO00O0O0O00Oo + ooo0Oo0 * I1II1 / oo - oOOOO % oOOOO
   if Oo000ooo00Oo > 0 :
    for OOoO000O0OO in IiI1iiI1III1I :
     os . unlink ( os . path . join ( III1I1 , OOoO000O0OO ) )
    for Iiii1iiiIiI1 in ii1111Ii1i :
     shutil . rmtree ( os . path . join ( III1I1 , Iiii1iiiIiI1 ) )
     if 59 - 59: OOoOoo00oo + OoI1Ii11I1Ii1i
   else :
    pass
  OoooOooooo0 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 66 - 66: oOOOo0o0O * o0oo0o % o0oo0o * i1Ii - OOoooooO - i1Ii
  for III1I1 , ii1111Ii1i , IiI1iiI1III1I in os . walk ( OoooOooooo0 ) :
   Oo000ooo00Oo = 0
   Oo000ooo00Oo += len ( IiI1iiI1III1I )
   if 70 - 70: OO00O0O0O00Oo + oOOOo0o0O
   if Oo000ooo00Oo > 0 :
    for OOoO000O0OO in IiI1iiI1III1I :
     os . unlink ( os . path . join ( III1I1 , OOoO000O0OO ) )
    for Iiii1iiiIiI1 in ii1111Ii1i :
     shutil . rmtree ( os . path . join ( III1I1 , Iiii1iiiIiI1 ) )
     if 93 - 93: OO00O0O0O00Oo + i1iiIII111ii
   else :
    pass
    if 33 - 33: I1II1
 ooo = Ii1I ( )
 if 78 - 78: I1II1 / OOoO * O0o00
 for IiIi1iI11 in ooo :
  iiI1iI1I = xbmc . translatePath ( IiIi1iI11 . path )
  if os . path . exists ( iiI1iI1I ) == True :
   for III1I1 , ii1111Ii1i , IiI1iiI1III1I in os . walk ( iiI1iI1I ) :
    Oo000ooo00Oo = 0
    Oo000ooo00Oo += len ( IiI1iiI1III1I )
    if Oo000ooo00Oo > 0 :
     for OOoO000O0OO in IiI1iiI1III1I :
      os . unlink ( os . path . join ( III1I1 , OOoO000O0OO ) )
     for Iiii1iiiIiI1 in ii1111Ii1i :
      shutil . rmtree ( os . path . join ( III1I1 , Iiii1iiiIiI1 ) )
      if 27 - 27: I1ii * OO00O0O0O00Oo - O0o00 + i1iiIII111ii * i1iiIII111ii
    else :
     pass
     if 55 - 55: OOoooooO
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 82 - 82: OO00O0O0O00Oo - OOoOoo00oo + O0o00
def OO0 ( ) :
 iIiiIi11IIi = [ ]
 Oo0 = sys . argv [ 2 ]
 if len ( Oo0 ) >= 2 :
  i1iI1 = sys . argv [ 2 ]
  oOII1ii1ii11I1 = i1iI1 . replace ( '?' , '' )
  if ( i1iI1 [ len ( i1iI1 ) - 1 ] == '/' ) :
   i1iI1 = i1iI1 [ 0 : len ( i1iI1 ) - 2 ]
  o0ooOO0o = oOII1ii1ii11I1 . split ( '&' )
  iIiiIi11IIi = { }
  for OOooooO0Oo in range ( len ( o0ooOO0o ) ) :
   ooo0 = { }
   ooo0 = o0ooOO0o [ OOooooO0Oo ] . split ( '=' )
   if ( len ( ooo0 ) ) == 2 :
    iIiiIi11IIi [ ooo0 [ 0 ] ] = ooo0 [ 1 ]
 return iIiiIi11IIi
 if 46 - 46: iiIIi1IiIi11 - o0oo0o
def oo000OO00Oo ( name , url , mode , iconimage , fanart , description = '' ) :
 if 50 - 50: iiIIi1IiIi11 / iiIIi1IiIi11 + OOoOoo00oo * OOoooooO / I1ii
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I1IIiiI1II1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 iI1iIiiiI1I1 = True
 iiiiiII = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 iiiiiII . setProperty ( "fanart_Image" , fanart )
 iiiiiII . setProperty ( "icon_Image" , iconimage )
 iI1iIiiiI1I1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1IIiiI1II1 , listitem = iiiiiII , isFolder = True )
 return iI1iIiiiI1I1
 if 78 - 78: oOOOo0o0O / O0o00 - oOOOo0o0O * OoI1Ii11I1Ii1i . o0ooo
def oO000Oo000 ( name , url , mode , iconimage , fanart , description = '' ) :
 if 96 - 96: ooo0Oo0 % ooO . OOO0O . I1II1
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I1IIiiI1II1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 iI1iIiiiI1I1 = True
 iiiiiII = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 iiiiiII . setProperty ( "fanart_Image" , fanart )
 iiiiiII . setProperty ( "icon_Image" , iconimage )
 iI1iIiiiI1I1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1IIiiI1II1 , listitem = iiiiiII , isFolder = False )
 return iI1iIiiiI1I1
 if 37 - 37: ooO - OOoOoo00oo % OoI1Ii11I1Ii1i / OOoOoo00oo % OOoooooO
i1iI1 = OO0 ( ) ; iIi1IIIi1 = None ; iIIIIii1 = None ; iiIiII11i1 = None ; oOo00Ooo0o0 = None ; oO = None ; oo0OOo = None
try : oOo00Ooo0o0 = urllib . unquote_plus ( i1iI1 [ "site" ] )
except : pass
try : iIi1IIIi1 = urllib . unquote_plus ( i1iI1 [ "url" ] )
except : pass
try : iIIIIii1 = urllib . unquote_plus ( i1iI1 [ "name" ] )
except : pass
try : iiIiII11i1 = int ( i1iI1 [ "mode" ] )
except : pass
try : oO = urllib . unquote_plus ( i1iI1 [ "iconimage" ] )
except : pass
try : oo0OOo = urllib . unquote_plus ( i1iI1 [ "fanart" ] )
except : pass
if 33 - 33: oOOOO
if iiIiII11i1 == None or iIi1IIIi1 == None or len ( iIi1IIIi1 ) < 1 : I1I ( )
elif iiIiII11i1 == 1 : i1Iii1i1I ( iIIIIii1 , iIi1IIIi1 )
elif iiIiII11i1 == 2 : o0o0O0O00oOOo ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 3 : I111iI ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 4 : PLAYSD ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 8 : oo00oO0O0 ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 9 : AUTO_UPDATER ( iIIIIii1 )
elif iiIiII11i1 == 10 : O0OO0oOoO0O0O ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 11 : O0o000Oo ( )
elif iiIiII11i1 == 12 : O0OOoOOO0oO ( iIi1IIIi1 )
elif iiIiII11i1 == 19 : o00o000oo ( iIi1IIIi1 )
elif iiIiII11i1 == 20 : i1i1IIii1i1 ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 21 : IiII1 ( iIi1IIIi1 )
elif iiIiII11i1 == 22 : i1iIi ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 23 : Oooo0 ( )
elif iiIiII11i1 == 24 : ooOOoo0oOooo0 ( )
elif iiIiII11i1 == 25 : oOoO ( )
elif iiIiII11i1 == 26 : oooOOOO0oooo ( )
elif iiIiII11i1 == 30 : IiII111i1i11 ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 40 : O0II11i11II ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 41 : OooOo0o0Oo ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 50 : Oo0ooo0Ooo ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 51 : Oo0OIi11 ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 60 : O0ooOoO ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 61 : iII1Iii1I11i ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 70 : iiIiI ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 71 : IIi11i1II ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 80 : oOooo0Oo ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 100 : IIII ( )
elif iiIiII11i1 == 500 : Iiii1II1iI ( )
elif iiIiII11i1 == 201 : II1IIIIiII1i ( )
elif iiIiII11i1 == 202 : i1 ( iIi1IIIi1 )
elif iiIiII11i1 == 203 : iiii1IIi ( iIi1IIIi1 )
elif iiIiII11i1 == 204 : I11I1i1iIII1I ( iIi1IIIi1 )
elif iiIiII11i1 == 205 : Ooo00Oo ( iIi1IIIi1 )
elif iiIiII11i1 == 206 : I1ii1ii11i1I ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 210 : ii1I1i1iiiI ( iIi1IIIi1 )
elif iiIiII11i1 == 220 : oOo0O ( iIi1IIIi1 )
elif iiIiII11i1 == 221 : Oo00o0OO0O00o ( iIIIIii1 , iIi1IIIi1 , oO )
elif iiIiII11i1 == 800 : iIiIIi ( iIIIIii1 , iIi1IIIi1 , oO )
if 87 - 87: o0ooo / i1Ii + o0oo0o
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )