import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
o0oOoO00o = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
i1 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
oOOoo00O0O = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 15 - 15: I11iii11IIi
O00o0o0000o0o = plugintools . get_setting ( "scrape1" )
O0Oo = plugintools . get_setting ( "scrape2" )
oo = plugintools . get_setting ( "scrape3" )
if 33 - 33: I1I1i1 * oO0 / OOo0o0 / OOoOoo00oo - iI1 + OoOooOOOO
i11iiII = o0O + '|SPLIT|' + Oo
checker . check ( i11iiII )
if 34 - 34: oooO % ii1IiIi11 * iIii1I111I11I . O00OooO0 % Ooooo
if not os . path . isfile ( ooo0OO ) :
 plugintools . open_settings_dialog ( )
 if 55 - 55: IiIIIiI1I1
if not os . path . exists ( IiiIII111iI ) :
 os . makedirs ( IiiIII111iI )
 if 86 - 86: i11iIiiIii + ii1IiIi11 + IiIIIiI1I1 * oooO + OOo0o0
if not os . path . isfile ( iI1Ii11111iIi ) :
 oOoO = open ( iI1Ii11111iIi , 'w' )
 if 68 - 68: oO0 . iI1 . i11iIiiIii
if not os . path . isfile ( IiII ) :
 oOoO = open ( IiII , 'w' )
 if 40 - 40: iI1 . oO0 . I11iii11IIi . o00ooo0
if not os . path . isfile ( i1i1II ) :
 oOoO = open ( i1i1II , 'w' )
 if 33 - 33: ii1IiIi11 + o00 % i11iIiiIii . IiIIIiI1I1 - Oo0oO0ooo
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 66 - 66: ii1IiIi11 - I1i1iI1i * I1i1iI1i . OoOooOOOO . OOoOoo00oo
class IiI1i11iii1 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 96 - 96: o0OO0 % iI1 % Oo0ooO0oo0oO
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 78 - 78: Oo0ooO0oo0oO - ii1IiIi11 * I1I1i1 + OOo0o0 + iIii1I111I11I + iIii1I111I11I
I11I11i1I = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 49 - 49: o00 % iIii1I111I11I * o0OO0
class oOOo0oo :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 80 - 80: oooO * i11iIiiIii / Ooooo
  if 9 - 9: ii1IiIi11 + iI1 % ii1IiIi11 + o00ooo0 . OoOooOOOO
  if 31 - 31: OOo0o0 + oooO + oooO / o00
  if 26 - 26: I1i1iI1i
def IiiI11Iiiii ( ) :
 ii1I1i1I = 5
 OOoo0O0 = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 iiiIi1i1I = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 80 - 80: oO0 - I1I1i1
 OOO00 = [ ]
 if 21 - 21: I1i1iI1i - I1i1iI1i
 for iIii11I in range ( ii1I1i1I ) :
  OOO00 . append ( oOOo0oo ( OOoo0O0 [ iIii11I ] , iiiIi1i1I [ iIii11I ] ) )
  if 69 - 69: iI1 % Ooooo - OOo0o0 + Ooooo - o0OO0 % I1i1iI1i
 return OOO00
 if 31 - 31: o00 - OoOooOOOO . Ooooo % oO0 - o0OO0
def iii11 ( ) :
 if 58 - 58: OoOooOOOO * i11iIiiIii / oO0 % Ooooo - OOoOoo00oo / iI1
 ii11i1 = IIIii1II1II ( i1 )
 if len ( ii11i1 ) > 1 :
  i1I1iI = iI1Ii11111iIi
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 83 - 83: OOoOoo00oo / IiIIIiI1I1
 ii11i1 = IIIii1II1II ( o0oOoO00o )
 if len ( ii11i1 ) > 1 :
  i1I1iI = IiII
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 49 - 49: OOo0o0
 ii11i1 = IIIii1II1II ( oOOoo00O0O )
 if len ( ii11i1 ) > 1 :
  i1I1iI = i1i1II
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 35 - 35: oO0 - I1i1iI1i / OOoOoo00oo % o00ooo0
 o00OO00OoO = OOOO0OOoO0O0 ( II1 )
 o00OO00OoO = base64 . b64decode ( o00OO00OoO )
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 62 - 62: Oo0ooO0oo0oO * oO0
  if '<search>ZGlzcGxheQ==</search>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   Oo0oOOo ( i1OOO , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 58 - 58: o00 * OoOooOOOO * OOoOoo00oo / OoOooOOOO
  elif '<vip>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   Oo0oOOo ( i1OOO , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 75 - 75: iI1
  elif '<divider>bnVsbA==</divider>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( i1OOO , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 63 - 63: OoOooOOOO % iI1 * iI1 * I1I1i1 / OOoOoo00oo
   if 74 - 74: o00
   if 75 - 75: OOo0o0 . IiIIIiI1I1
   if 54 - 54: o00 % oO0 % oooO % Oo0ooO0oo0oO + Oo0ooO0oo0oO * IiIIIiI1I1
   if 87 - 87: IiIIIiI1I1 * I11iii11IIi % i11iIiiIii % oO0 - OoOooOOOO
   if 68 - 68: Ooooo % o00ooo0 . O00OooO0 . OOoOoo00oo
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   Oo0oOOo ( i1OOO , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 92 - 92: iIii1I111I11I . Ooooo
   if 31 - 31: Ooooo . oO0 / o0OO0
   if 89 - 89: oO0
   if 68 - 68: I1I1i1 * I1i1iI1i % o0OO0 + I1I1i1 + IiIIIiI1I1
   if 4 - 4: IiIIIiI1I1 + o0OO0 * OoOooOOOO
   if 55 - 55: I11iii11IIi + Oo0ooO0oo0oO / oO0 * iI1 - i11iIiiIii - ii1IiIi11
   if 25 - 25: OOoOoo00oo
   if 7 - 7: o00ooo0 / Oo0oO0ooo * Ooooo . O00OooO0 . Oo0ooO0oo0oO
   if 13 - 13: OoOooOOOO / i11iIiiIii
   if 2 - 2: Oo0oO0ooo / o0OO0 / OOo0o0 % oO0 % ii1IiIi11
   if 52 - 52: OOo0o0
   if 95 - 95: ii1IiIi11
   if 87 - 87: IiIIIiI1I1 + oO0 . OoOooOOOO + oO0
   if 91 - 91: o0OO0
   if 61 - 61: o00
   if 64 - 64: IiIIIiI1I1 / oO0 - o0OO0 - oooO
   if 86 - 86: oooO % oO0 / Oo0oO0ooo / oO0
   if 42 - 42: I1I1i1
   if 67 - 67: Ooooo . iIii1I111I11I . o0OO0
   if 10 - 10: OOoOoo00oo % OOoOoo00oo - Oo0ooO0oo0oO / OoOooOOOO + ii1IiIi11
   if 87 - 87: iI1 * OOoOoo00oo + OoOooOOOO / Oo0ooO0oo0oO / iIii1I111I11I
   if 37 - 37: iIii1I111I11I - IiIIIiI1I1 * iI1 % i11iIiiIii - Ooooo
  elif '<sportsdevil>' in oO0Ii1iIiII1ii1 :
   o0oO = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1IiiiI1iI = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1iIi = re . compile ( '<referer>(.+?)</referer>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = base64 . b64decode ( i1OOO )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    i1IiiiI1iI = base64 . b64decode ( i1IiiiI1iI )
    i1iIi = base64 . b64decode ( i1iIi )
    ooOOoooooo = i1iIi
    II1I = "/"
    if not ooOOoooooo . endswith ( II1I ) :
     O0 = ooOOoooooo + "/"
    else :
     O0 = ooOOoooooo
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( i1OOO ) + '%26url=' + i1IiiiI1iI
    i1IiiiI1iI = o00OO00OoO + '%26referer=' + O0
    I1III ( i1OOO , i1IiiiI1iI , 4 , IIiIi1iI , i1II1Iiii1I11 )
   elif len ( o0oO ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = base64 . b64decode ( i1OOO )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    I1III ( i1OOO , url2 + 'NOTPLAY' , 8 , IIiIi1iI , i1II1Iiii1I11 )
    if 9 - 9: OOoOoo00oo / I11iii11IIi - Oo0oO0ooo / I1i1iI1i / Oo0ooO0oo0oO - OOo0o0
  elif '<folder>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for i1OOO , i1IiiiI1iI , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    i1OOO = base64 . b64decode ( i1OOO )
    i1IiiiI1iI = base64 . b64decode ( i1IiiiI1iI )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
    Oo0oOOo ( i1OOO , i1IiiiI1iI , 1 , IIiIi1iI , i1II1Iiii1I11 )
  elif '<m3u>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for i1OOO , i1IiiiI1iI , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    i1OOO = base64 . b64decode ( i1OOO )
    i1IiiiI1iI = base64 . b64decode ( i1IiiiI1iI )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
    Oo0oOOo ( i1OOO , i1IiiiI1iI , 10 , IIiIi1iI , i1II1Iiii1I11 )
  else :
   o0oO = re . compile ( '<link>(.+?)</link>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
    o0O0OOO0Ooo = len ( O0Oo000ooO00 )
    for i1OOO , i1IiiiI1iI , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
     i1OOO = base64 . b64decode ( i1OOO )
     i1IiiiI1iI = base64 . b64decode ( i1IiiiI1iI )
     IIiIi1iI = base64 . b64decode ( IIiIi1iI )
     i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
     I1III ( i1OOO , i1IiiiI1iI , 2 , IIiIi1iI , i1II1Iiii1I11 )
   elif len ( o0oO ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = base64 . b64decode ( i1OOO )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
    I1III ( i1OOO , II1 , 3 , IIiIi1iI , i1II1Iiii1I11 )
    if 45 - 45: o0OO0 / OOo0o0
 i1IIIII11I1IiI = open ( IIi1IiiiI1Ii ) . read ( )
 i1I = i1IIIII11I1IiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0Oo000ooO00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( i1I ) )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  OoOO = float ( oO0Ii1iIiII1ii1 )
 i1IIIII11I1IiI = open ( I11i11Ii ) . read ( )
 i1I = i1IIIII11I1IiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0Oo000ooO00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( i1I ) )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  ooOOO0 = float ( oO0Ii1iIiII1ii1 )
  if 65 - 65: o0OO0
 I1III ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( OoOO ) + "[/COLOR]" , 'url' , 999 , iiiii , i1II1Iiii1I11 , '' )
 I1III ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( ooOOO0 ) + "[/COLOR]" , 'url' , 999 , iiiii , i1II1Iiii1I11 , '' )
 if 68 - 68: OoOooOOOO % Ooooo
 ooO00OO0 = i11111IIIII ( )
 if 19 - 19: oO0 * o00ooo0
 if ooO00OO0 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif ooO00OO0 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 14 - 14: iIii1I111I11I
def I1iI1iIi111i ( name , url ) :
 if 44 - 44: o00ooo0 % o00 + oooO
 hash = [ ]
 I1I1I = url
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 if 95 - 95: o00 + OOo0o0 + iIii1I111I11I * Oo0ooO0oo0oO % iI1 / O00OooO0
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 56 - 56: iIii1I111I11I
  if '<search>' in oO0Ii1iIiII1ii1 :
   if 86 - 86: o00 % Ooooo
   o0oO = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    url = name + "!" + url + "!" + IIiIi1iI
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    Oo0oOOo ( name , url , 20 , IIiIi1iI , IIiIi1iI )
    if 15 - 15: o00ooo0 * Oo0oO0ooo + i11iIiiIii
   elif len ( o0oO ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    url = I1I1I + "!" + name + "!" + IIiIi1iI
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    Oo0oOOo ( name , url , 22 , IIiIi1iI , IIiIi1iI )
    if 6 - 6: IiIIIiI1I1 / i11iIiiIii + iIii1I111I11I * iI1
  elif '<regex>' in oO0Ii1iIiII1ii1 :
   o00o0 = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( oO0Ii1iIiII1ii1 )
   o00o0 = '' . join ( o00o0 )
   ii = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( o00o0 )
   o00o0 = urllib . quote_plus ( o00o0 )
   if 84 - 84: OOo0o0 % o00 . i11iIiiIii / I1I1i1
   o0OIiII = hashlib . md5 ( )
   for ii1iII1II in o00o0 : o0OIiII . update ( str ( ii1iII1II ) )
   o0OIiII = str ( o0OIiII . hexdigest ( ) )
   if 48 - 48: o00 * ii1IiIi11 . oooO + iI1
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   oO0Ii1iIiII1ii1 = re . sub ( '<regex>.+?</regex>' , '' , oO0Ii1iIiII1ii1 )
   oO0Ii1iIiII1ii1 = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , oO0Ii1iIiII1ii1 )
   oO0Ii1iIiII1ii1 = re . sub ( '<link></link>' , '' , oO0Ii1iIiII1ii1 )
   if 78 - 78: i11iIiiIii / iIii1I111I11I - ii1IiIi11 / OoOooOOOO + iI1
   name = re . sub ( '<meta>.+?</meta>' , '' , oO0Ii1iIiII1ii1 )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 82 - 82: ii1IiIi11
   try : iiI1Ii1iI1 = re . findall ( '<date>(.+?)</date>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : iiI1Ii1iI1 = ''
   if re . search ( r'\d+' , iiI1Ii1iI1 ) : name += ' [COLOR red] Updated %s[/COLOR]' % iiI1Ii1iI1
   if 87 - 87: I11iii11IIi . O00OooO0
   try : O0OO0O = re . findall ( '<thumbnail>(.+?)</thumbnail>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : O0OO0O = iiiii
   if 81 - 81: iI1 . OOo0o0 % o0OO0 / Oo0oO0ooo - iI1
   try : Ii1I1i = re . findall ( '<fanart>(.+?)</fanart>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : Ii1I1i = O0O0OO0O0O0
   if 99 - 99: iI1 . iIii1I111I11I + IiIIIiI1I1 % iI1 . i11iIiiIii % o0OO0
   try : oOO00O = re . findall ( '<meta>(.+?)</meta>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : oOO00O = '0'
   if 77 - 77: I11iii11IIi - o00ooo0 - oooO . oO0
   try : url = re . findall ( '<link>(.+?)</link>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % oOO00O )
   url = '<preset>search</preset>%s' % oOO00O if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % oOO00O )
   url = '<preset>searchsd</preset>%s' % oOO00O if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 39 - 39: o00 / IiIIIiI1I1 + Ooooo / oO0
   if not o00o0 == '' :
    hash . append ( { 'regex' : o0OIiII , 'response' : o00o0 } )
    url += '|regex=%s' % o00o0
    if 13 - 13: O00OooO0 + o0OO0 + iIii1I111I11I % Oo0oO0ooo / OOo0o0 . O00OooO0
   I1III ( name , url , 30 , O0OO0O , Ii1I1i )
   if 86 - 86: iI1 * OOo0o0 % o00ooo0 . ii1IiIi11 . i11iIiiIii
  elif '<sportsdevil>' in oO0Ii1iIiII1ii1 :
   o0oO = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     i1iIi = re . compile ( '<referer>(.+?)</referer>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : i1iIi = "None"
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : i1II1Iiii1I11 = O0O0OO0O0O0
    ooOOoooooo = i1iIi
    II1I = "/"
    if not ooOOoooooo . endswith ( II1I ) :
     O0 = ooOOoooooo + "/"
    else :
     O0 = ooOOoooooo
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = o00OO00OoO + '%26referer=' + O0
    I1III ( name , url , 2 , IIiIi1iI , i1II1Iiii1I11 )
    if 56 - 56: OOoOoo00oo % o0OO0 - Oo0oO0ooo
   elif len ( o0oO ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : i1II1Iiii1I11 = O0O0OO0O0O0
    I1III ( name , I1I1I + 'NOTPLAY' , 8 , IIiIi1iI , i1II1Iiii1I11 )
    if 100 - 100: ii1IiIi11 - o0OO0 % iI1 * OoOooOOOO + Oo0oO0ooo
  elif '<folder>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for name , url , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    Oo0oOOo ( name , url , 1 , IIiIi1iI , i1II1Iiii1I11 )
    if 88 - 88: I1i1iI1i - I1I1i1 * o0OO0 * I1i1iI1i . I1i1iI1i
  elif '<m3u>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for name , url , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    Oo0oOOo ( name , url , 10 , IIiIi1iI , i1II1Iiii1I11 )
    if 33 - 33: Ooooo + iIii1I111I11I * iI1 / Oo0ooO0oo0oO - Oo0oO0ooo
  else :
   o0oO = re . compile ( '<link>(.+?)</link>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
    o0O0OOO0Ooo = len ( O0Oo000ooO00 )
    for name , url , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
     I1III ( name , url , 2 , IIiIi1iI , i1II1Iiii1I11 )
   elif len ( o0oO ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : i1II1Iiii1I11 = O0O0OO0O0O0
    I1III ( name , I1I1I , 3 , IIiIi1iI , i1II1Iiii1I11 )
    if 54 - 54: Ooooo / OoOooOOOO . iI1 % iIii1I111I11I
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 57 - 57: i11iIiiIii . OOoOoo00oo - ii1IiIi11 - iI1 + oO0
def oO00oooOOoOo0 ( name , url , iconimage ) :
 OoOOoOooooOOo = [ ]
 oOo0O = [ ]
 oo0O0 = [ ]
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iI = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iI ) [ 0 ]
 o0oO = re . compile ( '<link>(.+?)</link>' ) . findall ( iI )
 ii1iII1II = 1
 for OO0O000 in o0oO :
  iiIiI1i1 = OO0O000
  if '(' in OO0O000 :
   OO0O000 = OO0O000 . split ( '(' ) [ 0 ]
   oO0O00oOOoooO = str ( iiIiI1i1 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   OoOOoOooooOOo . append ( OO0O000 )
   oOo0O . append ( oO0O00oOOoooO )
  else :
   OoOOoOooooOOo . append ( OO0O000 )
   oOo0O . append ( 'Link ' + str ( ii1iII1II ) )
  ii1iII1II = ii1iII1II + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 IiIi11iI = O00ooooo00 . select ( name , oOo0O )
 if IiIi11iI < 0 :
  quit ( )
 else :
  url = OoOOoOooooOOo [ IiIi11iI ]
  print url
  if 83 - 83: o00 % I11iii11IIi % IiIIIiI1I1 % OOoOoo00oo
 url = OoOOoOooooOOo [ IiIi11iI ]
 name = oOo0O [ IiIi11iI ]
 OoO000O0Oo ( name , url , iiiii )
 if 63 - 63: Oo0ooO0oo0oO * i11iIiiIii % Oo0ooO0oo0oO * i11iIiiIii
def iI1111iiii ( name , url , iconimage ) :
 if 67 - 67: I1i1iI1i / Oo0oO0ooo * ii1IiIi11 + oooO
 OoOOoOooooOOo = [ ]
 oOo0O = [ ]
 oo0O0 = [ ]
 OooOo0ooo = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iI = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 o0oO = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iI )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iI ) [ 0 ]
 if 71 - 71: Ooooo + ii1IiIi11
 iI1111ii1I = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 45 - 45: o00ooo0 + OOo0o0
 ii1iII1II = 1
 if 94 - 94: iI1 . o00ooo0 - OOo0o0 % o0OO0 - I1I1i1
 for OO0O000 in o0oO :
  iiIiI1i1 = OO0O000
  if '(' in OO0O000 :
   OO0O000 = OO0O000 . split ( '(' ) [ 0 ]
   oO0O00oOOoooO = str ( iiIiI1i1 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   OoOOoOooooOOo . append ( OO0O000 )
   oOo0O . append ( oO0O00oOOoooO )
   OooOo0ooo . append ( 'Stream ' + str ( ii1iII1II ) )
  else :
   OoOOoOooooOOo . append ( OO0O000 )
   oOo0O . append ( 'Link ' + str ( ii1iII1II ) )
   if 72 - 72: ii1IiIi11
  ii1iII1II = ii1iII1II + 1
  if 1 - 1: I1I1i1 * O00OooO0 * I1i1iI1i + IiIIIiI1I1
 name = '[COLOR red]' + name + '[/COLOR]'
 if 33 - 33: o0OO0 * OOo0o0 - Ooooo % Ooooo
 O00ooooo00 = xbmcgui . Dialog ( )
 IiIi11iI = O00ooooo00 . select ( name , oOo0O )
 if IiIi11iI < 0 :
  quit ( )
 else :
  ooOOoooooo = oOo0O [ IiIi11iI ]
  II1I = "/"
  if not ooOOoooooo . endswith ( II1I ) :
   O0 = ooOOoooooo + "/"
  else :
   O0 = ooOOoooooo
  url = iI1111ii1I + OoOOoOooooOOo [ IiIi11iI ] + "%26referer=" + O0
  if 18 - 18: Ooooo / I11iii11IIi * Ooooo + Ooooo * i11iIiiIii * OOoOoo00oo
 name = oOo0O [ IiIi11iI ]
 OoO000O0Oo ( name , url , iiiii )
 if 11 - 11: IiIIIiI1I1 / oO0 - O00OooO0 * I1i1iI1i + I1i1iI1i . oO0
def i1I1i111Ii ( name , url , iconimage ) :
 if 67 - 67: Oo0oO0ooo . o00ooo0
 oo0OooOOo0 , iIii11I = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 oo0OooOOo0 += urllib . unquote_plus ( iIii11I )
 url = regex . resolve ( oo0OooOOo0 )
 if 27 - 27: IiIIIiI1I1 % Oo0oO0ooo
 OoO000O0Oo ( name , url , iconimage )
 if 73 - 73: OoOooOOOO
def ooO ( ) :
 if 51 - 51: Oo0oO0ooo % Ooooo . iI1 / Oo0ooO0oo0oO / oooO . iI1
 I1III ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 I1III ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 I1III ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 Oo0oOOo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 Oo0oOOo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 42 - 42: OOo0o0 + o00ooo0 - ii1IiIi11 / O00OooO0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 9 - 9: o0OO0 % o0OO0 - OOo0o0
def OoO ( ) :
 if 12 - 12: o0OO0 - OOo0o0
 Oo0oOOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 81 - 81: oO0 - oO0 . iIii1I111I11I
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 73 - 73: oooO % i11iIiiIii - Oo0oO0ooo
def Ii1iI111II1I1 ( ) :
 if 91 - 91: OoOooOOOO % OoOooOOOO - Oo0oO0ooo
 Oo0oOOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 18 - 18: oooO - i11iIiiIii / o00 . OoOooOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 55 - 55: o00ooo0 % o00 + oooO * Oo0ooO0oo0oO
def o0ooooO0o0O ( ) :
 if 24 - 24: o0OO0 * OOo0o0
 ii1iII1II = 0
 IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  ii1iII1II = ii1iII1II + 1
  oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1IiiiI1iI = oO0Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ii1iII1II ) + '[/COLOR]' , i1IiiiI1iI , 12 , iiiii , O0O0OO0O0O0 )
  if 7 - 7: Ooooo * I1I1i1 - IiIIIiI1I1 + OoOooOOOO * Oo0oO0ooo % I1I1i1
 IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  ii1iII1II = ii1iII1II + 1
  oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1IiiiI1iI = oO0Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ii1iII1II ) + '[/COLOR]' , i1IiiiI1iI , 12 , iiiii , O0O0OO0O0O0 )
  if 15 - 15: oO0 % Oo0oO0ooo * oooO
 IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  ii1iII1II = ii1iII1II + 1
  oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1IiiiI1iI = oO0Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ii1iII1II ) + '[/COLOR]' , i1IiiiI1iI , 12 , iiiii , O0O0OO0O0O0 )
  if 81 - 81: IiIIIiI1I1 - Oo0ooO0oo0oO - o00ooo0 / Ooooo - o0OO0 * oooO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 20 - 20: iI1 % O00OooO0
def III1i1i11i ( url ) :
 if 100 - 100: iI1 / Ooooo / OOoOoo00oo
 IiI1iiiIii = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
 if 78 - 78: I11iii11IIi - OOo0o0 / oO0
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  IIiIi1iI = re . compile ( '<img.+?src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , IIiIi1iI , O0O0OO0O0O0 )
  if 10 - 10: iIii1I111I11I + I11iii11IIi * OOoOoo00oo + Oo0ooO0oo0oO / Ooooo / OOoOoo00oo
 try :
  iI1II = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( IiI1iiiIii ) [ 0 ]
  Oo0oOOo ( '[COLOR yellow]Next Page -->[/COLOR]' , iI1II , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 69 - 69: IiIIIiI1I1 % iI1
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 50 - 50: I1i1iI1i % oooO
def IIii1111 ( url ) :
 if 42 - 42: oooO / OOo0o0 . iI1 + iI1 % oO0 + i11iIiiIii
 IiI1iiiIii = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( IiI1iiiIii )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  try :
   i1OOO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except :
   i1OOO = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 56 - 56: OOo0o0
def I1 ( url ) :
 if 68 - 68: Oo0ooO0oo0oO * Oo0ooO0oo0oO . OOo0o0 / o00 % I11iii11IIi
 IiI1iiiIii = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( IiI1iiiIii )
 i1i11I11 = 0
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  try :
   i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<img.+?src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except : i1i11I11 = 1
  if 10 - 10: o0OO0 - I1i1iI1i . oO0
  if i1i11I11 == 0 :
   Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , IIiIi1iI , O0O0OO0O0O0 )
  i1i11I11 = 0
  if 44 - 44: O00OooO0 - OOo0o0 . o00ooo0 . O00OooO0 * oO0
 try :
  iI1II = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( IiI1iiiIii ) [ 0 ]
  Oo0oOOo ( '[COLOR yellow]Next Page -->[/COLOR]' , iI1II , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 5 - 5: Ooooo
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 90 - 90: Ooooo . IiIIIiI1I1 / ii1IiIi11 - oooO
def ii1 ( url ) :
 if 39 - 39: ii1IiIi11 / IiIIIiI1I1 . OOo0o0 % o0OO0 * iIii1I111I11I + Oo0oO0ooo
 O0oo0O = datetime . date . today ( )
 I1IiI11 = datetime . datetime . strftime ( O0oo0O , '%A %d %B %Y' )
 if 9 - 9: oooO
 I1III ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( I1IiI11 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 64 - 64: Oo0ooO0oo0oO / Oo0oO0ooo . o00 + I1i1iI1i . I1I1i1
 IiI1iiiIii = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( IiI1iiiIii )
 i1i11I11 = 0
 ii1iII1II = 0
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  try :
   oO = re . compile ( 'title="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   try :
    IIiIi = re . compile ( '<p>(.+?)</p>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   except : IIiIi = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<img src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except : i1i11I11 = 1
  if 91 - 91: OOoOoo00oo * I11iii11IIi / Oo0oO0ooo . o0OO0 + I1I1i1 + oO0
  if i1i11I11 == 0 :
   if 'vs' in oO :
    i1OOO = '[COLOR dodgerblue]' + oO + ' - ' + '[/COLOR][COLOR green]' + IIiIi + '[/COLOR]'
    ii1iII1II = ii1iII1II + 1
    I1III ( i1OOO , url , 206 , IIiIi1iI , O0O0OO0O0O0 , '' )
  i1i11I11 = 0
  if 8 - 8: iI1 / OOoOoo00oo
 if ii1iII1II == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 20 - 20: Oo0oO0ooo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 95 - 95: iIii1I111I11I - Oo0oO0ooo
def I1ii1ii11i1I ( name , url , iconimage ) :
 if 58 - 58: iIii1I111I11I + I11iii11IIi
 IiI1iiiIii = OOOO0OOoO0O0 ( url )
 II1I1I1Ii = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( IiI1iiiIii ) [ 0 ]
 if 70 - 70: I1I1i1 % iI1 + OoOooOOOO / ii1IiIi11 % o0OO0
 if not "http" in II1I1I1Ii :
  II1I1I1Ii = II1I1I1Ii . replace ( "//" , "" )
  url = "http://" + II1I1I1Ii
 else :
  url = II1I1I1Ii
  if 100 - 100: OOo0o0 + OoOooOOOO * OOo0o0
 oOOo0OOOo00O = url
 if 76 - 76: i11iIiiIii + OOo0o0 / OOoOoo00oo - I1I1i1 - ii1IiIi11 + OOoOoo00oo
 ooI1i = OOOO0OOoO0O0 ( url )
 II1I1I1Ii = re . compile ( "atob(.+?)," ) . findall ( ooI1i ) [ 0 ]
 II1I1I1Ii = II1I1I1Ii . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( II1I1I1Ii )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + oOOo0OOOo00O + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 OoO000O0Oo ( name , url , iconimage )
 if 32 - 32: oO0 / I1I1i1 + OoOooOOOO
def ii1I1i1iiiI ( url ) :
 if 96 - 96: I1i1iI1i + iI1
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 44 - 44: iI1
  if '<display>eWVz</display>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   url = base64 . b64decode ( url )
   IIiIi1iI = base64 . b64decode ( IIiIi1iI )
   i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
   Oo0oOOo ( i1OOO , url , 220 , IIiIi1iI , i1II1Iiii1I11 , '' )
   if 20 - 20: oooO + ii1IiIi11 / o0OO0 % Oo0ooO0oo0oO
def oOo0OOOO0O00oO ( url ) :
 if 9 - 9: Oo0ooO0oo0oO
 IiI1iiiIii = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( IiI1iiiIii )
 if 31 - 31: OOo0o0 % I1I1i1
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  i1OOO = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  try :
   iI1I = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except : iI1I = "SD"
  iI1I = '[COLOR yellow]' + iI1I + '[/COLOR]'
  IIiIi1iI = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  i1OOO = i1OOO . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 100 - 100: Oo0ooO0oo0oO + oO0 / I11iii11IIi . i11iIiiIii
  I1III ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR] - ' + iI1I , url , 212 , IIiIi1iI , O0O0OO0O0O0 , '' )
  if 14 - 14: OOo0o0 * OoOooOOOO + iIii1I111I11I + o0OO0 + i11iIiiIii
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( IiI1iiiIii ) [ 0 ]
  oOoO0 = 'http://www.fmovies.se/' + url
  Oo0oOOo ( "Next Page -->" , oOoO0 , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 77 - 77: Oo0ooO0oo0oO . iIii1I111I11I % iIii1I111I11I + i11iIiiIii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 72 - 72: Oo0ooO0oo0oO * ii1IiIi11 % IiIIIiI1I1 / I1I1i1
def I11i1II ( url ) :
 if 72 - 72: Oo0ooO0oo0oO . o00ooo0 / I11iii11IIi . o00
 IiI1iiiIii = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( IiI1iiiIii )
 if 54 - 54: o00 % o00
 if 86 - 86: o0OO0 % ii1IiIi11 * IiIIIiI1I1 * Oo0ooO0oo0oO * o00ooo0 * oooO
def OOOoOOO0oO ( url ) :
 if 28 - 28: IiIIIiI1I1 + i11iIiiIii / oooO % oO0 % I11iii11IIi - o0OO0
 if "iptvembed" in url :
  IiI1iiiIii = OOOO0OOoO0O0 ( url )
  O0Oo000ooO00 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( IiI1iiiIii )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = oO0Ii1iIiII1ii1
   if 54 - 54: o00ooo0 + o00
 if "sourcetv" in url :
  IiI1iiiIii = OOOO0OOoO0O0 ( url )
  O0Oo000ooO00 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( IiI1iiiIii )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = oO0Ii1iIiII1ii1
   if 83 - 83: OOoOoo00oo - Oo0oO0ooo + OoOooOOOO
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 IIiI1 = [ ]
 for i1iI1 , ii1I1IiiI1ii1i , url in iIi1Ii1i1iI :
  O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : url }
  IIiI1 . append ( O0o )
 list = [ ]
 for oO0OoO00o in IIiI1 :
  O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
  iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
  for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
   O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
  list . append ( O0o )
  if 96 - 96: oO0 . OOo0o0 - IiIIIiI1I1
 O0O = 0
 for oO0OoO00o in list :
  O0O = 1
  i1OOO = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
  url = I11iiiii1II ( oO0OoO00o [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   I1III ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   Oo0oOOo ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 51 - 51: o0OO0 % iI1 - o00
 if O0O == 0 :
  I1III ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 31 - 31: iIii1I111I11I / I11iii11IIi - iIii1I111I11I - OoOooOOOO
def I1iiIIIi11 ( url ) :
 if 12 - 12: I1i1iI1i % OOo0o0 * oooO % Oo0ooO0oo0oO / ii1IiIi11
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I1I1I = url
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 27 - 27: i11iIiiIii % o00 % oooO . o0OO0 - I11iii11IIi + oO0
  o0oO = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 )
  if len ( o0oO ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + IIiIi1iI
   i1OOO = '[COLOR mediumpurple]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 20 , IIiIi1iI , IIiIi1iI )
   if 57 - 57: Oo0ooO0oo0oO / oooO - o00ooo0
  elif len ( o0oO ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = I1I1I + "!" + i1OOO + "!" + IIiIi1iI
   i1OOO = '[COLOR mediumpurple]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 22 , IIiIi1iI , IIiIi1iI )
   if 51 - 51: O00OooO0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 25 - 25: I1i1iI1i + O00OooO0 * OOoOoo00oo
def OoO0ooO ( url ) :
 if 51 - 51: iIii1I111I11I / IiIIIiI1I1 * oO0 . iIii1I111I11I / OOoOoo00oo / i11iIiiIii
 O0oo0O = datetime . date . today ( )
 I1IiI11 = datetime . datetime . strftime ( O0oo0O , '%A %d %B %Y' )
 if 21 - 21: iI1 / OOoOoo00oo + ii1IiIi11 + I1i1iI1i
 I1III ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( I1IiI11 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 91 - 91: i11iIiiIii / o00ooo0 + iIii1I111I11I + IiIIIiI1I1 * i11iIiiIii
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I1I1I = url
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 66 - 66: Oo0ooO0oo0oO % o00ooo0 - o0OO0 + oooO * Ooooo . O00OooO0
  o0oO = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 )
  if len ( o0oO ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + IIiIi1iI
   i1OOO = '[COLOR mediumpurple]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 20 , IIiIi1iI , IIiIi1iI )
   if 52 - 52: IiIIIiI1I1 + o0OO0 . iIii1I111I11I . OOoOoo00oo . I1I1i1
  elif len ( o0oO ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = I1I1I + "!" + i1OOO + "!" + IIiIi1iI
   i1OOO = '[COLOR mediumpurple]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 22 , IIiIi1iI , IIiIi1iI )
   if 97 - 97: Oo0oO0ooo / iIii1I111I11I
def Oooo0 ( ) :
 if 59 - 59: I1i1iI1i
 O0oo0O = datetime . date . today ( )
 I1IiI11 = datetime . datetime . strftime ( O0oo0O , '%A %d %B %Y' )
 if 47 - 47: IiIIIiI1I1 - Oo0oO0ooo / o00
 I1III ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( I1IiI11 ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 12 - 12: OoOooOOOO
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 O0Oo000ooO00 = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( o00OO00OoO )
 O0iII1 = str ( O0Oo000ooO00 )
 II = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( O0iII1 )
 for oO0Ii1iIiII1ii1 in II :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in oO0Ii1iIiII1ii1 :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    oO = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( 'src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     II1i = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
     II1i = Ii1IIIIi1ii1I ( II1i )
    except : II1i = "null"
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + oO + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    i1OOO = IiiIiI1Ii1i ( i1OOO )
    i1IiiiI1iI = oO + "!" + II1i . lower ( ) + "!" + IIiIi1iI
    Oo0oOOo ( i1OOO , i1IiiiI1iI , 20 , IIiIi1iI , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    oO = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     II1i = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : II1i = "null"
    IIiIi1iI = re . compile ( 'src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + oO + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    i1OOO = IiiIiI1Ii1i ( i1OOO )
    i1IiiiI1iI = oO + "!" + II1i . lower ( ) + "!" + IIiIi1iI
    Oo0oOOo ( i1OOO , i1IiiiI1iI , 20 , IIiIi1iI , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 22 - 22: O00OooO0 / i11iIiiIii
def oOOoo ( name , url , iconimage ) :
 if 14 - 14: OOo0o0 * iI1
 try :
  url , O0OOO0OOooo00 , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 6 - 6: ii1IiIi11 - IiIIIiI1I1 * OoOooOOOO . iIii1I111I11I / o0OO0 * IiIIIiI1I1
 II11iI111i1 = [ ]
 if 95 - 95: I1i1iI1i - O00OooO0 * Oo0oO0ooo + oO0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iI = re . compile ( '<title>' + re . escape ( O0OOO0OOooo00 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iI ) [ 0 ]
 o0oO = re . compile ( '<search>(.+?)</search>' ) . findall ( iI )
 for OO0O000 in o0oO :
  II11iI111i1 . append ( OO0O000 )
  if 10 - 10: OOo0o0 / i11iIiiIii
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 92 - 92: oooO . Ooooo
 oOO00O0Ooooo00 = 0
 if 97 - 97: IiIIIiI1I1 / Ooooo % o00ooo0 % OOoOoo00oo
 ii111I11iI = [ ]
 OO0ooo0o0O0Oooooo = [ ]
 i11IIIiI1I = [ ]
 I1IiiI . update ( 0 )
 o0 = 0
 if 30 - 30: o0OO0 * I1i1iI1i
 if O00o0o0000o0o == "true" :
  o0 = 1
  IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if oOO00O0Ooooo00 < 100 :
    I1IiiI . update ( oOO00O0Ooooo00 )
    oOO00O0Ooooo00 = oOO00O0Ooooo00 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1I1IiiI1ii1i , url in iIi1Ii1i1iI :
    O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : url }
    IIiI1 . append ( O0o )
   I1iIIIi1 = [ ]
   for oO0OoO00o in IIiI1 :
    O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
    for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
     O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
    I1iIIIi1 . append ( O0o )
    if 17 - 17: Oo0ooO0oo0oO . I1i1iI1i / oooO % o00 % o00ooo0 / i11iIiiIii
   for oO0OoO00o in I1iIIIi1 :
    name = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
    url = I11iiiii1II ( oO0OoO00o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    ii111I11iI . append ( name )
    OO0ooo0o0O0Oooooo . append ( url )
    if "hd" in name . lower ( ) :
     i11IIIiI1I . append ( "1" )
    else :
     i11IIIiI1I . append ( "0" )
    OOO = list ( zip ( i11IIIiI1I , ii111I11iI , OO0ooo0o0O0Oooooo ) )
    if 30 - 30: I1i1iI1i - I1i1iI1i . o0OO0 / iIii1I111I11I
 if O0Oo == "true" :
  o0 = 1
  IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if oOO00O0Ooooo00 < 100 :
    I1IiiI . update ( oOO00O0Ooooo00 )
    oOO00O0Ooooo00 = oOO00O0Ooooo00 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1I1IiiI1ii1i , url in iIi1Ii1i1iI :
    O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : url }
    IIiI1 . append ( O0o )
   I1iIIIi1 = [ ]
   for oO0OoO00o in IIiI1 :
    O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
    for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
     O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
    I1iIIIi1 . append ( O0o )
    if 31 - 31: OoOooOOOO + OOo0o0 . I1i1iI1i
   for oO0OoO00o in I1iIIIi1 :
    name = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
    url = I11iiiii1II ( oO0OoO00o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    ii111I11iI . append ( name )
    OO0ooo0o0O0Oooooo . append ( url )
    if "hd" in name . lower ( ) :
     i11IIIiI1I . append ( "1" )
    else :
     i11IIIiI1I . append ( "0" )
    OOO = list ( zip ( i11IIIiI1I , ii111I11iI , OO0ooo0o0O0Oooooo ) )
    if 89 - 89: o00 + o00ooo0 + o00
 if oo == "true" :
  o0 = 1
  IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if oOO00O0Ooooo00 < 100 :
    I1IiiI . update ( oOO00O0Ooooo00 )
    oOO00O0Ooooo00 = oOO00O0Ooooo00 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1I1IiiI1ii1i , url in iIi1Ii1i1iI :
    O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : url }
    IIiI1 . append ( O0o )
   I1iIIIi1 = [ ]
   for oO0OoO00o in IIiI1 :
    O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
    for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
     O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
    I1iIIIi1 . append ( O0o )
    if 7 - 7: o0OO0 % OOo0o0 + OOoOoo00oo * iIii1I111I11I - iIii1I111I11I
   for oO0OoO00o in I1iIIIi1 :
    name = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
    url = I11iiiii1II ( oO0OoO00o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    ii111I11iI . append ( name )
    OO0ooo0o0O0Oooooo . append ( url )
    if "hd" in name . lower ( ) :
     i11IIIiI1I . append ( "1" )
    else :
     i11IIIiI1I . append ( "0" )
    OOO = list ( zip ( i11IIIiI1I , ii111I11iI , OO0ooo0o0O0Oooooo ) )
    if 42 - 42: oO0 * oO0 * Ooooo . oooO
 if o0 == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 51 - 51: OoOooOOOO % Oo0ooO0oo0oO - I1i1iI1i % IiIIIiI1I1 * Oo0ooO0oo0oO % I1I1i1
 oO0o00oOOooO0 = sorted ( OOO , key = lambda iIii11I : int ( iIii11I [ 0 ] ) , reverse = True )
 OOOoO000 = sorted ( II11iI111i1 )
 if 57 - 57: o00
 i1IIIII11I1IiI = 0
 if 54 - 54: I11iii11IIi + iI1 + i11iIiiIii
 I1IiiI . update ( 100 )
 if 28 - 28: iI1
 I1III ( '                    [COLOR yellow][I]LINKS FOR ' + O0OOO0OOooo00 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 I1III ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 70 - 70: O00OooO0
 if 34 - 34: Ooooo % O00OooO0
 for II1i in OOOoO000 :
  if 3 - 3: o00 / OoOooOOOO + O00OooO0 . IiIIIiI1I1 . I1I1i1
  I1III ( '                                  [COLOR mediumpurple][I]' + II1i . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 83 - 83: iI1 + I1i1iI1i
  O0iII1 = II1i . split ( ' ' )
  if 22 - 22: ii1IiIi11 % iIii1I111I11I * I1i1iI1i - OOo0o0 / Oo0ooO0oo0oO
  for OoOO00 , name , url in oO0o00oOOooO0 :
   if 28 - 28: iI1 - i11iIiiIii . OOoOoo00oo + O00OooO0 / OOoOoo00oo
   i11iIiI11I1i = 0
   if 41 - 41: ii1IiIi11
   for oOOoo0o0OOOO in O0iII1 :
    if 26 - 26: iIii1I111I11I % Oo0ooO0oo0oO + OOo0o0
    if not oOOoo0o0OOOO . lower ( ) in name . lower ( ) :
     i11iIiI11I1i = 1
     if 67 - 67: iI1 + o00 - o0OO0 . iI1 * o00 * oooO
   if i11iIiI11I1i == 0 :
    i1IIIII11I1IiI = i1IIIII11I1IiI + 1
    if "hd" in name . lower ( ) :
     I1III ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( i1IIIII11I1IiI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     I1III ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( i1IIIII11I1IiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 90 - 90: ii1IiIi11 . O00OooO0
  if i1IIIII11I1IiI == 0 :
   I1III ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 81 - 81: OoOooOOOO - oooO % IiIIIiI1I1 - I1I1i1 / I11iii11IIi
  O0iII1 = ""
  if 4 - 4: I1i1iI1i - o00ooo0 % ii1IiIi11 - OoOooOOOO * OOo0o0
 I1IiiI . close ( )
 if 85 - 85: I1i1iI1i * Oo0ooO0oo0oO . iIii1I111I11I / I1i1iI1i % Oo0oO0ooo % o0OO0
def I1iii ( name , url , iconimage ) :
 if 86 - 86: OOoOoo00oo * o0OO0 * O00OooO0
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 51 - 51: o00 + O00OooO0 . o00ooo0 . OOoOoo00oo + oO0 * Oo0oO0ooo
 oOO00O0Ooooo00 = 0
 try :
  O0OOO0OOooo00 , II1i , iconimage = url . split ( '!' )
 except :
  try :
   II1i , iconimage = url . split ( '!' )
   O0OOO0OOooo00 = II1i
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 72 - 72: iI1 + iI1 / o00 . I1i1iI1i % ii1IiIi11
 III = 0
 if 41 - 41: i11iIiiIii + I11iii11IIi / Oo0oO0ooo . I1i1iI1i % iI1 % o00ooo0
 if "all " in name . lower ( ) :
  II1i = II1i . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  O0OOO0OOooo00 = O0OOO0OOooo00 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  III = 1
  if 70 - 70: I11iii11IIi . I1i1iI1i - iIii1I111I11I
 ii111I11iI = [ ]
 OO0ooo0o0O0Oooooo = [ ]
 i11IIIiI1I = [ ]
 I1IiiI . update ( 0 )
 o0 = 0
 if O00o0o0000o0o == "true" :
  o0 = 1
  IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if oOO00O0Ooooo00 < 100 :
    I1IiiI . update ( oOO00O0Ooooo00 )
    oOO00O0Ooooo00 = oOO00O0Ooooo00 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1I1IiiI1ii1i , url in iIi1Ii1i1iI :
    O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : url }
    IIiI1 . append ( O0o )
   I1iIIIi1 = [ ]
   for oO0OoO00o in IIiI1 :
    O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
    for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
     O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
    I1iIIIi1 . append ( O0o )
    if 30 - 30: OOoOoo00oo % Oo0oO0ooo
   for oO0OoO00o in I1iIIIi1 :
    name = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
    url = I11iiiii1II ( oO0OoO00o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    ii111I11iI . append ( name )
    OO0ooo0o0O0Oooooo . append ( url )
    if "hd" in name . lower ( ) :
     i11IIIiI1I . append ( "1" )
    else :
     i11IIIiI1I . append ( "0" )
    OOO = list ( zip ( i11IIIiI1I , ii111I11iI , OO0ooo0o0O0Oooooo ) )
    if 89 - 89: Ooooo + I1i1iI1i + Ooooo * o00ooo0 + Oo0ooO0oo0oO % oooO
 if O0Oo == "true" :
  o0 = 1
  IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if oOO00O0Ooooo00 < 100 :
    I1IiiI . update ( oOO00O0Ooooo00 )
    oOO00O0Ooooo00 = oOO00O0Ooooo00 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1I1IiiI1ii1i , url in iIi1Ii1i1iI :
    O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : url }
    IIiI1 . append ( O0o )
   I1iIIIi1 = [ ]
   for oO0OoO00o in IIiI1 :
    O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
    for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
     O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
    I1iIIIi1 . append ( O0o )
    if 59 - 59: OoOooOOOO + i11iIiiIii
   for oO0OoO00o in I1iIIIi1 :
    name = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
    url = I11iiiii1II ( oO0OoO00o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    ii111I11iI . append ( name )
    OO0ooo0o0O0Oooooo . append ( url )
    if "hd" in name . lower ( ) :
     i11IIIiI1I . append ( "1" )
    else :
     i11IIIiI1I . append ( "0" )
    OOO = list ( zip ( i11IIIiI1I , ii111I11iI , OO0ooo0o0O0Oooooo ) )
    if 88 - 88: i11iIiiIii - IiIIIiI1I1
 if oo == "true" :
  o0 = 1
  IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if oOO00O0Ooooo00 < 100 :
    I1IiiI . update ( oOO00O0Ooooo00 )
    oOO00O0Ooooo00 = oOO00O0Ooooo00 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   IIiI1 = [ ]
   for i1iI1 , ii1I1IiiI1ii1i , url in iIi1Ii1i1iI :
    O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : url }
    IIiI1 . append ( O0o )
   I1iIIIi1 = [ ]
   for oO0OoO00o in IIiI1 :
    O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
    iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
    for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
     O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
    I1iIIIi1 . append ( O0o )
    if 67 - 67: OoOooOOOO . I11iii11IIi + oO0 - I1i1iI1i
   for oO0OoO00o in I1iIIIi1 :
    name = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
    url = I11iiiii1II ( oO0OoO00o [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    ii111I11iI . append ( name )
    OO0ooo0o0O0Oooooo . append ( url )
    if "hd" in name . lower ( ) :
     i11IIIiI1I . append ( "1" )
    else :
     i11IIIiI1I . append ( "0" )
    OOO = list ( zip ( i11IIIiI1I , ii111I11iI , OO0ooo0o0O0Oooooo ) )
    if 70 - 70: OoOooOOOO / o00 - Oo0ooO0oo0oO - iIii1I111I11I
 if o0 == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 11 - 11: Oo0ooO0oo0oO . I1i1iI1i . o00 / o00ooo0 - oooO
 oO0o00oOOooO0 = sorted ( OOO , key = lambda iIii11I : int ( iIii11I [ 0 ] ) , reverse = True )
 if 30 - 30: oO0
 i1IIIII11I1IiI = 0
 if 21 - 21: i11iIiiIii / Ooooo % OoOooOOOO * o0OO0 . oooO - Oo0ooO0oo0oO
 I1IiiI . update ( 100 )
 if 26 - 26: o00 * oO0
 I1III ( '                                [COLOR yellow][I]LINKS FOR ' + O0OOO0OOooo00 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 I1III ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O0iII1 = II1i . split ( ' ' )
 for OoOO00 , name , url in oO0o00oOOooO0 :
  if III == 1 :
   iioo0o0OoOOO = name
   if 88 - 88: iIii1I111I11I
  i11iIiI11I1i = 0
  if 19 - 19: o00 * O00OooO0 + ii1IiIi11
  for oOOoo0o0OOOO in O0iII1 :
   if 65 - 65: OoOooOOOO . Ooooo . I1I1i1 . iIii1I111I11I - OoOooOOOO
   if not oOOoo0o0OOOO . lower ( ) in name . lower ( ) :
    i11iIiI11I1i = 1
    if 19 - 19: i11iIiiIii + iIii1I111I11I % IiIIIiI1I1
  if i11iIiI11I1i == 0 :
   i1IIIII11I1IiI = i1IIIII11I1IiI + 1
   if III == 1 :
    if "hd" in name . lower ( ) :
     I1III ( '                                          [COLOR blue] ' + str ( iioo0o0OoOOO ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     I1III ( '                                          [COLOR blue] ' + str ( iioo0o0OoOOO ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     I1III ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( i1IIIII11I1IiI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     I1III ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( i1IIIII11I1IiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 14 - 14: I1I1i1 . o00 . oooO / ii1IiIi11 % OOoOoo00oo - IiIIIiI1I1
 if i1IIIII11I1IiI == 0 :
  I1III ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 67 - 67: oooO - OoOooOOOO . o00ooo0
 I1IiiI . close ( )
 if 35 - 35: iIii1I111I11I + IiIIIiI1I1 - iI1 . iIii1I111I11I . O00OooO0
def oo0ooOO ( term ) :
 if 24 - 24: I1I1i1 % I1I1i1 * Oo0ooO0oo0oO
 OoOOoOooooOOo = [ ]
 oOo0O = [ ]
 if 50 - 50: I1I1i1 . i11iIiiIii - iI1 . iI1
 IiI1iiiIii = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( IiI1iiiIii )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1IiiiI1iI = oO0Ii1iIiII1ii1
  if 31 - 31: OoOooOOOO / I11iii11IIi * o00ooo0 . oO0
  i1IiiiI1iI = i1IiiiI1iI . replace ( '#AAASTREAM:' , '#A:' )
  i1IiiiI1iI = i1IiiiI1iI . replace ( '#EXTINF:' , '#A:' )
  iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i1IiiiI1iI )
  IIiI1 = [ ]
  for i1iI1 , ii1I1IiiI1ii1i , i1IiiiI1iI in iIi1Ii1i1iI :
   O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : i1IiiiI1iI }
   IIiI1 . append ( O0o )
  list = [ ]
  for oO0OoO00o in IIiI1 :
   O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
   iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
   for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
    O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
   list . append ( O0o )
   if 57 - 57: OoOooOOOO + Oo0ooO0oo0oO % o00ooo0 % Oo0oO0ooo
  for oO0OoO00o in list :
   i1OOO = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
   i1IiiiI1iI = I11iiiii1II ( oO0OoO00o [ "url" ] )
   i1IiiiI1iI = i1IiiiI1iI . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in i1OOO . lower ( ) :
    OoOOoOooooOOo . append ( i1IiiiI1iI )
    oOo0O . append ( i1OOO )
    if 83 - 83: OOo0o0 / i11iIiiIii % Oo0ooO0oo0oO . oooO % iI1 . I1i1iI1i
 O00ooooo00 = xbmcgui . Dialog ( )
 IiIi11iI = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , oOo0O )
 if IiIi11iI < 0 :
  quit ( )
  if 94 - 94: ii1IiIi11 + Oo0ooO0oo0oO % I1I1i1
 i1IiiiI1iI = OoOOoOooooOOo [ IiIi11iI ]
 i1OOO = oOo0O [ IiIi11iI ]
 OoO000O0Oo ( i1OOO , i1IiiiI1iI , iiiii )
 if 93 - 93: ii1IiIi11 - OoOooOOOO + Oo0ooO0oo0oO * OOo0o0 + Ooooo . iIii1I111I11I
def IiI1iII1II111 ( name , url , iconimage ) :
 if 28 - 28: oO0 * I1I1i1 . oooO % oooO / oooO * Ooooo
 list = ooO00O0O0 ( url )
 if 33 - 33: I11iii11IIi
 II11i11Iii = 0
 oOoO = open ( IiII , mode = 'r' ) ; oooo00o0o0o = oOoO . read ( ) ; oOoO . close ( )
 oooo00o0o0o = oooo00o0o0o . replace ( '\n' , '' )
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( oooo00o0o0o )
 O0O = 0
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 87 - 87: oooO * o00ooo0 - ii1IiIi11 % OoOooOOOO / Ooooo
  IiIiiI11111I1 = re . compile ( '<url>(.+?)</url>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  if 55 - 55: IiIIIiI1I1 % I1i1iI1i / I1i1iI1i % I1i1iI1i
  if url == IiIiiI11111I1 :
   II11i11Iii = 1
   if 52 - 52: OOoOoo00oo + OOoOoo00oo . o00
 for oO0OoO00o in list :
  name = I11iiiii1II ( oO0OoO00o [ "display_name" ] )
  url = I11iiiii1II ( oO0OoO00o [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if II11i11Iii == 1 :
   if 34 - 34: I1i1iI1i . o0OO0 / iI1 * oO0 - OOoOoo00oo
   oOoO = open ( iI1Ii11111iIi , mode = 'r' ) ; oooo00o0o0o = oOoO . read ( ) ; oOoO . close ( )
   oooo00o0o0o = oooo00o0o0o . replace ( '\n' , '' )
   O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( oooo00o0o0o )
   for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
    if 36 - 36: o00ooo0 / o0OO0 / I1I1i1 - o0OO0 - o00ooo0
    ii1I11 = re . compile ( '<name>(.+?)</name>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    if 99 - 99: OoOooOOOO
    II11i11II = ii1I11 . replace ( ' ' , '' )
    II1Ii1iI1i1 = name . replace ( ' ' , '' )
    if II11i11II . lower ( ) in II1Ii1iI1i1 . lower ( ) :
     if 54 - 54: o0OO0
     oOoO = open ( i1i1II , mode = 'r' ) ; oooo00o0o0o = oOoO . read ( ) ; oOoO . close ( )
     oooo00o0o0o = oooo00o0o0o . replace ( '\n' , '' )
     O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( oooo00o0o0o )
     for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
      if 68 - 68: I1I1i1 * OOo0o0 . IiIIIiI1I1 % iI1 % Ooooo
      oooo0OO = re . compile ( '<replace>(.+?)</replace>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
      if 23 - 23: iI1 + I1I1i1
      name = name . lower ( ) . replace ( oooo0OO , '' )
      if 2 - 2: iI1 - ii1IiIi11 - oooO - Ooooo . Oo0ooO0oo0oO
     I1III ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 79 - 79: ii1IiIi11 . I1I1i1
  else : I1III ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 40 - 40: OOo0o0 + I11iii11IIi . OOo0o0 % IiIIIiI1I1
def ooO00O0O0 ( url ) :
 if 15 - 15: ii1IiIi11 * I11iii11IIi % OOoOoo00oo * Oo0ooO0oo0oO - i11iIiiIii
 Oo00OOOOoo0oo = IIIii1II1II ( url )
 Oo00OOOOoo0oo = Oo00OOOOoo0oo . replace ( '#AAASTREAM:' , '#A:' )
 Oo00OOOOoo0oo = Oo00OOOOoo0oo . replace ( '#EXTINF:' , '#A:' )
 iIi1Ii1i1iI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( Oo00OOOOoo0oo )
 IIiI1 = [ ]
 for i1iI1 , ii1I1IiiI1ii1i , url in iIi1Ii1i1iI :
  O0o = { "params" : i1iI1 , "display_name" : ii1I1IiiI1ii1i , "url" : url }
  IIiI1 . append ( O0o )
 list = [ ]
 for oO0OoO00o in IIiI1 :
  O0o = { "display_name" : oO0OoO00o [ "display_name" ] , "url" : oO0OoO00o [ "url" ] }
  iIi1Ii1i1iI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oO0OoO00o [ "params" ] )
  for II1iiiiII , O0OoOO0oo0 in iIi1Ii1i1iI :
   O0o [ II1iiiiII . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OoOO0oo0 . strip ( )
  list . append ( O0o )
  if 80 - 80: Ooooo * oO0 * o00 - o0OO0 . oO0 % Oo0oO0ooo
 return list
 if 13 - 13: iI1 . Oo0oO0ooo * iI1 + Oo0oO0ooo
 if 59 - 59: Oo0oO0ooo + i11iIiiIii + o00ooo0 / oooO
def I11 ( ) :
 if 47 - 47: OOoOoo00oo / iI1 / iIii1I111I11I
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 86 - 86: OOo0o0
def Ii ( name , url , iconimage ) :
 if 2 - 2: OOoOoo00oo . OOoOoo00oo + OOoOoo00oo * OOo0o0
 oOo00oOOOOO = datetime . datetime . now ( )
 OoOOo0O00 = oOo00oOOOOO . day
 if 49 - 49: oO0 / I11iii11IIi . i11iIiiIii
 IIIi1i = OoOOo0O00
 if 71 - 71: iIii1I111I11I % OOo0o0 / OoOooOOOO / I11iii11IIi
 OO0OO0OO = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 Ooo = datetime . datetime . strftime ( OO0OO0OO , '%A - %d %B %Y' )
 oO0o = 'http://www.predictz.com/predictions/'
 if 24 - 24: oO0 % o00ooo0 + iIii1I111I11I . i11iIiiIii . OOoOoo00oo
 IIi1II = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 IiiI11i1I = datetime . datetime . strftime ( IIi1II , '%A - %d %B %Y' )
 OOo0 = datetime . datetime . strftime ( IIi1II , '%d' )
 iiIii1IIi = 'http://www.predictz.com/predictions/tomorrow/'
 if 10 - 10: i11iIiiIii - OOo0o0 % Oo0ooO0oo0oO
 i111IIIiI = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 III111iiIi1 = datetime . datetime . strftime ( i111IIIiI , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii11Ii = datetime . datetime . strftime ( i111IIIiI , '%y%m%d' )
 IiIiIi1IIi = 'http://www.predictz.com/predictions/20' + str ( Ii11Ii )
 if 69 - 69: ii1IiIi11 + I11iii11IIi + o00 - Oo0oO0ooo / oooO
 O0O0ooOOO = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 O0oiIiiiiI1II1I1 = datetime . datetime . strftime ( O0O0ooOOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoO0ooOoooo = datetime . datetime . strftime ( O0O0ooOOO , '%y%m%d' )
 IIIII1iii11 = 'http://www.predictz.com/predictions/20' + str ( OoO0ooOoooo )
 if 35 - 35: iI1 / Ooooo / o00 - Oo0ooO0oo0oO + o00 . Ooooo
 O0O00O000OOO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIOo0O = datetime . datetime . strftime ( O0O00O000OOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii11 = datetime . datetime . strftime ( O0O00O000OOO , '%y%m%d' )
 II1i111 = 'http://www.predictz.com/predictions/20' + str ( Ii11 )
 if 50 - 50: O00OooO0 % o00ooo0
 if 21 - 21: I1i1iI1i - Oo0ooO0oo0oO
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( Ooo ) + '[/B][/COLOR]' , oO0o , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IiiI11i1I ) + '[/B][/COLOR]' , iiIii1IIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( III111iiIi1 ) , IiIiIi1IIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( O0oiIiiiiI1II1I1 ) , IIIII1iii11 , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIOo0O ) , II1i111 , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 93 - 93: iI1 - OOo0o0 % oO0 . oO0 - IiIIIiI1I1
def O00ooOo ( name , url , iconimage ) :
 if 80 - 80: OOo0o0 - OoOooOOOO + I1i1iI1i
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 O0iII1 = str ( O0Oo000ooO00 )
 II = re . compile ( '<tr(.+?)</tr>' ) . findall ( O0iII1 )
 for oO0Ii1iIiII1ii1 in II :
  try :
   IIiIi = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR red][B]' + IIiIi + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   oO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   O0ooOoO = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   oO = IIII ( oO )
   O0ooOoO = IIII ( O0ooOoO )
   I1III ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + O0ooOoO + ' [/B][/COLOR]| [COLOR mediumpurple]' + oO + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 50 - 50: I11iii11IIi % O00OooO0
def iIi ( name , url , iconimage ) :
 if 10 - 10: I1I1i1 / I11iii11IIi
 oOo00oOOOOO = datetime . datetime . now ( )
 OoOOo0O00 = oOo00oOOOOO . day
 if 15 - 15: iIii1I111I11I . oO0 / iIii1I111I11I * oooO - Oo0oO0ooo % OOoOoo00oo
 IIIi1i = OoOOo0O00
 if 57 - 57: o0OO0 % oO0 % iI1
 OO0OO0OO = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 Ooo = datetime . datetime . strftime ( OO0OO0OO , '%A - %d %B %Y' )
 oO0o = 'http://www.predictz.com/predictions/'
 if 45 - 45: OOoOoo00oo + o00 * i11iIiiIii
 IIi1II = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 IiiI11i1I = datetime . datetime . strftime ( IIi1II , '%A - %d %B %Y' )
 OOo0 = datetime . datetime . strftime ( IIi1II , '%d' )
 iiIii1IIi = 'http://www.predictz.com/predictions/tomorrow/'
 if 13 - 13: I1i1iI1i * iI1 - ii1IiIi11 / OoOooOOOO + oooO + O00OooO0
 i111IIIiI = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 III111iiIi1 = datetime . datetime . strftime ( i111IIIiI , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii11Ii = datetime . datetime . strftime ( i111IIIiI , '%y%m%d' )
 IiIiIi1IIi = 'http://www.predictz.com/predictions/20' + str ( Ii11Ii )
 if 39 - 39: Oo0ooO0oo0oO - I1i1iI1i
 O0O0ooOOO = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 O0oiIiiiiI1II1I1 = datetime . datetime . strftime ( O0O0ooOOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoO0ooOoooo = datetime . datetime . strftime ( O0O0ooOOO , '%y%m%d' )
 IIIII1iii11 = 'http://www.predictz.com/predictions/20' + str ( OoO0ooOoooo )
 if 81 - 81: OOoOoo00oo - o0OO0 * I1i1iI1i
 O0O00O000OOO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIOo0O = datetime . datetime . strftime ( O0O00O000OOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii11 = datetime . datetime . strftime ( O0O00O000OOO , '%y%m%d' )
 II1i111 = 'http://www.predictz.com/predictions/20' + str ( Ii11 )
 if 23 - 23: o00 / iI1
 if 28 - 28: I11iii11IIi * IiIIIiI1I1 - I1I1i1
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( Ooo ) + '[/B][/COLOR]' , oO0o , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IiiI11i1I ) + '[/B][/COLOR]' , iiIii1IIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( III111iiIi1 ) , IiIiIi1IIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( O0oiIiiiiI1II1I1 ) , IIIII1iii11 , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIOo0O ) , II1i111 , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 19 - 19: oooO
def Ooooo0OoO0 ( name , url , iconimage ) :
 if 9 - 9: OoOooOOOO . O00OooO0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 O0iII1 = str ( O0Oo000ooO00 )
 II = re . compile ( '<tr(.+?)</tr>' ) . findall ( O0iII1 )
 for oO0Ii1iIiII1ii1 in II :
  try :
   IIiIi = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR red][B]' + IIiIi + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   oO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   iIi1i = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   OO0Oo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 1 ]
   IiIIIIIIiI = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 2 ]
   oO = IIII ( oO )
   I1III ( '[COLOR mediumpurple][B]' + oO + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + iIi1i + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + OO0Oo + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + IiIIIIIIiI + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 54 - 54: I11iii11IIi + Oo0oO0ooo / iIii1I111I11I . Oo0oO0ooo * oO0
def IIiIiiiIIIIi1 ( name , url , iconimage ) :
 if 39 - 39: I1I1i1 / ii1IiIi11 / Ooooo
 oOo00oOOOOO = datetime . datetime . now ( )
 OoOOo0O00 = oOo00oOOOOO . day
 if 81 - 81: oooO / I1I1i1 % I1i1iI1i * iI1 / iI1
 IIIi1i = OoOOo0O00
 if 28 - 28: i11iIiiIii / OOo0o0 . Oo0ooO0oo0oO / o00
 OO0OO0OO = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 Ooo = datetime . datetime . strftime ( OO0OO0OO , '%A - %d %B %Y' )
 oO0o = 'http://www.predictz.com/predictions/'
 if 72 - 72: I1i1iI1i / Oo0oO0ooo + ii1IiIi11 / oO0 * ii1IiIi11
 IIi1II = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 IiiI11i1I = datetime . datetime . strftime ( IIi1II , '%A - %d %B %Y' )
 OOo0 = datetime . datetime . strftime ( IIi1II , '%d' )
 iiIii1IIi = 'http://www.predictz.com/predictions/tomorrow/'
 if 34 - 34: o0OO0 * o0OO0 % I1i1iI1i + iIii1I111I11I * Oo0ooO0oo0oO % ii1IiIi11
 i111IIIiI = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 III111iiIi1 = datetime . datetime . strftime ( i111IIIiI , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii11Ii = datetime . datetime . strftime ( i111IIIiI , '%y%m%d' )
 IiIiIi1IIi = 'http://www.predictz.com/predictions/20' + str ( Ii11Ii )
 if 25 - 25: oooO + oO0 . OOo0o0 % oO0 * OoOooOOOO
 O0O0ooOOO = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 O0oiIiiiiI1II1I1 = datetime . datetime . strftime ( O0O0ooOOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoO0ooOoooo = datetime . datetime . strftime ( O0O0ooOOO , '%y%m%d' )
 IIIII1iii11 = 'http://www.predictz.com/predictions/20' + str ( OoO0ooOoooo )
 if 32 - 32: i11iIiiIii - Ooooo
 O0O00O000OOO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIOo0O = datetime . datetime . strftime ( O0O00O000OOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii11 = datetime . datetime . strftime ( O0O00O000OOO , '%y%m%d' )
 II1i111 = 'http://www.predictz.com/predictions/20' + str ( Ii11 )
 if 53 - 53: I1i1iI1i - O00OooO0
 if 87 - 87: iI1 . Oo0oO0ooo
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( Ooo ) + '[/B][/COLOR]' , oO0o , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IiiI11i1I ) + '[/B][/COLOR]' , iiIii1IIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( III111iiIi1 ) , IiIiIi1IIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( O0oiIiiiiI1II1I1 ) , IIIII1iii11 , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIOo0O ) , II1i111 , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 17 - 17: ii1IiIi11 . i11iIiiIii
def IIIiiiI ( name , url , iconimage ) :
 if 94 - 94: o0OO0 - oooO - Oo0ooO0oo0oO % IiIIIiI1I1 / ii1IiIi11 % iIii1I111I11I
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 O0iII1 = str ( O0Oo000ooO00 )
 II = re . compile ( '<tr(.+?)</tr>' ) . findall ( O0iII1 )
 for oO0Ii1iIiII1ii1 in II :
  try :
   IIiIi = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR red][B]' + IIiIi + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   oO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1IIIII11I1IiI , i1I = oO . split ( ' v ' )
   iIi1IIi1ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I11Ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 1 ]
   iIiII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 2 ]
   i1i1IIIIIIIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 3 ]
   oo0o0oOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 4 ]
   OO0oOOo0o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 5 ]
   I1III11iiii11i1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 6 ]
   ooOo0OoO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 7 ]
   i1iiIIi1I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 8 ]
   iiI1I1IIi11i1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 9 ]
   if 45 - 45: IiIIIiI1I1 % OOo0o0 - IiIIIiI1I1
   if iIi1IIi1ii == "W" :
    iIi1IIi1ii = '[COLOR lime]W[/COLOR]'
   elif iIi1IIi1ii == "D" :
    iIi1IIi1ii = '[COLOR yellow]D[/COLOR]'
   else : iIi1IIi1ii = '[COLOR red]L[/COLOR]'
   if 31 - 31: O00OooO0 / i11iIiiIii
   if I11Ii == "W" :
    I11Ii = '[COLOR lime]W[/COLOR]'
   elif I11Ii == "D" :
    I11Ii = '[COLOR yellow]D[/COLOR]'
   else : I11Ii = '[COLOR red]L[/COLOR]'
   if 83 - 83: OOoOoo00oo / Ooooo - i11iIiiIii . Oo0ooO0oo0oO + I11iii11IIi
   if iIiII == "W" :
    iIiII = '[COLOR lime]W[/COLOR]'
   elif iIiII == "D" :
    iIiII = '[COLOR yellow]D[/COLOR]'
   else : iIiII = '[COLOR red]L[/COLOR]'
   if 59 - 59: o0OO0 % I11iii11IIi
   if i1i1IIIIIIIi == "W" :
    i1i1IIIIIIIi = '[COLOR lime]W[/COLOR]'
   elif i1i1IIIIIIIi == "D" :
    i1i1IIIIIIIi = '[COLOR yellow]D[/COLOR]'
   else : i1i1IIIIIIIi = '[COLOR red]L[/COLOR]'
   if 92 - 92: ii1IiIi11 % iIii1I111I11I / OOoOoo00oo % OOoOoo00oo * Oo0oO0ooo
   if oo0o0oOo == "W" :
    oo0o0oOo = '[COLOR lime]W[/COLOR]'
   elif oo0o0oOo == "D" :
    oo0o0oOo = '[COLOR yellow]D[/COLOR]'
   else : oo0o0oOo = '[COLOR red]L[/COLOR]'
   if 74 - 74: o0OO0 . Oo0oO0ooo % I1I1i1 % O00OooO0
   if OO0oOOo0o == "W" :
    OO0oOOo0o = '[COLOR lime]W[/COLOR]'
   elif OO0oOOo0o == "D" :
    OO0oOOo0o = '[COLOR yellow]D[/COLOR]'
   else : OO0oOOo0o = '[COLOR red]L[/COLOR]'
   if 87 - 87: iI1 - i11iIiiIii
   if I1III11iiii11i1 == "W" :
    I1III11iiii11i1 = '[COLOR lime]W[/COLOR]'
   elif I1III11iiii11i1 == "D" :
    I1III11iiii11i1 = '[COLOR yellow]D[/COLOR]'
   else : I1III11iiii11i1 = '[COLOR red]L[/COLOR]'
   if 78 - 78: i11iIiiIii / Oo0ooO0oo0oO - OOo0o0
   if ooOo0OoO == "W" :
    ooOo0OoO = '[COLOR lime]W[/COLOR]'
   elif ooOo0OoO == "D" :
    ooOo0OoO = '[COLOR yellow]D[/COLOR]'
   else : ooOo0OoO = '[COLOR red]L[/COLOR]'
   if 23 - 23: oooO
   if i1iiIIi1I == "W" :
    i1iiIIi1I = '[COLOR lime]W[/COLOR]'
   elif i1iiIIi1I == "D" :
    i1iiIIi1I = '[COLOR yellow]D[/COLOR]'
   else : i1iiIIi1I = '[COLOR red]L[/COLOR]'
   if 40 - 40: OOo0o0 - o00 / I11iii11IIi
   if iiI1I1IIi11i1 == "W" :
    iiI1I1IIi11i1 = '[COLOR lime]W[/COLOR]'
   elif iiI1I1IIi11i1 == "D" :
    iiI1I1IIi11i1 = '[COLOR yellow]D[/COLOR]'
   else : iiI1I1IIi11i1 = '[COLOR red]L[/COLOR]'
   if 14 - 14: OOoOoo00oo
   i1IIIII11I1IiI = IIII ( i1IIIII11I1IiI )
   i1I = IIII ( i1I )
   I1III ( '[COLOR mediumpurple][B]' + i1IIIII11I1IiI + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[B]' + iIi1IIi1ii + '  ' + I11Ii + '  ' + iIiII + '  ' + i1i1IIIIIIIi + '  ' + oo0o0oOo + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR mediumpurple][B]' + i1I + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[B]' + OO0oOOo0o + '  ' + I1III11iiii11i1 + '  ' + ooOo0OoO + '  ' + i1iiIIi1I + '  ' + iiI1I1IIi11i1 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 5 - 5: OOo0o0 . Oo0ooO0oo0oO % Oo0ooO0oo0oO
def ooO0oo0o0 ( name , url , iconimage ) :
 if 9 - 9: Oo0oO0ooo + OOoOoo00oo / Oo0oO0ooo . iI1 * IiIIIiI1I1
 oOo00oOOOOO = datetime . datetime . now ( )
 OoOOo0O00 = oOo00oOOOOO . day
 if 45 - 45: i11iIiiIii
 IIIi1i = OoOOo0O00
 if 82 - 82: ii1IiIi11 + O00OooO0
 OO0OO0OO = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 Ooo = datetime . datetime . strftime ( OO0OO0OO , '%A - %d %B %Y' )
 oO0o = 'http://www.predictz.com/predictions/'
 if 12 - 12: Ooooo
 IIi1II = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 IiiI11i1I = datetime . datetime . strftime ( IIi1II , '%A - %d %B %Y' )
 OOo0 = datetime . datetime . strftime ( IIi1II , '%d' )
 iiIii1IIi = 'http://www.predictz.com/predictions/tomorrow/'
 if 93 - 93: i11iIiiIii % Oo0ooO0oo0oO % i11iIiiIii + OOo0o0 / OOo0o0 / o00
 i111IIIiI = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 III111iiIi1 = datetime . datetime . strftime ( i111IIIiI , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii11Ii = datetime . datetime . strftime ( i111IIIiI , '%y%m%d' )
 IiIiIi1IIi = 'http://www.predictz.com/predictions/20' + str ( Ii11Ii )
 if 49 - 49: OoOooOOOO . OOoOoo00oo . i11iIiiIii - o00 / ii1IiIi11
 O0O0ooOOO = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 O0oiIiiiiI1II1I1 = datetime . datetime . strftime ( O0O0ooOOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoO0ooOoooo = datetime . datetime . strftime ( O0O0ooOOO , '%y%m%d' )
 IIIII1iii11 = 'http://www.predictz.com/predictions/20' + str ( OoO0ooOoooo )
 if 62 - 62: OoOooOOOO
 O0O00O000OOO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIOo0O = datetime . datetime . strftime ( O0O00O000OOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii11 = datetime . datetime . strftime ( O0O00O000OOO , '%y%m%d' )
 II1i111 = 'http://www.predictz.com/predictions/20' + str ( Ii11 )
 if 1 - 1: O00OooO0 / O00OooO0 - i11iIiiIii
 if 87 - 87: I11iii11IIi / o0OO0 * O00OooO0 / OOo0o0
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( Ooo ) + '[/B][/COLOR]' , oO0o , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IiiI11i1I ) + '[/B][/COLOR]' , iiIii1IIi , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( III111iiIi1 ) , IiIiIi1IIi , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( O0oiIiiiiI1II1I1 ) , IIIII1iii11 , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIOo0O ) , II1i111 , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 19 - 19: Ooooo + o00ooo0 . Oo0oO0ooo - I11iii11IIi
def iIi1I1 ( name , url , iconimage ) :
 if 63 - 63: iIii1I111I11I * OOoOoo00oo . I1i1iI1i / OoOooOOOO * I11iii11IIi . IiIIIiI1I1
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 O0iII1 = str ( O0Oo000ooO00 )
 II = re . compile ( '<tr(.+?)</tr>' ) . findall ( O0iII1 )
 for oO0Ii1iIiII1ii1 in II :
  try :
   IIiIi = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR red][B]' + IIiIi + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   oO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1IIIII11I1IiI , i1I = oO . split ( ' v ' )
   if 62 - 62: o00ooo0 / IiIIIiI1I1 . Oo0oO0ooo * OOo0o0
   O0ooOoO = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   iIi1i = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   OO0Oo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 1 ]
   IiIIIIIIiI = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 2 ]
   iIi1IIi1ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I11Ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 1 ]
   iIiII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 2 ]
   i1i1IIIIIIIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 3 ]
   oo0o0oOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 4 ]
   OO0oOOo0o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 5 ]
   I1III11iiii11i1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 6 ]
   ooOo0OoO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 7 ]
   i1iiIIi1I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 8 ]
   iiI1I1IIi11i1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 9 ]
   if 21 - 21: OOo0o0
   if iIi1IIi1ii == "W" :
    iIi1IIi1ii = '[COLOR lime]W[/COLOR]'
   elif iIi1IIi1ii == "D" :
    iIi1IIi1ii = '[COLOR yellow]D[/COLOR]'
   else : iIi1IIi1ii = '[COLOR red]L[/COLOR]'
   if 81 - 81: oooO / Oo0ooO0oo0oO - IiIIIiI1I1 * Ooooo . Oo0oO0ooo * OOoOoo00oo
   if I11Ii == "W" :
    I11Ii = '[COLOR lime]W[/COLOR]'
   elif I11Ii == "D" :
    I11Ii = '[COLOR yellow]D[/COLOR]'
   else : I11Ii = '[COLOR red]L[/COLOR]'
   if 95 - 95: Oo0oO0ooo
   if iIiII == "W" :
    iIiII = '[COLOR lime]W[/COLOR]'
   elif iIiII == "D" :
    iIiII = '[COLOR yellow]D[/COLOR]'
   else : iIiII = '[COLOR red]L[/COLOR]'
   if 88 - 88: O00OooO0 % I1I1i1 + Ooooo + Ooooo * o00
   if i1i1IIIIIIIi == "W" :
    i1i1IIIIIIIi = '[COLOR lime]W[/COLOR]'
   elif i1i1IIIIIIIi == "D" :
    i1i1IIIIIIIi = '[COLOR yellow]D[/COLOR]'
   else : i1i1IIIIIIIi = '[COLOR red]L[/COLOR]'
   if 78 - 78: I1i1iI1i
   if oo0o0oOo == "W" :
    oo0o0oOo = '[COLOR lime]W[/COLOR]'
   elif oo0o0oOo == "D" :
    oo0o0oOo = '[COLOR yellow]D[/COLOR]'
   else : oo0o0oOo = '[COLOR red]L[/COLOR]'
   if 77 - 77: OOoOoo00oo / o00ooo0 / I11iii11IIi % OoOooOOOO
   if OO0oOOo0o == "W" :
    OO0oOOo0o = '[COLOR lime]W[/COLOR]'
   elif OO0oOOo0o == "D" :
    OO0oOOo0o = '[COLOR yellow]D[/COLOR]'
   else : OO0oOOo0o = '[COLOR red]L[/COLOR]'
   if 48 - 48: oooO - O00OooO0 + Oo0ooO0oo0oO + I1i1iI1i
   if I1III11iiii11i1 == "W" :
    I1III11iiii11i1 = '[COLOR lime]W[/COLOR]'
   elif I1III11iiii11i1 == "D" :
    I1III11iiii11i1 = '[COLOR yellow]D[/COLOR]'
   else : I1III11iiii11i1 = '[COLOR red]L[/COLOR]'
   if 4 - 4: o00 . oooO + ii1IiIi11 * Ooooo . IiIIIiI1I1
   if ooOo0OoO == "W" :
    ooOo0OoO = '[COLOR lime]W[/COLOR]'
   elif ooOo0OoO == "D" :
    ooOo0OoO = '[COLOR yellow]D[/COLOR]'
   else : ooOo0OoO = '[COLOR red]L[/COLOR]'
   if 87 - 87: oO0 / I1I1i1 / i11iIiiIii
   if i1iiIIi1I == "W" :
    i1iiIIi1I = '[COLOR lime]W[/COLOR]'
   elif i1iiIIi1I == "D" :
    i1iiIIi1I = '[COLOR yellow]D[/COLOR]'
   else : i1iiIIi1I = '[COLOR red]L[/COLOR]'
   if 74 - 74: iI1 / OOoOoo00oo % OOo0o0
   if iiI1I1IIi11i1 == "W" :
    iiI1I1IIi11i1 = '[COLOR lime]W[/COLOR]'
   elif iiI1I1IIi11i1 == "D" :
    iiI1I1IIi11i1 = '[COLOR yellow]D[/COLOR]'
   else : iiI1I1IIi11i1 = '[COLOR red]L[/COLOR]'
   if 88 - 88: oO0 - i11iIiiIii % OOo0o0 * oooO + OOoOoo00oo
   i1IIIII11I1IiI = IIII ( i1IIIII11I1IiI )
   i1I = IIII ( i1I )
   oO = IIII ( oO )
   O0ooOoO = IIII ( O0ooOoO )
   I1III ( '[COLOR blue][B]' + oO + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + O0ooOoO + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]' + i1IIIII11I1IiI + ' Form: - [/COLOR][B]' + iIi1IIi1ii + '  ' + I11Ii + '  ' + iIiII + '  ' + i1i1IIIIIIIi + '  ' + oo0o0oOo + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]' + i1I + ' Form - [/COLOR][B]' + OO0oOOo0o + '  ' + I1III11iiii11i1 + '  ' + ooOo0OoO + '  ' + i1iiIIi1I + '  ' + iiI1I1IIi11i1 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]' + i1IIIII11I1IiI + ' Win[/COLOR][COLOR dodgerblue][B] (' + iIi1i + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + OO0Oo + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]' + i1I + ' Win[/COLOR][COLOR dodgerblue][B] (' + IiIIIIIIiI + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 52 - 52: o00 . Oo0oO0ooo + oO0 % I1I1i1
  except : pass
  if 62 - 62: OOo0o0
def I1i111i ( name , url , iconimage ) :
 if 42 - 42: OOoOoo00oo / o00ooo0 % oO0
 I11iiIIII1I1 = [ ]
 i1IIi1i1Ii1 = [ ]
 Iii = [ ]
 o0Oo0oO = [ ]
 iIII1iiIi11 = [ ]
 if 84 - 84: i11iIiiIii * I1I1i1
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.livescores.com' )
 O0Oo000ooO00 = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( o00OO00OoO )
 O0iII1 = str ( O0Oo000ooO00 )
 II = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( O0iII1 )
 for oO0Ii1iIiII1ii1 in II :
  I1I1iII1i = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  iiIIii = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  try :
   O0ooOoO = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except :
   O0ooOoO = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 70 - 70: OOo0o0 - OoOooOOOO
  if "minute" in time . lower ( ) :
   iIII1iiIi11 . append ( '3' )
  elif "ht" in time . lower ( ) :
   iIII1iiIi11 . append ( '3' )
  elif "ft" in time . lower ( ) :
   iIII1iiIi11 . append ( '2' )
  else : iIII1iiIi11 . append ( '1' )
  if 62 - 62: oooO
  I11iiIIII1I1 . append ( I1I1iII1i )
  i1IIi1i1Ii1 . append ( iiIIii )
  Iii . append ( O0ooOoO )
  o0Oo0oO . append ( time )
  OOO = list ( zip ( iIII1iiIi11 , I11iiIIII1I1 , i1IIi1i1Ii1 , Iii , o0Oo0oO ) )
  if 63 - 63: OoOooOOOO + IiIIIiI1I1 * iI1 / OOo0o0 / I11iii11IIi * Oo0ooO0oo0oO
 I1III ( '[COLOR dodgerblue][B]Refresh Scores[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 I1III ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 57 - 57: oO0 - iI1 / IiIIIiI1I1 % i11iIiiIii
 oO0o00oOOooO0 = sorted ( OOO , key = lambda iIii11I : int ( iIii11I [ 0 ] ) , reverse = True )
 I11oOOooo = 0
 ooo0O0Oo = 0
 i111II = 0
 for OO0O00o0 , I111 , Ii1I1 , o000ooOOo , Iii1 in oO0o00oOOooO0 :
  if OO0O00o0 == "3" :
   if I11oOOooo == 0 :
    I1III ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    I11oOOooo = 1
  elif OO0O00o0 == "2" :
   if ooo0O0Oo == 0 :
    I1III ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    ooo0O0Oo = 1
  elif OO0O00o0 == "1" :
   if i111II == 0 :
    I1III ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    i111II = 1
  Iii1 = Iii1 . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  o000ooOOo = o000ooOOo . replace ( " " , "" )
  I1III ( '[COLOR red][B]' + Iii1 + "[/B][/COLOR]- [COLOR blue]" + o000ooOOo + "[/COLOR] | [COLOR white]" + I111 + "vs" + Ii1I1 + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 78 - 78: i11iIiiIii + OOo0o0 + Ooooo / OOo0o0 % Oo0ooO0oo0oO % O00OooO0
def Oo0O0Oo00O ( ) :
 if 9 - 9: OOo0o0 . Oo0oO0ooo - OOoOoo00oo
 O0iII1 = ''
 IiiiI = xbmc . Keyboard ( O0iII1 , 'Enter Search Term' )
 IiiiI . doModal ( )
 if IiiiI . isConfirmed ( ) :
  O0iII1 = IiiiI . getText ( )
  if len ( O0iII1 ) > 1 :
   i1IiiiI1iI = O0iII1 + "!" + iiiii
   I1iii ( "all " + O0iII1 , i1IiiiI1iI , iiiii )
  else : quit ( )
  if 12 - 12: o00
def IiIii1ii ( name , url , iconimage ) :
 if 8 - 8: I1I1i1 + oO0 . Oo0ooO0oo0oO % o0OO0
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 43 - 43: OOoOoo00oo - iIii1I111I11I
def IiiIiI1Ii1i ( text ) :
 if 70 - 70: iIii1I111I11I / OoOooOOOO % IiIIIiI1I1 - ii1IiIi11
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 47 - 47: iIii1I111I11I
 return text
 if 92 - 92: OoOooOOOO + oO0 % o00ooo0
def IIII ( text ) :
 if 23 - 23: Ooooo - OoOooOOOO + ii1IiIi11 - oO0 * oO0 . I11iii11IIi
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 47 - 47: iI1 % Oo0ooO0oo0oO
 return text
 if 11 - 11: Oo0oO0ooo % ii1IiIi11 - I1I1i1 - iI1 + OOo0o0
def Ii1IIIIi1ii1I ( text ) :
 if 98 - 98: iIii1I111I11I + ii1IiIi11 - I1I1i1
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 79 - 79: OoOooOOOO / Ooooo . oO0 - OOoOoo00oo
 return text
 if 47 - 47: I1i1iI1i % o0OO0 * iIii1I111I11I . ii1IiIi11
def OoO000O0Oo ( name , url , iconimage ) :
 if 38 - 38: o0OO0 - O00OooO0 % Ooooo
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 64 - 64: Oo0ooO0oo0oO
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 15 - 15: OOoOoo00oo + OoOooOOOO / OOoOoo00oo / Ooooo
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  I1Iii1I = urlresolver . HostedMediaFile ( url ) . resolve ( )
  iIi11I = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  iIi11I . setPath ( I1Iii1I )
  xbmc . Player ( ) . play ( I1Iii1I , iIi11I , False )
  quit ( )
 else :
  I1Iii1I = url
  iIi11I = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  iIi11I . setPath ( I1Iii1I )
  xbmc . Player ( ) . play ( I1Iii1I , iIi11I , False )
  quit ( )
  if 87 - 87: oooO / Oo0oO0ooo + I11iii11IIi + OoOooOOOO - I1i1iI1i + I11iii11IIi
def i11111IIIII ( ) :
 if 93 - 93: IiIIIiI1I1 . Oo0ooO0oo0oO % i11iIiiIii . oO0 % IiIIIiI1I1 + o0OO0
 o0OOoOO = xbmc . getInfoLabel ( "System.BuildVersion" )
 iII1 = float ( o0OOoOO [ : 4 ] )
 if iII1 >= 11.0 and iII1 <= 11.9 :
  III1I1 = 'Eden'
 elif iII1 >= 12.0 and iII1 <= 12.9 :
  III1I1 = 'Frodo'
 elif iII1 >= 13.0 and iII1 <= 13.9 :
  III1I1 = 'Gotham'
 elif iII1 >= 14.0 and iII1 <= 14.9 :
  III1I1 = 'Helix'
 elif iII1 >= 15.0 and iII1 <= 15.9 :
  III1I1 = 'Isengard'
 elif iII1 >= 16.0 and iII1 <= 16.9 :
  III1I1 = 'Jarvis'
 elif iII1 >= 17.0 and iII1 <= 17.9 :
  III1I1 = 'Krypton'
 else : III1I1 = "Decline"
 if 12 - 12: Oo0ooO0oo0oO % IiIIIiI1I1 % IiIIIiI1I1
 return III1I1
 if 78 - 78: O00OooO0 . oO0 . oooO
def OOOO0OOoO0O0 ( url ) :
 if 97 - 97: iI1
 oOoO0O00oo = urllib2 . Request ( url )
 oOoO0O00oo . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 Oo00OOOOoo0oo = urllib2 . urlopen ( oOoO0O00oo )
 o00OO00OoO = Oo00OOOOoo0oo . read ( )
 Oo00OOOOoo0oo . close ( )
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return o00OO00OoO
 if 93 - 93: OOoOoo00oo % oO0 . o0OO0 / iIii1I111I11I * iI1
def IIIii1II1II ( url ) :
 if 29 - 29: OOo0o0
 oOoO0O00oo = urllib2 . Request ( url )
 oOoO0O00oo . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 Oo00OOOOoo0oo = urllib2 . urlopen ( oOoO0O00oo )
 o00OO00OoO = Oo00OOOOoo0oo . read ( )
 Oo00OOOOoo0oo . close ( )
 return o00OO00OoO
 if 86 - 86: o00 . O00OooO0
def I11iiiii1II ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 2 - 2: I1i1iI1i
 if 60 - 60: I1I1i1
 if 81 - 81: oO0 % ii1IiIi11
 if 87 - 87: Oo0ooO0oo0oO . I1i1iI1i * oO0
 if 100 - 100: I1I1i1 / o00ooo0 - Oo0oO0ooo % ii1IiIi11 - Oo0ooO0oo0oO
def i11II ( ) :
 if 71 - 71: O00OooO0 . Ooooo . I1I1i1
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 68 - 68: i11iIiiIii % iI1 * I1I1i1 * O00OooO0 * o00 + o0OO0
 if os . path . exists ( Oooo000o ) == True :
  for o00OoO0oO00 , iIiii , O0O0o0oO0O00 in os . walk ( Oooo000o ) :
   o0O0oO0 = 0
   o0O0oO0 += len ( O0O0o0oO0O00 )
   if o0O0oO0 > 0 :
    for oOoO in O0O0o0oO0O00 :
     try :
      if ( oOoO . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o00OoO0oO00 , oOoO ) )
     except :
      pass
    for oo0 in iIiii :
     try :
      shutil . rmtree ( os . path . join ( o00OoO0oO00 , oo0 ) )
     except :
      pass
      if 39 - 39: IiIIIiI1I1 . o00
   else :
    pass
    if 45 - 45: iI1 * oO0 / Oo0ooO0oo0oO
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for o00OoO0oO00 , iIiii , O0O0o0oO0O00 in os . walk ( IiIi11iIIi1Ii ) :
   o0O0oO0 = 0
   o0O0oO0 += len ( O0O0o0oO0O00 )
   if o0O0oO0 > 0 :
    for oOoO in O0O0o0oO0O00 :
     try :
      if ( oOoO . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o00OoO0oO00 , oOoO ) )
     except :
      pass
    for oo0 in iIiii :
     try :
      shutil . rmtree ( os . path . join ( o00OoO0oO00 , oo0 ) )
     except :
      pass
      if 77 - 77: Ooooo - oooO
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iiI1iI1I = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 27 - 27: OOoOoo00oo * Ooooo - I1I1i1 + ii1IiIi11 * ii1IiIi11
  for o00OoO0oO00 , iIiii , O0O0o0oO0O00 in os . walk ( iiI1iI1I ) :
   o0O0oO0 = 0
   o0O0oO0 += len ( O0O0o0oO0O00 )
   if 55 - 55: IiIIIiI1I1
   if o0O0oO0 > 0 :
    for oOoO in O0O0o0oO0O00 :
     os . unlink ( os . path . join ( o00OoO0oO00 , oOoO ) )
    for oo0 in iIiii :
     shutil . rmtree ( os . path . join ( o00OoO0oO00 , oo0 ) )
     if 82 - 82: Ooooo - OoOooOOOO + I1I1i1
   else :
    pass
  OO0 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 9 - 9: iI1 % i11iIiiIii / I11iii11IIi
  for o00OoO0oO00 , iIiii , O0O0o0oO0O00 in os . walk ( OO0 ) :
   o0O0oO0 = 0
   o0O0oO0 += len ( O0O0o0oO0O00 )
   if 20 - 20: iI1 * o0OO0 + oooO - I1i1iI1i . oooO
   if o0O0oO0 > 0 :
    for oOoO in O0O0o0oO0O00 :
     os . unlink ( os . path . join ( o00OoO0oO00 , oOoO ) )
    for oo0 in iIiii :
     shutil . rmtree ( os . path . join ( o00OoO0oO00 , oo0 ) )
     if 60 - 60: OOo0o0 . OOo0o0 / iIii1I111I11I
   else :
    pass
    if 45 - 45: o0OO0 . i11iIiiIii % iIii1I111I11I . oO0 % O00OooO0 % Oo0ooO0oo0oO
 OOO00 = IiiI11Iiiii ( )
 if 58 - 58: Oo0ooO0oo0oO . oO0 - i11iIiiIii * Oo0ooO0oo0oO % i11iIiiIii / Oo0oO0ooo
 for oO0oI1I1 in OOO00 :
  O0Oo0 = xbmc . translatePath ( oO0oI1I1 . path )
  if os . path . exists ( O0Oo0 ) == True :
   for o00OoO0oO00 , iIiii , O0O0o0oO0O00 in os . walk ( O0Oo0 ) :
    o0O0oO0 = 0
    o0O0oO0 += len ( O0O0o0oO0O00 )
    if o0O0oO0 > 0 :
     for oOoO in O0O0o0oO0O00 :
      os . unlink ( os . path . join ( o00OoO0oO00 , oOoO ) )
     for oo0 in iIiii :
      shutil . rmtree ( os . path . join ( o00OoO0oO00 , oo0 ) )
      if 80 - 80: Oo0oO0ooo - Oo0ooO0oo0oO . OoOooOOOO + I1I1i1 - Ooooo
    else :
     pass
     if 5 - 5: iIii1I111I11I
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 62 - 62: oO0 . I1i1iI1i . OoOooOOOO . I1I1i1 * iIii1I111I11I
def OOOO ( ) :
 OoI1IiiiIiI = [ ]
 O0OoI1Ii1iIiII = sys . argv [ 2 ]
 if len ( O0OoI1Ii1iIiII ) >= 2 :
  i1iI1 = sys . argv [ 2 ]
  O0oOo00Ooo0o0 = i1iI1 . replace ( '?' , '' )
  if ( i1iI1 [ len ( i1iI1 ) - 1 ] == '/' ) :
   i1iI1 = i1iI1 [ 0 : len ( i1iI1 ) - 2 ]
  i1IiII1i1I = O0oOo00Ooo0o0 . split ( '&' )
  OoI1IiiiIiI = { }
  for ii1iII1II in range ( len ( i1IiII1i1I ) ) :
   iI1ii1ii1I = { }
   iI1ii1ii1I = i1IiII1i1I [ ii1iII1II ] . split ( '=' )
   if ( len ( iI1ii1ii1I ) ) == 2 :
    OoI1IiiiIiI [ iI1ii1ii1I [ 0 ] ] = iI1ii1ii1I [ 1 ]
 return OoI1IiiiIiI
 if 18 - 18: iI1 * iI1 % iI1
def Oo0oOOo ( name , url , mode , iconimage , fanart , description = '' ) :
 if 17 - 17: o0OO0 * oO0 * OOoOoo00oo * o00 * oooO % o00ooo0
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 IIiIi1iI1iII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OoOo00o = True
 iIi11I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 iIi11I . setProperty ( "fanart_Image" , fanart )
 iIi11I . setProperty ( "icon_Image" , iconimage )
 OoOo00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIiIi1iI1iII , listitem = iIi11I , isFolder = True )
 return OoOo00o
 if 30 - 30: oO0 . oooO / oooO * i11iIiiIii
def I1III ( name , url , mode , iconimage , fanart , description = '' ) :
 if 46 - 46: I1I1i1 * I11iii11IIi % iI1 + o0OO0 * O00OooO0
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 IIiIi1iI1iII = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OoOo00o = True
 iIi11I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 iIi11I . setProperty ( "fanart_Image" , fanart )
 iIi11I . setProperty ( "icon_Image" , iconimage )
 OoOo00o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIiIi1iI1iII , listitem = iIi11I , isFolder = False )
 return OoOo00o
 if 34 - 34: I1I1i1
i1iI1 = OOOO ( ) ; i1IiiiI1iI = None ; i1OOO = None ; I11i11i1 = None ; OOOii1i1iiI = None ; IIiIi1iI = None ; i1II1Iiii1I11 = None
try : OOOii1i1iiI = urllib . unquote_plus ( i1iI1 [ "site" ] )
except : pass
try : i1IiiiI1iI = urllib . unquote_plus ( i1iI1 [ "url" ] )
except : pass
try : i1OOO = urllib . unquote_plus ( i1iI1 [ "name" ] )
except : pass
try : I11i11i1 = int ( i1iI1 [ "mode" ] )
except : pass
try : IIiIi1iI = urllib . unquote_plus ( i1iI1 [ "iconimage" ] )
except : pass
try : i1II1Iiii1I11 = urllib . unquote_plus ( i1iI1 [ "fanart" ] )
except : pass
if 94 - 94: o00ooo0 * o00ooo0 % o00 + OoOooOOOO
if I11i11i1 == None or i1IiiiI1iI == None or len ( i1IiiiI1iI ) < 1 : iii11 ( )
elif I11i11i1 == 1 : I1iI1iIi111i ( i1OOO , i1IiiiI1iI )
elif I11i11i1 == 2 : OoO000O0Oo ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 3 : oO00oooOOoOo0 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 4 : PLAYSD ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 8 : iI1111iiii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 9 : AUTO_UPDATER ( i1OOO )
elif I11i11i1 == 10 : IiI1iII1II111 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 11 : ooO ( )
elif I11i11i1 == 12 : OOOoOOO0oO ( i1IiiiI1iI )
elif I11i11i1 == 19 : I1iiIIIi11 ( i1IiiiI1iI )
elif I11i11i1 == 20 : I1iii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 21 : OoO0ooO ( i1IiiiI1iI )
elif I11i11i1 == 22 : oOOoo ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 23 : Oooo0 ( )
elif I11i11i1 == 24 : OoO ( )
elif I11i11i1 == 25 : Ii1iI111II1I1 ( )
elif I11i11i1 == 26 : I11 ( )
elif I11i11i1 == 30 : i1I1i111Ii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 40 : Ii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 41 : O00ooOo ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 50 : iIi ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 51 : Ooooo0OoO0 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 60 : IIiIiiiIIIIi1 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 61 : IIIiiiI ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 70 : ooO0oo0o0 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 71 : iIi1I1 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 80 : I1i111i ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 100 : Oo0O0Oo00O ( )
elif I11i11i1 == 500 : i11II ( )
elif I11i11i1 == 201 : o0ooooO0o0O ( )
elif I11i11i1 == 202 : III1i1i11i ( i1IiiiI1iI )
elif I11i11i1 == 203 : IIii1111 ( i1IiiiI1iI )
elif I11i11i1 == 204 : I1 ( i1IiiiI1iI )
elif I11i11i1 == 205 : ii1 ( i1IiiiI1iI )
elif I11i11i1 == 206 : I1ii1ii11i1I ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 210 : ii1I1i1iiiI ( i1IiiiI1iI )
elif I11i11i1 == 220 : oOo0OOOO0O00oO ( i1IiiiI1iI )
elif I11i11i1 == 221 : I11i1II ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 800 : IiIii1ii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif I11i11i1 == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 28 - 28: Oo0oO0ooo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )