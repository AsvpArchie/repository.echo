import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluX21lbnUueG1s' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = xbmc . translatePath ( 'special://home/addons/program.plexus' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
Oooo000o = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oo0O = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
OOo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
Ii1IIii11 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 55 - 55: i1111 - i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
oO000OoOoo00o = plugintools . get_setting ( "scrape1" )
iiiI11 = plugintools . get_setting ( "scrape2" )
OOooO = plugintools . get_setting ( "scrape3" )
if 58 - 58: i11iiII + OooooO0oOO + oOo0 / oo0Ooo0
I1I11I1I1I = IiiIII111iI + '|SPLIT|' + o0O
checker . check ( I1I11I1I1I )
if 90 - 90: i1IIiiiii + i1iIIIiI1I - OoO000 % OooOoO0Oo + iiIIiIiIi
if not os . path . isfile ( ooo0OO ) :
 plugintools . open_settings_dialog ( )
 if 38 - 38: i1IIiiiii / I11i1i11i1I
if not os . path . exists ( IiII ) :
 os . makedirs ( IiII )
 if 76 - 76: oooO0oo0oOOOO / oo0ooO0oOOOOo . i1IIi11111i * i1IIiiiii - oOo0
if not os . path . isfile ( i1i1II ) :
 Oooo = open ( i1i1II , 'w' )
 if 67 - 67: oOo0 / i111I % oo0Ooo0 - ooO0oo0oO0
if not os . path . isfile ( iI1Ii11111iIi ) :
 Oooo = open ( iI1Ii11111iIi , 'w' )
 if 82 - 82: i11iIiiIii . oOo0 / I11i1i11i1I * oooO0oo0oOOOO % OooooO0oOO % ooO0oo0oO0
if not os . path . isfile ( O0oo0OO0 ) :
 Oooo = open ( O0oo0OO0 , 'w' )
 if 78 - 78: ooO0oo0oO0 - i1IIiiiii * oo + oo0ooO0oOOOOo + i1iIIIiI1I + i1iIIIiI1I
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 11 - 11: i1iIIIiI1I - oo % iiIIiIiIi % i1iIIIiI1I / OOO0O - oo
class o0o0oOOOo0oo ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 80 - 80: oo0Ooo0 * i11iIiiIii / OooOoO0Oo
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 9 - 9: i1IIiiiii + OooooO0oOO % i1IIiiiii + II1Ii1iI1i . oOo0
III1i1i = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 26 - 26: i111I
class IiiI11Iiiii :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 18 - 18: oo0ooO0oOOOOo
  if 28 - 28: oOo0 - OoO000 . OoO000 + OOO0O - i111I + oooO0oo0oOOOO
  if 95 - 95: oo % OooooO0oOO . oooO0oo0oOOOO
  if 15 - 15: iiIIiIiIi / i1IIiiiii . i1IIiiiii - II1Ii1iI1i
def o00oOO0 ( ) :
 oOoo = 5
 iIii11I = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 OOO0OOO00oo = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 31 - 31: i1111 - oOo0 . OooOoO0Oo % OOO0O - oooO0oo0oOOOO
 iii11 = [ ]
 if 58 - 58: oOo0 * i11iIiiIii / OOO0O % OooOoO0Oo - i11iiII / OooooO0oOO
 for ii11i1 in range ( oOoo ) :
  iii11 . append ( IiiI11Iiiii ( iIii11I [ ii11i1 ] , OOO0OOO00oo [ ii11i1 ] ) )
  if 29 - 29: i11iiII % i1IIi11111i + iiIIiIiIi / oo0ooO0oOOOOo + oOo0 * oo0ooO0oOOOOo
 return iii11
 if 42 - 42: i1IIiiiii + OooooO0oOO
def o0O0o0Oo ( ) :
 if 16 - 16: oooO0oo0oOOOO - OooOoO0Oo * ooO0oo0oO0 + i1iIIIiI1I
 Ii11iII1 = Oo0O0O0ooO0O ( OOo )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = i1i1II
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 70 - 70: OoO000 * I11i1i11i1I * oo0Ooo0 / i1IIiiiii
 Ii11iII1 = Oo0O0O0ooO0O ( iiI1iIiI )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = iI1Ii11111iIi
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 88 - 88: oooO0oo0oOOOO
 Ii11iII1 = Oo0O0O0ooO0O ( Ii1IIii11 )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = O0oo0OO0
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 64 - 64: oo0Ooo0 * oooO0oo0oOOOO + OoO000 - oOo0 + i11iIiiIii * i1IIiiiii
 iII = o0 ( II1 )
 ooOooo000oOO = II1
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 80 - 80: OooooO0oOO + oOo0 - oOo0 % i1iIIIiI1I
  if '<search>display</search>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 97 - 97: iiIIiIiIi % i1iIIIiI1I * i1IIiiiii + oo0ooO0oOOOOo . oOo0 + oOo0
  elif '<arenavision>display</arenavision>' in Oo0OoO00oOO0o :
   if os . path . exists ( oO00oOo ) :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    II11i1I11Ii1i ( OoOO0oo0o , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
    if 59 - 59: ooO0oo0oO0 * i11iIiiIii / i11iiII * II1Ii1iI1i * oooO0oo0oOOOO
  elif '<vip>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 83 - 83: oo / OooOoO0Oo . OOO0O / OoO000 . OOO0O . oOo0
  elif '<divider>null</divider>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( OoOO0oo0o , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 96 - 96: I11i1i11i1I
   if 45 - 45: oooO0oo0oOOOO * oo0ooO0oOOOOo % I11i1i11i1I * i111I + i1iIIIiI1I . OOO0O
   if 67 - 67: i11iIiiIii - II1Ii1iI1i % i11iiII . oooO0oo0oOOOO
   if 77 - 77: OoO000 / i1IIi11111i
   if 15 - 15: OoO000 . ooO0oo0oO0 . i111I / i11iIiiIii - i1IIiiiii . II1Ii1iI1i
   if 33 - 33: oo0Ooo0 . oo0ooO0oOOOOo
  elif '<m3ulists>display</m3ulists>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 75 - 75: oo0ooO0oOOOOo % oo0ooO0oOOOOo . OooOoO0Oo
   if 5 - 5: oo0ooO0oOOOOo * iiIIiIiIi + OOO0O . oOo0 + OOO0O
   if 91 - 91: oooO0oo0oOOOO
   if 61 - 61: i1111
   if 64 - 64: iiIIiIiIi / OOO0O - oooO0oo0oOOOO - oo0Ooo0
   if 86 - 86: oo0Ooo0 % OOO0O / i1IIi11111i / OOO0O
   if 42 - 42: oo
   if 67 - 67: OooOoO0Oo . i1iIIIiI1I . oooO0oo0oOOOO
   if 10 - 10: i11iiII % i11iiII - ooO0oo0oO0 / oOo0 + i1IIiiiii
   if 87 - 87: OooooO0oOO * i11iiII + oOo0 / ooO0oo0oO0 / i1iIIIiI1I
   if 37 - 37: i1iIIIiI1I - iiIIiIiIi * OooooO0oOO % i11iIiiIii - OooOoO0Oo
   if 83 - 83: oo0Ooo0 / i1IIi11111i
   if 34 - 34: OoO000
   if 57 - 57: OooooO0oOO . oo0Ooo0 . II1Ii1iI1i
   if 42 - 42: oo0Ooo0 + i11iiII % oooO0oo0oOOOO
   if 6 - 6: OooooO0oOO
   if 68 - 68: OOO0O - oo
   if 28 - 28: oo . oOo0 / oOo0 + I11i1i11i1I . i11iiII
   if 1 - 1: ooO0oo0oO0 / i1111
   if 33 - 33: oo0Ooo0
   if 18 - 18: oo0ooO0oOOOOo % i1iIIIiI1I * oooO0oo0oOOOO
   if 87 - 87: i11iIiiIii
  elif '<sportsdevil>' in Oo0OoO00oOO0o :
   OO0Oooo0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000oo = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    IIi1I11I1II = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    OooOoooOo = IIi1I11I1II
    ii11IIII11I = "/"
    if not OooOoooOo . endswith ( ii11IIII11I ) :
     OOooo = OooOoooOo + "/"
    else :
     OOooo = OooOoooOo
    iII = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( OoOO0oo0o ) + '%26url=' + O000oo
    O000oo = iII + '%26referer=' + OOooo
    O0oOoOO ( OoOO0oo0o , O000oo , 4 , Oo0oOOOoOooOo , oOooOOOoOo )
   elif len ( OO0Oooo0 ) > 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O0oOoOO ( OoOO0oo0o , ooOooo000oOO + 'NOTPLAY' , 8 , Oo0oOOOoOooOo , oOooOOOoOo )
  elif '<plexus>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   O0oOoOO ( OoOO0oo0o , ooOooo000oOO + 'NOTPLAY' , 7 , Oo0oOOOoOooOo , oOooOOOoOo )
  elif '<rutubeplaylist>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   II11i1I11Ii1i ( OoOO0oo0o , ooOooo000oOO , 90 , Oo0oOOOoOooOo , oOooOOOoOo )
  elif '<folder>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for OoOO0oo0o , O000oo , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    II11i1I11Ii1i ( OoOO0oo0o , O000oo , 1 , Oo0oOOOoOooOo , oOooOOOoOo )
  elif '<m3u>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for OoOO0oo0o , O000oo , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    II11i1I11Ii1i ( OoOO0oo0o , O000oo , 10 , Oo0oOOOoOooOo , oOooOOOoOo )
  else :
   OO0Oooo0 = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
    OOoO00 = len ( Oo0oOOo )
    for OoOO0oo0o , O000oo , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
     O0oOoOO ( OoOO0oo0o , O000oo , 2 , Oo0oOOOoOooOo , oOooOOOoOo )
   elif len ( OO0Oooo0 ) > 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O0oOoOO ( OoOO0oo0o , II1 , 3 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 40 - 40: i1IIi11111i * i1IIiiiii + oOo0 % i1iIIIiI1I
 OOOOOoo0 = open ( IIi1IiiiI1Ii ) . read ( )
 ii1 = OOOOOoo0 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo0oOOo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ii1 ) )
 for Oo0OoO00oOO0o in Oo0oOOo :
  I1iI1iIi111i = float ( Oo0OoO00oOO0o )
 OOOOOoo0 = open ( I11i11Ii ) . read ( )
 ii1 = OOOOOoo0 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo0oOOo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ii1 ) )
 for Oo0OoO00oOO0o in Oo0oOOo :
  iiIi1IIi1I = float ( Oo0OoO00oOO0o )
  if 84 - 84: iiIIiIiIi * i1111 + I11i1i11i1I
 O0oOoOO ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( I1iI1iIi111i ) + "[/COLOR]" , 'url' , 999 , iiiii , oOooOOOoOo , '' )
 O0oOoOO ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( iiIi1IIi1I ) + "[/COLOR]" , 'url' , 999 , iiiii , oOooOOOoOo , '' )
 if 53 - 53: i1iIIIiI1I % i1111 . OoO000 - ooO0oo0oO0 - OoO000 * i1111
 ooO0oOOooOo0 = i1I1ii11i1Iii ( )
 if 26 - 26: oo0Ooo0 - ooO0oo0oO0 - i1IIi11111i / oo . OOO0O % ooO0oo0oO0
 if ooO0oOOooOo0 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif ooO0oOOooOo0 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 91 - 91: oo0ooO0oOOOOo . ooO0oo0oO0 / OooooO0oOO + II1Ii1iI1i
def I1i ( name , url ) :
 if 53 - 53: i11iiII * OOO0O + iiIIiIiIi - i1111
 hash = [ ]
 ooOooo000oOO = url
 iII = o0 ( url )
 if 2 - 2: oo0Ooo0 + i1IIiiiii - i1IIi11111i % oo0ooO0oOOOOo . i1iIIIiI1I
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 18 - 18: oOo0 + i1iIIIiI1I - i1IIiiiii . i1111 + i11iIiiIii
  if '<search>' in Oo0OoO00oOO0o :
   if 20 - 20: OooOoO0Oo
   OO0Oooo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = name + "!" + url + "!" + Oo0oOOOoOooOo
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    II11i1I11Ii1i ( name , url , 20 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
    if 52 - 52: i1111 - i111I % i1IIiiiii + i1IIi11111i * I11i1i11i1I . OoO000
   elif len ( OO0Oooo0 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = ooOooo000oOO + "!" + name + "!" + Oo0oOOOoOooOo
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    II11i1I11Ii1i ( name , url , 22 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
    if 75 - 75: iiIIiIiIi + OOO0O + oo0ooO0oOOOOo * oo0Ooo0 % OooooO0oOO . i1iIIIiI1I
  elif '<regex>' in Oo0OoO00oOO0o :
   oO = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Oo0OoO00oOO0o )
   oO = '' . join ( oO )
   I1Ii1I1 = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( oO )
   oO = urllib . quote_plus ( oO )
   if 28 - 28: oooO0oo0oOOOO * I11i1i11i1I - oOo0 % ooO0oo0oO0 * i1IIiiiii - i11iIiiIii
   IIII11 = hashlib . md5 ( )
   for IIIIii1I in oO : IIII11 . update ( str ( IIIIii1I ) )
   IIII11 = str ( IIII11 . hexdigest ( ) )
   if 39 - 39: i1111 / iiIIiIiIi + OooOoO0Oo / OOO0O
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Oo0OoO00oOO0o = re . sub ( '<regex>.+?</regex>' , '' , Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = re . sub ( '<link></link>' , '' , Oo0OoO00oOO0o )
   if 13 - 13: OoO000 + oooO0oo0oOOOO + i1iIIIiI1I % i1IIi11111i / oo0ooO0oOOOOo . OoO000
   name = re . sub ( '<meta>.+?</meta>' , '' , Oo0OoO00oOO0o )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 86 - 86: OooooO0oOO * oo0ooO0oOOOOo % II1Ii1iI1i . i1IIiiiii . i11iIiiIii
   try : oOOoo00O00o = re . findall ( '<date>(.+?)</date>' , Oo0OoO00oOO0o ) [ 0 ]
   except : oOOoo00O00o = ''
   if re . search ( r'\d+' , oOOoo00O00o ) : name += ' [COLOR red] Updated %s[/COLOR]' % oOOoo00O00o
   if 98 - 98: oOo0 + OoO000 + OooooO0oOO % i111I
   try : oooooo0O000o = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Oo0OoO00oOO0o ) [ 0 ]
   except : oooooo0O000o = iiiii
   if 64 - 64: i1IIi11111i . oo0ooO0oOOOOo - OooOoO0Oo / i111I
   try : O0O0ooOOO = re . findall ( '<fanart>(.+?)</fanart>' , Oo0OoO00oOO0o ) [ 0 ]
   except : O0O0ooOOO = O0O0OO0O0O0
   if 77 - 77: OOO0O - i1111 - iiIIiIiIi
   try : IiiiIIiIi1 = re . findall ( '<meta>(.+?)</meta>' , Oo0OoO00oOO0o ) [ 0 ]
   except : IiiiIIiIi1 = '0'
   if 74 - 74: ooO0oo0oO0 * i11iiII + OOO0O / II1Ii1iI1i / i1111 . I11i1i11i1I
   try : url = re . findall ( '<link>(.+?)</link>' , Oo0OoO00oOO0o ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % IiiiIIiIi1 )
   url = '<preset>search</preset>%s' % IiiiIIiIi1 if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % IiiiIIiIi1 )
   url = '<preset>searchsd</preset>%s' % IiiiIIiIi1 if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 62 - 62: i111I * i1IIi11111i
   if not oO == '' :
    hash . append ( { 'regex' : IIII11 , 'response' : oO } )
    url += '|regex=%s' % oO
    if 58 - 58: OOO0O % oo0ooO0oOOOOo
   O0oOoOO ( name , url , 30 , oooooo0O000o , O0O0ooOOO )
   if 50 - 50: OooOoO0Oo . oo0ooO0oOOOOo
  elif '<sportsdevil>' in Oo0OoO00oOO0o :
   OO0Oooo0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     IIi1I11I1II = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : IIi1I11I1II = "None"
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    OooOoooOo = IIi1I11I1II
    ii11IIII11I = "/"
    if not OooOoooOo . endswith ( ii11IIII11I ) :
     OOooo = OooOoooOo + "/"
    else :
     OOooo = OooOoooOo
    iII = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = iII + '%26referer=' + OOooo
    O0oOoOO ( name , url , 2 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 97 - 97: oooO0oo0oOOOO + OOO0O
   elif len ( OO0Oooo0 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    O0oOoOO ( name , ooOooo000oOO + 'NOTPLAY' , 8 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 89 - 89: oo0ooO0oOOOOo + oo * oo0Ooo0 * i1IIiiiii
  elif '<plexus>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   O0oOoOO ( name , ooOooo000oOO + 'NOTPLAY' , 7 , Oo0oOOOoOooOo , oOooOOOoOo )
   if 37 - 37: i111I - oooO0oo0oOOOO - oo0ooO0oOOOOo
  elif '<rutubeplaylist>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   II11i1I11Ii1i ( name , ooOooo000oOO , 90 , Oo0oOOOoOooOo , oOooOOOoOo )
   if 77 - 77: oOo0 * ooO0oo0oO0
  elif '<folder>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    II11i1I11Ii1i ( name , url , 1 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 98 - 98: i1IIi11111i % i1IIiiiii * i111I
  elif '<m3u>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    II11i1I11Ii1i ( name , url , 10 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 51 - 51: ooO0oo0oO0 . OOO0O / OooooO0oOO + oo0ooO0oOOOOo
  elif '<rutube>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?rutube>(.+?)</rutube>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    ooOooo000oOO = 'https://rutube.ru/play/embed/' + url + '?wmode=opaque&fakeFullscreen=1'
    II11i1I11Ii1i ( name , ooOooo000oOO , 2 , Oo0oOOOoOooOo , oOooOOOoOo )
  else :
   OO0Oooo0 = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
    OOoO00 = len ( Oo0oOOo )
    for name , url , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
     O0oOoOO ( name , url , 2 , Oo0oOOOoOooOo , oOooOOOoOo )
   elif len ( OO0Oooo0 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    O0oOoOO ( name , ooOooo000oOO , 3 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 33 - 33: iiIIiIiIi . i1111 % i1iIIIiI1I + oo0ooO0oOOOOo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 71 - 71: I11i1i11i1I % oOo0
def O00oO000O0O ( name , url , iconimage ) :
 I1i1i1iii = [ ]
 I1111i = [ ]
 iIIii = [ ]
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o00O0O ) [ 0 ]
 OO0Oooo0 = re . compile ( '<link>(.+?)</link>' ) . findall ( o00O0O )
 IIIIii1I = 1
 for ii1iii1i in OO0Oooo0 :
  Iii1I1111ii = ii1iii1i
  if '(' in ii1iii1i :
   ii1iii1i = ii1iii1i . split ( '(' ) [ 0 ]
   ooOoO00 = str ( Iii1I1111ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( ooOoO00 )
  else :
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( 'Link ' + str ( IIIIii1I ) )
  IIIIii1I = IIIIii1I + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 Ii1IIiI1i = O00ooooo00 . select ( name , I1111i )
 if Ii1IIiI1i < 0 :
  quit ( )
 else :
  url = I1i1i1iii [ Ii1IIiI1i ]
  print url
  if 78 - 78: i11iiII
 url = I1i1i1iii [ Ii1IIiI1i ]
 name = I1111i [ Ii1IIiI1i ]
 o0Oo0oO0oOO00 ( name , url , iiiii )
 if 92 - 92: i111I * OooOoO0Oo
def o0000oO ( name , url , iconimage ) :
 if 11 - 11: iiIIiIiIi / OOO0O - OoO000 * i111I + i111I . OOO0O
 I1i1i1iii = [ ]
 I1111i = [ ]
 iIIii = [ ]
 i1I1i111Ii = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 OO0Oooo0 = re . compile ( '<plexus>(.+?)</plexus>' ) . findall ( o00O0O )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o00O0O ) [ 0 ]
 if 67 - 67: i1IIi11111i . II1Ii1iI1i
 i1i1iI1iiiI = "plugin://program.plexus/?url="
 Ooo0oOooo0 = "&mode=1&name=acestream+"
 IIIIii1I = 0
 if 61 - 61: OOO0O - oOo0 - II1Ii1iI1i
 for ii1iii1i in OO0Oooo0 :
  IIIIii1I = IIIIii1I + 1
  if 25 - 25: oooO0oo0oOOOO * oo0Ooo0 + i11iiII . oo0ooO0oOOOOo . oo0ooO0oOOOOo
  Iii1I1111ii = ii1iii1i
  if '(' in ii1iii1i :
   ii1iii1i = ii1iii1i . split ( '(' ) [ 0 ]
   ooOoO00 = str ( Iii1I1111ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( ooOoO00 )
   i1I1i111Ii . append ( 'Stream ' + str ( IIIIii1I ) )
  else :
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( 'Link ' + str ( IIIIii1I ) )
   ooOoO00 = name
   if 58 - 58: i1IIi11111i
   if 53 - 53: II1Ii1iI1i
 if IIIIii1I > 1 :
  O00ooooo00 = xbmcgui . Dialog ( )
  Ii1IIiI1i = O00ooooo00 . select ( name , I1111i )
  if Ii1IIiI1i < 0 :
   quit ( )
  else :
   o0OOOoO0 = I1i1i1iii [ Ii1IIiI1i ]
   if not 'acestream://' in o0OOOoO0 :
    o0OOOoO0 = 'acestream://' + o0OOOoO0
   url = i1i1iI1iiiI + o0OOOoO0 + Ooo0oOooo0 + I1111i [ Ii1IIiI1i ]
   name = I1111i [ Ii1IIiI1i ]
 else :
  o0OOOoO0 = ii1iii1i
  if not 'acestream://' in o0OOOoO0 :
   o0OOOoO0 = 'acestream://' + o0OOOoO0
  url = i1i1iI1iiiI + o0OOOoO0 + Ooo0oOooo0 + ooOoO00
  name = ooOoO00
  if 73 - 73: oo0Ooo0 % i11iIiiIii - i1IIi11111i
 o0Oo0oO0oOO00 ( name , url , iiiii )
 if 7 - 7: oooO0oo0oOOOO * i11iIiiIii * i1IIiiiii + iiIIiIiIi % oo - iiIIiIiIi
def II1IIIIiII1i ( name , url , iconimage ) :
 if 1 - 1: i1111
 I1i1i1iii = [ ]
 I1111i = [ ]
 iIIii = [ ]
 i1I1i111Ii = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 OO0Oooo0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( o00O0O )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o00O0O ) [ 0 ]
 if 68 - 68: i1iIIIiI1I - i1IIi11111i / OooOoO0Oo / oo0Ooo0
 I11iiii = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 60 - 60: oo0Ooo0 . II1Ii1iI1i + OoO000 / oo0ooO0oOOOOo . i1111
 IIIIii1I = 1
 if 82 - 82: i11iiII / i1IIi11111i % ooO0oo0oO0 / II1Ii1iI1i - i1IIi11111i
 for ii1iii1i in OO0Oooo0 :
  Iii1I1111ii = ii1iii1i
  if '(' in ii1iii1i :
   ii1iii1i = ii1iii1i . split ( '(' ) [ 0 ]
   ooOoO00 = str ( Iii1I1111ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( ooOoO00 )
   i1I1i111Ii . append ( 'Stream ' + str ( IIIIii1I ) )
  else :
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( 'Link ' + str ( IIIIii1I ) )
   if 7 - 7: OooOoO0Oo * oo - iiIIiIiIi + oOo0 * i1IIi11111i % oo
  IIIIii1I = IIIIii1I + 1
  if 15 - 15: OOO0O % i1IIi11111i * oo0Ooo0
 name = '[COLOR red]' + name + '[/COLOR]'
 if 81 - 81: iiIIiIiIi - ooO0oo0oO0 - II1Ii1iI1i / OooOoO0Oo - oooO0oo0oOOOO * oo0Ooo0
 O00ooooo00 = xbmcgui . Dialog ( )
 Ii1IIiI1i = O00ooooo00 . select ( name , I1111i )
 if Ii1IIiI1i < 0 :
  quit ( )
 else :
  OooOoooOo = I1111i [ Ii1IIiI1i ]
  ii11IIII11I = "/"
  if not OooOoooOo . endswith ( ii11IIII11I ) :
   OOooo = OooOoooOo + "/"
  else :
   OOooo = OooOoooOo
  url = I11iiii + I1i1i1iii [ Ii1IIiI1i ] + "%26referer=" + OOooo
  if 20 - 20: OooooO0oOO % OoO000
 name = I1111i [ Ii1IIiI1i ]
 o0Oo0oO0oOO00 ( name , url , iiiii )
 if 19 - 19: i11iiII % OoO000 + iiIIiIiIi / OooOoO0Oo . iiIIiIiIi
def IiIi1I1 ( name , url , iconimage ) :
 if 39 - 39: i1111 + OOO0O - iiIIiIiIi . OOO0O
 OOOooo = [ ]
 OooO0OO = [ ]
 if 69 - 69: iiIIiIiIi % OooooO0oOO
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 OO0Oooo0 = re . compile ( '<rutubeplaylist>(.+?)</rutubeplaylist>' ) . findall ( o00O0O )
 if 50 - 50: i111I % oo0Ooo0
 for ii1iii1i in OO0Oooo0 :
  Iii1I1111ii = ii1iii1i
  if '(' in ii1iii1i :
   ii1iii1i = ii1iii1i . split ( '(' ) [ 0 ]
   ooOoO00 = str ( Iii1I1111ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   OOOooo . append ( ooOoO00 )
   OooO0OO . append ( ii1iii1i )
   IIii1111 = list ( zip ( OOOooo , OooO0OO ) )
   if 42 - 42: oo0Ooo0 / oo0ooO0oOOOOo . OooooO0oOO + OooooO0oOO % OOO0O + i11iIiiIii
 oo0o0000 = sorted ( IIii1111 )
 if 11 - 11: ooO0oo0oO0
 for IiIIII1i11I , url in oo0o0000 :
  OOO = o0 ( url )
  Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   iII1 = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
   if IiIIII1i11I . lower ( ) == "all" :
    iII1 = iII1 . replace ( '.' , ' ' )
    O0oOoOO ( iII1 , url , 2 , iconimage , iconimage , '' )
   elif IiIIII1i11I . lower ( ) in iII1 . lower ( ) :
    iII1 = iII1 . replace ( '.' , ' ' )
    O0oOoOO ( iII1 , url , 2 , iconimage , iconimage , '' )
    if 57 - 57: oo0ooO0oOOOOo . II1Ii1iI1i . OoO000 * i11iIiiIii + OooOoO0Oo . OoO000
 try :
  Oo0oOOo = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( OOO )
  oo0O00Oooo0O0 = str ( Oo0oOOo )
  I11 = re . compile ( 'href="(.+?)"' ) . findall ( oo0O00Oooo0O0 ) [ 1 ]
  url = I11 + "|SPLIT|" + IiIIII1i11I
  II11i1I11Ii1i ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 51 - 51: oo . i1IIi11111i * iiIIiIiIi % i1IIiiiii + i1111 . iiIIiIiIi
def iI1IiI11ii1I1 ( name , url , iconimage ) :
 if 32 - 32: i11iIiiIii
 url , IiIIII1i11I = url . split ( "|SPLIT|" )
 if 31 - 31: ooO0oo0oO0 / oo / i11iiII
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  iII1 = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
  if IiIIII1i11I . lower ( ) == "all" :
   iII1 = iII1 . replace ( '.' , ' ' )
   O0oOoOO ( iII1 , url , 2 , iconimage , iconimage , '' )
  elif IiIIII1i11I . lower ( ) in iII1 . lower ( ) :
   iII1 = iII1 . replace ( '.' , ' ' )
   O0oOoOO ( iII1 , url , 2 , iconimage , iconimage , '' )
   if 41 - 41: I11i1i11i1I
 try :
  Oo0oOOo = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( OOO )
  oo0O00Oooo0O0 = str ( Oo0oOOo )
  I11 = re . compile ( 'href="(.+?)"' ) . findall ( oo0O00Oooo0O0 ) [ 1 ]
  url = I11 + "|SPLIT|" + IiIIII1i11I
  II11i1I11Ii1i ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 10 - 10: I11i1i11i1I / I11i1i11i1I / OooOoO0Oo . OooOoO0Oo
def OOoo ( name , url , iconimage ) :
 if 50 - 50: oo
 O0o0 , ii11i1 = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 O0o0 += urllib . unquote_plus ( ii11i1 )
 url = regex . resolve ( O0o0 )
 if 43 - 43: i1111 . OooooO0oOO / i11iiII
 o0Oo0oO0oOO00 ( name , url , iconimage )
 if 20 - 20: i1IIi11111i
def o0oO000oo ( ) :
 if 95 - 95: iiIIiIiIi / iiIIiIiIi
 O0oOoOO ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 O0oOoOO ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 O0oOoOO ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 II11i1I11Ii1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 II11i1I11Ii1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 30 - 30: i11iiII + I11i1i11i1I / I11i1i11i1I % i11iiII . i11iiII
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 55 - 55: iiIIiIiIi - oo0Ooo0 + i1111 + i1iIIIiI1I % i1IIiiiii
def iiI11i1II ( ) :
 if 51 - 51: oo0ooO0oOOOOo % I11i1i11i1I % oo0ooO0oOOOOo * oooO0oo0oOOOO - oOo0 % I11i1i11i1I
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 65 - 65: iiIIiIiIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 68 - 68: iiIIiIiIi % i11iIiiIii + i1111
def OOOO0OOO ( ) :
 if 3 - 3: oo
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 97 - 97: OooOoO0Oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 15 - 15: II1Ii1iI1i + OOO0O
def iii1i1I1i1 ( ) :
 if 25 - 25: i11iiII . iiIIiIiIi
 IIIIii1I = 0
 OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IIIIii1I = IIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  O000oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( IIIIii1I ) + '[/COLOR]' , O000oo , 12 , iiiii , O0O0OO0O0O0 )
  if 24 - 24: OooooO0oOO / i11iIiiIii + OooooO0oOO
 OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IIIIii1I = IIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  O000oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( IIIIii1I ) + '[/COLOR]' , O000oo , 12 , iiiii , O0O0OO0O0O0 )
  if 20 - 20: oo0Ooo0 + i1IIiiiii / oooO0oo0oOOOO % ooO0oo0oO0
 OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IIIIii1I = IIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  O000oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( IIIIii1I ) + '[/COLOR]' , O000oo , 12 , iiiii , O0O0OO0O0O0 )
  if 88 - 88: OOO0O / i1111
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 87 - 87: i11iiII - i11iiII - i1iIIIiI1I + OooooO0oOO
def OOoooiIIiIiI1I1 ( url ) :
 if 56 - 56: i1IIi11111i . oooO0oo0oOOOO + I11i1i11i1I
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 if 1 - 1: i1iIIIiI1I
 for Oo0OoO00oOO0o in Oo0oOOo :
  OoOO0oo0o = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  Oo0oOOOoOooOo = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 12 , Oo0oOOOoOooOo , O0O0OO0O0O0 )
  if 97 - 97: oOo0 + i1iIIIiI1I + oooO0oo0oOOOO + i11iIiiIii
 try :
  oOoO0 = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( OOO ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR yellow]Next Page -->[/COLOR]' , oOoO0 , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 77 - 77: ooO0oo0oO0 . i1iIIIiI1I % i1iIIIiI1I + i11iIiiIii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 72 - 72: ooO0oo0oO0 * i1IIiiiii % iiIIiIiIi / oo
def I11i1II ( ) :
 if 72 - 72: ooO0oo0oO0 . II1Ii1iI1i / I11i1i11i1I . i1111
 OOO = o0 ( 'http://arenavision.in' )
 Oo0oOOo = re . compile ( '<li class="(.+?)/li>' , re . DOTALL ) . findall ( OOO )
 if 54 - 54: i1111 % i1111
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'leaf"><a href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000oo = re . compile ( 'leaf"><a href="(.+?)">.+?</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   if 'av' in O000oo :
    O000oo = 'http://arenavision.in' + O000oo
    O0oOoOO ( '[COLOR white]' + OoOO0oo0o + '[/COLOR]' , O000oo , 96 , iiiii , O0O0OO0O0O0 )
  except : pass
  if 86 - 86: oooO0oo0oOOOO % i1IIiiiii * iiIIiIiIi * ooO0oo0oO0 * II1Ii1iI1i * oo0Ooo0
 ooO0oOOooOo0 = i1I1ii11i1Iii ( )
 if 83 - 83: OOO0O % i1111 - OOO0O + OoO000 - oooO0oo0oOOOO
 if ooO0oOOooOo0 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif ooO0oOOooOo0 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 52 - 52: I11i1i11i1I * iiIIiIiIi
def i11IIIiIiIi ( name , url , iconimage ) :
 if 27 - 27: i11iiII + OOO0O - oOo0 + oooO0oo0oOOOO . i1IIiiiii
 try :
  OOO = o0 ( url )
  Oo0oOOo = re . compile ( 'this.loadPlayer(.+?),' , re . DOTALL ) . findall ( OOO ) [ 0 ]
  url = Oo0oOOo . replace ( '(' , '' ) . replace ( ')' , '' ) . replace ( '"' , '' ) . replace ( ' ' , '' )
  if 46 - 46: OoO000
  ooOooo000oOO = 'plugin://program.plexus/?url=acestream://' + str ( url ) + '&mode=1&name=acestream+' + str ( name )
  if 45 - 45: iiIIiIiIi
  o0Oo0oO0oOO00 ( name , ooOooo000oOO , iconimage )
 except : quit ( )
 if 21 - 21: OooooO0oOO . OooOoO0Oo . oOo0 / I11i1i11i1I / OooOoO0Oo
def i1iI1 ( url ) :
 if 1 - 1: II1Ii1iI1i . i11iIiiIii % oOo0
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except :
   OoOO0oo0o = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 82 - 82: ooO0oo0oO0 + I11i1i11i1I . ooO0oo0oO0 % OoO000 / i1IIiiiii . i1IIiiiii
def IIi ( url ) :
 if 66 - 66: OooooO0oOO % oo . oOo0
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( OOO )
 o0OIiiiI = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : o0OIiiiI = 1
  if 61 - 61: oOo0 % oOo0 * oo0ooO0oOOOOo / oo0ooO0oOOOOo
  if o0OIiiiI == 0 :
   II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 12 , Oo0oOOOoOooOo , O0O0OO0O0O0 )
  o0OIiiiI = 0
  if 75 - 75: OoO000 . iiIIiIiIi
 try :
  oOoO0 = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( OOO ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR yellow]Next Page -->[/COLOR]' , oOoO0 , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 50 - 50: OOO0O
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 60 - 60: iiIIiIiIi * ooO0oo0oO0 * i11iiII * I11i1i11i1I
def O0ooooo0OOOO0 ( url ) :
 if 9 - 9: i1111 - oo0ooO0oOOOOo / i1iIIIiI1I / oo0ooO0oOOOOo
 I1i111iiIIIi = datetime . date . today ( )
 O00 = datetime . datetime . strftime ( I1i111iiIIIi , '%A %d %B %Y' )
 if 17 - 17: i1IIiiiii - i111I % i1IIiiiii . OoO000 / i11iIiiIii % i1iIIIiI1I
 O0oOoOO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( O00 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 28 - 28: oo0Ooo0
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( OOO )
 o0OIiiiI = 0
 IIIIii1I = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   iII1 = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOOOOoo = re . compile ( '<p>(.+?)</p>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOOOOoo = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<img src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : o0OIiiiI = 1
  if 58 - 58: oo0ooO0oOOOOo / OoO000 . OOO0O / i111I + OooOoO0Oo
  if o0OIiiiI == 0 :
   if 'vs' in iII1 :
    OoOO0oo0o = '[COLOR dodgerblue]' + iII1 + ' - ' + '[/COLOR][COLOR green]' + oOOOOoo + '[/COLOR]'
    IIIIii1I = IIIIii1I + 1
    O0oOoOO ( OoOO0oo0o , url , 206 , Oo0oOOOoOooOo , O0O0OO0O0O0 , '' )
  o0OIiiiI = 0
  if 86 - 86: oo0Ooo0 * i1IIi11111i + oo0Ooo0 + i1111
 if IIIIii1I == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 8 - 8: OooOoO0Oo - i1iIIIiI1I / iiIIiIiIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 96 - 96: OOO0O
def IIiiI ( name , url , iconimage ) :
 if 31 - 31: i11iiII + i1IIiiiii + OooOoO0Oo / i1IIiiiii
 OOO = o0 ( url )
 iiI111 = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( OOO ) [ 0 ]
 if 1 - 1: oo0Ooo0 * oo0ooO0oOOOOo . OOO0O / oooO0oo0oOOOO
 if not "http" in iiI111 :
  iiI111 = iiI111 . replace ( "//" , "" )
  url = "http://" + iiI111
 else :
  url = iiI111
  if 100 - 100: OooOoO0Oo . oo0ooO0oOOOOo * I11i1i11i1I % oooO0oo0oOOOO * oooO0oo0oOOOO
 II = url
 if 44 - 44: i1111 / i1iIIIiI1I / oo0Ooo0 % i1111 / II1Ii1iI1i . i1IIiiiii
 oOO = o0 ( url )
 iiI111 = re . compile ( "atob(.+?)," ) . findall ( oOO ) [ 0 ]
 iiI111 = iiI111 . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( iiI111 )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + II + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 o0Oo0oO0oOO00 ( name , url , iconimage )
 if 54 - 54: i1IIi11111i / ooO0oo0oO0 / oOo0 . oOo0 % i1iIIIiI1I . i1IIi11111i
def iI1i1i ( url ) :
 if 41 - 41: II1Ii1iI1i % i1iIIIiI1I + ooO0oo0oO0
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 2 - 2: ooO0oo0oO0 * I11i1i11i1I % OooooO0oOO - i1111 - i1iIIIiI1I
  if '<display>eWVz</display>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OoOO0oo0o = base64 . b64decode ( OoOO0oo0o )
   url = base64 . b64decode ( url )
   Oo0oOOOoOooOo = base64 . b64decode ( Oo0oOOOoOooOo )
   oOooOOOoOo = base64 . b64decode ( oOooOOOoOo )
   II11i1I11Ii1i ( OoOO0oo0o , url , 220 , Oo0oOOOoOooOo , oOooOOOoOo , '' )
   if 3 - 3: OooOoO0Oo
def i1iiIiI1Ii1i ( url ) :
 if 22 - 22: OoO000 / i11iIiiIii
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOO )
 if 62 - 62: oo / i11iiII
 for Oo0OoO00oOO0o in Oo0oOOo :
  OoOO0oo0o = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   ii1O000OOO0OOo = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : ii1O000OOO0OOo = "SD"
  ii1O000OOO0OOo = '[COLOR yellow]' + ii1O000OOO0OOo + '[/COLOR]'
  Oo0oOOOoOooOo = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  OoOO0oo0o = OoOO0oo0o . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 32 - 32: i1IIiiiii * oooO0oo0oOOOO
  O0oOoOO ( '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR] - ' + ii1O000OOO0OOo , url , 212 , Oo0oOOOoOooOo , O0O0OO0O0O0 , '' )
  if 100 - 100: iiIIiIiIi % ooO0oo0oO0 * i1111 - i1iIIIiI1I
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( OOO ) [ 0 ]
  I11 = 'http://www.fmovies.se/' + url
  II11i1I11Ii1i ( "Next Page -->" , I11 , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 92 - 92: iiIIiIiIi
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 22 - 22: I11i1i11i1I % i1iIIIiI1I * i11iiII / oOo0 % i11iIiiIii * oo0Ooo0
def Oo00OoOo ( url ) :
 if 24 - 24: i11iIiiIii - OooOoO0Oo
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOO )
 if 21 - 21: oo0Ooo0
 if 92 - 92: i11iIiiIii / OooOoO0Oo - i1iIIIiI1I % iiIIiIiIi * OooOoO0Oo + I11i1i11i1I
def ii1Oo0000oOo ( url ) :
 if 31 - 31: oo0Ooo0 . OooOoO0Oo * iiIIiIiIi + i11iIiiIii * OooooO0oOO
 if "iptvembed" in url :
  OOO = o0 ( url )
  Oo0oOOo = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '</pre>' , '' )
   url = Oo0OoO00oOO0o
   if 93 - 93: i11iiII / ooO0oo0oO0 * II1Ii1iI1i % i111I * oooO0oo0oOOOO * oo0Ooo0
 if "sourcetv" in url :
  OOO = o0 ( url )
  Oo0oOOo = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '</pre>' , '' )
   url = Oo0OoO00oOO0o
   if 64 - 64: i1111 + oooO0oo0oOOOO / ooO0oo0oO0 / I11i1i11i1I . iiIIiIiIi % OoO000
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 o0ooO = [ ]
 for OoOOOo0o0ooo , I1iiiiI1iI , url in iiI1I1ii :
  iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : url }
  o0ooO . append ( iIiiiii1i )
 list = [ ]
 for iiIi1IIiI in o0ooO :
  iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
  iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
  for i1 , oO0OO0 in iiI1I1ii :
   iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
  list . append ( iIiiiii1i )
  if 82 - 82: OoO000 - OoO000 + OOO0O
 II111Ii1i1 = 0
 for iiIi1IIiI in list :
  II111Ii1i1 = 1
  OoOO0oo0o = OO0 ( iiIi1IIiI [ "display_name" ] )
  url = OO0 ( iiIi1IIiI [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   O0oOoOO ( '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   II11i1I11Ii1i ( '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 44 - 44: i1iIIIiI1I - OooOoO0Oo / oooO0oo0oOOOO * I11i1i11i1I + i1111 / OOO0O
 if II111Ii1i1 == 0 :
  O0oOoOO ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 88 - 88: oo0ooO0oOOOOo - oo + i11iiII . OooOoO0Oo % OooOoO0Oo
def oOOOO ( url ) :
 if 49 - 49: i1111 . OooooO0oOO . i11iIiiIii % OoO000
 iII = o0 ( url )
 ooOooo000oOO = url
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 34 - 34: OooOoO0Oo % OoO000
  OO0Oooo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
  if len ( OO0Oooo0 ) == 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = OoOO0oo0o + "!" + url + "!" + Oo0oOOOoOooOo
   OoOO0oo0o = '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 20 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
   if 3 - 3: i1111 / oOo0 + OoO000 . iiIIiIiIi . oo
  elif len ( OO0Oooo0 ) > 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = ooOooo000oOO + "!" + OoOO0oo0o + "!" + Oo0oOOOoOooOo
   OoOO0oo0o = '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 22 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
   if 83 - 83: OooooO0oOO + i111I
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 22 - 22: i1IIiiiii % i1iIIIiI1I * i111I - oo0ooO0oOOOOo / ooO0oo0oO0
def OoOO00 ( url ) :
 if 28 - 28: OooooO0oOO - i11iIiiIii . i11iiII + OoO000 / i11iiII
 I1i111iiIIIi = datetime . date . today ( )
 O00 = datetime . datetime . strftime ( I1i111iiIIIi , '%A %d %B %Y' )
 if 35 - 35: OoO000
 O0oOoOO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( O00 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 75 - 75: I11i1i11i1I / i11iiII . OoO000 * oOo0 - i1111
 iII = o0 ( url )
 ooOooo000oOO = url
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 41 - 41: i1IIiiiii
  OO0Oooo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
  if len ( OO0Oooo0 ) == 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = OoOO0oo0o + "!" + url + "!" + Oo0oOOOoOooOo
   OoOO0oo0o = '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 20 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
   if 77 - 77: OooOoO0Oo
  elif len ( OO0Oooo0 ) > 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = ooOooo000oOO + "!" + OoOO0oo0o + "!" + Oo0oOOOoOooOo
   OoOO0oo0o = '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 22 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
   if 65 - 65: i1111 . i1IIi11111i % OooooO0oOO * oo
def iI11I ( ) :
 if 11 - 11: i1iIIIiI1I - OooooO0oOO + i1111 - ooO0oo0oO0
 I1i111iiIIIi = datetime . date . today ( )
 O00 = datetime . datetime . strftime ( I1i111iiIIIi , '%A %d %B %Y' )
 if 7 - 7: OoO000 - oo0Ooo0 / i1111 * i1IIiiiii . i1iIIIiI1I * i1iIIIiI1I
 O0oOoOO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( O00 ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 61 - 61: oo0Ooo0 % iiIIiIiIi - oo / I11i1i11i1I
 iII = o0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 Oo0oOOo = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 Ii1iI111 = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in Ii1iI111 :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in Oo0OoO00oOO0o :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iII1 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( 'src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     O0oooo00o0Oo = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
     O0oooo00o0Oo = I1iii ( O0oooo00o0Oo )
    except : O0oooo00o0Oo = "null"
    OoOO0oo0o = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + iII1 + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    OoOO0oo0o = oO0o0O0Ooo0o ( OoOO0oo0o )
    O000oo = iII1 + "!" + O0oooo00o0Oo . lower ( ) + "!" + Oo0oOOOoOooOo
    II11i1I11Ii1i ( OoOO0oo0o , O000oo , 20 , Oo0oOOOoOooOo , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iII1 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     O0oooo00o0Oo = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : O0oooo00o0Oo = "null"
    Oo0oOOOoOooOo = re . compile ( 'src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    OoOO0oo0o = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + iII1 + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    OoOO0oo0o = oO0o0O0Ooo0o ( OoOO0oo0o )
    O000oo = iII1 + "!" + O0oooo00o0Oo . lower ( ) + "!" + Oo0oOOOoOooOo
    II11i1I11Ii1i ( OoOO0oo0o , O000oo , 20 , Oo0oOOOoOooOo , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 21 - 21: OooOoO0Oo - i1IIi11111i + oo0Ooo0
def ooOoo0o0O ( name , url , iconimage ) :
 if 77 - 77: OooooO0oOO
 try :
  url , oOooOoo0o0Oo0 , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 35 - 35: I11i1i11i1I
 ooo0OO00O0O = [ ]
 if 19 - 19: oo * oo0Ooo0 / oo0Ooo0 . i111I - oOo0 + i11iIiiIii
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( oOooOoo0o0Oo0 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o00O0O ) [ 0 ]
 OO0Oooo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( o00O0O )
 for ii1iii1i in OO0Oooo0 :
  ooo0OO00O0O . append ( ii1iii1i )
  if 88 - 88: i11iIiiIii - iiIIiIiIi
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 67 - 67: oOo0 . I11i1i11i1I + OOO0O - i111I
 OOOoO = 0
 if 14 - 14: oo0Ooo0 . ooO0oo0oO0 . i111I . i1111 / oo0ooO0oOOOOo
 IiIi1 = [ ]
 i111iiI1ii = [ ]
 IIiii = [ ]
 I1IiiI . update ( 0 )
 I1i1i = 0
 if 86 - 86: I11i1i11i1I / OooooO0oOO + oooO0oo0oOOOO * i1iIIIiI1I
 if oO000OoOoo00o == "true" :
  I1i1i = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if OOOoO < 100 :
    I1IiiI . update ( OOOoO )
    OOOoO = OOOoO + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o0ooO = [ ]
   for OoOOOo0o0ooo , I1iiiiI1iI , url in iiI1I1ii :
    iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : url }
    o0ooO . append ( iIiiiii1i )
   iiI11I1i1i1iI = [ ]
   for iiIi1IIiI in o0ooO :
    iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
    iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
    for i1 , oO0OO0 in iiI1I1ii :
     iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
    iiI11I1i1i1iI . append ( iIiiiii1i )
    if 60 - 60: i111I % I11i1i11i1I + oOo0 . iiIIiIiIi * ooO0oo0oO0
   for iiIi1IIiI in iiI11I1i1i1iI :
    name = OO0 ( iiIi1IIiI [ "display_name" ] )
    url = OO0 ( iiIi1IIiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IiIi1 . append ( name )
    i111iiI1ii . append ( url )
    if "hd" in name . lower ( ) :
     IIiii . append ( "1" )
    else :
     IIiii . append ( "0" )
    IIii1111 = list ( zip ( IIiii , IiIi1 , i111iiI1ii ) )
    if 93 - 93: oo
 if iiiI11 == "true" :
  I1i1i = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if OOOoO < 100 :
    I1IiiI . update ( OOOoO )
    OOOoO = OOOoO + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o0ooO = [ ]
   for OoOOOo0o0ooo , I1iiiiI1iI , url in iiI1I1ii :
    iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : url }
    o0ooO . append ( iIiiiii1i )
   iiI11I1i1i1iI = [ ]
   for iiIi1IIiI in o0ooO :
    iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
    iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
    for i1 , oO0OO0 in iiI1I1ii :
     iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
    iiI11I1i1i1iI . append ( iIiiiii1i )
    if 5 - 5: oo0Ooo0 / oOo0
   for iiIi1IIiI in iiI11I1i1i1iI :
    name = OO0 ( iiIi1IIiI [ "display_name" ] )
    url = OO0 ( iiIi1IIiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IiIi1 . append ( name )
    i111iiI1ii . append ( url )
    if "hd" in name . lower ( ) :
     IIiii . append ( "1" )
    else :
     IIiii . append ( "0" )
    IIii1111 = list ( zip ( IIiii , IiIi1 , i111iiI1ii ) )
    if 77 - 77: iiIIiIiIi - i1IIi11111i % oo0Ooo0 - oooO0oo0oOOOO
 if OOooO == "true" :
  I1i1i = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if OOOoO < 100 :
    I1IiiI . update ( OOOoO )
    OOOoO = OOOoO + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o0ooO = [ ]
   for OoOOOo0o0ooo , I1iiiiI1iI , url in iiI1I1ii :
    iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : url }
    o0ooO . append ( iIiiiii1i )
   iiI11I1i1i1iI = [ ]
   for iiIi1IIiI in o0ooO :
    iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
    iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
    for i1 , oO0OO0 in iiI1I1ii :
     iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
    iiI11I1i1i1iI . append ( iIiiiii1i )
    if 67 - 67: oOo0 + I11i1i11i1I
   for iiIi1IIiI in iiI11I1i1i1iI :
    name = OO0 ( iiIi1IIiI [ "display_name" ] )
    url = OO0 ( iiIi1IIiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IiIi1 . append ( name )
    i111iiI1ii . append ( url )
    if "hd" in name . lower ( ) :
     IIiii . append ( "1" )
    else :
     IIiii . append ( "0" )
    IIii1111 = list ( zip ( IIiii , IiIi1 , i111iiI1ii ) )
    if 84 - 84: oooO0oo0oOOOO * i111I - OoO000 * OoO000
 if I1i1i == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 8 - 8: iiIIiIiIi / II1Ii1iI1i . OooooO0oOO
 oo0o0000 = sorted ( IIii1111 , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 i1I1IiI = sorted ( ooo0OO00O0O )
 if 66 - 66: oo
 OOOOOoo0 = 0
 if 56 - 56: oooO0oo0oOOOO
 I1IiiI . update ( 100 )
 if 61 - 61: oo0ooO0oOOOOo / oOo0 / I11i1i11i1I * oooO0oo0oOOOO
 O0oOoOO ( '                    [COLOR yellow][I]LINKS FOR ' + oOooOoo0o0Oo0 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O0oOoOO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 23 - 23: OooooO0oOO - oOo0 + oo0Ooo0
 if 12 - 12: i1IIi11111i / iiIIiIiIi % oo0ooO0oOOOOo / i11iIiiIii % i111I
 for O0oooo00o0Oo in i1I1IiI :
  if 15 - 15: ooO0oo0oO0 % i111I - I11i1i11i1I * i1IIiiiii + oo0Ooo0
  O0oOoOO ( '                                  [COLOR mediumpurple][I]' + O0oooo00o0Oo . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 11 - 11: i1iIIIiI1I * i1IIiiiii - OOO0O
  oo0O00Oooo0O0 = O0oooo00o0Oo . split ( ' ' )
  if 66 - 66: OOO0O . i11iIiiIii - i1iIIIiI1I * oo0ooO0oOOOOo + i111I * i11iiII
  for oO0OO0O00Oo , name , url in oo0o0000 :
   if 42 - 42: i1111 % OoO000 % OooOoO0Oo % II1Ii1iI1i - OooooO0oOO
   i1I1I1iiII = 0
   if 58 - 58: oo0Ooo0 + i1111 * i1iIIIiI1I * i11iIiiIii - ooO0oo0oO0
   for oooo00o0o0o in oo0O00Oooo0O0 :
    if 87 - 87: oo0Ooo0 * II1Ii1iI1i - i1IIiiiii % oOo0 / OooOoO0Oo
    if not oooo00o0o0o . lower ( ) in name . lower ( ) :
     i1I1I1iiII = 1
     if 39 - 39: i1IIi11111i * i11iIiiIii - OooooO0oOO / OoO000 % OooOoO0Oo % oo0Ooo0
   if i1I1I1iiII == 0 :
    OOOOOoo0 = OOOOOoo0 + 1
    if "hd" in name . lower ( ) :
     O0oOoOO ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( OOOOOoo0 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O0oOoOO ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( OOOOOoo0 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 65 - 65: OooooO0oOO - iiIIiIiIi % i111I / i111I % i111I
  if OOOOOoo0 == 0 :
   O0oOoOO ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 52 - 52: i11iiII + i11iiII . i1111
  oo0O00Oooo0O0 = ""
  if 34 - 34: i111I . oooO0oo0oOOOO / OooooO0oOO * OOO0O - i11iiII
 I1IiiI . close ( )
 if 36 - 36: II1Ii1iI1i / oooO0oo0oOOOO / oo - oooO0oo0oOOOO - II1Ii1iI1i
def ii1I11 ( name , url , iconimage ) :
 if 99 - 99: oOo0
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 45 - 45: OooooO0oOO - oOo0 * OooOoO0Oo / I11i1i11i1I * i1111 - OooOoO0Oo
 OOOoO = 0
 try :
  oOooOoo0o0Oo0 , O0oooo00o0Oo , iconimage = url . split ( '!' )
 except :
  try :
   O0oooo00o0Oo , iconimage = url . split ( '!' )
   oOooOoo0o0Oo0 = O0oooo00o0Oo
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 83 - 83: oo % OoO000 . i111I
 O0Oo = 0
 if 7 - 7: OoO000 % ooO0oo0oO0 + oo0Ooo0 - i1IIiiiii * OooooO0oOO
 if "all " in name . lower ( ) :
  O0oooo00o0Oo = O0oooo00o0Oo . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  oOooOoo0o0Oo0 = oOooOoo0o0Oo0 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  O0Oo = 1
  if 94 - 94: OOO0O . oooO0oo0oOOOO / i1IIiiiii . i11iiII - II1Ii1iI1i
 IiIi1 = [ ]
 i111iiI1ii = [ ]
 IIiii = [ ]
 I1IiiI . update ( 0 )
 I1i1i = 0
 if oO000OoOoo00o == "true" :
  I1i1i = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if OOOoO < 100 :
    I1IiiI . update ( OOOoO )
    OOOoO = OOOoO + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o0ooO = [ ]
   for OoOOOo0o0ooo , I1iiiiI1iI , url in iiI1I1ii :
    iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : url }
    o0ooO . append ( iIiiiii1i )
   iiI11I1i1i1iI = [ ]
   for iiIi1IIiI in o0ooO :
    iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
    iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
    for i1 , oO0OO0 in iiI1I1ii :
     iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
    iiI11I1i1i1iI . append ( iIiiiii1i )
    if 26 - 26: oo - oOo0 . oo0ooO0oOOOOo
   for iiIi1IIiI in iiI11I1i1i1iI :
    name = OO0 ( iiIi1IIiI [ "display_name" ] )
    url = OO0 ( iiIi1IIiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IiIi1 . append ( name )
    i111iiI1ii . append ( url )
    if "hd" in name . lower ( ) :
     IIiii . append ( "1" )
    else :
     IIiii . append ( "0" )
    IIii1111 = list ( zip ( IIiii , IiIi1 , i111iiI1ii ) )
    if 65 - 65: i11iiII % oooO0oo0oOOOO % ooO0oo0oO0 * i1IIiiiii
 if iiiI11 == "true" :
  I1i1i = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if OOOoO < 100 :
    I1IiiI . update ( OOOoO )
    OOOoO = OOOoO + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o0ooO = [ ]
   for OoOOOo0o0ooo , I1iiiiI1iI , url in iiI1I1ii :
    iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : url }
    o0ooO . append ( iIiiiii1i )
   iiI11I1i1i1iI = [ ]
   for iiIi1IIiI in o0ooO :
    iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
    iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
    for i1 , oO0OO0 in iiI1I1ii :
     iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
    iiI11I1i1i1iI . append ( iIiiiii1i )
    if 31 - 31: i1IIiiiii
   for iiIi1IIiI in iiI11I1i1i1iI :
    name = OO0 ( iiIi1IIiI [ "display_name" ] )
    url = OO0 ( iiIi1IIiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IiIi1 . append ( name )
    i111iiI1ii . append ( url )
    if "hd" in name . lower ( ) :
     IIiii . append ( "1" )
    else :
     IIiii . append ( "0" )
    IIii1111 = list ( zip ( IIiii , IiIi1 , i111iiI1ii ) )
    if 44 - 44: OOO0O - ooO0oo0oO0 - I11i1i11i1I
 if OOooO == "true" :
  I1i1i = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if OOOoO < 100 :
    I1IiiI . update ( OOOoO )
    OOOoO = OOOoO + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o0ooO = [ ]
   for OoOOOo0o0ooo , I1iiiiI1iI , url in iiI1I1ii :
    iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : url }
    o0ooO . append ( iIiiiii1i )
   iiI11I1i1i1iI = [ ]
   for iiIi1IIiI in o0ooO :
    iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
    iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
    for i1 , oO0OO0 in iiI1I1ii :
     iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
    iiI11I1i1i1iI . append ( iIiiiii1i )
    if 80 - 80: ooO0oo0oO0 * OooOoO0Oo % oo0Ooo0 % I11i1i11i1I
   for iiIi1IIiI in iiI11I1i1i1iI :
    name = OO0 ( iiIi1IIiI [ "display_name" ] )
    url = OO0 ( iiIi1IIiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IiIi1 . append ( name )
    i111iiI1ii . append ( url )
    if "hd" in name . lower ( ) :
     IIiii . append ( "1" )
    else :
     IIiii . append ( "0" )
    IIii1111 = list ( zip ( IIiii , IiIi1 , i111iiI1ii ) )
    if 95 - 95: ooO0oo0oO0 - i11iiII . OooOoO0Oo - i1IIi11111i
 if I1i1i == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 75 - 75: oo + oo0ooO0oOOOOo - II1Ii1iI1i . i111I * i1IIiiiii / OoO000
 oo0o0000 = sorted ( IIii1111 , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 if 86 - 86: OOO0O * i1111 - oooO0oo0oOOOO . OOO0O % ooO0oo0oO0 / oOo0
 OOOOOoo0 = 0
 if 11 - 11: i1IIi11111i * OooooO0oOO + i11iiII / i11iiII
 I1IiiI . update ( 100 )
 if 37 - 37: i11iIiiIii + II1Ii1iI1i
 O0oOoOO ( '                                [COLOR yellow][I]LINKS FOR ' + oOooOoo0o0Oo0 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O0oOoOO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 oo0O00Oooo0O0 = O0oooo00o0Oo . split ( ' ' )
 for oO0OO0O00Oo , name , url in oo0o0000 :
  if O0Oo == 1 :
   I1i11II = name
   if 31 - 31: OooooO0oOO / OoO000 * oo0ooO0oOOOOo . i1111
  i1I1I1iiII = 0
  if 89 - 89: oooO0oo0oOOOO
  for oooo00o0o0o in oo0O00Oooo0O0 :
   if 2 - 2: i11iiII . i11iiII + i11iiII * oo0ooO0oOOOOo
   if not oooo00o0o0o . lower ( ) in name . lower ( ) :
    i1I1I1iiII = 1
    if 100 - 100: I11i1i11i1I % i1IIiiiii / oo0Ooo0
  if i1I1I1iiII == 0 :
   OOOOOoo0 = OOOOOoo0 + 1
   if O0Oo == 1 :
    if "hd" in name . lower ( ) :
     O0oOoOO ( '                                          [COLOR blue] ' + str ( I1i11II ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O0oOoOO ( '                                          [COLOR blue] ' + str ( I1i11II ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     O0oOoOO ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( OOOOOoo0 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O0oOoOO ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( OOOOOoo0 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 30 - 30: I11i1i11i1I - oOo0 - i1iIIIiI1I
 if OOOOOoo0 == 0 :
  O0oOoOO ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 81 - 81: oo0ooO0oOOOOo . i111I + oOo0 * iiIIiIiIi
 I1IiiI . close ( )
 if 74 - 74: II1Ii1iI1i + oooO0oo0oOOOO + I11i1i11i1I
def iIIIi1i1I11i ( term ) :
 if 55 - 55: I11i1i11i1I - oOo0
 I1i1i1iii = [ ]
 I1111i = [ ]
 if 84 - 84: OooOoO0Oo + I11i1i11i1I - OOO0O * OOO0O
 OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  O000oo = Oo0OoO00oOO0o
  if 61 - 61: i111I . OooooO0oOO . i111I / I11i1i11i1I
  O000oo = O000oo . replace ( '#AAASTREAM:' , '#A:' )
  O000oo = O000oo . replace ( '#EXTINF:' , '#A:' )
  iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O000oo )
  o0ooO = [ ]
  for OoOOOo0o0ooo , I1iiiiI1iI , O000oo in iiI1I1ii :
   iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : O000oo }
   o0ooO . append ( iIiiiii1i )
  list = [ ]
  for iiIi1IIiI in o0ooO :
   iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
   iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
   for i1 , oO0OO0 in iiI1I1ii :
    iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
   list . append ( iIiiiii1i )
   if 72 - 72: II1Ii1iI1i
  for iiIi1IIiI in list :
   OoOO0oo0o = OO0 ( iiIi1IIiI [ "display_name" ] )
   O000oo = OO0 ( iiIi1IIiI [ "url" ] )
   O000oo = O000oo . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in OoOO0oo0o . lower ( ) :
    I1i1i1iii . append ( O000oo )
    I1111i . append ( OoOO0oo0o )
    if 82 - 82: OOO0O + i111I / i11iIiiIii * i11iiII . i111I
 O00ooooo00 = xbmcgui . Dialog ( )
 Ii1IIiI1i = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , I1111i )
 if Ii1IIiI1i < 0 :
  quit ( )
  if 63 - 63: i11iiII
 O000oo = I1i1i1iii [ Ii1IIiI1i ]
 OoOO0oo0o = I1111i [ Ii1IIiI1i ]
 o0Oo0oO0oOO00 ( OoOO0oo0o , O000oo , iiiii )
 if 6 - 6: iiIIiIiIi / i11iiII
def oOooO00o0O ( name , url , iconimage ) :
 if 80 - 80: oOo0 / oo0Ooo0 / OOO0O + II1Ii1iI1i - I11i1i11i1I
 list = iIIiiIIi1IiI ( url )
 if 14 - 14: OoO000 % OooooO0oOO % I11i1i11i1I - i11iIiiIii
 o0OO000ooOo = 0
 Oooo = open ( iI1Ii11111iIi , mode = 'r' ) ; oOo00OooO0oO = Oooo . read ( ) ; Oooo . close ( )
 oOo00OooO0oO = oOo00OooO0oO . replace ( '\n' , '' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( oOo00OooO0oO )
 II111Ii1i1 = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 16 - 16: OoO000 / I11i1i11i1I + oOo0 / i1IIiiiii
  IIIiiI1 = re . compile ( '<url>(.+?)</url>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  if 74 - 74: oo0Ooo0 - oOo0 + II1Ii1iI1i . i1IIi11111i + oOo0 - oo0Ooo0
  if url == IIIiiI1 :
   o0OO000ooOo = 1
   if 17 - 17: oooO0oo0oOOOO . OooOoO0Oo . oooO0oo0oOOOO + oooO0oo0oOOOO / I11i1i11i1I . iiIIiIiIi
 for iiIi1IIiI in list :
  name = OO0 ( iiIi1IIiI [ "display_name" ] )
  url = OO0 ( iiIi1IIiI [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if o0OO000ooOo == 1 :
   if 62 - 62: i11iiII % i1iIIIiI1I * oo - II1Ii1iI1i
   Oooo = open ( i1i1II , mode = 'r' ) ; oOo00OooO0oO = Oooo . read ( ) ; Oooo . close ( )
   oOo00OooO0oO = oOo00OooO0oO . replace ( '\n' , '' )
   Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( oOo00OooO0oO )
   for Oo0OoO00oOO0o in Oo0oOOo :
    if 66 - 66: i11iIiiIii / oo0ooO0oOOOOo - i111I / II1Ii1iI1i . i11iIiiIii
    IIIII1iii11 = re . compile ( '<name>(.+?)</name>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    if 35 - 35: OooooO0oOO / OooOoO0Oo / i1111 - ooO0oo0oO0 + i1111 . OooOoO0Oo
    O0O00O000OOO = IIIII1iii11 . replace ( ' ' , '' )
    iI = name . replace ( ' ' , '' )
    if O0O00O000OOO . lower ( ) in iI . lower ( ) :
     if 100 - 100: i1IIi11111i / oo0ooO0oOOOOo * i1iIIIiI1I . oooO0oo0oOOOO / oOo0
     Oooo = open ( O0oo0OO0 , mode = 'r' ) ; oOo00OooO0oO = Oooo . read ( ) ; Oooo . close ( )
     oOo00OooO0oO = oOo00OooO0oO . replace ( '\n' , '' )
     Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( oOo00OooO0oO )
     for Oo0OoO00oOO0o in Oo0oOOo :
      if 83 - 83: OooOoO0Oo
      ii111Ii11iii = re . compile ( '<replace>(.+?)</replace>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
      if 62 - 62: ooO0oo0oO0
      name = name . lower ( ) . replace ( ii111Ii11iii , '' )
      if 93 - 93: OooooO0oOO - oo0ooO0oOOOOo % OOO0O . OOO0O - iiIIiIiIi
     O0oOoOO ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 90 - 90: iiIIiIiIi + i1111 * i11iiII / i1IIiiiii . oo0ooO0oOOOOo + oo0ooO0oOOOOo
  else : O0oOoOO ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 40 - 40: iiIIiIiIi / OOO0O % i11iIiiIii % i11iiII / i1IIi11111i
def iIIiiIIi1IiI ( url ) :
 if 62 - 62: II1Ii1iI1i - OOO0O
 oo0O0oo = Oo0O0O0ooO0O ( url )
 oo0O0oo = oo0O0oo . replace ( '#AAASTREAM:' , '#A:' )
 oo0O0oo = oo0O0oo . replace ( '#EXTINF:' , '#A:' )
 iiI1I1ii = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( oo0O0oo )
 o0ooO = [ ]
 for OoOOOo0o0ooo , I1iiiiI1iI , url in iiI1I1ii :
  iIiiiii1i = { "params" : OoOOOo0o0ooo , "display_name" : I1iiiiI1iI , "url" : url }
  o0ooO . append ( iIiiiii1i )
 list = [ ]
 for iiIi1IIiI in o0ooO :
  iIiiiii1i = { "display_name" : iiIi1IIiI [ "display_name" ] , "url" : iiIi1IIiI [ "url" ] }
  iiI1I1ii = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIi1IIiI [ "params" ] )
  for i1 , oO0OO0 in iiI1I1ii :
   iIiiiii1i [ i1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oO0OO0 . strip ( )
  list . append ( iIiiiii1i )
  if 14 - 14: oooO0oo0oOOOO / II1Ii1iI1i / I11i1i11i1I + ooO0oo0oO0
 return list
 if 96 - 96: i1iIIIiI1I
 if 18 - 18: i1iIIIiI1I * oo0Ooo0 - i1IIiiiii
def II1i1III ( ) :
 if 34 - 34: OooOoO0Oo - i11iIiiIii / ooO0oo0oO0
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 87 - 87: i11iiII / i111I - I11i1i11i1I % OOO0O % OoO000 % I11i1i11i1I
def Ii1 ( name , url , iconimage ) :
 if 34 - 34: i1iIIIiI1I - i111I . i1IIi11111i / i1111
 II1II = datetime . datetime . now ( )
 oo0O = II1II . day
 if 95 - 95: i111I . oooO0oo0oOOOO . oo0ooO0oOOOOo * I11i1i11i1I . i1IIiiiii
 iI1 = oo0O
 if 31 - 31: OooooO0oOO / ooO0oo0oO0
 o0oO0OoO0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOOOOOoOO = datetime . datetime . strftime ( o0oO0OoO0 , '%A - %d %B %Y' )
 oooo00 = 'http://www.predictz.com/predictions/'
 if 35 - 35: OooOoO0Oo . OOO0O * i11iIiiIii
 iiII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 o0Oii1111i = datetime . datetime . strftime ( iiII , '%A - %d %B %Y' )
 O0ooOO = datetime . datetime . strftime ( iiII , '%d' )
 IiiI = 'http://www.predictz.com/predictions/tomorrow/'
 if 19 - 19: i1111
 OoOO = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 II1i11i1iIi11 = datetime . datetime . strftime ( OoOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oo0O0oO0O0O = datetime . datetime . strftime ( OoOO , '%y%m%d' )
 oOo0O = 'http://www.predictz.com/predictions/20' + str ( oo0O0oO0O0O )
 if 26 - 26: OoO000 / II1Ii1iI1i * OooooO0oOO . i1IIi11111i
 i1i = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 IIIiiiI = datetime . datetime . strftime ( i1i , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoO00oo00 = datetime . datetime . strftime ( i1i , '%y%m%d' )
 Oo0Oo0O = 'http://www.predictz.com/predictions/20' + str ( OoO00oo00 )
 if 44 - 44: i111I % i111I
 I11Ii = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIiII = datetime . datetime . strftime ( I11Ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1i1IIIIIIIi = datetime . datetime . strftime ( I11Ii , '%y%m%d' )
 oo0o0oOo = 'http://www.predictz.com/predictions/20' + str ( i1i1IIIIIIIi )
 if 58 - 58: oo0ooO0oOOOOo - i1111 % OooooO0oOO + OooOoO0Oo . OOO0O / OoO000
 if 8 - 8: i11iiII . oo * oo0Ooo0 + i1111 % i11iIiiIii
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOOOOOoOO ) + '[/B][/COLOR]' , oooo00 , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( o0Oii1111i ) + '[/B][/COLOR]' , IiiI , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( II1i11i1iIi11 ) , oOo0O , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( IIIiiiI ) , Oo0Oo0O , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iIiII ) , oo0o0oOo , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 8 - 8: iiIIiIiIi * oooO0oo0oOOOO
def OOoO ( name , url , iconimage ) :
 if 18 - 18: ooO0oo0oO0 + I11i1i11i1I - oOo0 + i111I * i111I
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 Ii1iI111 = re . compile ( '<tr(.+?)</tr>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in Ii1iI111 :
  try :
   oOOOOoo = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR red][B]' + oOOOOoo + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iII1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1I = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iII1 = iiI1I1IIi11i1 ( iII1 )
   i1I = iiI1I1IIi11i1 ( i1I )
   O0oOoOO ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + i1I + ' [/B][/COLOR]| [COLOR mediumpurple]' + iII1 + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 45 - 45: iiIIiIiIi % oo0ooO0oOOOOo - iiIIiIiIi
def i1i1 ( name , url , iconimage ) :
 if 69 - 69: i11iiII - OooOoO0Oo
 II1II = datetime . datetime . now ( )
 oo0O = II1II . day
 if 16 - 16: I11i1i11i1I
 iI1 = oo0O
 if 14 - 14: II1Ii1iI1i - oooO0oo0oOOOO % I11i1i11i1I
 o0oO0OoO0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOOOOOoOO = datetime . datetime . strftime ( o0oO0OoO0 , '%A - %d %B %Y' )
 oooo00 = 'http://www.predictz.com/predictions/'
 if 92 - 92: i1IIiiiii % i1iIIIiI1I / i11iiII % i11iiII * i1IIi11111i
 iiII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 o0Oii1111i = datetime . datetime . strftime ( iiII , '%A - %d %B %Y' )
 O0ooOO = datetime . datetime . strftime ( iiII , '%d' )
 IiiI = 'http://www.predictz.com/predictions/tomorrow/'
 if 74 - 74: oooO0oo0oOOOO . i1IIi11111i % oo % OoO000
 OoOO = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 II1i11i1iIi11 = datetime . datetime . strftime ( OoOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oo0O0oO0O0O = datetime . datetime . strftime ( OoOO , '%y%m%d' )
 oOo0O = 'http://www.predictz.com/predictions/20' + str ( oo0O0oO0O0O )
 if 87 - 87: OooooO0oOO - i11iIiiIii
 i1i = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 IIIiiiI = datetime . datetime . strftime ( i1i , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoO00oo00 = datetime . datetime . strftime ( i1i , '%y%m%d' )
 Oo0Oo0O = 'http://www.predictz.com/predictions/20' + str ( OoO00oo00 )
 if 78 - 78: i11iIiiIii / ooO0oo0oO0 - oo0ooO0oOOOOo
 I11Ii = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIiII = datetime . datetime . strftime ( I11Ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1i1IIIIIIIi = datetime . datetime . strftime ( I11Ii , '%y%m%d' )
 oo0o0oOo = 'http://www.predictz.com/predictions/20' + str ( i1i1IIIIIIIi )
 if 23 - 23: oo0Ooo0
 if 40 - 40: oo0ooO0oOOOOo - i1111 / I11i1i11i1I
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOOOOOoOO ) + '[/B][/COLOR]' , oooo00 , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( o0Oii1111i ) + '[/B][/COLOR]' , IiiI , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( II1i11i1iIi11 ) , oOo0O , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( IIIiiiI ) , Oo0Oo0O , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iIiII ) , oo0o0oOo , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 14 - 14: i11iiII
def iI1iIIiI1ii ( name , url , iconimage ) :
 if 78 - 78: oooO0oo0oOOOO * oOo0
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 Ii1iI111 = re . compile ( '<tr(.+?)</tr>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in Ii1iI111 :
  try :
   oOOOOoo = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR red][B]' + oOOOOoo + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iII1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iIii1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Ooo0oO0 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   o0Oo0oOooOoOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   iII1 = iiI1I1IIi11i1 ( iII1 )
   O0oOoOO ( '[COLOR mediumpurple][B]' + iII1 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + iIii1 + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + Ooo0oO0 + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + o0Oo0oOooOoOo + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 49 - 49: oOo0 . i11iiII . i11iIiiIii - i1111 / i1IIiiiii
def ooOo0O0o0 ( name , url , iconimage ) :
 if 65 - 65: iiIIiIiIi + oooO0oo0oOOOO
 II1II = datetime . datetime . now ( )
 oo0O = II1II . day
 if 32 - 32: i111I - OOO0O - i11iIiiIii * oo0ooO0oOOOOo / I11i1i11i1I + i111I
 iI1 = oo0O
 if 35 - 35: II1Ii1iI1i - oo0ooO0oOOOOo * i1iIIIiI1I
 o0oO0OoO0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOOOOOoOO = datetime . datetime . strftime ( o0oO0OoO0 , '%A - %d %B %Y' )
 oooo00 = 'http://www.predictz.com/predictions/'
 if 63 - 63: i1iIIIiI1I * i11iiII . i111I / oOo0 * I11i1i11i1I . iiIIiIiIi
 iiII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 o0Oii1111i = datetime . datetime . strftime ( iiII , '%A - %d %B %Y' )
 O0ooOO = datetime . datetime . strftime ( iiII , '%d' )
 IiiI = 'http://www.predictz.com/predictions/tomorrow/'
 if 62 - 62: II1Ii1iI1i / iiIIiIiIi . i1IIi11111i * oo0ooO0oOOOOo
 OoOO = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 II1i11i1iIi11 = datetime . datetime . strftime ( OoOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oo0O0oO0O0O = datetime . datetime . strftime ( OoOO , '%y%m%d' )
 oOo0O = 'http://www.predictz.com/predictions/20' + str ( oo0O0oO0O0O )
 if 21 - 21: oo0ooO0oOOOOo
 i1i = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 IIIiiiI = datetime . datetime . strftime ( i1i , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoO00oo00 = datetime . datetime . strftime ( i1i , '%y%m%d' )
 Oo0Oo0O = 'http://www.predictz.com/predictions/20' + str ( OoO00oo00 )
 if 81 - 81: oo0Ooo0 / ooO0oo0oO0 - iiIIiIiIi * OooOoO0Oo . i1IIi11111i * i11iiII
 I11Ii = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIiII = datetime . datetime . strftime ( I11Ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1i1IIIIIIIi = datetime . datetime . strftime ( I11Ii , '%y%m%d' )
 oo0o0oOo = 'http://www.predictz.com/predictions/20' + str ( i1i1IIIIIIIi )
 if 95 - 95: i1IIi11111i
 if 88 - 88: OoO000 % oo + OooOoO0Oo + OooOoO0Oo * i1111
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOOOOOoOO ) + '[/B][/COLOR]' , oooo00 , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( o0Oii1111i ) + '[/B][/COLOR]' , IiiI , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( II1i11i1iIi11 ) , oOo0O , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( IIIiiiI ) , Oo0Oo0O , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iIiII ) , oo0o0oOo , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 78 - 78: i111I
def OOoo0 ( name , url , iconimage ) :
 if 36 - 36: oo0ooO0oOOOOo + oo0Ooo0 - OoO000 + ooO0oo0oO0 + i111I
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 Ii1iI111 = re . compile ( '<tr(.+?)</tr>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in Ii1iI111 :
  try :
   oOOOOoo = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR red][B]' + oOOOOoo + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iII1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OOOOOoo0 , ii1 = iII1 . split ( ' v ' )
   Ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I1i111IiIiIi1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   i1II11II1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   II1IIIii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 3 ]
   iIIIiIi1I1i = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 4 ]
   OoOOoO0oOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 5 ]
   O0ooOOOO0O0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 6 ]
   i1IIi1i1Ii1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 7 ]
   Iii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 8 ]
   o0Oo0oO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 9 ]
   if 48 - 48: OooooO0oOO . oo0ooO0oOOOOo / OooooO0oOO
   if Ii == "W" :
    Ii = '[COLOR lime]W[/COLOR]'
   elif Ii == "D" :
    Ii = '[COLOR yellow]D[/COLOR]'
   else : Ii = '[COLOR red]L[/COLOR]'
   if 56 - 56: ooO0oo0oO0 . i11iIiiIii - oOo0 * i1111 * OooOoO0Oo
   if I1i111IiIiIi1 == "W" :
    I1i111IiIiIi1 = '[COLOR lime]W[/COLOR]'
   elif I1i111IiIiIi1 == "D" :
    I1i111IiIiIi1 = '[COLOR yellow]D[/COLOR]'
   else : I1i111IiIiIi1 = '[COLOR red]L[/COLOR]'
   if 5 - 5: oOo0 / oOo0 - i11iiII
   if i1II11II1 == "W" :
    i1II11II1 = '[COLOR lime]W[/COLOR]'
   elif i1II11II1 == "D" :
    i1II11II1 = '[COLOR yellow]D[/COLOR]'
   else : i1II11II1 = '[COLOR red]L[/COLOR]'
   if 79 - 79: i11iiII + OooOoO0Oo
   if II1IIIii == "W" :
    II1IIIii = '[COLOR lime]W[/COLOR]'
   elif II1IIIii == "D" :
    II1IIIii = '[COLOR yellow]D[/COLOR]'
   else : II1IIIii = '[COLOR red]L[/COLOR]'
   if 10 - 10: I11i1i11i1I + oooO0oo0oOOOO
   if iIIIiIi1I1i == "W" :
    iIIIiIi1I1i = '[COLOR lime]W[/COLOR]'
   elif iIIIiIi1I1i == "D" :
    iIIIiIi1I1i = '[COLOR yellow]D[/COLOR]'
   else : iIIIiIi1I1i = '[COLOR red]L[/COLOR]'
   if 43 - 43: ooO0oo0oO0 / i1111 % oo0ooO0oOOOOo - oOo0
   if OoOOoO0oOo == "W" :
    OoOOoO0oOo = '[COLOR lime]W[/COLOR]'
   elif OoOOoO0oOo == "D" :
    OoOOoO0oOo = '[COLOR yellow]D[/COLOR]'
   else : OoOOoO0oOo = '[COLOR red]L[/COLOR]'
   if 62 - 62: oo0Ooo0
   if O0ooOOOO0O0 == "W" :
    O0ooOOOO0O0 = '[COLOR lime]W[/COLOR]'
   elif O0ooOOOO0O0 == "D" :
    O0ooOOOO0O0 = '[COLOR yellow]D[/COLOR]'
   else : O0ooOOOO0O0 = '[COLOR red]L[/COLOR]'
   if 63 - 63: oOo0 + iiIIiIiIi * OooooO0oOO / oo0ooO0oOOOOo / I11i1i11i1I * ooO0oo0oO0
   if i1IIi1i1Ii1 == "W" :
    i1IIi1i1Ii1 = '[COLOR lime]W[/COLOR]'
   elif i1IIi1i1Ii1 == "D" :
    i1IIi1i1Ii1 = '[COLOR yellow]D[/COLOR]'
   else : i1IIi1i1Ii1 = '[COLOR red]L[/COLOR]'
   if 57 - 57: OOO0O - OooooO0oOO / iiIIiIiIi % i11iIiiIii
   if Iii == "W" :
    Iii = '[COLOR lime]W[/COLOR]'
   elif Iii == "D" :
    Iii = '[COLOR yellow]D[/COLOR]'
   else : Iii = '[COLOR red]L[/COLOR]'
   if 3 - 3: i1iIIIiI1I . iiIIiIiIi % i1IIi11111i + i11iiII
   if o0Oo0oO == "W" :
    o0Oo0oO = '[COLOR lime]W[/COLOR]'
   elif o0Oo0oO == "D" :
    o0Oo0oO = '[COLOR yellow]D[/COLOR]'
   else : o0Oo0oO = '[COLOR red]L[/COLOR]'
   if 64 - 64: II1Ii1iI1i
   OOOOOoo0 = iiI1I1IIi11i1 ( OOOOOoo0 )
   ii1 = iiI1I1IIi11i1 ( ii1 )
   O0oOoOO ( '[COLOR mediumpurple][B]' + OOOOOoo0 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[B]' + Ii + '  ' + I1i111IiIiIi1 + '  ' + i1II11II1 + '  ' + II1IIIii + '  ' + iIIIiIi1I1i + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR mediumpurple][B]' + ii1 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[B]' + OoOOoO0oOo + '  ' + O0ooOOOO0O0 + '  ' + i1IIi1i1Ii1 + '  ' + Iii + '  ' + o0Oo0oO + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 29 - 29: oo0ooO0oOOOOo / i11iIiiIii / i1IIi11111i % OooooO0oOO % i11iIiiIii
def i111II ( name , url , iconimage ) :
 if 63 - 63: i1IIi11111i - oo % i1iIIIiI1I % oo0Ooo0 / oo0ooO0oOOOOo / II1Ii1iI1i
 II1II = datetime . datetime . now ( )
 oo0O = II1II . day
 if 69 - 69: I11i1i11i1I * i1111 * iiIIiIiIi . i1iIIIiI1I - i11iiII
 iI1 = oo0O
 if 39 - 39: i1IIiiiii * i1IIi11111i % oo . OOO0O
 o0oO0OoO0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOOOOOoOO = datetime . datetime . strftime ( o0oO0OoO0 , '%A - %d %B %Y' )
 oooo00 = 'http://www.predictz.com/predictions/'
 if 24 - 24: II1Ii1iI1i * ooO0oo0oO0 / i1IIiiiii
 iiII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 o0Oii1111i = datetime . datetime . strftime ( iiII , '%A - %d %B %Y' )
 O0ooOO = datetime . datetime . strftime ( iiII , '%d' )
 IiiI = 'http://www.predictz.com/predictions/tomorrow/'
 if 78 - 78: i11iIiiIii + oo0ooO0oOOOOo + OooOoO0Oo / oo0ooO0oOOOOo % ooO0oo0oO0 % OoO000
 OoOO = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 II1i11i1iIi11 = datetime . datetime . strftime ( OoOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oo0O0oO0O0O = datetime . datetime . strftime ( OoOO , '%y%m%d' )
 oOo0O = 'http://www.predictz.com/predictions/20' + str ( oo0O0oO0O0O )
 if 83 - 83: ooO0oo0oO0 % OOO0O % oo0ooO0oOOOOo % OooOoO0Oo . i11iiII % oooO0oo0oOOOO
 i1i = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 IIIiiiI = datetime . datetime . strftime ( i1i , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoO00oo00 = datetime . datetime . strftime ( i1i , '%y%m%d' )
 Oo0Oo0O = 'http://www.predictz.com/predictions/20' + str ( OoO00oo00 )
 if 47 - 47: oo0ooO0oOOOOo
 I11Ii = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIiII = datetime . datetime . strftime ( I11Ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1i1IIIIIIIi = datetime . datetime . strftime ( I11Ii , '%y%m%d' )
 oo0o0oOo = 'http://www.predictz.com/predictions/20' + str ( i1i1IIIIIIIi )
 if 66 - 66: i1IIi11111i - OoO000
 if 33 - 33: i1IIi11111i / oo
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOOOOOoOO ) + '[/B][/COLOR]' , oooo00 , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( o0Oii1111i ) + '[/B][/COLOR]' , IiiI , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( II1i11i1iIi11 ) , oOo0O , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( IIIiiiI ) , Oo0Oo0O , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iIiII ) , oo0o0oOo , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 12 - 12: i1111
def IiIii1ii ( name , url , iconimage ) :
 if 8 - 8: oo + OOO0O . ooO0oo0oO0 % oooO0oo0oOOOO
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 Ii1iI111 = re . compile ( '<tr(.+?)</tr>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in Ii1iI111 :
  try :
   oOOOOoo = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR red][B]' + oOOOOoo + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iII1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OOOOOoo0 , ii1 = iII1 . split ( ' v ' )
   if 43 - 43: i11iiII - i1iIIIiI1I
   i1I = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iIii1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Ooo0oO0 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   o0Oo0oOooOoOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   Ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I1i111IiIiIi1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   i1II11II1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   II1IIIii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 3 ]
   iIIIiIi1I1i = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 4 ]
   OoOOoO0oOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 5 ]
   O0ooOOOO0O0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 6 ]
   i1IIi1i1Ii1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 7 ]
   Iii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 8 ]
   o0Oo0oO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 9 ]
   if 70 - 70: i1iIIIiI1I / oOo0 % iiIIiIiIi - i1IIiiiii
   if Ii == "W" :
    Ii = '[COLOR lime]W[/COLOR]'
   elif Ii == "D" :
    Ii = '[COLOR yellow]D[/COLOR]'
   else : Ii = '[COLOR red]L[/COLOR]'
   if 47 - 47: i1iIIIiI1I
   if I1i111IiIiIi1 == "W" :
    I1i111IiIiIi1 = '[COLOR lime]W[/COLOR]'
   elif I1i111IiIiIi1 == "D" :
    I1i111IiIiIi1 = '[COLOR yellow]D[/COLOR]'
   else : I1i111IiIiIi1 = '[COLOR red]L[/COLOR]'
   if 92 - 92: oOo0 + OOO0O % II1Ii1iI1i
   if i1II11II1 == "W" :
    i1II11II1 = '[COLOR lime]W[/COLOR]'
   elif i1II11II1 == "D" :
    i1II11II1 = '[COLOR yellow]D[/COLOR]'
   else : i1II11II1 = '[COLOR red]L[/COLOR]'
   if 23 - 23: OooOoO0Oo - oOo0 + i1IIiiiii - OOO0O * OOO0O . I11i1i11i1I
   if II1IIIii == "W" :
    II1IIIii = '[COLOR lime]W[/COLOR]'
   elif II1IIIii == "D" :
    II1IIIii = '[COLOR yellow]D[/COLOR]'
   else : II1IIIii = '[COLOR red]L[/COLOR]'
   if 47 - 47: OooooO0oOO % ooO0oo0oO0
   if iIIIiIi1I1i == "W" :
    iIIIiIi1I1i = '[COLOR lime]W[/COLOR]'
   elif iIIIiIi1I1i == "D" :
    iIIIiIi1I1i = '[COLOR yellow]D[/COLOR]'
   else : iIIIiIi1I1i = '[COLOR red]L[/COLOR]'
   if 11 - 11: i1IIi11111i % i1IIiiiii - oo - OooooO0oOO + oo0ooO0oOOOOo
   if OoOOoO0oOo == "W" :
    OoOOoO0oOo = '[COLOR lime]W[/COLOR]'
   elif OoOOoO0oOo == "D" :
    OoOOoO0oOo = '[COLOR yellow]D[/COLOR]'
   else : OoOOoO0oOo = '[COLOR red]L[/COLOR]'
   if 98 - 98: i1iIIIiI1I + i1IIiiiii - oo
   if O0ooOOOO0O0 == "W" :
    O0ooOOOO0O0 = '[COLOR lime]W[/COLOR]'
   elif O0ooOOOO0O0 == "D" :
    O0ooOOOO0O0 = '[COLOR yellow]D[/COLOR]'
   else : O0ooOOOO0O0 = '[COLOR red]L[/COLOR]'
   if 79 - 79: oOo0 / OooOoO0Oo . OOO0O - i11iiII
   if i1IIi1i1Ii1 == "W" :
    i1IIi1i1Ii1 = '[COLOR lime]W[/COLOR]'
   elif i1IIi1i1Ii1 == "D" :
    i1IIi1i1Ii1 = '[COLOR yellow]D[/COLOR]'
   else : i1IIi1i1Ii1 = '[COLOR red]L[/COLOR]'
   if 47 - 47: i111I % oooO0oo0oOOOO * i1iIIIiI1I . i1IIiiiii
   if Iii == "W" :
    Iii = '[COLOR lime]W[/COLOR]'
   elif Iii == "D" :
    Iii = '[COLOR yellow]D[/COLOR]'
   else : Iii = '[COLOR red]L[/COLOR]'
   if 38 - 38: oooO0oo0oOOOO - OoO000 % OooOoO0Oo
   if o0Oo0oO == "W" :
    o0Oo0oO = '[COLOR lime]W[/COLOR]'
   elif o0Oo0oO == "D" :
    o0Oo0oO = '[COLOR yellow]D[/COLOR]'
   else : o0Oo0oO = '[COLOR red]L[/COLOR]'
   if 64 - 64: ooO0oo0oO0
   OOOOOoo0 = iiI1I1IIi11i1 ( OOOOOoo0 )
   ii1 = iiI1I1IIi11i1 ( ii1 )
   iII1 = iiI1I1IIi11i1 ( iII1 )
   i1I = iiI1I1IIi11i1 ( i1I )
   O0oOoOO ( '[COLOR blue][B]' + iII1 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + i1I + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]' + OOOOOoo0 + ' Form: - [/COLOR][B]' + Ii + '  ' + I1i111IiIiIi1 + '  ' + i1II11II1 + '  ' + II1IIIii + '  ' + iIIIiIi1I1i + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]' + ii1 + ' Form - [/COLOR][B]' + OoOOoO0oOo + '  ' + O0ooOOOO0O0 + '  ' + i1IIi1i1Ii1 + '  ' + Iii + '  ' + o0Oo0oO + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]' + OOOOOoo0 + ' Win[/COLOR][COLOR dodgerblue][B] (' + iIii1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + Ooo0oO0 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]' + ii1 + ' Win[/COLOR][COLOR dodgerblue][B] (' + o0Oo0oOooOoOo + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 15 - 15: i11iiII + oOo0 / i11iiII / OooOoO0Oo
  except : pass
  if 31 - 31: iiIIiIiIi + oooO0oo0oOOOO + iiIIiIiIi . ooO0oo0oO0 + I11i1i11i1I / oo0ooO0oOOOOo
def II11i1IiIII ( name , url , iconimage ) :
 if 67 - 67: I11i1i11i1I / i1iIIIiI1I * i111I
 Ooo = [ ]
 o0oOOO0 = [ ]
 oOOO = [ ]
 iI1iIIII1 = [ ]
 OO0I11Ii1iI11iI1 = [ ]
 if 32 - 32: i1IIi11111i
 iII = o0 ( 'http://www.livescores.com' )
 Oo0oOOo = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 Ii1iI111 = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in Ii1iI111 :
  oO0O00oo = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  OOoOoo00Oo = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   i1I = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except :
   i1I = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 9 - 9: i1111 * i1111 . i11iIiiIii * ooO0oo0oO0
  if "minute" in time . lower ( ) :
   OO0I11Ii1iI11iI1 . append ( '3' )
  elif "ht" in time . lower ( ) :
   OO0I11Ii1iI11iI1 . append ( '3' )
  elif "ft" in time . lower ( ) :
   OO0I11Ii1iI11iI1 . append ( '2' )
  else : OO0I11Ii1iI11iI1 . append ( '1' )
  if 18 - 18: oo . i1111 % OOO0O % i1IIiiiii
  Ooo . append ( oO0O00oo )
  o0oOOO0 . append ( OOoOoo00Oo )
  oOOO . append ( i1I )
  iI1iIIII1 . append ( time )
  IIii1111 = list ( zip ( OO0I11Ii1iI11iI1 , Ooo , o0oOOO0 , oOOO , iI1iIIII1 ) )
  if 87 - 87: ooO0oo0oO0 . i111I * OOO0O
 O0oOoOO ( '[COLOR dodgerblue][B]The scores will update every 10 seconds.[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 O0oOoOO ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 100 - 100: oo / II1Ii1iI1i - i1IIi11111i % i1IIiiiii - ooO0oo0oO0
 oo0o0000 = sorted ( IIii1111 , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 i11II = 0
 o0o = 0
 o00o0O0O00 = 0
 for iIIOOoO0oO00o , iiiiii1 , OO0o0oO0O000o , I1iI11iii , oo0oO in oo0o0000 :
  if iIIOOoO0oO00o == "3" :
   if i11II == 0 :
    O0oOoOO ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    i11II = 1
  elif iIIOOoO0oO00o == "2" :
   if o0o == 0 :
    O0oOoOO ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    o0o = 1
  elif iIIOOoO0oO00o == "1" :
   if o00o0O0O00 == 0 :
    O0oOoOO ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    o00o0O0O00 = 1
  oo0oO = oo0oO . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  I1iI11iii = I1iI11iii . replace ( " " , "" )
  O0oOoOO ( '[COLOR red][B]' + oo0oO + "[/B][/COLOR]- [COLOR blue]" + I1iI11iii + "[/COLOR] | [COLOR white]" + iiiiii1 + "vs" + OO0o0oO0O000o + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 50 - 50: i111I - ooO0oo0oO0 + II1Ii1iI1i % OooOoO0Oo - ooO0oo0oO0 % oooO0oo0oOOOO
def o0oO0Oo ( ) :
 if 71 - 71: oo0ooO0oOOOOo - OOO0O * i1iIIIiI1I + i1IIiiiii % i11iIiiIii - iiIIiIiIi
 oo0O00Oooo0O0 = ''
 o0O0OO0o = xbmc . Keyboard ( oo0O00Oooo0O0 , 'Enter Search Term' )
 o0O0OO0o . doModal ( )
 if o0O0OO0o . isConfirmed ( ) :
  oo0O00Oooo0O0 = o0O0OO0o . getText ( )
  if len ( oo0O00Oooo0O0 ) > 1 :
   O000oo = oo0O00Oooo0O0 + "!" + iiiii
   ii1I11 ( "all " + oo0O00Oooo0O0 , O000oo , iiiii )
  else : quit ( )
  if 54 - 54: OOO0O . OooooO0oOO % i11iIiiIii / i111I + OoO000 % OooooO0oOO
def i1ii1IIiI ( name , url , iconimage ) :
 if 31 - 31: oo * i11iIiiIii * i1IIiiiii . i11iIiiIii
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 12 - 12: OOO0O % OoO000 % i11iiII . i11iIiiIii * ooO0oo0oO0
def oO0o0O0Ooo0o ( text ) :
 if 66 - 66: i11iIiiIii * ooO0oo0oO0 % i111I
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 5 - 5: OOO0O % i111I
 return text
 if 60 - 60: OOO0O . II1Ii1iI1i % oo % iiIIiIiIi % oOo0
def iiI1I1IIi11i1 ( text ) :
 if 33 - 33: ooO0oo0oO0 - i1IIiiiii * i11iiII % ooO0oo0oO0 + oo . oOo0
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 56 - 56: i11iIiiIii * i1iIIIiI1I . OooooO0oOO
 return text
 if 78 - 78: OOO0O
def I1iii ( text ) :
 if 1 - 1: oOo0 . OoO000
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 42 - 42: oOo0 % OooooO0oOO / oo - OooooO0oOO * i11iIiiIii
 return text
 if 19 - 19: OooooO0oOO * i1IIi11111i % i11iIiiIii
def o0Oo0oO0oOO00 ( name , url , iconimage ) :
 if 24 - 24: oo0ooO0oOOOOo
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]Opening link...[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 10 - 10: oo0ooO0oOOOOo % i1IIiiiii / oOo0
 if "pl_type=user" in url :
  OOO = o0 ( url )
  url = re . compile ( '<meta property="og:video:iframe" content="(.+?)">' ) . findall ( OOO ) [ 0 ]
  if 28 - 28: oOo0 % iiIIiIiIi
 if not "plugin" in url :
  try :
   if not 'http' in url : url = 'http://' + url
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 48 - 48: i11iIiiIii % OooooO0oOO
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 29 - 29: i1iIIIiI1I + i11iIiiIii % oo0Ooo0
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  oOo00Ooo0o0 = urlresolver . HostedMediaFile ( url ) . resolve ( )
  i1IiII1i1I = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  i1IiII1i1I . setPath ( oOo00Ooo0o0 )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( oOo00Ooo0o0 , i1IiII1i1I , False )
  quit ( )
 else :
  oOo00Ooo0o0 = url
  i1IiII1i1I = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  i1IiII1i1I . setPath ( oOo00Ooo0o0 )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( oOo00Ooo0o0 , i1IiII1i1I , False )
  quit ( )
  if 39 - 39: oo0Ooo0
def i1I1ii11i1Iii ( ) :
 if 64 - 64: ooO0oo0oO0 / oooO0oo0oOOOO % OoO000 . i111I + OoO000 + OooooO0oOO
 Oo00o0O0O = xbmc . getInfoLabel ( "System.BuildVersion" )
 o0ooO0OoOo = float ( Oo00o0O0O [ : 4 ] )
 if o0ooO0OoOo >= 11.0 and o0ooO0OoOo <= 11.9 :
  o0oOO00 = 'Eden'
 elif o0ooO0OoOo >= 12.0 and o0ooO0OoOo <= 12.9 :
  o0oOO00 = 'Frodo'
 elif o0ooO0OoOo >= 13.0 and o0ooO0OoOo <= 13.9 :
  o0oOO00 = 'Gotham'
 elif o0ooO0OoOo >= 14.0 and o0ooO0OoOo <= 14.9 :
  o0oOO00 = 'Helix'
 elif o0ooO0OoOo >= 15.0 and o0ooO0OoOo <= 15.9 :
  o0oOO00 = 'Isengard'
 elif o0ooO0OoOo >= 16.0 and o0ooO0OoOo <= 16.9 :
  o0oOO00 = 'Jarvis'
 elif o0ooO0OoOo >= 17.0 and o0ooO0OoOo <= 17.9 :
  o0oOO00 = 'Krypton'
 else : o0oOO00 = "Decline"
 if 46 - 46: i11iIiiIii - oo0Ooo0
 return o0oOO00
 if 95 - 95: i1111
def o0 ( url ) :
 if 65 - 65: OOO0O
 I1iI11I1III1 = urllib2 . Request ( url )
 I1iI11I1III1 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 oo0O0oo = urllib2 . urlopen ( I1iI11I1III1 )
 iII = oo0O0oo . read ( )
 oo0O0oo . close ( )
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return iII
 if 8 - 8: i11iIiiIii / i1111 + oo0ooO0oOOOOo * i1IIiiiii % OoO000 . oo0Ooo0
def Oo0O0O0ooO0O ( url ) :
 if 6 - 6: OoO000 % I11i1i11i1I . I11i1i11i1I - i11iiII / oo0Ooo0 . II1Ii1iI1i
 I1iI11I1III1 = urllib2 . Request ( url )
 I1iI11I1III1 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 oo0O0oo = urllib2 . urlopen ( I1iI11I1III1 )
 iII = oo0O0oo . read ( )
 oo0O0oo . close ( )
 return iII
 if 99 - 99: OOO0O . OooOoO0Oo
def OO0 ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 59 - 59: oo0Ooo0 / I11i1i11i1I / oOo0 / oooO0oo0oOOOO / OOO0O + oo0ooO0oOOOOo
 if 13 - 13: oo0ooO0oOOOOo % OooooO0oOO / OooOoO0Oo % OooOoO0Oo % oooO0oo0oOOOO
 if 90 - 90: OoO000 . iiIIiIiIi / ooO0oo0oO0
 if 28 - 28: OoO000 + OooooO0oOO - iiIIiIiIi / ooO0oo0oO0 - i1IIi11111i
 if 45 - 45: oooO0oo0oOOOO / II1Ii1iI1i * OooooO0oOO * oo
def II11I ( ) :
 if 31 - 31: i1IIiiiii
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 18 - 18: iiIIiIiIi + i1IIiiiii
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for ii11i11 , OooiiIii , iii1IIiI in os . walk ( IiIi11iIIi1Ii ) :
   i1i1Ii11Ii = 0
   i1i1Ii11Ii += len ( iii1IIiI )
   if i1i1Ii11Ii > 0 :
    for Oooo in iii1IIiI :
     try :
      if ( Oooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( ii11i11 , Oooo ) )
     except :
      pass
    for O000oOo in OooiiIii :
     try :
      shutil . rmtree ( os . path . join ( ii11i11 , O000oOo ) )
     except :
      pass
      if 41 - 41: oooO0oo0oOOOO + OooooO0oOO . II1Ii1iI1i - i1111 * oo0ooO0oOOOOo . oo
   else :
    pass
    if 68 - 68: oo0ooO0oOOOOo
 if os . path . exists ( Oo0O ) == True :
  for ii11i11 , OooiiIii , iii1IIiI in os . walk ( Oo0O ) :
   i1i1Ii11Ii = 0
   i1i1Ii11Ii += len ( iii1IIiI )
   if i1i1Ii11Ii > 0 :
    for Oooo in iii1IIiI :
     try :
      if ( Oooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( ii11i11 , Oooo ) )
     except :
      pass
    for O000oOo in OooiiIii :
     try :
      shutil . rmtree ( os . path . join ( ii11i11 , O000oOo ) )
     except :
      pass
      if 20 - 20: OooOoO0Oo - OooOoO0Oo
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iIIiI11i1I11 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 29 - 29: oo * ooO0oo0oO0 * oooO0oo0oOOOO - OOO0O / OoO000
  for ii11i11 , OooiiIii , iii1IIiI in os . walk ( iIIiI11i1I11 ) :
   i1i1Ii11Ii = 0
   i1i1Ii11Ii += len ( iii1IIiI )
   if 99 - 99: iiIIiIiIi
   if i1i1Ii11Ii > 0 :
    for Oooo in iii1IIiI :
     os . unlink ( os . path . join ( ii11i11 , Oooo ) )
    for O000oOo in OooiiIii :
     shutil . rmtree ( os . path . join ( ii11i11 , O000oOo ) )
     if 76 - 76: oo
   else :
    pass
  o00ooOOo = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 83 - 83: i11iiII / i11iIiiIii + i1111 . i1iIIIiI1I * oOo0 + OoO000
  for ii11i11 , OooiiIii , iii1IIiI in os . walk ( o00ooOOo ) :
   i1i1Ii11Ii = 0
   i1i1Ii11Ii += len ( iii1IIiI )
   if 42 - 42: II1Ii1iI1i % i1111 . iiIIiIiIi
   if i1i1Ii11Ii > 0 :
    for Oooo in iii1IIiI :
     os . unlink ( os . path . join ( ii11i11 , Oooo ) )
    for O000oOo in OooiiIii :
     shutil . rmtree ( os . path . join ( ii11i11 , O000oOo ) )
     if 7 - 7: i11iiII - OooooO0oOO * oOo0 + oo0ooO0oOOOOo . i11iiII
   else :
    pass
    if 85 - 85: oooO0oo0oOOOO
 iii11 = o00oOO0 ( )
 if 32 - 32: i111I . oo / I11i1i11i1I * oo0ooO0oOOOOo / oo0ooO0oOOOOo * i1IIiiiii
 for iI111i11iI1 in iii11 :
  III1ii = xbmc . translatePath ( iI111i11iI1 . path )
  if os . path . exists ( III1ii ) == True :
   for ii11i11 , OooiiIii , iii1IIiI in os . walk ( III1ii ) :
    i1i1Ii11Ii = 0
    i1i1Ii11Ii += len ( iii1IIiI )
    if i1i1Ii11Ii > 0 :
     for Oooo in iii1IIiI :
      os . unlink ( os . path . join ( ii11i11 , Oooo ) )
     for O000oOo in OooiiIii :
      shutil . rmtree ( os . path . join ( ii11i11 , O000oOo ) )
      if 23 - 23: OooooO0oOO * i1iIIIiI1I
    else :
     pass
     if 53 - 53: i1IIiiiii - OOO0O . i1iIIIiI1I . OooOoO0Oo
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 48 - 48: i1iIIIiI1I + OoO000
def O0o0o0 ( ) :
 iii = [ ]
 O0 = sys . argv [ 2 ]
 if len ( O0 ) >= 2 :
  OoOOOo0o0ooo = sys . argv [ 2 ]
  o0Oii111 = OoOOOo0o0ooo . replace ( '?' , '' )
  if ( OoOOOo0o0ooo [ len ( OoOOOo0o0ooo ) - 1 ] == '/' ) :
   OoOOOo0o0ooo = OoOOOo0o0ooo [ 0 : len ( OoOOOo0o0ooo ) - 2 ]
  ooOo000OoO0o = o0Oii111 . split ( '&' )
  iii = { }
  for IIIIii1I in range ( len ( ooOo000OoO0o ) ) :
   ooooo0O0 = { }
   ooooo0O0 = ooOo000OoO0o [ IIIIii1I ] . split ( '=' )
   if ( len ( ooooo0O0 ) ) == 2 :
    iii [ ooooo0O0 [ 0 ] ] = ooooo0O0 [ 1 ]
 return iii
 if 10 - 10: oo0Ooo0 - I11i1i11i1I
def II11i1I11Ii1i ( name , url , mode , iconimage , fanart , description = '' ) :
 if 59 - 59: i111I * I11i1i11i1I + II1Ii1iI1i
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 iiii11IiiiiIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 oo0oo0O0 = True
 i1IiII1i1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1IiII1i1I . setProperty ( "fanart_Image" , fanart )
 i1IiII1i1I . setProperty ( "icon_Image" , iconimage )
 oo0oo0O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii11IiiiiIi , listitem = i1IiII1i1I , isFolder = True )
 return oo0oo0O0
 if 18 - 18: ooO0oo0oO0 + oOo0 + ooO0oo0oO0 . i11iiII + OooOoO0Oo . iiIIiIiIi
def O0oOoOO ( name , url , mode , iconimage , fanart , description = '' ) :
 if 7 - 7: i11iiII + ooO0oo0oO0 * oo0Ooo0 * oo0Ooo0 / i1111 - i1IIiiiii
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 iiii11IiiiiIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 oo0oo0O0 = True
 i1IiII1i1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1IiII1i1I . setProperty ( "fanart_Image" , fanart )
 i1IiII1i1I . setProperty ( "icon_Image" , iconimage )
 oo0oo0O0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iiii11IiiiiIi , listitem = i1IiII1i1I , isFolder = False )
 return oo0oo0O0
 if 65 - 65: OooooO0oOO + OOO0O + i1111
OoOOOo0o0ooo = O0o0o0 ( ) ; O000oo = None ; OoOO0oo0o = None ; oOOoo = None ; i1I1iIii11 = None ; Oo0oOOOoOooOo = None ; oOooOOOoOo = None
try : i1I1iIii11 = urllib . unquote_plus ( OoOOOo0o0ooo [ "site" ] )
except : pass
try : O000oo = urllib . unquote_plus ( OoOOOo0o0ooo [ "url" ] )
except : pass
try : OoOO0oo0o = urllib . unquote_plus ( OoOOOo0o0ooo [ "name" ] )
except : pass
try : oOOoo = int ( OoOOOo0o0ooo [ "mode" ] )
except : pass
try : Oo0oOOOoOooOo = urllib . unquote_plus ( OoOOOo0o0ooo [ "iconimage" ] )
except : pass
try : oOooOOOoOo = urllib . unquote_plus ( OoOOOo0o0ooo [ "fanart" ] )
except : pass
if 80 - 80: OOO0O - i1111
if oOOoo == None or O000oo == None or len ( O000oo ) < 1 : o0O0o0Oo ( )
elif oOOoo == 1 : I1i ( OoOO0oo0o , O000oo )
elif oOOoo == 2 : o0Oo0oO0oOO00 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 3 : O00oO000O0O ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 4 : PLAYSD ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 7 : o0000oO ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 8 : II1IIIIiII1i ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 9 : AUTO_UPDATER ( OoOO0oo0o )
elif oOOoo == 10 : oOooO00o0O ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 11 : o0oO000oo ( )
elif oOOoo == 12 : ii1Oo0000oOo ( O000oo )
elif oOOoo == 19 : oOOOO ( O000oo )
elif oOOoo == 20 : ii1I11 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 21 : OoOO00 ( O000oo )
elif oOOoo == 22 : ooOoo0o0O ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 23 : iI11I ( )
elif oOOoo == 24 : iiI11i1II ( )
elif oOOoo == 25 : OOOO0OOO ( )
elif oOOoo == 26 : II1i1III ( )
elif oOOoo == 30 : OOoo ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 40 : Ii1 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 41 : OOoO ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 50 : i1i1 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 51 : iI1iIIiI1ii ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 60 : ooOo0O0o0 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 61 : OOoo0 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 70 : i111II ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 71 : IiIii1ii ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 80 : II11i1IiIII ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 90 : IiIi1I1 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 91 : iI1IiI11ii1I1 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 95 : I11i1II ( )
elif oOOoo == 96 : i11IIIiIiIi ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 100 : o0oO0Oo ( )
elif oOOoo == 500 : II11I ( )
elif oOOoo == 201 : iii1i1I1i1 ( )
elif oOOoo == 202 : OOoooiIIiIiI1I1 ( O000oo )
elif oOOoo == 203 : i1iI1 ( O000oo )
elif oOOoo == 204 : IIi ( O000oo )
elif oOOoo == 205 : O0ooooo0OOOO0 ( O000oo )
elif oOOoo == 206 : IIiiI ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 210 : iI1i1i ( O000oo )
elif oOOoo == 220 : i1iiIiI1Ii1i ( O000oo )
elif oOOoo == 221 : Oo00OoOo ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 800 : i1ii1IIiI ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif oOOoo == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 35 - 35: iiIIiIiIi - oo . I11i1i11i1I * I11i1i11i1I / i11iIiiIii + i11iiII
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if oOOoo == 80 :
 xbmc . sleep ( 10000 )
 xbmc . executebuiltin ( 'Container.Refresh' )