import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
import datetime
import requests
from resources . lib . modules import regex
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = base64 . decodestring ( 'aHR0cDovL3RkYnJlcG8uY29tL3ByaXZhdGUvYWRkb25zL3Nwb3J0aWUvbWVudXMvbWFpbi54bWw=' )
II1 = xbmcgui . Dialog ( )
O00ooooo00 = xbmcgui . DialogProgress ( )
I1IiiI = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
I11i11Ii = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
OOOo0 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
if 59 - 59: I11i / Ii1I
IiiIII111iI = {
 'User-Agent' : base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) ,
 }
IiII = {
 'User-Agent' : 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' ,
 }
if 28 - 28: Ii11111i * iiI1i1
#######################################################################
#						Cache Functions
#######################################################################
if 46 - 46: Ooo0OO0oOO * Ii * Oo0o
class OOO0o0o ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 40 - 40: II / oo00 * i1I1Ii1iI1ii * o0oOoO00o . i1
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 64 - 64: oo % O0Oooo00
Ooo0 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 89 - 89: I111i1i1111i - Ii1Ii1iiii11 % I1I1i1
class IiI1i :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 61 - 61: oo0O000OoO + IiiIIiiI11 / i1 * Ii
  if 55 - 55: Ooo0OO0oOO
  if 43 - 43: oo00 - iiI1i1 + oo0O000OoO + I111i1i1111i
  if 17 - 17: i1I1Ii1iI1ii
def o00ooooO0oO ( ) :
 oOoOo00oOo = 5
 Oo = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 o00O00O0O0O = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 90 - 90: Ooo0OO0oOO + i1 / i1I1Ii1iI1ii % Ooo0OO0oOO - I11i
 iIii1 = [ ]
 if 71 - 71: II
 for oO0O in range ( oOoOo00oOo ) :
  iIii1 . append ( IiI1i ( Oo [ oO0O ] , o00O00O0O0O [ oO0O ] ) )
  if 70 - 70: Oo0o % Oo0o . I1I1i1 % II * i1I1Ii1iI1ii % i1
 return iIii1
 if 23 - 23: i11iIiiIii + Ii
def oOo ( ) :
 if 63 - 63: Oo0o
 if 57 - 57: i1
 if 14 - 14: Oo0o . Ii / I111i1i1111i
 if 38 - 38: Ooo0OO0oOO % i11iIiiIii . IiiIIiiI11 - oo + I111i1i1111i
 if 66 - 66: Ii11111i * Ii11111i . oo . iiI1i1 - oo
 if 77 - 77: O0Oooo00 - Ii1I
 if 82 - 82: i11iIiiIii . oo / Oo0o * I11i % i1 % Ii1I
 if 78 - 78: Ii1I - I111i1i1111i * II + i1I1Ii1iI1ii + Ii1Ii1iiii11 + Ii1Ii1iiii11
 if 11 - 11: Ii1Ii1iiii11 - II % IiiIIiiI11 % Ii1Ii1iiii11 / oo00 - II
 if 74 - 74: Ii1Ii1iiii11 * I11i
 if 89 - 89: i1 + Oo0o
 Ii1IOo0o0 = open ( I1IiiI ) . read ( )
 III1ii1iII = Ii1IOo0o0 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 oo0oooooO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( III1ii1iII ) )
 for i11Iiii in oo0oooooO0 :
  iI = float ( i11Iiii )
  if 28 - 28: oo - I1I1i1 . I1I1i1 + oo00 - Ii11111i + I11i
 oOoOooOo0o0 = OOOO ( ooo0OO )
 oOoOooOo0o0 = base64 . b64decode ( oOoOooOo0o0 )
 oOoOooOo0o0 = oOoOooOo0o0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oo0oooooO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( oOoOooOo0o0 )
 for i11Iiii in oo0oooooO0 :
  if 87 - 87: i1 / O0Oooo00 - iiI1i1 * oo / Ii11111i . I11i
  if '<search>ZGlzcGxheQ==</search>' in i11Iiii :
   iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
   iii11I111 = base64 . b64decode ( iii11I111 )
   OOOO00ooo0Ooo ( iii11I111 , ooo0OO , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 69 - 69: i1I1Ii1iI1ii * I11i + II . Ooo0OO0oOO / I11i
  elif '<vipchannels>' in i11Iiii :
   iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
   O000oo0O = re . compile ( '<vipchannels>(.+?)</vipchannels>' ) . findall ( i11Iiii ) [ 0 ]
   iii11I111 = base64 . b64decode ( iii11I111 )
   O000oo0O = base64 . b64decode ( O000oo0O )
   OOOO00ooo0Ooo ( iii11I111 , O000oo0O , 19 , iiiii , O0O0OO0O0O0 )
   if 66 - 66: o0oOoO00o / oo00 - Ii . oo / Ii * oo
  elif '<vipgames>' in i11Iiii :
   iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
   O000oo0O = re . compile ( '<vipgames>(.+?)</vipgames>' ) . findall ( i11Iiii ) [ 0 ]
   iii11I111 = base64 . b64decode ( iii11I111 )
   O000oo0O = base64 . b64decode ( O000oo0O )
   OOOO00ooo0Ooo ( iii11I111 , O000oo0O , 21 , iiiii , O0O0OO0O0O0 )
   if 29 - 29: o0oOoO00o % Ii + IiiIIiiI11 / i1I1Ii1iI1ii + oo * i1I1Ii1iI1ii
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in i11Iiii :
   iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
   iii11I111 = base64 . b64decode ( iii11I111 )
   OOOO00ooo0Ooo ( iii11I111 , ooo0OO , 11 , iiiii , O0O0OO0O0O0 )
   if 42 - 42: I111i1i1111i + i1
  elif '<sportsscrape>ZGlzcGxheQ==</sportsscrape>' in i11Iiii :
   iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
   O000oo0O = re . compile ( '<link>(.+?)</link>' ) . findall ( i11Iiii ) [ 0 ]
   iii11I111 = base64 . b64decode ( iii11I111 )
   O000oo0O = base64 . b64decode ( O000oo0O )
   OOOO00ooo0Ooo ( iii11I111 , O000oo0O , 205 , iiiii , O0O0OO0O0O0 )
   if 76 - 76: oo0O000OoO - II
   if 70 - 70: IiiIIiiI11
   if 61 - 61: o0oOoO00o . o0oOoO00o
   if 10 - 10: oo00 * Ii1Ii1iiii11 . O0Oooo00 + Ooo0OO0oOO - IiiIIiiI11 * iiI1i1
   if 56 - 56: i1I1Ii1iI1ii * I1I1i1 * Ooo0OO0oOO
   if 80 - 80: i1I1Ii1iI1ii * Ooo0OO0oOO % Ooo0OO0oOO
   if 59 - 59: Ii1I + Ii - i1I1Ii1iI1ii - Ii + oo / o0oOoO00o
   if 24 - 24: O0Oooo00 . Ii1Ii1iiii11 % oo + IiiIIiiI11 % oo00
   if 4 - 4: I1I1i1 - II * oo00 - O0Oooo00
   if 41 - 41: oo00 . Ii * i1 % I1I1i1
   if 86 - 86: Ii + I111i1i1111i % i11iIiiIii * i1 . IiiIIiiI11 * O0Oooo00
   if 44 - 44: i1
   if 88 - 88: oo0O000OoO % I111i1i1111i . Ooo0OO0oOO
   if 38 - 38: i1I1Ii1iI1ii
   if 57 - 57: I11i / i1 * oo0O000OoO / oo00 . Ooo0OO0oOO
  elif '<sportsdevil>' in i11Iiii :
   i11iIIIIIi1 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( i11Iiii )
   if len ( i11iIIIIIi1 ) == 1 :
    iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
    iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
    O000oo0O = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( i11Iiii ) [ 0 ]
    o00oOO0o = re . compile ( '<referer>(.+?)</referer>' ) . findall ( i11Iiii ) [ 0 ]
    iii11I111 = base64 . b64decode ( iii11I111 )
    iiII1i1 = base64 . b64decode ( iiII1i1 )
    O000oo0O = base64 . b64decode ( O000oo0O )
    o00oOO0o = base64 . b64decode ( o00oOO0o )
    OOO00O = o00oOO0o
    OOoOO0oo0ooO = "/"
    if not OOO00O . endswith ( OOoOO0oo0ooO ) :
     O0o0O00Oo0o0 = OOO00O + "/"
    else :
     O0o0O00Oo0o0 = OOO00O
    oOoOooOo0o0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( iii11I111 ) + '%26url=' + O000oo0O
    O000oo0O = oOoOooOo0o0 + '%26referer=' + O0o0O00Oo0o0
    O00O0oOO00O00 ( iii11I111 , O000oo0O , 4 , iiII1i1 , i1Oo00 )
   elif len ( i11iIIIIIi1 ) > 1 :
    iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
    iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
    iii11I111 = base64 . b64decode ( iii11I111 )
    iiII1i1 = base64 . b64decode ( iiII1i1 )
    O00O0oOO00O00 ( iii11I111 , url2 + 'NOTPLAY' , 8 , iiII1i1 , i1Oo00 )
    if 31 - 31: oo0O000OoO . oo00 / I11i
  elif '<folder>' in i11Iiii :
   o000O0o = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i11Iiii )
   for iii11I111 , O000oo0O , iiII1i1 , i1Oo00 in o000O0o :
    iii11I111 = base64 . b64decode ( iii11I111 )
    O000oo0O = base64 . b64decode ( O000oo0O )
    iiII1i1 = base64 . b64decode ( iiII1i1 )
    i1Oo00 = base64 . b64decode ( i1Oo00 )
    OOOO00ooo0Ooo ( iii11I111 , O000oo0O , 1 , iiII1i1 , i1Oo00 )
  elif '<m3u>' in i11Iiii :
   o000O0o = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i11Iiii )
   for iii11I111 , O000oo0O , iiII1i1 , i1Oo00 in o000O0o :
    iii11I111 = base64 . b64decode ( iii11I111 )
    O000oo0O = base64 . b64decode ( O000oo0O )
    iiII1i1 = base64 . b64decode ( iiII1i1 )
    i1Oo00 = base64 . b64decode ( i1Oo00 )
    OOOO00ooo0Ooo ( iii11I111 , O000oo0O , 10 , iiII1i1 , i1Oo00 )
  else :
   i11iIIIIIi1 = re . compile ( '<link>(.+?)</link>' ) . findall ( i11Iiii )
   if len ( i11iIIIIIi1 ) == 1 :
    o000O0o = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i11Iiii )
    iI1iII1 = len ( oo0oooooO0 )
    for iii11I111 , O000oo0O , iiII1i1 , i1Oo00 in o000O0o :
     iii11I111 = base64 . b64decode ( iii11I111 )
     O000oo0O = base64 . b64decode ( O000oo0O )
     iiII1i1 = base64 . b64decode ( iiII1i1 )
     i1Oo00 = base64 . b64decode ( i1Oo00 )
     O00O0oOO00O00 ( iii11I111 , O000oo0O , 2 , iiII1i1 , i1Oo00 )
   elif len ( i11iIIIIIi1 ) > 1 :
    iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
    iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
    i1Oo00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( i11Iiii ) [ 0 ]
    iii11I111 = base64 . b64decode ( iii11I111 )
    iiII1i1 = base64 . b64decode ( iiII1i1 )
    i1Oo00 = base64 . b64decode ( i1Oo00 )
    O00O0oOO00O00 ( iii11I111 , ooo0OO , 3 , iiII1i1 , i1Oo00 )
    if 86 - 86: oo
 OOoo0O ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , ooo0OO , 500 , iiiii , O0O0OO0O0O0 , "" )
 OOoo0O ( '[COLOR dodgerblue]VER ' + str ( iI ) + '[/COLOR][COLOR yellow] - CHECK FOR UPDATES[/COLOR]' , ooo0OO , 9 , iiiii , O0O0OO0O0O0 , "" )
 if 67 - 67: i11iIiiIii - iiI1i1 % o0oOoO00o . I11i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 77 - 77: I1I1i1 / Ii
def I1 ( name , url ) :
 if 15 - 15: Ooo0OO0oOO
 hash = [ ]
 Iiooo0O = url
 oOoOooOo0o0 = OOOO ( url )
 if 75 - 75: i1I1Ii1iI1ii % i1I1Ii1iI1ii . oo0O000OoO
 oo0oooooO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( oOoOooOo0o0 )
 for i11Iiii in oo0oooooO0 :
  if 5 - 5: i1I1Ii1iI1ii * IiiIIiiI11 + oo00 . oo + oo00
  if '<regex>' in i11Iiii :
   oO = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( i11Iiii )
   oO = '' . join ( oO )
   iIi1IIIi1 = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( oO )
   oO = urllib . quote_plus ( oO )
   if 86 - 86: O0Oooo00 % oo00 / Ii / oo00
   iIIi1i1 = hashlib . md5 ( )
   for i1IIIiiII1 in oO : iIIi1i1 . update ( str ( i1IIIiiII1 ) )
   iIIi1i1 = str ( iIIi1i1 . hexdigest ( ) )
   if 87 - 87: i1 * o0oOoO00o + oo / Ii1I / Ii1Ii1iiii11
   i11Iiii = i11Iiii . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   i11Iiii = re . sub ( '<regex>.+?</regex>' , '' , i11Iiii )
   i11Iiii = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , i11Iiii )
   i11Iiii = re . sub ( '<link></link>' , '' , i11Iiii )
   if 37 - 37: Ii1Ii1iiii11 - IiiIIiiI11 * i1 % i11iIiiIii - oo0O000OoO
   name = re . sub ( '<meta>.+?</meta>' , '' , i11Iiii )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 83 - 83: O0Oooo00 / Ii
   try : iIIiIi1iIII1 = re . findall ( '<date>(.+?)</date>' , i11Iiii ) [ 0 ]
   except : iIIiIi1iIII1 = ''
   if re . search ( r'\d+' , iIIiIi1iIII1 ) : name += ' [COLOR red] Updated %s[/COLOR]' % iIIiIi1iIII1
   if 78 - 78: I11i . i1 . Ooo0OO0oOO % oo
   try : i1iIi = re . findall ( '<thumbnail>(.+?)</thumbnail>' , i11Iiii ) [ 0 ]
   except : i1iIi = iiiii
   if 68 - 68: i11iIiiIii % o0oOoO00o + i11iIiiIii
   try : iii = re . findall ( '<fanart>(.+?)</fanart>' , i11Iiii ) [ 0 ]
   except : iii = O0O0OO0O0O0
   if 1 - 1: Oo0o / i1I1Ii1iI1ii % Ii1Ii1iiii11 * I1I1i1 . i11iIiiIii
   try : III1Iiii1I11 = re . findall ( '<meta>(.+?)</meta>' , i11Iiii ) [ 0 ]
   except : III1Iiii1I11 = '0'
   if 9 - 9: o0oOoO00o / Oo0o - Ii / Ii11111i / Ii1I - i1I1Ii1iI1ii
   try : url = re . findall ( '<link>(.+?)</link>' , i11Iiii ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % III1Iiii1I11 )
   url = '<preset>search</preset>%s' % III1Iiii1I11 if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % III1Iiii1I11 )
   url = '<preset>searchsd</preset>%s' % III1Iiii1I11 if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 91 - 91: Ii1Ii1iiii11 % iiI1i1 % Ii1I
   if not oO == '' :
    hash . append ( { 'regex' : iIIi1i1 , 'response' : oO } )
    url += '|regex=%s' % oO
    if 20 - 20: oo % I111i1i1111i / I111i1i1111i + I111i1i1111i
   O00O0oOO00O00 ( name , url , 30 , i1iIi , iii )
   if 45 - 45: i1 - I1I1i1 - Ii11111i - II . Ooo0OO0oOO / I11i
  elif '<sportsdevil>' in i11Iiii :
   i11iIIIIIi1 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( i11Iiii )
   if len ( i11iIIIIIi1 ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( i11Iiii ) [ 0 ]
    try :
     o00oOO0o = re . compile ( '<referer>(.+?)</referer>' ) . findall ( i11Iiii ) [ 0 ]
    except : o00oOO0o = "None"
    iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
    try :
     i1Oo00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( i11Iiii ) [ 0 ]
    except : i1Oo00 = O0O0OO0O0O0
    OOO00O = o00oOO0o
    OOoOO0oo0ooO = "/"
    if not OOO00O . endswith ( OOoOO0oo0ooO ) :
     O0o0O00Oo0o0 = OOO00O + "/"
    else :
     O0o0O00Oo0o0 = OOO00O
    oOoOooOo0o0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = oOoOooOo0o0 + '%26referer=' + O0o0O00Oo0o0
    O00O0oOO00O00 ( name , url , 2 , iiII1i1 , i1Oo00 )
    if 51 - 51: I11i + Ii1Ii1iiii11
   elif len ( i11iIIIIIi1 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
    iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
    try :
     i1Oo00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( i11Iiii ) [ 0 ]
    except : i1Oo00 = O0O0OO0O0O0
    O00O0oOO00O00 ( name , Iiooo0O + 'NOTPLAY' , 8 , iiII1i1 , i1Oo00 )
    if 8 - 8: i1 * oo00 - I111i1i1111i - II * oo % Ii
  elif '<folder>' in i11Iiii :
   o000O0o = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i11Iiii )
   for name , url , iiII1i1 , i1Oo00 in o000O0o :
    OOOO00ooo0Ooo ( name , url , 1 , iiII1i1 , i1Oo00 )
    if 48 - 48: I11i
  elif '<m3u>' in i11Iiii :
   o000O0o = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i11Iiii )
   for name , url , iiII1i1 , i1Oo00 in o000O0o :
    OOOO00ooo0Ooo ( name , url , 10 , iiII1i1 , i1Oo00 )
    if 11 - 11: O0Oooo00 + Ii11111i - II / i1I1Ii1iI1ii + Oo0o . Ooo0OO0oOO
  else :
   i11iIIIIIi1 = re . compile ( '<link>(.+?)</link>' ) . findall ( i11Iiii )
   if len ( i11iIIIIIi1 ) == 1 :
    o000O0o = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( i11Iiii )
    iI1iII1 = len ( oo0oooooO0 )
    for name , url , iiII1i1 , i1Oo00 in o000O0o :
     O00O0oOO00O00 ( name , url , 2 , iiII1i1 , i1Oo00 )
   elif len ( i11iIIIIIi1 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
    iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
    try :
     i1Oo00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( i11Iiii ) [ 0 ]
    except : i1Oo00 = O0O0OO0O0O0
    O00O0oOO00O00 ( name , Iiooo0O , 3 , iiII1i1 , i1Oo00 )
    if 41 - 41: I111i1i1111i - I11i - I11i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 68 - 68: oo % oo0O000OoO
def ooO00OO0 ( name , url , iconimage ) :
 i11111IIIII = [ ]
 iIiii1i111iI1 = [ ]
 i11 = [ ]
 oOoOooOo0o0 = OOOO ( url )
 oO0oOo0 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( oOoOooOo0o0 ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0oOo0 ) [ 0 ]
 i11iIIIIIi1 = re . compile ( '<link>(.+?)</link>' ) . findall ( oO0oOo0 )
 i1IIIiiII1 = 1
 for I1I1I in i11iIIIIIi1 :
  OoOO000 = I1I1I
  if '(' in I1I1I :
   I1I1I = I1I1I . split ( '(' ) [ 0 ]
   i1Ii11i1i = str ( OoOO000 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   i11111IIIII . append ( I1I1I )
   iIiii1i111iI1 . append ( i1Ii11i1i )
  else :
   i11111IIIII . append ( I1I1I )
   iIiii1i111iI1 . append ( 'Link ' + str ( i1IIIiiII1 ) )
  i1IIIiiII1 = i1IIIiiII1 + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 II1 = xbmcgui . Dialog ( )
 o0oOOoo = II1 . select ( name , iIiii1i111iI1 )
 if o0oOOoo < 0 :
  quit ( )
 else :
  url = i11111IIIII [ o0oOOoo ]
  print url
  if 51 - 51: Oo0o * i11iIiiIii
 url = i11111IIIII [ o0oOOoo ]
 name = iIiii1i111iI1 [ o0oOOoo ]
 O0oo00o0O ( name , url , iiiii )
 if 1 - 1: Ooo0OO0oOO
def OOooooO0Oo ( name , url , iconimage ) :
 if 91 - 91: i1I1Ii1iI1ii . Ii1I / i1 + iiI1i1
 i11111IIIII = [ ]
 iIiii1i111iI1 = [ ]
 i11 = [ ]
 I1i = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 oOoOooOo0o0 = OOOO ( url )
 oO0oOo0 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( oOoOooOo0o0 ) [ 0 ]
 i11iIIIIIi1 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0oOo0 )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0oOo0 ) [ 0 ]
 if 53 - 53: o0oOoO00o * oo00 + IiiIIiiI11 - Ooo0OO0oOO
 I1I11i = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 5 - 5: Ii11111i % oo00 % i1 % Ii1Ii1iiii11
 i1IIIiiII1 = 1
 if 7 - 7: Ooo0OO0oOO + Ii11111i . oo0O000OoO . IiiIIiiI11 - i1I1Ii1iI1ii
 for I1I1I in i11iIIIIIi1 :
  OoOO000 = I1I1I
  if '(' in I1I1I :
   I1I1I = I1I1I . split ( '(' ) [ 0 ]
   i1Ii11i1i = str ( OoOO000 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   i11111IIIII . append ( I1I1I )
   iIiii1i111iI1 . append ( i1Ii11i1i )
   I1i . append ( 'Stream ' + str ( i1IIIiiII1 ) )
  else :
   i11111IIIII . append ( I1I1I )
   iIiii1i111iI1 . append ( 'Link ' + str ( i1IIIiiII1 ) )
   if 26 - 26: Oo0o / I1I1i1 % Ii1I / I1I1i1 + O0Oooo00
  i1IIIiiII1 = i1IIIiiII1 + 1
  if 90 - 90: oo00 * oo0O000OoO + i1I1Ii1iI1ii
 name = '[COLOR red]' + name + '[/COLOR]'
 if 81 - 81: i1 . i1I1Ii1iI1ii % I11i / Ii - i1
 II1 = xbmcgui . Dialog ( )
 o0oOOoo = II1 . select ( name , iIiii1i111iI1 )
 if o0oOOoo < 0 :
  quit ( )
 else :
  OOO00O = iIiii1i111iI1 [ o0oOOoo ]
  OOoOO0oo0ooO = "/"
  if not OOO00O . endswith ( OOoOO0oo0ooO ) :
   O0o0O00Oo0o0 = OOO00O + "/"
  else :
   O0o0O00Oo0o0 = OOO00O
  url = I1I11i + i11111IIIII [ o0oOOoo ] + "%26referer=" + O0o0O00Oo0o0
  if 43 - 43: i11iIiiIii + Oo0o * Ooo0OO0oOO * oo0O000OoO * I11i
 name = iIiii1i111iI1 [ o0oOOoo ]
 O0oo00o0O ( name , url , iiiii )
 if 64 - 64: oo % Ii1I * i1
def o0 ( name , url , iconimage ) :
 if 37 - 37: i1 - oo0O000OoO % Oo0o
 OOOoo0OO , oO0O = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 OOOoo0OO += urllib . unquote_plus ( oO0O )
 url = regex . resolve ( OOOoo0OO )
 if 57 - 57: II / IiiIIiiI11
 O0oo00o0O ( name , url , iconimage )
 if 29 - 29: Ii1I + oo00 * II * oo . Ii * Ii
def I111I1Iiii1i ( ) :
 if 56 - 56: o0oOoO00o % I11i - Ii
 OOoo0O ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 OOoo0O ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 OOoo0O ( "################################################################" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 OOOO00ooo0Ooo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , ooo0OO , 201 , iiiii , O0O0OO0O0O0 )
 OOOO00ooo0Ooo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 OOOO00ooo0Ooo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 100 - 100: I111i1i1111i - I11i % i1 * oo + Ii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 88 - 88: Ii11111i - II * I11i * Ii11111i . Ii11111i
def I111iI ( ) :
 if 56 - 56: Ii
 i1IIIiiII1 = 0
 O0oO = requests . get ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) , headers = IiII )
 oo0oooooO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO . content )
 for i11Iiii in oo0oooooO0 :
  i1IIIiiII1 = i1IIIiiII1 + 1
  i11Iiii = i11Iiii . replace ( '<br />' , '\n' )
  O000oo0O = i11Iiii
  OOOO00ooo0Ooo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( i1IIIiiII1 ) + '[/COLOR]' , O000oo0O , 12 , iiiii , O0O0OO0O0O0 )
  if 73 - 73: o0oOoO00o * i11iIiiIii % i1 . o0oOoO00o
 O0oO = requests . get ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) , headers = IiII )
 oo0oooooO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO . content )
 for i11Iiii in oo0oooooO0 :
  i1IIIiiII1 = i1IIIiiII1 + 1
  i11Iiii = i11Iiii . replace ( '<br />' , '\n' )
  O000oo0O = i11Iiii
  OOOO00ooo0Ooo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( i1IIIiiII1 ) + '[/COLOR]' , O000oo0O , 12 , iiiii , O0O0OO0O0O0 )
  if 66 - 66: i1 + i1 + IiiIIiiI11 / Ii1Ii1iiii11 + oo
 O0oO = requests . get ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) , headers = IiII )
 oo0oooooO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO . content )
 for i11Iiii in oo0oooooO0 :
  i1IIIiiII1 = i1IIIiiII1 + 1
  i11Iiii = i11Iiii . replace ( '<br />' , '\n' )
  O000oo0O = i11Iiii
  OOOO00ooo0Ooo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( i1IIIiiII1 ) + '[/COLOR]' , O000oo0O , 12 , iiiii , O0O0OO0O0O0 )
  if 30 - 30: I11i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 44 - 44: i1 / O0Oooo00 / O0Oooo00
def OOO ( url ) :
 if 32 - 32: iiI1i1 / Ooo0OO0oOO . Oo0o
 O0oO = requests . get ( url , headers = IiII )
 oo0oooooO0 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( O0oO . content )
 if 62 - 62: Ii11111i * Ii
 for i11Iiii in oo0oooooO0 :
  iii11I111 = re . compile ( 'title="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
  iiII1i1 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
  OOOO00ooo0Ooo ( '[COLOR dodgerblue]' + iii11I111 + '[/COLOR]' , url , 12 , iiII1i1 , O0O0OO0O0O0 )
  if 58 - 58: oo00 % i1I1Ii1iI1ii
 try :
  i1OOoO = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( O0oO . content ) [ 0 ]
  OOOO00ooo0Ooo ( '[COLOR yellow]Next Page -->[/COLOR]' , i1OOoO , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 89 - 89: i1I1Ii1iI1ii + II * O0Oooo00 * I111i1i1111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 37 - 37: Ii11111i - I11i - i1I1Ii1iI1ii
def o0o0O0O00oOOo ( url ) :
 if 14 - 14: oo00 + i1
 O0oO = requests . get ( url , headers = IiII )
 oo0oooooO0 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( O0oO . content )
 for i11Iiii in oo0oooooO0 :
  try :
   iii11I111 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( i11Iiii ) [ 0 ]
  except :
   iii11I111 = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( i11Iiii ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
  OOOO00ooo0Ooo ( '[COLOR dodgerblue]' + iii11I111 + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 52 - 52: Ii11111i - IiiIIiiI11
def o0O0o0 ( url ) :
 if 37 - 37: o0oOoO00o * O0Oooo00 % i11iIiiIii % IiiIIiiI11 + I111i1i1111i
 O0oO = requests . get ( url , headers = IiII )
 oo0oooooO0 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( O0oO . content )
 OOoOO0o0o0 = 0
 for i11Iiii in oo0oooooO0 :
  try :
   iii11I111 = re . compile ( 'title="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
   iiII1i1 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
  except : OOoOO0o0o0 = 1
  if 11 - 11: Ii
  if OOoOO0o0o0 == 0 :
   OOOO00ooo0Ooo ( '[COLOR dodgerblue]' + iii11I111 + '[/COLOR]' , url , 12 , iiII1i1 , O0O0OO0O0O0 )
  OOoOO0o0o0 = 0
  if 16 - 16: I111i1i1111i + I1I1i1 * I11i % iiI1i1 . Ii
 try :
  i1OOoO = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( O0oO . content ) [ 0 ]
  OOOO00ooo0Ooo ( '[COLOR yellow]Next Page -->[/COLOR]' , i1OOoO , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 67 - 67: Ii11111i / Ii * I111i1i1111i + O0Oooo00
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 65 - 65: Ii11111i - o0oOoO00o / IiiIIiiI11 / Ooo0OO0oOO / iiI1i1
def o00oo0 ( url ) :
 if 38 - 38: IiiIIiiI11 % Ooo0OO0oOO % O0Oooo00 / II + oo00 / iiI1i1
 OoOOo0OOoO = datetime . date . today ( )
 ooO0O00Oo0o = datetime . datetime . strftime ( OoOOo0OOoO , '%A %d %B %Y' )
 if 65 - 65: o0oOoO00o . O0Oooo00 - oo0O000OoO * I1I1i1 / oo0O000OoO / IiiIIiiI11
 OOoo0O ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( ooO0O00Oo0o ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 OOoo0O ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 40 - 40: IiiIIiiI11 * I1I1i1 * i11iIiiIii
 O0oO = requests . get ( url , headers = IiII )
 oo0oooooO0 = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( O0oO . content )
 OOoOO0o0o0 = 0
 i1IIIiiII1 = 0
 for i11Iiii in oo0oooooO0 :
  try :
   oo0OO00OoooOo = re . compile ( 'title="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
   try :
    II1i111Ii1i = re . compile ( '<p>(.+?)</p>' ) . findall ( i11Iiii ) [ 0 ]
   except : II1i111Ii1i = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( i11Iiii ) [ 0 ]
   iiII1i1 = re . compile ( '<img src="(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
  except : OOoOO0o0o0 = 1
  if 15 - 15: Ooo0OO0oOO / iiI1i1
  if OOoOO0o0o0 == 0 :
   if 'vs' in oo0OO00OoooOo :
    iii11I111 = '[COLOR dodgerblue]' + oo0OO00OoooOo + ' - ' + '[/COLOR][COLOR green]' + II1i111Ii1i + '[/COLOR]'
    i1IIIiiII1 = i1IIIiiII1 + 1
    O00O0oOO00O00 ( iii11I111 , url , 206 , iiII1i1 , O0O0OO0O0O0 , '' )
  OOoOO0o0o0 = 0
  if 76 - 76: O0Oooo00 / oo . I11i % Ii . i1I1Ii1iI1ii + I1I1i1
 if i1IIIiiII1 == 0 :
  II1 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 71 - 71: oo0O000OoO . Ooo0OO0oOO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 62 - 62: Ii11111i . O0Oooo00
def oOOOoo00 ( name , url , iconimage ) :
 if 9 - 9: I11i % I11i - i1I1Ii1iI1ii
 O0oO = requests . get ( url , headers = IiII )
 OoO = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( O0oO . content ) [ 0 ]
 if 12 - 12: I11i - i1I1Ii1iI1ii
 if not "http" in OoO :
  OoO = OoO . replace ( "//" , "" )
  url = "http://" + OoO
 else :
  url = OoO
  if 81 - 81: oo00 - oo00 . Ii1Ii1iiii11
 o0OoOo00o0o = url
 if 41 - 41: IiiIIiiI11 % II - Oo0o * oo0O000OoO * Oo0o
 OOOoOO0o = requests . get ( url , headers = IiII )
 OoO = re . compile ( "atob(.+?)," ) . findall ( OOOoOO0o . content ) [ 0 ]
 OoO = OoO . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( OoO )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + o0OoOo00o0o + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 O0oo00o0O ( name , url , iconimage )
 if 1 - 1: Ooo0OO0oOO
def O0oOo00o ( url ) :
 if 81 - 81: I1I1i1 % iiI1i1 . Ii1I
 oOoOooOo0o0 = OOOO ( url )
 oo0oooooO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( oOoOooOo0o0 )
 for i11Iiii in oo0oooooO0 :
  if 4 - 4: i11iIiiIii % II % iiI1i1 / I1I1i1
  if '<display>eWVz</display>' in i11Iiii :
   iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( i11Iiii ) [ 0 ]
   iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
   i1Oo00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( i11Iiii ) [ 0 ]
   iii11I111 = base64 . b64decode ( iii11I111 )
   url = base64 . b64decode ( url )
   iiII1i1 = base64 . b64decode ( iiII1i1 )
   i1Oo00 = base64 . b64decode ( i1Oo00 )
   OOOO00ooo0Ooo ( iii11I111 , url , 220 , iiII1i1 , i1Oo00 , '' )
   if 6 - 6: Ii1Ii1iiii11 / Ii % oo - Ii
def iiii111II ( url ) :
 if 50 - 50: oo * Ii % Ii1I + I111i1i1111i + Ii1Ii1iiii11 + Ii
 O0oO = requests . get ( url , headers = IiII )
 oo0oooooO0 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( O0oO . content )
 if 71 - 71: o0oOoO00o * o0oOoO00o * iiI1i1 . i1 / oo0O000OoO
 for i11Iiii in oo0oooooO0 :
  iii11I111 = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( i11Iiii ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( i11Iiii ) [ 0 ]
  try :
   ooo0O0o00O = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( i11Iiii ) [ 0 ]
  except : ooo0O0o00O = "SD"
  ooo0O0o00O = '[COLOR yellow]' + ooo0O0o00O + '[/COLOR]'
  iiII1i1 = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( i11Iiii ) [ 0 ]
  iii11I111 = iii11I111 . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 48 - 48: IiiIIiiI11 / oo0O000OoO . Ii1I * oo00 * i1 / iiI1i1
  O00O0oOO00O00 ( '[COLOR mediumpurple]' + iii11I111 + '[/COLOR] - ' + ooo0O0o00O , url , 212 , iiII1i1 , O0O0OO0O0O0 , '' )
  if 92 - 92: Oo0o % Oo0o - i1I1Ii1iI1ii / oo00
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( O0oO . content ) [ 0 ]
  I11IIIi = 'http://www.fmovies.se/' + url
  OOOO00ooo0Ooo ( "Next Page -->" , I11IIIi , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 15 - 15: o0oOoO00o * II
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 16 - 16: Ii1Ii1iiii11 + oo00
def O00OO ( url ) :
 if 17 - 17: O0Oooo00 / oo0O000OoO + i1 - i11iIiiIii . Ii1Ii1iiii11
 O0oO = requests . get ( url , headers = IiII )
 oo0oooooO0 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( O0oO . content )
 if 95 - 95: II % iiI1i1 * i11iIiiIii % Oo0o - i1
 if 67 - 67: oo00 + o0oOoO00o . i1I1Ii1iI1ii . Ooo0OO0oOO
def o000ooooO0o ( url ) :
 if 40 - 40: o0oOoO00o + iiI1i1 * oo
 if "iptvembed" in url :
  O0oO = requests . get ( url , headers = IiII )
  oo0oooooO0 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( O0oO . content )
  for i11Iiii in oo0oooooO0 :
   i11Iiii = i11Iiii . replace ( '<br />' , '\n' )
   i11Iiii = i11Iiii . replace ( '</pre>' , '' )
   url = i11Iiii
   if 85 - 85: I111i1i1111i * Oo0o . I11i - i11iIiiIii
 if "sourcetv" in url :
  O0oO = requests . get ( url , headers = IiII )
  oo0oooooO0 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( O0oO . content )
  for i11Iiii in oo0oooooO0 :
   i11Iiii = i11Iiii . replace ( '<br />' , '\n' )
   i11Iiii = i11Iiii . replace ( '</pre>' , '' )
   url = i11Iiii
   if 18 - 18: I111i1i1111i + I1I1i1 - I11i
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 i1Ii1i1I11Iii = [ ]
 for I1i1i1 , OoO0O00O0oo0O , url in o00O :
  I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : url }
  i1Ii1i1I11Iii . append ( I1IiI11 )
 list = [ ]
 for iI1iiiiIii in i1Ii1i1I11Iii :
  I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
  o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
  for iIiIiIiI , i11OOoo in o00O :
   I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11OOoo . strip ( )
  list . append ( I1IiI11 )
  if 50 - 50: II
 ii = 0
 for iI1iiiiIii in list :
  ii = 1
  iii11I111 = Iiii1iI1i ( iI1iiiiIii [ "display_name" ] )
  url = Iiii1iI1i ( iI1iiiiIii [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   O00O0oOO00O00 ( '[COLOR mediumpurple]' + iii11I111 + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   OOOO00ooo0Ooo ( '[COLOR mediumpurple]' + iii11I111 + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 34 - 34: IiiIIiiI11 * Ii . iiI1i1 * IiiIIiiI11 / IiiIIiiI11
 if ii == 0 :
  O00O0oOO00O00 ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 30 - 30: o0oOoO00o + Oo0o / Oo0o % o0oOoO00o . o0oOoO00o
def O0O0Oo00 ( url ) :
 if 80 - 80: i1 + oo / O0Oooo00
 oOoOooOo0o0 = OOOO ( url )
 oo0oooooO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( oOoOooOo0o0 )
 for i11Iiii in oo0oooooO0 :
  if 79 - 79: IiiIIiiI11
  iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
  i11I1I1I = re . compile ( '<search>(.+?)</search>' ) . findall ( i11Iiii ) [ 0 ]
  iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
  i1Oo00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( i11Iiii ) [ 0 ]
  url = iii11I111 + '!' + i11I1I1I + '!' + iiII1i1
  OOOO00ooo0Ooo ( '[COLOR blue]' + iii11I111 + '[/COLOR]' , url , 20 , iiII1i1 , i1Oo00 )
  if 64 - 64: I111i1i1111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 66 - 66: i11iIiiIii - oo * Oo0o
def OooOOOO ( url ) :
 if 45 - 45: o0oOoO00o % Ii - i11iIiiIii
 OoOOo0OOoO = datetime . date . today ( )
 ooO0O00Oo0o = datetime . datetime . strftime ( OoOOo0OOoO , '%A %d %B %Y' )
 if 11 - 11: Ii1I * Ii1I * Ii
 OOoo0O ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( ooO0O00Oo0o ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 OOoo0O ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 46 - 46: oo00 + II
 oOoOooOo0o0 = OOOO ( url )
 Iiooo0O = url
 oo0oooooO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( oOoOooOo0o0 )
 for i11Iiii in oo0oooooO0 :
  if 70 - 70: Ii1Ii1iiii11 / Ii1I
  i11iIIIIIi1 = re . compile ( '<search>(.+?)</search>' ) . findall ( i11Iiii )
  if len ( i11iIIIIIi1 ) == 1 :
   iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( i11Iiii ) [ 0 ]
   iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
   url = iii11I111 + "!" + url + "!" + iiII1i1
   iii11I111 = '[COLOR mediumpurple]' + iii11I111 + '[/COLOR]'
   OOOO00ooo0Ooo ( iii11I111 , url , 20 , iiII1i1 , iiII1i1 )
   if 85 - 85: Ii11111i % iiI1i1 * Ii11111i / o0oOoO00o
   if 96 - 96: Ii11111i + i1
  elif len ( i11iIIIIIi1 ) > 1 :
   iii11I111 = re . compile ( '<title>(.+?)</title>' ) . findall ( i11Iiii ) [ 0 ]
   iiII1i1 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( i11Iiii ) [ 0 ]
   url = Iiooo0O + "!" + iii11I111 + "!" + iiII1i1
   iii11I111 = '[COLOR mediumpurple]' + iii11I111 + '[/COLOR]'
   OOOO00ooo0Ooo ( iii11I111 , url , 22 , iiII1i1 , iiII1i1 )
   if 44 - 44: i1
   if 20 - 20: O0Oooo00 + I111i1i1111i / I11i % Ii1I
   if 88 - 88: oo00 / Ooo0OO0oOO
   if 87 - 87: o0oOoO00o - o0oOoO00o - Ii1Ii1iiii11 + i1
   if 82 - 82: i1 / Ii1I . Ii . oo / i1I1Ii1iI1ii
   if 42 - 42: Oo0o
   if 19 - 19: i1 % o0oOoO00o * Ii1I + Ii
   if 46 - 46: Oo0o
   if 1 - 1: Ii1Ii1iiii11
   if 97 - 97: oo + Ii1Ii1iiii11 + I11i + i11iIiiIii
   if 77 - 77: i1I1Ii1iI1ii / Ii11111i
   if 46 - 46: i1I1Ii1iI1ii % Ii1I . Ii1Ii1iiii11 % Ii1Ii1iiii11 + i11iIiiIii
   if 72 - 72: Ii1I * I111i1i1111i % IiiIIiiI11 / II
def I11i1II ( name , url , iconimage ) :
 if 72 - 72: Ii1I . iiI1i1 / Oo0o . Ooo0OO0oOO
 try :
  url , ooo000o000 , iconimage = url . split ( '!' )
 except :
  II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 100 - 100: I1I1i1 . O0Oooo00 / I111i1i1111i % oo00 % Ooo0OO0oOO - II
 IiIi1I1ii111 = [ ]
 if 46 - 46: I11i + iiI1i1 - iiI1i1 + Ooo0OO0oOO
 oOoOooOo0o0 = OOOO ( url )
 oO0oOo0 = re . compile ( '<title>' + re . escape ( ooo000o000 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( oOoOooOo0o0 ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0oOo0 ) [ 0 ]
 i11iIIIIIi1 = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0oOo0 )
 for I1I1I in i11iIIIIIi1 :
  IiIi1I1ii111 . append ( I1I1I )
  if 83 - 83: o0oOoO00o - Ii + oo
 O00ooooo00 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 O00ooooo00 . update ( 0 )
 if 5 - 5: I111i1i1111i
 iIi1i1iIi1iI = 0
 if 26 - 26: Ii11111i * Ii + oo
 IiIii1i111 = [ ]
 iIo0o00 = [ ]
 IIi = [ ]
 O00ooooo00 . update ( 0 )
 O0oO = requests . get ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) , headers = IiII )
 oo0oooooO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO . content )
 for i11Iiii in oo0oooooO0 :
  if iIi1i1iIi1iI < 100 :
   O00ooooo00 . update ( iIi1i1iIi1iI )
   iIi1i1iIi1iI = iIi1i1iIi1iI + 10
  i11Iiii = i11Iiii . replace ( '<br />' , '\n' )
  url = i11Iiii
  url = url . replace ( '#AAASTREAM:' , '#A:' )
  url = url . replace ( '#EXTINF:' , '#A:' )
  o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
  i1Ii1i1I11Iii = [ ]
  for I1i1i1 , OoO0O00O0oo0O , url in o00O :
   I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : url }
   i1Ii1i1I11Iii . append ( I1IiI11 )
  oOoO00oo0O = [ ]
  for iI1iiiiIii in i1Ii1i1I11Iii :
   I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
   o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
   for iIiIiIiI , i11OOoo in o00O :
    I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11OOoo . strip ( )
   oOoO00oo0O . append ( I1IiI11 )
   if 39 - 39: Ii1I / I11i / i1 - I111i1i1111i - Ii1Ii1iiii11 % oo
  for iI1iiiiIii in oOoO00oo0O :
   name = Iiii1iI1i ( iI1iiiiIii [ "display_name" ] )
   url = Iiii1iI1i ( iI1iiiiIii [ "url" ] )
   url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   IiIii1i111 . append ( name )
   iIo0o00 . append ( url )
   if "hd" in name . lower ( ) :
    IIi . append ( "1" )
   else :
    IIi . append ( "0" )
   I1ii11Ii = list ( zip ( IIi , IiIii1i111 , iIo0o00 ) )
 I111i1II = sorted ( I1ii11Ii , key = lambda oO0O : int ( oO0O [ 0 ] ) , reverse = True )
 O0ooooo0OOOO0 = sorted ( IiIi1I1ii111 )
 if 9 - 9: Ooo0OO0oOO - i1I1Ii1iI1ii / Ii1Ii1iiii11 / i1I1Ii1iI1ii
 Ii1IOo0o0 = 0
 if 40 - 40: oo * oo . Ii1Ii1iiii11 % I11i
 O00ooooo00 . update ( 100 )
 if 9 - 9: i1 + O0Oooo00 / O0Oooo00
 O00O0oOO00O00 ( '                    [COLOR yellow][I]LINKS FOR ' + ooo000o000 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O00O0oOO00O00 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 12 - 12: Ii11111i % i1I1Ii1iI1ii * O0Oooo00 % Ii1I / I111i1i1111i
 if 27 - 27: i11iIiiIii % Ooo0OO0oOO % O0Oooo00 . I11i - Oo0o + oo00
 for i11I1I1I in O0ooooo0OOOO0 :
  if 57 - 57: Ii1I / O0Oooo00 - iiI1i1
  O00O0oOO00O00 ( '                                  [COLOR mediumpurple][I]' + i11I1I1I . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 51 - 51: I1I1i1
  ii11I1 = i11I1I1I . split ( ' ' )
  if 75 - 75: II / Ooo0OO0oOO % I11i
  for Ii111iIi1iIi , name , url in I111i1II :
   if 21 - 21: i1 / o0oOoO00o + I111i1i1111i + Ii11111i
   OoOo = 0
   if 35 - 35: IiiIIiiI11 * oo . O0Oooo00 * i1I1Ii1iI1ii . oo00 / I11i
   for O00 in ii11I1 :
    if 52 - 52: IiiIIiiI11 + I11i . Ii1Ii1iiii11 . o0oOoO00o . II
    if not O00 . lower ( ) in name . lower ( ) :
     OoOo = 1
     if 97 - 97: Ii / Ii1Ii1iiii11
   if OoOo == 0 :
    Ii1IOo0o0 = Ii1IOo0o0 + 1
    if "hd" in name . lower ( ) :
     O00O0oOO00O00 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( Ii1IOo0o0 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O00O0oOO00O00 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( Ii1IOo0o0 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 71 - 71: Ooo0OO0oOO / iiI1i1 . o0oOoO00o % Ii11111i . oo00
  if Ii1IOo0o0 == 0 :
   O00O0oOO00O00 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 41 - 41: iiI1i1 * Ooo0OO0oOO / Ii11111i . oo
  ii11I1 = ""
  if 83 - 83: Ii1Ii1iiii11 . I11i / Oo0o / oo - Ooo0OO0oOO
 O00ooooo00 . close ( )
 if 100 - 100: II
def II1i ( name , url , iconimage ) :
 if 2 - 2: Ii1I * Oo0o % i1 - Ooo0OO0oOO - Ii1Ii1iiii11
 O00ooooo00 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 O00ooooo00 . update ( 0 )
 if 3 - 3: oo0O000OoO
 iIi1i1iIi1iI = 0
 try :
  ooo000o000 , i11I1I1I , iconimage = url . split ( '!' )
 except :
  try :
   i11I1I1I , iconimage = url . split ( '!' )
   ooo000o000 = i11I1I1I
  except :
   II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 45 - 45: oo0O000OoO
 oOIIi1iiii1iI = 0
 if 25 - 25: o0oOoO00o + I11i
 if "all" in name . lower ( ) :
  i11I1I1I = i11I1I1I . replace ( 'all' , '' ) . replace ( 'ALL' , '' ) . replace ( 'All' , '' )
  ooo000o000 = ooo000o000 . replace ( 'all' , '' ) . replace ( 'ALL' , '' ) . replace ( 'All' , '' )
  oOIIi1iiii1iI = 1
  if 28 - 28: Ii11111i
 IiIii1i111 = [ ]
 iIo0o00 = [ ]
 IIi = [ ]
 O00ooooo00 . update ( 0 )
 O0oO = requests . get ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) , headers = IiII )
 oo0oooooO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO . content )
 for i11Iiii in oo0oooooO0 :
  if iIi1i1iIi1iI < 100 :
   O00ooooo00 . update ( iIi1i1iIi1iI )
   iIi1i1iIi1iI = iIi1i1iIi1iI + 10
  i11Iiii = i11Iiii . replace ( '<br />' , '\n' )
  url = i11Iiii
  url = url . replace ( '#AAASTREAM:' , '#A:' )
  url = url . replace ( '#EXTINF:' , '#A:' )
  o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
  i1Ii1i1I11Iii = [ ]
  for I1i1i1 , OoO0O00O0oo0O , url in o00O :
   I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : url }
   i1Ii1i1I11Iii . append ( I1IiI11 )
  oOoO00oo0O = [ ]
  for iI1iiiiIii in i1Ii1i1I11Iii :
   I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
   o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
   for iIiIiIiI , i11OOoo in o00O :
    I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11OOoo . strip ( )
   oOoO00oo0O . append ( I1IiI11 )
   if 89 - 89: Ii1Ii1iiii11 - IiiIIiiI11 % Oo0o % i1I1Ii1iI1ii
  for iI1iiiiIii in oOoO00oo0O :
   name = Iiii1iI1i ( iI1iiiiIii [ "display_name" ] )
   url = Iiii1iI1i ( iI1iiiiIii [ "url" ] )
   url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   IiIii1i111 . append ( name )
   iIo0o00 . append ( url )
   if "hd" in name . lower ( ) :
    IIi . append ( "1" )
   else :
    IIi . append ( "0" )
   I1ii11Ii = list ( zip ( IIi , IiIii1i111 , iIo0o00 ) )
 I111i1II = sorted ( I1ii11Ii , key = lambda oO0O : int ( oO0O [ 0 ] ) , reverse = True )
 if 49 - 49: Oo0o - Ii / I1I1i1 / I11i % i1I1Ii1iI1ii * I111i1i1111i
 Ii1IOo0o0 = 0
 if 100 - 100: oo . Ii1Ii1iiii11 / I11i * iiI1i1 * I111i1i1111i * Oo0o
 O00ooooo00 . update ( 100 )
 if 84 - 84: o0oOoO00o / oo % i11iIiiIii * oo0O000OoO % o0oOoO00o - Ii11111i
 O00O0oOO00O00 ( '                                [COLOR yellow][I]LINKS FOR ' + ooo000o000 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O00O0oOO00O00 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 ii11I1 = i11I1I1I . split ( ' ' )
 for Ii111iIi1iIi , name , url in I111i1II :
  if oOIIi1iiii1iI == 1 :
   OoOoooO = name
   if 1 - 1: Ii1I / oo0O000OoO % Ii * o0oOoO00o . I111i1i1111i * Ii1Ii1iiii11
  OoOo = 0
  if 87 - 87: oo0O000OoO + Ii1I + Ii1I / oo0O000OoO . IiiIIiiI11 % i1
  for O00 in ii11I1 :
   if 18 - 18: oo0O000OoO % iiI1i1 % Ii11111i - oo / O0Oooo00 . oo0O000OoO
   if not O00 . lower ( ) in name . lower ( ) :
    OoOo = 1
    if 95 - 95: IiiIIiiI11 * i1 . oo0O000OoO
  if OoOo == 0 :
   Ii1IOo0o0 = Ii1IOo0o0 + 1
   if oOIIi1iiii1iI == 1 :
    if "hd" in name . lower ( ) :
     O00O0oOO00O00 ( '                                          [COLOR blue] ' + str ( OoOoooO ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O00O0oOO00O00 ( '                                          [COLOR blue] ' + str ( OoOoooO ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     O00O0oOO00O00 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( Ii1IOo0o0 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O00O0oOO00O00 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( Ii1IOo0o0 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 97 - 97: oo0O000OoO - Ii1I
 if Ii1IOo0o0 == 0 :
  O00O0oOO00O00 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 75 - 75: Ii11111i * I1I1i1
 O00ooooo00 . close ( )
 if 9 - 9: I1I1i1 - Ooo0OO0oOO + I11i / Ii1I / i11iIiiIii
def I1IIIiI1I1ii1 ( term ) :
 if 30 - 30: I11i * Ii11111i
 i11111IIIII = [ ]
 iIiii1i111iI1 = [ ]
 if 38 - 38: I1I1i1 - o0oOoO00o . oo00 - oo0O000OoO . Ii11111i
 O0oO = requests . get ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) , headers = IiII )
 oo0oooooO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO . content )
 for i11Iiii in oo0oooooO0 :
  i11Iiii = i11Iiii . replace ( '<br />' , '\n' )
  O000oo0O = i11Iiii
  if 89 - 89: Ii1I
  O000oo0O = O000oo0O . replace ( '#AAASTREAM:' , '#A:' )
  O000oo0O = O000oo0O . replace ( '#EXTINF:' , '#A:' )
  o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O000oo0O )
  i1Ii1i1I11Iii = [ ]
  for I1i1i1 , OoO0O00O0oo0O , O000oo0O in o00O :
   I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : O000oo0O }
   i1Ii1i1I11Iii . append ( I1IiI11 )
  list = [ ]
  for iI1iiiiIii in i1Ii1i1I11Iii :
   I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
   o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
   for iIiIiIiI , i11OOoo in o00O :
    I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11OOoo . strip ( )
   list . append ( I1IiI11 )
   if 21 - 21: O0Oooo00 % O0Oooo00
  for iI1iiiiIii in list :
   iii11I111 = Iiii1iI1i ( iI1iiiiIii [ "display_name" ] )
   O000oo0O = Iiii1iI1i ( iI1iiiiIii [ "url" ] )
   O000oo0O = O000oo0O . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in iii11I111 . lower ( ) :
    i11111IIIII . append ( O000oo0O )
    iIiii1i111iI1 . append ( iii11I111 )
    if 27 - 27: i11iIiiIii / o0oOoO00o
 II1 = xbmcgui . Dialog ( )
 o0oOOoo = II1 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , iIiii1i111iI1 )
 if o0oOOoo < 0 :
  quit ( )
  if 84 - 84: Oo0o
 O000oo0O = i11111IIIII [ o0oOOoo ]
 iii11I111 = iIiii1i111iI1 [ o0oOOoo ]
 O0oo00o0O ( iii11I111 , O000oo0O , iiiii )
 if 43 - 43: i1 - Ii11111i
def ii1iI ( name , url , iconimage ) :
 if 49 - 49: i1I1Ii1iI1ii . I1I1i1 / II + Ooo0OO0oOO
 list = ii11i ( url )
 for iI1iiiiIii in list :
  name = Iiii1iI1i ( iI1iiiiIii [ "display_name" ] )
  url = Iiii1iI1i ( iI1iiiiIii [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  O00O0oOO00O00 ( name , url , 2 , '' , '' , '' )
  if 35 - 35: o0oOoO00o * Ii1Ii1iiii11 - II % i1I1Ii1iI1ii
def ii11i ( url ) :
 if 87 - 87: oo00 * oo0O000OoO . O0Oooo00
 O0Oo0o000oO = requests . get ( url , headers = IiiIII111iI )
 O0Oo0o000oO = O0Oo0o000oO . content
 O0Oo0o000oO = O0Oo0o000oO . replace ( '#AAASTREAM:' , '#A:' )
 O0Oo0o000oO = O0Oo0o000oO . replace ( '#EXTINF:' , '#A:' )
 o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O0Oo0o000oO )
 i1Ii1i1I11Iii = [ ]
 for I1i1i1 , OoO0O00O0oo0O , url in o00O :
  I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : url }
  i1Ii1i1I11Iii . append ( I1IiI11 )
 list = [ ]
 for iI1iiiiIii in i1Ii1i1I11Iii :
  I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
  o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
  for iIiIiIiI , i11OOoo in o00O :
   I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11OOoo . strip ( )
  list . append ( I1IiI11 )
  if 99 - 99: i1 * Ooo0OO0oOO * oo0O000OoO
 return list
 if 92 - 92: Oo0o
def iI11I ( ) :
 if 53 - 53: Ii1I + I111i1i1111i - oo0O000OoO
 ii11I1 = ''
 OoOiIIiii = xbmc . Keyboard ( ii11I1 , 'Enter Search Term' )
 OoOiIIiii . doModal ( )
 if OoOiIIiii . isConfirmed ( ) :
  ii11I1 = OoOiIIiii . getText ( )
  if len ( ii11I1 ) > 1 :
   O000oo0O = ii11I1 + "!" + iiiii
   II1i ( "all " + ii11I1 , O000oo0O , iiiii )
  else : quit ( )
  if 61 - 61: I1I1i1 . iiI1i1 / oo0O000OoO % i11iIiiIii * Ii1Ii1iiii11
def i1i1i1I ( name , url , iconimage ) :
 if 83 - 83: i1 + Ii11111i
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 22 - 22: I111i1i1111i % Ii1Ii1iiii11 * Ii11111i - i1I1Ii1iI1ii / Ii1I
  if 86 - 86: Ii11111i . Ii1Ii1iiii11 % oo00 / O0Oooo00 * Ii1Ii1iiii11 / i1I1Ii1iI1ii
  if 64 - 64: i11iIiiIii
  if 38 - 38: I1I1i1 / Ii - I1I1i1 . O0Oooo00
  if 69 - 69: Ii11111i + o0oOoO00o
def O0oOo00o0 ( name ) :
 if 65 - 65: Ooo0OO0oOO . Ii % i1 * II
 ii = 0
 if 38 - 38: oo00 / Ii1Ii1iiii11 % Oo0o
 try :
  OOOO ( "http://www.google.com" )
 except :
  II1 . ok ( Oo0Ooo , '[COLOR red]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/COLOR]' )
  sys . exit ( 0 )
  if 11 - 11: Ii1Ii1iiii11 - i1 + Ooo0OO0oOO - Ii1I
 try :
  O00ooooo00 . create ( Oo0Ooo , "Checking for repository updates" , '' , 'Please Wait...' )
  O00ooooo00 . update ( 0 )
  Ii1IOo0o0 = open ( IIi1IiiiI1Ii ) . read ( )
  III1ii1iII = Ii1IOo0o0 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  oo0oooooO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( III1ii1iII ) )
  for i11Iiii in oo0oooooO0 :
   O00ooooo00 . update ( 25 )
   iI = float ( i11Iiii ) + 0.01
   O000oo0O = oO00oOo + str ( iI ) + '.zip'
   O0oO = requests . get ( O000oo0O , headers = IiII )
   if "Not Found" not in O0oO . content :
    ii = 1
    O00ooooo00 . update ( 75 )
    Ooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( Ooo0 ) :
     os . makedirs ( Ooo0 )
    I1i11ii11 = os . path . join ( Ooo0 , 'repoupdate.zip' )
    try : os . remove ( I1i11ii11 )
    except : pass
    O00ooooo00 . update ( 100 )
    O00ooooo00 . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( O000oo0O , I1i11ii11 , O00ooooo00 )
    OO00O0oOO = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    O00ooooo00 . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( I1i11ii11 , OO00O0oOO , O00ooooo00 )
    try : os . remove ( I1i11ii11 )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    II1 . ok ( Oo0Ooo , "ECHO repository was updated to " + str ( iI ) + ', you may need to restart the addon for changes to take effect' )
    if 4 - 4: Ii11111i - iiI1i1 % I111i1i1111i - oo * i1I1Ii1iI1ii
  O00ooooo00 . update ( 75 , "Checking for addon updates" )
  Ii1IOo0o0 = open ( I1IiiI ) . read ( )
  III1ii1iII = Ii1IOo0o0 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  oo0oooooO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( III1ii1iII ) )
  for i11Iiii in oo0oooooO0 :
   iI = float ( i11Iiii ) + 0.01
   O000oo0O = I11i11Ii + str ( iI ) + '.zip'
   O0oO = requests . get ( O000oo0O , headers = IiII )
   if "Not Found" not in O0oO . content :
    ii = 1
    O00ooooo00 . update ( 75 )
    Ooo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( Ooo0 ) :
     os . makedirs ( Ooo0 )
    I1i11ii11 = os . path . join ( Ooo0 , 'wizupdate.zip' )
    try : os . remove ( I1i11ii11 )
    except : pass
    O00ooooo00 . update ( 100 )
    O00ooooo00 . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( O000oo0O , I1i11ii11 , O00ooooo00 )
    OO00O0oOO = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    O00ooooo00 . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( I1i11ii11 , OO00O0oOO , O00ooooo00 )
    try : os . remove ( I1i11ii11 )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    O00ooooo00 . update ( 100 )
    O00ooooo00 . close
    II1 . ok ( Oo0Ooo , "Sportie was updated to " + str ( iI ) + ', you may need to restart the addon for changes to take effect' )
 except :
  II1 . ok ( Oo0Ooo , 'Sorry! We encountered an error whilst checking for updates. You can make Kodi force check the repository for updates as an alternative if you wish.' )
  quit ( )
  if 85 - 85: Ii11111i * Ii1I . Ii1Ii1iiii11 / Ii11111i % Ii % I11i
 if O00ooooo00 . iscanceled ( ) :
  O00ooooo00 . close ( )
 else :
  if ii == 0 :
   if not name == "no dialog" :
    II1 . ok ( Oo0Ooo , "There are no updates at this time." )
    quit ( )
    if 36 - 36: I111i1i1111i / Ooo0OO0oOO / I1I1i1 / I1I1i1 + o0oOoO00o
def O0oo00o0O ( name , url , iconimage ) :
 if 95 - 95: I1I1i1
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 51 - 51: Ooo0OO0oOO + I1I1i1 . iiI1i1 . o0oOoO00o + oo00 * Ii
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 72 - 72: i1 + i1 / Ooo0OO0oOO . Ii11111i % I111i1i1111i
 if 49 - 49: i1 . II - Oo0o * Ii11111i . Oo0o
 if 2 - 2: Ii11111i % oo
 if 63 - 63: Ii % Ii1I
 if 39 - 39: Ii1Ii1iiii11 / Ooo0OO0oOO / o0oOoO00o % Ii
 if 89 - 89: oo0O000OoO + Ii11111i + oo0O000OoO * iiI1i1 + Ii1I % O0Oooo00
 oOo0oO = url
 IIi1IIIIi = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 IIi1IIIIi . setPath ( oOo0oO )
 xbmc . Player ( ) . play ( oOo0oO , IIi1IIIIi , False )
 if 70 - 70: oo / Ooo0OO0oOO - Ii1I - Ii1Ii1iiii11
def OOOO ( url ) :
 if 11 - 11: Ii1I . Ii11111i . Ooo0OO0oOO / iiI1i1 - O0Oooo00
 ii1ii11 = urllib2 . Request ( url )
 ii1ii11 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 O0Oo0o000oO = urllib2 . urlopen ( ii1ii11 )
 oOoOooOo0o0 = O0Oo0o000oO . read ( )
 O0Oo0o000oO . close ( )
 oOoOooOo0o0 = oOoOooOo0o0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return oOoOooOo0o0
 if 84 - 84: I11i . O0Oooo00 - Ooo0OO0oOO . IiiIIiiI11 / Ooo0OO0oOO
def Iiii1iI1i ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 47 - 47: Ii11111i
 if 4 - 4: Ii % O0Oooo00
 if 10 - 10: I1I1i1 . Ii11111i - II + I1I1i1 - I11i
 if 82 - 82: IiiIIiiI11 + Ooo0OO0oOO
 if 39 - 39: i1 % Ii1I % I11i % Ii11111i * o0oOoO00o + Ii1Ii1iiii11
def oOo000 ( ) :
 if 14 - 14: II . Ooo0OO0oOO . O0Oooo00 / I111i1i1111i % o0oOoO00o - IiiIIiiI11
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 67 - 67: O0Oooo00 - oo . iiI1i1
 if os . path . exists ( OOOo0 ) == True :
  for I1I1iI , I1iIi1iiIIiI , oOoOOoOOooOO in os . walk ( OOOo0 ) :
   I11I = 0
   I11I += len ( oOoOOoOOooOO )
   if I11I > 0 :
    for iIIII1i in oOoOOoOOooOO :
     try :
      if ( iIIII1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( I1I1iI , iIIII1i ) )
     except :
      pass
    for o00oO0 in I1iIi1iiIIiI :
     try :
      shutil . rmtree ( os . path . join ( I1I1iI , o00oO0 ) )
     except :
      pass
      if 5 - 5: Ii1I
   else :
    pass
    if 72 - 72: i1 . oo0O000OoO / oo00 + O0Oooo00 % Ii1I
 if os . path . exists ( Oooo000o ) == True :
  for I1I1iI , I1iIi1iiIIiI , oOoOOoOOooOO in os . walk ( Oooo000o ) :
   I11I = 0
   I11I += len ( oOoOOoOOooOO )
   if I11I > 0 :
    for iIIII1i in oOoOOoOOooOO :
     try :
      if ( iIIII1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( I1I1iI , iIIII1i ) )
     except :
      pass
    for o00oO0 in I1iIi1iiIIiI :
     try :
      shutil . rmtree ( os . path . join ( I1I1iI , o00oO0 ) )
     except :
      pass
      if 42 - 42: o0oOoO00o * oo00 % IiiIIiiI11 - oo00 . i11iIiiIii - oo0O000OoO
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  o0oO0oOO = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 89 - 89: IiiIIiiI11 + I111i1i1111i * IiiIIiiI11 / IiiIIiiI11
  for I1I1iI , I1iIi1iiIIiI , oOoOOoOOooOO in os . walk ( o0oO0oOO ) :
   I11I = 0
   I11I += len ( oOoOOoOOooOO )
   if 46 - 46: II
   if I11I > 0 :
    for iIIII1i in oOoOOoOOooOO :
     os . unlink ( os . path . join ( I1I1iI , iIIII1i ) )
    for o00oO0 in I1iIi1iiIIiI :
     shutil . rmtree ( os . path . join ( I1I1iI , o00oO0 ) )
     if 71 - 71: O0Oooo00 / O0Oooo00 * i1 * i1 / Ooo0OO0oOO
   else :
    pass
  II1I1iiIII1I1 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 85 - 85: Ii1Ii1iiii11 * i1I1Ii1iI1ii
  for I1I1iI , I1iIi1iiIIiI , oOoOOoOOooOO in os . walk ( II1I1iiIII1I1 ) :
   I11I = 0
   I11I += len ( oOoOOoOOooOO )
   if 3 - 3: oo
   if I11I > 0 :
    for iIIII1i in oOoOOoOOooOO :
     os . unlink ( os . path . join ( I1I1iI , iIIII1i ) )
    for o00oO0 in I1iIi1iiIIiI :
     shutil . rmtree ( os . path . join ( I1I1iI , o00oO0 ) )
     if 20 - 20: Ooo0OO0oOO . Ii1Ii1iiii11 / Ooo0OO0oOO % i11iIiiIii % Ii1Ii1iiii11
   else :
    pass
    if 11 - 11: I1I1i1 % o0oOoO00o % I111i1i1111i / Ooo0OO0oOO % oo0O000OoO - Oo0o
 iIii1 = o00ooooO0oO ( )
 if 96 - 96: o0oOoO00o / Ooo0OO0oOO . I111i1i1111i - Ii1Ii1iiii11 * O0Oooo00 * i1
 for O00oo0ooO in iIii1 :
  iiIii1ii = xbmc . translatePath ( O00oo0ooO . path )
  if os . path . exists ( iiIii1ii ) == True :
   for I1I1iI , I1iIi1iiIIiI , oOoOOoOOooOO in os . walk ( iiIii1ii ) :
    I11I = 0
    I11I += len ( oOoOOoOOooOO )
    if I11I > 0 :
     for iIIII1i in oOoOOoOOooOO :
      os . unlink ( os . path . join ( I1I1iI , iIIII1i ) )
     for o00oO0 in I1iIi1iiIIiI :
      shutil . rmtree ( os . path . join ( I1I1iI , o00oO0 ) )
      if 33 - 33: oo0O000OoO
    else :
     pass
     if 62 - 62: o0oOoO00o + I111i1i1111i + iiI1i1 / Ii11111i
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 II1 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 7 - 7: i1I1Ii1iI1ii + iiI1i1 . Ii / Oo0o
def I111i1I1 ( ) :
 O0o00OOo00O0O = [ ]
 II1iOo = sys . argv [ 2 ]
 if len ( II1iOo ) >= 2 :
  I1i1i1 = sys . argv [ 2 ]
  OOoO000O00oO = I1i1i1 . replace ( '?' , '' )
  if ( I1i1i1 [ len ( I1i1i1 ) - 1 ] == '/' ) :
   I1i1i1 = I1i1i1 [ 0 : len ( I1i1i1 ) - 2 ]
  i1OoOO = OOoO000O00oO . split ( '&' )
  O0o00OOo00O0O = { }
  for i1IIIiiII1 in range ( len ( i1OoOO ) ) :
   iIII1I1i1i = { }
   iIII1I1i1i = i1OoOO [ i1IIIiiII1 ] . split ( '=' )
   if ( len ( iIII1I1i1i ) ) == 2 :
    O0o00OOo00O0O [ iIII1I1i1i [ 0 ] ] = iIII1I1i1i [ 1 ]
 return O0o00OOo00O0O
 if 79 - 79: I111i1i1111i . II
def OOOO00ooo0Ooo ( name , url , mode , iconimage , fanart , description = '' ) :
 if 40 - 40: i1I1Ii1iI1ii + Oo0o . i1I1Ii1iI1ii % IiiIIiiI11
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I11I1IIiiII1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 IIIIIii1ii11 = True
 IIi1IIIIi = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 IIi1IIIIi . setProperty ( "fanart_Image" , fanart )
 IIi1IIIIi . setProperty ( "icon_Image" , iconimage )
 IIIIIii1ii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11I1IIiiII1 , listitem = IIi1IIIIi , isFolder = True )
 return IIIIIii1ii11
 if 86 - 86: oo00 * Ooo0OO0oOO - I11i . oo00 % Ii1I / oo
def OOoo0O ( name , url , mode , iconimage , fanart , description ) :
 if 11 - 11: Ii * i1 + o0oOoO00o / o0oOoO00o
 I11I1IIiiII1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 IIIIIii1ii11 = True
 IIi1IIIIi = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 IIi1IIIIi . setProperty ( "fanart_Image" , fanart )
 IIi1IIIIi . setProperty ( "icon_Image" , iconimage )
 IIIIIii1ii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11I1IIiiII1 , listitem = IIi1IIIIi , isFolder = False )
 return IIIIIii1ii11
 if 37 - 37: i11iIiiIii + iiI1i1
def O00O0oOO00O00 ( name , url , mode , iconimage , fanart , description = '' ) :
 if 23 - 23: Ii1Ii1iiii11 + O0Oooo00 . oo00 * Ii + o0oOoO00o
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I11I1IIiiII1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 IIIIIii1ii11 = True
 IIi1IIIIi = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 IIi1IIIIi . setProperty ( "fanart_Image" , fanart )
 IIi1IIIIi . setProperty ( "icon_Image" , iconimage )
 if 18 - 18: I1I1i1 * i1I1Ii1iI1ii . I1I1i1 / I11i
 if 8 - 8: i1I1Ii1iI1ii
 if 4 - 4: o0oOoO00o + o0oOoO00o * IiiIIiiI11 - oo00
 if 78 - 78: I111i1i1111i / Ooo0OO0oOO % oo00
 if 52 - 52: oo - Ii1Ii1iiii11 * i1
 if 17 - 17: Ii11111i + oo * O0Oooo00 * oo00
 if 36 - 36: I11i + Oo0o
 IIIIIii1ii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11I1IIiiII1 , listitem = IIi1IIIIi , isFolder = False )
 return IIIIIii1ii11
 if 5 - 5: Oo0o * oo00
I1i1i1 = I111i1I1 ( ) ; O000oo0O = None ; iii11I111 = None ; ii1I11iIiIII1 = None ; oOO0OOOOoooO = None ; iiII1i1 = None ; i1Oo00 = None
try : oOO0OOOOoooO = urllib . unquote_plus ( I1i1i1 [ "site" ] )
except : pass
try : O000oo0O = urllib . unquote_plus ( I1i1i1 [ "url" ] )
except : pass
try : iii11I111 = urllib . unquote_plus ( I1i1i1 [ "name" ] )
except : pass
try : ii1I11iIiIII1 = int ( I1i1i1 [ "mode" ] )
except : pass
try : iiII1i1 = urllib . unquote_plus ( I1i1i1 [ "iconimage" ] )
except : pass
try : i1Oo00 = urllib . unquote_plus ( I1i1i1 [ "fanart" ] )
except : pass
if 22 - 22: O0Oooo00 + Ii1I
if ii1I11iIiIII1 == None or O000oo0O == None or len ( O000oo0O ) < 1 : oOo ( )
elif ii1I11iIiIII1 == 1 : I1 ( iii11I111 , O000oo0O )
elif ii1I11iIiIII1 == 2 : O0oo00o0O ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 3 : ooO00OO0 ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 4 : PLAYSD ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 8 : OOooooO0Oo ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 9 : O0oOo00o0 ( iii11I111 )
elif ii1I11iIiIII1 == 10 : ii1iI ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 11 : I111I1Iiii1i ( )
elif ii1I11iIiIII1 == 12 : o000ooooO0o ( O000oo0O )
elif ii1I11iIiIII1 == 19 : O0O0Oo00 ( O000oo0O )
elif ii1I11iIiIII1 == 20 : II1i ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 21 : OooOOOO ( O000oo0O )
elif ii1I11iIiIII1 == 22 : I11i1II ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 30 : o0 ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 100 : iI11I ( )
elif ii1I11iIiIII1 == 500 : oOo000 ( )
elif ii1I11iIiIII1 == 201 : I111iI ( )
elif ii1I11iIiIII1 == 202 : OOO ( O000oo0O )
elif ii1I11iIiIII1 == 203 : o0o0O0O00oOOo ( O000oo0O )
elif ii1I11iIiIII1 == 204 : o0O0o0 ( O000oo0O )
elif ii1I11iIiIII1 == 205 : o00oo0 ( O000oo0O )
elif ii1I11iIiIII1 == 206 : oOOOoo00 ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 210 : O0oOo00o ( O000oo0O )
elif ii1I11iIiIII1 == 220 : iiii111II ( O000oo0O )
elif ii1I11iIiIII1 == 221 : O00OO ( iii11I111 , O000oo0O , iiII1i1 )
elif ii1I11iIiIII1 == 800 : i1i1i1I ( iii11I111 , O000oo0O , iiII1i1 )
if 24 - 24: oo00 % iiI1i1 + Ii1Ii1iiii11 . i11iIiiIii . o0oOoO00o
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )