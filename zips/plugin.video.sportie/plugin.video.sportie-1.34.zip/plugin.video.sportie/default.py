import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , hashlib
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
from resources . lib . modules import cache_dir
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluX21lbnUueG1s' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = xbmc . translatePath ( 'special://home/addons/program.plexus' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
Oooo000o = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oo0O = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
OOo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
Ii1IIii11 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 55 - 55: i1111 - i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
oO000OoOoo00o = "true"
iiiI11 = "false"
OOooO = "false"
try :
 oO000OoOoo00o = plugintools . get_setting ( "scrape1" )
 iiiI11 = plugintools . get_setting ( "scrape2" )
 OOooO = plugintools . get_setting ( "scrape3" )
except :
 oO000OoOoo00o = "true"
 iiiI11 = "false"
 OOooO = "false"
 if 58 - 58: i11iiII + OooooO0oOO + oOo0 / oo0Ooo0
I1I11I1I1I = IiiIII111iI + '|SPLIT|' + o0O
checker . check ( I1I11I1I1I )
if 90 - 90: i1IIiiiii + i1iIIIiI1I - OoO000 % OooOoO0Oo + iiIIiIiIi
cache_dir . check ( )
if 38 - 38: i1IIiiiii / I11i1i11i1I
if not os . path . exists ( IiII ) :
 os . makedirs ( IiII )
 if 76 - 76: oooO0oo0oOOOO / oo0ooO0oOOOOo . i1IIi11111i * i1IIiiiii - oOo0
if not os . path . isfile ( i1i1II ) :
 Oooo = open ( i1i1II , 'w' )
 if 67 - 67: oOo0 / i111I % oo0Ooo0 - ooO0oo0oO0
if not os . path . isfile ( iI1Ii11111iIi ) :
 Oooo = open ( iI1Ii11111iIi , 'w' )
 if 82 - 82: i11iIiiIii . oOo0 / I11i1i11i1I * oooO0oo0oOOOO % OooooO0oOO % ooO0oo0oO0
if not os . path . isfile ( O0oo0OO0 ) :
 Oooo = open ( O0oo0OO0 , 'w' )
 if 78 - 78: ooO0oo0oO0 - i1IIiiiii * oo + oo0ooO0oOOOOo + i1iIIIiI1I + i1iIIIiI1I
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 11 - 11: i1iIIIiI1I - oo % iiIIiIiIi % i1iIIIiI1I / OOO0O - oo
class o0o0oOOOo0oo ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 80 - 80: oo0Ooo0 * i11iIiiIii / OooOoO0Oo
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 9 - 9: i1IIiiiii + OooooO0oOO % i1IIiiiii + II1Ii1iI1i . oOo0
III1i1i = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 26 - 26: i111I
class IiiI11Iiiii :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 18 - 18: oo0ooO0oOOOOo
  if 28 - 28: oOo0 - OoO000 . OoO000 + OOO0O - i111I + oooO0oo0oOOOO
  if 95 - 95: oo % OooooO0oOO . oooO0oo0oOOOO
  if 15 - 15: iiIIiIiIi / i1IIiiiii . i1IIiiiii - II1Ii1iI1i
def o00oOO0 ( ) :
 oOoo = 5
 iIii11I = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 OOO0OOO00oo = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 31 - 31: i1111 - oOo0 . OooOoO0Oo % OOO0O - oooO0oo0oOOOO
 iii11 = [ ]
 if 58 - 58: oOo0 * i11iIiiIii / OOO0O % OooOoO0Oo - i11iiII / OooooO0oOO
 for ii11i1 in range ( oOoo ) :
  iii11 . append ( IiiI11Iiiii ( iIii11I [ ii11i1 ] , OOO0OOO00oo [ ii11i1 ] ) )
  if 29 - 29: i11iiII % i1IIi11111i + iiIIiIiIi / oo0ooO0oOOOOo + oOo0 * oo0ooO0oOOOOo
 return iii11
 if 42 - 42: i1IIiiiii + OooooO0oOO
def o0O0o0Oo ( ) :
 if 16 - 16: oooO0oo0oOOOO - OooOoO0Oo * ooO0oo0oO0 + i1iIIIiI1I
 Ii11iII1 = Oo0O0O0ooO0O ( OOo )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = i1i1II
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 70 - 70: OoO000 * I11i1i11i1I * oo0Ooo0 / i1IIiiiii
 Ii11iII1 = Oo0O0O0ooO0O ( iiI1iIiI )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = iI1Ii11111iIi
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 88 - 88: oooO0oo0oOOOO
 Ii11iII1 = Oo0O0O0ooO0O ( Ii1IIii11 )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = O0oo0OO0
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 64 - 64: oo0Ooo0 * oooO0oo0oOOOO + OoO000 - oOo0 + i11iIiiIii * i1IIiiiii
 iII = o0 ( II1 )
 ooOooo000oOO = II1
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 80 - 80: OooooO0oOO + oOo0 - oOo0 % i1iIIIiI1I
  if "<mamahd>" in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i = re . compile ( '<mamahd>(.+?)</mamahd>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 300 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 89 - 89: OOO0O
  elif "<bigsports>" in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i = re . compile ( '<bigsports>(.+?)</bigsports>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 301 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 68 - 68: oo * i111I % oooO0oo0oOOOO + oo + iiIIiIiIi
  elif "<cricbox>" in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i = re . compile ( '<cricbox>(.+?)</cricbox>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 302 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 4 - 4: iiIIiIiIi + oooO0oo0oOOOO * oOo0
  elif "<cricfree>" in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i = re . compile ( '<cricfree>(.+?)</cricfree>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 303 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 55 - 55: I11i1i11i1I + ooO0oo0oO0 / OOO0O * OooooO0oOO - i11iIiiIii - i1IIiiiii
  elif "<sports4u>" in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i = re . compile ( '<sports4u>(.+?)</sports4u>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 304 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 25 - 25: i11iiII
  elif "<sports4ulive>" in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , "url" , 305 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 7 - 7: II1Ii1iI1i / i1IIi11111i * OooOoO0Oo . OoO000 . ooO0oo0oO0
  elif '<search>display</search>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 13 - 13: oOo0 / i11iIiiIii
  elif '<arenavision>display</arenavision>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   if os . path . exists ( oO00oOo ) : oo0oOo ( OoOO0oo0o , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : Iiii ( '[COLOR darkgray]' + OoOO0oo0o + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 75 - 75: OOO0O % oo0ooO0oOOOOo % oo0ooO0oOOOOo . OooOoO0Oo
   if 5 - 5: oo0ooO0oOOOOo * iiIIiIiIi + OOO0O . oOo0 + OOO0O
  elif '<vip>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 91 - 91: oooO0oo0oOOOO
  elif '<divider>null</divider>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Iiii ( OoOO0oo0o , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 61 - 61: i1111
   if 64 - 64: iiIIiIiIi / OOO0O - oooO0oo0oOOOO - oo0Ooo0
   if 86 - 86: oo0Ooo0 % OOO0O / i1IIi11111i / OOO0O
   if 42 - 42: oo
   if 67 - 67: OooOoO0Oo . i1iIIIiI1I . oooO0oo0oOOOO
   if 10 - 10: i11iiII % i11iiII - ooO0oo0oO0 / oOo0 + i1IIiiiii
  elif '<m3ulists>display</m3ulists>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( OoOO0oo0o , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 87 - 87: OooooO0oOO * i11iiII + oOo0 / ooO0oo0oO0 / i1iIIIiI1I
   if 37 - 37: i1iIIIiI1I - iiIIiIiIi * OooooO0oOO % i11iIiiIii - OooOoO0Oo
   if 83 - 83: oo0Ooo0 / i1IIi11111i
   if 34 - 34: OoO000
   if 57 - 57: OooooO0oOO . oo0Ooo0 . II1Ii1iI1i
   if 42 - 42: oo0Ooo0 + i11iiII % oooO0oo0oOOOO
   if 6 - 6: OooooO0oOO
   if 68 - 68: OOO0O - oo
   if 28 - 28: oo . oOo0 / oOo0 + I11i1i11i1I . i11iiII
   if 1 - 1: ooO0oo0oO0 / i1111
   if 33 - 33: oo0Ooo0
   if 18 - 18: oo0ooO0oOOOOo % i1iIIIiI1I * oooO0oo0oOOOO
   if 87 - 87: i11iIiiIii
   if 93 - 93: i11iiII - oo % i11iIiiIii . i1iIIIiI1I / i1iIIIiI1I - OooOoO0Oo
   if 9 - 9: i11iiII / I11i1i11i1I - i1IIi11111i / i111I / ooO0oo0oO0 - oo0ooO0oOOOOo
   if 91 - 91: i1iIIIiI1I % II1Ii1iI1i % ooO0oo0oO0
   if 20 - 20: oOo0 % i1IIiiiii / i1IIiiiii + i1IIiiiii
   if 45 - 45: OooooO0oOO - OoO000 - i111I - oo . i1111 / oooO0oo0oOOOO
   if 51 - 51: oooO0oo0oOOOO + i1iIIIiI1I
   if 8 - 8: OooooO0oOO * OOO0O - i1IIiiiii - oo * oOo0 % i1IIi11111i
   if 48 - 48: oooO0oo0oOOOO
   if 11 - 11: oo0Ooo0 + i111I - oo / oo0ooO0oOOOOo + I11i1i11i1I . i1111
  elif '<sportsdevil>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o )
   if len ( i1Iii1i1I ) == 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    II11i1I11Ii1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    OOoO00 = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    IiI111111IIII = OOoO00
    i1Ii = "/"
    if not IiI111111IIII . endswith ( i1Ii ) :
     ii111iI1iIi1 = IiI111111IIII + "/"
    else :
     ii111iI1iIi1 = IiI111111IIII
    iII = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( OoOO0oo0o ) + '%26url=' + II11i1I11Ii1i
    II11i1I11Ii1i = iII + '%26referer=' + ii111iI1iIi1
    Iiii ( OoOO0oo0o , II11i1I11Ii1i , 4 , O000O0oOO0 , O0ooo0O0oo0 )
   elif len ( i1Iii1i1I ) > 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Iiii ( OoOO0oo0o , ooOooo000oOO + 'NOTPLAY' , 8 , O000O0oOO0 , O0ooo0O0oo0 )
  elif '<plexus>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : O0ooo0O0oo0 = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : Iiii ( OoOO0oo0o , ooOooo000oOO + 'NOTPLAY' , 7 , O000O0oOO0 , O0ooo0O0oo0 )
   else : Iiii ( '[COLOR darkgray]' + OoOO0oo0o + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 78 - 78: oo . oOo0 + oo / oo0Ooo0 / oo
  elif '<rutubeplaylist>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : O0ooo0O0oo0 = O0O0OO0O0O0
   oo0oOo ( OoOO0oo0o , ooOooo000oOO , 90 , O000O0oOO0 , O0ooo0O0oo0 )
  elif '<folder>' in Oo0OoO00oOO0o :
   oO0O00OoOO0 = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 , O0ooo0O0oo0 in oO0O00OoOO0 :
    oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 1 , O000O0oOO0 , O0ooo0O0oo0 )
  elif '<m3u>' in Oo0OoO00oOO0o :
   oO0O00OoOO0 = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 , O0ooo0O0oo0 in oO0O00OoOO0 :
    oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 10 , O000O0oOO0 , O0ooo0O0oo0 )
  else :
   i1Iii1i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o )
   if len ( i1Iii1i1I ) == 1 :
    oO0O00OoOO0 = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
    OoO = len ( Oo0oOOo )
    for OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 , O0ooo0O0oo0 in oO0O00OoOO0 :
     Iiii ( OoOO0oo0o , II11i1I11Ii1i , 2 , O000O0oOO0 , O0ooo0O0oo0 )
   elif len ( i1Iii1i1I ) > 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Iiii ( OoOO0oo0o , II1 , 3 , O000O0oOO0 , O0ooo0O0oo0 )
    if 88 - 88: i1iIIIiI1I . i1111 * i1111 % OooOoO0Oo
 iiIIiiIi1Ii11 = open ( IIi1IiiiI1Ii ) . read ( )
 Oo0 = iiIIiiIi1Ii11 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo0oOOo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( Oo0 ) )
 for Oo0OoO00oOO0o in Oo0oOOo :
  oOooo0O0Oo = float ( Oo0OoO00oOO0o )
 iiIIiiIi1Ii11 = open ( I11i11Ii ) . read ( )
 Oo0 = iiIIiiIi1Ii11 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo0oOOo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( Oo0 ) )
 for Oo0OoO00oOO0o in Oo0oOOo :
  iI = float ( Oo0OoO00oOO0o )
  if 80 - 80: OooOoO0Oo . i11iIiiIii - oo0ooO0oOOOOo
 Iiii ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 Iiii ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 Iiii ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 Iiii ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( "[COLOR dodgerblue]Sportie Testing Section[/COLOR]" , 'http://echocoder.com/private/addons/sportie/test/testmenu.xml' , 1 , iiiii , O0ooo0O0oo0 , '' )
 Iiii ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( oOooo0O0Oo ) + "[/COLOR]" , 'url' , 999 , iiiii , O0ooo0O0oo0 , '' )
 Iiii ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( iI ) + "[/COLOR]" , 'url' , 999 , iiiii , O0ooo0O0oo0 , '' )
 if 25 - 25: oo
 oOo0oO = OOOO0oo0 ( )
 if 35 - 35: i1IIiiiii - i1IIi11111i % oo0ooO0oOOOOo . i111I % i1IIiiiii
 if oOo0oO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oOo0oO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 47 - 47: i1iIIIiI1I - i1IIiiiii . i1111 + i111I . i11iIiiIii
def OOo0oO00ooO00 ( name , url ) :
 if 90 - 90: OOO0O * OooOoO0Oo + oo0ooO0oOOOOo
 hash = [ ]
 ooOooo000oOO = url
 iII = o0 ( url )
 if 81 - 81: OooooO0oOO . oo0ooO0oOOOOo % oooO0oo0oOOOO / i1IIi11111i - OooooO0oOO
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 43 - 43: i11iIiiIii + I11i1i11i1I * i1111 * OooOoO0Oo * oooO0oo0oOOOO
  if "<mamahd>" in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<mamahd>(.+?)</mamahd>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( name , url , 300 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 64 - 64: oOo0 % ooO0oo0oO0 * OooooO0oOO
  elif "<bigsports>" in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<bigsports>(.+?)</bigsports>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( name , url , 301 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 79 - 79: oooO0oo0oOOOO
  elif "<cricbox>" in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<cricbox>(.+?)</cricbox>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( name , url , 302 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 78 - 78: i11iiII + oOo0 - OooOoO0Oo
  elif "<cricfree>" in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<cricfree>(.+?)</cricfree>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( name , url , 303 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 38 - 38: oo0ooO0oOOOOo - OooooO0oOO + ooO0oo0oO0 / OOO0O % I11i1i11i1I
  elif "<sports4u>" in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<sports4u>(.+?)</sports4u>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( name , url , 304 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 57 - 57: oo / iiIIiIiIi
  elif "<sports4ulive>" in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oOo ( name , "url" , 305 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 29 - 29: ooO0oo0oO0 + OOO0O * oo * oOo0 . i1IIi11111i * i1IIi11111i
  elif '<search>' in Oo0OoO00oOO0o :
   if 7 - 7: OoO000 * OooOoO0Oo % i1IIiiiii - oo0ooO0oOOOOo
   i1Iii1i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
   if len ( i1Iii1i1I ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = name + "!" + url + "!" + O000O0oOO0
    name = '[COLOR white]' + name + '[/COLOR]'
    oo0oOo ( name , url , 20 , O000O0oOO0 , O000O0oOO0 )
    if 13 - 13: i1IIiiiii . i11iIiiIii
   elif len ( i1Iii1i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = ooOooo000oOO + "!" + name + "!" + O000O0oOO0
    name = '[COLOR white]' + name + '[/COLOR]'
    oo0oOo ( name , url , 22 , O000O0oOO0 , O000O0oOO0 )
    if 56 - 56: i11iiII % oooO0oo0oOOOO - i1IIi11111i
  elif '<fightclubsearch>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<fightclubsearch>(.+?)</fightclubsearch>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = 'true|SPLIT|' + url
   oo0oOo ( name , url , 222 , iiiii , O0O0OO0O0O0 )
   if 100 - 100: i1IIiiiii - oooO0oo0oOOOO % OooooO0oOO * oOo0 + i1IIi11111i
  elif '<fightclubterms>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<fightclubterms>(.+?)</fightclubterms>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = 'false|SPLIT|' + url + '|SPLIT|' + ooOooo000oOO + '|SPLIT|' + name
   oo0oOo ( name , url , 222 , iiiii , O0O0OO0O0O0 )
   if 88 - 88: i111I - oo * oooO0oo0oOOOO * i111I . i111I
  elif '<arenavision>display</arenavision>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   if os . path . exists ( oO00oOo ) : oo0oOo ( name , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : Iiii ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 33 - 33: OooOoO0Oo + i1iIIIiI1I * OooooO0oOO / ooO0oo0oO0 - i1IIi11111i
  elif '<divider>null</divider>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Iiii ( name , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 54 - 54: OooOoO0Oo / oOo0 . OooooO0oOO % i1iIIIiI1I
  elif '<regex>' in Oo0OoO00oOO0o :
   OoO0OOOOo0O = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Oo0OoO00oOO0o )
   OoO0OOOOo0O = '' . join ( OoO0OOOOo0O )
   OooOO = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( OoO0OOOOo0O )
   OoO0OOOOo0O = urllib . quote_plus ( OoO0OOOOo0O )
   if 21 - 21: oo0Ooo0 / OoO000 % ooO0oo0oO0 * I11i1i11i1I
   oooooOO = hashlib . md5 ( )
   for IiIIIIii1I in OoO0OOOOo0O : oooooOO . update ( str ( IiIIIIii1I ) )
   oooooOO = str ( oooooOO . hexdigest ( ) )
   if 97 - 97: oooO0oo0oOOOO + OOO0O
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Oo0OoO00oOO0o = re . sub ( '<regex>.+?</regex>' , '' , Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = re . sub ( '<link></link>' , '' , Oo0OoO00oOO0o )
   if 89 - 89: oo0ooO0oOOOOo + oo * oo0Ooo0 * i1IIiiiii
   name = re . sub ( '<meta>.+?</meta>' , '' , Oo0OoO00oOO0o )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 37 - 37: i111I - oooO0oo0oOOOO - oo0ooO0oOOOOo
   try : o0o0O0O00oOOo = re . findall ( '<date>(.+?)</date>' , Oo0OoO00oOO0o ) [ 0 ]
   except : o0o0O0O00oOOo = ''
   if re . search ( r'\d+' , o0o0O0O00oOOo ) : name += ' [COLOR red] Updated %s[/COLOR]' % o0o0O0O00oOOo
   if 14 - 14: OOO0O + OooooO0oOO
   try : oo00oO0O0 = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Oo0OoO00oOO0o ) [ 0 ]
   except : oo00oO0O0 = iiiii
   if 30 - 30: oOo0 + i11iiII * oo0Ooo0 % i11iIiiIii % OOO0O
   try : OO0OoOO0o0o = re . findall ( '<fanart>(.+?)</fanart>' , Oo0OoO00oOO0o ) [ 0 ]
   except : OO0OoOO0o0o = O0O0OO0O0O0
   if 95 - 95: i11iIiiIii
   try : iI1111iiii = re . findall ( '<meta>(.+?)</meta>' , Oo0OoO00oOO0o ) [ 0 ]
   except : iI1111iiii = '0'
   if 67 - 67: i111I / i1IIi11111i * i1IIiiiii + oo0Ooo0
   try : url = re . findall ( '<link>(.+?)</link>' , Oo0OoO00oOO0o ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % iI1111iiii )
   url = '<preset>search</preset>%s' % iI1111iiii if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % iI1111iiii )
   url = '<preset>searchsd</preset>%s' % iI1111iiii if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 65 - 65: i111I - i11iiII / iiIIiIiIi / i1111 / II1Ii1iI1i
   if not OoO0OOOOo0O == '' :
    hash . append ( { 'regex' : oooooOO , 'response' : OoO0OOOOo0O } )
    url += '|regex=%s' % OoO0OOOOo0O
    if 71 - 71: OooOoO0Oo + i1IIiiiii
   Iiii ( name , url , 30 , oo00oO0O0 , OO0OoOO0o0o )
   if 28 - 28: oOo0
  elif '<sportsdevil>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o )
   if len ( i1Iii1i1I ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     OOoO00 = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : OOoO00 = "None"
    O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : O0ooo0O0oo0 = O0O0OO0O0O0
    IiI111111IIII = OOoO00
    i1Ii = "/"
    if not IiI111111IIII . endswith ( i1Ii ) :
     ii111iI1iIi1 = IiI111111IIII + "/"
    else :
     ii111iI1iIi1 = IiI111111IIII
    iII = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = iII + '%26referer=' + ii111iI1iIi1
    Iiii ( name , url , 2 , O000O0oOO0 , O0ooo0O0oo0 )
    if 38 - 38: iiIIiIiIi % i1111 % oo0Ooo0 / oo + OOO0O / II1Ii1iI1i
   elif len ( i1Iii1i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : O0ooo0O0oo0 = O0O0OO0O0O0
    Iiii ( name , ooOooo000oOO + 'NOTPLAY' , 8 , O000O0oOO0 , O0ooo0O0oo0 )
    if 54 - 54: ooO0oo0oO0 % i11iiII - oOo0 / OooooO0oOO - oo . oo0Ooo0
  elif '<plexus>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : O0ooo0O0oo0 = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : Iiii ( name , ooOooo000oOO + 'NOTPLAY' , 7 , O000O0oOO0 , O0ooo0O0oo0 )
   else : Iiii ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 11 - 11: i11iiII . oo * OoO000 * i111I + iiIIiIiIi
  elif '<rutubeplaylist>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : O0ooo0O0oo0 = O0O0OO0O0O0
   oo0oOo ( name , ooOooo000oOO , 90 , O000O0oOO0 , O0ooo0O0oo0 )
   if 33 - 33: oooO0oo0oOOOO * oo0ooO0oOOOOo - OooOoO0Oo % OooOoO0Oo
  elif '<folder>' in Oo0OoO00oOO0o :
   oO0O00OoOO0 = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , O000O0oOO0 , O0ooo0O0oo0 in oO0O00OoOO0 :
    oo0oOo ( name , url , 1 , O000O0oOO0 , O0ooo0O0oo0 )
    if 18 - 18: OooOoO0Oo / I11i1i11i1I * OooOoO0Oo + OooOoO0Oo * i11iIiiIii * i11iiII
  elif '<m3u>' in Oo0OoO00oOO0o :
   oO0O00OoOO0 = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , O000O0oOO0 , O0ooo0O0oo0 in oO0O00OoOO0 :
    oo0oOo ( name , url , 10 , O000O0oOO0 , O0ooo0O0oo0 )
    if 11 - 11: iiIIiIiIi / OOO0O - OoO000 * i111I + i111I . OOO0O
  elif '<rutube>' in Oo0OoO00oOO0o :
   oO0O00OoOO0 = re . compile ( '<title>(.+?)</title>.+?rutube>(.+?)</rutube>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , O000O0oOO0 , O0ooo0O0oo0 in oO0O00OoOO0 :
    ooOooo000oOO = 'https://rutube.ru/play/embed/' + url + '?wmode=opaque&fakeFullscreen=1'
    oo0oOo ( name , ooOooo000oOO , 2 , O000O0oOO0 , O0ooo0O0oo0 )
  else :
   i1Iii1i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o )
   if len ( i1Iii1i1I ) == 1 :
    oO0O00OoOO0 = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
    OoO = len ( Oo0oOOo )
    for name , url , O000O0oOO0 , O0ooo0O0oo0 in oO0O00OoOO0 :
     Iiii ( name , url , 2 , O000O0oOO0 , O0ooo0O0oo0 )
   elif len ( i1Iii1i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : O0ooo0O0oo0 = O0O0OO0O0O0
    Iiii ( name , ooOooo000oOO , 3 , O000O0oOO0 , O0ooo0O0oo0 )
    if 26 - 26: i1IIiiiii % i11iiII
 oOo0oO = OOOO0oo0 ( )
 if 76 - 76: OoO000 * i1iIIIiI1I
 if oOo0oO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oOo0oO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 52 - 52: oOo0
def iiii1 ( name , url , iconimage ) :
 ooO0oooOO0 = [ ]
 o0o = [ ]
 oo0 = [ ]
 iII = o0 ( url )
 oOOOoo00 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oOOOoo00 ) [ 0 ]
 i1Iii1i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( oOOOoo00 )
 IiIIIIii1I = 1
 for iiIiIIIiiI in i1Iii1i1I :
  iiI1IIIi = iiIiIIIiiI
  if '(' in iiIiIIIiiI :
   iiIiIIIiiI = iiIiIIIiiI . split ( '(' ) [ 0 ]
   II11IiIi11 = str ( iiI1IIIi . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   ooO0oooOO0 . append ( iiIiIIIiiI )
   o0o . append ( II11IiIi11 )
  else :
   ooO0oooOO0 . append ( iiIiIIIiiI )
   o0o . append ( 'Link ' + str ( IiIIIIii1I ) )
  IiIIIIii1I = IiIIIIii1I + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 II = O00ooooo00 . select ( name , o0o )
 if II < 0 :
  quit ( )
 else :
  url = ooO0oooOO0 [ II ]
  print url
  if 77 - 77: OooooO0oOO * iiIIiIiIi + OoO000 + I11i1i11i1I * oOo0
 url = ooO0oooOO0 [ II ]
 name = o0o [ II ]
 OOoOO0ooo ( name , url , iiiii )
 if 30 - 30: oo0ooO0oOOOOo - II1Ii1iI1i % i1111 + oo0Ooo0 * ooO0oo0oO0
def o0ooooO0o0O ( name , url , iconimage ) :
 if 24 - 24: oooO0oo0oOOOO * oo0ooO0oOOOOo
 ooO0oooOO0 = [ ]
 o0o = [ ]
 oo0 = [ ]
 IiI1iiiIii = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 iII = o0 ( url )
 oOOOoo00 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 i1Iii1i1I = re . compile ( '<plexus>(.+?)</plexus>' ) . findall ( oOOOoo00 )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oOOOoo00 ) [ 0 ]
 if 7 - 7: OooOoO0Oo * oo - iiIIiIiIi + oOo0 * i1IIi11111i % oo
 iI1i111I1Ii = "plugin://program.plexus/?url="
 i11i1ii1I = "&mode=1&name=acestream+"
 IiIIIIii1I = 0
 if 88 - 88: oo0Ooo0 % i11iiII
 for iiIiIIIiiI in i1Iii1i1I :
  IiIIIIii1I = IiIIIIii1I + 1
  if 48 - 48: iiIIiIiIi / OooOoO0Oo . ooO0oo0oO0 * OOO0O * OooooO0oOO / II1Ii1iI1i
  iiI1IIIi = iiIiIIIiiI
  if '(' in iiIiIIIiiI :
   iiIiIIIiiI = iiIiIIIiiI . split ( '(' ) [ 0 ]
   II11IiIi11 = str ( iiI1IIIi . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   ooO0oooOO0 . append ( iiIiIIIiiI )
   o0o . append ( II11IiIi11 )
   IiI1iiiIii . append ( 'Stream ' + str ( IiIIIIii1I ) )
  else :
   ooO0oooOO0 . append ( iiIiIIIiiI )
   o0o . append ( 'Link ' + str ( IiIIIIii1I ) )
   II11IiIi11 = name
   if 92 - 92: I11i1i11i1I % I11i1i11i1I - oo0ooO0oOOOOo / OOO0O
   if 10 - 10: i1iIIIiI1I + I11i1i11i1I * i11iiII + ooO0oo0oO0 / OooOoO0Oo / i11iiII
 if IiIIIIii1I > 1 :
  O00ooooo00 = xbmcgui . Dialog ( )
  II = O00ooooo00 . select ( name , o0o )
  if II < 0 :
   quit ( )
  else :
   iI1II = ooO0oooOO0 [ II ]
   if not 'acestream://' in iI1II :
    iI1II = 'acestream://' + iI1II
   url = iI1i111I1Ii + iI1II + i11i1ii1I + o0o [ II ]
   name = o0o [ II ]
 else :
  iI1II = iiIiIIIiiI
  if not 'acestream://' in iI1II :
   iI1II = 'acestream://' + iI1II
  url = iI1i111I1Ii + iI1II + i11i1ii1I + II11IiIi11
  name = II11IiIi11
  if 69 - 69: iiIIiIiIi % OooooO0oOO
 OOoOO0ooo ( name , url , iiiii )
 if 50 - 50: i111I % oo0Ooo0
def IIii1111 ( name , url , iconimage ) :
 if 42 - 42: oo0Ooo0 / oo0ooO0oOOOOo . OooooO0oOO + OooooO0oOO % OOO0O + i11iIiiIii
 ooO0oooOO0 = [ ]
 o0o = [ ]
 oo0 = [ ]
 IiI1iiiIii = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 iII = o0 ( url )
 oOOOoo00 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 i1Iii1i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oOOOoo00 )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oOOOoo00 ) [ 0 ]
 if 56 - 56: oo0ooO0oOOOOo
 I1 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 68 - 68: ooO0oo0oO0 * ooO0oo0oO0 . oo0ooO0oOOOOo / i1111 % I11i1i11i1I
 IiIIIIii1I = 1
 if 38 - 38: iiIIiIiIi - oOo0 / i1iIIIiI1I
 for iiIiIIIiiI in i1Iii1i1I :
  iiI1IIIi = iiIiIIIiiI
  if '(' in iiIiIIIiiI :
   iiIiIIIiiI = iiIiIIIiiI . split ( '(' ) [ 0 ]
   II11IiIi11 = str ( iiI1IIIi . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   ooO0oooOO0 . append ( iiIiIIIiiI )
   o0o . append ( II11IiIi11 )
   IiI1iiiIii . append ( 'Stream ' + str ( IiIIIIii1I ) )
  else :
   ooO0oooOO0 . append ( iiIiIIIiiI )
   o0o . append ( 'Link ' + str ( IiIIIIii1I ) )
   if 66 - 66: oooO0oo0oOOOO % i11iiII + i11iIiiIii . OOO0O / i1IIiiiii + i11iiII
  IiIIIIii1I = IiIIIIii1I + 1
  if 86 - 86: oo0ooO0oOOOOo
 name = '[COLOR red]' + name + '[/COLOR]'
 if 5 - 5: OoO000 * OOO0O
 O00ooooo00 = xbmcgui . Dialog ( )
 II = O00ooooo00 . select ( name , o0o )
 if II < 0 :
  quit ( )
 else :
  IiI111111IIII = o0o [ II ]
  i1Ii = "/"
  if not IiI111111IIII . endswith ( i1Ii ) :
   ii111iI1iIi1 = IiI111111IIII + "/"
  else :
   ii111iI1iIi1 = IiI111111IIII
  url = I1 + ooO0oooOO0 [ II ] + "%26referer=" + ii111iI1iIi1
  if 5 - 5: OooOoO0Oo
 name = o0o [ II ]
 OOoOO0ooo ( name , url , iiiii )
 if 90 - 90: OooOoO0Oo . iiIIiIiIi / i1IIiiiii - oo0Ooo0
def ii1 ( name , url , iconimage ) :
 if 39 - 39: i1IIiiiii / iiIIiIiIi . oo0ooO0oOOOOo % oooO0oo0oOOOO * i1iIIIiI1I + i1IIi11111i
 O0oo0O = [ ]
 I1IiI11 = [ ]
 if 9 - 9: oo0Ooo0
 iII = o0 ( url )
 oOOOoo00 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 i1Iii1i1I = re . compile ( '<rutubeplaylist>(.+?)</rutubeplaylist>' ) . findall ( oOOOoo00 )
 if 64 - 64: ooO0oo0oO0 / i1IIi11111i . i1111 + i111I . oo
 for iiIiIIIiiI in i1Iii1i1I :
  iiI1IIIi = iiIiIIIiiI
  if '(' in iiIiIIIiiI :
   iiIiIIIiiI = iiIiIIIiiI . split ( '(' ) [ 0 ]
   II11IiIi11 = str ( iiI1IIIi . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   O0oo0O . append ( II11IiIi11 )
   I1IiI11 . append ( iiIiIIIiiI )
   oO = list ( zip ( O0oo0O , I1IiI11 ) )
   if 10 - 10: I11i1i11i1I / I11i1i11i1I / OooOoO0Oo . OooOoO0Oo
 OOoo = sorted ( oO )
 if 50 - 50: oo
 for ii , url in OOoo :
  Iiii1iI1i = o0 ( url )
  Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   I1ii1ii11i1I = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
   if ii . lower ( ) == "all" :
    I1ii1ii11i1I = I1ii1ii11i1I . replace ( '.' , ' ' )
    Iiii ( I1ii1ii11i1I , url , 2 , iconimage , iconimage , '' )
   elif ii . lower ( ) in I1ii1ii11i1I . lower ( ) :
    I1ii1ii11i1I = I1ii1ii11i1I . replace ( '.' , ' ' )
    Iiii ( I1ii1ii11i1I , url , 2 , iconimage , iconimage , '' )
    if 58 - 58: i1iIIIiI1I + I11i1i11i1I
 try :
  Oo0oOOo = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( Iiii1iI1i )
  II1I1I1Ii = str ( Oo0oOOo )
  OOOOoO00o0O = re . compile ( 'href="(.+?)"' ) . findall ( II1I1I1Ii ) [ 1 ]
  url = OOOOoO00o0O + "|SPLIT|" + ii
  oo0oOo ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 41 - 41: oOo0 * i1IIiiiii - OoO000 + oo0ooO0oOOOOo
def oOOOo00O00O ( name , url , iconimage ) :
 if 2 - 2: oo0ooO0oOOOOo - i11iiII
 url , ii = url . split ( "|SPLIT|" )
 if 58 - 58: i1IIiiiii + oo0ooO0oOOOOo - i1IIi11111i
 Iiii1iI1i = o0 ( url )
 Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( Iiii1iI1i )
 for Oo0OoO00oOO0o in Oo0oOOo :
  I1ii1ii11i1I = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
  if ii . lower ( ) == "all" :
   I1ii1ii11i1I = I1ii1ii11i1I . replace ( '.' , ' ' )
   Iiii ( I1ii1ii11i1I , url , 2 , iconimage , iconimage , '' )
  elif ii . lower ( ) in I1ii1ii11i1I . lower ( ) :
   I1ii1ii11i1I = I1ii1ii11i1I . replace ( '.' , ' ' )
   Iiii ( I1ii1ii11i1I , url , 2 , iconimage , iconimage , '' )
   if 3 - 3: oo
 try :
  Oo0oOOo = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( Iiii1iI1i )
  II1I1I1Ii = str ( Oo0oOOo )
  OOOOoO00o0O = re . compile ( 'href="(.+?)"' ) . findall ( II1I1I1Ii ) [ 1 ]
  url = OOOOoO00o0O + "|SPLIT|" + ii
  oo0oOo ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 97 - 97: OooOoO0Oo
def iiIII1i ( url ) :
 if 31 - 31: i1iIIIiI1I . oOo0 - iiIIiIiIi . i111I / i111I
 try :
  OOoO , url = url . split ( '|SPLIT|' )
 except : OOoO , url , ooOooo000oOO , OoOO0oo0o = url . split ( '|SPLIT|' )
 if 44 - 44: OooooO0oOO
 if OOoO == 'true' :
  II1I1I1Ii = ''
  I1i11i = xbmc . Keyboard ( II1I1I1Ii , 'Enter Search Term' )
  I1i11i . doModal ( )
  if I1i11i . isConfirmed ( ) :
   II1I1I1Ii = I1i11i . getText ( )
   if len ( II1I1I1Ii ) > 1 :
    ii = II1I1I1Ii . lower ( )
   else : quit ( )
   if 11 - 11: i1IIi11111i / i1111 + oo0ooO0oOOOOo * i11iiII - i11iiII - i1IIi11111i
  O0oOooooo0O = [ ]
  iiI1I1 = [ ]
  ooO = [ ]
  oO = [ ]
  if 6 - 6: ooO0oo0oO0 . iiIIiIiIi % oo0ooO0oOOOOo
  I1IiiI . create ( Oo0Ooo , "[COLOR white]We are searching for " + ii + ".[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
  I1IiiI . update ( 0 )
  if 50 - 50: i1iIIIiI1I + oooO0oo0oOOOO + i1IIiiiii . i1111 / oo0ooO0oOOOOo
  IiIIIIii1I = 1
  i1Iii11I1i = 0
  Iiii1iI1i = o0 ( url )
  Oo0oOOo = re . compile ( '<search>(.+?)</search>' , re . DOTALL ) . findall ( Iiii1iI1i )
  Oo00o0OO0O00o = len ( Oo0oOOo )
  for Oo0OoO00oOO0o in Oo0oOOo :
   O0Oooo = 100 * int ( IiIIIIii1I ) / int ( Oo00o0OO0O00o )
   I1IiiI . update ( O0Oooo , '' , '[COLOR blue]Searching list ' + str ( IiIIIIii1I ) + ' of ' + str ( Oo00o0OO0O00o ) + '[/COLOR]' )
   iiIi1i = o0 ( Oo0OoO00oOO0o )
   Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( iiIi1i )
   for I1i11111i1i11 in Oo0oOOo :
    I1ii1ii11i1I = re . compile ( 'title="(.+?)"' ) . findall ( I1i11111i1i11 ) [ 0 ]
    url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( I1i11111i1i11 ) [ 0 ]
    O000O0oOO0 = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( I1i11111i1i11 ) [ 0 ]
    O000O0oOO0 = "https://pic.rutube.ru" + O000O0oOO0 + "size=l"
    I1ii1ii11i1I = I1ii1ii11i1I . replace ( '.' , ' ' )
    if ii in I1ii1ii11i1I . lower ( ) :
     i1Iii11I1i = i1Iii11I1i + 1
     O0oOooooo0O . append ( I1ii1ii11i1I )
     iiI1I1 . append ( url )
     ooO . append ( O000O0oOO0 )
     oO = list ( zip ( O0oOooooo0O , iiI1I1 , ooO ) )
     if 77 - 77: i11iiII + oo / OooooO0oOO + oooO0oo0oOOOO * oo0ooO0oOOOOo
   IiIIIIii1I = IiIIIIii1I + 1
   if 28 - 28: iiIIiIiIi + i11iIiiIii / oo0Ooo0 % OOO0O % I11i1i11i1I - oooO0oo0oOOOO
  OOoo = sorted ( oO )
  Iiii ( '[B][COLOR dodgerblue]We found ' + str ( i1Iii11I1i ) + ' matches for ' + ii + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  Iiii ( '#######################################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  for OoOO0oo0o , url , O000O0oOO0 in OOoo :
   Iiii ( '[COLOR white]' + OoOO0oo0o + '[/COLOR]' , url , 2 , O000O0oOO0 , O000O0oOO0 , '' )
   if 54 - 54: II1Ii1iI1i + i1111
   if 83 - 83: i11iiII - i1IIi11111i + oOo0
   if 5 - 5: i1IIiiiii
 else :
  if 46 - 46: OoO000
  O0oOooooo0O = [ ]
  iiI1I1 = [ ]
  ooO = [ ]
  oO = [ ]
  if 45 - 45: iiIIiIiIi
  I1IiiI . create ( Oo0Ooo , "[COLOR white]We are searching for " + OoOO0oo0o + ".[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
  I1IiiI . update ( 0 )
  if 21 - 21: OooooO0oOO . OooOoO0Oo . oOo0 / I11i1i11i1I / OooOoO0Oo
  IiIIIIii1I = 1
  i1Iii11I1i = 0
  Iiii1iI1i = o0 ( ooOooo000oOO )
  oOOOoo00 = re . compile ( '<title>' + re . escape ( OoOO0oo0o ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( Iiii1iI1i ) [ 0 ]
  i1Iii1i1I = re . compile ( '<term>(.+?)</term>' ) . findall ( oOOOoo00 )
  iiIi1i = o0 ( url )
  i1iI1 = re . compile ( '<search>(.+?)</search>' , re . DOTALL ) . findall ( iiIi1i )
  Oo00o0OO0O00o = len ( i1iI1 )
  for Oo0OoO00oOO0o in i1iI1 :
   O0Oooo = 100 * int ( IiIIIIii1I ) / int ( Oo00o0OO0O00o )
   I1IiiI . update ( O0Oooo , '' , '[COLOR blue]Searching list ' + str ( IiIIIIii1I ) + ' of ' + str ( Oo00o0OO0O00o ) + '[/COLOR]' )
   iiIi1i = o0 ( Oo0OoO00oOO0o )
   Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( iiIi1i )
   for I1i11111i1i11 in Oo0oOOo :
    I1ii1ii11i1I = re . compile ( 'title="(.+?)"' ) . findall ( I1i11111i1i11 ) [ 0 ]
    url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( I1i11111i1i11 ) [ 0 ]
    O000O0oOO0 = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( I1i11111i1i11 ) [ 0 ]
    O000O0oOO0 = "https://pic.rutube.ru" + O000O0oOO0 + "size=l"
    I1ii1ii11i1I = I1ii1ii11i1I . replace ( '.' , ' ' )
    for ii in i1Iii1i1I :
     if ii . lower ( ) in I1ii1ii11i1I . lower ( ) :
      i1Iii11I1i = i1Iii11I1i + 1
      O0oOooooo0O . append ( I1ii1ii11i1I )
      iiI1I1 . append ( url )
      ooO . append ( O000O0oOO0 )
      oO = list ( zip ( O0oOooooo0O , iiI1I1 , ooO ) )
      if 1 - 1: II1Ii1iI1i . i11iIiiIii % oOo0
   IiIIIIii1I = IiIIIIii1I + 1
   if 82 - 82: ooO0oo0oO0 + I11i1i11i1I . ooO0oo0oO0 % OoO000 / i1IIiiiii . i1IIiiiii
  OOoo = sorted ( oO )
  Iiii ( '[B][COLOR dodgerblue]' + OoOO0oo0o + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  Iiii ( '#######################################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  for OoOO0oo0o , url , O000O0oOO0 in OOoo :
   Iiii ( '[COLOR white]' + OoOO0oo0o + '[/COLOR]' , url , 2 , O000O0oOO0 , O000O0oOO0 , '' )
   if 14 - 14: oo0ooO0oOOOOo . oOo0 . oo0Ooo0 + i111I - oOo0 + OoO000
def iII1iiiiIII ( url ) :
 if 78 - 78: oOo0 * oo0ooO0oOOOOo / oo0Ooo0 - oooO0oo0oOOOO / OoO000
 try :
  iII = o0 ( url ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
  OoOO0oo0o = url . split ( '/' ) [ 2 ]
  OoOO0oo0o = OoOO0oo0o . replace ( '.html' , '' )
  oOO = re . compile ( '<div class="schedule">(.+?)<br><div id="pagination">' ) . findall ( iII ) [ 0 ]
  O0o0OO0000ooo = re . compile ( '<a href="(.+?)">.+?<img src="(.+?)"></div>.+?<div class="home cell">.+?<span>(.+?)</span>.+?<span>(.+?)</span>.+?</a>' ) . findall ( oOO )
  for url , O000O0oOO0 , iIIII1iIIii , oOOO00o000o in O0o0OO0000ooo :
   url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + O000O0oOO0
   Iiii ( '[COLOR white]' + iIIII1iIIii + ' vs ' + oOOO00o000o + '[/COLOR]' , url , 2 , O000O0oOO0 , O0O0OO0O0O0 , '' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 9 - 9: OooooO0oOO + oo0Ooo0 / oo0Ooo0
def Ii1I11ii1i ( url ) :
 if 89 - 89: i1iIIIiI1I . oooO0oo0oOOOO / i11iiII % OOO0O . I11i1i11i1I
 try :
  iII = o0 ( url )
  O0o0OO0000ooo = re . compile ( "<td><strong>(.+?)</strong></td>.+?<a target=.+? href=(.+?) class=.+?" , re . DOTALL ) . findall ( iII )
  for IiiI1i , url in O0o0OO0000ooo :
   url = url . replace ( "'" , '' )
   url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iiiii
   Iiii ( '[COLOR white]' + IiiI1i + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 51 - 51: OoO000
def ii11I1 ( url ) :
 if 75 - 75: oo / i1111 % oooO0oo0oOOOO
 try :
  Ii111iIi1iIi = "http://cricbox.tv/"
  iII = o0 ( url )
  O0o0OO0000ooo = re . compile ( '<td><i class=".+?<td style="font-weight:bold;font-family: Calibri;"><a href="(.+?)">.+?<span style=".+?">(.+?)</span>.+?</a></td>' , re . DOTALL ) . findall ( iII )
  for url , IIIII in O0o0OO0000ooo :
   url = Ii111iIi1iIi + url
   url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iiiii
   Iiii ( '[COLOR white]' + IIIII + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 78 - 78: i1IIiiiii * II1Ii1iI1i
def iI11 ( url ) :
 if 96 - 96: oOo0
 try :
  iII = o0 ( url )
  O0o0OO0000ooo = re . compile ( '<a style="text-decoration:none !important;color:#545454;" href="(.+?)" target="_blank">(.+?)</a></td>' ) . findall ( iII )
  for url , IIIII in O0o0OO0000ooo :
   url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iiiii
   Iiii ( '[COLOR white]' + IIIII + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 85 - 85: oo0ooO0oOOOOo . OOO0O / iiIIiIiIi . oooO0oo0oOOOO % OooOoO0Oo
def OO0ooo0oOO ( url ) :
 if 97 - 97: i1IIi11111i / i1iIIIiI1I
 IiIIIIii1I = 0
 iII = o0 ( url )
 O0o0OO0000ooo = re . compile ( '<!-- Watch link. -->.+?<a href="(.+?)" title="live (.+?)" target="_blank"> ' , re . DOTALL ) . findall ( iII )
 for url , IiiI1i in O0o0OO0000ooo :
  IiIIIIii1I = IiIIIIii1I + 1
  url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iiiii
  Iiii ( '[COLOR white]' + IiiI1i + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 71 - 71: i1111 / II1Ii1iI1i . i11iiII % i111I . OOO0O
 if IiIIIIii1I == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, we could not find any live links at the moment. Please try again later." )
  quit ( )
  if 41 - 41: II1Ii1iI1i * i1111 / i111I . oOo0
def O0 ( ) :
 if 33 - 33: II1Ii1iI1i
 iII = o0 ( "http://sports4u.live" )
 Oo0oOOo = re . compile ( '<h4>Watch live</h4>(.+?)</div>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 Ii1iII1iI1 = re . compile ( '<ul><li>(.+?)</ul></li>' , re . DOTALL ) . findall ( iII )
 for I1i11111i1i11 in Ii1iII1iI1 :
  II11i1I11Ii1i = re . compile ( '<a href="(.+?)">' ) . findall ( I1i11111i1i11 ) [ 0 ]
  i1i1IIIIi1i = re . compile ( 'src="(.+?)"' ) . findall ( I1i11111i1i11 ) [ 0 ]
  OoOO0oo0o = II11i1I11Ii1i . split ( "channel/" ) [ 1 ]
  OoOO0oo0o = OoOO0oo0o . split ( "-live" ) [ 0 ]
  OoOO0oo0o = OoOO0oo0o . replace ( "-" , " " )
  O000O0oOO0 = 'http://sports4u.live' + i1i1IIIIi1i
  Iiii ( '[COLOR white]' + OoOO0oo0o . title ( ) + '[/COLOR]' , II11i1I11Ii1i , 306 , O000O0oOO0 , O0O0OO0O0O0 , '' )
  if 7 - 7: ooO0oo0oO0 + i1iIIIiI1I * i11iIiiIii / i111I + i1iIIIiI1I - I11i1i11i1I
def IiiioooOOoooo ( name , url , iconimage ) :
 if 89 - 89: i1iIIIiI1I - iiIIiIiIi % I11i1i11i1I % oo0ooO0oOOOOo
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="watch-stream">(.+?)</div>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 url = re . compile ( 'src="(.+?)" name="iframe_a"' , re . DOTALL ) . findall ( Oo0oOOo ) [ 0 ]
 url = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + url + '%26referer=no%26icon%3d' + iconimage + '%26title=' + name
 OOoOO0ooo ( name , url , iconimage )
 if 49 - 49: I11i1i11i1I - i1IIi11111i / OoO000 / oooO0oo0oOOOO % oo0ooO0oOOOOo * i1IIiiiii
def OOoO0 ( name , url , iconimage ) :
 if 22 - 22: I11i1i11i1I % i1iIIIiI1I * i11iiII / oOo0 % i11iIiiIii * oo0Ooo0
 O0o0 , ii11i1 = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 O0o0 += urllib . unquote_plus ( ii11i1 )
 url = regex . resolve ( O0o0 )
 if 95 - 95: i111I - OoO000 * i1IIi11111i + OOO0O
 OOoOO0ooo ( name , url , iconimage )
 if 10 - 10: oo0ooO0oOOOOo / i11iIiiIii
def o00 ( ) :
 if 85 - 85: i11iiII . OooOoO0Oo
 Iiii ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 Iiii ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 Iiii ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 oo0oOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 oo0oOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 78 - 78: iiIIiIiIi * OooOoO0Oo + ooO0oo0oO0 + ooO0oo0oO0 / OooOoO0Oo . i1IIiiiii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 97 - 97: iiIIiIiIi / OooOoO0Oo % II1Ii1iI1i % i11iiII
def ii111I11iI ( ) :
 if 93 - 93: i11iiII / ooO0oo0oO0 * II1Ii1iI1i % i111I * oooO0oo0oOOOO * oo0Ooo0
 oo0oOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 64 - 64: i1111 + oooO0oo0oOOOO / ooO0oo0oO0 / I11i1i11i1I . iiIIiIiIi % OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 50 - 50: ooO0oo0oO0 - OoO000 + oOo0
def o0iiiI1I1iIIIi1 ( ) :
 if 17 - 17: ooO0oo0oO0 . i111I / oo0Ooo0 % i1111 % II1Ii1iI1i / i11iIiiIii
 oo0oOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 58 - 58: I11i1i11i1I . i1111 + OooooO0oOO - i11iIiiIii / i1111 / oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 85 - 85: OOO0O + oOo0
def I1II ( ) :
 if 27 - 27: i1111 / i1IIiiiii . oOo0
 IiIIIIii1I = 0
 Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IiIIIIii1I = IiIIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  II11i1I11Ii1i = Oo0OoO00oOO0o
  oo0oOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( IiIIIIii1I ) + '[/COLOR]' , II11i1I11Ii1i , 12 , iiiii , O0O0OO0O0O0 )
  if 9 - 9: iiIIiIiIi - i11iiII - i1iIIIiI1I
 Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IiIIIIii1I = IiIIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  II11i1I11Ii1i = Oo0OoO00oOO0o
  oo0oOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( IiIIIIii1I ) + '[/COLOR]' , II11i1I11Ii1i , 12 , iiiii , O0O0OO0O0O0 )
  if 82 - 82: OoO000 - OoO000 + OOO0O
 Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IiIIIIii1I = IiIIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  II11i1I11Ii1i = Oo0OoO00oOO0o
  oo0oOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( IiIIIIii1I ) + '[/COLOR]' , II11i1I11Ii1i , 12 , iiiii , O0O0OO0O0O0 )
  if 8 - 8: oo0ooO0oOOOOo % i1iIIIiI1I * OooooO0oOO % i1IIiiiii . iiIIiIiIi / iiIIiIiIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 81 - 81: oo
def oO0o00oOOooO0 ( url ) :
 if 79 - 79: oo - ooO0oo0oO0 + i1IIiiiii - OooOoO0Oo
 Iiii1iI1i = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
 if 93 - 93: i1111 . i1IIi11111i - I11i1i11i1I + OOO0O
 for Oo0OoO00oOO0o in Oo0oOOo :
  OoOO0oo0o = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  O000O0oOO0 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  oo0oOo ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 12 , O000O0oOO0 , O0O0OO0O0O0 )
  if 61 - 61: i1111
 try :
  Ii1ii111i1 = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( Iiii1iI1i ) [ 0 ]
  oo0oOo ( '[COLOR yellow]Next Page -->[/COLOR]' , Ii1ii111i1 , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 31 - 31: oOo0 + oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 87 - 87: iiIIiIiIi
def IIIii ( ) :
 if 83 - 83: OoO000 % oo0ooO0oOOOOo % i1IIi11111i . ooO0oo0oO0 - OoO000
 Iiii1iI1i = o0 ( 'http://arenavision.in/schedule' )
 Oo0oOOo = re . compile ( '<tr><td class="auto-style3"(.+?)</tr>' , re . DOTALL ) . findall ( Iiii1iI1i )
 if 88 - 88: i111I
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   o0o0O0O00oOOo = re . compile ( '190px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   time = re . compile ( '182px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OO00 = re . compile ( '188px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   IIiiIIi1 = re . compile ( '685px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   o00ooO00O = re . compile ( '317px">(.+?) ' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i = IIiiIIi1 + '|SPLIT|' + o00ooO00O
   Iiii ( '[COLOR blue][B]' + IIiiIIi1 + '[/B][/COLOR] - [COLOR white]' + o0o0O0O00oOOo + ' | [COLOR orangered][B]' + time + '[/B][/COLOR] | ' + OO00 + '[/COLOR]' , II11i1I11Ii1i , 97 , iiiii , O0O0OO0O0O0 )
  except : pass
 oOo0oO = OOOO0oo0 ( )
 if 68 - 68: i11iIiiIii + i1IIiiiii
 if oOo0oO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oOo0oO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 77 - 77: OooOoO0Oo
def OooOOOOoO00OoOO ( name , url , iconimage ) :
 if 85 - 85: OooooO0oOO - ooO0oo0oO0 / oooO0oo0oOOOO
 name , url = url . split ( '|SPLIT|' )
 if 99 - 99: i1111 * OoO000 % ooO0oo0oO0 / i1IIiiiii
 OOO00O0oOOo = "null"
 O0oO = "null"
 if 79 - 79: oo0ooO0oOOOOo % i1iIIIiI1I * i111I * ooO0oo0oO0 . i1iIIIiI1I / i1IIiiiii
 if "-" in url :
  OOO00O0oOOo , O0oO = url . split ( '-' )
  if 19 - 19: oooO0oo0oOOOO + oo0Ooo0 + i1IIiiiii / i1111 / i1111
  oO0o0O0Ooo0o = O00ooooo00 . select ( "[COLOR red]Please select an stream[/COLOR]" , [ '[COLOR white]Link 1[/COLOR]' , '[COLOR white]Link 2[/COLOR]' ] )
  if 21 - 21: OooOoO0Oo - i1IIi11111i + oo0Ooo0
  if oO0o0O0Ooo0o == 0 : url = 'http://arenavision.in/av' + OOO00O0oOOo
  elif oO0o0O0Ooo0o == 1 : url = 'http://arenavision.in/av' + O0oO
  else : quit ( )
  if 78 - 78: i111I - i11iIiiIii - i1111
 else : url = 'http://arenavision.in/av' + url
 if 77 - 77: OOO0O % i1IIiiiii
 II1IiiIii ( name , url , iconimage )
 if 84 - 84: OooooO0oOO % II1Ii1iI1i
 if 70 - 70: I11i1i11i1I . i111I - i1iIIIiI1I
def II1IiiIii ( name , url , iconimage ) :
 if 30 - 30: i11iiII % i1IIi11111i
 try :
  Iiii1iI1i = o0 ( url )
  Oo0oOOo = re . compile ( 'this.loadPlayer(.+?),' , re . DOTALL ) . findall ( Iiii1iI1i ) [ 0 ]
  url = Oo0oOOo . replace ( '(' , '' ) . replace ( ')' , '' ) . replace ( '"' , '' ) . replace ( ' ' , '' )
  if 89 - 89: OooOoO0Oo + i111I + OooOoO0Oo * II1Ii1iI1i + ooO0oo0oO0 % oo0Ooo0
  ooOooo000oOO = 'plugin://program.plexus/?url=acestream://' + str ( url ) + '&mode=1&name=acestream+' + str ( name )
  if 59 - 59: oOo0 + i11iIiiIii
  OOoOO0ooo ( name , ooOooo000oOO , iconimage )
 except : quit ( )
 if 88 - 88: i11iIiiIii - iiIIiIiIi
def O0iIi1IiII ( url ) :
 if 27 - 27: i1iIIIiI1I . oo0Ooo0 . ooO0oo0oO0 . ooO0oo0oO0
 Iiii1iI1i = o0 ( url )
 Oo0oOOo = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( Iiii1iI1i )
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except :
   OoOO0oo0o = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  oo0oOo ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 20 - 20: oo0ooO0oOOOOo / II1Ii1iI1i
def oOIi111 ( url ) :
 if 67 - 67: oooO0oo0oOOOO
 Iiii1iI1i = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( Iiii1iI1i )
 Ooo = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : Ooo = 1
  if 99 - 99: oooO0oo0oOOOO + i111I
  if Ooo == 0 :
   oo0oOo ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 12 , O000O0oOO0 , O0O0OO0O0O0 )
  Ooo = 0
  if 4 - 4: i1IIi11111i % oo0Ooo0
 try :
  Ii1ii111i1 = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( Iiii1iI1i ) [ 0 ]
  oo0oOo ( '[COLOR yellow]Next Page -->[/COLOR]' , Ii1ii111i1 , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 10 - 10: OoO000 . i111I - oo + OoO000 - oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 82 - 82: iiIIiIiIi + i1111
def II1i1i1iII1 ( url ) :
 if 68 - 68: I11i1i11i1I + i11iIiiIii
 Oo0oOooo000OO = datetime . date . today ( )
 OO0oOo = datetime . datetime . strftime ( Oo0oOooo000OO , '%A %d %B %Y' )
 if 35 - 35: i1iIIIiI1I + iiIIiIiIi - OooooO0oOO . i1iIIIiI1I . OoO000
 Iiii ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( OO0oOo ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 Iiii ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 87 - 87: OOO0O
 Iiii1iI1i = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( Iiii1iI1i )
 Ooo = 0
 IiIIIIii1I = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   I1ii1ii11i1I = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    Ii = re . compile ( '<p>(.+?)</p>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : Ii = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<img src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : Ooo = 1
  if 65 - 65: OOO0O / oo % OoO000
  if Ooo == 0 :
   if 'vs' in I1ii1ii11i1I :
    OoOO0oo0o = '[COLOR dodgerblue]' + I1ii1ii11i1I + ' - ' + '[/COLOR][COLOR blue]' + Ii + '[/COLOR]'
    IiIIIIii1I = IiIIIIii1I + 1
    Iiii ( OoOO0oo0o , url , 206 , O000O0oOO0 , O0O0OO0O0O0 , '' )
  Ooo = 0
  if 45 - 45: OOO0O
 if IiIIIIii1I == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 66 - 66: oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 56 - 56: oooO0oo0oOOOO
def OOo00 ( name , url , iconimage ) :
 if 37 - 37: II1Ii1iI1i
 Iiii1iI1i = o0 ( url )
 III1i1iI1 = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( Iiii1iI1i ) [ 0 ]
 if 97 - 97: oo0Ooo0 - i11iIiiIii
 if not "http" in III1i1iI1 :
  III1i1iI1 = III1i1iI1 . replace ( "//" , "" )
  url = "http://" + III1i1iI1
 else :
  url = III1i1iI1
  if 17 - 17: oo0Ooo0
 oo0OO00oO = url
 if 93 - 93: i1IIiiiii - oOo0 + ooO0oo0oO0 * oo0ooO0oOOOOo + OooOoO0Oo . i1iIIIiI1I
 IiI1iII1II111 = o0 ( url )
 III1i1iI1 = re . compile ( "atob(.+?)," ) . findall ( IiI1iII1II111 ) [ 0 ]
 III1i1iI1 = III1i1iI1 . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( III1i1iI1 )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + oo0OO00oO + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 OOoOO0ooo ( name , url , iconimage )
 if 28 - 28: OOO0O * oo . oo0Ooo0 % oo0Ooo0 / oo0Ooo0 * OooOoO0Oo
def ooO00O0O0 ( url ) :
 if 33 - 33: I11i1i11i1I
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 49 - 49: oo % i1iIIIiI1I % i1iIIIiI1I / i1iIIIiI1I
  if '<display>eWVz</display>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0ooo0O0oo0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OoOO0oo0o = base64 . b64decode ( OoOO0oo0o )
   url = base64 . b64decode ( url )
   O000O0oOO0 = base64 . b64decode ( O000O0oOO0 )
   O0ooo0O0oo0 = base64 . b64decode ( O0ooo0O0oo0 )
   oo0oOo ( OoOO0oo0o , url , 220 , O000O0oOO0 , O0ooo0O0oo0 , '' )
   if 53 - 53: ooO0oo0oO0
def oooo00o0o0o ( url ) :
 if 87 - 87: oo0Ooo0 * II1Ii1iI1i - i1IIiiiii % oOo0 / OooOoO0Oo
 Iiii1iI1i = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( Iiii1iI1i )
 if 39 - 39: i1IIi11111i * i11iIiiIii - OooooO0oOO / OoO000 % OooOoO0Oo % oo0Ooo0
 for Oo0OoO00oOO0o in Oo0oOOo :
  OoOO0oo0o = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   OO00oo0o = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : OO00oo0o = "SD"
  OO00oo0o = '[COLOR yellow]' + OO00oo0o + '[/COLOR]'
  O000O0oOO0 = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  OoOO0oo0o = OoOO0oo0o . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 18 - 18: oo + ooO0oo0oO0 - i1111 - i1IIi11111i
  Iiii ( '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR] - ' + OO00oo0o , url , 212 , O000O0oOO0 , O0O0OO0O0O0 , '' )
  if 71 - 71: i111I
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( Iiii1iI1i ) [ 0 ]
  OOOOoO00o0O = 'http://www.fmovies.se/' + url
  oo0oOo ( "Next Page -->" , OOOOoO00o0O , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 33 - 33: OooOoO0Oo
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 62 - 62: i11iiII + i1IIiiiii + II1Ii1iI1i / i111I
def IIiiii ( url ) :
 if 37 - 37: oo0ooO0oOOOOo % iiIIiIiIi
 Iiii1iI1i = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( Iiii1iI1i )
 if 83 - 83: oOo0 . OooOoO0Oo + OooooO0oOO - oOo0 * OooOoO0Oo / OooOoO0Oo
 if 39 - 39: OooOoO0Oo / I11i1i11i1I % oo % i11iIiiIii
def o0o0Ooo0 ( url ) :
 if 78 - 78: ooO0oo0oO0 + oo0Ooo0 - i1IIiiiii * OooOoO0Oo - i111I % OOO0O
 if "iptvembed" in url :
  Iiii1iI1i = o0 ( url )
  Oo0oOOo = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '</pre>' , '' )
   url = Oo0OoO00oOO0o
   if 34 - 34: oooO0oo0oOOOO
 if "sourcetv" in url :
  Iiii1iI1i = o0 ( url )
  Oo0oOOo = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '</pre>' , '' )
   url = Oo0OoO00oOO0o
   if 80 - 80: II1Ii1iI1i - I11i1i11i1I / oo - i11iIiiIii
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 iIIIIIiI1I1 = [ ]
 for I11I1IIiiII1 , IIIIIii1ii11 , url in OO0O0o0o0 :
  OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : url }
  iIIIIIiI1I1 . append ( OOOooo0OooOoO )
 list = [ ]
 for o00ooO00O in iIIIIIiI1I1 :
  OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
  OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
  for oOoOOOo , ii1I in OO0O0o0o0 :
   OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
  list . append ( OOOooo0OooOoO )
  if 85 - 85: oo0Ooo0
 ooOoO0 = 0
 for o00ooO00O in list :
  ooOoO0 = 1
  OoOO0oo0o = oo0oooOo ( o00ooO00O [ "display_name" ] )
  url = oo0oooOo ( o00ooO00O [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   Iiii ( '[COLOR white]' + OoOO0oo0o + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   oo0oOo ( '[COLOR white]' + OoOO0oo0o + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 59 - 59: OooOoO0Oo - oo0ooO0oOOOOo - iiIIiIiIi
 if ooOoO0 == 0 :
  Iiii ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 48 - 48: II1Ii1iI1i + oo0Ooo0 % OOO0O / I11i1i11i1I - oo0ooO0oOOOOo
def OOoOOo0O00O ( url ) :
 if 36 - 36: oooO0oo0oOOOO + I11i1i11i1I
 iII = o0 ( url )
 ooOooo000oOO = url
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 5 - 5: I11i1i11i1I * OOO0O
  i1Iii1i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
  if len ( i1Iii1i1I ) == 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = OoOO0oo0o + "!" + url + "!" + O000O0oOO0
   OoOO0oo0o = '[COLOR white]' + OoOO0oo0o + '[/COLOR]'
   oo0oOo ( OoOO0oo0o , url , 20 , O000O0oOO0 , O000O0oOO0 )
   if 46 - 46: iiIIiIiIi
  elif len ( i1Iii1i1I ) > 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = ooOooo000oOO + "!" + OoOO0oo0o + "!" + O000O0oOO0
   OoOO0oo0o = '[COLOR white]' + OoOO0oo0o + '[/COLOR]'
   oo0oOo ( OoOO0oo0o , url , 22 , O000O0oOO0 , O000O0oOO0 )
   if 33 - 33: i1iIIIiI1I - i1111 * i111I - I11i1i11i1I - oOo0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 84 - 84: OooOoO0Oo + I11i1i11i1I - OOO0O * OOO0O
def OoooO0o ( url ) :
 if 24 - 24: OOO0O % II1Ii1iI1i + i1iIIIiI1I . i11iIiiIii . i11iiII
 Oo0oOooo000OO = datetime . date . today ( )
 OO0oOo = datetime . datetime . strftime ( Oo0oOooo000OO , '%A %d %B %Y' )
 if 17 - 17: i11iiII . i1111 . iiIIiIiIi / i11iiII
 Iiii ( '[COLOR dodgerblue]EVENTS FOR ' + str ( OO0oOo ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 Iiii ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 57 - 57: oo0Ooo0
 iII = o0 ( url )
 ooOooo000oOO = url
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 67 - 67: oo . iiIIiIiIi
  i1Iii1i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
  if len ( i1Iii1i1I ) == 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = OoOO0oo0o + "!" + url + "!" + O000O0oOO0
   OoOO0oo0o = '[COLOR white]' + OoOO0oo0o + '[/COLOR]'
   oo0oOo ( OoOO0oo0o , url , 20 , O000O0oOO0 , O000O0oOO0 )
   if 87 - 87: OooooO0oOO % i1IIiiiii
  elif len ( i1Iii1i1I ) > 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000O0oOO0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = ooOooo000oOO + "!" + OoOO0oo0o + "!" + O000O0oOO0
   OoOO0oo0o = '[COLOR white]' + OoOO0oo0o + '[/COLOR]'
   oo0oOo ( OoOO0oo0o , url , 22 , O000O0oOO0 , O000O0oOO0 )
   if 83 - 83: i1111 - oo0Ooo0
def iiIii1IIi ( ) :
 if 10 - 10: i11iIiiIii - oo0ooO0oOOOOo % ooO0oo0oO0
 Oo0oOooo000OO = datetime . date . today ( )
 OO0oOo = datetime . datetime . strftime ( Oo0oOooo000OO , '%A %d %B %Y' )
 if 49 - 49: OooooO0oOO
 Iiii ( '[COLOR dodgerblue]EVENTS FOR ' + str ( OO0oOo ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 Iiii ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 83 - 83: OooooO0oOO % I11i1i11i1I - oo0ooO0oOOOOo . i1iIIIiI1I / I11i1i11i1I % i11iiII
 iII = o0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 Oo0oOOo = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( iII )
 II1I1I1Ii = str ( Oo0oOOo )
 i1iI1 = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( II1I1I1Ii )
 for Oo0OoO00oOO0o in i1iI1 :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in Oo0OoO00oOO0o :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    I1ii1ii11i1I = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000O0oOO0 = re . compile ( 'src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     OooOo0o0Oo = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
     OooOo0o0Oo = OooO0oOo ( OooOo0o0Oo )
    except : OooOo0o0Oo = "null"
    OoOO0oo0o = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + I1ii1ii11i1I + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    OoOO0oo0o = oOOo00O0OOOo ( OoOO0oo0o )
    II11i1I11Ii1i = I1ii1ii11i1I + "!" + OooOo0o0Oo . lower ( ) + "!" + O000O0oOO0
    oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 20 , O000O0oOO0 , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    I1ii1ii11i1I = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     OooOo0o0Oo = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : OooOo0o0Oo = "null"
    O000O0oOO0 = re . compile ( 'src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    OoOO0oo0o = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + I1ii1ii11i1I + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    OoOO0oo0o = oOOo00O0OOOo ( OoOO0oo0o )
    II11i1I11Ii1i = I1ii1ii11i1I + "!" + OooOo0o0Oo . lower ( ) + "!" + O000O0oOO0
    oo0oOo ( OoOO0oo0o , II11i1I11Ii1i , 20 , O000O0oOO0 , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 31 - 31: oo0Ooo0 % oOo0 * oo0Ooo0
def IiII1i1iii1Ii ( name , url , iconimage ) :
 if 23 - 23: i11iIiiIii
 try :
  url , II1I11IIi , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 66 - 66: i11iIiiIii / oo0ooO0oOOOOo - i111I / II1Ii1iI1i . i11iIiiIii
 IIIII1iii11 = [ ]
 if 35 - 35: OooooO0oOO / OooOoO0Oo / i1111 - ooO0oo0oO0 + i1111 . OooOoO0Oo
 iII = o0 ( url )
 oOOOoo00 = re . compile ( '<title>' + re . escape ( II1I11IIi ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oOOOoo00 ) [ 0 ]
 i1Iii1i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( oOOOoo00 )
 for iiIiIIIiiI in i1Iii1i1I :
  IIIII1iii11 . append ( iiIiIIIiiI )
  if 81 - 81: i1iIIIiI1I * oOo0 - i11iiII * i1IIiiiii % OOO0O * OOO0O
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 59 - 59: ooO0oo0oO0
 I1ii1Ii1ii11i = 0
 if 94 - 94: OoO000 + OooOoO0Oo / oOo0
 O0oOooooo0O = [ ]
 iiI1I1 = [ ]
 o00o = [ ]
 I1IiiI . update ( 0 )
 iii11II1I = 0
 if 5 - 5: OOO0O - OoO000 * OoO000
 if oO000OoOoo00o == "true" :
  iii11II1I = 1
  Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if I1ii1Ii1ii11i < 100 :
    I1IiiI . update ( I1ii1Ii1ii11i )
    I1ii1Ii1ii11i = I1ii1Ii1ii11i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iIIIIIiI1I1 = [ ]
   for I11I1IIiiII1 , IIIIIii1ii11 , url in OO0O0o0o0 :
    OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : url }
    iIIIIIiI1I1 . append ( OOOooo0OooOoO )
   IiiIi1IIII1i = [ ]
   for o00ooO00O in iIIIIIiI1I1 :
    OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
    OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
    for oOoOOOo , ii1I in OO0O0o0o0 :
     OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
    IiiIi1IIII1i . append ( OOOooo0OooOoO )
    if 98 - 98: oOo0 + II1Ii1iI1i . i1IIi11111i - i1111 - oo0ooO0oOOOOo
   for o00ooO00O in IiiIi1IIII1i :
    name = oo0oooOo ( o00ooO00O [ "display_name" ] )
    url = oo0oooOo ( o00ooO00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    O0oOooooo0O . append ( name )
    iiI1I1 . append ( url )
    if "hd" in name . lower ( ) :
     o00o . append ( "1" )
    else :
     o00o . append ( "0" )
    oO = list ( zip ( o00o , O0oOooooo0O , iiI1I1 ) )
    if 24 - 24: I11i1i11i1I - II1Ii1iI1i + oo0Ooo0
 if iiiI11 == "true" :
  iii11II1I = 1
  Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if I1ii1Ii1ii11i < 100 :
    I1IiiI . update ( I1ii1Ii1ii11i )
    I1ii1Ii1ii11i = I1ii1Ii1ii11i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iIIIIIiI1I1 = [ ]
   for I11I1IIiiII1 , IIIIIii1ii11 , url in OO0O0o0o0 :
    OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : url }
    iIIIIIiI1I1 . append ( OOOooo0OooOoO )
   IiiIi1IIII1i = [ ]
   for o00ooO00O in iIIIIIiI1I1 :
    OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
    OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
    for oOoOOOo , ii1I in OO0O0o0o0 :
     OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
    IiiIi1IIII1i . append ( OOOooo0OooOoO )
    if 38 - 38: i111I / i11iiII . oooO0oo0oOOOO / II1Ii1iI1i / I11i1i11i1I + ooO0oo0oO0
   for o00ooO00O in IiiIi1IIII1i :
    name = oo0oooOo ( o00ooO00O [ "display_name" ] )
    url = oo0oooOo ( o00ooO00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    O0oOooooo0O . append ( name )
    iiI1I1 . append ( url )
    if "hd" in name . lower ( ) :
     o00o . append ( "1" )
    else :
     o00o . append ( "0" )
    oO = list ( zip ( o00o , O0oOooooo0O , iiI1I1 ) )
    if 96 - 96: i1iIIIiI1I
 if OOooO == "true" :
  iii11II1I = 1
  Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if I1ii1Ii1ii11i < 100 :
    I1IiiI . update ( I1ii1Ii1ii11i )
    I1ii1Ii1ii11i = I1ii1Ii1ii11i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iIIIIIiI1I1 = [ ]
   for I11I1IIiiII1 , IIIIIii1ii11 , url in OO0O0o0o0 :
    OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : url }
    iIIIIIiI1I1 . append ( OOOooo0OooOoO )
   IiiIi1IIII1i = [ ]
   for o00ooO00O in iIIIIIiI1I1 :
    OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
    OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
    for oOoOOOo , ii1I in OO0O0o0o0 :
     OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
    IiiIi1IIII1i . append ( OOOooo0OooOoO )
    if 18 - 18: i1iIIIiI1I * oo0Ooo0 - i1IIiiiii
   for o00ooO00O in IiiIi1IIII1i :
    name = oo0oooOo ( o00ooO00O [ "display_name" ] )
    url = oo0oooOo ( o00ooO00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    O0oOooooo0O . append ( name )
    iiI1I1 . append ( url )
    if "hd" in name . lower ( ) :
     o00o . append ( "1" )
    else :
     o00o . append ( "0" )
    oO = list ( zip ( o00o , O0oOooooo0O , iiI1I1 ) )
    if 31 - 31: I11i1i11i1I - oooO0oo0oOOOO % OOO0O % OooooO0oOO
 if iii11II1I == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 45 - 45: i11iiII + i1111 * i11iIiiIii
 OOoo = sorted ( oO , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 IiIIi1I1I11Ii = sorted ( IIIII1iii11 )
 if 64 - 64: i111I
 iiIIiiIi1Ii11 = 0
 if 81 - 81: i11iiII - oooO0oo0oOOOO * i111I
 I1IiiI . update ( 100 )
 if 23 - 23: i1111 / OooooO0oOO
 Iiii ( '[COLOR dodgerblue][B]LINKS FOR ' + II1I11IIi . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 Iiii ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 28 - 28: I11i1i11i1I * iiIIiIiIi - oo
 if 19 - 19: oo0Ooo0
 for OooOo0o0Oo in IiIIi1I1I11Ii :
  if 67 - 67: oooO0oo0oOOOO % ooO0oo0oO0 / OoO000 . i11iIiiIii - i1IIiiiii + oooO0oo0oOOOO
  Iiii ( '[COLOR orangered][B]' + OooOo0o0Oo . upper ( ) + ' LINKS[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 27 - 27: oOo0
  II1I1I1Ii = OooOo0o0Oo . split ( ' ' )
  if 89 - 89: i1111 / OooooO0oOO
  for IIo0OoO00 , name , url in OOoo :
   if 18 - 18: OooooO0oOO - oo0ooO0oOOOOo - i1IIi11111i - i1IIi11111i
   OOooo00 = 0
   if 35 - 35: OooOoO0Oo . OOO0O * i11iIiiIii
   for iiII in II1I1I1Ii :
    if 57 - 57: oo0Ooo0 . I11i1i11i1I + i1111
    if not iiII . lower ( ) in name . lower ( ) :
     OOooo00 = 1
     if 43 - 43: OooOoO0Oo % i1iIIIiI1I
   if OOooo00 == 0 :
    iiIIiiIi1Ii11 = iiIIiiIi1Ii11 + 1
    if "hd" in name . lower ( ) :
     Iiii ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iiIIiiIi1Ii11 ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     Iiii ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iiIIiiIi1Ii11 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 69 - 69: i1iIIIiI1I % oo
  if iiIIiiIi1Ii11 == 0 :
   Iiii ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 86 - 86: OooooO0oOO / OooooO0oOO
  II1I1I1Ii = ""
  if 28 - 28: i11iIiiIii / oo0ooO0oOOOOo . ooO0oo0oO0 / i1111
 I1IiiI . close ( )
 if 72 - 72: i111I / i1IIi11111i + i1IIiiiii / OOO0O * i1IIiiiii
def Ii1iIi111i1i1 ( name , url , iconimage ) :
 if 45 - 45: OOO0O . oo0ooO0oOOOOo % OOO0O * i1IIi11111i % i1IIi11111i
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 63 - 63: OooOoO0Oo
 I1ii1Ii1ii11i = 0
 try :
  II1I11IIi , OooOo0o0Oo , iconimage = url . split ( '!' )
 except :
  try :
   OooOo0o0Oo , iconimage = url . split ( '!' )
   II1I11IIi = OooOo0o0Oo
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 53 - 53: i111I - OoO000
 oOo = 0
 if 17 - 17: i1IIiiiii . i11iIiiIii
 if "all " in name . lower ( ) :
  OooOo0o0Oo = OooOo0o0Oo . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  II1I11IIi = II1I11IIi . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  oOo = 1
  if 5 - 5: i11iiII + oooO0oo0oOOOO + oooO0oo0oOOOO . OooOoO0Oo - iiIIiIiIi
 O0oOooooo0O = [ ]
 iiI1I1 = [ ]
 o00o = [ ]
 I1IiiI . update ( 0 )
 iii11II1I = 0
 if oO000OoOoo00o == "true" :
  iii11II1I = 1
  Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if I1ii1Ii1ii11i < 100 :
    I1IiiI . update ( I1ii1Ii1ii11i )
    I1ii1Ii1ii11i = I1ii1Ii1ii11i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iIIIIIiI1I1 = [ ]
   for I11I1IIiiII1 , IIIIIii1ii11 , url in OO0O0o0o0 :
    OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : url }
    iIIIIIiI1I1 . append ( OOOooo0OooOoO )
   IiiIi1IIII1i = [ ]
   for o00ooO00O in iIIIIIiI1I1 :
    OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
    OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
    for oOoOOOo , ii1I in OO0O0o0o0 :
     OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
    IiiIi1IIII1i . append ( OOOooo0OooOoO )
    if 63 - 63: OooooO0oOO
   for o00ooO00O in IiiIi1IIII1i :
    name = oo0oooOo ( o00ooO00O [ "display_name" ] )
    url = oo0oooOo ( o00ooO00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    O0oOooooo0O . append ( name )
    iiI1I1 . append ( url )
    if "hd" in name . lower ( ) :
     o00o . append ( "1" )
    else :
     o00o . append ( "0" )
    oO = list ( zip ( o00o , O0oOooooo0O , iiI1I1 ) )
    if 71 - 71: II1Ii1iI1i . i1IIiiiii * i1iIIIiI1I % i111I + oOo0
 if iiiI11 == "true" :
  iii11II1I = 1
  Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if I1ii1Ii1ii11i < 100 :
    I1IiiI . update ( I1ii1Ii1ii11i )
    I1ii1Ii1ii11i = I1ii1Ii1ii11i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iIIIIIiI1I1 = [ ]
   for I11I1IIiiII1 , IIIIIii1ii11 , url in OO0O0o0o0 :
    OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : url }
    iIIIIIiI1I1 . append ( OOOooo0OooOoO )
   IiiIi1IIII1i = [ ]
   for o00ooO00O in iIIIIIiI1I1 :
    OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
    OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
    for oOoOOOo , ii1I in OO0O0o0o0 :
     OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
    IiiIi1IIII1i . append ( OOOooo0OooOoO )
    if 36 - 36: OoO000
   for o00ooO00O in IiiIi1IIII1i :
    name = oo0oooOo ( o00ooO00O [ "display_name" ] )
    url = oo0oooOo ( o00ooO00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    O0oOooooo0O . append ( name )
    iiI1I1 . append ( url )
    if "hd" in name . lower ( ) :
     o00o . append ( "1" )
    else :
     o00o . append ( "0" )
    oO = list ( zip ( o00o , O0oOooooo0O , iiI1I1 ) )
    if 49 - 49: oOo0 / i111I / i1IIi11111i
 if OOooO == "true" :
  iii11II1I = 1
  Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if I1ii1Ii1ii11i < 100 :
    I1IiiI . update ( I1ii1Ii1ii11i )
    I1ii1Ii1ii11i = I1ii1Ii1ii11i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iIIIIIiI1I1 = [ ]
   for I11I1IIiiII1 , IIIIIii1ii11 , url in OO0O0o0o0 :
    OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : url }
    iIIIIIiI1I1 . append ( OOOooo0OooOoO )
   IiiIi1IIII1i = [ ]
   for o00ooO00O in iIIIIIiI1I1 :
    OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
    OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
    for oOoOOOo , ii1I in OO0O0o0o0 :
     OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
    IiiIi1IIII1i . append ( OOOooo0OooOoO )
    if 74 - 74: OooOoO0Oo % i11iiII
   for o00ooO00O in IiiIi1IIII1i :
    name = oo0oooOo ( o00ooO00O [ "display_name" ] )
    url = oo0oooOo ( o00ooO00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    O0oOooooo0O . append ( name )
    iiI1I1 . append ( url )
    if "hd" in name . lower ( ) :
     o00o . append ( "1" )
    else :
     o00o . append ( "0" )
    oO = list ( zip ( o00o , O0oOooooo0O , iiI1I1 ) )
    if 7 - 7: i1111
 if iii11II1I == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 27 - 27: OooooO0oOO . i111I + i11iIiiIii
 OOoo = sorted ( oO , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 if 86 - 86: oo0Ooo0 / oo0ooO0oOOOOo - oo0ooO0oOOOOo + i11iiII + OooooO0oOO
 iiIIiiIi1Ii11 = 0
 if 33 - 33: oo0ooO0oOOOOo . i1iIIIiI1I . OoO000 . II1Ii1iI1i
 I1IiiI . update ( 100 )
 if 49 - 49: i11iiII
 Iiii ( '[COLOR dodgerblue][B]LINKS FOR ' + II1I11IIi . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 Iiii ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 II1I1I1Ii = OooOo0o0Oo . split ( ' ' )
 for IIo0OoO00 , name , url in OOoo :
  if oOo == 1 :
   O0oOOo0o = name
   if 50 - 50: i1iIIIiI1I . i11iiII . oo * oo0Ooo0 + i1111 % i11iIiiIii
  OOooo00 = 0
  if 8 - 8: iiIIiIiIi * oooO0oo0oOOOO
  for iiII in II1I1I1Ii :
   if 73 - 73: oo0ooO0oOOOOo / OooooO0oOO / oo0Ooo0 / oo
   if not iiII . lower ( ) in name . lower ( ) :
    OOooo00 = 1
    if 11 - 11: OOO0O + OoO000 - i111I / oo
  if OOooo00 == 0 :
   iiIIiiIi1Ii11 = iiIIiiIi1Ii11 + 1
   if oOo == 1 :
    if "hd" in name . lower ( ) :
     Iiii ( '[COLOR blue] ' + str ( O0oOOo0o ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     Iiii ( '[COLOR blue] ' + str ( O0oOOo0o ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     Iiii ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iiIIiiIi1Ii11 ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     Iiii ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iiIIiiIi1Ii11 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 34 - 34: iiIIiIiIi
 if iiIIiiIi1Ii11 == 0 :
  Iiii ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 45 - 45: iiIIiIiIi / I11i1i11i1I / i1IIiiiii
 I1IiiI . close ( )
 if 44 - 44: i11iiII - i1IIiiiii / i1111 * oo * I11i1i11i1I
def OO0ooo0o0 ( term ) :
 if 69 - 69: i11iiII - OooOoO0Oo
 ooO0oooOO0 = [ ]
 o0o = [ ]
 if 16 - 16: I11i1i11i1I
 Iiii1iI1i = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Iiii1iI1i )
 for Oo0OoO00oOO0o in Oo0oOOo :
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  II11i1I11Ii1i = Oo0OoO00oOO0o
  if 14 - 14: II1Ii1iI1i - oooO0oo0oOOOO % I11i1i11i1I
  II11i1I11Ii1i = II11i1I11Ii1i . replace ( '#AAASTREAM:' , '#A:' )
  II11i1I11Ii1i = II11i1I11Ii1i . replace ( '#EXTINF:' , '#A:' )
  OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( II11i1I11Ii1i )
  iIIIIIiI1I1 = [ ]
  for I11I1IIiiII1 , IIIIIii1ii11 , II11i1I11Ii1i in OO0O0o0o0 :
   OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : II11i1I11Ii1i }
   iIIIIIiI1I1 . append ( OOOooo0OooOoO )
  list = [ ]
  for o00ooO00O in iIIIIIiI1I1 :
   OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
   OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
   for oOoOOOo , ii1I in OO0O0o0o0 :
    OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
   list . append ( OOOooo0OooOoO )
   if 92 - 92: i1IIiiiii % i1iIIIiI1I / i11iiII % i11iiII * i1IIi11111i
  for o00ooO00O in list :
   OoOO0oo0o = oo0oooOo ( o00ooO00O [ "display_name" ] )
   II11i1I11Ii1i = oo0oooOo ( o00ooO00O [ "url" ] )
   II11i1I11Ii1i = II11i1I11Ii1i . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in OoOO0oo0o . lower ( ) :
    ooO0oooOO0 . append ( II11i1I11Ii1i )
    o0o . append ( OoOO0oo0o )
    if 74 - 74: oooO0oo0oOOOO . i1IIi11111i % oo % OoO000
 O00ooooo00 = xbmcgui . Dialog ( )
 II = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , o0o )
 if II < 0 :
  quit ( )
  if 87 - 87: OooooO0oOO - i11iIiiIii
 II11i1I11Ii1i = ooO0oooOO0 [ II ]
 OoOO0oo0o = o0o [ II ]
 OOoOO0ooo ( OoOO0oo0o , II11i1I11Ii1i , iiiii )
 if 78 - 78: i11iIiiIii / ooO0oo0oO0 - oo0ooO0oOOOOo
def iIIIIiiIii ( name , url , iconimage ) :
 if 58 - 58: I11i1i11i1I
 list = IiiIIIiI1ii ( url )
 if 78 - 78: oooO0oo0oOOOO * oOo0
 iIii1 = 0
 Oooo = open ( iI1Ii11111iIi , mode = 'r' ) ; Ooo0oO0 = Oooo . read ( ) ; Oooo . close ( )
 Ooo0oO0 = Ooo0oO0 . replace ( '\n' , '' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( Ooo0oO0 )
 ooOoO0 = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 86 - 86: oooO0oo0oOOOO
  O0o0oOooOoOo = re . compile ( '<url>(.+?)</url>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  if 49 - 49: oOo0 . i11iiII . i11iIiiIii - i1111 / i1IIiiiii
  if url == O0o0oOooOoOo :
   iIii1 = 1
   if 62 - 62: oOo0
 for o00ooO00O in list :
  name = oo0oooOo ( o00ooO00O [ "display_name" ] )
  url = oo0oooOo ( o00ooO00O [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if iIii1 == 1 :
   if 1 - 1: OoO000 / OoO000 - i11iIiiIii
   Oooo = open ( i1i1II , mode = 'r' ) ; Ooo0oO0 = Oooo . read ( ) ; Oooo . close ( )
   Ooo0oO0 = Ooo0oO0 . replace ( '\n' , '' )
   Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( Ooo0oO0 )
   for Oo0OoO00oOO0o in Oo0oOOo :
    if 87 - 87: I11i1i11i1I / oooO0oo0oOOOO * OoO000 / oo0ooO0oOOOOo
    I1iiIII = re . compile ( '<name>(.+?)</name>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    if 16 - 16: OooooO0oOO + iiIIiIiIi / oo0ooO0oOOOOo
    O00oOoo0OoO0 = I1iiIII . replace ( ' ' , '' )
    Ooo0 = name . replace ( ' ' , '' )
    if O00oOoo0OoO0 . lower ( ) in Ooo0 . lower ( ) :
     if 91 - 91: II1Ii1iI1i - ooO0oo0oO0
     Oooo = open ( O0oo0OO0 , mode = 'r' ) ; Ooo0oO0 = Oooo . read ( ) ; Oooo . close ( )
     Ooo0oO0 = Ooo0oO0 . replace ( '\n' , '' )
     Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( Ooo0oO0 )
     for Oo0OoO00oOO0o in Oo0oOOo :
      if 55 - 55: i1IIi11111i * oo0ooO0oOOOOo % iiIIiIiIi . ooO0oo0oO0 * OooOoO0Oo
      o0oo0000 = re . compile ( '<replace>(.+?)</replace>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
      if 42 - 42: OooOoO0Oo + OooOoO0Oo * i1111
      name = name . lower ( ) . replace ( o0oo0000 , '' )
      if 78 - 78: i111I
     Iiii ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 77 - 77: i11iiII / II1Ii1iI1i / I11i1i11i1I % oOo0
  else : Iiii ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 48 - 48: oo0Ooo0 - OoO000 + ooO0oo0oO0 + i111I
def IiiIIIiI1ii ( url ) :
 if 4 - 4: i1111 . oo0Ooo0 + i1IIiiiii * OooOoO0Oo . iiIIiIiIi
 oOoOo = Oo0O0O0ooO0O ( url )
 oOoOo = oOoOo . replace ( '#AAASTREAM:' , '#A:' )
 oOoOo = oOoOo . replace ( '#EXTINF:' , '#A:' )
 OO0O0o0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( oOoOo )
 iIIIIIiI1I1 = [ ]
 for I11I1IIiiII1 , IIIIIii1ii11 , url in OO0O0o0o0 :
  OOOooo0OooOoO = { "params" : I11I1IIiiII1 , "display_name" : IIIIIii1ii11 , "url" : url }
  iIIIIIiI1I1 . append ( OOOooo0OooOoO )
 list = [ ]
 for o00ooO00O in iIIIIIiI1I1 :
  OOOooo0OooOoO = { "display_name" : o00ooO00O [ "display_name" ] , "url" : o00ooO00O [ "url" ] }
  OO0O0o0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o00ooO00O [ "params" ] )
  for oOoOOOo , ii1I in OO0O0o0o0 :
   OOOooo0OooOoO [ oOoOOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
  list . append ( OOOooo0OooOoO )
  if 74 - 74: OooooO0oOO / i11iiII % oo0ooO0oOOOOo
 return list
 if 88 - 88: OOO0O - i11iIiiIii % oo0ooO0oOOOOo * oo0Ooo0 + i11iiII
 if 52 - 52: i1111 . i1IIi11111i + OOO0O % oo
def oo0O0o00 ( ) :
 if 70 - 70: oo
 oo0oOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 oo0oOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 46 - 46: oo0Ooo0 - II1Ii1iI1i
def i111iiIIII ( name , url , iconimage ) :
 if 80 - 80: I11i1i11i1I * i1IIiiiii + i11iiII * oOo0
 I1Ii = datetime . datetime . now ( )
 Ii111iIi1iIi = I1Ii . day
 if 77 - 77: ooO0oo0oO0 - II1Ii1iI1i . OooooO0oOO
 iIi1iIIIiIiI = Ii111iIi1iIi
 if 62 - 62: i11iIiiIii % oOo0 . OoO000 . oOo0
 ooOo0O0O0oOO0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIiIIi = datetime . datetime . strftime ( ooOo0O0O0oOO0 , '%A - %d %B %Y' )
 III1I = 'http://www.predictz.com/predictions/'
 if 11 - 11: iiIIiIiIi - oOo0 + iiIIiIiIi * OooooO0oOO / i1IIi11111i
 OoOOOO = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1iiIi111I = datetime . datetime . strftime ( OoOOOO , '%A - %d %B %Y' )
 Iiii1iIii = datetime . datetime . strftime ( OoOOOO , '%d' )
 oOoooO000O = 'http://www.predictz.com/predictions/tomorrow/'
 if 49 - 49: oo0ooO0oOOOOo * i1IIiiiii + oo0Ooo0 + i1iIIIiI1I
 IIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooo0O0OOO000o = datetime . datetime . strftime ( IIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iiI1iii = datetime . datetime . strftime ( IIi11 , '%y%m%d' )
 OOoOOo00O0o0 = 'http://www.predictz.com/predictions/20' + str ( iiI1iii )
 if 83 - 83: ooO0oo0oO0 % OOO0O % oo0ooO0oOOOOo % OooOoO0Oo . i11iiII % oooO0oo0oOOOO
 iIiIi1ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iiiiiII = datetime . datetime . strftime ( iIiIi1ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii1ii = datetime . datetime . strftime ( iIiIi1ii , '%y%m%d' )
 IIiI1i = 'http://www.predictz.com/predictions/20' + str ( ii1ii )
 if 6 - 6: i11iiII / i1iIIIiI1I - oOo0
 o00O00Oo00O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IIii1I1I1I = datetime . datetime . strftime ( o00O00Oo00O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoOOOo0 = datetime . datetime . strftime ( o00O00Oo00O , '%y%m%d' )
 o00IIIIII1II1I = 'http://www.predictz.com/predictions/20' + str ( OoOOOo0 )
 if 79 - 79: oo0ooO0oOOOOo % oOo0 / oooO0oo0oOOOO
 if 94 - 94: i11iiII + i11iiII + i111I % iiIIiIiIi
 oo0oOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIiIIi ) + '[/B][/COLOR]' , III1I , 41 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1iiIi111I ) + '[/B][/COLOR]' , oOoooO000O , 41 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( ooo0O0OOO000o ) , OOoOOo00O0o0 , 41 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( iiiiiII ) , IIiI1i , 41 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( IIii1I1I1I ) , o00IIIIII1II1I , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 7 - 7: i1iIIIiI1I
def oOo000O ( name , url , iconimage ) :
 if 1 - 1: ooO0oo0oO0
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 II1I1I1Ii = str ( Oo0oOOo )
 i1iI1 = re . compile ( '<tr(.+?)</tr>' ) . findall ( II1I1I1Ii )
 for Oo0OoO00oOO0o in i1iI1 :
  try :
   Ii = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR red][B]' + Ii + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   I1ii1ii11i1I = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oo0oO0o0 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I1ii1ii11i1I = Iii1Ii ( I1ii1ii11i1I )
   oo0oO0o0 = Iii1Ii ( oo0oO0o0 )
   Iiii ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + oo0oO0o0 + ' [/B][/COLOR]| [COLOR mediumpurple]' + I1ii1ii11i1I + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 30 - 30: oooO0oo0oOOOO - i1iIIIiI1I % I11i1i11i1I
def O0Oo ( name , url , iconimage ) :
 if 39 - 39: oOo0 - i111I + I11i1i11i1I
 I1Ii = datetime . datetime . now ( )
 Ii111iIi1iIi = I1Ii . day
 if 93 - 93: iiIIiIiIi . ooO0oo0oO0 % i11iIiiIii . OOO0O % iiIIiIiIi + oooO0oo0oOOOO
 iIi1iIIIiIiI = Ii111iIi1iIi
 if 65 - 65: i1IIiiiii + oo - i111I
 ooOo0O0O0oOO0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIiIIi = datetime . datetime . strftime ( ooOo0O0O0oOO0 , '%A - %d %B %Y' )
 III1I = 'http://www.predictz.com/predictions/'
 if 51 - 51: I11i1i11i1I + OooooO0oOO / i1iIIIiI1I - II1Ii1iI1i
 OoOOOO = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1iiIi111I = datetime . datetime . strftime ( OoOOOO , '%A - %d %B %Y' )
 Iiii1iIii = datetime . datetime . strftime ( OoOOOO , '%d' )
 oOoooO000O = 'http://www.predictz.com/predictions/tomorrow/'
 if 51 - 51: I11i1i11i1I - i11iiII * oo0Ooo0
 IIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooo0O0OOO000o = datetime . datetime . strftime ( IIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iiI1iii = datetime . datetime . strftime ( IIi11 , '%y%m%d' )
 OOoOOo00O0o0 = 'http://www.predictz.com/predictions/20' + str ( iiI1iii )
 if 12 - 12: ooO0oo0oO0 % iiIIiIiIi % iiIIiIiIi
 iIiIi1ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iiiiiII = datetime . datetime . strftime ( iIiIi1ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii1ii = datetime . datetime . strftime ( iIiIi1ii , '%y%m%d' )
 IIiI1i = 'http://www.predictz.com/predictions/20' + str ( ii1ii )
 if 78 - 78: OoO000 . OOO0O . oo0Ooo0
 o00O00Oo00O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IIii1I1I1I = datetime . datetime . strftime ( o00O00Oo00O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoOOOo0 = datetime . datetime . strftime ( o00O00Oo00O , '%y%m%d' )
 o00IIIIII1II1I = 'http://www.predictz.com/predictions/20' + str ( OoOOOo0 )
 if 97 - 97: OooooO0oOO
 if 80 - 80: i1IIi11111i . i1IIiiiii
 oo0oOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIiIIi ) + '[/B][/COLOR]' , III1I , 51 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1iiIi111I ) + '[/B][/COLOR]' , oOoooO000O , 51 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( ooo0O0OOO000o ) , OOoOOo00O0o0 , 51 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( iiiiiII ) , IIiI1i , 51 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( IIii1I1I1I ) , o00IIIIII1II1I , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 47 - 47: oo0Ooo0 + iiIIiIiIi + i1111 % i11iIiiIii
def OOoOoo00Oo ( name , url , iconimage ) :
 if 9 - 9: i1111 * i1111 . i11iIiiIii * ooO0oo0oO0
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 II1I1I1Ii = str ( Oo0oOOo )
 i1iI1 = re . compile ( '<tr(.+?)</tr>' ) . findall ( II1I1I1Ii )
 for Oo0OoO00oOO0o in i1iI1 :
  try :
   Ii = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR red][B]' + Ii + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   I1ii1ii11i1I = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II1I11Iii1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1iIIi1II1iiI = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   III1Ii1i1I1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   I1ii1ii11i1I = Iii1Ii ( I1ii1ii11i1I )
   Iiii ( '[COLOR mediumpurple][B]' + I1ii1ii11i1I + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + II1I11Iii1 + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + i1iIIi1II1iiI + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + III1Ii1i1I1 + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 97 - 97: OooOoO0Oo . iiIIiIiIi - OooOoO0Oo + i1IIi11111i * i1111
def I111Ii ( name , url , iconimage ) :
 if 34 - 34: oo0ooO0oOOOOo / i1iIIIiI1I % oooO0oo0oOOOO . oo . II1Ii1iI1i
 I1Ii = datetime . datetime . now ( )
 Ii111iIi1iIi = I1Ii . day
 if 29 - 29: oooO0oo0oOOOO . OooOoO0Oo
 iIi1iIIIiIiI = Ii111iIi1iIi
 if 66 - 66: OooooO0oOO * ooO0oo0oO0 % ooO0oo0oO0 * OoO000 - iiIIiIiIi - OoO000
 ooOo0O0O0oOO0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIiIIi = datetime . datetime . strftime ( ooOo0O0O0oOO0 , '%A - %d %B %Y' )
 III1I = 'http://www.predictz.com/predictions/'
 if 70 - 70: OooOoO0Oo + OooooO0oOO
 OoOOOO = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1iiIi111I = datetime . datetime . strftime ( OoOOOO , '%A - %d %B %Y' )
 Iiii1iIii = datetime . datetime . strftime ( OoOOOO , '%d' )
 oOoooO000O = 'http://www.predictz.com/predictions/tomorrow/'
 if 93 - 93: OooOoO0Oo + i1IIiiiii
 IIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooo0O0OOO000o = datetime . datetime . strftime ( IIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iiI1iii = datetime . datetime . strftime ( IIi11 , '%y%m%d' )
 OOoOOo00O0o0 = 'http://www.predictz.com/predictions/20' + str ( iiI1iii )
 if 33 - 33: oooO0oo0oOOOO
 iIiIi1ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iiiiiII = datetime . datetime . strftime ( iIiIi1ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii1ii = datetime . datetime . strftime ( iIiIi1ii , '%y%m%d' )
 IIiI1i = 'http://www.predictz.com/predictions/20' + str ( ii1ii )
 if 78 - 78: oooO0oo0oOOOO / i1111 * oo
 o00O00Oo00O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IIii1I1I1I = datetime . datetime . strftime ( o00O00Oo00O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoOOOo0 = datetime . datetime . strftime ( o00O00Oo00O , '%y%m%d' )
 o00IIIIII1II1I = 'http://www.predictz.com/predictions/20' + str ( OoOOOo0 )
 if 50 - 50: i111I - ooO0oo0oO0 + II1Ii1iI1i % OooOoO0Oo - ooO0oo0oO0 % oooO0oo0oOOOO
 if 58 - 58: OoO000 + ooO0oo0oO0
 oo0oOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIiIIi ) + '[/B][/COLOR]' , III1I , 61 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1iiIi111I ) + '[/B][/COLOR]' , oOoooO000O , 61 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( ooo0O0OOO000o ) , OOoOOo00O0o0 , 61 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( iiiiiII ) , IIiI1i , 61 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( IIii1I1I1I ) , o00IIIIII1II1I , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 65 - 65: i1111 - OooOoO0Oo % oo0ooO0oOOOOo - OOO0O * i1iIIIiI1I + i1IIiiiii
def O0o0O0OO0o ( name , url , iconimage ) :
 if 54 - 54: OOO0O . OooooO0oOO % i11iIiiIii / i111I + OoO000 % OooooO0oOO
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 II1I1I1Ii = str ( Oo0oOOo )
 i1iI1 = re . compile ( '<tr(.+?)</tr>' ) . findall ( II1I1I1Ii )
 for Oo0OoO00oOO0o in i1iI1 :
  try :
   Ii = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR red][B]' + Ii + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   I1ii1ii11i1I = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIIiiIi1Ii11 , Oo0 = I1ii1ii11i1I . split ( ' v ' )
   i1ii1IIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II1ii1ii11I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   o0ooOO0o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   ooo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 3 ]
   i1iI1i1I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 4 ]
   O0Oo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 5 ]
   OOooO0OO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 6 ]
   iI1iIiiiI1I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 7 ]
   OOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 8 ]
   OoI1IiiiIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 9 ]
   if 77 - 77: i1IIiiiii / i1111 - i1IIiiiii / oOo0
   if i1ii1IIiI == "W" :
    i1ii1IIiI = '[COLOR lime]W[/COLOR]'
   elif i1ii1IIiI == "D" :
    i1ii1IIiI = '[COLOR yellow]D[/COLOR]'
   else : i1ii1IIiI = '[COLOR red]L[/COLOR]'
   if 97 - 97: oOo0 / OooooO0oOO . i1111
   if II1ii1ii11I1 == "W" :
    II1ii1ii11I1 = '[COLOR lime]W[/COLOR]'
   elif II1ii1ii11I1 == "D" :
    II1ii1ii11I1 = '[COLOR yellow]D[/COLOR]'
   else : II1ii1ii11I1 = '[COLOR red]L[/COLOR]'
   if 44 - 44: i1IIiiiii % oo0Ooo0 . OooOoO0Oo
   if o0ooOO0o == "W" :
    o0ooOO0o = '[COLOR lime]W[/COLOR]'
   elif o0ooOO0o == "D" :
    o0ooOO0o = '[COLOR yellow]D[/COLOR]'
   else : o0ooOO0o = '[COLOR red]L[/COLOR]'
   if 18 - 18: ooO0oo0oO0 + oo0Ooo0 * i1IIi11111i - oOo0 / i1IIi11111i
   if ooo0 == "W" :
    ooo0 = '[COLOR lime]W[/COLOR]'
   elif ooo0 == "D" :
    ooo0 = '[COLOR yellow]D[/COLOR]'
   else : ooo0 = '[COLOR red]L[/COLOR]'
   if 78 - 78: oo0Ooo0 . OoO000
   if i1iI1i1I1 == "W" :
    i1iI1i1I1 = '[COLOR lime]W[/COLOR]'
   elif i1iI1i1I1 == "D" :
    i1iI1i1I1 = '[COLOR yellow]D[/COLOR]'
   else : i1iI1i1I1 = '[COLOR red]L[/COLOR]'
   if 38 - 38: OOO0O + OoO000
   if O0Oo0 == "W" :
    O0Oo0 = '[COLOR lime]W[/COLOR]'
   elif O0Oo0 == "D" :
    O0Oo0 = '[COLOR yellow]D[/COLOR]'
   else : O0Oo0 = '[COLOR red]L[/COLOR]'
   if 15 - 15: I11i1i11i1I + oo0Ooo0 . iiIIiIiIi - ooO0oo0oO0 / oooO0oo0oOOOO % ooO0oo0oO0
   if OOooO0OO0 == "W" :
    OOooO0OO0 = '[COLOR lime]W[/COLOR]'
   elif OOooO0OO0 == "D" :
    OOooO0OO0 = '[COLOR yellow]D[/COLOR]'
   else : OOooO0OO0 = '[COLOR red]L[/COLOR]'
   if 86 - 86: i1IIi11111i / OooooO0oOO * i1IIiiiii
   if iI1iIiiiI1I1 == "W" :
    iI1iIiiiI1I1 = '[COLOR lime]W[/COLOR]'
   elif iI1iIiiiI1I1 == "D" :
    iI1iIiiiI1I1 = '[COLOR yellow]D[/COLOR]'
   else : iI1iIiiiI1I1 = '[COLOR red]L[/COLOR]'
   if 64 - 64: iiIIiIiIi / oooO0oo0oOOOO * OOO0O * iiIIiIiIi
   if OOOO == "W" :
    OOOO = '[COLOR lime]W[/COLOR]'
   elif OOOO == "D" :
    OOOO = '[COLOR yellow]D[/COLOR]'
   else : OOOO = '[COLOR red]L[/COLOR]'
   if 60 - 60: oo0Ooo0 / II1Ii1iI1i % i11iiII / i11iiII * i11iiII . i11iIiiIii
   if OoI1IiiiIiI == "W" :
    OoI1IiiiIiI = '[COLOR lime]W[/COLOR]'
   elif OoI1IiiiIiI == "D" :
    OoI1IiiiIiI = '[COLOR yellow]D[/COLOR]'
   else : OoI1IiiiIiI = '[COLOR red]L[/COLOR]'
   if 99 - 99: OOO0O
   iiIIiiIi1Ii11 = Iii1Ii ( iiIIiiIi1Ii11 )
   Oo0 = Iii1Ii ( Oo0 )
   Iiii ( '[COLOR mediumpurple][B]' + iiIIiiIi1Ii11 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[B]' + i1ii1IIiI + '  ' + II1ii1ii11I1 + '  ' + o0ooOO0o + '  ' + ooo0 + '  ' + i1iI1i1I1 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR mediumpurple][B]' + Oo0 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[B]' + O0Oo0 + '  ' + OOooO0OO0 + '  ' + iI1iIiiiI1I1 + '  ' + OOOO + '  ' + OoI1IiiiIiI + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 77 - 77: oo0ooO0oOOOOo
def IIiIi11iiIi ( name , url , iconimage ) :
 if 48 - 48: OoO000 % oo0Ooo0
 I1Ii = datetime . datetime . now ( )
 Ii111iIi1iIi = I1Ii . day
 if 3 - 3: OoO000 % i1IIiiiii + I11i1i11i1I
 iIi1iIIIiIiI = Ii111iIi1iIi
 if 47 - 47: oooO0oo0oOOOO * i1IIi11111i * oo . i1111
 ooOo0O0O0oOO0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIiIIi = datetime . datetime . strftime ( ooOo0O0O0oOO0 , '%A - %d %B %Y' )
 III1I = 'http://www.predictz.com/predictions/'
 if 95 - 95: i1IIiiiii % OoO000 . oooO0oo0oOOOO % OooOoO0Oo
 OoOOOO = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1iiIi111I = datetime . datetime . strftime ( OoOOOO , '%A - %d %B %Y' )
 Iiii1iIii = datetime . datetime . strftime ( OoOOOO , '%d' )
 oOoooO000O = 'http://www.predictz.com/predictions/tomorrow/'
 if 68 - 68: I11i1i11i1I . I11i1i11i1I - i11iiII / oo0Ooo0 . iiIIiIiIi / II1Ii1iI1i
 IIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooo0O0OOO000o = datetime . datetime . strftime ( IIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iiI1iii = datetime . datetime . strftime ( IIi11 , '%y%m%d' )
 OOoOOo00O0o0 = 'http://www.predictz.com/predictions/20' + str ( iiI1iii )
 if 12 - 12: i11iiII * II1Ii1iI1i * oo0Ooo0
 iIiIi1ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iiiiiII = datetime . datetime . strftime ( iIiIi1ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii1ii = datetime . datetime . strftime ( iIiIi1ii , '%y%m%d' )
 IIiI1i = 'http://www.predictz.com/predictions/20' + str ( ii1ii )
 if 23 - 23: oOo0 / oooO0oo0oOOOO / i1IIi11111i
 o00O00Oo00O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 IIii1I1I1I = datetime . datetime . strftime ( o00O00Oo00O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OoOOOo0 = datetime . datetime . strftime ( o00O00Oo00O , '%y%m%d' )
 o00IIIIII1II1I = 'http://www.predictz.com/predictions/20' + str ( OoOOOo0 )
 if 49 - 49: oo0Ooo0 . oo0ooO0oOOOOo % OooooO0oOO / i1IIiiiii
 if 95 - 95: oooO0oo0oOOOO * OOO0O * OoO000 . iiIIiIiIi / ooO0oo0oO0
 oo0oOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIiIIi ) + '[/B][/COLOR]' , III1I , 71 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1iiIi111I ) + '[/B][/COLOR]' , oOoooO000O , 71 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( ooo0O0OOO000o ) , OOoOOo00O0o0 , 71 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( iiiiiII ) , IIiI1i , 71 , iiiii , O0O0OO0O0O0 , '' )
 oo0oOo ( str ( IIii1I1I1I ) , o00IIIIII1II1I , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 28 - 28: OoO000 + OooooO0oOO - iiIIiIiIi / ooO0oo0oO0 - i1IIi11111i
def Ii1i1 ( name , url , iconimage ) :
 if 65 - 65: OooooO0oOO + i11iiII / oOo0
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 II1I1I1Ii = str ( Oo0oOOo )
 i1iI1 = re . compile ( '<tr(.+?)</tr>' ) . findall ( II1I1I1Ii )
 for Oo0OoO00oOO0o in i1iI1 :
  try :
   Ii = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR red][B]' + Ii + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   I1ii1ii11i1I = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIIiiIi1Ii11 , Oo0 = I1ii1ii11i1I . split ( ' v ' )
   if 85 - 85: ooO0oo0oO0 / i111I % i1111
   oo0oO0o0 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II1I11Iii1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1iIIi1II1iiI = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   III1Ii1i1I1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   i1ii1IIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II1ii1ii11I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   o0ooOO0o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   ooo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 3 ]
   i1iI1i1I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 4 ]
   O0Oo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 5 ]
   OOooO0OO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 6 ]
   iI1iIiiiI1I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 7 ]
   OOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 8 ]
   OoI1IiiiIiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 9 ]
   if 49 - 49: i11iIiiIii % OOO0O + OooOoO0Oo . i1111 % i1iIIIiI1I * oOo0
   if i1ii1IIiI == "W" :
    i1ii1IIiI = '[COLOR lime]W[/COLOR]'
   elif i1ii1IIiI == "D" :
    i1ii1IIiI = '[COLOR yellow]D[/COLOR]'
   else : i1ii1IIiI = '[COLOR red]L[/COLOR]'
   if 67 - 67: II1Ii1iI1i
   if II1ii1ii11I1 == "W" :
    II1ii1ii11I1 = '[COLOR lime]W[/COLOR]'
   elif II1ii1ii11I1 == "D" :
    II1ii1ii11I1 = '[COLOR yellow]D[/COLOR]'
   else : II1ii1ii11I1 = '[COLOR red]L[/COLOR]'
   if 5 - 5: i1111 . i111I
   if o0ooOO0o == "W" :
    o0ooOO0o = '[COLOR lime]W[/COLOR]'
   elif o0ooOO0o == "D" :
    o0ooOO0o = '[COLOR yellow]D[/COLOR]'
   else : o0ooOO0o = '[COLOR red]L[/COLOR]'
   if 57 - 57: i1IIi11111i
   if ooo0 == "W" :
    ooo0 = '[COLOR lime]W[/COLOR]'
   elif ooo0 == "D" :
    ooo0 = '[COLOR yellow]D[/COLOR]'
   else : ooo0 = '[COLOR red]L[/COLOR]'
   if 35 - 35: i111I - OooOoO0Oo / oo
   if i1iI1i1I1 == "W" :
    i1iI1i1I1 = '[COLOR lime]W[/COLOR]'
   elif i1iI1i1I1 == "D" :
    i1iI1i1I1 = '[COLOR yellow]D[/COLOR]'
   else : i1iI1i1I1 = '[COLOR red]L[/COLOR]'
   if 50 - 50: OOO0O
   if O0Oo0 == "W" :
    O0Oo0 = '[COLOR lime]W[/COLOR]'
   elif O0Oo0 == "D" :
    O0Oo0 = '[COLOR yellow]D[/COLOR]'
   else : O0Oo0 = '[COLOR red]L[/COLOR]'
   if 33 - 33: oo0Ooo0
   if OOooO0OO0 == "W" :
    OOooO0OO0 = '[COLOR lime]W[/COLOR]'
   elif OOooO0OO0 == "D" :
    OOooO0OO0 = '[COLOR yellow]D[/COLOR]'
   else : OOooO0OO0 = '[COLOR red]L[/COLOR]'
   if 98 - 98: OOO0O % i1111
   if iI1iIiiiI1I1 == "W" :
    iI1iIiiiI1I1 = '[COLOR lime]W[/COLOR]'
   elif iI1iIiiiI1I1 == "D" :
    iI1iIiiiI1I1 = '[COLOR yellow]D[/COLOR]'
   else : iI1iIiiiI1I1 = '[COLOR red]L[/COLOR]'
   if 95 - 95: ooO0oo0oO0 - OooOoO0Oo - oOo0 + OooOoO0Oo % i11iiII . i1IIi11111i
   if OOOO == "W" :
    OOOO = '[COLOR lime]W[/COLOR]'
   elif OOOO == "D" :
    OOOO = '[COLOR yellow]D[/COLOR]'
   else : OOOO = '[COLOR red]L[/COLOR]'
   if 41 - 41: oooO0oo0oOOOO + OooooO0oOO . II1Ii1iI1i - i1111 * oo0ooO0oOOOOo . oo
   if OoI1IiiiIiI == "W" :
    OoI1IiiiIiI = '[COLOR lime]W[/COLOR]'
   elif OoI1IiiiIiI == "D" :
    OoI1IiiiIiI = '[COLOR yellow]D[/COLOR]'
   else : OoI1IiiiIiI = '[COLOR red]L[/COLOR]'
   if 68 - 68: oo0ooO0oOOOOo
   iiIIiiIi1Ii11 = Iii1Ii ( iiIIiiIi1Ii11 )
   Oo0 = Iii1Ii ( Oo0 )
   I1ii1ii11i1I = Iii1Ii ( I1ii1ii11i1I )
   oo0oO0o0 = Iii1Ii ( oo0oO0o0 )
   Iiii ( '[COLOR blue][B]' + I1ii1ii11i1I + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + oo0oO0o0 + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR orange]' + iiIIiiIi1Ii11 + ' Form: - [/COLOR][B]' + i1ii1IIiI + '  ' + II1ii1ii11I1 + '  ' + o0ooOO0o + '  ' + ooo0 + '  ' + i1iI1i1I1 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR orange]' + Oo0 + ' Form - [/COLOR][B]' + O0Oo0 + '  ' + OOooO0OO0 + '  ' + iI1iIiiiI1I1 + '  ' + OOOO + '  ' + OoI1IiiiIiI + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR orange]' + iiIIiiIi1Ii11 + ' Win[/COLOR][COLOR dodgerblue][B] (' + II1I11Iii1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + i1iIIi1II1iiI + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '[COLOR orange]' + Oo0 + ' Win[/COLOR][COLOR dodgerblue][B] (' + III1Ii1i1I1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Iiii ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 20 - 20: OooOoO0Oo - OooOoO0Oo
  except : pass
  if 37 - 37: OoO000
def iI11i ( name , url , iconimage ) :
 if 73 - 73: i1iIIIiI1I * i1iIIIiI1I / iiIIiIiIi
 IIi = [ ]
 i1i11iI1II11 = [ ]
 iIi11i = [ ]
 ooIII1II1iii1i = [ ]
 O0OO0oOO = [ ]
 if 85 - 85: oooO0oo0oOOOO
 iII = o0 ( 'http://www.livescores.com' )
 Oo0oOOo = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( iII )
 II1I1I1Ii = str ( Oo0oOOo )
 i1iI1 = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( II1I1I1Ii )
 for Oo0OoO00oOO0o in i1iI1 :
  Iii = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  IiI1I1 = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   oo0oO0o0 = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except :
   oo0oO0o0 = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 19 - 19: i1IIiiiii
  if "minute" in time . lower ( ) :
   O0OO0oOO . append ( '3' )
  elif "ht" in time . lower ( ) :
   O0OO0oOO . append ( '3' )
  elif "ft" in time . lower ( ) :
   O0OO0oOO . append ( '2' )
  else : O0OO0oOO . append ( '1' )
  if 55 - 55: oOo0 % oOo0 / oooO0oo0oOOOO % i1iIIIiI1I - oo0ooO0oOOOOo . I11i1i11i1I
  IIi . append ( Iii )
  i1i11iI1II11 . append ( IiI1I1 )
  iIi11i . append ( oo0oO0o0 )
  ooIII1II1iii1i . append ( time )
  oO = list ( zip ( O0OO0oOO , IIi , i1i11iI1II11 , iIi11i , ooIII1II1iii1i ) )
  if 49 - 49: ooO0oo0oO0 * II1Ii1iI1i . i111I
 Iiii ( '[COLOR dodgerblue][B]The scores will update every 10 seconds.[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 Iiii ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 90 - 90: oo0ooO0oOOOOo % i11iiII - ooO0oo0oO0 % OOO0O
 OOoo = sorted ( oO , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 IIiI11I1I1i1i = 0
 oooo = 0
 O0o0O = 0
 for ii111 , ooOo000OoO0o , ooooo0O0 , i1III1iI , ii1i in OOoo :
  if ii111 == "3" :
   if IIiI11I1I1i1i == 0 :
    Iiii ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    IIiI11I1I1i1i = 1
  elif ii111 == "2" :
   if oooo == 0 :
    Iiii ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    oooo = 1
  elif ii111 == "1" :
   if O0o0O == 0 :
    Iiii ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    O0o0O = 1
  ii1i = ii1i . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  i1III1iI = i1III1iI . replace ( " " , "" )
  Iiii ( '[COLOR red][B]' + ii1i + "[/B][/COLOR]- [COLOR blue]" + i1III1iI + "[/COLOR] | [COLOR white]" + ooOo000OoO0o + "vs" + ooooo0O0 + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 12 - 12: i1IIiiiii
def Ooii1IIi1ii ( ) :
 if 85 - 85: i111I % OOO0O * ooO0oo0oO0
 II1I1I1Ii = ''
 I1i11i = xbmc . Keyboard ( II1I1I1Ii , 'Enter Search Term' )
 I1i11i . doModal ( )
 if I1i11i . isConfirmed ( ) :
  II1I1I1Ii = I1i11i . getText ( )
  if len ( II1I1I1Ii ) > 1 :
   II11i1I11Ii1i = II1I1I1Ii + "!" + iiiii
   Ii1iIi111i1i1 ( "all " + II1I1I1Ii , II11i1I11Ii1i , iiiii )
  else : quit ( )
  if 44 - 44: ooO0oo0oO0 . i11iiII + OooOoO0Oo . iiIIiIiIi
def II1i11 ( name , url , iconimage ) :
 if 28 - 28: i1111 - OooooO0oOO % OOO0O + oo - OOO0O
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 28 - 28: i1111 . OooooO0oOO + oooO0oo0oOOOO . oooO0oo0oOOOO . oOo0
def oOOo00O0OOOo ( text ) :
 if 98 - 98: i111I % oooO0oo0oOOOO - oooO0oo0oOOOO
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 76 - 76: II1Ii1iI1i % OOO0O - i1IIi11111i / oo0ooO0oOOOOo * iiIIiIiIi
 return text
 if 4 - 4: I11i1i11i1I * I11i1i11i1I / OOO0O
def Iii1Ii ( text ) :
 if 4 - 4: i1IIi11111i * OOO0O % oo0Ooo0 . OOO0O
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 11 - 11: oOo0 - OOO0O - oo0ooO0oOOOOo * OOO0O + iiIIiIiIi
 return text
 if 62 - 62: i1IIi11111i * i11iIiiIii . i1iIIIiI1I
def OooO0oOo ( text ) :
 if 35 - 35: OoO000 . oooO0oo0oOOOO + I11i1i11i1I + oOo0 + II1Ii1iI1i
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 65 - 65: oooO0oo0oOOOO * i1IIi11111i / i1IIi11111i . OOO0O
 return text
 if 87 - 87: i1111 * i11iiII % I11i1i11i1I * I11i1i11i1I
def OOoOO0ooo ( name , url , iconimage ) :
 if 58 - 58: oOo0 . oo0ooO0oOOOOo + i1IIi11111i % I11i1i11i1I - oo
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]Opening link...[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 50 - 50: i1iIIIiI1I % i1111 - iiIIiIiIi . II1Ii1iI1i + oooO0oo0oOOOO % i1iIIIiI1I
 if "pl_type=user" in url :
  Iiii1iI1i = o0 ( url )
  url = re . compile ( '<meta property="og:video:iframe" content="(.+?)">' ) . findall ( Iiii1iI1i ) [ 0 ]
  if 10 - 10: i1iIIIiI1I . II1Ii1iI1i + i1IIiiiii
 if not "plugin" in url :
  try :
   if not 'http' in url : url = 'http://' + url
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 66 - 66: oo % oo0ooO0oOOOOo
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 21 - 21: OOO0O - i111I % i11iIiiIii
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  Oo00O0OO = urlresolver . HostedMediaFile ( url ) . resolve ( )
  oOOOoo0o = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  oOOOoo0o . setPath ( Oo00O0OO )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( Oo00O0OO , oOOOoo0o , False )
  quit ( )
 else :
  Oo00O0OO = url
  oOOOoo0o = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  oOOOoo0o . setPath ( Oo00O0OO )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( Oo00O0OO , oOOOoo0o , False )
  quit ( )
  if 44 - 44: oooO0oo0oOOOO % II1Ii1iI1i
def OOOO0oo0 ( ) :
 if 42 - 42: i1111 - oo - i111I . i1iIIIiI1I / OOO0O
 ooooo0Oo0 = xbmc . getInfoLabel ( "System.BuildVersion" )
 o0I1IIIi11ii11 = float ( ooooo0Oo0 [ : 4 ] )
 if o0I1IIIi11ii11 >= 11.0 and o0I1IIIi11ii11 <= 11.9 :
  O0o0oo0oOO0oO = 'Eden'
 elif o0I1IIIi11ii11 >= 12.0 and o0I1IIIi11ii11 <= 12.9 :
  O0o0oo0oOO0oO = 'Frodo'
 elif o0I1IIIi11ii11 >= 13.0 and o0I1IIIi11ii11 <= 13.9 :
  O0o0oo0oOO0oO = 'Gotham'
 elif o0I1IIIi11ii11 >= 14.0 and o0I1IIIi11ii11 <= 14.9 :
  O0o0oo0oOO0oO = 'Helix'
 elif o0I1IIIi11ii11 >= 15.0 and o0I1IIIi11ii11 <= 15.9 :
  O0o0oo0oOO0oO = 'Isengard'
 elif o0I1IIIi11ii11 >= 16.0 and o0I1IIIi11ii11 <= 16.9 :
  O0o0oo0oOO0oO = 'Jarvis'
 elif o0I1IIIi11ii11 >= 17.0 and o0I1IIIi11ii11 <= 17.9 :
  O0o0oo0oOO0oO = 'Krypton'
 else : O0o0oo0oOO0oO = "Decline"
 if 15 - 15: oo * i1111
 return O0o0oo0oOO0oO
 if 59 - 59: OooOoO0Oo + oo / oOo0
def o0 ( url ) :
 if 97 - 97: I11i1i11i1I * i1iIIIiI1I % iiIIiIiIi . i1iIIIiI1I - OooOoO0Oo - oOo0
 oo0O0o00I1ii1i = urllib2 . Request ( url )
 oo0O0o00I1ii1i . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 oOoOo = urllib2 . urlopen ( oo0O0o00I1ii1i )
 iII = oOoOo . read ( )
 oOoOo . close ( )
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return iII
 if 22 - 22: OooooO0oOO * i1IIiiiii * i11iIiiIii + i1iIIIiI1I * OOO0O * oo
def Oo0O0O0ooO0O ( url ) :
 if 85 - 85: i1iIIIiI1I * oOo0 % I11i1i11i1I - i1iIIIiI1I - oo0Ooo0
 oo0O0o00I1ii1i = urllib2 . Request ( url )
 oo0O0o00I1ii1i . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 oOoOo = urllib2 . urlopen ( oo0O0o00I1ii1i )
 iII = oOoOo . read ( )
 oOoOo . close ( )
 return iII
 if 46 - 46: oooO0oo0oOOOO
def oo0oooOo ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 65 - 65: ooO0oo0oO0 % OooooO0oOO + oooO0oo0oOOOO / i111I
 if 52 - 52: i1IIiiiii % oOo0 * i1IIi11111i % oo0Ooo0 + oOo0 / i1iIIIiI1I
 if 80 - 80: i111I + OoO000
 if 95 - 95: OooOoO0Oo / OooooO0oOO * OooOoO0Oo - i111I * i111I % oo
 if 43 - 43: I11i1i11i1I . OooOoO0Oo
def I1I1i1i ( ) :
 if 87 - 87: OOO0O / OoO000 . iiIIiIiIi - oOo0 / oo
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 41 - 41: i1111
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for II1Iiii11111 , iiI11I1iiIiII1I , o00ooOoo in os . walk ( IiIi11iIIi1Ii ) :
   i111i1I1ii1i = 0
   i111i1I1ii1i += len ( o00ooOoo )
   if i111i1I1ii1i > 0 :
    for Oooo in o00ooOoo :
     try :
      if ( Oooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( II1Iiii11111 , Oooo ) )
     except :
      pass
    for O0O in iiI11I1iiIiII1I :
     try :
      shutil . rmtree ( os . path . join ( II1Iiii11111 , O0O ) )
     except :
      pass
      if 80 - 80: ooO0oo0oO0
   else :
    pass
    if 23 - 23: i1111
 if os . path . exists ( Oo0O ) == True :
  for II1Iiii11111 , iiI11I1iiIiII1I , o00ooOoo in os . walk ( Oo0O ) :
   i111i1I1ii1i = 0
   i111i1I1ii1i += len ( o00ooOoo )
   if i111i1I1ii1i > 0 :
    for Oooo in o00ooOoo :
     try :
      if ( Oooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( II1Iiii11111 , Oooo ) )
     except :
      pass
    for O0O in iiI11I1iiIiII1I :
     try :
      shutil . rmtree ( os . path . join ( II1Iiii11111 , O0O ) )
     except :
      pass
      if 71 - 71: OooOoO0Oo * I11i1i11i1I . oo0Ooo0
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  i1ii1iiIi1II = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 98 - 98: oo - i1IIiiiii . OoO000 % i11iIiiIii
  for II1Iiii11111 , iiI11I1iiIiII1I , o00ooOoo in os . walk ( i1ii1iiIi1II ) :
   i111i1I1ii1i = 0
   i111i1I1ii1i += len ( o00ooOoo )
   if 69 - 69: i11iiII + i1iIIIiI1I * oooO0oo0oOOOO . oOo0 % OOO0O
   if i111i1I1ii1i > 0 :
    for Oooo in o00ooOoo :
     os . unlink ( os . path . join ( II1Iiii11111 , Oooo ) )
    for O0O in iiI11I1iiIiII1I :
     shutil . rmtree ( os . path . join ( II1Iiii11111 , O0O ) )
     if 96 - 96: iiIIiIiIi . iiIIiIiIi - oo0Ooo0 / oo0Ooo0
   else :
    pass
  OoOo = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 6 - 6: iiIIiIiIi
  for II1Iiii11111 , iiI11I1iiIiII1I , o00ooOoo in os . walk ( OoOo ) :
   i111i1I1ii1i = 0
   i111i1I1ii1i += len ( o00ooOoo )
   if 39 - 39: iiIIiIiIi / oooO0oo0oOOOO * OoO000
   if i111i1I1ii1i > 0 :
    for Oooo in o00ooOoo :
     os . unlink ( os . path . join ( II1Iiii11111 , Oooo ) )
    for O0O in iiI11I1iiIiII1I :
     shutil . rmtree ( os . path . join ( II1Iiii11111 , O0O ) )
     if 17 - 17: i1IIiiiii / ooO0oo0oO0 - oo + i1IIi11111i % oOo0
   else :
    pass
    if 14 - 14: oo0ooO0oOOOOo % OoO000 + i11iiII + oo
 iii11 = o00oOO0 ( )
 if 76 - 76: oo - i11iIiiIii + OOO0O + oOo0 / i111I
 for IiI1Iii1 in iii11 :
  Ooooo = xbmc . translatePath ( IiI1Iii1 . path )
  if os . path . exists ( Ooooo ) == True :
   for II1Iiii11111 , iiI11I1iiIiII1I , o00ooOoo in os . walk ( Ooooo ) :
    i111i1I1ii1i = 0
    i111i1I1ii1i += len ( o00ooOoo )
    if i111i1I1ii1i > 0 :
     for Oooo in o00ooOoo :
      os . unlink ( os . path . join ( II1Iiii11111 , Oooo ) )
     for O0O in iiI11I1iiIiII1I :
      shutil . rmtree ( os . path . join ( II1Iiii11111 , O0O ) )
      if 43 - 43: oOo0
    else :
     pass
     if 57 - 57: oooO0oo0oOOOO / oo0ooO0oOOOOo
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 12 - 12: i111I / oooO0oo0oOOOO + i1111 * i11iiII
def Ii11ii1I1 ( ) :
 Iii11III1I11 = [ ]
 iii = sys . argv [ 2 ]
 if len ( iii ) >= 2 :
  I11I1IIiiII1 = sys . argv [ 2 ]
  IiIIII1iiIIi = I11I1IIiiII1 . replace ( '?' , '' )
  if ( I11I1IIiiII1 [ len ( I11I1IIiiII1 ) - 1 ] == '/' ) :
   I11I1IIiiII1 = I11I1IIiiII1 [ 0 : len ( I11I1IIiiII1 ) - 2 ]
  i1I1IiI1ii = IiIIII1iiIIi . split ( '&' )
  Iii11III1I11 = { }
  for IiIIIIii1I in range ( len ( i1I1IiI1ii ) ) :
   O00OOoOOOO00O = { }
   O00OOoOOOO00O = i1I1IiI1ii [ IiIIIIii1I ] . split ( '=' )
   if ( len ( O00OOoOOOO00O ) ) == 2 :
    Iii11III1I11 [ O00OOoOOOO00O [ 0 ] ] = O00OOoOOOO00O [ 1 ]
 return Iii11III1I11
 if 72 - 72: i1IIi11111i + OoO000 . OOO0O + OOO0O
def oo0oOo ( name , url , mode , iconimage , fanart , description = '' ) :
 if 94 - 94: i11iIiiIii % i111I / i1IIi11111i
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 iII1Iii11111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OOo00ooOoO0o = True
 oOOOoo0o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oOOOoo0o . setProperty ( "fanart_Image" , fanart )
 oOOOoo0o . setProperty ( "icon_Image" , iconimage )
 OOo00ooOoO0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iII1Iii11111 , listitem = oOOOoo0o , isFolder = True )
 return OOo00ooOoO0o
 if 21 - 21: i11iIiiIii
def Iiii ( name , url , mode , iconimage , fanart , description = '' ) :
 if 89 - 89: i1iIIIiI1I . i11iIiiIii * oooO0oo0oOOOO
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 iII1Iii11111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OOo00ooOoO0o = True
 oOOOoo0o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oOOOoo0o . setProperty ( "fanart_Image" , fanart )
 oOOOoo0o . setProperty ( "icon_Image" , iconimage )
 OOo00ooOoO0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iII1Iii11111 , listitem = oOOOoo0o , isFolder = False )
 return OOo00ooOoO0o
 if 44 - 44: II1Ii1iI1i . i1IIi11111i / i11iIiiIii + OoO000
I11I1IIiiII1 = Ii11ii1I1 ( ) ; II11i1I11Ii1i = None ; OoOO0oo0o = None ; iI111II1ii = None ; O0ooO00ooOO0o = None ; O000O0oOO0 = None ; O0ooo0O0oo0 = None
try : O0ooO00ooOO0o = urllib . unquote_plus ( I11I1IIiiII1 [ "site" ] )
except : pass
try : II11i1I11Ii1i = urllib . unquote_plus ( I11I1IIiiII1 [ "url" ] )
except : pass
try : OoOO0oo0o = urllib . unquote_plus ( I11I1IIiiII1 [ "name" ] )
except : pass
try : iI111II1ii = int ( I11I1IIiiII1 [ "mode" ] )
except : pass
try : O000O0oOO0 = urllib . unquote_plus ( I11I1IIiiII1 [ "iconimage" ] )
except : pass
try : O0ooo0O0oo0 = urllib . unquote_plus ( I11I1IIiiII1 [ "fanart" ] )
except : pass
if 65 - 65: i1iIIIiI1I . oo + i1IIiiiii
if iI111II1ii == None or II11i1I11Ii1i == None or len ( II11i1I11Ii1i ) < 1 : o0O0o0Oo ( )
elif iI111II1ii == 1 : OOo0oO00ooO00 ( OoOO0oo0o , II11i1I11Ii1i )
elif iI111II1ii == 2 : OOoOO0ooo ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 3 : iiii1 ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 4 : PLAYSD ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 7 : o0ooooO0o0O ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 8 : IIii1111 ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 9 : AUTO_UPDATER ( OoOO0oo0o )
elif iI111II1ii == 10 : iIIIIiiIii ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 11 : o00 ( )
elif iI111II1ii == 12 : o0o0Ooo0 ( II11i1I11Ii1i )
elif iI111II1ii == 19 : OOoOOo0O00O ( II11i1I11Ii1i )
elif iI111II1ii == 20 : Ii1iIi111i1i1 ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 21 : OoooO0o ( II11i1I11Ii1i )
elif iI111II1ii == 22 : IiII1i1iii1Ii ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 23 : iiIii1IIi ( )
elif iI111II1ii == 24 : ii111I11iI ( )
elif iI111II1ii == 25 : o0iiiI1I1iIIIi1 ( )
elif iI111II1ii == 26 : oo0O0o00 ( )
elif iI111II1ii == 30 : OOoO0 ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 40 : i111iiIIII ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 41 : oOo000O ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 50 : O0Oo ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 51 : OOoOoo00Oo ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 60 : I111Ii ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 61 : O0o0O0OO0o ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 70 : IIiIi11iiIi ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 71 : Ii1i1 ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 80 : iI11i ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 90 : ii1 ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 91 : oOOOo00O00O ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 95 : IIIii ( )
elif iI111II1ii == 96 : II1IiiIii ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 97 : OooOOOOoO00OoOO ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 100 : Ooii1IIi1ii ( )
elif iI111II1ii == 500 : I1I1i1i ( )
elif iI111II1ii == 201 : I1II ( )
elif iI111II1ii == 202 : oO0o00oOOooO0 ( II11i1I11Ii1i )
elif iI111II1ii == 203 : O0iIi1IiII ( II11i1I11Ii1i )
elif iI111II1ii == 204 : oOIi111 ( II11i1I11Ii1i )
elif iI111II1ii == 205 : II1i1i1iII1 ( II11i1I11Ii1i )
elif iI111II1ii == 206 : OOo00 ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 210 : ooO00O0O0 ( II11i1I11Ii1i )
elif iI111II1ii == 220 : oooo00o0o0o ( II11i1I11Ii1i )
elif iI111II1ii == 221 : IIiiii ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 222 : iiIII1i ( II11i1I11Ii1i )
elif iI111II1ii == 300 : iII1iiiiIII ( II11i1I11Ii1i )
elif iI111II1ii == 301 : Ii1I11ii1i ( II11i1I11Ii1i )
elif iI111II1ii == 302 : ii11I1 ( II11i1I11Ii1i )
elif iI111II1ii == 303 : iI11 ( II11i1I11Ii1i )
elif iI111II1ii == 304 : OO0ooo0oOO ( II11i1I11Ii1i )
elif iI111II1ii == 305 : O0 ( )
elif iI111II1ii == 306 : IiiioooOOoooo ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 800 : II1i11 ( OoOO0oo0o , II11i1I11Ii1i , O000O0oOO0 )
elif iI111II1ii == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 25 - 25: oo0ooO0oOOOOo + I11i1i11i1I . I11i1i11i1I % i111I - i1IIiiiii
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if iI111II1ii == 80 :
 xbmc . sleep ( 10000 )
 xbmc . executebuiltin ( 'Container.Refresh' )