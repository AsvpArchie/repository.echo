import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
import plugintools
import datetime
from resources . lib . modules import regex
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
if 91 - 91: Ii1I . OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
O0oO = plugintools . get_setting ( "scrape1" )
o0oO0 = plugintools . get_setting ( "scrape2" )
oo00 = plugintools . get_setting ( "scrape3" )
if 88 - 88: O0Oo0oO0o . II1iI . i1iIii1Ii1II
#######################################################################
#						Cache Functions
#######################################################################
if 1 - 1: O0Oooo00
class Ooo0 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 89 - 89: I111i1i1111i - Ii1Ii1iiii11 % I1I1i1
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 18 - 18: iiIIIIi1i1 / OOoOoo00oo - iI1 + OOooO % ooO00oo - O000oo
i1iIIi1 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 50 - 50: i11iIiiIii - OOoOoo00oo
class oo0Ooo0 :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 46 - 46: O000oo % O000oo - Ii1Ii1iiii11 * O0Oooo00 % iI1
  if 55 - 55: i1iIii1Ii1II % o0000oOoOoO0o / OOoOoo00oo - Ii1Ii1iiii11 - Ii1I / i1I1ii1II1iII
  if 28 - 28: OoOO - o0000oOoOoO0o
  if 70 - 70: II1iI . II1iI - II1iI / I111i1i1111i * I1I1i1
def OoO000 ( ) :
 IIiiIiI1 = 5
 iiIiIIi = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 ooOoo0O = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 76 - 76: Ii1I / O0Oooo00 . oooO0oo0oOOOO * OOoOoo00oo - I1I1i1
 Oooo = [ ]
 if 67 - 67: I1I1i1 / OoOO0ooOOoo0O % iiIIIIi1i1 - OoOO
 for Ooo in range ( IIiiIiI1 ) :
  Oooo . append ( oo0Ooo0 ( iiIiIIi [ Ooo ] , ooOoo0O [ Ooo ] ) )
  if 68 - 68: iiIIIIi1i1 + I1I1i1 . OoOO - OOooO % OoOO - O000oo
 return Oooo
 if 79 - 79: O0Oo0oO0o + oooO0oo0oOOOO - iI1
def oO00O00o0OOO0 ( ) :
 if 27 - 27: Ii1I % o0000oOoOoO0o * Ii1Ii1iiii11 + i11iIiiIii + OoOO0ooOOoo0O * o0000oOoOoO0o
 if not os . path . isfile ( ooo0OO ) :
  plugintools . open_settings_dialog ( )
  if 80 - 80: iiIIIIi1i1 * i11iIiiIii / ooO00oo
 I11II1i = open ( IIi1IiiiI1Ii ) . read ( )
 IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  I1IIIii = float ( IIiiiiiiIi1I1 )
  if 95 - 95: II1iI % Ii1Ii1iiii11 . Ii1I
 I1i1I = oOO00oOO ( II1 )
 I1i1I = base64 . b64decode ( I1i1I )
 I1i1I = I1i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 75 - 75: o0000oOoOoO0o / OoOO0ooOOoo0O - Ii1I / i1iIii1Ii1II . i1I1ii1II1iII - o0000oOoOoO0o
  if '<search>ZGlzcGxheQ==</search>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 13 - 13: ooO00oo % i1iIii1Ii1II - i11iIiiIii . oooO0oo0oOOOO + i1I1ii1II1iII
  elif '<vip>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 10 - 10: I111i1i1111i * O000oo * i1I1ii1II1iII % OOoOoo00oo . I1I1i1 + ooO00oo
  elif '<divider>bnVsbA==</divider>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   IIiIi11i1 ( O000OO0 , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 29 - 29: I111i1i1111i % oooO0oo0oOOOO + O000oo / O0Oooo00 + I1I1i1 * O0Oooo00
  elif '<extras>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , II1 , 26 , iiiii , O0O0OO0O0O0 )
   if 42 - 42: OOoOoo00oo + Ii1Ii1iiii11
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 76 - 76: ooO00oo - II1iI
   if 70 - 70: O000oo
   if 61 - 61: I111i1i1111i . I111i1i1111i
   if 10 - 10: i1iIii1Ii1II * iI1 . iiIIIIi1i1 + i1I1ii1II1iII - O000oo * o0000oOoOoO0o
   if 56 - 56: O0Oooo00 * OOooO * i1I1ii1II1iII
   if 80 - 80: O0Oooo00 * i1I1ii1II1iII % i1I1ii1II1iII
   if 59 - 59: OoOO + oooO0oo0oOOOO - O0Oooo00 - oooO0oo0oOOOO + I1I1i1 / I111i1i1111i
   if 24 - 24: iiIIIIi1i1 . iI1 % I1I1i1 + O000oo % i1iIii1Ii1II
   if 4 - 4: OOooO - II1iI * i1iIii1Ii1II - iiIIIIi1i1
   if 41 - 41: i1iIii1Ii1II . oooO0oo0oOOOO * Ii1Ii1iiii11 % OOooO
   if 86 - 86: oooO0oo0oOOOO + OOoOoo00oo % i11iIiiIii * Ii1Ii1iiii11 . O000oo * iiIIIIi1i1
   if 44 - 44: Ii1Ii1iiii11
   if 88 - 88: ooO00oo % OOoOoo00oo . i1I1ii1II1iII
   if 38 - 38: O0Oooo00
   if 57 - 57: Ii1I / Ii1Ii1iiii11 * ooO00oo / i1iIii1Ii1II . i1I1ii1II1iII
   if 26 - 26: iI1
   if 91 - 91: II1iI . I111i1i1111i + II1iI - iI1 / OoOO0ooOOoo0O
   if 39 - 39: I111i1i1111i / O000oo - i1I1ii1II1iII
   if 98 - 98: I111i1i1111i / iiIIIIi1i1 % Ii1Ii1iiii11 . i1iIii1Ii1II
   if 91 - 91: Ii1Ii1iiii11 % O0Oo0oO0o
   if 64 - 64: iiIIIIi1i1 % iI1 - ooO00oo - Ii1Ii1iiii11
   if 31 - 31: iiIIIIi1i1 - i1I1ii1II1iII . iiIIIIi1i1
  elif '<sportsdevil>' in IIiiiiiiIi1I1 :
   i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0O0oOO00O00o = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    iI1ii11iIi1i = re . compile ( '<referer>(.+?)</referer>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    iI1ii11iIi1i = base64 . b64decode ( iI1ii11iIi1i )
    iiI111I1iIiI = iI1ii11iIi1i
    II = "/"
    if not iiI111I1iIiI . endswith ( II ) :
     Ii1I1IIii1II = iiI111I1iIiI + "/"
    else :
     Ii1I1IIii1II = iiI111I1iIiI
    I1i1I = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( O000OO0 ) + '%26url=' + O0O0oOO00O00o
    O0O0oOO00O00o = I1i1I + '%26referer=' + Ii1I1IIii1II
    IIiIi11i1 ( O000OO0 , O0O0oOO00O00o , 4 , Oo0o00 , O0 )
   elif len ( i1I11i1I ) > 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    IIiIi11i1 ( O000OO0 , url2 + 'NOTPLAY' , 8 , Oo0o00 , O0 )
    if 25 - 25: I111i1i1111i
  elif '<folder>' in IIiiiiiiIi1I1 :
   Ii1i = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for O000OO0 , O0O0oOO00O00o , Oo0o00 , O0 in Ii1i :
    O000OO0 = base64 . b64decode ( O000OO0 )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0 = base64 . b64decode ( O0 )
    I11iii1Ii ( O000OO0 , O0O0oOO00O00o , 1 , Oo0o00 , O0 )
  elif '<m3u>' in IIiiiiiiIi1I1 :
   Ii1i = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for O000OO0 , O0O0oOO00O00o , Oo0o00 , O0 in Ii1i :
    O000OO0 = base64 . b64decode ( O000OO0 )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0 = base64 . b64decode ( O0 )
    I11iii1Ii ( O000OO0 , O0O0oOO00O00o , 10 , Oo0o00 , O0 )
  else :
   i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    Ii1i = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
    I1 = len ( ooooooO0oo )
    for O000OO0 , O0O0oOO00O00o , Oo0o00 , O0 in Ii1i :
     O000OO0 = base64 . b64decode ( O000OO0 )
     O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
     Oo0o00 = base64 . b64decode ( Oo0o00 )
     O0 = base64 . b64decode ( O0 )
     IIiIi11i1 ( O000OO0 , O0O0oOO00O00o , 2 , Oo0o00 , O0 )
   elif len ( i1I11i1I ) > 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0 = base64 . b64decode ( O0 )
    IIiIi11i1 ( O000OO0 , II1 , 3 , Oo0o00 , O0 )
    if 15 - 15: i1I1ii1II1iII
 IIiIi11i1 ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '[COLOR dodgerblue]VER ' + str ( I1IIIii ) + '[/COLOR][COLOR yellow] - CHECK FOR UPDATES[/COLOR]' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 if 18 - 18: i11iIiiIii . o0000oOoOoO0o % OoOO0ooOOoo0O / Ii1I
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 75 - 75: i1iIii1Ii1II % O0Oooo00 % O0Oooo00 . ooO00oo
def III1iII1I1ii ( name , url ) :
 if 61 - 61: i1I1ii1II1iII
 hash = [ ]
 O0OOO = url
 I1i1I = oOO00oOO ( url )
 if 10 - 10: I1I1i1 * iiIIIIi1i1 % i1iIii1Ii1II / oooO0oo0oOOOO / i1iIii1Ii1II
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 42 - 42: II1iI
  if '<search>' in IIiiiiiiIi1I1 :
   if 67 - 67: ooO00oo . iI1 . Ii1I
   i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    url = name + "!" + url + "!" + Oo0o00
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    I11iii1Ii ( name , url , 20 , Oo0o00 , Oo0o00 )
    if 10 - 10: I111i1i1111i % I111i1i1111i - OoOO / I1I1i1 + OOoOoo00oo
   elif len ( i1I11i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    url = O0OOO + "!" + name + "!" + Oo0o00
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    I11iii1Ii ( name , url , 22 , Oo0o00 , Oo0o00 )
    if 87 - 87: Ii1Ii1iiii11 * I111i1i1111i + I1I1i1 / OoOO / iI1
  elif '<regex>' in IIiiiiiiIi1I1 :
   I1111IIi = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( IIiiiiiiIi1I1 )
   I1111IIi = '' . join ( I1111IIi )
   Oo0oO = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( I1111IIi )
   I1111IIi = urllib . quote_plus ( I1111IIi )
   if 1 - 1: II1iI - Ii1Ii1iiii11 . iiIIIIi1i1 . II1iI / O0Oo0oO0o + iiIIIIi1i1
   OooOOOOo = hashlib . md5 ( )
   for oo0O0oO in I1111IIi : OooOOOOo . update ( str ( oo0O0oO ) )
   OooOOOOo = str ( OooOOOOo . hexdigest ( ) )
   if 60 - 60: oooO0oo0oOOOO
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   IIiiiiiiIi1I1 = re . sub ( '<regex>.+?</regex>' , '' , IIiiiiiiIi1I1 )
   IIiiiiiiIi1I1 = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , IIiiiiiiIi1I1 )
   IIiiiiiiIi1I1 = re . sub ( '<link></link>' , '' , IIiiiiiiIi1I1 )
   if 22 - 22: i1I1ii1II1iII
   name = re . sub ( '<meta>.+?</meta>' , '' , IIiiiiiiIi1I1 )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 33 - 33: iiIIIIi1i1
   try : iI11i1ii11 = re . findall ( '<date>(.+?)</date>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : iI11i1ii11 = ''
   if re . search ( r'\d+' , iI11i1ii11 ) : name += ' [COLOR red] Updated %s[/COLOR]' % iI11i1ii11
   if 58 - 58: II1iI % i11iIiiIii . iI1 / Ii1Ii1iiii11
   try : O0o = re . findall ( '<thumbnail>(.+?)</thumbnail>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : O0o = iiiii
   if 59 - 59: oooO0oo0oOOOO + oooO0oo0oOOOO + O0Oooo00 / OoOO
   try : O000ooIIi1I11I1II = re . findall ( '<fanart>(.+?)</fanart>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : O000ooIIi1I11I1II = O0O0OO0O0O0
   if 63 - 63: OoOO0ooOOoo0O - II1iI . i1I1ii1II1iII / O0Oooo00 . i1iIii1Ii1II / Ii1I
   try : o0OOOO00O0Oo = re . findall ( '<meta>(.+?)</meta>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : o0OOOO00O0Oo = '0'
   if 48 - 48: Ii1I
   try : url = re . findall ( '<link>(.+?)</link>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % o0OOOO00O0Oo )
   url = '<preset>search</preset>%s' % o0OOOO00O0Oo if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % o0OOOO00O0Oo )
   url = '<preset>searchsd</preset>%s' % o0OOOO00O0Oo if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 11 - 11: iiIIIIi1i1 + OoOO0ooOOoo0O - II1iI / O0Oooo00 + O0Oo0oO0o . i1I1ii1II1iII
   if not I1111IIi == '' :
    hash . append ( { 'regex' : OooOOOOo , 'response' : I1111IIi } )
    url += '|regex=%s' % I1111IIi
    if 41 - 41: OOoOoo00oo - Ii1I - Ii1I
   IIiIi11i1 ( name , url , 30 , O0o , O000ooIIi1I11I1II )
   if 68 - 68: I1I1i1 % ooO00oo
  elif '<sportsdevil>' in IIiiiiiiIi1I1 :
   i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     iI1ii11iIi1i = re . compile ( '<referer>(.+?)</referer>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : iI1ii11iIi1i = "None"
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : O0 = O0O0OO0O0O0
    iiI111I1iIiI = iI1ii11iIi1i
    II = "/"
    if not iiI111I1iIiI . endswith ( II ) :
     Ii1I1IIii1II = iiI111I1iIiI + "/"
    else :
     Ii1I1IIii1II = iiI111I1iIiI
    I1i1I = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = I1i1I + '%26referer=' + Ii1I1IIii1II
    IIiIi11i1 ( name , url , 2 , Oo0o00 , O0 )
    if 88 - 88: OoOO - O000oo + I1I1i1
   elif len ( i1I11i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : O0 = O0O0OO0O0O0
    IIiIi11i1 ( name , O0OOO + 'NOTPLAY' , 8 , Oo0o00 , O0 )
    if 40 - 40: oooO0oo0oOOOO * OOoOoo00oo + I1I1i1 % iI1
  elif '<folder>' in IIiiiiiiIi1I1 :
   Ii1i = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for name , url , Oo0o00 , O0 in Ii1i :
    I11iii1Ii ( name , url , 1 , Oo0o00 , O0 )
    if 74 - 74: Ii1Ii1iiii11 - O0Oo0oO0o + OoOO0ooOOoo0O + ooO00oo / i1iIii1Ii1II
  elif '<m3u>' in IIiiiiiiIi1I1 :
   Ii1i = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for name , url , Oo0o00 , O0 in Ii1i :
    I11iii1Ii ( name , url , 10 , Oo0o00 , O0 )
    if 23 - 23: Ii1I
  else :
   i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    Ii1i = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
    I1 = len ( ooooooO0oo )
    for name , url , Oo0o00 , O0 in Ii1i :
     IIiIi11i1 ( name , url , 2 , Oo0o00 , O0 )
   elif len ( i1I11i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : O0 = O0O0OO0O0O0
    IIiIi11i1 ( name , O0OOO , 3 , Oo0o00 , O0 )
    if 85 - 85: OOoOoo00oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 84 - 84: oooO0oo0oOOOO . OoOO % OoOO0ooOOoo0O + OOoOoo00oo % OoOO0ooOOoo0O % II1iI
def IIi1 ( name , url , iconimage ) :
 I1I1I = [ ]
 OoOO000 = [ ]
 i1Ii11i1i = [ ]
 I1i1I = oOO00oOO ( url )
 o0oOOoo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0oOOoo ) [ 0 ]
 i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( o0oOOoo )
 oo0O0oO = 1
 for oOo00O0oo00o0 in i1I11i1I :
  ii = oOo00O0oo00o0
  if '(' in oOo00O0oo00o0 :
   oOo00O0oo00o0 = oOo00O0oo00o0 . split ( '(' ) [ 0 ]
   OOooooO0Oo = str ( ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1I1I . append ( oOo00O0oo00o0 )
   OoOO000 . append ( OOooooO0Oo )
  else :
   I1I1I . append ( oOo00O0oo00o0 )
   OoOO000 . append ( 'Link ' + str ( oo0O0oO ) )
  oo0O0oO = oo0O0oO + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( name , OoOO000 )
 if OO < 0 :
  quit ( )
 else :
  url = I1I1I [ OO ]
  print url
  if 25 - 25: II1iI
 url = I1I1I [ OO ]
 name = OoOO000 [ OO ]
 oOo0oO ( name , url , iiiii )
 if 51 - 51: O0Oo0oO0o - Ii1Ii1iiii11 + i1I1ii1II1iII * OOoOoo00oo . iiIIIIi1i1 + Ii1Ii1iiii11
def OoO0o ( name , url , iconimage ) :
 if 78 - 78: Ii1Ii1iiii11 % Ii1I % OOoOoo00oo
 I1I1I = [ ]
 OoOO000 = [ ]
 i1Ii11i1i = [ ]
 iiI1Ii1iI1 = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 I1i1I = oOO00oOO ( url )
 o0oOOoo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( o0oOOoo )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0oOOoo ) [ 0 ]
 if 87 - 87: O0Oo0oO0o . OOooO
 O0OO0O = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 81 - 81: Ii1Ii1iiii11 . O0Oooo00 % Ii1I / oooO0oo0oOOOO - Ii1Ii1iiii11
 oo0O0oO = 1
 if 43 - 43: i11iIiiIii + O0Oo0oO0o * i1I1ii1II1iII * ooO00oo * Ii1I
 for oOo00O0oo00o0 in i1I11i1I :
  ii = oOo00O0oo00o0
  if '(' in oOo00O0oo00o0 :
   oOo00O0oo00o0 = oOo00O0oo00o0 . split ( '(' ) [ 0 ]
   OOooooO0Oo = str ( ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1I1I . append ( oOo00O0oo00o0 )
   OoOO000 . append ( OOooooO0Oo )
   iiI1Ii1iI1 . append ( 'Stream ' + str ( oo0O0oO ) )
  else :
   I1I1I . append ( oOo00O0oo00o0 )
   OoOO000 . append ( 'Link ' + str ( oo0O0oO ) )
   if 64 - 64: I1I1i1 % OoOO * Ii1Ii1iiii11
  oo0O0oO = oo0O0oO + 1
  if 79 - 79: Ii1I
 name = '[COLOR red]' + name + '[/COLOR]'
 if 78 - 78: I111i1i1111i + I1I1i1 - ooO00oo
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( name , OoOO000 )
 if OO < 0 :
  quit ( )
 else :
  iiI111I1iIiI = OoOO000 [ OO ]
  II = "/"
  if not iiI111I1iIiI . endswith ( II ) :
   Ii1I1IIii1II = iiI111I1iIiI + "/"
  else :
   Ii1I1IIii1II = iiI111I1iIiI
  url = O0OO0O + I1I1I [ OO ] + "%26referer=" + Ii1I1IIii1II
  if 38 - 38: O0Oooo00 - Ii1Ii1iiii11 + OoOO / i1iIii1Ii1II % O0Oo0oO0o
 name = OoOO000 [ OO ]
 oOo0oO ( name , url , iiiii )
 if 57 - 57: II1iI / O000oo
def Ii1I1Ii ( name , url , iconimage ) :
 if 69 - 69: oooO0oo0oOOOO / O0Oooo00 . OOooO * ooO00oo % OOoOoo00oo - O0Oooo00
 i1i , Ooo = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 i1i += urllib . unquote_plus ( Ooo )
 url = regex . resolve ( i1i )
 if 56 - 56: I111i1i1111i % Ii1I - oooO0oo0oOOOO
 oOo0oO ( name , url , iconimage )
 if 100 - 100: OOoOoo00oo - Ii1I % Ii1Ii1iiii11 * I1I1i1 + oooO0oo0oOOOO
def Oo0O0oooo ( ) :
 if 33 - 33: ooO00oo + iI1 * Ii1Ii1iiii11 / OoOO - oooO0oo0oOOOO
 IIiIi11i1 ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 54 - 54: ooO00oo / I1I1i1 . Ii1Ii1iiii11 % iI1
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 57 - 57: i11iIiiIii . I111i1i1111i - OOoOoo00oo - Ii1Ii1iiii11 + i1iIii1Ii1II
def oO00oooOOoOo0 ( ) :
 if 74 - 74: OoOO * I111i1i1111i + i1iIii1Ii1II / o0000oOoOoO0o / i1I1ii1II1iII . O0Oo0oO0o
 I11iii1Ii ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 62 - 62: OoOO0ooOOoo0O * oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 58 - 58: i1iIii1Ii1II % O0Oooo00
def i1 ( ) :
 if 51 - 51: O0Oo0oO0o / i1iIii1Ii1II . I1I1i1 * O0Oooo00 + II1iI * OOooO
 I11iii1Ii ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 73 - 73: II1iI + OoOO0ooOOoo0O - Ii1I - OOoOoo00oo - i1I1ii1II1iII
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 99 - 99: O000oo . OOoOoo00oo + ooO00oo + OoOO0ooOOoo0O % O0Oooo00
def ooO ( ) :
 if 46 - 46: oooO0oo0oOOOO - OoOO0ooOOoo0O - iiIIIIi1i1 * i1I1ii1II1iII
 oo0O0oO = 0
 I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  oo0O0oO = oo0O0oO + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( oo0O0oO ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 80 - 80: i11iIiiIii % O000oo + OOoOoo00oo % iiIIIIi1i1 - I111i1i1111i
 I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  oo0O0oO = oo0O0oO + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( oo0O0oO ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 18 - 18: iI1 - I1I1i1 . ooO00oo . OoOO
 I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  oo0O0oO = oo0O0oO + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( oo0O0oO ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 2 - 2: I1I1i1 . II1iI
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 78 - 78: iiIIIIi1i1 * OoOO . oooO0oo0oOOOO / O0Oooo00 - OoOO0ooOOoo0O / ooO00oo
def i1I1IiiIi1i ( url ) :
 if 29 - 29: oooO0oo0oOOOO % oooO0oo0oOOOO
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 if 94 - 94: OoOO / O0Oo0oO0o % iI1 * iI1 * i1I1ii1II1iII
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OO0 = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  Oo0o00 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 12 , Oo0o00 , O0O0OO0O0O0 )
  if 29 - 29: II1iI + i1iIii1Ii1II / O0Oooo00 / I1I1i1 * OoOO
 try :
  O0OO = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( I1i1I11I ) [ 0 ]
  I11iii1Ii ( '[COLOR yellow]Next Page -->[/COLOR]' , O0OO , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 6 - 6: OoOO % i11iIiiIii % I111i1i1111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 93 - 93: OOooO * OoOO0ooOOoo0O + O000oo
def IiII111i1i11 ( url ) :
 if 40 - 40: O000oo * OOooO * i11iIiiIii
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   O000OO0 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except :
   O000OO0 = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 57 - 57: O000oo
def II11Iiii ( url ) :
 if 46 - 46: iiIIIIi1i1 / OOoOoo00oo
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( I1i1I11I )
 O000 = 0
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   O000OO0 = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : O000 = 1
  if 52 - 52: I1I1i1
  if O000 == 0 :
   I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 12 , Oo0o00 , O0O0OO0O0O0 )
  O000 = 0
  if 19 - 19: oooO0oo0oOOOO
 try :
  O0OO = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( I1i1I11I ) [ 0 ]
  I11iii1Ii ( '[COLOR yellow]Next Page -->[/COLOR]' , O0OO , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 25 - 25: OOoOoo00oo / O000oo
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 31 - 31: I1I1i1 . Ii1I % oooO0oo0oOOOO . O0Oooo00 + OOooO
def o0o ( url ) :
 if 62 - 62: OoOO0ooOOoo0O . iiIIIIi1i1
 oOOOoo00 = datetime . date . today ( )
 iiIiIIIiiI = datetime . datetime . strftime ( oOOOoo00 , '%A %d %B %Y' )
 if 12 - 12: Ii1I - O0Oooo00
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iiIiIIIiiI ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 81 - 81: i1iIii1Ii1II - i1iIii1Ii1II . iI1
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( I1i1I11I )
 O000 = 0
 oo0O0oO = 0
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   o0OoOo00o0o = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   try :
    I1II1I11I1I = re . compile ( '<p>(.+?)</p>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   except : I1II1I11I1I = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<img src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : O000 = 1
  if 54 - 54: OoOO0ooOOoo0O + O0Oooo00 - o0000oOoOoO0o % i11iIiiIii
  if O000 == 0 :
   if 'vs' in o0OoOo00o0o :
    O000OO0 = '[COLOR dodgerblue]' + o0OoOo00o0o + ' - ' + '[/COLOR][COLOR green]' + I1II1I11I1I + '[/COLOR]'
    oo0O0oO = oo0O0oO + 1
    IIiIi11i1 ( O000OO0 , url , 206 , Oo0o00 , O0O0OO0O0O0 , '' )
  O000 = 0
  if 3 - 3: O0Oooo00 % O0Oooo00
 if oo0O0oO == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 83 - 83: i1I1ii1II1iII + ooO00oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 73 - 73: iI1
def IiiiiI1i1Iii ( name , url , iconimage ) :
 if 87 - 87: O0Oooo00
 I1i1I11I = oOO00oOO ( url )
 IiI1iiiIii = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( I1i1I11I ) [ 0 ]
 if 7 - 7: ooO00oo * II1iI - O000oo + I1I1i1 * oooO0oo0oOOOO % II1iI
 if not "http" in IiI1iiiIii :
  IiI1iiiIii = IiI1iiiIii . replace ( "//" , "" )
  url = "http://" + IiI1iiiIii
 else :
  url = IiI1iiiIii
  if 15 - 15: i1iIii1Ii1II % oooO0oo0oOOOO * iiIIIIi1i1
 O0OoooO0 = url
 if 85 - 85: iiIIIIi1i1
 iI1i11II1i = oOO00oOO ( url )
 IiI1iiiIii = re . compile ( "atob(.+?)," ) . findall ( iI1i11II1i ) [ 0 ]
 IiI1iiiIii = IiI1iiiIii . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( IiI1iiiIii )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + O0OoooO0 + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 oOo0oO ( name , url , iconimage )
 if 96 - 96: ooO00oo
def oOoOo0O0OOOoO ( url ) :
 if 50 - 50: O000oo
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 47 - 47: O0Oo0oO0o * I111i1i1111i + OoOO / ooO00oo / II1iI - OoOO0ooOOoo0O
  if '<display>eWVz</display>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   url = base64 . b64decode ( url )
   Oo0o00 = base64 . b64decode ( Oo0o00 )
   O0 = base64 . b64decode ( O0 )
   I11iii1Ii ( O000OO0 , url , 220 , Oo0o00 , O0 , '' )
   if 33 - 33: i1iIii1Ii1II * I1I1i1 - i1I1ii1II1iII
def OOo0o0O0O ( url ) :
 if 65 - 65: i11iIiiIii
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( I1i1I11I )
 if 85 - 85: OOoOoo00oo % iI1 + iiIIIIi1i1 / O0Oooo00 . Ii1Ii1iiii11 + I1I1i1
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OO0 = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  try :
   ooOoOo0 = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : ooOoOo0 = "SD"
  ooOoOo0 = '[COLOR yellow]' + ooOoOo0 + '[/COLOR]'
  Oo0o00 = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  O000OO0 = O000OO0 . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 2 - 2: iI1 % OoOO * OoOO . O0Oooo00 / iI1
  IIiIi11i1 ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR] - ' + ooOoOo0 , url , 212 , Oo0o00 , O0O0OO0O0O0 , '' )
  if 27 - 27: II1iI + O000oo - o0000oOoOoO0o
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( I1i1I11I ) [ 0 ]
  O00oOOooo = 'http://www.fmovies.se/' + url
  I11iii1Ii ( "Next Page -->" , O00oOOooo , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 50 - 50: I111i1i1111i % Ii1I * O0Oooo00
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 5 - 5: OOooO * i1iIii1Ii1II
def i1Ii1i1I11Iii ( url ) :
 if 25 - 25: OOooO + OOoOoo00oo / O000oo . O0Oooo00 % Ii1I * II1iI
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( I1i1I11I )
 if 84 - 84: O000oo % OOoOoo00oo + i11iIiiIii
 if 28 - 28: O0Oo0oO0o + II1iI * I1I1i1 % Ii1Ii1iiii11 . iiIIIIi1i1 % Ii1I
def I1iiiiIii ( url ) :
 if 19 - 19: II1iI - O0Oo0oO0o . Ii1I
 if "iptvembed" in url :
  I1i1I11I = oOO00oOO ( url )
  ooooooO0oo = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '</pre>' , '' )
   url = IIiiiiiiIi1I1
   if 60 - 60: i1I1ii1II1iII + O0Oo0oO0o
 if "sourcetv" in url :
  I1i1I11I = oOO00oOO ( url )
  ooooooO0oo = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '</pre>' , '' )
   url = IIiiiiiiIi1I1
   if 9 - 9: O000oo * OoOO0ooOOoo0O - OoOO + i1iIii1Ii1II / II1iI . II1iI
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 iiI1iI111ii1i = [ ]
 for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
  O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
  iiI1iI111ii1i . append ( O0i11I1I1I )
 list = [ ]
 for oOOOo00O00O in iiI1iI111ii1i :
  O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
  iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
  for iIIIII1I , oo in iiIIi :
   O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
  list . append ( O0i11I1I1I )
  if 42 - 42: ooO00oo . oooO0oo0oOOOO . o0000oOoOoO0o + i1iIii1Ii1II + I1I1i1 + oooO0oo0oOOOO
 I1I = 0
 for oOOOo00O00O in list :
  I1I = 1
  O000OO0 = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
  url = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   IIiIi11i1 ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   I11iii1Ii ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 20 - 20: iiIIIIi1i1 + OOoOoo00oo / Ii1I % OoOO
 if I1I == 0 :
  IIiIi11i1 ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 88 - 88: i1iIii1Ii1II / i1I1ii1II1iII
def OOOOO0O00 ( url ) :
 if 30 - 30: OoOO . oooO0oo0oOOOO . I1I1i1 / O0Oooo00
 I1i1I = oOO00oOO ( url )
 O0OOO = url
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 42 - 42: O0Oo0oO0o
  i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 )
  if len ( i1I11i1I ) == 1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = O000OO0 + "!" + url + "!" + Oo0o00
   O000OO0 = '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]'
   I11iii1Ii ( O000OO0 , url , 20 , Oo0o00 , Oo0o00 )
   if 19 - 19: Ii1Ii1iiii11 % I111i1i1111i * OoOO + oooO0oo0oOOOO
  elif len ( i1I11i1I ) > 1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = O0OOO + "!" + O000OO0 + "!" + Oo0o00
   O000OO0 = '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]'
   I11iii1Ii ( O000OO0 , url , 22 , Oo0o00 , Oo0o00 )
   if 46 - 46: O0Oo0oO0o
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 1 - 1: iI1
def O0O0Ooo ( url ) :
 if 77 - 77: O0Oooo00 / OoOO0ooOOoo0O
 oOOOoo00 = datetime . date . today ( )
 iiIiIIIiiI = datetime . datetime . strftime ( oOOOoo00 , '%A %d %B %Y' )
 if 46 - 46: O0Oooo00 % OoOO . iI1 % iI1 + i11iIiiIii
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iiIiIIIiiI ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 72 - 72: OoOO * OOoOoo00oo % O000oo / II1iI
 I1i1I = oOO00oOO ( url )
 O0OOO = url
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 35 - 35: O000oo + o0000oOoOoO0o % I111i1i1111i % iiIIIIi1i1 + Ii1Ii1iiii11
  i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 )
  if len ( i1I11i1I ) == 1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = O000OO0 + "!" + url + "!" + Oo0o00
   O000OO0 = '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]'
   I11iii1Ii ( O000OO0 , url , 20 , Oo0o00 , Oo0o00 )
   if 17 - 17: o0000oOoOoO0o
  elif len ( i1I11i1I ) > 1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = O0OOO + "!" + O000OO0 + "!" + Oo0o00
   O000OO0 = '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]'
   I11iii1Ii ( O000OO0 , url , 22 , Oo0o00 , Oo0o00 )
   if 21 - 21: O0Oo0oO0o
def I1ii1 ( ) :
 if 99 - 99: O000oo . ooO00oo % OOooO * OOooO . o0000oOoOoO0o
 oOOOoo00 = datetime . date . today ( )
 iiIiIIIiiI = datetime . datetime . strftime ( oOOOoo00 , '%A %d %B %Y' )
 if 72 - 72: I1I1i1 % I111i1i1111i + II1iI / Ii1Ii1iiii11 + OOooO
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iiIiIIIiiI ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 10 - 10: ooO00oo / O000oo + i11iIiiIii / OOoOoo00oo
 I1i1I = oOO00oOO ( 'http://www.oddschecker.com/tv-sports-calendar' )
 ooooooO0oo = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( I1i1I )
 OOOoOoO = str ( ooooooO0oo )
 iIIIII1ii1I = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( OOOoOoO )
 for IIiiiiiiIi1I1 in iIIIII1ii1I :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in IIiiiiiiIi1I1 :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    o0OoOo00o0o = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( 'src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     Ii1i1iI = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
     Ii1i1iI = IIiI1 ( Ii1i1iI )
    except : Ii1i1iI = "null"
    O000OO0 = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + o0OoOo00o0o + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    O000OO0 = i1iI1 ( O000OO0 )
    O0O0oOO00O00o = o0OoOo00o0o + "!" + Ii1i1iI . lower ( ) + "!" + Oo0o00
    I11iii1Ii ( O000OO0 , O0O0oOO00O00o , 20 , Oo0o00 , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    o0OoOo00o0o = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     Ii1i1iI = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : Ii1i1iI = "null"
    Oo0o00 = re . compile ( 'src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + o0OoOo00o0o + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    O000OO0 = i1iI1 ( O000OO0 )
    O0O0oOO00O00o = o0OoOo00o0o + "!" + Ii1i1iI . lower ( ) + "!" + Oo0o00
    I11iii1Ii ( O000OO0 , O0O0oOO00O00o , 20 , Oo0o00 , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 1 - 1: o0000oOoOoO0o . i11iIiiIii % I1I1i1
def OooO0oo ( name , url , iconimage ) :
 if 89 - 89: OOoOoo00oo
 try :
  url , ooOoOO0OoO00o , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 11 - 11: O0Oo0oO0o - oooO0oo0oOOOO * i1I1ii1II1iII . I111i1i1111i . Ii1Ii1iiii11
 O0OoOO0oo0 = [ ]
 if 96 - 96: i1iIii1Ii1II . O0Oooo00 - O000oo
 I1i1I = oOO00oOO ( url )
 o0oOOoo = re . compile ( '<title>' + re . escape ( ooOoOO0OoO00o ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0oOOoo ) [ 0 ]
 i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( o0oOOoo )
 for oOo00O0oo00o0 in i1I11i1I :
  O0OoOO0oo0 . append ( oOo00O0oo00o0 )
  if 99 - 99: OOooO . O0Oo0oO0o - OOoOoo00oo % OOoOoo00oo * Ii1I . i1I1ii1II1iII
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 4 - 4: OOoOoo00oo
 OO0oOOoo = 0
 if 52 - 52: O0Oooo00 % O0Oo0oO0o
 Oo000ooOOO = [ ]
 Ii11i1I11i = [ ]
 I11i1 = [ ]
 I1IiiI . update ( 0 )
 iIiIIIIIii = 0
 if 58 - 58: O0Oooo00 / OOooO . i1iIii1Ii1II / OoOO0ooOOoo0O + ooO00oo
 if O0oO == "true" :
  iIiIIIIIii = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if OO0oOOoo < 100 :
    I1IiiI . update ( OO0oOOoo )
    OO0oOOoo = OO0oOOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0i11I1I1I )
   O0OoO0ooOO0o = [ ]
   for oOOOo00O00O in iiI1iI111ii1i :
    O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
    for iIIIII1I , oo in iiIIi :
     O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
    O0OoO0ooOO0o . append ( O0i11I1I1I )
    if 81 - 81: Ii1I * i1I1ii1II1iII + oooO0oo0oOOOO * i11iIiiIii - I111i1i1111i / oooO0oo0oOOOO
   for oOOOo00O00O in O0OoO0ooOO0o :
    name = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
    url = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    Oo000ooOOO . append ( name )
    Ii11i1I11i . append ( url )
    if "hd" in name . lower ( ) :
     I11i1 . append ( "1" )
    else :
     I11i1 . append ( "0" )
    oO0o00ooO = list ( zip ( I11i1 , Oo000ooOOO , Ii11i1I11i ) )
    if 24 - 24: OOooO * i11iIiiIii * I1I1i1
 if o0oO0 == "true" :
  iIiIIIIIii = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if OO0oOOoo < 100 :
    I1IiiI . update ( OO0oOOoo )
    OO0oOOoo = OO0oOOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0i11I1I1I )
   O0OoO0ooOO0o = [ ]
   for oOOOo00O00O in iiI1iI111ii1i :
    O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
    for iIIIII1I , oo in iiIIi :
     O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
    O0OoO0ooOO0o . append ( O0i11I1I1I )
    if 85 - 85: O0Oooo00 . i1iIii1Ii1II / O000oo . Ii1I % ooO00oo
   for oOOOo00O00O in O0OoO0ooOO0o :
    name = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
    url = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    Oo000ooOOO . append ( name )
    Ii11i1I11i . append ( url )
    if "hd" in name . lower ( ) :
     I11i1 . append ( "1" )
    else :
     I11i1 . append ( "0" )
    oO0o00ooO = list ( zip ( I11i1 , Oo000ooOOO , Ii11i1I11i ) )
    if 90 - 90: O0Oo0oO0o % Ii1I * OoOO . iI1
 if oo00 == "true" :
  iIiIIIIIii = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if OO0oOOoo < 100 :
    I1IiiI . update ( OO0oOOoo )
    OO0oOOoo = OO0oOOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0i11I1I1I )
   O0OoO0ooOO0o = [ ]
   for oOOOo00O00O in iiI1iI111ii1i :
    O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
    for iIIIII1I , oo in iiIIi :
     O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
    O0OoO0ooOO0o . append ( O0i11I1I1I )
    if 8 - 8: O000oo + i1I1ii1II1iII / iI1 / iiIIIIi1i1
   for oOOOo00O00O in O0OoO0ooOO0o :
    name = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
    url = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    Oo000ooOOO . append ( name )
    Ii11i1I11i . append ( url )
    if "hd" in name . lower ( ) :
     I11i1 . append ( "1" )
    else :
     I11i1 . append ( "0" )
    oO0o00ooO = list ( zip ( I11i1 , Oo000ooOOO , Ii11i1I11i ) )
    if 74 - 74: Ii1I / o0000oOoOoO0o
 if iIiIIIIIii == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 78 - 78: OoOO0ooOOoo0O . II1iI + O000oo - o0000oOoOoO0o
 ii1 = sorted ( oO0o00ooO , key = lambda Ooo : int ( Ooo [ 0 ] ) , reverse = True )
 O0iII1 = sorted ( O0OoOO0oo0 )
 if 27 - 27: II1iI . iiIIIIi1i1 + i1iIii1Ii1II / OoOO % iI1 . O000oo
 I11II1i = 0
 if 14 - 14: Ii1Ii1iiii11 + I111i1i1111i - iI1 / Ii1I . ooO00oo
 I1IiiI . update ( 100 )
 if 45 - 45: ooO00oo
 IIiIi11i1 ( '                    [COLOR yellow][I]LINKS FOR ' + ooOoOO0OoO00o . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 83 - 83: i1iIii1Ii1II . OoOO0ooOOoo0O
 if 58 - 58: i11iIiiIii + OoOO0ooOOoo0O % OoOO0ooOOoo0O / OOooO / i11iIiiIii
 for Ii1i1iI in O0iII1 :
  if 62 - 62: II1iI / I111i1i1111i
  IIiIi11i1 ( '                                  [COLOR mediumpurple][I]' + Ii1i1iI . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 7 - 7: OoOO0ooOOoo0O . OOooO
  OOOoOoO = Ii1i1iI . split ( ' ' )
  if 53 - 53: OOoOoo00oo % OOoOoo00oo * O0Oooo00 + i1iIii1Ii1II
  for Oooo00 , name , url in ii1 :
   if 6 - 6: OOoOoo00oo - O000oo * I1I1i1 . iI1 / Ii1I * O000oo
   II11iI111i1 = 0
   if 95 - 95: OoOO0ooOOoo0O - OOooO * oooO0oo0oOOOO + i1iIii1Ii1II
   for iIi1 in OOOoOoO :
    if 21 - 21: iiIIIIi1i1
    if not iIi1 . lower ( ) in name . lower ( ) :
     II11iI111i1 = 1
     if 92 - 92: i11iIiiIii / ooO00oo - iI1 % O000oo * ooO00oo + O0Oo0oO0o
   if II11iI111i1 == 0 :
    I11II1i = I11II1i + 1
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 11 - 11: OoOO0ooOOoo0O . ooO00oo
  if I11II1i == 0 :
   IIiIi11i1 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 80 - 80: OoOO0ooOOoo0O - I1I1i1 * OOoOoo00oo * I111i1i1111i / oooO0oo0oOOOO / I1I1i1
  OOOoOoO = ""
  if 13 - 13: ooO00oo * O000oo + i11iIiiIii * ooO00oo - O000oo
 I1IiiI . close ( )
 if 23 - 23: OoOO * o0000oOoOoO0o % OoOO0ooOOoo0O * OOooO
def I1Iiiiiii ( name , url , iconimage ) :
 if 39 - 39: OOooO * O0Oo0oO0o + OoOO - OOooO + I1I1i1
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 69 - 69: Ii1I
 OO0oOOoo = 0
 try :
  ooOoOO0OoO00o , Ii1i1iI , iconimage = url . split ( '!' )
 except :
  try :
   Ii1i1iI , iconimage = url . split ( '!' )
   ooOoOO0OoO00o = Ii1i1iI
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 85 - 85: O000oo / Ii1I
 iI1iIIIi1i = 0
 if 89 - 89: OoOO
 if "all " in name . lower ( ) :
  Ii1i1iI = Ii1i1iI . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  ooOoOO0OoO00o = ooOoOO0OoO00o . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  iI1iIIIi1i = 1
  if 21 - 21: iiIIIIi1i1 % iiIIIIi1i1
 Oo000ooOOO = [ ]
 Ii11i1I11i = [ ]
 I11i1 = [ ]
 I1IiiI . update ( 0 )
 iIiIIIIIii = 0
 if O0oO == "true" :
  iIiIIIIIii = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if OO0oOOoo < 100 :
    I1IiiI . update ( OO0oOOoo )
    OO0oOOoo = OO0oOOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0i11I1I1I )
   O0OoO0ooOO0o = [ ]
   for oOOOo00O00O in iiI1iI111ii1i :
    O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
    for iIIIII1I , oo in iiIIi :
     O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
    O0OoO0ooOO0o . append ( O0i11I1I1I )
    if 27 - 27: i11iIiiIii / I111i1i1111i
   for oOOOo00O00O in O0OoO0ooOO0o :
    name = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
    url = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    Oo000ooOOO . append ( name )
    Ii11i1I11i . append ( url )
    if "hd" in name . lower ( ) :
     I11i1 . append ( "1" )
    else :
     I11i1 . append ( "0" )
    oO0o00ooO = list ( zip ( I11i1 , Oo000ooOOO , Ii11i1I11i ) )
    if 84 - 84: O0Oo0oO0o
 if o0oO0 == "true" :
  iIiIIIIIii = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if OO0oOOoo < 100 :
    I1IiiI . update ( OO0oOOoo )
    OO0oOOoo = OO0oOOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0i11I1I1I )
   O0OoO0ooOO0o = [ ]
   for oOOOo00O00O in iiI1iI111ii1i :
    O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
    for iIIIII1I , oo in iiIIi :
     O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
    O0OoO0ooOO0o . append ( O0i11I1I1I )
    if 43 - 43: Ii1Ii1iiii11 - OoOO0ooOOoo0O
   for oOOOo00O00O in O0OoO0ooOO0o :
    name = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
    url = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    Oo000ooOOO . append ( name )
    Ii11i1I11i . append ( url )
    if "hd" in name . lower ( ) :
     I11i1 . append ( "1" )
    else :
     I11i1 . append ( "0" )
    oO0o00ooO = list ( zip ( I11i1 , Oo000ooOOO , Ii11i1I11i ) )
    if 3 - 3: Ii1I / iI1
 if oo00 == "true" :
  iIiIIIIIii = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if OO0oOOoo < 100 :
    I1IiiI . update ( OO0oOOoo )
    OO0oOOoo = OO0oOOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0i11I1I1I )
   O0OoO0ooOO0o = [ ]
   for oOOOo00O00O in iiI1iI111ii1i :
    O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
    for iIIIII1I , oo in iiIIi :
     O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
    O0OoO0ooOO0o . append ( O0i11I1I1I )
    if 31 - 31: I1I1i1 + O0Oooo00 . OoOO0ooOOoo0O
   for oOOOo00O00O in O0OoO0ooOO0o :
    name = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
    url = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    Oo000ooOOO . append ( name )
    Ii11i1I11i . append ( url )
    if "hd" in name . lower ( ) :
     I11i1 . append ( "1" )
    else :
     I11i1 . append ( "0" )
    oO0o00ooO = list ( zip ( I11i1 , Oo000ooOOO , Ii11i1I11i ) )
    if 89 - 89: i1I1ii1II1iII + o0000oOoOoO0o + i1I1ii1II1iII
 if iIiIIIIIii == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 7 - 7: Ii1I % O0Oooo00 + I111i1i1111i * iI1 - iI1
 ii1 = sorted ( oO0o00ooO , key = lambda Ooo : int ( Ooo [ 0 ] ) , reverse = True )
 if 42 - 42: i1iIii1Ii1II * i1iIii1Ii1II * ooO00oo . iiIIIIi1i1
 I11II1i = 0
 if 51 - 51: I1I1i1 % OoOO - OoOO0ooOOoo0O % O000oo * OoOO % II1iI
 I1IiiI . update ( 100 )
 if 99 - 99: Ii1Ii1iiii11 * i1I1ii1II1iII * ooO00oo
 IIiIi11i1 ( '                                [COLOR yellow][I]LINKS FOR ' + ooOoOO0OoO00o . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 OOOoOoO = Ii1i1iI . split ( ' ' )
 for Oooo00 , name , url in ii1 :
  if iI1iIIIi1i == 1 :
   oOooO0 = name
   if 79 - 79: II1iI - OoOO + OOoOoo00oo - ooO00oo
  II11iI111i1 = 0
  if 93 - 93: i1I1ii1II1iII . oooO0oo0oOOOO - O0Oo0oO0o + i1iIii1Ii1II
  for iIi1 in OOOoOoO :
   if 61 - 61: i1I1ii1II1iII
   if not iIi1 . lower ( ) in name . lower ( ) :
    II11iI111i1 = 1
    if 15 - 15: i11iIiiIii % oooO0oo0oOOOO * iiIIIIi1i1 / ooO00oo
  if II11iI111i1 == 0 :
   I11II1i = I11II1i + 1
   if iI1iIIIi1i == 1 :
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                          [COLOR blue] ' + str ( oOooO0 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                          [COLOR blue] ' + str ( oOooO0 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 90 - 90: iI1
 if I11II1i == 0 :
  IIiIi11i1 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 31 - 31: I1I1i1 + Ii1I
 I1IiiI . close ( )
 if 87 - 87: O000oo
def IIIii ( term ) :
 if 83 - 83: OOooO % O0Oooo00 % oooO0oo0oOOOO . OoOO - OOooO
 I1I1I = [ ]
 OoOO000 = [ ]
 if 88 - 88: OoOO0ooOOoo0O
 I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = IIiiiiiiIi1I1
  if 84 - 84: i1iIii1Ii1II / iiIIIIi1i1 * iI1 / Ii1Ii1iiii11 - i11iIiiIii . O0Oo0oO0o
  O0O0oOO00O00o = O0O0oOO00O00o . replace ( '#AAASTREAM:' , '#A:' )
  O0O0oOO00O00o = O0O0oOO00O00o . replace ( '#EXTINF:' , '#A:' )
  iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O0O0oOO00O00o )
  iiI1iI111ii1i = [ ]
  for Ii1IIiI1IiIII , OO0Oo000OOOoO , O0O0oOO00O00o in iiIIi :
   O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : O0O0oOO00O00o }
   iiI1iI111ii1i . append ( O0i11I1I1I )
  list = [ ]
  for oOOOo00O00O in iiI1iI111ii1i :
   O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
   iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
   for iIIIII1I , oo in iiIIi :
    O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
   list . append ( O0i11I1I1I )
   if 60 - 60: I111i1i1111i * oooO0oo0oOOOO
  for oOOOo00O00O in list :
   O000OO0 = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
   O0O0oOO00O00o = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
   O0O0oOO00O00o = O0O0oOO00O00o . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in O000OO0 . lower ( ) :
    I1I1I . append ( O0O0oOO00O00o )
    OoOO000 . append ( O000OO0 )
    if 17 - 17: I1I1i1 % O0Oo0oO0o / I111i1i1111i . OOooO * I1I1i1 - i1I1ii1II1iII
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , OoOO000 )
 if OO < 0 :
  quit ( )
  if 41 - 41: OOoOoo00oo
 O0O0oOO00O00o = I1I1I [ OO ]
 O000OO0 = OoOO000 [ OO ]
 oOo0oO ( O000OO0 , O0O0oOO00O00o , iiiii )
 if 77 - 77: ooO00oo
def Oo ( name , url , iconimage ) :
 if 81 - 81: Ii1Ii1iiii11 * II1iI
 list = iI11I ( url )
 for oOOOo00O00O in list :
  name = ooooO0oOoOOoO ( oOOOo00O00O [ "display_name" ] )
  url = ooooO0oOoOOoO ( oOOOo00O00O [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  IIiIi11i1 ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 11 - 11: iI1 - Ii1Ii1iiii11 + i1I1ii1II1iII - OoOO
def iI11I ( url ) :
 if 7 - 7: OOooO - iiIIIIi1i1 / i1I1ii1II1iII * OOoOoo00oo . iI1 * iI1
 O0O0oOOo0O = II11 ( url )
 O0O0oOOo0O = O0O0oOOo0O . replace ( '#AAASTREAM:' , '#A:' )
 O0O0oOOo0O = O0O0oOOo0O . replace ( '#EXTINF:' , '#A:' )
 iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O0O0oOOo0O )
 iiI1iI111ii1i = [ ]
 for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
  O0i11I1I1I = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
  iiI1iI111ii1i . append ( O0i11I1I1I )
 list = [ ]
 for oOOOo00O00O in iiI1iI111ii1i :
  O0i11I1I1I = { "display_name" : oOOOo00O00O [ "display_name" ] , "url" : oOOOo00O00O [ "url" ] }
  iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( oOOOo00O00O [ "params" ] )
  for iIIIII1I , oo in iiIIi :
   O0i11I1I1I [ iIIIII1I . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oo . strip ( )
  list . append ( O0i11I1I1I )
  if 68 - 68: iI1 * OoOO0ooOOoo0O * OoOO . i1I1ii1II1iII
 return list
 if 81 - 81: I1I1i1 / Ii1I + iiIIIIi1i1 + OOoOoo00oo / oooO0oo0oOOOO
 if 27 - 27: i1iIii1Ii1II * OOooO
def O0Ooo0oo ( ) :
 if 41 - 41: i1iIii1Ii1II * iiIIIIi1i1 / i1iIii1Ii1II % Ii1Ii1iiii11
 I11iii1Ii ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 I11iii1Ii ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 I11iii1Ii ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 18 - 18: i1I1ii1II1iII . OoOO0ooOOoo0O % i1iIii1Ii1II % OOoOoo00oo
def II1IiiIii ( name , url , iconimage ) :
 if 84 - 84: Ii1Ii1iiii11 % o0000oOoOoO0o
 oOO = datetime . datetime . now ( )
 Ii1II = oOO . day
 if 89 - 89: ooO00oo + OoOO0ooOOoo0O + ooO00oo * o0000oOoOoO0o + OoOO % iiIIIIi1i1
 oOo0oOIIi1IIIIi = Ii1II
 if 70 - 70: I1I1i1 / i1I1ii1II1iII - OoOO - iI1
 Iii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIi1i = datetime . datetime . strftime ( Iii , '%A - %d %B %Y' )
 i1ii = 'http://www.predictz.com/predictions/'
 if 68 - 68: I1I1i1 * Ii1I . iiIIIIi1i1 - i1I1ii1II1iII . O000oo / i1I1ii1II1iII
 iii1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1i = datetime . datetime . strftime ( iii1 , '%A - %d %B %Y' )
 OOOO = datetime . datetime . strftime ( iii1 , '%d' )
 ooO0oO00O0o = 'http://www.predictz.com/predictions/tomorrow/'
 if 70 - 70: ooO00oo
 i11iIIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooOooo000OO00 = datetime . datetime . strftime ( i11iIIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiIiI1I1I1 = datetime . datetime . strftime ( i11iIIi11 , '%y%m%d' )
 I11 = 'http://www.predictz.com/predictions/20' + str ( IiIiI1I1I1 )
 if 87 - 87: i1iIii1Ii1II
 Ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 oO0O = datetime . datetime . strftime ( Ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oOOiiiIIiIi = datetime . datetime . strftime ( Ii , '%y%m%d' )
 OooOOO = 'http://www.predictz.com/predictions/20' + str ( oOOiiiIIiIi )
 if 48 - 48: OoOO % o0000oOoOoO0o % iI1 + O000oo
 Iiii11iIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 i1iI11I1II1 = datetime . datetime . strftime ( Iiii11iIi1 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii11II1i = datetime . datetime . strftime ( Iiii11iIi1 , '%y%m%d' )
 OOO = 'http://www.predictz.com/predictions/20' + str ( ii11II1i )
 if 89 - 89: O000oo + OOoOoo00oo * O000oo / O000oo
 if 46 - 46: II1iI
 I11iii1Ii ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIi1i ) + '[/B][/COLOR]' , i1ii , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1i ) + '[/B][/COLOR]' , ooO0oO00O0o , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( ooOooo000OO00 ) , I11 , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( oO0O ) , OooOOO , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( i1iI11I1II1 ) , OOO , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 71 - 71: iiIIIIi1i1 / iiIIIIi1i1 * Ii1Ii1iiii11 * Ii1Ii1iiii11 / i1I1ii1II1iII
def II1I1iiIII1I1 ( name , url , iconimage ) :
 if 85 - 85: iI1 * O0Oooo00
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( I1i1I )
 OOOoOoO = str ( ooooooO0oo )
 iIIIII1ii1I = re . compile ( '<tr(.+?)</tr>' ) . findall ( OOOoOoO )
 for IIiiiiiiIi1I1 in iIIIII1ii1I :
  try :
   I1II1I11I1I = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   IIiIi11i1 ( '#############################################' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[COLOR red][B]' + I1II1I11I1I + ' Predictions[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '#############################################' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OoOo00o0o = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   ii1iii11i1 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   o0OoOo00o0o = I11Oo00oO0O ( o0OoOo00o0o )
   ii1iii11i1 = I11Oo00oO0O ( ii1iii11i1 )
   IIiIi11i1 ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + ii1iii11i1 + ' [/B][/COLOR]| [COLOR mediumpurple]' + o0OoOo00o0o + '[/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 96 - 96: I111i1i1111i / i1I1ii1II1iII . OOoOoo00oo - iI1 * iiIIIIi1i1 * Ii1Ii1iiii11
def O00oo0ooO ( name , url , iconimage ) :
 if 38 - 38: OoOO - i1I1ii1II1iII - oooO0oo0oOOOO
 oOO = datetime . datetime . now ( )
 Ii1II = oOO . day
 if 71 - 71: OoOO0ooOOoo0O
 oOo0oOIIi1IIIIi = Ii1II
 if 33 - 33: ooO00oo
 Iii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIi1i = datetime . datetime . strftime ( Iii , '%A - %d %B %Y' )
 i1ii = 'http://www.predictz.com/predictions/'
 if 62 - 62: I111i1i1111i + OOoOoo00oo + o0000oOoOoO0o / OoOO0ooOOoo0O
 iii1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1i = datetime . datetime . strftime ( iii1 , '%A - %d %B %Y' )
 OOOO = datetime . datetime . strftime ( iii1 , '%d' )
 ooO0oO00O0o = 'http://www.predictz.com/predictions/tomorrow/'
 if 7 - 7: O0Oooo00 + o0000oOoOoO0o . oooO0oo0oOOOO / O0Oo0oO0o
 i11iIIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooOooo000OO00 = datetime . datetime . strftime ( i11iIIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiIiI1I1I1 = datetime . datetime . strftime ( i11iIIi11 , '%y%m%d' )
 I11 = 'http://www.predictz.com/predictions/20' + str ( IiIiI1I1I1 )
 if 22 - 22: O000oo - O000oo % I1I1i1 . ooO00oo + Ii1Ii1iiii11
 Ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 oO0O = datetime . datetime . strftime ( Ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oOOiiiIIiIi = datetime . datetime . strftime ( Ii , '%y%m%d' )
 OooOOO = 'http://www.predictz.com/predictions/20' + str ( oOOiiiIIiIi )
 if 63 - 63: oooO0oo0oOOOO % ooO00oo * O0Oooo00 + ooO00oo / O0Oo0oO0o % iI1
 Iiii11iIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 i1iI11I1II1 = datetime . datetime . strftime ( Iiii11iIi1 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii11II1i = datetime . datetime . strftime ( Iiii11iIi1 , '%y%m%d' )
 OOO = 'http://www.predictz.com/predictions/20' + str ( ii11II1i )
 if 45 - 45: OOooO
 if 20 - 20: OoOO0ooOOoo0O * O0Oooo00 * Ii1I . I1I1i1
 I11iii1Ii ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIi1i ) + '[/B][/COLOR]' , i1ii , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1i ) + '[/B][/COLOR]' , ooO0oO00O0o , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( ooOooo000OO00 ) , I11 , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( oO0O ) , OooOOO , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( i1iI11I1II1 ) , OOO , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 78 - 78: OoOO + iiIIIIi1i1 - OOoOoo00oo * ooO00oo - OoOO0ooOOoo0O % i1iIii1Ii1II
def i1OoOO ( name , url , iconimage ) :
 if 44 - 44: I1I1i1
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( I1i1I )
 OOOoOoO = str ( ooooooO0oo )
 iIIIII1ii1I = re . compile ( '<tr(.+?)</tr>' ) . findall ( OOOoOoO )
 for IIiiiiiiIi1I1 in iIIIII1ii1I :
  try :
   I1II1I11I1I = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   IIiIi11i1 ( '#############################################' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[COLOR red][B]' + I1II1I11I1I + '[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '#############################################' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OoOo00o0o = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0O0o0o0o = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   IIIIIiI = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 1 ]
   Oo0000O0OOooO = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 2 ]
   o0OoOo00o0o = I11Oo00oO0O ( o0OoOo00o0o )
   IIiIi11i1 ( '[COLOR mediumpurple][B]' + o0OoOo00o0o + '[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + O0O0o0o0o + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + IIIIIiI + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + Oo0000O0OOooO + ')[/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 54 - 54: iiIIIIi1i1 / oooO0oo0oOOOO * Ii1Ii1iiii11 + OoOO0ooOOoo0O - iI1 / OoOO0ooOOoo0O
def I111IIiii1Ii ( name , url , iconimage ) :
 if 13 - 13: Ii1Ii1iiii11 . oooO0oo0oOOOO * Ii1Ii1iiii11 + oooO0oo0oOOOO
 oOO = datetime . datetime . now ( )
 Ii1II = oOO . day
 if 59 - 59: oooO0oo0oOOOO + i11iIiiIii + o0000oOoOoO0o / iiIIIIi1i1
 oOo0oOIIi1IIIIi = Ii1II
 if 44 - 44: iiIIIIi1i1 . i1iIii1Ii1II * oooO0oo0oOOOO + OoOO0ooOOoo0O - iI1 - OOooO
 Iii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIi1i = datetime . datetime . strftime ( Iii , '%A - %d %B %Y' )
 i1ii = 'http://www.predictz.com/predictions/'
 if 15 - 15: OOooO / Ii1I . O0Oooo00 . i11iIiiIii
 iii1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 I1i = datetime . datetime . strftime ( iii1 , '%A - %d %B %Y' )
 OOOO = datetime . datetime . strftime ( iii1 , '%d' )
 ooO0oO00O0o = 'http://www.predictz.com/predictions/tomorrow/'
 if 59 - 59: ooO00oo - O0Oooo00 - O000oo
 i11iIIi11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 ooOooo000OO00 = datetime . datetime . strftime ( i11iIIi11 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiIiI1I1I1 = datetime . datetime . strftime ( i11iIIi11 , '%y%m%d' )
 I11 = 'http://www.predictz.com/predictions/20' + str ( IiIiI1I1I1 )
 if 48 - 48: o0000oOoOoO0o + iiIIIIi1i1 % i1iIii1Ii1II / O0Oo0oO0o - O0Oooo00
 Ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 oO0O = datetime . datetime . strftime ( Ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oOOiiiIIiIi = datetime . datetime . strftime ( Ii , '%y%m%d' )
 OooOOO = 'http://www.predictz.com/predictions/20' + str ( oOOiiiIIiIi )
 if 67 - 67: Ii1Ii1iiii11 % O0Oooo00 . OoOO0ooOOoo0O + I1I1i1 * iiIIIIi1i1 * i1iIii1Ii1II
 Iiii11iIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 i1iI11I1II1 = datetime . datetime . strftime ( Iiii11iIi1 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ii11II1i = datetime . datetime . strftime ( Iiii11iIi1 , '%y%m%d' )
 OOO = 'http://www.predictz.com/predictions/20' + str ( ii11II1i )
 if 36 - 36: Ii1I + O0Oo0oO0o
 if 5 - 5: O0Oo0oO0o * i1iIii1Ii1II
 I11iii1Ii ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIi1i ) + '[/B][/COLOR]' , i1ii , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( I1i ) + '[/B][/COLOR]' , ooO0oO00O0o , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( ooOooo000OO00 ) , I11 , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( oO0O ) , OooOOO , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( i1iI11I1II1 ) , OOO , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 46 - 46: O000oo
def I11iIiII ( name , url , iconimage ) :
 if 66 - 66: O0Oo0oO0o - O0Oooo00 * OOooO + i1iIii1Ii1II + O0Oooo00 - OoOO
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( I1i1I )
 OOOoOoO = str ( ooooooO0oo )
 iIIIII1ii1I = re . compile ( '<tr(.+?)</tr>' ) . findall ( OOOoOoO )
 for IIiiiiiiIi1I1 in iIIIII1ii1I :
  try :
   I1II1I11I1I = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   IIiIi11i1 ( '#############################################' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[COLOR red][B]' + I1II1I11I1I + '[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '#############################################' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OoOo00o0o = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   I11II1i , IIIII = o0OoOo00o0o . split ( ' v ' )
   iiiI1ii11 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   ii1i = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 1 ]
   IIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 2 ]
   oo0OO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 3 ]
   IiiI11i1I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 4 ]
   OOo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 5 ]
   iiIii1IIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 6 ]
   ii1IiIiI1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 7 ]
   OOOoOo00O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 8 ]
   O0ooOo0o0Oo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 9 ]
   if 71 - 71: OoOO - I1I1i1 . oooO0oo0oOOOO % OoOO0ooOOoo0O + I1I1i1
   if iiiI1ii11 == "W" :
    iiiI1ii11 = '[COLOR lime]W[/COLOR]'
   elif iiiI1ii11 == "D" :
    iiiI1ii11 = '[COLOR yellow]D[/COLOR]'
   else : iiiI1ii11 = '[COLOR red]L[/COLOR]'
   if 26 - 26: O0Oo0oO0o + I1I1i1 / II1iI % i1iIii1Ii1II % I111i1i1111i + i1I1ii1II1iII
   if ii1i == "W" :
    ii1i = '[COLOR lime]W[/COLOR]'
   elif ii1i == "D" :
    ii1i = '[COLOR yellow]D[/COLOR]'
   else : ii1i = '[COLOR red]L[/COLOR]'
   if 31 - 31: iiIIIIi1i1 % I1I1i1 * iiIIIIi1i1
   if IIi == "W" :
    IIi = '[COLOR lime]W[/COLOR]'
   elif IIi == "D" :
    IIi = '[COLOR yellow]D[/COLOR]'
   else : IIi = '[COLOR red]L[/COLOR]'
   if 45 - 45: o0000oOoOoO0o . oooO0oo0oOOOO + I1I1i1 - OoOO0ooOOoo0O % O000oo
   if oo0OO == "W" :
    oo0OO = '[COLOR lime]W[/COLOR]'
   elif oo0OO == "D" :
    oo0OO = '[COLOR yellow]D[/COLOR]'
   else : oo0OO = '[COLOR red]L[/COLOR]'
   if 1 - 1: OoOO
   if IiiI11i1I == "W" :
    IiiI11i1I = '[COLOR lime]W[/COLOR]'
   elif IiiI11i1I == "D" :
    IiiI11i1I = '[COLOR yellow]D[/COLOR]'
   else : IiiI11i1I = '[COLOR red]L[/COLOR]'
   if 93 - 93: o0000oOoOoO0o . i11iIiiIii . O0Oo0oO0o
   if OOo0 == "W" :
    OOo0 = '[COLOR lime]W[/COLOR]'
   elif OOo0 == "D" :
    OOo0 = '[COLOR yellow]D[/COLOR]'
   else : OOo0 = '[COLOR red]L[/COLOR]'
   if 99 - 99: iiIIIIi1i1 - ooO00oo - Ii1Ii1iiii11 % II1iI
   if iiIii1IIi == "W" :
    iiIii1IIi = '[COLOR lime]W[/COLOR]'
   elif iiIii1IIi == "D" :
    iiIii1IIi = '[COLOR yellow]D[/COLOR]'
   else : iiIii1IIi = '[COLOR red]L[/COLOR]'
   if 21 - 21: i1I1ii1II1iII % I111i1i1111i . o0000oOoOoO0o - OoOO0ooOOoo0O
   if ii1IiIiI1 == "W" :
    ii1IiIiI1 = '[COLOR lime]W[/COLOR]'
   elif ii1IiIiI1 == "D" :
    ii1IiIiI1 = '[COLOR yellow]D[/COLOR]'
   else : ii1IiIiI1 = '[COLOR red]L[/COLOR]'
   if 4 - 4: OoOO0ooOOoo0O . O000oo
   if OOOoOo00O == "W" :
    OOOoOo00O = '[COLOR lime]W[/COLOR]'
   elif OOOoOo00O == "D" :
    OOOoOo00O = '[COLOR yellow]D[/COLOR]'
   else : OOOoOo00O = '[COLOR red]L[/COLOR]'
   if 78 - 78: I111i1i1111i + iiIIIIi1i1 - Ii1I
   if O0ooOo0o0Oo == "W" :
    O0ooOo0o0Oo = '[COLOR lime]W[/COLOR]'
   elif O0ooOo0o0Oo == "D" :
    O0ooOo0o0Oo = '[COLOR yellow]D[/COLOR]'
   else : O0ooOo0o0Oo = '[COLOR red]L[/COLOR]'
   if 10 - 10: ooO00oo % oooO0oo0oOOOO
   I11II1i = I11Oo00oO0O ( I11II1i )
   IIIII = I11Oo00oO0O ( IIIII )
   IIiIi11i1 ( '[COLOR mediumpurple][B]' + I11II1i + ' Form Guide[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[B]' + iiiI1ii11 + '  ' + ii1i + '  ' + IIi + '  ' + oo0OO + '  ' + IiiI11i1I + '[/B]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[COLOR mediumpurple][B]' + IIIII + ' Form Guide[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[B]' + OOo0 + '  ' + iiIii1IIi + '  ' + ii1IiIiI1 + '  ' + OOOoOo00O + '  ' + O0ooOo0o0Oo + '[/B]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 97 - 97: OoOO0ooOOoo0O - ooO00oo
def oooo00 ( ) :
 if 96 - 96: I111i1i1111i % O000oo % OOoOoo00oo - O000oo % i1iIii1Ii1II + I111i1i1111i
 OOOoOoO = ''
 iI = xbmc . Keyboard ( OOOoOoO , 'Enter Search Term' )
 iI . doModal ( )
 if iI . isConfirmed ( ) :
  OOOoOoO = iI . getText ( )
  if len ( OOOoOoO ) > 1 :
   O0O0oOO00O00o = OOOoOoO + "!" + iiiii
   I1Iiiiiii ( "all " + OOOoOoO , O0O0oOO00O00o , iiiii )
  else : quit ( )
  if 100 - 100: oooO0oo0oOOOO / O0Oooo00 * iI1 . Ii1I / I1I1i1
def oOO0o000Oo00o ( name , url , iconimage ) :
 if 21 - 21: OoOO0ooOOoo0O - OoOO
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 93 - 93: Ii1Ii1iiii11 - O0Oooo00 % i1iIii1Ii1II . i1iIii1Ii1II - O000oo
  if 90 - 90: O000oo + i1I1ii1II1iII * I111i1i1111i / OOoOoo00oo . O0Oooo00 + O0Oooo00
  if 40 - 40: O000oo / i1iIii1Ii1II % i11iIiiIii % I111i1i1111i / oooO0oo0oOOOO
  if 62 - 62: o0000oOoOoO0o - i1iIii1Ii1II
  if 62 - 62: o0000oOoOoO0o + O0Oo0oO0o % OOooO
def iIi ( name ) :
 if 10 - 10: II1iI / O0Oo0oO0o
 I1I = 0
 if 15 - 15: iI1 . i1iIii1Ii1II / iI1 * iiIIIIi1i1 - oooO0oo0oOOOO % I111i1i1111i
 try :
  oOO00oOO ( "http://www.google.com" )
 except :
  O00ooooo00 . ok ( Oo0Ooo , '[COLOR red]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/COLOR]' )
  sys . exit ( 0 )
  if 57 - 57: Ii1I % i1iIii1Ii1II % Ii1Ii1iiii11
 try :
  I1IiiI . create ( Oo0Ooo , "Checking for repository updates" , '' , 'Please Wait...' )
  I1IiiI . update ( 0 )
  I11II1i = open ( I11i11Ii ) . read ( )
  IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   I1IiiI . update ( 25 )
   I1IIIii = float ( IIiiiiiiIi1I1 ) + 0.01
   O0O0oOO00O00o = OOOo0 + str ( I1IIIii ) + '.zip'
   I1i1I11I = oOO00oOO ( O0O0oOO00O00o )
   if "Not Found" not in I1i1I11I :
    I1I = 1
    I1IiiI . update ( 75 )
    i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( i1iIIi1 ) :
     os . makedirs ( i1iIIi1 )
    iI1iii = os . path . join ( i1iIIi1 , 'repoupdate.zip' )
    try : os . remove ( iI1iii )
    except : pass
    I1IiiI . update ( 100 )
    I1IiiI . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( O0O0oOO00O00o , iI1iii , I1IiiI )
    OOOo = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    I1IiiI . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( iI1iii , OOOo , I1IiiI )
    try : os . remove ( iI1iii )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    O00ooooo00 . ok ( Oo0Ooo , "ECHO repository was updated to " + str ( I1IIIii ) + ', you may need to restart the addon for changes to take effect' )
    if 79 - 79: i1iIii1Ii1II % OOooO % O0Oo0oO0o
  I1IiiI . update ( 75 , "Checking for addon updates" )
  I11II1i = open ( IIi1IiiiI1Ii ) . read ( )
  IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   I1IIIii = float ( IIiiiiiiIi1I1 ) + 0.01
   O0O0oOO00O00o = oO00oOo + str ( I1IIIii ) + '.zip'
   I1i1I11I = oOO00oOO ( O0O0oOO00O00o )
   if "Not Found" not in I1i1I11I :
    I1I = 1
    I1IiiI . update ( 75 )
    i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( i1iIIi1 ) :
     os . makedirs ( i1iIIi1 )
    iI1iii = os . path . join ( i1iIIi1 , 'wizupdate.zip' )
    try : os . remove ( iI1iii )
    except : pass
    I1IiiI . update ( 100 )
    I1IiiI . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( O0O0oOO00O00o , iI1iii , I1IiiI )
    OOOo = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    I1IiiI . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( iI1iii , OOOo , I1IiiI )
    try : os . remove ( iI1iii )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    I1IiiI . update ( 100 )
    I1IiiI . close
    O00ooooo00 . ok ( Oo0Ooo , "Sportie was updated to " + str ( I1IIIii ) + ', you may need to restart the addon for changes to take effect' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , 'Sorry! We encountered an error whilst checking for updates. You can make Kodi force check the repository for updates as an alternative if you wish.' )
  quit ( )
  if 29 - 29: OoOO0ooOOoo0O . oooO0oo0oOOOO % I111i1i1111i - iI1
 if I1IiiI . iscanceled ( ) :
  I1IiiI . close ( )
 else :
  if I1I == 0 :
   if not name == "no dialog" :
    O00ooooo00 . ok ( Oo0Ooo , "There are no updates at this time." )
    quit ( )
    if 8 - 8: o0000oOoOoO0o
def i1iI1 ( text ) :
 if 32 - 32: Ii1Ii1iiii11 / i1I1ii1II1iII
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 45 - 45: I111i1i1111i + II1iI * i11iIiiIii / I1I1i1 % iiIIIIi1i1 * Ii1I
 return text
 if 17 - 17: Ii1I
def I11Oo00oO0O ( text ) :
 if 88 - 88: O0Oo0oO0o . Ii1I % OoOO0ooOOoo0O / I1I1i1
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 89 - 89: i1I1ii1II1iII / Ii1Ii1iiii11
 return text
 if 14 - 14: I1I1i1 . oooO0oo0oOOOO * O000oo + i1I1ii1II1iII - O000oo + I1I1i1
def IIiI1 ( text ) :
 if 18 - 18: Ii1Ii1iiii11 - O0Oooo00 - oooO0oo0oOOOO - oooO0oo0oOOOO
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 54 - 54: O0Oo0oO0o + oooO0oo0oOOOO / iI1 . oooO0oo0oOOOO * i1iIii1Ii1II
 return text
 if 1 - 1: i1iIii1Ii1II * II1iI . o0000oOoOoO0o / O0Oo0oO0o . I111i1i1111i + O0Oo0oO0o
def oOo0oO ( name , url , iconimage ) :
 if 17 - 17: O0Oo0oO0o + II1iI / OOoOoo00oo / iI1 * I1I1i1
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 29 - 29: II1iI % OoOO0ooOOoo0O * Ii1Ii1iiii11 / i1I1ii1II1iII - Ii1Ii1iiii11
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 19 - 19: i11iIiiIii
 oo0 = url
 oOOII1i11i1iIi11 = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 oOOII1i11i1iIi11 . setPath ( oo0 )
 xbmc . Player ( ) . play ( oo0 , oOOII1i11i1iIi11 , False )
 if 83 - 83: OOoOoo00oo
def oOO00oOO ( url ) :
 if 25 - 25: iiIIIIi1i1 + i1iIii1Ii1II . O0Oooo00 % i1iIii1Ii1II * I1I1i1
 ii1IiIi11 = urllib2 . Request ( url )
 ii1IiIi11 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 O0O0oOOo0O = urllib2 . urlopen ( ii1IiIi11 )
 I1i1I = O0O0oOOo0O . read ( )
 O0O0oOOo0O . close ( )
 I1i1I = I1i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return I1i1I
 if 22 - 22: Ii1Ii1iiii11
def II11 ( url ) :
 if 33 - 33: OoOO / OOoOoo00oo
 ii1IiIi11 = urllib2 . Request ( url )
 ii1IiIi11 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 O0O0oOOo0O = urllib2 . urlopen ( ii1IiIi11 )
 I1i1I = O0O0oOOo0O . read ( )
 O0O0oOOo0O . close ( )
 return I1i1I
 if 1 - 1: OOoOoo00oo
def ooooO0oOoOOoO ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 48 - 48: Ii1I + Ii1I . ooO00oo - O000oo
 if 63 - 63: Ii1Ii1iiii11
 if 71 - 71: o0000oOoOoO0o . OOoOoo00oo * iI1 % OoOO0ooOOoo0O + I1I1i1
 if 36 - 36: OOooO
 if 49 - 49: I1I1i1 / OoOO0ooOOoo0O / oooO0oo0oOOOO
def o0OooooOoOO ( ) :
 if 19 - 19: OOooO
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 78 - 78: I1I1i1 % O0Oooo00
 if os . path . exists ( Oooo000o ) == True :
  for IIIiIiI , I1ii1II1iII , II1i in os . walk ( Oooo000o ) :
   o0OO00oo = 0
   o0OO00oo += len ( II1i )
   if o0OO00oo > 0 :
    for i1i1IiIiIi1Ii in II1i :
     try :
      if ( i1i1IiIiIi1Ii . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( IIIiIiI , i1i1IiIiIi1Ii ) )
     except :
      pass
    for oO0ooOO in I1ii1II1iII :
     try :
      shutil . rmtree ( os . path . join ( IIIiIiI , oO0ooOO ) )
     except :
      pass
      if 16 - 16: O0Oo0oO0o + O000oo / O0Oo0oO0o / II1iI % Ii1Ii1iiii11 % I111i1i1111i
   else :
    pass
    if 22 - 22: i1I1ii1II1iII * II1iI * iiIIIIi1i1 + I111i1i1111i * O0Oooo00
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for IIIiIiI , I1ii1II1iII , II1i in os . walk ( IiIi11iIIi1Ii ) :
   o0OO00oo = 0
   o0OO00oo += len ( II1i )
   if o0OO00oo > 0 :
    for i1i1IiIiIi1Ii in II1i :
     try :
      if ( i1i1IiIiIi1Ii . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( IIIiIiI , i1i1IiIiIi1Ii ) )
     except :
      pass
    for oO0ooOO in I1ii1II1iII :
     try :
      shutil . rmtree ( os . path . join ( IIIiIiI , oO0ooOO ) )
     except :
      pass
      if 100 - 100: o0000oOoOoO0o / OOooO
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  IiII1iiIiI = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 59 - 59: Ii1I % O0Oo0oO0o
  for IIIiIiI , I1ii1II1iII , II1i in os . walk ( IiII1iiIiI ) :
   o0OO00oo = 0
   o0OO00oo += len ( II1i )
   if 92 - 92: OOoOoo00oo % iI1 / I111i1i1111i % I111i1i1111i * oooO0oo0oOOOO
   if o0OO00oo > 0 :
    for i1i1IiIiIi1Ii in II1i :
     os . unlink ( os . path . join ( IIIiIiI , i1i1IiIiIi1Ii ) )
    for oO0ooOO in I1ii1II1iII :
     shutil . rmtree ( os . path . join ( IIIiIiI , oO0ooOO ) )
     if 74 - 74: Ii1I . oooO0oo0oOOOO % II1iI % OOooO
   else :
    pass
  oOo0OooOo = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 51 - 51: iiIIIIi1i1 . O0Oo0oO0o
  for IIIiIiI , I1ii1II1iII , II1i in os . walk ( oOo0OooOo ) :
   o0OO00oo = 0
   o0OO00oo += len ( II1i )
   if 45 - 45: o0000oOoOoO0o - O0Oo0oO0o / Ii1I . I111i1i1111i
   if o0OO00oo > 0 :
    for i1i1IiIiIi1Ii in II1i :
     os . unlink ( os . path . join ( IIIiIiI , i1i1IiIiIi1Ii ) )
    for oO0ooOO in I1ii1II1iII :
     shutil . rmtree ( os . path . join ( IIIiIiI , oO0ooOO ) )
     if 5 - 5: O0Oooo00 . OoOO % OoOO
   else :
    pass
    if 56 - 56: OoOO0ooOOoo0O - iiIIIIi1i1 - o0000oOoOoO0o
 Oooo = OoO000 ( )
 if 8 - 8: ooO00oo / I1I1i1 . oooO0oo0oOOOO + I111i1i1111i / i11iIiiIii
 for I1Iii1iI1 in Oooo :
  o0 = xbmc . translatePath ( I1Iii1iI1 . path )
  if os . path . exists ( o0 ) == True :
   for IIIiIiI , I1ii1II1iII , II1i in os . walk ( o0 ) :
    o0OO00oo = 0
    o0OO00oo += len ( II1i )
    if o0OO00oo > 0 :
     for i1i1IiIiIi1Ii in II1i :
      os . unlink ( os . path . join ( IIIiIiI , i1i1IiIiIi1Ii ) )
     for oO0ooOO in I1ii1II1iII :
      shutil . rmtree ( os . path . join ( IIIiIiI , oO0ooOO ) )
      if 93 - 93: i11iIiiIii % OoOO % i11iIiiIii + O0Oooo00 / O0Oooo00 / i1I1ii1II1iII
    else :
     pass
     if 49 - 49: I1I1i1 . I111i1i1111i . i11iIiiIii - i1I1ii1II1iII / OOoOoo00oo
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 62 - 62: I1I1i1
def i1I1i ( ) :
 OO0oIiII1iiI = [ ]
 iII = sys . argv [ 2 ]
 if len ( iII ) >= 2 :
  Ii1IIiI1IiIII = sys . argv [ 2 ]
  oO0O000oOoo0O = Ii1IIiI1IiIII . replace ( '?' , '' )
  if ( Ii1IIiI1IiIII [ len ( Ii1IIiI1IiIII ) - 1 ] == '/' ) :
   Ii1IIiI1IiIII = Ii1IIiI1IiIII [ 0 : len ( Ii1IIiI1IiIII ) - 2 ]
  iIIiii11iIiiI = oO0O000oOoo0O . split ( '&' )
  OO0oIiII1iiI = { }
  for oo0O0oO in range ( len ( iIIiii11iIiiI ) ) :
   O0Oo0 = { }
   O0Oo0 = iIIiii11iIiiI [ oo0O0oO ] . split ( '=' )
   if ( len ( O0Oo0 ) ) == 2 :
    OO0oIiII1iiI [ O0Oo0 [ 0 ] ] = O0Oo0 [ 1 ]
 return OO0oIiII1iiI
 if 98 - 98: ooO00oo
def I11iii1Ii ( name , url , mode , iconimage , fanart , description = '' ) :
 if 92 - 92: ooO00oo - OoOO
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I11III111i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 o0Oo = True
 oOOII1i11i1iIi11 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oOOII1i11i1iIi11 . setProperty ( "fanart_Image" , fanart )
 oOOII1i11i1iIi11 . setProperty ( "icon_Image" , iconimage )
 o0Oo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11III111i , listitem = oOOII1i11i1iIi11 , isFolder = True )
 return o0Oo
 if 57 - 57: I1I1i1 / O0Oo0oO0o
def IIiIi11i1 ( name , url , mode , iconimage , fanart , description = '' ) :
 if 69 - 69: Ii1Ii1iiii11 - O0Oo0oO0o % OOooO
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I11III111i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 o0Oo = True
 oOOII1i11i1iIi11 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oOOII1i11i1iIi11 . setProperty ( "fanart_Image" , fanart )
 oOOII1i11i1iIi11 . setProperty ( "icon_Image" , iconimage )
 o0Oo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11III111i , listitem = oOOII1i11i1iIi11 , isFolder = False )
 return o0Oo
 if 50 - 50: OoOO0ooOOoo0O
Ii1IIiI1IiIII = i1I1i ( ) ; O0O0oOO00O00o = None ; O000OO0 = None ; IiI1i111IiIiIi1 = None ; i1II11II1 = None ; Oo0o00 = None ; O0 = None
try : i1II11II1 = urllib . unquote_plus ( Ii1IIiI1IiIII [ "site" ] )
except : pass
try : O0O0oOO00O00o = urllib . unquote_plus ( Ii1IIiI1IiIII [ "url" ] )
except : pass
try : O000OO0 = urllib . unquote_plus ( Ii1IIiI1IiIII [ "name" ] )
except : pass
try : IiI1i111IiIiIi1 = int ( Ii1IIiI1IiIII [ "mode" ] )
except : pass
try : Oo0o00 = urllib . unquote_plus ( Ii1IIiI1IiIII [ "iconimage" ] )
except : pass
try : O0 = urllib . unquote_plus ( Ii1IIiI1IiIII [ "fanart" ] )
except : pass
if 5 - 5: O0Oo0oO0o - I111i1i1111i % Ii1Ii1iiii11 - i1I1ii1II1iII . oooO0oo0oOOOO + iI1
if IiI1i111IiIiIi1 == None or O0O0oOO00O00o == None or len ( O0O0oOO00O00o ) < 1 : oO00O00o0OOO0 ( )
elif IiI1i111IiIiIi1 == 1 : III1iII1I1ii ( O000OO0 , O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 2 : oOo0oO ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 3 : IIi1 ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 4 : PLAYSD ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 8 : OoO0o ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 9 : iIi ( O000OO0 )
elif IiI1i111IiIiIi1 == 10 : Oo ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 11 : Oo0O0oooo ( )
elif IiI1i111IiIiIi1 == 12 : I1iiiiIii ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 19 : OOOOO0O00 ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 20 : I1Iiiiiii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 21 : O0O0Ooo ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 22 : OooO0oo ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 23 : I1ii1 ( )
elif IiI1i111IiIiIi1 == 24 : oO00oooOOoOo0 ( )
elif IiI1i111IiIiIi1 == 25 : i1 ( )
elif IiI1i111IiIiIi1 == 26 : O0Ooo0oo ( )
elif IiI1i111IiIiIi1 == 30 : Ii1I1Ii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 40 : II1IiiIii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 41 : II1I1iiIII1I1 ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 50 : O00oo0ooO ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 51 : i1OoOO ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 60 : I111IIiii1Ii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 61 : I11iIiII ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 100 : oooo00 ( )
elif IiI1i111IiIiIi1 == 500 : o0OooooOoOO ( )
elif IiI1i111IiIiIi1 == 201 : ooO ( )
elif IiI1i111IiIiIi1 == 202 : i1I1IiiIi1i ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 203 : IiII111i1i11 ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 204 : II11Iiii ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 205 : o0o ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 206 : IiiiiI1i1Iii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 210 : oOoOo0O0OOOoO ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 220 : OOo0o0O0O ( O0O0oOO00O00o )
elif IiI1i111IiIiIi1 == 221 : i1Ii1i1I11Iii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IiI1i111IiIiIi1 == 800 : oOO0o000Oo00o ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
if 47 - 47: Ii1I - OoOO - iI1
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )