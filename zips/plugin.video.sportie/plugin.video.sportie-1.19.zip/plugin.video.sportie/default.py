import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
import plugintools
import datetime
from resources . lib . modules import regex
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
if 91 - 91: Ii1I . OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
O0oO = plugintools . get_setting ( "scrape1" )
o0oO0 = plugintools . get_setting ( "scrape2" )
oo00 = plugintools . get_setting ( "scrape3" )
if 88 - 88: O0Oo0oO0o . II1iI . i1iIii1Ii1II
#######################################################################
#						Cache Functions
#######################################################################
if 1 - 1: O0Oooo00
class Ooo0 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 89 - 89: I111i1i1111i - Ii1Ii1iiii11 % I1I1i1
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 18 - 18: iiIIIIi1i1 / OOoOoo00oo - iI1 + OOooO % ooO00oo - O000oo
i1iIIi1 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 50 - 50: i11iIiiIii - OOoOoo00oo
class oo0Ooo0 :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 46 - 46: O000oo % O000oo - Ii1Ii1iiii11 * O0Oooo00 % iI1
  if 55 - 55: i1iIii1Ii1II % o0000oOoOoO0o / OOoOoo00oo - Ii1Ii1iiii11 - Ii1I / i1I1ii1II1iII
  if 28 - 28: OoOO - o0000oOoOoO0o
  if 70 - 70: II1iI . II1iI - II1iI / I111i1i1111i * I1I1i1
def OoO000 ( ) :
 IIiiIiI1 = 5
 iiIiIIi = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 ooOoo0O = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 76 - 76: Ii1I / O0Oooo00 . oooO0oo0oOOOO * OOoOoo00oo - I1I1i1
 Oooo = [ ]
 if 67 - 67: I1I1i1 / OoOO0ooOOoo0O % iiIIIIi1i1 - OoOO
 for Ooo in range ( IIiiIiI1 ) :
  Oooo . append ( oo0Ooo0 ( iiIiIIi [ Ooo ] , ooOoo0O [ Ooo ] ) )
  if 68 - 68: iiIIIIi1i1 + I1I1i1 . OoOO - OOooO % OoOO - O000oo
 return Oooo
 if 79 - 79: O0Oo0oO0o + oooO0oo0oOOOO - iI1
def oO00O00o0OOO0 ( ) :
 if 27 - 27: Ii1I % o0000oOoOoO0o * Ii1Ii1iiii11 + i11iIiiIii + OoOO0ooOOoo0O * o0000oOoOoO0o
 if not os . path . isfile ( ooo0OO ) :
  plugintools . open_settings_dialog ( )
  if 80 - 80: iiIIIIi1i1 * i11iIiiIii / ooO00oo
 I11II1i = open ( IIi1IiiiI1Ii ) . read ( )
 IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  I1IIIii = float ( IIiiiiiiIi1I1 )
  if 95 - 95: II1iI % Ii1Ii1iiii11 . Ii1I
 I1i1I = oOO00oOO ( II1 )
 I1i1I = base64 . b64decode ( I1i1I )
 I1i1I = I1i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 75 - 75: o0000oOoOoO0o / OoOO0ooOOoo0O - Ii1I / i1iIii1Ii1II . i1I1ii1II1iII - o0000oOoOoO0o
  if '<search>ZGlzcGxheQ==</search>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 13 - 13: ooO00oo % i1iIii1Ii1II - i11iIiiIii . oooO0oo0oOOOO + i1I1ii1II1iII
  elif '<vip>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 10 - 10: I111i1i1111i * O000oo * i1I1ii1II1iII % OOoOoo00oo . I1I1i1 + ooO00oo
  elif '<divider>bnVsbA==</divider>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   IIiIi11i1 ( O000OO0 , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 29 - 29: I111i1i1111i % oooO0oo0oOOOO + O000oo / O0Oooo00 + I1I1i1 * O0Oooo00
  elif '<extras>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , II1 , 26 , iiiii , O0O0OO0O0O0 )
   if 42 - 42: OOoOoo00oo + Ii1Ii1iiii11
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 76 - 76: ooO00oo - II1iI
   if 70 - 70: O000oo
   if 61 - 61: I111i1i1111i . I111i1i1111i
   if 10 - 10: i1iIii1Ii1II * iI1 . iiIIIIi1i1 + i1I1ii1II1iII - O000oo * o0000oOoOoO0o
   if 56 - 56: O0Oooo00 * OOooO * i1I1ii1II1iII
   if 80 - 80: O0Oooo00 * i1I1ii1II1iII % i1I1ii1II1iII
   if 59 - 59: OoOO + oooO0oo0oOOOO - O0Oooo00 - oooO0oo0oOOOO + I1I1i1 / I111i1i1111i
   if 24 - 24: iiIIIIi1i1 . iI1 % I1I1i1 + O000oo % i1iIii1Ii1II
   if 4 - 4: OOooO - II1iI * i1iIii1Ii1II - iiIIIIi1i1
   if 41 - 41: i1iIii1Ii1II . oooO0oo0oOOOO * Ii1Ii1iiii11 % OOooO
   if 86 - 86: oooO0oo0oOOOO + OOoOoo00oo % i11iIiiIii * Ii1Ii1iiii11 . O000oo * iiIIIIi1i1
   if 44 - 44: Ii1Ii1iiii11
   if 88 - 88: ooO00oo % OOoOoo00oo . i1I1ii1II1iII
   if 38 - 38: O0Oooo00
   if 57 - 57: Ii1I / Ii1Ii1iiii11 * ooO00oo / i1iIii1Ii1II . i1I1ii1II1iII
   if 26 - 26: iI1
   if 91 - 91: II1iI . I111i1i1111i + II1iI - iI1 / OoOO0ooOOoo0O
   if 39 - 39: I111i1i1111i / O000oo - i1I1ii1II1iII
   if 98 - 98: I111i1i1111i / iiIIIIi1i1 % Ii1Ii1iiii11 . i1iIii1Ii1II
   if 91 - 91: Ii1Ii1iiii11 % O0Oo0oO0o
   if 64 - 64: iiIIIIi1i1 % iI1 - ooO00oo - Ii1Ii1iiii11
   if 31 - 31: iiIIIIi1i1 - i1I1ii1II1iII . iiIIIIi1i1
  elif '<sportsdevil>' in IIiiiiiiIi1I1 :
   i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0O0oOO00O00o = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    iI1ii11iIi1i = re . compile ( '<referer>(.+?)</referer>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    iI1ii11iIi1i = base64 . b64decode ( iI1ii11iIi1i )
    iiI111I1iIiI = iI1ii11iIi1i
    II = "/"
    if not iiI111I1iIiI . endswith ( II ) :
     Ii1I1IIii1II = iiI111I1iIiI + "/"
    else :
     Ii1I1IIii1II = iiI111I1iIiI
    I1i1I = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( O000OO0 ) + '%26url=' + O0O0oOO00O00o
    O0O0oOO00O00o = I1i1I + '%26referer=' + Ii1I1IIii1II
    IIiIi11i1 ( O000OO0 , O0O0oOO00O00o , 4 , Oo0o00 , O0 )
   elif len ( i1I11i1I ) > 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    IIiIi11i1 ( O000OO0 , url2 + 'NOTPLAY' , 8 , Oo0o00 , O0 )
    if 25 - 25: I111i1i1111i
  elif '<folder>' in IIiiiiiiIi1I1 :
   Ii1i = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for O000OO0 , O0O0oOO00O00o , Oo0o00 , O0 in Ii1i :
    O000OO0 = base64 . b64decode ( O000OO0 )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0 = base64 . b64decode ( O0 )
    I11iii1Ii ( O000OO0 , O0O0oOO00O00o , 1 , Oo0o00 , O0 )
  elif '<m3u>' in IIiiiiiiIi1I1 :
   Ii1i = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for O000OO0 , O0O0oOO00O00o , Oo0o00 , O0 in Ii1i :
    O000OO0 = base64 . b64decode ( O000OO0 )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0 = base64 . b64decode ( O0 )
    I11iii1Ii ( O000OO0 , O0O0oOO00O00o , 10 , Oo0o00 , O0 )
  else :
   i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    Ii1i = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
    I1 = len ( ooooooO0oo )
    for O000OO0 , O0O0oOO00O00o , Oo0o00 , O0 in Ii1i :
     O000OO0 = base64 . b64decode ( O000OO0 )
     O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
     Oo0o00 = base64 . b64decode ( Oo0o00 )
     O0 = base64 . b64decode ( O0 )
     IIiIi11i1 ( O000OO0 , O0O0oOO00O00o , 2 , Oo0o00 , O0 )
   elif len ( i1I11i1I ) > 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0 = base64 . b64decode ( O0 )
    IIiIi11i1 ( O000OO0 , II1 , 3 , Oo0o00 , O0 )
    if 15 - 15: i1I1ii1II1iII
 IIiIi11i1 ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '[COLOR dodgerblue]VER ' + str ( I1IIIii ) + '[/COLOR][COLOR yellow] - CHECK FOR UPDATES[/COLOR]' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 if 18 - 18: i11iIiiIii . o0000oOoOoO0o % OoOO0ooOOoo0O / Ii1I
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 75 - 75: i1iIii1Ii1II % O0Oooo00 % O0Oooo00 . ooO00oo
def III1iII1I1ii ( name , url ) :
 if 61 - 61: i1I1ii1II1iII
 hash = [ ]
 O0OOO = url
 I1i1I = oOO00oOO ( url )
 if 10 - 10: I1I1i1 * iiIIIIi1i1 % i1iIii1Ii1II / oooO0oo0oOOOO / i1iIii1Ii1II
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 42 - 42: II1iI
  if '<search>' in IIiiiiiiIi1I1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   o0o = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = name + '!' + o0o + '!' + Oo0o00
   I11iii1Ii ( '[COLOR blue]' + name + '[/COLOR]' , url , 20 , Oo0o00 , O0 )
   if 84 - 84: Ii1I
  if '<regex>' in IIiiiiiiIi1I1 :
   OOOooOO0 = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( IIiiiiiiIi1I1 )
   OOOooOO0 = '' . join ( OOOooOO0 )
   OOOOoOoo0O0O0 = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( OOOooOO0 )
   OOOooOO0 = urllib . quote_plus ( OOOooOO0 )
   if 85 - 85: Ii1Ii1iiii11 % i11iIiiIii - iI1 * OoOO0ooOOoo0O / oooO0oo0oOOOO % oooO0oo0oOOOO
   IIiIi1iI = hashlib . md5 ( )
   for i1IiiiI1iI in OOOooOO0 : IIiIi1iI . update ( str ( i1IiiiI1iI ) )
   IIiIi1iI = str ( IIiIi1iI . hexdigest ( ) )
   if 49 - 49: OOoOoo00oo / II1iI . i1I1ii1II1iII
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   IIiiiiiiIi1I1 = re . sub ( '<regex>.+?</regex>' , '' , IIiiiiiiIi1I1 )
   IIiiiiiiIi1I1 = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , IIiiiiiiIi1I1 )
   IIiiiiiiIi1I1 = re . sub ( '<link></link>' , '' , IIiiiiiiIi1I1 )
   if 68 - 68: i11iIiiIii % I111i1i1111i + i11iIiiIii
   name = re . sub ( '<meta>.+?</meta>' , '' , IIiiiiiiIi1I1 )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 31 - 31: i1I1ii1II1iII . oooO0oo0oOOOO
   try : II1I = re . findall ( '<date>(.+?)</date>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : II1I = ''
   if re . search ( r'\d+' , II1I ) : name += ' [COLOR red] Updated %s[/COLOR]' % II1I
   if 84 - 84: OOooO . i11iIiiIii . OOooO * I111i1i1111i - iiIIIIi1i1
   try : ii = re . findall ( '<thumbnail>(.+?)</thumbnail>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : ii = iiiii
   if 81 - 81: ooO00oo % iI1 . I111i1i1111i / O0Oooo00
   try : iiiIiI = re . findall ( '<fanart>(.+?)</fanart>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : iiiIiI = O0O0OO0O0O0
   if 91 - 91: iI1 % o0000oOoOoO0o % OoOO
   try : IIi1I11I1II = re . findall ( '<meta>(.+?)</meta>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : IIi1I11I1II = '0'
   if 63 - 63: OoOO0ooOOoo0O - II1iI . i1I1ii1II1iII / O0Oooo00 . i1iIii1Ii1II / Ii1I
   try : url = re . findall ( '<link>(.+?)</link>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % IIi1I11I1II )
   url = '<preset>search</preset>%s' % IIi1I11I1II if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % IIi1I11I1II )
   url = '<preset>searchsd</preset>%s' % IIi1I11I1II if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 84 - 84: OOooO
   if not OOOooOO0 == '' :
    hash . append ( { 'regex' : IIiIi1iI , 'response' : OOOooOO0 } )
    url += '|regex=%s' % OOOooOO0
    if 86 - 86: i1iIii1Ii1II - OOoOoo00oo - II1iI * iI1
   IIiIi11i1 ( name , url , 30 , ii , iiiIiI )
   if 66 - 66: OoOO0ooOOoo0O + Ii1I
  elif '<sportsdevil>' in IIiiiiiiIi1I1 :
   i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     iI1ii11iIi1i = re . compile ( '<referer>(.+?)</referer>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : iI1ii11iIi1i = "None"
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : O0 = O0O0OO0O0O0
    iiI111I1iIiI = iI1ii11iIi1i
    II = "/"
    if not iiI111I1iIiI . endswith ( II ) :
     Ii1I1IIii1II = iiI111I1iIiI + "/"
    else :
     Ii1I1IIii1II = iiI111I1iIiI
    I1i1I = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = I1i1I + '%26referer=' + Ii1I1IIii1II
    IIiIi11i1 ( name , url , 2 , Oo0o00 , O0 )
    if 11 - 11: iiIIIIi1i1 + OoOO0ooOOoo0O - II1iI / O0Oooo00 + O0Oo0oO0o . i1I1ii1II1iII
   elif len ( i1I11i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : O0 = O0O0OO0O0O0
    IIiIi11i1 ( name , O0OOO + 'NOTPLAY' , 8 , Oo0o00 , O0 )
    if 41 - 41: OOoOoo00oo - Ii1I - Ii1I
  elif '<folder>' in IIiiiiiiIi1I1 :
   Ii1i = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for name , url , Oo0o00 , O0 in Ii1i :
    I11iii1Ii ( name , url , 1 , Oo0o00 , O0 )
    if 68 - 68: I1I1i1 % ooO00oo
  elif '<m3u>' in IIiiiiiiIi1I1 :
   Ii1i = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for name , url , Oo0o00 , O0 in Ii1i :
    I11iii1Ii ( name , url , 10 , Oo0o00 , O0 )
    if 88 - 88: OoOO - O000oo + I1I1i1
  else :
   i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1I11i1I ) == 1 :
    Ii1i = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
    I1 = len ( ooooooO0oo )
    for name , url , Oo0o00 , O0 in Ii1i :
     IIiIi11i1 ( name , url , 2 , Oo0o00 , O0 )
   elif len ( i1I11i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : O0 = O0O0OO0O0O0
    IIiIi11i1 ( name , O0OOO , 3 , Oo0o00 , O0 )
    if 40 - 40: oooO0oo0oOOOO * OOoOoo00oo + I1I1i1 % iI1
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 74 - 74: Ii1Ii1iiii11 - O0Oo0oO0o + OoOO0ooOOoo0O + ooO00oo / i1iIii1Ii1II
def i1 ( name , url , iconimage ) :
 I1iI1iIi111i = [ ]
 iiIi1IIi1I = [ ]
 o0OoOO000ooO0 = [ ]
 I1i1I = oOO00oOO ( url )
 o0o0o0oO0oOO = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0o0o0oO0oOO ) [ 0 ]
 i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( o0o0o0oO0oOO )
 i1IiiiI1iI = 1
 for ii1Ii11I in i1I11i1I :
  o00o0 = ii1Ii11I
  if '(' in ii1Ii11I :
   ii1Ii11I = ii1Ii11I . split ( '(' ) [ 0 ]
   iiOOooooO0Oo = str ( o00o0 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1iI1iIi111i . append ( ii1Ii11I )
   iiIi1IIi1I . append ( iiOOooooO0Oo )
  else :
   I1iI1iIi111i . append ( ii1Ii11I )
   iiIi1IIi1I . append ( 'Link ' + str ( i1IiiiI1iI ) )
  i1IiiiI1iI = i1IiiiI1iI + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( name , iiIi1IIi1I )
 if OO < 0 :
  quit ( )
 else :
  url = I1iI1iIi111i [ OO ]
  print url
  if 25 - 25: II1iI
 url = I1iI1iIi111i [ OO ]
 name = iiIi1IIi1I [ OO ]
 oOo0oO ( name , url , iiiii )
 if 51 - 51: O0Oo0oO0o - Ii1Ii1iiii11 + i1I1ii1II1iII * OOoOoo00oo . iiIIIIi1i1 + Ii1Ii1iiii11
def OoO0o ( name , url , iconimage ) :
 if 78 - 78: Ii1Ii1iiii11 % Ii1I % OOoOoo00oo
 I1iI1iIi111i = [ ]
 iiIi1IIi1I = [ ]
 o0OoOO000ooO0 = [ ]
 iiI1Ii1iI1 = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 I1i1I = oOO00oOO ( url )
 o0o0o0oO0oOO = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( o0o0o0oO0oOO )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0o0o0oO0oOO ) [ 0 ]
 if 87 - 87: O0Oo0oO0o . OOooO
 O0OO0O = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 81 - 81: Ii1Ii1iiii11 . O0Oooo00 % Ii1I / oooO0oo0oOOOO - Ii1Ii1iiii11
 i1IiiiI1iI = 1
 if 43 - 43: i11iIiiIii + O0Oo0oO0o * i1I1ii1II1iII * ooO00oo * Ii1I
 for ii1Ii11I in i1I11i1I :
  o00o0 = ii1Ii11I
  if '(' in ii1Ii11I :
   ii1Ii11I = ii1Ii11I . split ( '(' ) [ 0 ]
   iiOOooooO0Oo = str ( o00o0 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1iI1iIi111i . append ( ii1Ii11I )
   iiIi1IIi1I . append ( iiOOooooO0Oo )
   iiI1Ii1iI1 . append ( 'Stream ' + str ( i1IiiiI1iI ) )
  else :
   I1iI1iIi111i . append ( ii1Ii11I )
   iiIi1IIi1I . append ( 'Link ' + str ( i1IiiiI1iI ) )
   if 64 - 64: I1I1i1 % OoOO * Ii1Ii1iiii11
  i1IiiiI1iI = i1IiiiI1iI + 1
  if 79 - 79: Ii1I
 name = '[COLOR red]' + name + '[/COLOR]'
 if 78 - 78: I111i1i1111i + I1I1i1 - ooO00oo
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( name , iiIi1IIi1I )
 if OO < 0 :
  quit ( )
 else :
  iiI111I1iIiI = iiIi1IIi1I [ OO ]
  II = "/"
  if not iiI111I1iIiI . endswith ( II ) :
   Ii1I1IIii1II = iiI111I1iIiI + "/"
  else :
   Ii1I1IIii1II = iiI111I1iIiI
  url = O0OO0O + I1iI1iIi111i [ OO ] + "%26referer=" + Ii1I1IIii1II
  if 38 - 38: O0Oooo00 - Ii1Ii1iiii11 + OoOO / i1iIii1Ii1II % O0Oo0oO0o
 name = iiIi1IIi1I [ OO ]
 oOo0oO ( name , url , iiiii )
 if 57 - 57: II1iI / O000oo
def Ii1I1Ii ( name , url , iconimage ) :
 if 69 - 69: oooO0oo0oOOOO / O0Oooo00 . OOooO * ooO00oo % OOoOoo00oo - O0Oooo00
 i1i , Ooo = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 i1i += urllib . unquote_plus ( Ooo )
 url = regex . resolve ( i1i )
 if 56 - 56: I111i1i1111i % Ii1I - oooO0oo0oOOOO
 oOo0oO ( name , url , iconimage )
 if 100 - 100: OOoOoo00oo - Ii1I % Ii1Ii1iiii11 * I1I1i1 + oooO0oo0oOOOO
def Oo0O0oooo ( ) :
 if 33 - 33: ooO00oo + iI1 * Ii1Ii1iiii11 / OoOO - oooO0oo0oOOOO
 IIiIi11i1 ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 54 - 54: ooO00oo / I1I1i1 . Ii1Ii1iiii11 % iI1
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 57 - 57: i11iIiiIii . I111i1i1111i - OOoOoo00oo - Ii1Ii1iiii11 + i1iIii1Ii1II
def oO00oooOOoOo0 ( ) :
 if 74 - 74: OoOO * I111i1i1111i + i1iIii1Ii1II / o0000oOoOoO0o / i1I1ii1II1iII . O0Oo0oO0o
 I11iii1Ii ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 62 - 62: OoOO0ooOOoo0O * oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 58 - 58: i1iIii1Ii1II % O0Oooo00
def i1OOoO ( ) :
 if 89 - 89: O0Oooo00 + II1iI * iiIIIIi1i1 * OOoOoo00oo
 I11iii1Ii ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 37 - 37: OoOO0ooOOoo0O - Ii1I - O0Oooo00
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 77 - 77: I1I1i1 * OoOO
def oO00oOOoooO ( ) :
 if 46 - 46: oooO0oo0oOOOO - OoOO0ooOOoo0O - iiIIIIi1i1 * i1I1ii1II1iII
 i1IiiiI1iI = 0
 I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  i1IiiiI1iI = i1IiiiI1iI + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( i1IiiiI1iI ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 80 - 80: i11iIiiIii % O000oo + OOoOoo00oo % iiIIIIi1i1 - I111i1i1111i
 I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  i1IiiiI1iI = i1IiiiI1iI + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( i1IiiiI1iI ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 18 - 18: iI1 - I1I1i1 . ooO00oo . OoOO
 I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  i1IiiiI1iI = i1IiiiI1iI + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( i1IiiiI1iI ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 2 - 2: I1I1i1 . II1iI
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 78 - 78: iiIIIIi1i1 * OoOO . oooO0oo0oOOOO / O0Oooo00 - OoOO0ooOOoo0O / ooO00oo
def i1I1IiiIi1i ( url ) :
 if 29 - 29: oooO0oo0oOOOO % oooO0oo0oOOOO
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 if 94 - 94: OoOO / O0Oo0oO0o % iI1 * iI1 * i1I1ii1II1iII
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OO0 = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  Oo0o00 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 12 , Oo0o00 , O0O0OO0O0O0 )
  if 29 - 29: II1iI + i1iIii1Ii1II / O0Oooo00 / I1I1i1 * OoOO
 try :
  O0OO = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( I1i1I11I ) [ 0 ]
  I11iii1Ii ( '[COLOR yellow]Next Page -->[/COLOR]' , O0OO , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 6 - 6: OoOO % i11iIiiIii % I111i1i1111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 93 - 93: OOooO * OoOO0ooOOoo0O + O000oo
def IiII111i1i11 ( url ) :
 if 40 - 40: O000oo * OOooO * i11iIiiIii
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   O000OO0 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except :
   O000OO0 = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 57 - 57: O000oo
def II11Iiii ( url ) :
 if 46 - 46: iiIIIIi1i1 / OOoOoo00oo
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( I1i1I11I )
 O000 = 0
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   O000OO0 = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : O000 = 1
  if 52 - 52: I1I1i1
  if O000 == 0 :
   I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 12 , Oo0o00 , O0O0OO0O0O0 )
  O000 = 0
  if 19 - 19: oooO0oo0oOOOO
 try :
  O0OO = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( I1i1I11I ) [ 0 ]
  I11iii1Ii ( '[COLOR yellow]Next Page -->[/COLOR]' , O0OO , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 25 - 25: OOoOoo00oo / O000oo
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 31 - 31: I1I1i1 . Ii1I % oooO0oo0oOOOO . O0Oooo00 + OOooO
def o0ooo0 ( url ) :
 if 61 - 61: i1iIii1Ii1II - I1I1i1 - o0000oOoOoO0o
 IiI1iIiIIIii = datetime . date . today ( )
 oOoO = datetime . datetime . strftime ( IiI1iIiIIIii , '%A %d %B %Y' )
 if 81 - 81: i1iIii1Ii1II - i1iIii1Ii1II . iI1
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( oOoO ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 73 - 73: iiIIIIi1i1 % i11iIiiIii - oooO0oo0oOOOO
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( I1i1I11I )
 O000 = 0
 i1IiiiI1iI = 0
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   Ii1iI111II1I1 = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   try :
    oOOOOoOO0o = re . compile ( '<p>(.+?)</p>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   except : oOOOOoOO0o = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<img src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : O000 = 1
  if 1 - 1: i1I1ii1II1iII
  if O000 == 0 :
   if 'vs' in Ii1iI111II1I1 :
    O000OO0 = '[COLOR dodgerblue]' + Ii1iI111II1I1 + ' - ' + '[/COLOR][COLOR green]' + oOOOOoOO0o + '[/COLOR]'
    i1IiiiI1iI = i1IiiiI1iI + 1
    IIiIi11i1 ( O000OO0 , url , 206 , Oo0o00 , O0O0OO0O0O0 , '' )
  O000 = 0
  if 68 - 68: iI1 - oooO0oo0oOOOO / ooO00oo / iiIIIIi1i1
 if i1IiiiI1iI == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 12 - 12: OOoOoo00oo + i11iIiiIii * OoOO / I111i1i1111i . iiIIIIi1i1
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 5 - 5: o0000oOoOoO0o + OOooO / O0Oooo00 . iI1 / iiIIIIi1i1
def IiiiIiii11 ( name , url , iconimage ) :
 if 92 - 92: i1iIii1Ii1II + ooO00oo * OOoOoo00oo % oooO0oo0oOOOO
 I1i1I11I = oOO00oOO ( url )
 i1I1i1 = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( I1i1I11I ) [ 0 ]
 if 81 - 81: O000oo - OoOO - o0000oOoOoO0o / ooO00oo - Ii1I * iiIIIIi1i1
 if not "http" in i1I1i1 :
  i1I1i1 = i1I1i1 . replace ( "//" , "" )
  url = "http://" + i1I1i1
 else :
  url = i1I1i1
  if 20 - 20: Ii1Ii1iiii11 % OOooO
 III1i1i11i = url
 if 100 - 100: Ii1Ii1iiii11 / ooO00oo / I111i1i1111i
 oOoOOo0O = oOO00oOO ( url )
 i1I1i1 = re . compile ( "atob(.+?)," ) . findall ( oOoOOo0O ) [ 0 ]
 i1I1i1 = i1I1i1 . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( i1I1i1 )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + III1i1i11i + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 oOo0oO ( name , url , iconimage )
 if 84 - 84: II1iI + o0000oOoOoO0o - i1I1ii1II1iII . I111i1i1111i * OoOO0ooOOoo0O + oooO0oo0oOOOO
def II1i11I ( url ) :
 if 50 - 50: OoOO0ooOOoo0O % iiIIIIi1i1
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 49 - 49: Ii1Ii1iiii11 - i11iIiiIii . ooO00oo * OOoOoo00oo % iI1 + o0000oOoOoO0o
  if '<display>eWVz</display>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   url = base64 . b64decode ( url )
   Oo0o00 = base64 . b64decode ( Oo0o00 )
   O0 = base64 . b64decode ( O0 )
   I11iii1Ii ( O000OO0 , url , 220 , Oo0o00 , O0 , '' )
   if 71 - 71: O0Oooo00
def IIIIiIiIi1 ( url ) :
 if 2 - 2: iI1 % OoOO * OoOO . O0Oooo00 / iI1
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( I1i1I11I )
 if 27 - 27: II1iI + O000oo - o0000oOoOoO0o
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OO0 = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  try :
   O00oOOooo = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : O00oOOooo = "SD"
  O00oOOooo = '[COLOR yellow]' + O00oOOooo + '[/COLOR]'
  Oo0o00 = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  O000OO0 = O000OO0 . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 50 - 50: I111i1i1111i % Ii1I * O0Oooo00
  IIiIi11i1 ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR] - ' + O00oOOooo , url , 212 , Oo0o00 , O0O0OO0O0O0 , '' )
  if 5 - 5: OOooO * i1iIii1Ii1II
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( I1i1I11I ) [ 0 ]
  i1Ii1i1I11Iii = 'http://www.fmovies.se/' + url
  I11iii1Ii ( "Next Page -->" , i1Ii1i1I11Iii , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 25 - 25: OOooO + OOoOoo00oo / O000oo . O0Oooo00 % Ii1I * II1iI
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 84 - 84: O000oo % OOoOoo00oo + i11iIiiIii
def II1I1Ii ( url ) :
 if 62 - 62: Ii1I % iiIIIIi1i1 . iiIIIIi1i1 - OoOO / i11iIiiIii
 I1i1I11I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( I1i1I11I )
 if 31 - 31: OoOO / II1iI / I111i1i1111i
 if 41 - 41: O0Oo0oO0o
def IIiIi ( url ) :
 if 91 - 91: I111i1i1111i * O0Oo0oO0o / oooO0oo0oOOOO . Ii1I + II1iI + i1iIii1Ii1II
 if "iptvembed" in url :
  I1i1I11I = oOO00oOO ( url )
  ooooooO0oo = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '</pre>' , '' )
   url = IIiiiiiiIi1I1
   if 8 - 8: Ii1Ii1iiii11 / I111i1i1111i
 if "sourcetv" in url :
  I1i1I11I = oOO00oOO ( url )
  ooooooO0oo = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '</pre>' , '' )
   url = IIiiiiiiIi1I1
   if 20 - 20: oooO0oo0oOOOO
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 o00o0II1I = [ ]
 for II1I1I1Ii , OOOOoO00o0O , url in o0oO000oo :
  I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : url }
  o00o0II1I . append ( I1I1I1IIi1III )
 list = [ ]
 for II11IiiIII in o00o0II1I :
  I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
  o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
  for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
   I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
  list . append ( I1I1I1IIi1III )
  if 82 - 82: iI1
 O0o = 0
 for II11IiiIII in list :
  O0o = 1
  O000OO0 = i1iIiIIi ( II11IiiIII [ "display_name" ] )
  url = i1iIiIIi ( II11IiiIII [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   IIiIi11i1 ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   I11iii1Ii ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 62 - 62: O0Oo0oO0o - iiIIIIi1i1
 if O0o == 0 :
  IIiIi11i1 ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 21 - 21: Ii1I % OOooO . oooO0oo0oOOOO / i1I1ii1II1iII + OOooO
def OOOO0O00o ( url ) :
 if 62 - 62: OoOO
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 12 - 12: I1I1i1 / O0Oooo00
  O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  o0o = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  O0 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = O000OO0 + '!' + o0o + '!' + Oo0o00
  I11iii1Ii ( '[COLOR blue]' + O000OO0 + '[/COLOR]' , url , 20 , Oo0o00 , O0 )
  if 42 - 42: O0Oo0oO0o
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 19 - 19: Ii1Ii1iiii11 % I111i1i1111i * OoOO + oooO0oo0oOOOO
def iii11I ( url ) :
 if 50 - 50: iI1 + Ii1I + OOoOoo00oo . i1I1ii1II1iII / O0Oooo00
 IiI1iIiIIIii = datetime . date . today ( )
 oOoO = datetime . datetime . strftime ( IiI1iIiIIIii , '%A %d %B %Y' )
 if 17 - 17: OOoOoo00oo % OoOO - OoOO
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( oOoO ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 78 - 78: iI1 + iiIIIIi1i1 . O000oo - iI1 . OOoOoo00oo
 I1i1I = oOO00oOO ( url )
 O0OOO = url
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 30 - 30: oooO0oo0oOOOO + II1iI % OOoOoo00oo * iI1 / O0Oo0oO0o - iiIIIIi1i1
  i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 )
  if len ( i1I11i1I ) == 1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = O000OO0 + "!" + url + "!" + Oo0o00
   O000OO0 = '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]'
   I11iii1Ii ( O000OO0 , url , 20 , Oo0o00 , Oo0o00 )
   if 64 - 64: OoOO
   if 21 - 21: O0Oo0oO0o . i1I1ii1II1iII
  elif len ( i1I11i1I ) > 1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = O0OOO + "!" + O000OO0 + "!" + Oo0o00
   O000OO0 = '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]'
   I11iii1Ii ( O000OO0 , url , 22 , Oo0o00 , Oo0o00 )
   if 54 - 54: i1I1ii1II1iII % i1I1ii1II1iII
   if 86 - 86: Ii1I % OOoOoo00oo * O000oo * OoOO * o0000oOoOoO0o * iiIIIIi1i1
   if 83 - 83: i1iIii1Ii1II % i1I1ii1II1iII - i1iIii1Ii1II + OOooO - Ii1I
   if 52 - 52: O0Oo0oO0o * O000oo
   if 33 - 33: OOoOoo00oo
   if 74 - 74: I1I1i1 + Ii1I + o0000oOoOoO0o - o0000oOoOoO0o + i1I1ii1II1iII
   if 83 - 83: I111i1i1111i - oooO0oo0oOOOO + I1I1i1
   if 5 - 5: OOoOoo00oo
   if 46 - 46: OOooO
   if 45 - 45: O000oo
   if 21 - 21: Ii1Ii1iiii11 . ooO00oo . I1I1i1 / O0Oo0oO0o / ooO00oo
   if 17 - 17: I1I1i1 / I1I1i1 / iiIIIIi1i1
   if 1 - 1: o0000oOoOoO0o . i11iIiiIii % I1I1i1
def OooO0oo ( ) :
 if 89 - 89: OOoOoo00oo
 IiI1iIiIIIii = datetime . date . today ( )
 oOoO = datetime . datetime . strftime ( IiI1iIiIIIii , '%A %d %B %Y' )
 if 76 - 76: O000oo
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( oOoO ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 15 - 15: I1I1i1 . iiIIIIi1i1 + OoOO0ooOOoo0O - II1iI
 I1i1I = oOO00oOO ( 'http://www.oddschecker.com/tv-sports-calendar' )
 ooooooO0oo = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( I1i1I )
 Oo0 = str ( ooooooO0oo )
 oooooOOO000Oo = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( Oo0 )
 for IIiiiiiiIi1I1 in oooooOOO000Oo :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in IIiiiiiiIi1I1 :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Ii1iI111II1I1 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Oo0o00 = re . compile ( 'src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     o0o = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
     o0o = Ooo00OoOOO ( o0o )
    except : o0o = "null"
    O000OO0 = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + Ii1iI111II1I1 + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    O000OO0 = Oo0OO0000oooo ( O000OO0 )
    O0O0oOO00O00o = Ii1iI111II1I1 + "!" + o0o . lower ( ) + "!" + Oo0o00
    I11iii1Ii ( O000OO0 , O0O0oOO00O00o , 20 , Oo0o00 , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    Ii1iI111II1I1 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     o0o = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : o0o = "null"
    Oo0o00 = re . compile ( 'src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + Ii1iI111II1I1 + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    O000OO0 = Oo0OO0000oooo ( O000OO0 )
    O0O0oOO00O00o = Ii1iI111II1I1 + "!" + o0o . lower ( ) + "!" + Oo0o00
    I11iii1Ii ( O000OO0 , O0O0oOO00O00o , 20 , Oo0o00 , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 7 - 7: Ii1Ii1iiii11 - II1iI - Ii1I % Ii1Ii1iiii11 - i1I1ii1II1iII
def I1II ( name , url , iconimage ) :
 if 64 - 64: Ii1I % iiIIIIi1i1 % Ii1I * II1iI . Ii1Ii1iiii11 + oooO0oo0oOOOO
 try :
  url , O00 , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 17 - 17: OOoOoo00oo - OoOO0ooOOoo0O % OOoOoo00oo . OOooO / i11iIiiIii % iI1
 iIiIIIIIii = [ ]
 if 58 - 58: O0Oooo00 / OOooO . i1iIii1Ii1II / OoOO0ooOOoo0O + ooO00oo
 I1i1I = oOO00oOO ( url )
 o0o0o0oO0oOO = re . compile ( '<title>' + re . escape ( O00 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0o0o0oO0oOO ) [ 0 ]
 i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( o0o0o0oO0oOO )
 for ii1Ii11I in i1I11i1I :
  iIiIIIIIii . append ( ii1Ii11I )
  if 86 - 86: iiIIIIi1i1 * oooO0oo0oOOOO + iiIIIIi1i1 + i1I1ii1II1iII
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 8 - 8: ooO00oo - iI1 / O000oo
 oo0oOoo = 0
 if 57 - 57: i1iIii1Ii1II - I111i1i1111i
 I11i = [ ]
 iI11 = [ ]
 o00oOoOo0 = [ ]
 I1IiiI . update ( 0 )
 o0O0O0ooo0oOO = 0
 if 97 - 97: oooO0oo0oOOOO / iI1
 if O0oO == "true" :
  o0O0O0ooo0oOO = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if oo0oOoo < 100 :
    I1IiiI . update ( oo0oOoo )
    oo0oOoo = oo0oOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o00o0II1I = [ ]
   for II1I1I1Ii , OOOOoO00o0O , url in o0oO000oo :
    I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : url }
    o00o0II1I . append ( I1I1I1IIi1III )
   Oooo0 = [ ]
   for II11IiiIII in o00o0II1I :
    I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
    o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
    for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
     I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
    Oooo0 . append ( I1I1I1IIi1III )
    if 59 - 59: OoOO0ooOOoo0O
   for II11IiiIII in Oooo0 :
    name = i1iIiIIi ( II11IiiIII [ "display_name" ] )
    url = i1iIiIIi ( II11IiiIII [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    I11i . append ( name )
    iI11 . append ( url )
    if "hd" in name . lower ( ) :
     o00oOoOo0 . append ( "1" )
    else :
     o00oOoOo0 . append ( "0" )
    i1iiiii1 = list ( zip ( o00oOoOo0 , I11i , iI11 ) )
    if 83 - 83: iI1 . Ii1I / O0Oo0oO0o / I1I1i1 - i1I1ii1II1iII
 if o0oO0 == "true" :
  o0O0O0ooo0oOO = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if oo0oOoo < 100 :
    I1IiiI . update ( oo0oOoo )
    oo0oOoo = oo0oOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o00o0II1I = [ ]
   for II1I1I1Ii , OOOOoO00o0O , url in o0oO000oo :
    I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : url }
    o00o0II1I . append ( I1I1I1IIi1III )
   Oooo0 = [ ]
   for II11IiiIII in o00o0II1I :
    I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
    o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
    for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
     I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
    Oooo0 . append ( I1I1I1IIi1III )
    if 100 - 100: II1iI
   for II11IiiIII in Oooo0 :
    name = i1iIiIIi ( II11IiiIII [ "display_name" ] )
    url = i1iIiIIi ( II11IiiIII [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    I11i . append ( name )
    iI11 . append ( url )
    if "hd" in name . lower ( ) :
     o00oOoOo0 . append ( "1" )
    else :
     o00oOoOo0 . append ( "0" )
    i1iiiii1 = list ( zip ( o00oOoOo0 , I11i , iI11 ) )
    if 46 - 46: i1iIii1Ii1II / OoOO % iI1 . OoOO * iI1
 if oo00 == "true" :
  o0O0O0ooo0oOO = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if oo0oOoo < 100 :
    I1IiiI . update ( oo0oOoo )
    oo0oOoo = oo0oOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o00o0II1I = [ ]
   for II1I1I1Ii , OOOOoO00o0O , url in o0oO000oo :
    I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : url }
    o00o0II1I . append ( I1I1I1IIi1III )
   Oooo0 = [ ]
   for II11IiiIII in o00o0II1I :
    I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
    o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
    for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
     I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
    Oooo0 . append ( I1I1I1IIi1III )
    if 38 - 38: I111i1i1111i - iI1 / Ii1I . ooO00oo
   for II11IiiIII in Oooo0 :
    name = i1iIiIIi ( II11IiiIII [ "display_name" ] )
    url = i1iIiIIi ( II11IiiIII [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    I11i . append ( name )
    iI11 . append ( url )
    if "hd" in name . lower ( ) :
     o00oOoOo0 . append ( "1" )
    else :
     o00oOoOo0 . append ( "0" )
    i1iiiii1 = list ( zip ( o00oOoOo0 , I11i , iI11 ) )
    if 45 - 45: ooO00oo
 if o0O0O0ooo0oOO == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 83 - 83: i1iIii1Ii1II . OoOO0ooOOoo0O
 Oo0ooo = sorted ( i1iiiii1 , key = lambda Ooo : int ( Ooo [ 0 ] ) , reverse = True )
 IIiIiiii = sorted ( iIiIIIIIii )
 if 89 - 89: iI1 - O000oo % O0Oo0oO0o % O0Oooo00
 I11II1i = 0
 if 49 - 49: O0Oo0oO0o - oooO0oo0oOOOO / OOooO / Ii1I % O0Oooo00 * OOoOoo00oo
 I1IiiI . update ( 100 )
 if 100 - 100: I1I1i1 . iI1 / Ii1I * o0000oOoOoO0o * OOoOoo00oo * O0Oo0oO0o
 IIiIi11i1 ( '                    [COLOR yellow][I]LINKS FOR ' + O00 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 84 - 84: I111i1i1111i / I1I1i1 % i11iIiiIii * ooO00oo % I111i1i1111i - OoOO0ooOOoo0O
 if 99 - 99: oooO0oo0oOOOO + Ii1I + o0000oOoOoO0o / i11iIiiIii - o0000oOoOoO0o * OoOO
 for o0o in IIiIiiii :
  if 72 - 72: oooO0oo0oOOOO * I111i1i1111i . OOoOoo00oo * OOooO * O0Oo0oO0o * ooO00oo
  IIiIi11i1 ( '                                  [COLOR mediumpurple][I]' + o0o . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 40 - 40: oooO0oo0oOOOO
  Oo0 = o0o . split ( ' ' )
  if 14 - 14: ooO00oo
  for Oo0000oOo , name , url in Oo0ooo :
   if 31 - 31: iiIIIIi1i1 . ooO00oo * O000oo + i11iIiiIii * Ii1Ii1iiii11
   OO0ooo0o0O0Oooooo = 0
   if 1 - 1: O000oo % i1iIii1Ii1II * O0Oo0oO0o
   for o0O0oo0 in Oo0 :
    if 30 - 30: Ii1I * OoOO0ooOOoo0O
    if not o0O0oo0 . lower ( ) in name . lower ( ) :
     OO0ooo0o0O0Oooooo = 1
     if 38 - 38: OOooO - I111i1i1111i . i1iIii1Ii1II - ooO00oo . OoOO0ooOOoo0O
   if OO0ooo0o0O0Oooooo == 0 :
    I11II1i = I11II1i + 1
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 89 - 89: OoOO
  if I11II1i == 0 :
   IIiIi11i1 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 21 - 21: iiIIIIi1i1 % iiIIIIi1i1
  Oo0 = ""
  if 27 - 27: i11iIiiIii / I111i1i1111i
 I1IiiI . close ( )
 if 84 - 84: O0Oo0oO0o
def iIiiiii1i ( name , url , iconimage ) :
 if 40 - 40: Ii1I - OoOO0ooOOoo0O - OOooO
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 37 - 37: i1iIii1Ii1II / i1I1ii1II1iII / Ii1I
 oo0oOoo = 0
 try :
  O00 , o0o , iconimage = url . split ( '!' )
 except :
  try :
   o0o , iconimage = url . split ( '!' )
   O00 = o0o
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 76 - 76: oooO0oo0oOOOO . O000oo - I111i1i1111i - iI1 * II1iI
 O0Oo00O = 0
 if 91 - 91: Ii1Ii1iiii11 % OOoOoo00oo . O000oo / iI1 * OoOO
 if "all " in name . lower ( ) :
  o0o = o0o . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  O00 = O00 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  O0Oo00O = 1
  if 43 - 43: O000oo + iI1 - ooO00oo / Ii1I * O0Oo0oO0o + oooO0oo0oOOOO
 I11i = [ ]
 iI11 = [ ]
 o00oOoOo0 = [ ]
 I1IiiI . update ( 0 )
 o0O0O0ooo0oOO = 0
 if O0oO == "true" :
  o0O0O0ooo0oOO = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if oo0oOoo < 100 :
    I1IiiI . update ( oo0oOoo )
    oo0oOoo = oo0oOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o00o0II1I = [ ]
   for II1I1I1Ii , OOOOoO00o0O , url in o0oO000oo :
    I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : url }
    o00o0II1I . append ( I1I1I1IIi1III )
   Oooo0 = [ ]
   for II11IiiIII in o00o0II1I :
    I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
    o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
    for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
     I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
    Oooo0 . append ( I1I1I1IIi1III )
    if 28 - 28: OOoOoo00oo * O0Oooo00 - II1iI
   for II11IiiIII in Oooo0 :
    name = i1iIiIIi ( II11IiiIII [ "display_name" ] )
    url = i1iIiIIi ( II11IiiIII [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    I11i . append ( name )
    iI11 . append ( url )
    if "hd" in name . lower ( ) :
     o00oOoOo0 . append ( "1" )
    else :
     o00oOoOo0 . append ( "0" )
    i1iiiii1 = list ( zip ( o00oOoOo0 , I11i , iI11 ) )
    if 42 - 42: I111i1i1111i
 if o0oO0 == "true" :
  o0O0O0ooo0oOO = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if oo0oOoo < 100 :
    I1IiiI . update ( oo0oOoo )
    oo0oOoo = oo0oOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o00o0II1I = [ ]
   for II1I1I1Ii , OOOOoO00o0O , url in o0oO000oo :
    I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : url }
    o00o0II1I . append ( I1I1I1IIi1III )
   Oooo0 = [ ]
   for II11IiiIII in o00o0II1I :
    I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
    o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
    for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
     I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
    Oooo0 . append ( I1I1I1IIi1III )
    if 76 - 76: I111i1i1111i * i1I1ii1II1iII . oooO0oo0oOOOO - O0Oo0oO0o + Ii1Ii1iiii11 + i11iIiiIii
   for II11IiiIII in Oooo0 :
    name = i1iIiIIi ( II11IiiIII [ "display_name" ] )
    url = i1iIiIIi ( II11IiiIII [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    I11i . append ( name )
    iI11 . append ( url )
    if "hd" in name . lower ( ) :
     o00oOoOo0 . append ( "1" )
    else :
     o00oOoOo0 . append ( "0" )
    i1iiiii1 = list ( zip ( o00oOoOo0 , I11i , iI11 ) )
    if 28 - 28: Ii1Ii1iiii11
 if oo00 == "true" :
  o0O0O0ooo0oOO = 1
  I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if oo0oOoo < 100 :
    I1IiiI . update ( oo0oOoo )
    oo0oOoo = oo0oOoo + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o00o0II1I = [ ]
   for II1I1I1Ii , OOOOoO00o0O , url in o0oO000oo :
    I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : url }
    o00o0II1I . append ( I1I1I1IIi1III )
   Oooo0 = [ ]
   for II11IiiIII in o00o0II1I :
    I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
    o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
    for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
     I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
    Oooo0 . append ( I1I1I1IIi1III )
    if 70 - 70: OOooO
   for II11IiiIII in Oooo0 :
    name = i1iIiIIi ( II11IiiIII [ "display_name" ] )
    url = i1iIiIIi ( II11IiiIII [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    I11i . append ( name )
    iI11 . append ( url )
    if "hd" in name . lower ( ) :
     o00oOoOo0 . append ( "1" )
    else :
     o00oOoOo0 . append ( "0" )
    i1iiiii1 = list ( zip ( o00oOoOo0 , I11i , iI11 ) )
    if 34 - 34: ooO00oo % OOooO
 if o0O0O0ooo0oOO == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 3 - 3: i1I1ii1II1iII / I1I1i1 + OOooO . O000oo . II1iI
 Oo0ooo = sorted ( i1iiiii1 , key = lambda Ooo : int ( Ooo [ 0 ] ) , reverse = True )
 if 83 - 83: Ii1Ii1iiii11 + OoOO0ooOOoo0O
 I11II1i = 0
 if 22 - 22: OOoOoo00oo % iI1 * OoOO0ooOOoo0O - O0Oooo00 / OoOO
 I1IiiI . update ( 100 )
 if 86 - 86: OoOO0ooOOoo0O . iI1 % i1iIii1Ii1II / iiIIIIi1i1 * iI1 / O0Oooo00
 IIiIi11i1 ( '                                [COLOR yellow][I]LINKS FOR ' + O00 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 Oo0 = o0o . split ( ' ' )
 for Oo0000oOo , name , url in Oo0ooo :
  if O0Oo00O == 1 :
   oO = name
   if 60 - 60: I111i1i1111i * oooO0oo0oOOOO
  OO0ooo0o0O0Oooooo = 0
  if 17 - 17: I1I1i1 % O0Oo0oO0o / I111i1i1111i . OOooO * I1I1i1 - i1I1ii1II1iII
  for o0O0oo0 in Oo0 :
   if 41 - 41: OOoOoo00oo
   if not o0O0oo0 . lower ( ) in name . lower ( ) :
    OO0ooo0o0O0Oooooo = 1
    if 77 - 77: ooO00oo
  if OO0ooo0o0O0Oooooo == 0 :
   I11II1i = I11II1i + 1
   if O0Oo00O == 1 :
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                          [COLOR blue] ' + str ( oO ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                          [COLOR blue] ' + str ( oO ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 65 - 65: i1I1ii1II1iII . oooO0oo0oOOOO % Ii1Ii1iiii11 * II1iI
 if I11II1i == 0 :
  IIiIi11i1 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 38 - 38: i1iIii1Ii1II / iI1 % O0Oo0oO0o
 I1IiiI . close ( )
 if 11 - 11: iI1 - Ii1Ii1iiii11 + i1I1ii1II1iII - OoOO
def I1i11ii11 ( term ) :
 if 81 - 81: I1I1i1 - iiIIIIi1i1 % O000oo - II1iI / O0Oo0oO0o
 I1iI1iIi111i = [ ]
 iiIi1IIi1I = [ ]
 if 4 - 4: OoOO0ooOOoo0O - o0000oOoOoO0o % OOoOoo00oo - I1I1i1 * O0Oooo00
 I1i1I11I = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( I1i1I11I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = IIiiiiiiIi1I1
  if 85 - 85: OoOO0ooOOoo0O * OoOO . iI1 / OoOO0ooOOoo0O % oooO0oo0oOOOO % Ii1I
  O0O0oOO00O00o = O0O0oOO00O00o . replace ( '#AAASTREAM:' , '#A:' )
  O0O0oOO00O00o = O0O0oOO00O00o . replace ( '#EXTINF:' , '#A:' )
  o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O0O0oOO00O00o )
  o00o0II1I = [ ]
  for II1I1I1Ii , OOOOoO00o0O , O0O0oOO00O00o in o0oO000oo :
   I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : O0O0oOO00O00o }
   o00o0II1I . append ( I1I1I1IIi1III )
  list = [ ]
  for II11IiiIII in o00o0II1I :
   I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
   o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
   for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
    I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
   list . append ( I1I1I1IIi1III )
   if 36 - 36: OOoOoo00oo / i1I1ii1II1iII / OOooO / OOooO + I111i1i1111i
  for II11IiiIII in list :
   O000OO0 = i1iIiIIi ( II11IiiIII [ "display_name" ] )
   O0O0oOO00O00o = i1iIiIIi ( II11IiiIII [ "url" ] )
   O0O0oOO00O00o = O0O0oOO00O00o . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in O000OO0 . lower ( ) :
    I1iI1iIi111i . append ( O0O0oOO00O00o )
    iiIi1IIi1I . append ( O000OO0 )
    if 95 - 95: OOooO
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , iiIi1IIi1I )
 if OO < 0 :
  quit ( )
  if 51 - 51: i1I1ii1II1iII + OOooO . o0000oOoOoO0o . I111i1i1111i + i1iIii1Ii1II * oooO0oo0oOOOO
 O0O0oOO00O00o = I1iI1iIi111i [ OO ]
 O000OO0 = iiIi1IIi1I [ OO ]
 oOo0oO ( O000OO0 , O0O0oOO00O00o , iiiii )
 if 72 - 72: Ii1Ii1iiii11 + Ii1Ii1iiii11 / i1I1ii1II1iII . OoOO0ooOOoo0O % OOoOoo00oo
def III ( name , url , iconimage ) :
 if 41 - 41: i11iIiiIii + O0Oo0oO0o / oooO0oo0oOOOO . OoOO0ooOOoo0O % Ii1Ii1iiii11 % o0000oOoOoO0o
 list = oOO ( url )
 for II11IiiIII in list :
  name = i1iIiIIi ( II11IiiIII [ "display_name" ] )
  url = i1iIiIIi ( II11IiiIII [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  IIiIi11i1 ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 17 - 17: i1I1ii1II1iII / I111i1i1111i % OOooO + oooO0oo0oOOOO * ooO00oo
def oOO ( url ) :
 if 36 - 36: ooO00oo * II1iI
 I1I = ii1iIi1II ( url )
 I1I = I1I . replace ( '#AAASTREAM:' , '#A:' )
 I1I = I1I . replace ( '#EXTINF:' , '#A:' )
 o0oO000oo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( I1I )
 o00o0II1I = [ ]
 for II1I1I1Ii , OOOOoO00o0O , url in o0oO000oo :
  I1I1I1IIi1III = { "params" : II1I1I1Ii , "display_name" : OOOOoO00o0O , "url" : url }
  o00o0II1I . append ( I1I1I1IIi1III )
 list = [ ]
 for II11IiiIII in o00o0II1I :
  I1I1I1IIi1III = { "display_name" : II11IiiIII [ "display_name" ] , "url" : II11IiiIII [ "url" ] }
  o0oO000oo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II11IiiIII [ "params" ] )
  for o0OOOo , ii1iiIiIII1ii in o0oO000oo :
   I1I1I1IIi1III [ o0OOOo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1iiIiIII1ii . strip ( )
  list . append ( I1I1I1IIi1III )
  if 2 - 2: O0Oo0oO0o + i1iIii1Ii1II - I1I1i1 . oooO0oo0oOOOO - I1I1i1
 return list
 if 67 - 67: OoOO - iI1
 if 11 - 11: OoOO . OoOO0ooOOoo0O . i1I1ii1II1iII / o0000oOoOoO0o - iiIIIIi1i1
def ii1ii11 ( ) :
 if 84 - 84: Ii1I . iiIIIIi1i1 - i1I1ii1II1iII . O000oo / i1I1ii1II1iII
 I11iii1Ii ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 I11iii1Ii ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 I11iii1Ii ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 47 - 47: OoOO0ooOOoo0O
def ii1i1i1IiII ( name , url , iconimage ) :
 if 63 - 63: iI1 . II1iI / i1I1ii1II1iII * OOooO + Ii1Ii1iiii11 % OOoOoo00oo
 I1i11iIIi11 = datetime . datetime . now ( )
 ooOooo000OO00 = I1i11iIIi11 . day
 if 34 - 34: Ii1I % o0000oOoOoO0o - I1I1i1 + O0Oo0oO0o
 OoOo000oOo0oo = ooOooo000OO00
 if 65 - 65: i1iIii1Ii1II / II1iI % OOooO
 iIiIIii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OOo00 = datetime . datetime . strftime ( iIiIIii , '%A - %d %B %Y' )
 iIII = 'http://www.predictz.com/predictions/'
 if 48 - 48: OoOO % o0000oOoOoO0o % iI1 + O000oo
 Iiii11iIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 i1iI11I1II1 = datetime . datetime . strftime ( Iiii11iIi1 , '%A - %d %B %Y' )
 ii11II1i = datetime . datetime . strftime ( Iiii11iIi1 , '%d' )
 OOO = 'http://www.predictz.com/predictions/tomorrow/'
 if 89 - 89: O000oo + OOoOoo00oo * O000oo / O000oo
 i11i11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 OoOoO00O0 = datetime . datetime . strftime ( i11i11 , '%A - %d %B %Y' )
 OoOOO = datetime . datetime . strftime ( i11i11 , '%y%m%d' )
 o0o00Ooo0o = 'http://www.predictz.com/predictions/' + str ( OoOOO )
 if 76 - 76: i1I1ii1II1iII
 Ii1i1i1111 = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 o0oO0O00oOo = datetime . datetime . strftime ( Ii1i1i1111 , '%A - %d %B %Y' )
 I1111I1II11 = datetime . datetime . strftime ( Ii1i1i1111 , '%y%m%d' )
 iiiIIIIiIi = 'http://www.predictz.com/predictions/' + str ( I1111I1II11 )
 if 34 - 34: OoOO0ooOOoo0O . Ii1I / Ii1Ii1iiii11 * i1iIii1Ii1II - I111i1i1111i
 IiiiI = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 Iii = datetime . datetime . strftime ( IiiiI , '%A - %d %B %Y' )
 i1I1 = datetime . datetime . strftime ( IiiiI , '%y%m%d' )
 O0II11i11II = 'http://www.predictz.com/predictions/' + str ( i1I1 )
 if 29 - 29: O0Oo0oO0o % II1iI % OOooO . O0Oooo00 / OoOO0ooOOoo0O * O000oo
 o0 = datetime . date . today ( ) + datetime . timedelta ( days = 5 )
 OoO000O = datetime . datetime . strftime ( o0 , '%A - %d %B %Y' )
 OOo = datetime . datetime . strftime ( o0 , '%y%m%d' )
 iIIiiIIIi1I = 'http://www.predictz.com/predictions/' + str ( OOo )
 if 65 - 65: I111i1i1111i % Ii1I % OoOO * OOoOoo00oo
 iIIIIIiI1I1 = datetime . date . today ( ) + datetime . timedelta ( days = 6 )
 I11I1IIiiII1 = datetime . datetime . strftime ( iIIIIIiI1I1 , '%A - %d %B %Y' )
 IIIIIii1ii11 = datetime . datetime . strftime ( iIIIIIiI1I1 , '%y%m%d' )
 OOOooo0OooOoO = 'http://www.predictz.com/predictions/' + str ( IIIIIii1ii11 )
 if 91 - 91: Ii1Ii1iiii11 + oooO0oo0oOOOO
 if 59 - 59: oooO0oo0oOOOO + i11iIiiIii + o0000oOoOoO0o / iiIIIIi1i1
 I11iii1Ii ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOo00 ) + '[/B][/COLOR]' , iIII , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( i1iI11I1II1 ) + '[/B][/COLOR]' , OOO , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( OoOoO00O0 ) , o0o00Ooo0o , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( o0oO0O00oOo ) , iiiIIIIiIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( Iii ) , O0II11i11II , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( OoO000O ) , iIIiiIIIi1I , 41 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( I11I1IIiiII1 ) , OOOooo0OooOoO , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 44 - 44: iiIIIIi1i1 . i1iIii1Ii1II * oooO0oo0oOOOO + OoOO0ooOOoo0O - iI1 - OOooO
def I1iii ( name , url , iconimage ) :
 if 51 - 51: I111i1i1111i
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( I1i1I )
 Oo0 = str ( ooooooO0oo )
 oooooOOO000Oo = re . compile ( 'lc">(.+?)<td class="ta' ) . findall ( Oo0 )
 for IIiiiiiiIi1I1 in oooooOOO000Oo :
  try :
   Ii1iI111II1I1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   III1I1Ii11iI = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   Ii1iI111II1I1 = oO00OoOO ( Ii1iI111II1I1 )
   III1I1Ii11iI = oO00OoOO ( III1I1Ii11iI )
   IIiIi11i1 ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + III1I1Ii11iI + ' [/B][/COLOR]| [COLOR mediumpurple]' + Ii1iI111II1I1 + '[/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 18 - 18: O000oo - i1iIii1Ii1II % o0000oOoOoO0o + Ii1I + i11iIiiIii + o0000oOoOoO0o
def oOo0o0O ( name , url , iconimage ) :
 if 83 - 83: O0Oooo00 / I1I1i1 / I1I1i1 + O0Oooo00 * ooO00oo + O0Oooo00
 I1i11iIIi11 = datetime . datetime . now ( )
 ooOooo000OO00 = I1i11iIIi11 . day
 if 36 - 36: i1iIii1Ii1II + O0Oooo00 - OoOO0ooOOoo0O . Ii1Ii1iiii11 . OoOO0ooOOoo0O / O0Oo0oO0o
 OoOo000oOo0oo = ooOooo000OO00
 if 72 - 72: o0000oOoOoO0o
 iIiIIii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OOo00 = datetime . datetime . strftime ( iIiIIii , '%A - %d %B %Y' )
 iIII = 'http://www.predictz.com/predictions/'
 if 82 - 82: i1iIii1Ii1II + OoOO0ooOOoo0O / i11iIiiIii * I111i1i1111i . OoOO0ooOOoo0O
 Iiii11iIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 i1iI11I1II1 = datetime . datetime . strftime ( Iiii11iIi1 , '%A - %d %B %Y' )
 ii11II1i = datetime . datetime . strftime ( Iiii11iIi1 , '%d' )
 OOO = 'http://www.predictz.com/predictions/tomorrow/'
 if 63 - 63: I111i1i1111i
 i11i11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 OoOoO00O0 = datetime . datetime . strftime ( i11i11 , '%A - %d %B %Y' )
 OoOOO = datetime . datetime . strftime ( i11i11 , '%y%m%d' )
 o0o00Ooo0o = 'http://www.predictz.com/predictions/' + str ( OoOOO )
 if 6 - 6: O000oo / I111i1i1111i
 Ii1i1i1111 = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 o0oO0O00oOo = datetime . datetime . strftime ( Ii1i1i1111 , '%A - %d %B %Y' )
 I1111I1II11 = datetime . datetime . strftime ( Ii1i1i1111 , '%y%m%d' )
 iiiIIIIiIi = 'http://www.predictz.com/predictions/' + str ( I1111I1II11 )
 if 57 - 57: iiIIIIi1i1
 IiiiI = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 Iii = datetime . datetime . strftime ( IiiiI , '%A - %d %B %Y' )
 i1I1 = datetime . datetime . strftime ( IiiiI , '%y%m%d' )
 O0II11i11II = 'http://www.predictz.com/predictions/' + str ( i1I1 )
 if 67 - 67: II1iI . O000oo
 o0 = datetime . date . today ( ) + datetime . timedelta ( days = 5 )
 OoO000O = datetime . datetime . strftime ( o0 , '%A - %d %B %Y' )
 OOo = datetime . datetime . strftime ( o0 , '%y%m%d' )
 iIIiiIIIi1I = 'http://www.predictz.com/predictions/' + str ( OOo )
 if 87 - 87: Ii1Ii1iiii11 % OOoOoo00oo
 iIIIIIiI1I1 = datetime . date . today ( ) + datetime . timedelta ( days = 6 )
 I11I1IIiiII1 = datetime . datetime . strftime ( iIIIIIiI1I1 , '%A - %d %B %Y' )
 IIIIIii1ii11 = datetime . datetime . strftime ( iIIIIIiI1I1 , '%y%m%d' )
 OOOooo0OooOoO = 'http://www.predictz.com/predictions/' + str ( IIIIIii1ii11 )
 if 83 - 83: i1I1ii1II1iII - iiIIIIi1i1
 if 35 - 35: o0000oOoOoO0o - OoOO + o0000oOoOoO0o
 I11iii1Ii ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOo00 ) + '[/B][/COLOR]' , iIII , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( i1iI11I1II1 ) + '[/B][/COLOR]' , OOO , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( OoOoO00O0 ) , o0o00Ooo0o , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( o0oO0O00oOo ) , iiiIIIIiIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( Iii ) , O0II11i11II , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( OoO000O ) , iIIiiIIIi1I , 51 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( I11I1IIiiII1 ) , OOOooo0OooOoO , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 86 - 86: OoOO + i1iIii1Ii1II . i11iIiiIii - OOoOoo00oo
def ooO000O ( name , url , iconimage ) :
 if 53 - 53: O0Oooo00 . iI1 / OOoOoo00oo
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( I1i1I )
 Oo0 = str ( ooooooO0oo )
 oooooOOO000Oo = re . compile ( 'lc">(.+?)<td class="ta' ) . findall ( Oo0 )
 for IIiiiiiiIi1I1 in oooooOOO000Oo :
  try :
   Ii1iI111II1I1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   I11iiIi1i1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   i1IiiI1iIi = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 1 ]
   oOOo00O0OOOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 2 ]
   Ii1iI111II1I1 = oO00OoOO ( Ii1iI111II1I1 )
   IIiIi11i1 ( '[COLOR mediumpurple][B]' + Ii1iI111II1I1 + '[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + I11iiIi1i1 + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + i1IiiI1iIi + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + oOOo00O0OOOo + ')[/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 31 - 31: iiIIIIi1i1 % I1I1i1 * iiIIIIi1i1
def IiII1i1iii1Ii ( name , url , iconimage ) :
 if 23 - 23: i11iIiiIii
 I1i11iIIi11 = datetime . datetime . now ( )
 ooOooo000OO00 = I1i11iIIi11 . day
 if 39 - 39: O0Oooo00 - I111i1i1111i % iI1 * II1iI - I1I1i1 / iI1
 OoOo000oOo0oo = ooOooo000OO00
 if 29 - 29: I111i1i1111i
 iIiIIii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OOo00 = datetime . datetime . strftime ( iIiIIii , '%A - %d %B %Y' )
 iIII = 'http://www.predictz.com/predictions/'
 if 52 - 52: i11iIiiIii / o0000oOoOoO0o
 Iiii11iIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 i1iI11I1II1 = datetime . datetime . strftime ( Iiii11iIi1 , '%A - %d %B %Y' )
 ii11II1i = datetime . datetime . strftime ( Iiii11iIi1 , '%d' )
 OOO = 'http://www.predictz.com/predictions/tomorrow/'
 if 1 - 1: O000oo
 i11i11 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 OoOoO00O0 = datetime . datetime . strftime ( i11i11 , '%A - %d %B %Y' )
 OoOOO = datetime . datetime . strftime ( i11i11 , '%y%m%d' )
 o0o00Ooo0o = 'http://www.predictz.com/predictions/' + str ( OoOOO )
 if 78 - 78: I111i1i1111i + iiIIIIi1i1 - Ii1I
 Ii1i1i1111 = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 o0oO0O00oOo = datetime . datetime . strftime ( Ii1i1i1111 , '%A - %d %B %Y' )
 I1111I1II11 = datetime . datetime . strftime ( Ii1i1i1111 , '%y%m%d' )
 iiiIIIIiIi = 'http://www.predictz.com/predictions/' + str ( I1111I1II11 )
 if 10 - 10: ooO00oo % oooO0oo0oOOOO
 IiiiI = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 Iii = datetime . datetime . strftime ( IiiiI , '%A - %d %B %Y' )
 i1I1 = datetime . datetime . strftime ( IiiiI , '%y%m%d' )
 O0II11i11II = 'http://www.predictz.com/predictions/' + str ( i1I1 )
 if 97 - 97: OoOO0ooOOoo0O - ooO00oo
 o0 = datetime . date . today ( ) + datetime . timedelta ( days = 5 )
 OoO000O = datetime . datetime . strftime ( o0 , '%A - %d %B %Y' )
 OOo = datetime . datetime . strftime ( o0 , '%y%m%d' )
 iIIiiIIIi1I = 'http://www.predictz.com/predictions/' + str ( OOo )
 if 58 - 58: OoOO + Ii1I
 iIIIIIiI1I1 = datetime . date . today ( ) + datetime . timedelta ( days = 6 )
 I11I1IIiiII1 = datetime . datetime . strftime ( iIIIIIiI1I1 , '%A - %d %B %Y' )
 IIIIIii1ii11 = datetime . datetime . strftime ( iIIIIIiI1I1 , '%y%m%d' )
 OOOooo0OooOoO = 'http://www.predictz.com/predictions/' + str ( IIIIIii1ii11 )
 if 30 - 30: O000oo % iI1 * I1I1i1 - I111i1i1111i * OOoOoo00oo % O000oo
 if 46 - 46: i11iIiiIii - Ii1I . Ii1Ii1iiii11
 I11iii1Ii ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOo00 ) + '[/B][/COLOR]' , iIII , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( i1iI11I1II1 ) + '[/B][/COLOR]' , OOO , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( OoOoO00O0 ) , o0o00Ooo0o , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( o0oO0O00oOo ) , iiiIIIIiIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( Iii ) , O0II11i11II , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( OoO000O ) , iIIiiIIIi1I , 61 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( str ( I11I1IIiiII1 ) , OOOooo0OooOoO , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 100 - 100: oooO0oo0oOOOO / O0Oooo00 * iI1 . Ii1I / I1I1i1
def oOO0o000Oo00o ( name , url , iconimage ) :
 if 21 - 21: OoOO0ooOOoo0O - OoOO
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( I1i1I )
 Oo0 = str ( ooooooO0oo )
 oooooOOO000Oo = re . compile ( 'lc">(.+?)<td class="ta' ) . findall ( Oo0 )
 for IIiiiiiiIi1I1 in oooooOOO000Oo :
  try :
   Ii1iI111II1I1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   I11II1i , IIIII = Ii1iI111II1I1 . split ( ' v ' )
   OO0OoOOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O00ooOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 1 ]
   oOO0o00O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 2 ]
   oOoOIIII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 3 ]
   iI1iiiIiii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 4 ]
   ii1i1i = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 5 ]
   II11iIII1i1I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 6 ]
   oOO0oo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 7 ]
   IiIIi1I1I11Ii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 8 ]
   o0OO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( IIiiiiiiIi1I1 ) [ 9 ]
   if 58 - 58: OoOO0ooOOoo0O . oooO0oo0oOOOO / i1I1ii1II1iII / i1I1ii1II1iII - OOooO + O0Oo0oO0o
   if OO0OoOOO0 == "W" :
    OO0OoOOO0 = '[COLOR lime]W[/COLOR]'
   elif OO0OoOOO0 == "D" :
    OO0OoOOO0 = '[COLOR yellow]D[/COLOR]'
   else : OO0OoOOO0 = '[COLOR red]L[/COLOR]'
   if 59 - 59: OoOO0ooOOoo0O + iiIIIIi1i1 . ooO00oo - Ii1I % OoOO / Ii1I
   if O00ooOo == "W" :
    O00ooOo = '[COLOR lime]W[/COLOR]'
   elif O00ooOo == "D" :
    O00ooOo = '[COLOR yellow]D[/COLOR]'
   else : O00ooOo = '[COLOR red]L[/COLOR]'
   if 88 - 88: O0Oo0oO0o . Ii1I % OoOO0ooOOoo0O / I1I1i1
   if oOO0o00O == "W" :
    oOO0o00O = '[COLOR lime]W[/COLOR]'
   elif oOO0o00O == "D" :
    oOO0o00O = '[COLOR yellow]D[/COLOR]'
   else : oOO0o00O = '[COLOR red]L[/COLOR]'
   if 89 - 89: i1I1ii1II1iII / Ii1Ii1iiii11
   if oOoOIIII == "W" :
    oOoOIIII = '[COLOR lime]W[/COLOR]'
   elif oOoOIIII == "D" :
    oOoOIIII = '[COLOR yellow]D[/COLOR]'
   else : oOoOIIII = '[COLOR red]L[/COLOR]'
   if 14 - 14: I1I1i1 . oooO0oo0oOOOO * O000oo + i1I1ii1II1iII - O000oo + I1I1i1
   if iI1iiiIiii == "W" :
    iI1iiiIiii = '[COLOR lime]W[/COLOR]'
   elif iI1iiiIiii == "D" :
    iI1iiiIiii = '[COLOR yellow]D[/COLOR]'
   else : iI1iiiIiii = '[COLOR red]L[/COLOR]'
   if 18 - 18: Ii1Ii1iiii11 - O0Oooo00 - oooO0oo0oOOOO - oooO0oo0oOOOO
   if ii1i1i == "W" :
    ii1i1i = '[COLOR lime]W[/COLOR]'
   elif ii1i1i == "D" :
    ii1i1i = '[COLOR yellow]D[/COLOR]'
   else : ii1i1i = '[COLOR red]L[/COLOR]'
   if 54 - 54: O0Oo0oO0o + oooO0oo0oOOOO / iI1 . oooO0oo0oOOOO * i1iIii1Ii1II
   if II11iIII1i1I == "W" :
    II11iIII1i1I = '[COLOR lime]W[/COLOR]'
   elif II11iIII1i1I == "D" :
    II11iIII1i1I = '[COLOR yellow]D[/COLOR]'
   else : II11iIII1i1I = '[COLOR red]L[/COLOR]'
   if 1 - 1: i1iIii1Ii1II * II1iI . o0000oOoOoO0o / O0Oo0oO0o . I111i1i1111i + O0Oo0oO0o
   if oOO0oo == "W" :
    oOO0oo = '[COLOR lime]W[/COLOR]'
   elif oOO0oo == "D" :
    oOO0oo = '[COLOR yellow]D[/COLOR]'
   else : oOO0oo = '[COLOR red]L[/COLOR]'
   if 17 - 17: O0Oo0oO0o + II1iI / OOoOoo00oo / iI1 * I1I1i1
   if IiIIi1I1I11Ii == "W" :
    IiIIi1I1I11Ii = '[COLOR lime]W[/COLOR]'
   elif IiIIi1I1I11Ii == "D" :
    IiIIi1I1I11Ii = '[COLOR yellow]D[/COLOR]'
   else : IiIIi1I1I11Ii = '[COLOR red]L[/COLOR]'
   if 29 - 29: II1iI % OoOO0ooOOoo0O * Ii1Ii1iiii11 / i1I1ii1II1iII - Ii1Ii1iiii11
   if o0OO == "W" :
    o0OO = '[COLOR lime]W[/COLOR]'
   elif o0OO == "D" :
    o0OO = '[COLOR yellow]D[/COLOR]'
   else : o0OO = '[COLOR red]L[/COLOR]'
   if 19 - 19: i11iIiiIii
   I11II1i = oO00OoOO ( I11II1i )
   IIIII = oO00OoOO ( IIIII )
   IIiIi11i1 ( '[COLOR mediumpurple][B]' + I11II1i + ' Form Guide[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[B]' + OO0OoOOO0 + '  ' + O00ooOo + '  ' + oOO0o00O + '  ' + oOoOIIII + '  ' + iI1iiiIiii + '[/B]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[COLOR mediumpurple][B]' + IIIII + ' Form Guide[/B][/COLOR]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
   IIiIi11i1 ( '[B]' + ii1i1i + '  ' + II11iIII1i1I + '  ' + oOO0oo + '  ' + IiIIi1I1I11Ii + '  ' + o0OO + '[/B]' , 'url' , 20 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 54 - 54: i1I1ii1II1iII . iiIIIIi1i1
def oOOII1i11i1iIi11 ( ) :
 if 83 - 83: OOoOoo00oo
 Oo0 = ''
 I1iI1I1 = xbmc . Keyboard ( Oo0 , 'Enter Search Term' )
 I1iI1I1 . doModal ( )
 if I1iI1I1 . isConfirmed ( ) :
  Oo0 = I1iI1I1 . getText ( )
  if len ( Oo0 ) > 1 :
   O0O0oOO00O00o = Oo0 + "!" + iiiii
   iIiiiii1i ( "all " + Oo0 , O0O0oOO00O00o , iiiii )
  else : quit ( )
  if 48 - 48: oooO0oo0oOOOO / i11iIiiIii - O0Oooo00 * Ii1Ii1iiii11 / OoOO0ooOOoo0O
def OoOo ( name , url , iconimage ) :
 if 17 - 17: OOoOoo00oo . i11iIiiIii
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 5 - 5: I111i1i1111i + Ii1I + Ii1I . ooO00oo - O000oo
  if 63 - 63: Ii1Ii1iiii11
  if 71 - 71: o0000oOoOoO0o . OOoOoo00oo * iI1 % OoOO0ooOOoo0O + I1I1i1
  if 36 - 36: OOooO
  if 49 - 49: I1I1i1 / OoOO0ooOOoo0O / oooO0oo0oOOOO
def o0OooooOoOO ( name ) :
 if 19 - 19: OOooO
 O0o = 0
 if 78 - 78: I1I1i1 % O0Oooo00
 try :
  oOO00oOO ( "http://www.google.com" )
 except :
  O00ooooo00 . ok ( Oo0Ooo , '[COLOR red]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/COLOR]' )
  sys . exit ( 0 )
  if 39 - 39: I111i1i1111i + oooO0oo0oOOOO - OoOO - O0Oooo00
 try :
  I1IiiI . create ( Oo0Ooo , "Checking for repository updates" , '' , 'Please Wait...' )
  I1IiiI . update ( 0 )
  I11II1i = open ( I11i11Ii ) . read ( )
  IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   I1IiiI . update ( 25 )
   I1IIIii = float ( IIiiiiiiIi1I1 ) + 0.01
   O0O0oOO00O00o = OOOo0 + str ( I1IIIii ) + '.zip'
   I1i1I11I = oOO00oOO ( O0O0oOO00O00o )
   if "Not Found" not in I1i1I11I :
    O0o = 1
    I1IiiI . update ( 75 )
    i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( i1iIIi1 ) :
     os . makedirs ( i1iIIi1 )
    I1i = os . path . join ( i1iIIi1 , 'repoupdate.zip' )
    try : os . remove ( I1i )
    except : pass
    I1IiiI . update ( 100 )
    I1IiiI . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( O0O0oOO00O00o , I1i , I1IiiI )
    i1II1iII = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    I1IiiI . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( I1i , i1II1iII , I1IiiI )
    try : os . remove ( I1i )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    O00ooooo00 . ok ( Oo0Ooo , "ECHO repository was updated to " + str ( I1IIIii ) + ', you may need to restart the addon for changes to take effect' )
    if 8 - 8: i1iIii1Ii1II / Ii1I * Ii1I % ooO00oo - O0Oo0oO0o + iiIIIIi1i1
  I1IiiI . update ( 75 , "Checking for addon updates" )
  I11II1i = open ( IIi1IiiiI1Ii ) . read ( )
  IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   I1IIIii = float ( IIiiiiiiIi1I1 ) + 0.01
   O0O0oOO00O00o = oO00oOo + str ( I1IIIii ) + '.zip'
   I1i1I11I = oOO00oOO ( O0O0oOO00O00o )
   if "Not Found" not in I1i1I11I :
    O0o = 1
    I1IiiI . update ( 75 )
    i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( i1iIIi1 ) :
     os . makedirs ( i1iIIi1 )
    I1i = os . path . join ( i1iIIi1 , 'wizupdate.zip' )
    try : os . remove ( I1i )
    except : pass
    I1IiiI . update ( 100 )
    I1IiiI . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( O0O0oOO00O00o , I1i , I1IiiI )
    i1II1iII = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    I1IiiI . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( I1i , i1II1iII , I1IiiI )
    try : os . remove ( I1i )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    I1IiiI . update ( 100 )
    I1IiiI . close
    O00ooooo00 . ok ( Oo0Ooo , "Sportie was updated to " + str ( I1IIIii ) + ', you may need to restart the addon for changes to take effect' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , 'Sorry! We encountered an error whilst checking for updates. You can make Kodi force check the repository for updates as an alternative if you wish.' )
  quit ( )
  if 83 - 83: Ii1I . oooO0oo0oOOOO
 if I1IiiI . iscanceled ( ) :
  I1IiiI . close ( )
 else :
  if O0o == 0 :
   if not name == "no dialog" :
    O00ooooo00 . ok ( Oo0Ooo , "There are no updates at this time." )
    quit ( )
    if 95 - 95: iiIIIIi1i1 . OoOO0ooOOoo0O - o0000oOoOoO0o - OoOO0ooOOoo0O - II1iI % OoOO
def Oo0OO0000oooo ( text ) :
 if 64 - 64: I1I1i1 + OoOO0ooOOoo0O * OoOO0ooOOoo0O
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 41 - 41: O000oo . O0Oo0oO0o + oooO0oo0oOOOO
 return text
 if 100 - 100: OOoOoo00oo + II1iI
def oO00OoOO ( text ) :
 if 73 - 73: o0000oOoOoO0o - ooO00oo % O000oo / II1iI
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 40 - 40: I111i1i1111i * O000oo - oooO0oo0oOOOO / OOooO / i11iIiiIii
 return text
 if 83 - 83: I111i1i1111i / ooO00oo - i11iIiiIii . OoOO + O0Oo0oO0o
def Ooo00OoOOO ( text ) :
 if 59 - 59: Ii1I % O0Oo0oO0o
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 92 - 92: OOoOoo00oo % iI1 / I111i1i1111i % I111i1i1111i * oooO0oo0oOOOO
 return text
 if 74 - 74: Ii1I . oooO0oo0oOOOO % II1iI % OOooO
def oOo0oO ( name , url , iconimage ) :
 if 87 - 87: Ii1Ii1iiii11 - i11iIiiIii
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 78 - 78: i11iIiiIii / OoOO - O0Oooo00
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 23 - 23: iiIIIIi1i1
 iIiiIiiIi = url
 i1iiIIIi = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 i1iiIIIi . setPath ( iIiiIiiIi )
 xbmc . Player ( ) . play ( iIiiIiiIi , i1iiIIIi , False )
 if 62 - 62: Ii1I / oooO0oo0oOOOO % Ii1I * II1iI % oooO0oo0oOOOO
def oOO00oOO ( url ) :
 if 33 - 33: oooO0oo0oOOOO . Ii1Ii1iiii11 * II1iI * OoOO
 II11 = urllib2 . Request ( url )
 II11 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 I1I = urllib2 . urlopen ( II11 )
 I1i1I = I1I . read ( )
 I1I . close ( )
 I1i1I = I1i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return I1i1I
 if 12 - 12: ooO00oo
def ii1iIi1II ( url ) :
 if 93 - 93: i11iIiiIii % OoOO % i11iIiiIii + O0Oooo00 / O0Oooo00 / i1I1ii1II1iII
 II11 = urllib2 . Request ( url )
 II11 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 I1I = urllib2 . urlopen ( II11 )
 I1i1I = I1I . read ( )
 I1I . close ( )
 return I1i1I
 if 49 - 49: I1I1i1 . I111i1i1111i . i11iIiiIii - i1I1ii1II1iII / OOoOoo00oo
def i1iIiIIi ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 62 - 62: I1I1i1
 if 1 - 1: OOooO / OOooO - i11iIiiIii
 if 87 - 87: O0Oo0oO0o / Ii1I * OOooO / O0Oooo00
 if 19 - 19: ooO00oo + o0000oOoOoO0o . oooO0oo0oOOOO - O0Oo0oO0o
 if 16 - 16: Ii1Ii1iiii11 + O000oo / O0Oooo00
def O00oOoo0OoO0 ( ) :
 if 62 - 62: o0000oOoOoO0o / O000oo . oooO0oo0oOOOO * O0Oooo00
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 21 - 21: O0Oooo00
 if os . path . exists ( Oooo000o ) == True :
  for O0Oo0 , o0oO0oo0000OO , I1i1ii1IiIii in os . walk ( Oooo000o ) :
   oOOO0O0Ooo = 0
   oOOO0O0Ooo += len ( I1i1ii1IiIii )
   if oOOO0O0Ooo > 0 :
    for Ii in I1i1ii1IiIii :
     try :
      if ( Ii . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( O0Oo0 , Ii ) )
     except :
      pass
    for I1i111IiIiIi1 in o0oO0oo0000OO :
     try :
      shutil . rmtree ( os . path . join ( O0Oo0 , I1i111IiIiIi1 ) )
     except :
      pass
      if 39 - 39: iiIIIIi1i1 - I111i1i1111i
   else :
    pass
    if 53 - 53: O0Oooo00 % iI1 + O000oo . O0Oo0oO0o - I111i1i1111i % O0Oooo00
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for O0Oo0 , o0oO0oo0000OO , I1i1ii1IiIii in os . walk ( IiIi11iIIi1Ii ) :
   oOOO0O0Ooo = 0
   oOOO0O0Ooo += len ( I1i1ii1IiIii )
   if oOOO0O0Ooo > 0 :
    for Ii in I1i1ii1IiIii :
     try :
      if ( Ii . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( O0Oo0 , Ii ) )
     except :
      pass
    for I1i111IiIiIi1 in o0oO0oo0000OO :
     try :
      shutil . rmtree ( os . path . join ( O0Oo0 , I1i111IiIiIi1 ) )
     except :
      pass
      if 64 - 64: i1I1ii1II1iII
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iIIIiIi1I1i = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 78 - 78: OoOO % i1iIii1Ii1II + I111i1i1111i / o0000oOoOoO0o % i1I1ii1II1iII + I1I1i1
  for O0Oo0 , o0oO0oo0000OO , I1i1ii1IiIii in os . walk ( iIIIiIi1I1i ) :
   oOOO0O0Ooo = 0
   oOOO0O0Ooo += len ( I1i1ii1IiIii )
   if 91 - 91: OoOO % II1iI . O0Oooo00 + OOoOoo00oo + O0Oooo00
   if oOOO0O0Ooo > 0 :
    for Ii in I1i1ii1IiIii :
     os . unlink ( os . path . join ( O0Oo0 , Ii ) )
    for I1i111IiIiIi1 in o0oO0oo0000OO :
     shutil . rmtree ( os . path . join ( O0Oo0 , I1i111IiIiIi1 ) )
     if 95 - 95: OOoOoo00oo + I111i1i1111i * I1I1i1
   else :
    pass
  I1Ii = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 77 - 77: OoOO - o0000oOoOoO0o . Ii1Ii1iiii11
  for O0Oo0 , o0oO0oo0000OO , I1i1ii1IiIii in os . walk ( I1Ii ) :
   oOOO0O0Ooo = 0
   oOOO0O0Ooo += len ( I1i1ii1IiIii )
   if 26 - 26: O0Oooo00 * OOooO . o0000oOoOoO0o
   if oOOO0O0Ooo > 0 :
    for Ii in I1i1ii1IiIii :
     os . unlink ( os . path . join ( O0Oo0 , Ii ) )
    for I1i111IiIiIi1 in o0oO0oo0000OO :
     shutil . rmtree ( os . path . join ( O0Oo0 , I1i111IiIiIi1 ) )
     if 59 - 59: Ii1I + o0000oOoOoO0o - O0Oooo00
   else :
    pass
    if 62 - 62: i11iIiiIii % I1I1i1 . OOooO . I1I1i1
 Oooo = OoO000 ( )
 if 84 - 84: i11iIiiIii * II1iI
 for I1I1iII1i in Oooo :
  iiIIii = xbmc . translatePath ( I1I1iII1i . path )
  if os . path . exists ( iiIIii ) == True :
   for O0Oo0 , o0oO0oo0000OO , I1i1ii1IiIii in os . walk ( iiIIii ) :
    oOOO0O0Ooo = 0
    oOOO0O0Ooo += len ( I1i1ii1IiIii )
    if oOOO0O0Ooo > 0 :
     for Ii in I1i1ii1IiIii :
      os . unlink ( os . path . join ( O0Oo0 , Ii ) )
     for I1i111IiIiIi1 in o0oO0oo0000OO :
      shutil . rmtree ( os . path . join ( O0Oo0 , I1i111IiIiIi1 ) )
      if 70 - 70: O0Oooo00 - I1I1i1
    else :
     pass
     if 62 - 62: iiIIIIi1i1
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 63 - 63: I1I1i1 + O000oo * Ii1Ii1iiii11 / O0Oooo00 / O0Oo0oO0o * OoOO
def OOoO00ooO ( ) :
 I1IIIIiii1i = [ ]
 o0IiiiI111I = sys . argv [ 2 ]
 if len ( o0IiiiI111I ) >= 2 :
  II1I1I1Ii = sys . argv [ 2 ]
  III1I11i1iIi = II1I1I1Ii . replace ( '?' , '' )
  if ( II1I1I1Ii [ len ( II1I1I1Ii ) - 1 ] == '/' ) :
   II1I1I1Ii = II1I1I1Ii [ 0 : len ( II1I1I1Ii ) - 2 ]
  OO0oo0O0OOO0 = III1I11i1iIi . split ( '&' )
  I1IIIIiii1i = { }
  for i1IiiiI1iI in range ( len ( OO0oo0O0OOO0 ) ) :
   OoOOo = { }
   OoOOo = OO0oo0O0OOO0 [ i1IiiiI1iI ] . split ( '=' )
   if ( len ( OoOOo ) ) == 2 :
    I1IIIIiii1i [ OoOOo [ 0 ] ] = OoOOo [ 1 ]
 return I1IIIIiii1i
 if 46 - 46: oooO0oo0oOOOO / OOoOoo00oo . ooO00oo % i11iIiiIii + O0Oooo00 + OoOO0ooOOoo0O
def I11iii1Ii ( name , url , mode , iconimage , fanart , description = '' ) :
 if 93 - 93: OOoOoo00oo - OOooO . ooO00oo % OoOO % iiIIIIi1i1
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 Ii11IiIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OOo0o = True
 i1iiIIIi = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1iiIIIi . setProperty ( "fanart_Image" , fanart )
 i1iiIIIi . setProperty ( "icon_Image" , iconimage )
 OOo0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii11IiIi , listitem = i1iiIIIi , isFolder = True )
 return OOo0o
 if 20 - 20: II1iI / OoOO
def IIiIi11i1 ( name , url , mode , iconimage , fanart , description = '' ) :
 if 15 - 15: Ii1Ii1iiii11 . O0Oooo00
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 Ii11IiIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OOo0o = True
 i1iiIIIi = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1iiIIIi . setProperty ( "fanart_Image" , fanart )
 i1iiIIIi . setProperty ( "icon_Image" , iconimage )
 OOo0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii11IiIi , listitem = i1iiIIIi , isFolder = False )
 return OOo0o
 if 21 - 21: OoOO / i1I1ii1II1iII % o0000oOoOoO0o
II1I1I1Ii = OOoO00ooO ( ) ; O0O0oOO00O00o = None ; O000OO0 = None ; IIiI1i = None ; iII1 = None ; Oo0o00 = None ; O0 = None
try : iII1 = urllib . unquote_plus ( II1I1I1Ii [ "site" ] )
except : pass
try : O0O0oOO00O00o = urllib . unquote_plus ( II1I1I1Ii [ "url" ] )
except : pass
try : O000OO0 = urllib . unquote_plus ( II1I1I1Ii [ "name" ] )
except : pass
try : IIiI1i = int ( II1I1I1Ii [ "mode" ] )
except : pass
try : Oo0o00 = urllib . unquote_plus ( II1I1I1Ii [ "iconimage" ] )
except : pass
try : O0 = urllib . unquote_plus ( II1I1I1Ii [ "fanart" ] )
except : pass
if 70 - 70: iI1 / I1I1i1 % O000oo - OOoOoo00oo
if IIiI1i == None or O0O0oOO00O00o == None or len ( O0O0oOO00O00o ) < 1 : oO00O00o0OOO0 ( )
elif IIiI1i == 1 : III1iII1I1ii ( O000OO0 , O0O0oOO00O00o )
elif IIiI1i == 2 : oOo0oO ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 3 : i1 ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 4 : PLAYSD ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 8 : OoO0o ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 9 : o0OooooOoOO ( O000OO0 )
elif IIiI1i == 10 : III ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 11 : Oo0O0oooo ( )
elif IIiI1i == 12 : IIiIi ( O0O0oOO00O00o )
elif IIiI1i == 19 : OOOO0O00o ( O0O0oOO00O00o )
elif IIiI1i == 20 : iIiiiii1i ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 21 : iii11I ( O0O0oOO00O00o )
elif IIiI1i == 22 : I1II ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 23 : OooO0oo ( )
elif IIiI1i == 24 : oO00oooOOoOo0 ( )
elif IIiI1i == 25 : i1OOoO ( )
elif IIiI1i == 26 : ii1ii11 ( )
elif IIiI1i == 30 : Ii1I1Ii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 40 : ii1i1i1IiII ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 41 : I1iii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 50 : oOo0o0O ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 51 : ooO000O ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 60 : IiII1i1iii1Ii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 61 : oOO0o000Oo00o ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 100 : oOOII1i11i1iIi11 ( )
elif IIiI1i == 500 : O00oOoo0OoO0 ( )
elif IIiI1i == 201 : oO00oOOoooO ( )
elif IIiI1i == 202 : i1I1IiiIi1i ( O0O0oOO00O00o )
elif IIiI1i == 203 : IiII111i1i11 ( O0O0oOO00O00o )
elif IIiI1i == 204 : II11Iiii ( O0O0oOO00O00o )
elif IIiI1i == 205 : o0ooo0 ( O0O0oOO00O00o )
elif IIiI1i == 206 : IiiiIiii11 ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 210 : II1i11I ( O0O0oOO00O00o )
elif IIiI1i == 220 : IIIIiIiIi1 ( O0O0oOO00O00o )
elif IIiI1i == 221 : II1I1Ii ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
elif IIiI1i == 800 : OoOo ( O000OO0 , O0O0oOO00O00o , Oo0o00 )
if 47 - 47: iI1
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )