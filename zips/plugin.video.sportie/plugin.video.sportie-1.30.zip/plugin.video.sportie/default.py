import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluX21lbnUueG1s' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = xbmc . translatePath ( 'special://home/addons/program.plexus' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
Oooo000o = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oo0O = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
OOo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
Ii1IIii11 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 55 - 55: i1111 - i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
oO000OoOoo00o = plugintools . get_setting ( "scrape1" )
iiiI11 = plugintools . get_setting ( "scrape2" )
OOooO = plugintools . get_setting ( "scrape3" )
if 58 - 58: i11iiII + OooooO0oOO + oOo0 / oo0Ooo0
I1I11I1I1I = IiiIII111iI + '|SPLIT|' + o0O
checker . check ( I1I11I1I1I )
if 90 - 90: i1IIiiiii + i1iIIIiI1I - OoO000 % OooOoO0Oo + iiIIiIiIi
if not os . path . isfile ( ooo0OO ) :
 plugintools . open_settings_dialog ( )
 if 38 - 38: i1IIiiiii / I11i1i11i1I
if not os . path . exists ( IiII ) :
 os . makedirs ( IiII )
 if 76 - 76: oooO0oo0oOOOO / oo0ooO0oOOOOo . i1IIi11111i * i1IIiiiii - oOo0
if not os . path . isfile ( i1i1II ) :
 Oooo = open ( i1i1II , 'w' )
 if 67 - 67: oOo0 / i111I % oo0Ooo0 - ooO0oo0oO0
if not os . path . isfile ( iI1Ii11111iIi ) :
 Oooo = open ( iI1Ii11111iIi , 'w' )
 if 82 - 82: i11iIiiIii . oOo0 / I11i1i11i1I * oooO0oo0oOOOO % OooooO0oOO % ooO0oo0oO0
if not os . path . isfile ( O0oo0OO0 ) :
 Oooo = open ( O0oo0OO0 , 'w' )
 if 78 - 78: ooO0oo0oO0 - i1IIiiiii * oo + oo0ooO0oOOOOo + i1iIIIiI1I + i1iIIIiI1I
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 11 - 11: i1iIIIiI1I - oo % iiIIiIiIi % i1iIIIiI1I / OOO0O - oo
class o0o0oOOOo0oo ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 80 - 80: oo0Ooo0 * i11iIiiIii / OooOoO0Oo
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 9 - 9: i1IIiiiii + OooooO0oOO % i1IIiiiii + II1Ii1iI1i . oOo0
III1i1i = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 26 - 26: i111I
class IiiI11Iiiii :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 18 - 18: oo0ooO0oOOOOo
  if 28 - 28: oOo0 - OoO000 . OoO000 + OOO0O - i111I + oooO0oo0oOOOO
  if 95 - 95: oo % OooooO0oOO . oooO0oo0oOOOO
  if 15 - 15: iiIIiIiIi / i1IIiiiii . i1IIiiiii - II1Ii1iI1i
def o00oOO0 ( ) :
 oOoo = 5
 iIii11I = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 OOO0OOO00oo = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 31 - 31: i1111 - oOo0 . OooOoO0Oo % OOO0O - oooO0oo0oOOOO
 iii11 = [ ]
 if 58 - 58: oOo0 * i11iIiiIii / OOO0O % OooOoO0Oo - i11iiII / OooooO0oOO
 for ii11i1 in range ( oOoo ) :
  iii11 . append ( IiiI11Iiiii ( iIii11I [ ii11i1 ] , OOO0OOO00oo [ ii11i1 ] ) )
  if 29 - 29: i11iiII % i1IIi11111i + iiIIiIiIi / oo0ooO0oOOOOo + oOo0 * oo0ooO0oOOOOo
 return iii11
 if 42 - 42: i1IIiiiii + OooooO0oOO
def o0O0o0Oo ( ) :
 if 16 - 16: oooO0oo0oOOOO - OooOoO0Oo * ooO0oo0oO0 + i1iIIIiI1I
 Ii11iII1 = Oo0O0O0ooO0O ( OOo )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = i1i1II
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 70 - 70: OoO000 * I11i1i11i1I * oo0Ooo0 / i1IIiiiii
 Ii11iII1 = Oo0O0O0ooO0O ( iiI1iIiI )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = iI1Ii11111iIi
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 88 - 88: oooO0oo0oOOOO
 Ii11iII1 = Oo0O0O0ooO0O ( Ii1IIii11 )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = O0oo0OO0
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 64 - 64: oo0Ooo0 * oooO0oo0oOOOO + OoO000 - oOo0 + i11iIiiIii * i1IIiiiii
 iII = o0 ( II1 )
 ooOooo000oOO = II1
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 80 - 80: OooooO0oOO + oOo0 - oOo0 % i1iIIIiI1I
  if '<search>display</search>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 97 - 97: iiIIiIiIi % i1iIIIiI1I * i1IIiiiii + oo0ooO0oOOOOo . oOo0 + oOo0
  elif '<arenavision>display</arenavision>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   if os . path . exists ( oO00oOo ) : II11i1I11Ii1i ( OoOO0oo0o , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : Oooo0O0oo00oO ( '[COLOR darkgray]' + OoOO0oo0o + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 14 - 14: OOO0O / OoO000 . OOO0O . oo0Ooo0 % oo * oo0Ooo0
   if 16 - 16: OOO0O . iiIIiIiIi + i11iIiiIii
  elif '<vip>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 38 - 38: OoO000 * oOo0 . oo0ooO0oOOOOo
  elif '<divider>null</divider>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oooo0O0oo00oO ( OoOO0oo0o , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 98 - 98: i111I + i1iIIIiI1I . OOO0O
   if 67 - 67: i11iIiiIii - II1Ii1iI1i % i11iiII . oooO0oo0oOOOO
   if 77 - 77: OoO000 / i1IIi11111i
   if 15 - 15: OoO000 . ooO0oo0oO0 . i111I / i11iIiiIii - i1IIiiiii . II1Ii1iI1i
   if 33 - 33: oo0Ooo0 . oo0ooO0oOOOOo
   if 75 - 75: oo0ooO0oOOOOo % oo0ooO0oOOOOo . OooOoO0Oo
  elif '<m3ulists>display</m3ulists>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 5 - 5: oo0ooO0oOOOOo * iiIIiIiIi + OOO0O . oOo0 + OOO0O
   if 91 - 91: oooO0oo0oOOOO
   if 61 - 61: i1111
   if 64 - 64: iiIIiIiIi / OOO0O - oooO0oo0oOOOO - oo0Ooo0
   if 86 - 86: oo0Ooo0 % OOO0O / i1IIi11111i / OOO0O
   if 42 - 42: oo
   if 67 - 67: OooOoO0Oo . i1iIIIiI1I . oooO0oo0oOOOO
   if 10 - 10: i11iiII % i11iiII - ooO0oo0oO0 / oOo0 + i1IIiiiii
   if 87 - 87: OooooO0oOO * i11iiII + oOo0 / ooO0oo0oO0 / i1iIIIiI1I
   if 37 - 37: i1iIIIiI1I - iiIIiIiIi * OooooO0oOO % i11iIiiIii - OooOoO0Oo
   if 83 - 83: oo0Ooo0 / i1IIi11111i
   if 34 - 34: OoO000
   if 57 - 57: OooooO0oOO . oo0Ooo0 . II1Ii1iI1i
   if 42 - 42: oo0Ooo0 + i11iiII % oooO0oo0oOOOO
   if 6 - 6: OooooO0oOO
   if 68 - 68: OOO0O - oo
   if 28 - 28: oo . oOo0 / oOo0 + I11i1i11i1I . i11iiII
   if 1 - 1: ooO0oo0oO0 / i1111
   if 33 - 33: oo0Ooo0
   if 18 - 18: oo0ooO0oOOOOo % i1iIIIiI1I * oooO0oo0oOOOO
   if 87 - 87: i11iIiiIii
   if 93 - 93: i11iiII - oo % i11iIiiIii . i1iIIIiI1I / i1iIIIiI1I - OooOoO0Oo
  elif '<sportsdevil>' in Oo0OoO00oOO0o :
   IIII = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o )
   if len ( IIII ) == 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    o00oooO0Oo = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    o0O0OOO0Ooo = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiII1 = o0O0OOO0Ooo
    OOO00O0O = "/"
    if not iiIiII1 . endswith ( OOO00O0O ) :
     iii = iiIiII1 + "/"
    else :
     iii = iiIiII1
    iII = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( OoOO0oo0o ) + '%26url=' + o00oooO0Oo
    o00oooO0Oo = iII + '%26referer=' + iii
    Oooo0O0oo00oO ( OoOO0oo0o , o00oooO0Oo , 4 , iiIiI , oOooOOOoOo )
   elif len ( IIII ) > 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oooo0O0oo00oO ( OoOO0oo0o , ooOooo000oOO + 'NOTPLAY' , 8 , iiIiI , oOooOOOoOo )
  elif '<plexus>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : Oooo0O0oo00oO ( OoOO0oo0o , ooOooo000oOO + 'NOTPLAY' , 7 , iiIiI , oOooOOOoOo )
   else : Oooo0O0oo00oO ( '[COLOR darkgray]' + OoOO0oo0o + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 41 - 41: i1IIiiiii - oooO0oo0oOOOO - oooO0oo0oOOOO
  elif '<rutubeplaylist>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   II11i1I11Ii1i ( OoOO0oo0o , ooOooo000oOO , 90 , iiIiI , oOooOOOoOo )
  elif '<folder>' in Oo0OoO00oOO0o :
   oO00OOoO00 = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for OoOO0oo0o , o00oooO0Oo , iiIiI , oOooOOOoOo in oO00OOoO00 :
    II11i1I11Ii1i ( OoOO0oo0o , o00oooO0Oo , 1 , iiIiI , oOooOOOoOo )
  elif '<m3u>' in Oo0OoO00oOO0o :
   oO00OOoO00 = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for OoOO0oo0o , o00oooO0Oo , iiIiI , oOooOOOoOo in oO00OOoO00 :
    II11i1I11Ii1i ( OoOO0oo0o , o00oooO0Oo , 10 , iiIiI , oOooOOOoOo )
  else :
   IIII = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o )
   if len ( IIII ) == 1 :
    oO00OOoO00 = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
    IiI111111IIII = len ( Oo0oOOo )
    for OoOO0oo0o , o00oooO0Oo , iiIiI , oOooOOOoOo in oO00OOoO00 :
     Oooo0O0oo00oO ( OoOO0oo0o , o00oooO0Oo , 2 , iiIiI , oOooOOOoOo )
   elif len ( IIII ) > 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oooo0O0oo00oO ( OoOO0oo0o , II1 , 3 , iiIiI , oOooOOOoOo )
    if 37 - 37: OooOoO0Oo / OOO0O
 i1 = open ( IIi1IiiiI1Ii ) . read ( )
 I1iI1iIi111i = i1 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo0oOOo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( I1iI1iIi111i ) )
 for Oo0OoO00oOO0o in Oo0oOOo :
  iiIi1IIi1I = float ( Oo0OoO00oOO0o )
 i1 = open ( I11i11Ii ) . read ( )
 I1iI1iIi111i = i1 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo0oOOo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( I1iI1iIi111i ) )
 for Oo0OoO00oOO0o in Oo0oOOo :
  o0OoOO000ooO0 = float ( Oo0OoO00oOO0o )
  if 56 - 56: i1iIIIiI1I
 Oooo0O0oo00oO ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 Oooo0O0oo00oO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 Oooo0O0oo00oO ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 Oooo0O0oo00oO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 Oooo0O0oo00oO ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( iiIi1IIi1I ) + "[/COLOR]" , 'url' , 999 , iiiii , oOooOOOoOo , '' )
 Oooo0O0oo00oO ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( o0OoOO000ooO0 ) + "[/COLOR]" , 'url' , 999 , iiiii , oOooOOOoOo , '' )
 if 86 - 86: i1111 % OooOoO0Oo
 iiIIiiIi1Ii11 = Oo0 ( )
 if 70 - 70: oo0Ooo0
 if iiIIiiIi1Ii11 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif iiIIiiIi1Ii11 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 45 - 45: oooO0oo0oOOOO
def I1IiiiiI ( name , url ) :
 if 80 - 80: OooOoO0Oo . i11iIiiIii - oo0ooO0oOOOOo
 hash = [ ]
 ooOooo000oOO = url
 iII = o0 ( url )
 if 25 - 25: oo
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 62 - 62: oOo0 + oooO0oo0oOOOO
  if '<search>' in Oo0OoO00oOO0o :
   if 98 - 98: oo0ooO0oOOOOo
   IIII = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
   if len ( IIII ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = name + "!" + url + "!" + iiIiI
    name = '[COLOR white]' + name + '[/COLOR]'
    II11i1I11Ii1i ( name , url , 20 , iiIiI , iiIiI )
    if 51 - 51: I11i1i11i1I - OooooO0oOO + i1111 * i1IIiiiii . oo0Ooo0 + OooooO0oOO
   elif len ( IIII ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = ooOooo000oOO + "!" + name + "!" + iiIiI
    name = '[COLOR white]' + name + '[/COLOR]'
    II11i1I11Ii1i ( name , url , 22 , iiIiI , iiIiI )
    if 78 - 78: i11iIiiIii / i1iIIIiI1I - i1IIiiiii / oOo0 + OooooO0oOO
  elif '<arenavision>display</arenavision>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   if os . path . exists ( oO00oOo ) : II11i1I11Ii1i ( name , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : Oooo0O0oo00oO ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 82 - 82: i1IIiiiii
  elif '<regex>' in Oo0OoO00oOO0o :
   ii = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Oo0OoO00oOO0o )
   ii = '' . join ( ii )
   I1Ii1iI1 = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( ii )
   ii = urllib . quote_plus ( ii )
   if 87 - 87: I11i1i11i1I . OoO000
   O0OO0O = hashlib . md5 ( )
   for OO in ii : O0OO0O . update ( str ( OO ) )
   O0OO0O = str ( O0OO0O . hexdigest ( ) )
   if 83 - 83: oooO0oo0oOOOO / i1IIi11111i - oo - oOo0
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Oo0OoO00oOO0o = re . sub ( '<regex>.+?</regex>' , '' , Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = re . sub ( '<link></link>' , '' , Oo0OoO00oOO0o )
   if 36 - 36: OoO000
   name = re . sub ( '<meta>.+?</meta>' , '' , Oo0OoO00oOO0o )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 36 - 36: iiIIiIiIi / oooO0oo0oOOOO * I11i1i11i1I - oOo0 % ooO0oo0oO0 * OooooO0oOO
   try : o0iI11I1II = re . findall ( '<date>(.+?)</date>' , Oo0OoO00oOO0o ) [ 0 ]
   except : o0iI11I1II = ''
   if re . search ( r'\d+' , o0iI11I1II ) : name += ' [COLOR red] Updated %s[/COLOR]' % o0iI11I1II
   if 40 - 40: ooO0oo0oO0 / OOO0O % i11iiII + i1111
   try : ii1Ii1I1Ii11i = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Oo0OoO00oOO0o ) [ 0 ]
   except : ii1Ii1I1Ii11i = iiiii
   if 35 - 35: oo0ooO0oOOOOo
   try : O0O0Oooo0o = re . findall ( '<fanart>(.+?)</fanart>' , Oo0OoO00oOO0o ) [ 0 ]
   except : O0O0Oooo0o = O0O0OO0O0O0
   if 56 - 56: i11iiII % oooO0oo0oOOOO - i1IIi11111i
   try : O00o0OO0 = re . findall ( '<meta>(.+?)</meta>' , Oo0OoO00oOO0o ) [ 0 ]
   except : O00o0OO0 = '0'
   if 35 - 35: OooooO0oOO % iiIIiIiIi / OooOoO0Oo + ooO0oo0oO0 . i111I . i1IIi11111i
   try : url = re . findall ( '<link>(.+?)</link>' , Oo0OoO00oOO0o ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % O00o0OO0 )
   url = '<preset>search</preset>%s' % O00o0OO0 if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % O00o0OO0 )
   url = '<preset>searchsd</preset>%s' % O00o0OO0 if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 71 - 71: OoO000 * i1111 * OooooO0oOO
   if not ii == '' :
    hash . append ( { 'regex' : O0OO0O , 'response' : ii } )
    url += '|regex=%s' % ii
    if 56 - 56: i1IIi11111i
   Oooo0O0oo00oO ( name , url , 30 , ii1Ii1I1Ii11i , O0O0Oooo0o )
   if 54 - 54: OooOoO0Oo / oOo0 . OooooO0oOO % i1iIIIiI1I
  elif '<sportsdevil>' in Oo0OoO00oOO0o :
   IIII = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o )
   if len ( IIII ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     o0O0OOO0Ooo = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : o0O0OOO0Ooo = "None"
    iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    iiIiII1 = o0O0OOO0Ooo
    OOO00O0O = "/"
    if not iiIiII1 . endswith ( OOO00O0O ) :
     iii = iiIiII1 + "/"
    else :
     iii = iiIiII1
    iII = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = iII + '%26referer=' + iii
    Oooo0O0oo00oO ( name , url , 2 , iiIiI , oOooOOOoOo )
    if 57 - 57: i11iIiiIii . i11iiII - i1IIiiiii - OooooO0oOO + OOO0O
   elif len ( IIII ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    Oooo0O0oo00oO ( name , ooOooo000oOO + 'NOTPLAY' , 8 , iiIiI , oOooOOOoOo )
    if 63 - 63: OOO0O * i1iIIIiI1I
  elif '<plexus>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : Oooo0O0oo00oO ( name , ooOooo000oOO + 'NOTPLAY' , 7 , iiIiI , oOooOOOoOo )
   else : Oooo0O0oo00oO ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 69 - 69: oooO0oo0oOOOO . oo
  elif '<rutubeplaylist>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   II11i1I11Ii1i ( name , ooOooo000oOO , 90 , iiIiI , oOooOOOoOo )
   if 49 - 49: i1IIi11111i - oo0Ooo0
  elif '<folder>' in Oo0OoO00oOO0o :
   oO00OOoO00 = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , iiIiI , oOooOOOoOo in oO00OOoO00 :
    II11i1I11Ii1i ( name , url , 1 , iiIiI , oOooOOOoOo )
    if 74 - 74: ooO0oo0oO0 * i11iiII + OOO0O / II1Ii1iI1i / i1111 . I11i1i11i1I
  elif '<m3u>' in Oo0OoO00oOO0o :
   oO00OOoO00 = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , iiIiI , oOooOOOoOo in oO00OOoO00 :
    II11i1I11Ii1i ( name , url , 10 , iiIiI , oOooOOOoOo )
    if 62 - 62: i111I * i1IIi11111i
  elif '<rutube>' in Oo0OoO00oOO0o :
   oO00OOoO00 = re . compile ( '<title>(.+?)</title>.+?rutube>(.+?)</rutube>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , iiIiI , oOooOOOoOo in oO00OOoO00 :
    ooOooo000oOO = 'https://rutube.ru/play/embed/' + url + '?wmode=opaque&fakeFullscreen=1'
    II11i1I11Ii1i ( name , ooOooo000oOO , 2 , iiIiI , oOooOOOoOo )
  else :
   IIII = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o )
   if len ( IIII ) == 1 :
    oO00OOoO00 = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
    IiI111111IIII = len ( Oo0oOOo )
    for name , url , iiIiI , oOooOOOoOo in oO00OOoO00 :
     Oooo0O0oo00oO ( name , url , 2 , iiIiI , oOooOOOoOo )
   elif len ( IIII ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    Oooo0O0oo00oO ( name , ooOooo000oOO , 3 , iiIiI , oOooOOOoOo )
    if 58 - 58: OOO0O % oo0ooO0oOOOOo
 iiIIiiIi1Ii11 = Oo0 ( )
 if 50 - 50: OooOoO0Oo . oo0ooO0oOOOOo
 if iiIIiiIi1Ii11 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif iiIIiiIi1Ii11 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 97 - 97: oooO0oo0oOOOO + OOO0O
def OO0O000 ( name , url , iconimage ) :
 iiIiI1i1 = [ ]
 oO0O00oOOoooO = [ ]
 IiIi11iI = [ ]
 iII = o0 ( url )
 Oo0O00O000 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0O00O000 ) [ 0 ]
 IIII = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0O00O000 )
 OO = 1
 for i11I1IiII1i1i in IIII :
  ooI1111i = i11I1IiII1i1i
  if '(' in i11I1IiII1i1i :
   i11I1IiII1i1i = i11I1IiII1i1i . split ( '(' ) [ 0 ]
   iIIii = str ( ooI1111i . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   iiIiI1i1 . append ( i11I1IiII1i1i )
   oO0O00oOOoooO . append ( iIIii )
  else :
   iiIiI1i1 . append ( i11I1IiII1i1i )
   oO0O00oOOoooO . append ( 'Link ' + str ( OO ) )
  OO = OO + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 o00O0O = O00ooooo00 . select ( name , oO0O00oOOoooO )
 if o00O0O < 0 :
  quit ( )
 else :
  url = iiIiI1i1 [ o00O0O ]
  print url
  if 20 - 20: II1Ii1iI1i - iiIIiIiIi
 url = iiIiI1i1 [ o00O0O ]
 name = oO0O00oOOoooO [ o00O0O ]
 i1iI ( name , url , iiiii )
 if 94 - 94: ooO0oo0oO0 / I11i1i11i1I % i1iIIIiI1I * i1iIIIiI1I * i1111
def IIiIiI ( name , url , iconimage ) :
 if 94 - 94: OooooO0oOO . II1Ii1iI1i - oo0ooO0oOOOOo % oooO0oo0oOOOO - oo
 iiIiI1i1 = [ ]
 oO0O00oOOoooO = [ ]
 IiIi11iI = [ ]
 ooO0O00Oo0o = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 iII = o0 ( url )
 Oo0O00O000 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 IIII = re . compile ( '<plexus>(.+?)</plexus>' ) . findall ( Oo0O00O000 )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0O00O000 ) [ 0 ]
 if 65 - 65: i11iiII . oo0Ooo0 - OooOoO0Oo * OoO000 / OooOoO0Oo / iiIIiIiIi
 i111iIi1i1II1 = "plugin://program.plexus/?url="
 oooO = "&mode=1&name=acestream+"
 OO = 0
 if 26 - 26: i1IIiiiii % i11iiII
 for i11I1IiII1i1i in IIII :
  OO = OO + 1
  if 76 - 76: OoO000 * i1iIIIiI1I
  ooI1111i = i11I1IiII1i1i
  if '(' in i11I1IiII1i1i :
   i11I1IiII1i1i = i11I1IiII1i1i . split ( '(' ) [ 0 ]
   iIIii = str ( ooI1111i . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   iiIiI1i1 . append ( i11I1IiII1i1i )
   oO0O00oOOoooO . append ( iIIii )
   ooO0O00Oo0o . append ( 'Stream ' + str ( OO ) )
  else :
   iiIiI1i1 . append ( i11I1IiII1i1i )
   oO0O00oOOoooO . append ( 'Link ' + str ( OO ) )
   iIIii = name
   if 52 - 52: oOo0
   if 19 - 19: i1IIi11111i
 if OO > 1 :
  O00ooooo00 = xbmcgui . Dialog ( )
  o00O0O = O00ooooo00 . select ( name , oO0O00oOOoooO )
  if o00O0O < 0 :
   quit ( )
  else :
   i11i = iiIiI1i1 [ o00O0O ]
   if not 'acestream://' in i11i :
    i11i = 'acestream://' + i11i
   url = i111iIi1i1II1 + i11i + oooO + oO0O00oOOoooO [ o00O0O ]
   name = oO0O00oOOoooO [ o00O0O ]
 else :
  i11i = i11I1IiII1i1i
  if not 'acestream://' in i11i :
   i11i = 'acestream://' + i11i
  url = i111iIi1i1II1 + i11i + oooO + iIIii
  name = iIIii
  if 73 - 73: oOo0
 i1iI ( name , url , iiiii )
 if 70 - 70: ooO0oo0oO0
def i11ii1iI ( name , url , iconimage ) :
 if 22 - 22: i111I
 iiIiI1i1 = [ ]
 oO0O00oOOoooO = [ ]
 IiIi11iI = [ ]
 ooO0O00Oo0o = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 iII = o0 ( url )
 Oo0O00O000 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 IIII = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0O00O000 )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0O00O000 ) [ 0 ]
 if 75 - 75: oo0ooO0oOOOOo + oo0ooO0oOOOOo + II1Ii1iI1i - II1Ii1iI1i
 OOooOOOooO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 12 - 12: oooO0oo0oOOOO - oo0ooO0oOOOOo
 OO = 1
 if 81 - 81: OOO0O - OOO0O . i1iIIIiI1I
 for i11I1IiII1i1i in IIII :
  ooI1111i = i11I1IiII1i1i
  if '(' in i11I1IiII1i1i :
   i11I1IiII1i1i = i11I1IiII1i1i . split ( '(' ) [ 0 ]
   iIIii = str ( ooI1111i . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   iiIiI1i1 . append ( i11I1IiII1i1i )
   oO0O00oOOoooO . append ( iIIii )
   ooO0O00Oo0o . append ( 'Stream ' + str ( OO ) )
  else :
   iiIiI1i1 . append ( i11I1IiII1i1i )
   oO0O00oOOoooO . append ( 'Link ' + str ( OO ) )
   if 73 - 73: oo0Ooo0 % i11iIiiIii - i1IIi11111i
  OO = OO + 1
  if 7 - 7: oooO0oo0oOOOO * i11iIiiIii * i1IIiiiii + iiIIiIiIi % oo - iiIIiIiIi
 name = '[COLOR red]' + name + '[/COLOR]'
 if 39 - 39: I11i1i11i1I * oOo0 % oOo0 - i111I + oo0ooO0oOOOOo - oo0Ooo0
 O00ooooo00 = xbmcgui . Dialog ( )
 o00O0O = O00ooooo00 . select ( name , oO0O00oOOoooO )
 if o00O0O < 0 :
  quit ( )
 else :
  iiIiII1 = oO0O00oOOoooO [ o00O0O ]
  OOO00O0O = "/"
  if not iiIiII1 . endswith ( OOO00O0O ) :
   iii = iiIiII1 + "/"
  else :
   iii = iiIiII1
  url = OOooOOOooO + iiIiI1i1 [ o00O0O ] + "%26referer=" + iii
  if 23 - 23: i11iIiiIii
 name = oO0O00oOOoooO [ o00O0O ]
 i1iI ( name , url , iiiii )
 if 30 - 30: oo0ooO0oOOOOo - II1Ii1iI1i % i1111 + oo0Ooo0 * ooO0oo0oO0
def o0ooooO0o0O ( name , url , iconimage ) :
 if 24 - 24: oooO0oo0oOOOO * oo0ooO0oOOOOo
 IiI1iiiIii = [ ]
 I1III1111iIi = [ ]
 if 38 - 38: i1iIIIiI1I + oo0Ooo0 / OooOoO0Oo % iiIIiIiIi - i11iiII
 iII = o0 ( url )
 Oo0O00O000 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 IIII = re . compile ( '<rutubeplaylist>(.+?)</rutubeplaylist>' ) . findall ( Oo0O00O000 )
 if 14 - 14: OooooO0oOO / OooOoO0Oo
 for i11I1IiII1i1i in IIII :
  ooI1111i = i11I1IiII1i1i
  if '(' in i11I1IiII1i1i :
   i11I1IiII1i1i = i11I1IiII1i1i . split ( '(' ) [ 0 ]
   iIIii = str ( ooI1111i . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   IiI1iiiIii . append ( iIIii )
   I1III1111iIi . append ( i11I1IiII1i1i )
   ooo0O0o00O = list ( zip ( IiI1iiiIii , I1III1111iIi ) )
   if 48 - 48: iiIIiIiIi / OooOoO0Oo . ooO0oo0oO0 * OOO0O * OooooO0oOO / II1Ii1iI1i
 OOOOoOOo0O0 = sorted ( ooo0O0o00O )
 if 92 - 92: i11iiII + ooO0oo0oO0 / i1111
 for OooO0OO , url in OOOOoOOo0O0 :
  o0OOo0o0O0O = o0 ( url )
  Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   o0OO0o0oOOO0O = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
   if OooO0OO . lower ( ) == "all" :
    o0OO0o0oOOO0O = o0OO0o0oOOO0O . replace ( '.' , ' ' )
    Oooo0O0oo00oO ( o0OO0o0oOOO0O , url , 2 , iconimage , iconimage , '' )
   elif OooO0OO . lower ( ) in o0OO0o0oOOO0O . lower ( ) :
    o0OO0o0oOOO0O = o0OO0o0oOOO0O . replace ( '.' , ' ' )
    Oooo0O0oo00oO ( o0OO0o0oOOO0O , url , 2 , iconimage , iconimage , '' )
    if 49 - 49: i11iiII . oo0ooO0oOOOOo . i1111
 try :
  Oo0oOOo = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( o0OOo0o0O0O )
  o000ooooO0o = str ( Oo0oOOo )
  iI1i11 = re . compile ( 'href="(.+?)"' ) . findall ( o000ooooO0o ) [ 1 ]
  url = iI1i11 + "|SPLIT|" + OooO0OO
  II11i1I11Ii1i ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 66 - 66: oooO0oo0oOOOO % i11iiII + i11iIiiIii . OOO0O / i1IIiiiii + i11iiII
def ooo00Ooo ( name , url , iconimage ) :
 if 93 - 93: i11iIiiIii - i1IIi11111i * i11iiII * oo0Ooo0 % oooO0oo0oOOOO + i111I
 url , OooO0OO = url . split ( "|SPLIT|" )
 if 25 - 25: OoO000 + i1IIiiiii / iiIIiIiIi . oo0ooO0oOOOOo % oooO0oo0oOOOO * oo
 o0OOo0o0O0O = o0 ( url )
 Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Oo0OoO00oOO0o in Oo0oOOo :
  o0OO0o0oOOO0O = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
  if OooO0OO . lower ( ) == "all" :
   o0OO0o0oOOO0O = o0OO0o0oOOO0O . replace ( '.' , ' ' )
   Oooo0O0oo00oO ( o0OO0o0oOOO0O , url , 2 , iconimage , iconimage , '' )
  elif OooO0OO . lower ( ) in o0OO0o0oOOO0O . lower ( ) :
   o0OO0o0oOOO0O = o0OO0o0oOOO0O . replace ( '.' , ' ' )
   Oooo0O0oo00oO ( o0OO0o0oOOO0O , url , 2 , iconimage , iconimage , '' )
   if 84 - 84: iiIIiIiIi % i1IIiiiii + i11iIiiIii
 try :
  Oo0oOOo = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( o0OOo0o0O0O )
  o000ooooO0o = str ( Oo0oOOo )
  iI1i11 = re . compile ( 'href="(.+?)"' ) . findall ( o000ooooO0o ) [ 1 ]
  url = iI1i11 + "|SPLIT|" + OooO0OO
  II11i1I11Ii1i ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 28 - 28: I11i1i11i1I + oo * oOo0 % OooooO0oOO . oo0Ooo0 % oooO0oo0oOOOO
def I1iiiiIii ( name , url , iconimage ) :
 if 19 - 19: oo - I11i1i11i1I . oooO0oo0oOOOO
 O0o0 , ii11i1 = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 O0o0 += urllib . unquote_plus ( ii11i1 )
 url = regex . resolve ( O0o0 )
 if 60 - 60: i1111 + I11i1i11i1I
 i1iI ( name , url , iconimage )
 if 9 - 9: iiIIiIiIi * i111I - ooO0oo0oO0 + OOO0O / oo . oo
def iiIIi ( ) :
 if 11 - 11: i1IIi11111i * OooooO0oOO
 Oooo0O0oo00oO ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 Oooo0O0oo00oO ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 Oooo0O0oo00oO ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 II11i1I11Ii1i ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 II11i1I11Ii1i ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 81 - 81: i1iIIIiI1I + OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 98 - 98: i1IIi11111i
def o00o0 ( ) :
 if 50 - 50: I11i1i11i1I / I11i1i11i1I % i11iiII . i11iiII
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 55 - 55: iiIIiIiIi - oo0Ooo0 + i1111 + i1iIIIiI1I % i1IIiiiii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 41 - 41: II1Ii1iI1i - oo0Ooo0 - i1IIiiiii
def III11I1 ( ) :
 if 36 - 36: OooooO0oOO - i1IIiiiii . I11i1i11i1I - i11iIiiIii - oOo0 * I11i1i11i1I
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 76 - 76: i11iIiiIii + oo0ooO0oOOOOo / i11iiII - oo - i1IIiiiii + i11iiII
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 51 - 51: ooO0oo0oO0 . iiIIiIiIi + ooO0oo0oO0
def oOoOO ( ) :
 if 44 - 44: i1IIi11111i / ooO0oo0oO0 % OooooO0oOO * i111I % iiIIiIiIi
 OO = 0
 o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Oo0OoO00oOO0o in Oo0oOOo :
  OO = OO + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  o00oooO0Oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( OO ) + '[/COLOR]' , o00oooO0Oo , 12 , iiiii , O0O0OO0O0O0 )
  if 25 - 25: i11iiII . iiIIiIiIi
 o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Oo0OoO00oOO0o in Oo0oOOo :
  OO = OO + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  o00oooO0Oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( OO ) + '[/COLOR]' , o00oooO0Oo , 12 , iiiii , O0O0OO0O0O0 )
  if 24 - 24: OooooO0oOO / i11iIiiIii + OooooO0oOO
 o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Oo0OoO00oOO0o in Oo0oOOo :
  OO = OO + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  o00oooO0Oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( OO ) + '[/COLOR]' , o00oooO0Oo , 12 , iiiii , O0O0OO0O0O0 )
  if 20 - 20: oo0Ooo0 + i1IIiiiii / oooO0oo0oOOOO % ooO0oo0oO0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 88 - 88: OOO0O / i1111
def OOOOO0O00 ( url ) :
 if 30 - 30: ooO0oo0oO0 . i1IIi11111i . oOo0 / oo0ooO0oOOOOo
 o0OOo0o0O0O = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 if 42 - 42: I11i1i11i1I
 for Oo0OoO00oOO0o in Oo0oOOo :
  OoOO0oo0o = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iiIiI = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 12 , iiIiI , O0O0OO0O0O0 )
  if 19 - 19: OooooO0oOO % i11iiII * ooO0oo0oO0 + i1IIi11111i
 try :
  iii11I = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( o0OOo0o0O0O ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR yellow]Next Page -->[/COLOR]' , iii11I , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 50 - 50: i1iIIIiI1I + oooO0oo0oOOOO + i1IIiiiii . i1111 / oo0ooO0oOOOOo
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 17 - 17: i1IIiiiii % ooO0oo0oO0 - ooO0oo0oO0
def O0o0O0 ( ) :
 if 11 - 11: i1111 % oo * i1iIIIiI1I + iiIIiIiIi + i1IIiiiii
 o0OOo0o0O0O = o0 ( 'http://arenavision.in/schedule' )
 Oo0oOOo = re . compile ( '<tr><td class="auto-style3"(.+?)</tr>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 if 24 - 24: I11i1i11i1I - OooooO0oOO % ooO0oo0oO0 . II1Ii1iI1i / oooO0oo0oOOOO
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   o0iI11I1II = re . compile ( '190px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   time = re . compile ( '182px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   ii1ii111 = re . compile ( '188px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I111i1i1111 = re . compile ( '685px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   IIII1 = re . compile ( '317px">(.+?) ' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   o00oooO0Oo = I111i1i1111 + '|SPLIT|' + IIII1
   Oooo0O0oo00oO ( '[COLOR blue][B]' + I111i1i1111 + '[/B][/COLOR] - [COLOR white]' + o0iI11I1II + ' | [COLOR orangered][B]' + time + '[/B][/COLOR] | ' + ii1ii111 + '[/COLOR]' , o00oooO0Oo , 97 , iiiii , O0O0OO0O0O0 )
  except : pass
 iiIIiiIi1Ii11 = Oo0 ( )
 if 10 - 10: OooOoO0Oo / iiIIiIiIi + i11iIiiIii / i1IIiiiii
 if iiIIiiIi1Ii11 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif iiIIiiIi1Ii11 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 74 - 74: oOo0 + oooO0oo0oOOOO + II1Ii1iI1i - II1Ii1iI1i + i1111
def oOOO0oo0 ( name , url , iconimage ) :
 if 46 - 46: OoO000
 name , url = url . split ( '|SPLIT|' )
 if 45 - 45: iiIIiIiIi
 IIi = "null"
 ooO0oOo0o = "null"
 if 66 - 66: OOO0O . II1Ii1iI1i . i11iIiiIii % i1iIIIiI1I % iiIIiIiIi
 if "-" in url :
  IIi , ooO0oOo0o = url . split ( '-' )
  if 43 - 43: oooO0oo0oOOOO
  Ii1 = O00ooooo00 . select ( "[COLOR red]Please select an stream[/COLOR]" , [ '[COLOR white]Link 1[/COLOR]' , '[COLOR white]Link 2[/COLOR]' ] )
  if 14 - 14: ooO0oo0oO0 % ooO0oo0oO0 * i11iIiiIii - oo - oo0Ooo0
  if Ii1 == 0 : url = 'http://arenavision.in/av' + IIi
  elif Ii1 == 1 : url = 'http://arenavision.in/av' + ooO0oOo0o
  else : quit ( )
  if 63 - 63: oo
 else : url = 'http://arenavision.in/av' + url
 if 69 - 69: ooO0oo0oO0 . i11iiII % iiIIiIiIi + ooO0oo0oO0 / oooO0oo0oOOOO / i11iiII
 O00OoOO0oo0 ( name , url , iconimage )
 if 96 - 96: OOO0O . oo0ooO0oOOOOo - iiIIiIiIi
 if 99 - 99: OoO000 . I11i1i11i1I - i1IIiiiii % i1IIiiiii * oooO0oo0oOOOO . i1111
def O00OoOO0oo0 ( name , url , iconimage ) :
 if 4 - 4: i1IIiiiii
 try :
  o0OOo0o0O0O = o0 ( url )
  Oo0oOOo = re . compile ( 'this.loadPlayer(.+?),' , re . DOTALL ) . findall ( o0OOo0o0O0O ) [ 0 ]
  url = Oo0oOOo . replace ( '(' , '' ) . replace ( ')' , '' ) . replace ( '"' , '' ) . replace ( ' ' , '' )
  if 51 - 51: oo - oooO0oo0oOOOO % OooooO0oOO - i1111
  ooOooo000oOO = 'plugin://program.plexus/?url=acestream://' + str ( url ) + '&mode=1&name=acestream+' + str ( name )
  if 31 - 31: i1iIIIiI1I / I11i1i11i1I - i1iIIIiI1I - oOo0
  i1iI ( name , ooOooo000oOO , iconimage )
 except : quit ( )
 if 7 - 7: i1iIIIiI1I % oooO0oo0oOOOO . OOO0O + i1IIi11111i - oo0Ooo0
def o0o0O00oo0 ( url ) :
 if 27 - 27: i11iIiiIii % i1111 % oo0Ooo0 . oooO0oo0oOOOO - I11i1i11i1I + OOO0O
 o0OOo0o0O0O = o0 ( url )
 Oo0oOOo = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except :
   OoOO0oo0o = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 57 - 57: ooO0oo0oO0 / oo0Ooo0 - II1Ii1iI1i
def ooOOo00O00Oo ( url ) :
 if 42 - 42: oooO0oo0oOOOO / oo0ooO0oOOOOo + i111I * iiIIiIiIi % iiIIiIiIi
 o0OOo0o0O0O = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 i1iIi = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : i1iIi = 1
  if 21 - 21: OooooO0oOO / i11iiII + i1IIiiiii + i111I
  if i1iIi == 0 :
   II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 12 , iiIiI , O0O0OO0O0O0 )
  i1iIi = 0
  if 91 - 91: i11iIiiIii / II1Ii1iI1i + i1iIIIiI1I + iiIIiIiIi * i11iIiiIii
 try :
  iii11I = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( o0OOo0o0O0O ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR yellow]Next Page -->[/COLOR]' , iii11I , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 66 - 66: ooO0oo0oO0 % II1Ii1iI1i - oooO0oo0oOOOO + oo0Ooo0 * OooOoO0Oo . OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 52 - 52: iiIIiIiIi + oooO0oo0oOOOO . i1iIIIiI1I . i11iiII . oo
def oo000 ( url ) :
 if 32 - 32: II1Ii1iI1i . i1IIiiiii
 oOO = datetime . date . today ( )
 OoooI1i1iiiII1i = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 100 - 100: oo
 Oooo0O0oo00oO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( OoooI1i1iiiII1i ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 Oooo0O0oo00oO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 46 - 46: OOO0O / ooO0oo0oO0 % i1iIIIiI1I . ooO0oo0oO0 * i1iIIIiI1I
 o0OOo0o0O0O = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 i1iIi = 0
 OO = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   o0OO0o0oOOO0O = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    IIi1ii1Ii = re . compile ( '<p>(.+?)</p>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : IIi1ii1Ii = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<img src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : i1iIi = 1
  if 91 - 91: i11iIiiIii / i111I + i1iIIIiI1I - i11iIiiIii + oOo0
  if i1iIi == 0 :
   if 'vs' in o0OO0o0oOOO0O :
    OoOO0oo0o = '[COLOR dodgerblue]' + o0OO0o0oOOO0O + ' - ' + '[/COLOR][COLOR blue]' + IIi1ii1Ii + '[/COLOR]'
    OO = OO + 1
    Oooo0O0oo00oO ( OoOO0oo0o , url , 206 , iiIiI , O0O0OO0O0O0 , '' )
  i1iIi = 0
  if 18 - 18: i1111 / OoO000
 if OO == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 4 - 4: i1111 / i11iiII + i1111 . ooO0oo0oO0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 20 - 20: OooooO0oOO - i1IIiiiii % i1IIiiiii * oo0ooO0oOOOOo + OooOoO0Oo + oo0ooO0oOOOOo
def ii11i ( name , url , iconimage ) :
 if 100 - 100: iiIIiIiIi % ooO0oo0oO0 * i1111 - i1iIIIiI1I
 o0OOo0o0O0O = o0 ( url )
 oo00O00oO000o = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( o0OOo0o0O0O ) [ 0 ]
 if 71 - 71: i11iiII - iiIIiIiIi / OOO0O * OOO0O / II1Ii1iI1i . II1Ii1iI1i
 if not "http" in oo00O00oO000o :
  oo00O00oO000o = oo00O00oO000o . replace ( "//" , "" )
  url = "http://" + oo00O00oO000o
 else :
  url = oo00O00oO000o
  if 53 - 53: OooOoO0Oo
 i11iiI1111 = url
 if 97 - 97: I11i1i11i1I * i1IIi11111i . ooO0oo0oO0
 I1Ii1111iIi = o0 ( url )
 oo00O00oO000o = re . compile ( "atob(.+?)," ) . findall ( I1Ii1111iIi ) [ 0 ]
 oo00O00oO000o = oo00O00oO000o . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( oo00O00oO000o )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + i11iiI1111 + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 i1iI ( name , url , iconimage )
 if 31 - 31: oo0Ooo0 . OooOoO0Oo * iiIIiIiIi + i11iIiiIii * OooooO0oOO
def OO0ooo0o0O0Oooooo ( url ) :
 if 1 - 1: iiIIiIiIi % OOO0O * I11i1i11i1I
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 55 - 55: OOO0O
  if '<display>eWVz</display>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OoOO0oo0o = base64 . b64decode ( OoOO0oo0o )
   url = base64 . b64decode ( url )
   iiIiI = base64 . b64decode ( iiIiI )
   oOooOOOoOo = base64 . b64decode ( oOooOOOoOo )
   II11i1I11Ii1i ( OoOO0oo0o , url , 220 , iiIiI , oOooOOOoOo , '' )
   if 87 - 87: i111I % i1iIIIiI1I . i1IIi11111i / iiIIiIiIi
def i1I1iI ( url ) :
 if 62 - 62: OooOoO0Oo . OoO000 . i111I
 o0OOo0o0O0O = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 if 11 - 11: oOo0 / oo0Ooo0
 for Oo0OoO00oOO0o in Oo0oOOo :
  OoOO0oo0o = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   oooO0 = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : oooO0 = "SD"
  oooO0 = '[COLOR yellow]' + oooO0 + '[/COLOR]'
  iiIiI = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  OoOO0oo0o = OoOO0oo0o . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 16 - 16: i1111 + OooooO0oOO - i111I
  Oooo0O0oo00oO ( '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR] - ' + oooO0 , url , 212 , iiIiI , O0O0OO0O0O0 , '' )
  if 3 - 3: oooO0oo0oOOOO / i1iIIIiI1I
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( o0OOo0o0O0O ) [ 0 ]
  iI1i11 = 'http://www.fmovies.se/' + url
  II11i1I11Ii1i ( "Next Page -->" , iI1i11 , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 31 - 31: oOo0 + oo0ooO0oOOOOo . i111I
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 89 - 89: i1111 + II1Ii1iI1i + i1111
def IiII1II11I ( url ) :
 if 54 - 54: OoO000 + oooO0oo0oOOOO + oo0Ooo0 * OooOoO0Oo - oOo0 % OooooO0oOO
 o0OOo0o0O0O = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 if 13 - 13: iiIIiIiIi / i1iIIIiI1I * oo . oo * iiIIiIiIi
 if 63 - 63: OooOoO0Oo / oooO0oo0oOOOO * I11i1i11i1I + i1111 / OoO000 + i1IIiiiii
def OOoO000 ( url ) :
 if 57 - 57: i1111
 if "iptvembed" in url :
  o0OOo0o0O0O = o0 ( url )
  Oo0oOOo = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '</pre>' , '' )
   url = Oo0OoO00oOO0o
   if 54 - 54: I11i1i11i1I + OooooO0oOO + i11iIiiIii
 if "sourcetv" in url :
  o0OOo0o0O0O = o0 ( url )
  Oo0oOOo = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '</pre>' , '' )
   url = Oo0OoO00oOO0o
   if 28 - 28: OooooO0oOO
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 I1I = [ ]
 for oOoo000 , OooOo00o , url in ooo000o0ooO0 :
  IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : url }
  I1I . append ( IiI11i1IIiiI )
 list = [ ]
 for IIII1 in I1I :
  IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
  ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
  for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
   IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
  list . append ( IiI11i1IIiiI )
  if 1 - 1: i1IIi11111i % iiIIiIiIi
 oOoO00 = 0
 for IIII1 in list :
  oOoO00 = 1
  OoOO0oo0o = iI1IIIii ( IIII1 [ "display_name" ] )
  url = iI1IIIii ( IIII1 [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   Oooo0O0oo00oO ( '[COLOR white]' + OoOO0oo0o + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   II11i1I11Ii1i ( '[COLOR white]' + OoOO0oo0o + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 7 - 7: OoO000 - oo0Ooo0 / i1111 * i1IIiiiii . i1iIIIiI1I * i1iIIIiI1I
 if oOoO00 == 0 :
  Oooo0O0oo00oO ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 61 - 61: oo0Ooo0 % iiIIiIiIi - oo / I11i1i11i1I
def Ii1iI111 ( url ) :
 if 51 - 51: OoO000 * oooO0oo0oOOOO / i1111 . i1IIiiiii % oOo0 / i1IIi11111i
 iII = o0 ( url )
 ooOooo000oOO = url
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 9 - 9: i1IIi11111i % i1IIi11111i % i1111
  IIII = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
  if len ( IIII ) == 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = OoOO0oo0o + "!" + url + "!" + iiIiI
   OoOO0oo0o = '[COLOR white]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 20 , iiIiI , iiIiI )
   if 30 - 30: OoO000 + OooOoO0Oo - OoO000 . OoO000 - i1111 + oooO0oo0oOOOO
  elif len ( IIII ) > 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = ooOooo000oOO + "!" + OoOO0oo0o + "!" + iiIiI
   OoOO0oo0o = '[COLOR white]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 22 , iiIiI , iiIiI )
   if 86 - 86: II1Ii1iI1i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 41 - 41: OOO0O * oo0Ooo0 / OOO0O % OooooO0oOO
def Ii ( url ) :
 if 77 - 77: OOO0O % i1IIiiiii
 oOO = datetime . date . today ( )
 OoooI1i1iiiII1i = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 9 - 9: oo - I11i1i11i1I * i111I . I11i1i11i1I
 Oooo0O0oo00oO ( '[COLOR dodgerblue]EVENTS FOR ' + str ( OoooI1i1iiiII1i ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 Oooo0O0oo00oO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 2 - 2: i111I % oOo0
 iII = o0 ( url )
 ooOooo000oOO = url
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 63 - 63: i1IIi11111i % ooO0oo0oO0
  IIII = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
  if len ( IIII ) == 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = OoOO0oo0o + "!" + url + "!" + iiIiI
   OoOO0oo0o = '[COLOR white]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 20 , iiIiI , iiIiI )
   if 39 - 39: i1iIIIiI1I / i1111 / i11iiII % i1IIi11111i
  elif len ( IIII ) > 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iiIiI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = ooOooo000oOO + "!" + OoOO0oo0o + "!" + iiIiI
   OoOO0oo0o = '[COLOR white]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 22 , iiIiI , iiIiI )
   if 89 - 89: OooOoO0Oo + i111I + OooOoO0Oo * II1Ii1iI1i + ooO0oo0oO0 % oo0Ooo0
def oOo0oO ( ) :
 if 5 - 5: oOo0 - oOo0 . I11i1i11i1I + OOO0O - oOo0 . OooooO0oOO
 oOO = datetime . date . today ( )
 OoooI1i1iiiII1i = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 31 - 31: i1111 - ooO0oo0oO0 - ooO0oo0oO0 % oo0Ooo0
 Oooo0O0oo00oO ( '[COLOR dodgerblue]EVENTS FOR ' + str ( OoooI1i1iiiII1i ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 Oooo0O0oo00oO ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 12 - 12: ooO0oo0oO0
 iII = o0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 Oo0oOOo = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( iII )
 o000ooooO0o = str ( Oo0oOOo )
 iIi1i = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( o000ooooO0o )
 for Oo0OoO00oOO0o in iIi1i :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in Oo0OoO00oOO0o :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    o0OO0o0oOOO0O = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iiIiI = re . compile ( 'src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     i1ii = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
     i1ii = O0ooO0ooo0oO ( i1ii )
    except : i1ii = "null"
    OoOO0oo0o = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + o0OO0o0oOOO0O + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    OoOO0oo0o = iioo0o0OoOOO ( OoOO0oo0o )
    o00oooO0Oo = o0OO0o0oOOO0O + "!" + i1ii . lower ( ) + "!" + iiIiI
    II11i1I11Ii1i ( OoOO0oo0o , o00oooO0Oo , 20 , iiIiI , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    o0OO0o0oOOO0O = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     i1ii = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : i1ii = "null"
    iiIiI = re . compile ( 'src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    OoOO0oo0o = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + o0OO0o0oOOO0O + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    OoOO0oo0o = iioo0o0OoOOO ( OoOO0oo0o )
    o00oooO0Oo = o0OO0o0oOOO0O + "!" + i1ii . lower ( ) + "!" + iiIiI
    II11i1I11Ii1i ( OoOO0oo0o , o00oooO0Oo , 20 , iiIiI , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 88 - 88: i1iIIIiI1I
def iiI11I1i1i1iI ( name , url , iconimage ) :
 if 60 - 60: i111I % I11i1i11i1I + oOo0 . iiIIiIiIi * ooO0oo0oO0
 try :
  url , oooo00 , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 77 - 77: iiIIiIiIi - i1IIi11111i % oo0Ooo0 - oooO0oo0oOOOO
 o0O0O0 = [ ]
 if 6 - 6: i1iIIIiI1I . OoO000 * OOO0O . II1Ii1iI1i
 iII = o0 ( url )
 Oo0O00O000 = re . compile ( '<title>' + re . escape ( oooo00 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0O00O000 ) [ 0 ]
 IIII = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0O00O000 )
 for i11I1IiII1i1i in IIII :
  o0O0O0 . append ( i11I1IiII1i1i )
  if 98 - 98: II1Ii1iI1i
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 65 - 65: OOO0O / oo % OoO000
 iIiIIii = 0
 if 61 - 61: oo0ooO0oOOOOo / oOo0 / I11i1i11i1I * oooO0oo0oOOOO
 iIII1i1i = [ ]
 IiI1iii11iIi1 = [ ]
 i1iI11I1II1 = [ ]
 I1IiiI . update ( 0 )
 ii11II1i = 0
 if 58 - 58: I11i1i11i1I . OoO000 - I11i1i11i1I - OooOoO0Oo * i1IIiiiii
 if oO000OoOoo00o == "true" :
  ii11II1i = 1
  o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if iIiIIii < 100 :
    I1IiiI . update ( iIiIIii )
    iIiIIii = iIiIIii + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1I = [ ]
   for oOoo000 , OooOo00o , url in ooo000o0ooO0 :
    IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : url }
    I1I . append ( IiI11i1IIiiI )
   IIiI11i1111Ii = [ ]
   for IIII1 in I1I :
    IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
     IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
    IIiI11i1111Ii . append ( IiI11i1IIiiI )
    if 63 - 63: oOo0 + iiIIiIiIi
   for IIII1 in IIiI11i1111Ii :
    name = iI1IIIii ( IIII1 [ "display_name" ] )
    url = iI1IIIii ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iIII1i1i . append ( name )
    IiI1iii11iIi1 . append ( url )
    if "hd" in name . lower ( ) :
     i1iI11I1II1 . append ( "1" )
    else :
     i1iI11I1II1 . append ( "0" )
    ooo0O0o00O = list ( zip ( i1iI11I1II1 , iIII1i1i , IiI1iii11iIi1 ) )
    if 66 - 66: oOo0 - ooO0oo0oO0 / OOO0O + oOo0 - oo0Ooo0 + i1iIIIiI1I
 if iiiI11 == "true" :
  ii11II1i = 1
  o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if iIiIIii < 100 :
    I1IiiI . update ( iIiIIii )
    iIiIIii = iIiIIii + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1I = [ ]
   for oOoo000 , OooOo00o , url in ooo000o0ooO0 :
    IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : url }
    I1I . append ( IiI11i1IIiiI )
   IIiI11i1111Ii = [ ]
   for IIII1 in I1I :
    IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
     IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
    IIiI11i1111Ii . append ( IiI11i1IIiiI )
    if 29 - 29: oo0ooO0oOOOOo % ooO0oo0oO0 . i111I % i111I % i1111 / i1iIIIiI1I
   for IIII1 in IIiI11i1111Ii :
    name = iI1IIIii ( IIII1 [ "display_name" ] )
    url = iI1IIIii ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iIII1i1i . append ( name )
    IiI1iii11iIi1 . append ( url )
    if "hd" in name . lower ( ) :
     i1iI11I1II1 . append ( "1" )
    else :
     i1iI11I1II1 . append ( "0" )
    ooo0O0o00O = list ( zip ( i1iI11I1II1 , iIII1i1i , IiI1iii11iIi1 ) )
    if 70 - 70: i11iIiiIii % i1iIIIiI1I
 if OOooO == "true" :
  ii11II1i = 1
  o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if iIiIIii < 100 :
    I1IiiI . update ( iIiIIii )
    iIiIIii = iIiIIii + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1I = [ ]
   for oOoo000 , OooOo00o , url in ooo000o0ooO0 :
    IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : url }
    I1I . append ( IiI11i1IIiiI )
   IIiI11i1111Ii = [ ]
   for IIII1 in I1I :
    IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
     IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
    IIiI11i1111Ii . append ( IiI11i1IIiiI )
    if 11 - 11: OoO000 % i11iiII % i1IIiiiii / i1111 % OooOoO0Oo - I11i1i11i1I
   for IIII1 in IIiI11i1111Ii :
    name = iI1IIIii ( IIII1 [ "display_name" ] )
    url = iI1IIIii ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iIII1i1i . append ( name )
    IiI1iii11iIi1 . append ( url )
    if "hd" in name . lower ( ) :
     i1iI11I1II1 . append ( "1" )
    else :
     i1iI11I1II1 . append ( "0" )
    ooo0O0o00O = list ( zip ( i1iI11I1II1 , iIII1i1i , IiI1iii11iIi1 ) )
    if 96 - 96: i11iiII / i1111 . i1IIiiiii - i1iIIIiI1I * oo0Ooo0 * OooooO0oOO
 if ii11II1i == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 76 - 76: i1IIiiiii - i1111 * oOo0 / i111I
 OOOOoOOo0O0 = sorted ( ooo0O0o00O , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 IIIiIi = sorted ( o0O0O0 )
 if 34 - 34: i111I . oooO0oo0oOOOO / OooooO0oOO * OOO0O - i11iiII
 i1 = 0
 if 36 - 36: II1Ii1iI1i / oooO0oo0oOOOO / oo - oooO0oo0oOOOO - II1Ii1iI1i
 I1IiiI . update ( 100 )
 if 22 - 22: II1Ii1iI1i + i1IIiiiii
 Oooo0O0oo00oO ( '[COLOR dodgerblue][B]LINKS FOR ' + oooo00 . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 Oooo0O0oo00oO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 54 - 54: iiIIiIiIi % oOo0 . OooOoO0Oo + OooooO0oOO - oOo0 * i1IIi11111i
 if 92 - 92: oo0ooO0oOOOOo + OooOoO0Oo / I11i1i11i1I % oo % OoO000 . i111I
 for i1ii in IIIiIi :
  if 52 - 52: iiIIiIiIi / i11iIiiIii - oOo0 . OoO000 % ooO0oo0oO0 + oo0ooO0oOOOOo
  Oooo0O0oo00oO ( '[COLOR orangered][B]' + i1ii . upper ( ) + ' LINKS[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 71 - 71: OooooO0oOO % oo0Ooo0 * OOO0O . oooO0oo0oOOOO / i1IIiiiii . i11iiII
  o000ooooO0o = i1ii . split ( ' ' )
  if 58 - 58: I11i1i11i1I / OooooO0oOO
  for iIII1I1i1i , name , url in OOOOoOOo0O0 :
   if 79 - 79: i1IIiiiii . oo
   IIiI1I1 = 0
   if 15 - 15: i1IIiiiii * I11i1i11i1I % i11iiII * ooO0oo0oO0 - i11iIiiIii
   for Oo00OOOOoo0oo in o000ooooO0o :
    if 80 - 80: OooOoO0Oo * OOO0O * i1111 - oooO0oo0oOOOO . OOO0O % i1IIi11111i
    if not Oo00OOOOoo0oo . lower ( ) in name . lower ( ) :
     IIiI1I1 = 1
     if 13 - 13: OooooO0oOO . i1IIi11111i * OooooO0oOO + i1IIi11111i
   if IIiI1I1 == 0 :
    i1 = i1 + 1
    if "hd" in name . lower ( ) :
     Oooo0O0oo00oO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( i1 ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     Oooo0O0oo00oO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( i1 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 59 - 59: i1IIi11111i + i11iIiiIii + II1Ii1iI1i / oo0Ooo0
  if i1 == 0 :
   Oooo0O0oo00oO ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 44 - 44: oo0Ooo0 . OOO0O * i1IIi11111i + i111I - i1iIIIiI1I - OoO000
  o000ooooO0o = ""
  if 15 - 15: OoO000 / oooO0oo0oOOOO . oo0ooO0oOOOOo . i11iIiiIii
 I1IiiI . close ( )
 if 59 - 59: OooOoO0Oo - oo0ooO0oOOOOo - iiIIiIiIi
def Ii11iI ( name , url , iconimage ) :
 if 52 - 52: oOo0 - i1iIIIiI1I * OooooO0oOO
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 17 - 17: i111I + oOo0 * oo0Ooo0 * OOO0O
 iIiIIii = 0
 try :
  oooo00 , i1ii , iconimage = url . split ( '!' )
 except :
  try :
   i1ii , iconimage = url . split ( '!' )
   oooo00 = i1ii
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 36 - 36: oooO0oo0oOOOO + I11i1i11i1I
 iIIIi1i1I11i = 0
 if 55 - 55: I11i1i11i1I - oOo0
 if "all " in name . lower ( ) :
  i1ii = i1ii . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  oooo00 = oooo00 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  iIIIi1i1I11i = 1
  if 84 - 84: OooOoO0Oo + I11i1i11i1I - OOO0O * OOO0O
 iIII1i1i = [ ]
 IiI1iii11iIi1 = [ ]
 i1iI11I1II1 = [ ]
 I1IiiI . update ( 0 )
 ii11II1i = 0
 if oO000OoOoo00o == "true" :
  ii11II1i = 1
  o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if iIiIIii < 100 :
    I1IiiI . update ( iIiIIii )
    iIiIIii = iIiIIii + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1I = [ ]
   for oOoo000 , OooOo00o , url in ooo000o0ooO0 :
    IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : url }
    I1I . append ( IiI11i1IIiiI )
   IIiI11i1111Ii = [ ]
   for IIII1 in I1I :
    IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
     IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
    IIiI11i1111Ii . append ( IiI11i1IIiiI )
    if 61 - 61: i111I . OooooO0oOO . i111I / I11i1i11i1I
   for IIII1 in IIiI11i1111Ii :
    name = iI1IIIii ( IIII1 [ "display_name" ] )
    url = iI1IIIii ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iIII1i1i . append ( name )
    IiI1iii11iIi1 . append ( url )
    if "hd" in name . lower ( ) :
     i1iI11I1II1 . append ( "1" )
    else :
     i1iI11I1II1 . append ( "0" )
    ooo0O0o00O = list ( zip ( i1iI11I1II1 , iIII1i1i , IiI1iii11iIi1 ) )
    if 72 - 72: II1Ii1iI1i
 if iiiI11 == "true" :
  ii11II1i = 1
  o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if iIiIIii < 100 :
    I1IiiI . update ( iIiIIii )
    iIiIIii = iIiIIii + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1I = [ ]
   for oOoo000 , OooOo00o , url in ooo000o0ooO0 :
    IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : url }
    I1I . append ( IiI11i1IIiiI )
   IIiI11i1111Ii = [ ]
   for IIII1 in I1I :
    IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
     IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
    IIiI11i1111Ii . append ( IiI11i1IIiiI )
    if 82 - 82: OOO0O + i111I / i11iIiiIii * i11iiII . i111I
   for IIII1 in IIiI11i1111Ii :
    name = iI1IIIii ( IIII1 [ "display_name" ] )
    url = iI1IIIii ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iIII1i1i . append ( name )
    IiI1iii11iIi1 . append ( url )
    if "hd" in name . lower ( ) :
     i1iI11I1II1 . append ( "1" )
    else :
     i1iI11I1II1 . append ( "0" )
    ooo0O0o00O = list ( zip ( i1iI11I1II1 , iIII1i1i , IiI1iii11iIi1 ) )
    if 63 - 63: i11iiII
 if OOooO == "true" :
  ii11II1i = 1
  o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if iIiIIii < 100 :
    I1IiiI . update ( iIiIIii )
    iIiIIii = iIiIIii + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1I = [ ]
   for oOoo000 , OooOo00o , url in ooo000o0ooO0 :
    IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : url }
    I1I . append ( IiI11i1IIiiI )
   IIiI11i1111Ii = [ ]
   for IIII1 in I1I :
    IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
     IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
    IIiI11i1111Ii . append ( IiI11i1IIiiI )
    if 6 - 6: iiIIiIiIi / i11iiII
   for IIII1 in IIiI11i1111Ii :
    name = iI1IIIii ( IIII1 [ "display_name" ] )
    url = iI1IIIii ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iIII1i1i . append ( name )
    IiI1iii11iIi1 . append ( url )
    if "hd" in name . lower ( ) :
     i1iI11I1II1 . append ( "1" )
    else :
     i1iI11I1II1 . append ( "0" )
    ooo0O0o00O = list ( zip ( i1iI11I1II1 , iIII1i1i , IiI1iii11iIi1 ) )
    if 57 - 57: oo0Ooo0
 if ii11II1i == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 67 - 67: oo . iiIIiIiIi
 OOOOoOOo0O0 = sorted ( ooo0O0o00O , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 if 87 - 87: OooooO0oOO % i1IIiiiii
 i1 = 0
 if 83 - 83: i1111 - oo0Ooo0
 I1IiiI . update ( 100 )
 if 35 - 35: II1Ii1iI1i - ooO0oo0oO0 + II1Ii1iI1i
 Oooo0O0oo00oO ( '[COLOR dodgerblue][B]LINKS FOR ' + oooo00 . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 Oooo0O0oo00oO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 o000ooooO0o = i1ii . split ( ' ' )
 for iIII1I1i1i , name , url in OOOOoOOo0O0 :
  if iIIIi1i1I11i == 1 :
   OooOOo0 = name
   if 51 - 51: OOO0O
  IIiI1I1 = 0
  if 14 - 14: OoO000 % OooooO0oOO % I11i1i11i1I - i11iIiiIii
  for Oo00OOOOoo0oo in o000ooooO0o :
   if 53 - 53: i1IIiiiii % I11i1i11i1I
   if not Oo00OOOOoo0oo . lower ( ) in name . lower ( ) :
    IIiI1I1 = 1
    if 59 - 59: oOo0 % ooO0oo0oO0 . II1Ii1iI1i + i1111 * OoO000
  if IIiI1I1 == 0 :
   i1 = i1 + 1
   if iIIIi1i1I11i == 1 :
    if "hd" in name . lower ( ) :
     Oooo0O0oo00oO ( '[COLOR blue] ' + str ( OooOOo0 ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     Oooo0O0oo00oO ( '[COLOR blue] ' + str ( OooOOo0 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     Oooo0O0oo00oO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( i1 ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     Oooo0O0oo00oO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( i1 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 41 - 41: i1IIiiiii % i11iiII
 if i1 == 0 :
  Oooo0O0oo00oO ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 12 - 12: oOo0
 I1IiiI . close ( )
 if 69 - 69: i111I + oOo0
def IIi11I1 ( term ) :
 if 49 - 49: i1111 - i1IIi11111i / oo0Ooo0
 iiIiI1i1 = [ ]
 oO0O00oOOoooO = [ ]
 if 74 - 74: oo0Ooo0 - oOo0 + II1Ii1iI1i . i1IIi11111i + oOo0 - oo0Ooo0
 o0OOo0o0O0O = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Oo0OoO00oOO0o in Oo0oOOo :
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  o00oooO0Oo = Oo0OoO00oOO0o
  if 17 - 17: oooO0oo0oOOOO . OooOoO0Oo . oooO0oo0oOOOO + oooO0oo0oOOOO / I11i1i11i1I . iiIIiIiIi
  o00oooO0Oo = o00oooO0Oo . replace ( '#AAASTREAM:' , '#A:' )
  o00oooO0Oo = o00oooO0Oo . replace ( '#EXTINF:' , '#A:' )
  ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( o00oooO0Oo )
  I1I = [ ]
  for oOoo000 , OooOo00o , o00oooO0Oo in ooo000o0ooO0 :
   IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : o00oooO0Oo }
   I1I . append ( IiI11i1IIiiI )
  list = [ ]
  for IIII1 in I1I :
   IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
   ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
   for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
    IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
   list . append ( IiI11i1IIiiI )
   if 62 - 62: i11iiII % i1iIIIiI1I * oo - II1Ii1iI1i
  for IIII1 in list :
   OoOO0oo0o = iI1IIIii ( IIII1 [ "display_name" ] )
   o00oooO0Oo = iI1IIIii ( IIII1 [ "url" ] )
   o00oooO0Oo = o00oooO0Oo . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in OoOO0oo0o . lower ( ) :
    iiIiI1i1 . append ( o00oooO0Oo )
    oO0O00oOOoooO . append ( OoOO0oo0o )
    if 66 - 66: i11iIiiIii / oo0ooO0oOOOOo - i111I / II1Ii1iI1i . i11iIiiIii
 O00ooooo00 = xbmcgui . Dialog ( )
 o00O0O = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , oO0O00oOOoooO )
 if o00O0O < 0 :
  quit ( )
  if 16 - 16: I11i1i11i1I % i11iiII + oo0Ooo0 - oooO0oo0oOOOO . i1iIIIiI1I / OooOoO0Oo
 o00oooO0Oo = iiIiI1i1 [ o00O0O ]
 OoOO0oo0o = oO0O00oOOoooO [ o00O0O ]
 i1iI ( OoOO0oo0o , o00oooO0Oo , iiiii )
 if 35 - 35: OooooO0oOO / OooOoO0Oo / i1111 - ooO0oo0oO0 + i1111 . OooOoO0Oo
def O0O00O000OOO ( name , url , iconimage ) :
 if 3 - 3: oooO0oo0oOOOO
 list = Ooo0Oo0oo0 ( url )
 if 83 - 83: OooOoO0Oo
 ii111Ii11iii = 0
 Oooo = open ( iI1Ii11111iIi , mode = 'r' ) ; o00 = Oooo . read ( ) ; Oooo . close ( )
 o00 = o00 . replace ( '\n' , '' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( o00 )
 oOoO00 = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 67 - 67: oo0ooO0oOOOOo % OOO0O . OOO0O - iiIIiIiIi
  O00ooOo = re . compile ( '<url>(.+?)</url>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  if 80 - 80: oo0ooO0oOOOOo - oOo0 + i111I
  if url == O00ooOo :
   ii111Ii11iii = 1
   if 98 - 98: oOo0 + II1Ii1iI1i . i1IIi11111i - i1111 - oo0ooO0oOOOOo
 for IIII1 in list :
  name = iI1IIIii ( IIII1 [ "display_name" ] )
  url = iI1IIIii ( IIII1 [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if ii111Ii11iii == 1 :
   if 24 - 24: I11i1i11i1I - II1Ii1iI1i + oo0Ooo0
   Oooo = open ( i1i1II , mode = 'r' ) ; o00 = Oooo . read ( ) ; Oooo . close ( )
   o00 = o00 . replace ( '\n' , '' )
   Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( o00 )
   for Oo0OoO00oOO0o in Oo0oOOo :
    if 38 - 38: i111I / i11iiII . oooO0oo0oOOOO / II1Ii1iI1i / I11i1i11i1I + ooO0oo0oO0
    ooO00O00oOO = re . compile ( '<name>(.+?)</name>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    if 40 - 40: i1iIIIiI1I . OooooO0oOO + i1IIi11111i + i11iiII + OooOoO0Oo
    i11 = ooO00O00oOO . replace ( ' ' , '' )
    Ii1I1I11I = name . replace ( ' ' , '' )
    if i11 . lower ( ) in Ii1I1I11I . lower ( ) :
     if 29 - 29: i111I . i1IIi11111i % i11iiII - i1iIIIiI1I
     Oooo = open ( O0oo0OO0 , mode = 'r' ) ; o00 = Oooo . read ( ) ; Oooo . close ( )
     o00 = o00 . replace ( '\n' , '' )
     Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( o00 )
     for Oo0OoO00oOO0o in Oo0oOOo :
      if 8 - 8: II1Ii1iI1i
      iIiI1 = re . compile ( '<replace>(.+?)</replace>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
      if 37 - 37: oo * i11iIiiIii / oOo0 % OooOoO0Oo
      name = name . lower ( ) . replace ( iIiI1 , '' )
      if 71 - 71: i111I
     Oooo0O0oo00oO ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 11 - 11: OoO000
  else : Oooo0O0oo00oO ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 55 - 55: I11i1i11i1I
def Ooo0Oo0oo0 ( url ) :
 if 77 - 77: i1111
 IiiiIi1iI1iI = Oo0O0O0ooO0O ( url )
 IiiiIi1iI1iI = IiiiIi1iI1iI . replace ( '#AAASTREAM:' , '#A:' )
 IiiiIi1iI1iI = IiiiIi1iI1iI . replace ( '#EXTINF:' , '#A:' )
 ooo000o0ooO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IiiiIi1iI1iI )
 I1I = [ ]
 for oOoo000 , OooOo00o , url in ooo000o0ooO0 :
  IiI11i1IIiiI = { "params" : oOoo000 , "display_name" : OooOo00o , "url" : url }
  I1I . append ( IiI11i1IIiiI )
 list = [ ]
 for IIII1 in I1I :
  IiI11i1IIiiI = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
  ooo000o0ooO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
  for oOOo000oOoO0 , OoOo00o0OO in ooo000o0ooO0 :
   IiI11i1IIiiI [ oOOo000oOoO0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OoOo00o0OO . strip ( )
  list . append ( IiI11i1IIiiI )
  if 98 - 98: oo / oOo0 * i11iiII / OooooO0oOO
 return list
 if 64 - 64: OooooO0oOO - i1IIi11111i / i1iIIIiI1I - oo
 if 37 - 37: i11iIiiIii / i1iIIIiI1I
def oo00OoO ( ) :
 if 30 - 30: I11i1i11i1I . oo
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 57 - 57: oo0Ooo0 . I11i1i11i1I + i1111
def i111i11I1ii ( name , url , iconimage ) :
 if 64 - 64: OooooO0oOO / i11iIiiIii / oo0ooO0oOOOOo . i111I
 i1iiIIi11I = datetime . datetime . now ( )
 o0o0oOo000o0 = i1iiIIi11I . day
 if 25 - 25: oo0Ooo0 + OOO0O . oo0ooO0oOOOOo % OOO0O * oOo0
 ii1IiIi11 = o0o0oOo000o0
 if 22 - 22: OooooO0oOO
 ii1ii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOoooO00O = datetime . datetime . strftime ( ii1ii , '%A - %d %B %Y' )
 I1ii1111Ii = 'http://www.predictz.com/predictions/'
 if 69 - 69: OoO000 . oo + i1111
 oO0o = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 OooooOoO = datetime . datetime . strftime ( oO0o , '%A - %d %B %Y' )
 i1oOOOOOOOoO = datetime . datetime . strftime ( oO0o , '%d' )
 I1 = 'http://www.predictz.com/predictions/tomorrow/'
 if 13 - 13: OOO0O / i11iiII . oOo0 * oo0Ooo0 - I11i1i11i1I / OooooO0oOO
 II1i = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 o0OO00oo = datetime . datetime . strftime ( II1i , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1i1IiIiIi1Ii = datetime . datetime . strftime ( II1i , '%y%m%d' )
 oO0ooOO = 'http://www.predictz.com/predictions/20' + str ( i1i1IiIiIi1Ii )
 if 16 - 16: I11i1i11i1I + iiIIiIiIi / I11i1i11i1I / oo % OooooO0oOO % i11iiII
 Ii1II11II1iii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 o0oOO0ooOoO = datetime . datetime . strftime ( Ii1II11II1iii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO0000o00O = datetime . datetime . strftime ( Ii1II11II1iii , '%y%m%d' )
 O0Ooo = 'http://www.predictz.com/predictions/20' + str ( ooO0000o00O )
 if 78 - 78: oo % OoO000 * II1Ii1iI1i
 O0 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iI = datetime . datetime . strftime ( O0 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii1I = datetime . datetime . strftime ( O0 , '%y%m%d' )
 IiiIiiIi = 'http://www.predictz.com/predictions/20' + str ( Ii1I )
 if 40 - 40: oo0ooO0oOOOOo
 if 78 - 78: ooO0oo0oO0
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOoooO00O ) + '[/B][/COLOR]' , I1ii1111Ii , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OooooOoO ) + '[/B][/COLOR]' , I1 , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0OO00oo ) , oO0ooOO , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0oOO0ooOoO ) , O0Ooo , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iI ) , IiiIiiIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 56 - 56: i111I - oo0Ooo0 - II1Ii1iI1i
def I1i1I ( name , url , iconimage ) :
 if 35 - 35: i11iIiiIii - i1IIi11111i
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 o000ooooO0o = str ( Oo0oOOo )
 iIi1i = re . compile ( '<tr(.+?)</tr>' ) . findall ( o000ooooO0o )
 for Oo0OoO00oOO0o in iIi1i :
  try :
   IIi1ii1Ii = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR red][B]' + IIi1ii1Ii + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OO0o0oOOO0O = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OOoo0oO00oo00 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   o0OO0o0oOOO0O = O0ii ( o0OO0o0oOOO0O )
   OOoo0oO00oo00 = O0ii ( OOoo0oO00oo00 )
   Oooo0O0oo00oO ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + OOoo0oO00oo00 + ' [/B][/COLOR]| [COLOR mediumpurple]' + o0OO0o0oOOO0O + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 54 - 54: i1111 - OOO0O
def ooOOooo0Oo ( name , url , iconimage ) :
 if 66 - 66: I11i1i11i1I
 i1iiIIi11I = datetime . datetime . now ( )
 o0o0oOo000o0 = i1iiIIi11I . day
 if 28 - 28: OoO000 - OoO000 . II1Ii1iI1i - iiIIiIiIi + i1IIi11111i . OoO000
 ii1IiIi11 = o0o0oOo000o0
 if 54 - 54: OOO0O - OooOoO0Oo
 ii1ii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOoooO00O = datetime . datetime . strftime ( ii1ii , '%A - %d %B %Y' )
 I1ii1111Ii = 'http://www.predictz.com/predictions/'
 if 3 - 3: i1IIi11111i - I11i1i11i1I
 oO0o = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 OooooOoO = datetime . datetime . strftime ( oO0o , '%A - %d %B %Y' )
 i1oOOOOOOOoO = datetime . datetime . strftime ( oO0o , '%d' )
 I1 = 'http://www.predictz.com/predictions/tomorrow/'
 if 16 - 16: OooooO0oOO + iiIIiIiIi / oo0ooO0oOOOOo
 II1i = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 o0OO00oo = datetime . datetime . strftime ( II1i , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1i1IiIiIi1Ii = datetime . datetime . strftime ( II1i , '%y%m%d' )
 oO0ooOO = 'http://www.predictz.com/predictions/20' + str ( i1i1IiIiIi1Ii )
 if 82 - 82: OoO000 * i11iIiiIii % i1111 - i111I
 Ii1II11II1iii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 o0oOO0ooOoO = datetime . datetime . strftime ( Ii1II11II1iii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO0000o00O = datetime . datetime . strftime ( Ii1II11II1iii , '%y%m%d' )
 O0Ooo = 'http://www.predictz.com/predictions/20' + str ( ooO0000o00O )
 if 90 - 90: I11i1i11i1I . OooooO0oOO * II1Ii1iI1i - II1Ii1iI1i
 O0 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iI = datetime . datetime . strftime ( O0 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii1I = datetime . datetime . strftime ( O0 , '%y%m%d' )
 IiiIiiIi = 'http://www.predictz.com/predictions/20' + str ( Ii1I )
 if 16 - 16: i1IIi11111i * II1Ii1iI1i - oo0ooO0oOOOOo . OoO000 % oo0Ooo0 / oo0ooO0oOOOOo
 if 14 - 14: ooO0oo0oO0 * OooOoO0Oo * i11iiII / ooO0oo0oO0 * OoO000 / oo0Ooo0
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOoooO00O ) + '[/B][/COLOR]' , I1ii1111Ii , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OooooOoO ) + '[/B][/COLOR]' , I1 , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0OO00oo ) , oO0ooOO , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0oOO0ooOoO ) , O0Ooo , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iI ) , IiiIiiIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 77 - 77: oo + OooOoO0Oo + OooOoO0Oo * i1IIiiiii / i111I . i1IIiiiii
def ooo0O0OO ( name , url , iconimage ) :
 if 61 - 61: OoO000 + ooO0oo0oO0 + i11iIiiIii / i11iIiiIii % i1111
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 o000ooooO0o = str ( Oo0oOOo )
 iIi1i = re . compile ( '<tr(.+?)</tr>' ) . findall ( o000ooooO0o )
 for Oo0OoO00oOO0o in iIi1i :
  try :
   IIi1ii1Ii = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR red][B]' + IIi1ii1Ii + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OO0o0oOOO0O = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I1i111IiIiIi1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1II11II1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   II1IIIii = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   o0OO0o0oOOO0O = O0ii ( o0OO0o0oOOO0O )
   Oooo0O0oo00oO ( '[COLOR mediumpurple][B]' + o0OO0o0oOOO0O + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + I1i111IiIiIi1 + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + i1II11II1 + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + II1IIIii + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 40 - 40: OOO0O % oo
def oo0O0o00 ( name , url , iconimage ) :
 if 70 - 70: oo
 i1iiIIi11I = datetime . datetime . now ( )
 o0o0oOo000o0 = i1iiIIi11I . day
 if 46 - 46: oo0Ooo0 - II1Ii1iI1i
 ii1IiIi11 = o0o0oOo000o0
 if 46 - 46: OooOoO0Oo % i1IIiiiii
 ii1ii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOoooO00O = datetime . datetime . strftime ( ii1ii , '%A - %d %B %Y' )
 I1ii1111Ii = 'http://www.predictz.com/predictions/'
 if 72 - 72: ooO0oo0oO0
 oO0o = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 OooooOoO = datetime . datetime . strftime ( oO0o , '%A - %d %B %Y' )
 i1oOOOOOOOoO = datetime . datetime . strftime ( oO0o , '%d' )
 I1 = 'http://www.predictz.com/predictions/tomorrow/'
 if 45 - 45: I11i1i11i1I - oo0ooO0oOOOOo % OooOoO0Oo
 II1i = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 o0OO00oo = datetime . datetime . strftime ( II1i , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1i1IiIiIi1Ii = datetime . datetime . strftime ( II1i , '%y%m%d' )
 oO0ooOO = 'http://www.predictz.com/predictions/20' + str ( i1i1IiIiIi1Ii )
 if 38 - 38: OooOoO0Oo % oOo0 - i111I
 Ii1II11II1iii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 o0oOO0ooOoO = datetime . datetime . strftime ( Ii1II11II1iii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO0000o00O = datetime . datetime . strftime ( Ii1II11II1iii , '%y%m%d' )
 O0Ooo = 'http://www.predictz.com/predictions/20' + str ( ooO0000o00O )
 if 87 - 87: oo % i1IIi11111i
 O0 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iI = datetime . datetime . strftime ( O0 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii1I = datetime . datetime . strftime ( O0 , '%y%m%d' )
 IiiIiiIi = 'http://www.predictz.com/predictions/20' + str ( Ii1I )
 if 77 - 77: ooO0oo0oO0 - II1Ii1iI1i . OooooO0oOO
 if 26 - 26: oo0ooO0oOOOOo * OoO000 . II1Ii1iI1i
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOoooO00O ) + '[/B][/COLOR]' , I1ii1111Ii , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OooooOoO ) + '[/B][/COLOR]' , I1 , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0OO00oo ) , oO0ooOO , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0oOO0ooOoO ) , O0Ooo , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iI ) , IiiIiiIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 59 - 59: oooO0oo0oOOOO + II1Ii1iI1i - oo0ooO0oOOOOo
def OooOo000o0o ( name , url , iconimage ) :
 if 42 - 42: OooooO0oOO % oOo0
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 o000ooooO0o = str ( Oo0oOOo )
 iIi1i = re . compile ( '<tr(.+?)</tr>' ) . findall ( o000ooooO0o )
 for Oo0OoO00oOO0o in iIi1i :
  try :
   IIi1ii1Ii = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR red][B]' + IIi1ii1Ii + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OO0o0oOOO0O = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1 , I1iI1iIi111i = o0OO0o0oOOO0O . split ( ' v ' )
   OOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iIiIIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   III1I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   I1I111iIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 3 ]
   OoOOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 4 ]
   I1iiIi111I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 5 ]
   Iiii1iIii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 6 ]
   oOoooO000O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 7 ]
   III1I11i1iIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 8 ]
   OO0oo0O0OOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 9 ]
   if 76 - 76: i11iIiiIii / OOO0O + OOO0O / II1Ii1iI1i * i1IIi11111i
   if OOO0 == "W" :
    OOO0 = '[COLOR lime]W[/COLOR]'
   elif OOO0 == "D" :
    OOO0 = '[COLOR yellow]D[/COLOR]'
   else : OOO0 = '[COLOR red]L[/COLOR]'
   if 12 - 12: OooOoO0Oo % i11iIiiIii + oo0ooO0oOOOOo + OooOoO0Oo / oo0Ooo0
   if iIiIIi == "W" :
    iIiIIi = '[COLOR lime]W[/COLOR]'
   elif iIiIIi == "D" :
    iIiIIi = '[COLOR yellow]D[/COLOR]'
   else : iIiIIi = '[COLOR red]L[/COLOR]'
   if 53 - 53: OoO000 . OooOoO0Oo % ooO0oo0oO0 % OOO0O % oo0Ooo0
   if III1I == "W" :
    III1I = '[COLOR lime]W[/COLOR]'
   elif III1I == "D" :
    III1I = '[COLOR yellow]D[/COLOR]'
   else : III1I = '[COLOR red]L[/COLOR]'
   if 53 - 53: OooOoO0Oo
   if I1I111iIi == "W" :
    I1I111iIi = '[COLOR lime]W[/COLOR]'
   elif I1I111iIi == "D" :
    I1I111iIi = '[COLOR yellow]D[/COLOR]'
   else : I1I111iIi = '[COLOR red]L[/COLOR]'
   if 69 - 69: OOO0O . oo0ooO0oOOOOo . i1IIi11111i - i11iiII
   if OoOOOO == "W" :
    OoOOOO = '[COLOR lime]W[/COLOR]'
   elif OoOOOO == "D" :
    OoOOOO = '[COLOR yellow]D[/COLOR]'
   else : OoOOOO = '[COLOR red]L[/COLOR]'
   if 32 - 32: i111I / i1IIi11111i / ooO0oo0oO0 + i1111 . OooooO0oOO . oo0ooO0oOOOOo
   if I1iiIi111I == "W" :
    I1iiIi111I = '[COLOR lime]W[/COLOR]'
   elif I1iiIi111I == "D" :
    I1iiIi111I = '[COLOR yellow]D[/COLOR]'
   else : I1iiIi111I = '[COLOR red]L[/COLOR]'
   if 21 - 21: ooO0oo0oO0 / i1111 % II1Ii1iI1i
   if Iiii1iIii == "W" :
    Iiii1iIii = '[COLOR lime]W[/COLOR]'
   elif Iiii1iIii == "D" :
    Iiii1iIii = '[COLOR yellow]D[/COLOR]'
   else : Iiii1iIii = '[COLOR red]L[/COLOR]'
   if 8 - 8: oo + OOO0O . ooO0oo0oO0 % oooO0oo0oOOOO
   if oOoooO000O == "W" :
    oOoooO000O = '[COLOR lime]W[/COLOR]'
   elif oOoooO000O == "D" :
    oOoooO000O = '[COLOR yellow]D[/COLOR]'
   else : oOoooO000O = '[COLOR red]L[/COLOR]'
   if 43 - 43: i11iiII - i1iIIIiI1I
   if III1I11i1iIi == "W" :
    III1I11i1iIi = '[COLOR lime]W[/COLOR]'
   elif III1I11i1iIi == "D" :
    III1I11i1iIi = '[COLOR yellow]D[/COLOR]'
   else : III1I11i1iIi = '[COLOR red]L[/COLOR]'
   if 70 - 70: i1iIIIiI1I / oOo0 % iiIIiIiIi - i1IIiiiii
   if OO0oo0O0OOO0 == "W" :
    OO0oo0O0OOO0 = '[COLOR lime]W[/COLOR]'
   elif OO0oo0O0OOO0 == "D" :
    OO0oo0O0OOO0 = '[COLOR yellow]D[/COLOR]'
   else : OO0oo0O0OOO0 = '[COLOR red]L[/COLOR]'
   if 47 - 47: i1iIIIiI1I
   i1 = O0ii ( i1 )
   I1iI1iIi111i = O0ii ( I1iI1iIi111i )
   Oooo0O0oo00oO ( '[COLOR mediumpurple][B]' + i1 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[B]' + OOO0 + '  ' + iIiIIi + '  ' + III1I + '  ' + I1I111iIi + '  ' + OoOOOO + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR mediumpurple][B]' + I1iI1iIi111i + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[B]' + I1iiIi111I + '  ' + Iiii1iIii + '  ' + oOoooO000O + '  ' + III1I11i1iIi + '  ' + OO0oo0O0OOO0 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 92 - 92: oOo0 + OOO0O % II1Ii1iI1i
def I1I1I11Ii ( name , url , iconimage ) :
 if 48 - 48: i111I + OooooO0oOO % ooO0oo0oO0
 i1iiIIi11I = datetime . datetime . now ( )
 o0o0oOo000o0 = i1iiIIi11I . day
 if 11 - 11: i1IIi11111i % i1IIiiiii - oo - OooooO0oOO + oo0ooO0oOOOOo
 ii1IiIi11 = o0o0oOo000o0
 if 98 - 98: i1iIIIiI1I + i1IIiiiii - oo
 ii1ii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOoooO00O = datetime . datetime . strftime ( ii1ii , '%A - %d %B %Y' )
 I1ii1111Ii = 'http://www.predictz.com/predictions/'
 if 79 - 79: oOo0 / OooOoO0Oo . OOO0O - i11iiII
 oO0o = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 OooooOoO = datetime . datetime . strftime ( oO0o , '%A - %d %B %Y' )
 i1oOOOOOOOoO = datetime . datetime . strftime ( oO0o , '%d' )
 I1 = 'http://www.predictz.com/predictions/tomorrow/'
 if 47 - 47: i111I % oooO0oo0oOOOO * i1iIIIiI1I . i1IIiiiii
 II1i = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 o0OO00oo = datetime . datetime . strftime ( II1i , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1i1IiIiIi1Ii = datetime . datetime . strftime ( II1i , '%y%m%d' )
 oO0ooOO = 'http://www.predictz.com/predictions/20' + str ( i1i1IiIiIi1Ii )
 if 38 - 38: oooO0oo0oOOOO - OoO000 % OooOoO0Oo
 Ii1II11II1iii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 o0oOO0ooOoO = datetime . datetime . strftime ( Ii1II11II1iii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO0000o00O = datetime . datetime . strftime ( Ii1II11II1iii , '%y%m%d' )
 O0Ooo = 'http://www.predictz.com/predictions/20' + str ( ooO0000o00O )
 if 64 - 64: ooO0oo0oO0
 O0 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iI = datetime . datetime . strftime ( O0 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 Ii1I = datetime . datetime . strftime ( O0 , '%y%m%d' )
 IiiIiiIi = 'http://www.predictz.com/predictions/20' + str ( Ii1I )
 if 15 - 15: i11iiII + oOo0 / i11iiII / OooOoO0Oo
 if 31 - 31: iiIIiIiIi + oooO0oo0oOOOO + iiIIiIiIi . ooO0oo0oO0 + I11i1i11i1I / oo0ooO0oOOOOo
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOoooO00O ) + '[/B][/COLOR]' , I1ii1111Ii , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OooooOoO ) + '[/B][/COLOR]' , I1 , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0OO00oo ) , oO0ooOO , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0oOO0ooOoO ) , O0Ooo , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iI ) , IiiIiiIi , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 6 - 6: I11i1i11i1I % OoO000 * oo0Ooo0 / i1IIi11111i + I11i1i11i1I
def IIiI11i11 ( name , url , iconimage ) :
 if 14 - 14: i11iIiiIii
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 o000ooooO0o = str ( Oo0oOOo )
 iIi1i = re . compile ( '<tr(.+?)</tr>' ) . findall ( o000ooooO0o )
 for Oo0OoO00oOO0o in iIi1i :
  try :
   IIi1ii1Ii = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR red][B]' + IIi1ii1Ii + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OO0o0oOOO0O = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1 , I1iI1iIi111i = o0OO0o0oOOO0O . split ( ' v ' )
   if 73 - 73: iiIIiIiIi + OooooO0oOO . oo
   OOoo0oO00oo00 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I1i111IiIiIi1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1II11II1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   II1IIIii = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   OOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iIiIIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   III1I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   I1I111iIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 3 ]
   OoOOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 4 ]
   I1iiIi111I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 5 ]
   Iiii1iIii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 6 ]
   oOoooO000O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 7 ]
   III1I11i1iIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 8 ]
   OO0oo0O0OOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 9 ]
   if 46 - 46: oo - oo0ooO0oOOOOo / OOO0O - i111I + OooooO0oOO
   if OOO0 == "W" :
    OOO0 = '[COLOR lime]W[/COLOR]'
   elif OOO0 == "D" :
    OOO0 = '[COLOR yellow]D[/COLOR]'
   else : OOO0 = '[COLOR red]L[/COLOR]'
   if 58 - 58: oo0ooO0oOOOOo / oo0ooO0oOOOOo + iiIIiIiIi + oo0Ooo0 - OOO0O . oOo0
   if iIiIIi == "W" :
    iIiIIi = '[COLOR lime]W[/COLOR]'
   elif iIiIIi == "D" :
    iIiIIi = '[COLOR yellow]D[/COLOR]'
   else : iIiIIi = '[COLOR red]L[/COLOR]'
   if 15 - 15: iiIIiIiIi * OOO0O % OoO000 . OOO0O . oo0Ooo0
   if III1I == "W" :
    III1I = '[COLOR lime]W[/COLOR]'
   elif III1I == "D" :
    III1I = '[COLOR yellow]D[/COLOR]'
   else : III1I = '[COLOR red]L[/COLOR]'
   if 97 - 97: OooooO0oOO
   if I1I111iIi == "W" :
    I1I111iIi = '[COLOR lime]W[/COLOR]'
   elif I1I111iIi == "D" :
    I1I111iIi = '[COLOR yellow]D[/COLOR]'
   else : I1I111iIi = '[COLOR red]L[/COLOR]'
   if 80 - 80: i1IIi11111i . i1IIiiiii
   if OoOOOO == "W" :
    OoOOOO = '[COLOR lime]W[/COLOR]'
   elif OoOOOO == "D" :
    OoOOOO = '[COLOR yellow]D[/COLOR]'
   else : OoOOOO = '[COLOR red]L[/COLOR]'
   if 47 - 47: oo0Ooo0 + iiIIiIiIi + i1111 % i11iIiiIii
   if I1iiIi111I == "W" :
    I1iiIi111I = '[COLOR lime]W[/COLOR]'
   elif I1iiIi111I == "D" :
    I1iiIi111I = '[COLOR yellow]D[/COLOR]'
   else : I1iiIi111I = '[COLOR red]L[/COLOR]'
   if 93 - 93: i11iiII % OOO0O . oooO0oo0oOOOO / i1iIIIiI1I * OooooO0oOO
   if Iiii1iIii == "W" :
    Iiii1iIii = '[COLOR lime]W[/COLOR]'
   elif Iiii1iIii == "D" :
    Iiii1iIii = '[COLOR yellow]D[/COLOR]'
   else : Iiii1iIii = '[COLOR red]L[/COLOR]'
   if 29 - 29: oo0ooO0oOOOOo
   if oOoooO000O == "W" :
    oOoooO000O = '[COLOR lime]W[/COLOR]'
   elif oOoooO000O == "D" :
    oOoooO000O = '[COLOR yellow]D[/COLOR]'
   else : oOoooO000O = '[COLOR red]L[/COLOR]'
   if 86 - 86: i1111 . OoO000
   if III1I11i1iIi == "W" :
    III1I11i1iIi = '[COLOR lime]W[/COLOR]'
   elif III1I11i1iIi == "D" :
    III1I11i1iIi = '[COLOR yellow]D[/COLOR]'
   else : III1I11i1iIi = '[COLOR red]L[/COLOR]'
   if 2 - 2: i111I
   if OO0oo0O0OOO0 == "W" :
    OO0oo0O0OOO0 = '[COLOR lime]W[/COLOR]'
   elif OO0oo0O0OOO0 == "D" :
    OO0oo0O0OOO0 = '[COLOR yellow]D[/COLOR]'
   else : OO0oo0O0OOO0 = '[COLOR red]L[/COLOR]'
   if 60 - 60: oo
   i1 = O0ii ( i1 )
   I1iI1iIi111i = O0ii ( I1iI1iIi111i )
   o0OO0o0oOOO0O = O0ii ( o0OO0o0oOOO0O )
   OOoo0oO00oo00 = O0ii ( OOoo0oO00oo00 )
   Oooo0O0oo00oO ( '[COLOR blue][B]' + o0OO0o0oOOO0O + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + OOoo0oO00oo00 + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR orange]' + i1 + ' Form: - [/COLOR][B]' + OOO0 + '  ' + iIiIIi + '  ' + III1I + '  ' + I1I111iIi + '  ' + OoOOOO + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR orange]' + I1iI1iIi111i + ' Form - [/COLOR][B]' + I1iiIi111I + '  ' + Iiii1iIii + '  ' + oOoooO000O + '  ' + III1I11i1iIi + '  ' + OO0oo0O0OOO0 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR orange]' + i1 + ' Win[/COLOR][COLOR dodgerblue][B] (' + I1i111IiIiIi1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + i1II11II1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '[COLOR orange]' + I1iI1iIi111i + ' Win[/COLOR][COLOR dodgerblue][B] (' + II1IIIii + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   Oooo0O0oo00oO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 81 - 81: OOO0O % i1IIiiiii
  except : pass
  if 87 - 87: ooO0oo0oO0 . i111I * OOO0O
def OOOo ( name , url , iconimage ) :
 if 74 - 74: i1IIiiiii - i111I . I11i1i11i1I
 III1Ii1i1I1 = [ ]
 O0O00OooO = [ ]
 I1IiI1iI11 = [ ]
 iIi = [ ]
 iiO0O0o0oO0O00 = [ ]
 if 70 - 70: OooOoO0Oo + OooooO0oOO
 iII = o0 ( 'http://www.livescores.com' )
 Oo0oOOo = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( iII )
 o000ooooO0o = str ( Oo0oOOo )
 iIi1i = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( o000ooooO0o )
 for Oo0OoO00oOO0o in iIi1i :
  o00ooo0 = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  i1i1IiIi1 = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   OOoo0oO00oo00 = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except :
   OOoo0oO00oo00 = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 22 - 22: oo0Ooo0 * oooO0oo0oOOOO . i1111 - oo
  if "minute" in time . lower ( ) :
   iiO0O0o0oO0O00 . append ( '3' )
  elif "ht" in time . lower ( ) :
   iiO0O0o0oO0O00 . append ( '3' )
  elif "ft" in time . lower ( ) :
   iiO0O0o0oO0O00 . append ( '2' )
  else : iiO0O0o0oO0O00 . append ( '1' )
  if 90 - 90: OooooO0oOO
  III1Ii1i1I1 . append ( o00ooo0 )
  O0O00OooO . append ( i1i1IiIi1 )
  I1IiI1iI11 . append ( OOoo0oO00oo00 )
  iIi . append ( time )
  ooo0O0o00O = list ( zip ( iiO0O0o0oO0O00 , III1Ii1i1I1 , O0O00OooO , I1IiI1iI11 , iIi ) )
  if 94 - 94: oo0Ooo0 / i11iiII * OooOoO0Oo - OOO0O
 Oooo0O0oo00oO ( '[COLOR dodgerblue][B]The scores will update every 10 seconds.[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 Oooo0O0oo00oO ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 44 - 44: i1IIiiiii % i11iIiiIii - i1iIIIiI1I * i11iiII + I11i1i11i1I * oOo0
 OOOOoOOo0O0 = sorted ( ooo0O0o00O , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 IiI1iI1IiiIi1 = 0
 OoO0oo = 0
 OoOoO0O = 0
 for o0i1I11iI1iiI , I1ii , oO0oI1I1 , O0Oo0 , OOooO0OO0 in OOOOoOOo0O0 :
  if o0i1I11iI1iiI == "3" :
   if IiI1iI1IiiIi1 == 0 :
    Oooo0O0oo00oO ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    IiI1iI1IiiIi1 = 1
  elif o0i1I11iI1iiI == "2" :
   if OoO0oo == 0 :
    Oooo0O0oo00oO ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    OoO0oo = 1
  elif o0i1I11iI1iiI == "1" :
   if OoOoO0O == 0 :
    Oooo0O0oo00oO ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    OoOoO0O = 1
  OOooO0OO0 = OOooO0OO0 . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  O0Oo0 = O0Oo0 . replace ( " " , "" )
  Oooo0O0oo00oO ( '[COLOR red][B]' + OOooO0OO0 + "[/B][/COLOR]- [COLOR blue]" + O0Oo0 + "[/COLOR] | [COLOR white]" + I1ii + "vs" + oO0oI1I1 + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 5 - 5: i1iIIIiI1I
def OOiI1 ( ) :
 if 42 - 42: oOo0 % OooooO0oOO / oo - OooooO0oOO * i11iIiiIii
 o000ooooO0o = ''
 iI1IiiiIiI1Ii = xbmc . Keyboard ( o000ooooO0o , 'Enter Search Term' )
 iI1IiiiIiI1Ii . doModal ( )
 if iI1IiiiIiI1Ii . isConfirmed ( ) :
  o000ooooO0o = iI1IiiiIiI1Ii . getText ( )
  if len ( o000ooooO0o ) > 1 :
   o00oooO0Oo = o000ooooO0o + "!" + iiiii
   Ii11iI ( "all " + o000ooooO0o , o00oooO0Oo , iiiii )
  else : quit ( )
  if 78 - 78: i111I / oOo0 % OOO0O * i111I
def ooOO00o00 ( name , url , iconimage ) :
 if 18 - 18: ooO0oo0oO0 + oo0Ooo0 * i1IIi11111i - oOo0 / i1IIi11111i
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 78 - 78: oo0Ooo0 . OoO000
def iioo0o0OoOOO ( text ) :
 if 38 - 38: OOO0O + OoO000
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 15 - 15: I11i1i11i1I + oo0Ooo0 . iiIIiIiIi - ooO0oo0oO0 / oooO0oo0oOOOO % ooO0oo0oO0
 return text
 if 86 - 86: i1IIi11111i / OooooO0oOO * i1IIiiiii
def O0ii ( text ) :
 if 64 - 64: iiIIiIiIi / oooO0oo0oOOOO * OOO0O * iiIIiIiIi
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 60 - 60: oo0Ooo0 / II1Ii1iI1i % i11iiII / i11iiII * i11iiII . i11iIiiIii
 return text
 if 99 - 99: OOO0O
def O0ooO0ooo0oO ( text ) :
 if 77 - 77: oo0ooO0oOOOOo
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 48 - 48: OOO0O % i11iiII / oo0Ooo0 . ooO0oo0oO0 * i1111
 return text
 if 65 - 65: OOO0O
def i1iI ( name , url , iconimage ) :
 if 31 - 31: oo0Ooo0 * OOO0O . OoO000 % i1IIiiiii + I11i1i11i1I
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]Opening link...[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 47 - 47: oooO0oo0oOOOO * i1IIi11111i * oo . i1111
 if "pl_type=user" in url :
  o0OOo0o0O0O = o0 ( url )
  url = re . compile ( '<meta property="og:video:iframe" content="(.+?)">' ) . findall ( o0OOo0o0O0O ) [ 0 ]
  if 95 - 95: i1IIiiiii % OoO000 . oooO0oo0oOOOO % OooOoO0Oo
 if not "plugin" in url :
  try :
   if not 'http' in url : url = 'http://' + url
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 68 - 68: I11i1i11i1I . I11i1i11i1I - i11iiII / oo0Ooo0 . iiIIiIiIi / II1Ii1iI1i
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 12 - 12: i11iiII * II1Ii1iI1i * oo0Ooo0
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  i1iiI = urlresolver . HostedMediaFile ( url ) . resolve ( )
  I11 = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  I11 . setPath ( i1iiI )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( i1iiI , I11 , False )
  quit ( )
 else :
  i1iiI = url
  I11 = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  I11 . setPath ( i1iiI )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( i1iiI , I11 , False )
  quit ( )
  if 54 - 54: i1IIiiiii - OooOoO0Oo
def Oo0 ( ) :
 if 81 - 81: OoO000 . oooO0oo0oOOOO + i1111 * ooO0oo0oO0 * oOo0 / OOO0O
 Oo0OoOOOo = xbmc . getInfoLabel ( "System.BuildVersion" )
 I1II = float ( Oo0OoOOOo [ : 4 ] )
 if I1II >= 11.0 and I1II <= 11.9 :
  II11I = 'Eden'
 elif I1II >= 12.0 and I1II <= 12.9 :
  II11I = 'Frodo'
 elif I1II >= 13.0 and I1II <= 13.9 :
  II11I = 'Gotham'
 elif I1II >= 14.0 and I1II <= 14.9 :
  II11I = 'Helix'
 elif I1II >= 15.0 and I1II <= 15.9 :
  II11I = 'Isengard'
 elif I1II >= 16.0 and I1II <= 16.9 :
  II11I = 'Jarvis'
 elif I1II >= 17.0 and I1II <= 17.9 :
  II11I = 'Krypton'
 else : II11I = "Decline"
 if 31 - 31: i1IIiiiii
 return II11I
 if 18 - 18: iiIIiIiIi + i1IIiiiii
def o0 ( url ) :
 if 5 - 5: i111I + oo0Ooo0 * i1111
 OOoooooooO = urllib2 . Request ( url )
 OOoooooooO . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 IiiiIi1iI1iI = urllib2 . urlopen ( OOoooooooO )
 iII = IiiiIi1iI1iI . read ( )
 IiiiIi1iI1iI . close ( )
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return iII
 if 4 - 4: I11i1i11i1I + oo0ooO0oOOOOo
def Oo0O0O0ooO0O ( url ) :
 if 17 - 17: oo * OOO0O
 OOoooooooO = urllib2 . Request ( url )
 OOoooooooO . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 IiiiIi1iI1iI = urllib2 . urlopen ( OOoooooooO )
 iII = IiiiIi1iI1iI . read ( )
 IiiiIi1iI1iI . close ( )
 return iII
 if 15 - 15: i11iIiiIii / iiIIiIiIi % i1IIi11111i
def iI1IIIii ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 71 - 71: OooOoO0Oo / i11iiII * ooO0oo0oO0
 if 57 - 57: oOo0 + OooOoO0Oo % i11iiII . oo / oo * oooO0oo0oOOOO
 if 6 - 6: II1Ii1iI1i - i1111 * oo0ooO0oOOOOo . oo
 if 68 - 68: oo0ooO0oOOOOo
 if 20 - 20: OooOoO0Oo - OooOoO0Oo
def iIIiI11i1I11 ( ) :
 if 29 - 29: oo * ooO0oo0oO0 * oooO0oo0oOOOO - OOO0O / OoO000
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 99 - 99: iiIIiIiIi
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for o0OO00 , iIi11i , ooIII1II1iii1i in os . walk ( IiIi11iIIi1Ii ) :
   O0OO0oOO = 0
   O0OO0oOO += len ( ooIII1II1iii1i )
   if O0OO0oOO > 0 :
    for Oooo in ooIII1II1iii1i :
     try :
      if ( Oooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o0OO00 , Oooo ) )
     except :
      pass
    for ooooO in iIi11i :
     try :
      shutil . rmtree ( os . path . join ( o0OO00 , ooooO ) )
     except :
      pass
      if 92 - 92: oo0ooO0oOOOOo / oo0ooO0oOOOOo * i1IIiiiii
   else :
    pass
    if 19 - 19: i1IIiiiii
 if os . path . exists ( Oo0O ) == True :
  for o0OO00 , iIi11i , ooIII1II1iii1i in os . walk ( Oo0O ) :
   O0OO0oOO = 0
   O0OO0oOO += len ( ooIII1II1iii1i )
   if O0OO0oOO > 0 :
    for Oooo in ooIII1II1iii1i :
     try :
      if ( Oooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o0OO00 , Oooo ) )
     except :
      pass
    for ooooO in iIi11i :
     try :
      shutil . rmtree ( os . path . join ( o0OO00 , ooooO ) )
     except :
      pass
      if 55 - 55: oOo0 % oOo0 / oooO0oo0oOOOO % i1iIIIiI1I - oo0ooO0oOOOOo . I11i1i11i1I
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iiiii1I1III1 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 12 - 12: i1iIIIiI1I . OOO0O * i1IIi11111i
  for o0OO00 , iIi11i , ooIII1II1iii1i in os . walk ( iiiii1I1III1 ) :
   O0OO0oOO = 0
   O0OO0oOO += len ( ooIII1II1iii1i )
   if 37 - 37: i11iiII * i1IIi11111i % i11iIiiIii % II1Ii1iI1i % OoO000
   if O0OO0oOO > 0 :
    for Oooo in ooIII1II1iii1i :
     os . unlink ( os . path . join ( o0OO00 , Oooo ) )
    for ooooO in iIi11i :
     shutil . rmtree ( os . path . join ( o0OO00 , ooooO ) )
     if 15 - 15: ooO0oo0oO0 . oooO0oo0oOOOO
   else :
    pass
  O0o0O = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 6 - 6: i1111
  for o0OO00 , iIi11i , ooIII1II1iii1i in os . walk ( O0o0O ) :
   O0OO0oOO = 0
   O0OO0oOO += len ( ooIII1II1iii1i )
   if 7 - 7: i1IIiiiii % II1Ii1iI1i * i111I * oooO0oo0oOOOO + i1iIIIiI1I
   if O0OO0oOO > 0 :
    for Oooo in ooIII1II1iii1i :
     os . unlink ( os . path . join ( o0OO00 , Oooo ) )
    for ooooO in iIi11i :
     shutil . rmtree ( os . path . join ( o0OO00 , ooooO ) )
     if 95 - 95: i111I + oo0Ooo0 - i11iiII / i11iiII . II1Ii1iI1i . i111I
   else :
    pass
    if 29 - 29: iiIIiIiIi - II1Ii1iI1i . oo0Ooo0 - i11iiII + iiIIiIiIi + i111I
 iii11 = o00oOO0 ( )
 if 36 - 36: II1Ii1iI1i / iiIIiIiIi . ooO0oo0oO0
 for i1IiiiiIi1I in iii11 :
  ooo0O0o0OoOO = xbmc . translatePath ( i1IiiiiIi1I . path )
  if os . path . exists ( ooo0O0o0OoOO ) == True :
   for o0OO00 , iIi11i , ooIII1II1iii1i in os . walk ( ooo0O0o0OoOO ) :
    O0OO0oOO = 0
    O0OO0oOO += len ( ooIII1II1iii1i )
    if O0OO0oOO > 0 :
     for Oooo in ooIII1II1iii1i :
      os . unlink ( os . path . join ( o0OO00 , Oooo ) )
     for ooooO in iIi11i :
      shutil . rmtree ( os . path . join ( o0OO00 , ooooO ) )
      if 9 - 9: oo
    else :
     pass
     if 60 - 60: OooOoO0Oo
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 98 - 98: iiIIiIiIi
def Ii11i1Ii1IIII ( ) :
 i1iiIooo = [ ]
 O0oOoo = sys . argv [ 2 ]
 if len ( O0oOoo ) >= 2 :
  oOoo000 = sys . argv [ 2 ]
  OoOOoO0O0oO = oOoo000 . replace ( '?' , '' )
  if ( oOoo000 [ len ( oOoo000 ) - 1 ] == '/' ) :
   oOoo000 = oOoo000 [ 0 : len ( oOoo000 ) - 2 ]
  oOOoO = OoOOoO0O0oO . split ( '&' )
  i1iiIooo = { }
  for OO in range ( len ( oOOoO ) ) :
   oOo0Oo0O0O = { }
   oOo0Oo0O0O = oOOoO [ OO ] . split ( '=' )
   if ( len ( oOo0Oo0O0O ) ) == 2 :
    i1iiIooo [ oOo0Oo0O0O [ 0 ] ] = oOo0Oo0O0O [ 1 ]
 return i1iiIooo
 if 48 - 48: I11i1i11i1I - iiIIiIiIi + I11i1i11i1I - i1IIi11111i * i11iIiiIii . i1iIIIiI1I
def II11i1I11Ii1i ( name , url , mode , iconimage , fanart , description = '' ) :
 if 35 - 35: OoO000 . oooO0oo0oOOOO + I11i1i11i1I + oOo0 + II1Ii1iI1i
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 OooOooO0O0o0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OOO0o0 = True
 I11 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 I11 . setProperty ( "fanart_Image" , fanart )
 I11 . setProperty ( "icon_Image" , iconimage )
 OOO0o0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OooOooO0O0o0 , listitem = I11 , isFolder = True )
 return OOO0o0
 if 34 - 34: i1IIi11111i % I11i1i11i1I - OOO0O + i1iIIIiI1I
def Oooo0O0oo00oO ( name , url , mode , iconimage , fanart , description = '' ) :
 if 79 - 79: i1111 - iiIIiIiIi . II1Ii1iI1i + oooO0oo0oOOOO % oooO0oo0oOOOO * i1IIi11111i
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 OooOooO0O0o0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OOO0o0 = True
 I11 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 I11 . setProperty ( "fanart_Image" , fanart )
 I11 . setProperty ( "icon_Image" , iconimage )
 OOO0o0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OooOooO0O0o0 , listitem = I11 , isFolder = False )
 return OOO0o0
 if 7 - 7: II1Ii1iI1i + oOo0 % i1iIIIiI1I / oo0ooO0oOOOOo + II1Ii1iI1i
oOoo000 = Ii11i1Ii1IIII ( ) ; o00oooO0Oo = None ; OoOO0oo0o = None ; I1ii11I = None ; II1II1IIII = None ; iiIiI = None ; oOooOOOoOo = None
try : II1II1IIII = urllib . unquote_plus ( oOoo000 [ "site" ] )
except : pass
try : o00oooO0Oo = urllib . unquote_plus ( oOoo000 [ "url" ] )
except : pass
try : OoOO0oo0o = urllib . unquote_plus ( oOoo000 [ "name" ] )
except : pass
try : I1ii11I = int ( oOoo000 [ "mode" ] )
except : pass
try : iiIiI = urllib . unquote_plus ( oOoo000 [ "iconimage" ] )
except : pass
try : oOooOOOoOo = urllib . unquote_plus ( oOoo000 [ "fanart" ] )
except : pass
if 37 - 37: i111I
if I1ii11I == None or o00oooO0Oo == None or len ( o00oooO0Oo ) < 1 : o0O0o0Oo ( )
elif I1ii11I == 1 : I1IiiiiI ( OoOO0oo0o , o00oooO0Oo )
elif I1ii11I == 2 : i1iI ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 3 : OO0O000 ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 4 : PLAYSD ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 7 : IIiIiI ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 8 : i11ii1iI ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 9 : AUTO_UPDATER ( OoOO0oo0o )
elif I1ii11I == 10 : O0O00O000OOO ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 11 : iiIIi ( )
elif I1ii11I == 12 : OOoO000 ( o00oooO0Oo )
elif I1ii11I == 19 : Ii1iI111 ( o00oooO0Oo )
elif I1ii11I == 20 : Ii11iI ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 21 : Ii ( o00oooO0Oo )
elif I1ii11I == 22 : iiI11I1i1i1iI ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 23 : oOo0oO ( )
elif I1ii11I == 24 : o00o0 ( )
elif I1ii11I == 25 : III11I1 ( )
elif I1ii11I == 26 : oo00OoO ( )
elif I1ii11I == 30 : I1iiiiIii ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 40 : i111i11I1ii ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 41 : I1i1I ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 50 : ooOOooo0Oo ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 51 : ooo0O0OO ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 60 : oo0O0o00 ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 61 : OooOo000o0o ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 70 : I1I1I11Ii ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 71 : IIiI11i11 ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 80 : OOOo ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 90 : o0ooooO0o0O ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 91 : ooo00Ooo ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 95 : O0o0O0 ( )
elif I1ii11I == 96 : O00OoOO0oo0 ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 97 : oOOO0oo0 ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 100 : OOiI1 ( )
elif I1ii11I == 500 : iIIiI11i1I11 ( )
elif I1ii11I == 201 : oOoOO ( )
elif I1ii11I == 202 : OOOOO0O00 ( o00oooO0Oo )
elif I1ii11I == 203 : o0o0O00oo0 ( o00oooO0Oo )
elif I1ii11I == 204 : ooOOo00O00Oo ( o00oooO0Oo )
elif I1ii11I == 205 : oo000 ( o00oooO0Oo )
elif I1ii11I == 206 : ii11i ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 210 : OO0ooo0o0O0Oooooo ( o00oooO0Oo )
elif I1ii11I == 220 : i1I1iI ( o00oooO0Oo )
elif I1ii11I == 221 : IiII1II11I ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 800 : ooOO00o00 ( OoOO0oo0o , o00oooO0Oo , iiIiI )
elif I1ii11I == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 69 - 69: i1IIi11111i + i1iIIIiI1I
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if I1ii11I == 80 :
 xbmc . sleep ( 10000 )
 xbmc . executebuiltin ( 'Container.Refresh' )