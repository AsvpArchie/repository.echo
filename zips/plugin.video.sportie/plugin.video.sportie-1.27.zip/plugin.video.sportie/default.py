import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
o0oOoO00o = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
i1 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
oOOoo00O0O = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 15 - 15: I11iii11IIi
O00o0o0000o0o = plugintools . get_setting ( "scrape1" )
O0Oo = plugintools . get_setting ( "scrape2" )
oo = plugintools . get_setting ( "scrape3" )
if 33 - 33: I1I1i1 * oO0 / OOo0o0 / OOoOoo00oo - iI1 + OoOooOOOO
i11iiII = o0O + '|SPLIT|' + Oo
checker . check ( i11iiII )
if 34 - 34: oooO % ii1IiIi11 * iIii1I111I11I . O00OooO0 % Ooooo
if not os . path . isfile ( ooo0OO ) :
 plugintools . open_settings_dialog ( )
 if 55 - 55: IiIIIiI1I1
if not os . path . exists ( IiiIII111iI ) :
 os . makedirs ( IiiIII111iI )
 if 86 - 86: i11iIiiIii + ii1IiIi11 + IiIIIiI1I1 * oooO + OOo0o0
if not os . path . isfile ( iI1Ii11111iIi ) :
 oOoO = open ( iI1Ii11111iIi , 'w' )
 if 68 - 68: oO0 . iI1 . i11iIiiIii
if not os . path . isfile ( IiII ) :
 oOoO = open ( IiII , 'w' )
 if 40 - 40: iI1 . oO0 . I11iii11IIi . o00ooo0
if not os . path . isfile ( i1i1II ) :
 oOoO = open ( i1i1II , 'w' )
 if 33 - 33: ii1IiIi11 + o00 % i11iIiiIii . IiIIIiI1I1 - Oo0oO0ooo
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 66 - 66: ii1IiIi11 - I1i1iI1i * I1i1iI1i . OoOooOOOO . OOoOoo00oo
class IiI1i11iii1 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 96 - 96: o0OO0 % iI1 % Oo0ooO0oo0oO
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 78 - 78: Oo0ooO0oo0oO - ii1IiIi11 * I1I1i1 + OOo0o0 + iIii1I111I11I + iIii1I111I11I
I11I11i1I = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 49 - 49: o00 % iIii1I111I11I * o0OO0
class oOOo0oo :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 80 - 80: oooO * i11iIiiIii / Ooooo
  if 9 - 9: ii1IiIi11 + iI1 % ii1IiIi11 + o00ooo0 . OoOooOOOO
  if 31 - 31: OOo0o0 + oooO + oooO / o00
  if 26 - 26: I1i1iI1i
def IiiI11Iiiii ( ) :
 ii1I1i1I = 5
 OOoo0O0 = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 iiiIi1i1I = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 80 - 80: oO0 - I1I1i1
 OOO00 = [ ]
 if 21 - 21: I1i1iI1i - I1i1iI1i
 for iIii11I in range ( ii1I1i1I ) :
  OOO00 . append ( oOOo0oo ( OOoo0O0 [ iIii11I ] , iiiIi1i1I [ iIii11I ] ) )
  if 69 - 69: iI1 % Ooooo - OOo0o0 + Ooooo - o0OO0 % I1i1iI1i
 return OOO00
 if 31 - 31: o00 - OoOooOOOO . Ooooo % oO0 - o0OO0
def iii11 ( ) :
 if 58 - 58: OoOooOOOO * i11iIiiIii / oO0 % Ooooo - OOoOoo00oo / iI1
 ii11i1 = IIIii1II1II ( i1 )
 if len ( ii11i1 ) > 1 :
  i1I1iI = iI1Ii11111iIi
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 83 - 83: OOoOoo00oo / IiIIIiI1I1
 ii11i1 = IIIii1II1II ( o0oOoO00o )
 if len ( ii11i1 ) > 1 :
  i1I1iI = IiII
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 49 - 49: OOo0o0
 ii11i1 = IIIii1II1II ( oOOoo00O0O )
 if len ( ii11i1 ) > 1 :
  i1I1iI = i1i1II
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 35 - 35: oO0 - I1i1iI1i / OOoOoo00oo % o00ooo0
 o00OO00OoO = OOOO0OOoO0O0 ( II1 )
 o00OO00OoO = base64 . b64decode ( o00OO00OoO )
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 62 - 62: Oo0ooO0oo0oO * oO0
  if '<search>ZGlzcGxheQ==</search>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   Oo0oOOo ( i1OOO , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 58 - 58: o00 * OoOooOOOO * OOoOoo00oo / OoOooOOOO
  elif '<vip>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   Oo0oOOo ( i1OOO , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 75 - 75: iI1
  elif '<divider>bnVsbA==</divider>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( i1OOO , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 63 - 63: OoOooOOOO % iI1 * iI1 * I1I1i1 / OOoOoo00oo
   if 74 - 74: o00
   if 75 - 75: OOo0o0 . IiIIIiI1I1
   if 54 - 54: o00 % oO0 % oooO % Oo0ooO0oo0oO + Oo0ooO0oo0oO * IiIIIiI1I1
   if 87 - 87: IiIIIiI1I1 * I11iii11IIi % i11iIiiIii % oO0 - OoOooOOOO
   if 68 - 68: Ooooo % o00ooo0 . O00OooO0 . OOoOoo00oo
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   Oo0oOOo ( i1OOO , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 92 - 92: iIii1I111I11I . Ooooo
   if 31 - 31: Ooooo . oO0 / o0OO0
   if 89 - 89: oO0
   if 68 - 68: I1I1i1 * I1i1iI1i % o0OO0 + I1I1i1 + IiIIIiI1I1
   if 4 - 4: IiIIIiI1I1 + o0OO0 * OoOooOOOO
   if 55 - 55: I11iii11IIi + Oo0ooO0oo0oO / oO0 * iI1 - i11iIiiIii - ii1IiIi11
   if 25 - 25: OOoOoo00oo
   if 7 - 7: o00ooo0 / Oo0oO0ooo * Ooooo . O00OooO0 . Oo0ooO0oo0oO
   if 13 - 13: OoOooOOOO / i11iIiiIii
   if 2 - 2: Oo0oO0ooo / o0OO0 / OOo0o0 % oO0 % ii1IiIi11
   if 52 - 52: OOo0o0
   if 95 - 95: ii1IiIi11
   if 87 - 87: IiIIIiI1I1 + oO0 . OoOooOOOO + oO0
   if 91 - 91: o0OO0
   if 61 - 61: o00
   if 64 - 64: IiIIIiI1I1 / oO0 - o0OO0 - oooO
   if 86 - 86: oooO % oO0 / Oo0oO0ooo / oO0
   if 42 - 42: I1I1i1
   if 67 - 67: Ooooo . iIii1I111I11I . o0OO0
   if 10 - 10: OOoOoo00oo % OOoOoo00oo - Oo0ooO0oo0oO / OoOooOOOO + ii1IiIi11
   if 87 - 87: iI1 * OOoOoo00oo + OoOooOOOO / Oo0ooO0oo0oO / iIii1I111I11I
   if 37 - 37: iIii1I111I11I - IiIIIiI1I1 * iI1 % i11iIiiIii - Ooooo
  elif '<sportsdevil>' in oO0Ii1iIiII1ii1 :
   o0oO = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1IiiiI1iI = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1iIi = re . compile ( '<referer>(.+?)</referer>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = base64 . b64decode ( i1OOO )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    i1IiiiI1iI = base64 . b64decode ( i1IiiiI1iI )
    i1iIi = base64 . b64decode ( i1iIi )
    ooOOoooooo = i1iIi
    II1I = "/"
    if not ooOOoooooo . endswith ( II1I ) :
     O0 = ooOOoooooo + "/"
    else :
     O0 = ooOOoooooo
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( i1OOO ) + '%26url=' + i1IiiiI1iI
    i1IiiiI1iI = o00OO00OoO + '%26referer=' + O0
    I1III ( i1OOO , i1IiiiI1iI , 4 , IIiIi1iI , i1II1Iiii1I11 )
   elif len ( o0oO ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = base64 . b64decode ( i1OOO )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    I1III ( i1OOO , url2 + 'NOTPLAY' , 8 , IIiIi1iI , i1II1Iiii1I11 )
    if 9 - 9: OOoOoo00oo / I11iii11IIi - Oo0oO0ooo / I1i1iI1i / Oo0ooO0oo0oO - OOo0o0
  elif '<folder>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for i1OOO , i1IiiiI1iI , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    i1OOO = base64 . b64decode ( i1OOO )
    i1IiiiI1iI = base64 . b64decode ( i1IiiiI1iI )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
    Oo0oOOo ( i1OOO , i1IiiiI1iI , 1 , IIiIi1iI , i1II1Iiii1I11 )
  elif '<m3u>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for i1OOO , i1IiiiI1iI , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    i1OOO = base64 . b64decode ( i1OOO )
    i1IiiiI1iI = base64 . b64decode ( i1IiiiI1iI )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
    Oo0oOOo ( i1OOO , i1IiiiI1iI , 10 , IIiIi1iI , i1II1Iiii1I11 )
  else :
   o0oO = re . compile ( '<link>(.+?)</link>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
    o0O0OOO0Ooo = len ( O0Oo000ooO00 )
    for i1OOO , i1IiiiI1iI , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
     i1OOO = base64 . b64decode ( i1OOO )
     i1IiiiI1iI = base64 . b64decode ( i1IiiiI1iI )
     IIiIi1iI = base64 . b64decode ( IIiIi1iI )
     i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
     I1III ( i1OOO , i1IiiiI1iI , 2 , IIiIi1iI , i1II1Iiii1I11 )
   elif len ( o0oO ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = base64 . b64decode ( i1OOO )
    IIiIi1iI = base64 . b64decode ( IIiIi1iI )
    i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
    I1III ( i1OOO , II1 , 3 , IIiIi1iI , i1II1Iiii1I11 )
    if 45 - 45: o0OO0 / OOo0o0
 i1IIIII11I1IiI = open ( IIi1IiiiI1Ii ) . read ( )
 i1I = i1IIIII11I1IiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0Oo000ooO00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( i1I ) )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  OoOO = float ( oO0Ii1iIiII1ii1 )
 i1IIIII11I1IiI = open ( I11i11Ii ) . read ( )
 i1I = i1IIIII11I1IiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0Oo000ooO00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( i1I ) )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  ooOOO0 = float ( oO0Ii1iIiII1ii1 )
  if 65 - 65: o0OO0
 I1III ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( OoOO ) + "[/COLOR]" , 'url' , 999 , iiiii , i1II1Iiii1I11 , '' )
 I1III ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( ooOOO0 ) + "[/COLOR]" , 'url' , 999 , iiiii , i1II1Iiii1I11 , '' )
 if 68 - 68: OoOooOOOO % Ooooo
 ooO00OO0 = i11111IIIII ( )
 if 19 - 19: oO0 * o00ooo0
 if ooO00OO0 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif ooO00OO0 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 14 - 14: iIii1I111I11I
def I1iI1iIi111i ( name , url ) :
 if 44 - 44: o00ooo0 % o00 + oooO
 hash = [ ]
 I1I1I = url
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 if 95 - 95: o00 + OOo0o0 + iIii1I111I11I * Oo0ooO0oo0oO % iI1 / O00OooO0
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 56 - 56: iIii1I111I11I
  if '<search>' in oO0Ii1iIiII1ii1 :
   if 86 - 86: o00 % Ooooo
   o0oO = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    url = name + "!" + url + "!" + IIiIi1iI
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    Oo0oOOo ( name , url , 20 , IIiIi1iI , IIiIi1iI )
    if 15 - 15: o00ooo0 * Oo0oO0ooo + i11iIiiIii
   elif len ( o0oO ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    url = I1I1I + "!" + name + "!" + IIiIi1iI
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    Oo0oOOo ( name , url , 22 , IIiIi1iI , IIiIi1iI )
    if 6 - 6: IiIIIiI1I1 / i11iIiiIii + iIii1I111I11I * iI1
  elif '<regex>' in oO0Ii1iIiII1ii1 :
   o00o0 = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( oO0Ii1iIiII1ii1 )
   o00o0 = '' . join ( o00o0 )
   ii = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( o00o0 )
   o00o0 = urllib . quote_plus ( o00o0 )
   if 84 - 84: OOo0o0 % o00 . i11iIiiIii / I1I1i1
   o0OIiII = hashlib . md5 ( )
   for ii1iII1II in o00o0 : o0OIiII . update ( str ( ii1iII1II ) )
   o0OIiII = str ( o0OIiII . hexdigest ( ) )
   if 48 - 48: o00 * ii1IiIi11 . oooO + iI1
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   oO0Ii1iIiII1ii1 = re . sub ( '<regex>.+?</regex>' , '' , oO0Ii1iIiII1ii1 )
   oO0Ii1iIiII1ii1 = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , oO0Ii1iIiII1ii1 )
   oO0Ii1iIiII1ii1 = re . sub ( '<link></link>' , '' , oO0Ii1iIiII1ii1 )
   if 78 - 78: i11iIiiIii / iIii1I111I11I - ii1IiIi11 / OoOooOOOO + iI1
   name = re . sub ( '<meta>.+?</meta>' , '' , oO0Ii1iIiII1ii1 )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 82 - 82: ii1IiIi11
   try : iiI1Ii1iI1 = re . findall ( '<date>(.+?)</date>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : iiI1Ii1iI1 = ''
   if re . search ( r'\d+' , iiI1Ii1iI1 ) : name += ' [COLOR red] Updated %s[/COLOR]' % iiI1Ii1iI1
   if 87 - 87: I11iii11IIi . O00OooO0
   try : O0OO0O = re . findall ( '<thumbnail>(.+?)</thumbnail>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : O0OO0O = iiiii
   if 81 - 81: iI1 . OOo0o0 % o0OO0 / Oo0oO0ooo - iI1
   try : Ii1I1i = re . findall ( '<fanart>(.+?)</fanart>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : Ii1I1i = O0O0OO0O0O0
   if 99 - 99: iI1 . iIii1I111I11I + IiIIIiI1I1 % iI1 . i11iIiiIii % o0OO0
   try : oOO00O = re . findall ( '<meta>(.+?)</meta>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : oOO00O = '0'
   if 77 - 77: I11iii11IIi - o00ooo0 - oooO . oO0
   try : url = re . findall ( '<link>(.+?)</link>' , oO0Ii1iIiII1ii1 ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % oOO00O )
   url = '<preset>search</preset>%s' % oOO00O if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % oOO00O )
   url = '<preset>searchsd</preset>%s' % oOO00O if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 39 - 39: o00 / IiIIIiI1I1 + Ooooo / oO0
   if not o00o0 == '' :
    hash . append ( { 'regex' : o0OIiII , 'response' : o00o0 } )
    url += '|regex=%s' % o00o0
    if 13 - 13: O00OooO0 + o0OO0 + iIii1I111I11I % Oo0oO0ooo / OOo0o0 . O00OooO0
   I1III ( name , url , 30 , O0OO0O , Ii1I1i )
   if 86 - 86: iI1 * OOo0o0 % o00ooo0 . ii1IiIi11 . i11iIiiIii
  elif '<sportsdevil>' in oO0Ii1iIiII1ii1 :
   o0oO = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     i1iIi = re . compile ( '<referer>(.+?)</referer>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : i1iIi = "None"
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : i1II1Iiii1I11 = O0O0OO0O0O0
    ooOOoooooo = i1iIi
    II1I = "/"
    if not ooOOoooooo . endswith ( II1I ) :
     O0 = ooOOoooooo + "/"
    else :
     O0 = ooOOoooooo
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = o00OO00OoO + '%26referer=' + O0
    I1III ( name , url , 2 , IIiIi1iI , i1II1Iiii1I11 )
    if 56 - 56: OOoOoo00oo % o0OO0 - Oo0oO0ooo
   elif len ( o0oO ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : i1II1Iiii1I11 = O0O0OO0O0O0
    I1III ( name , I1I1I + 'NOTPLAY' , 8 , IIiIi1iI , i1II1Iiii1I11 )
    if 100 - 100: ii1IiIi11 - o0OO0 % iI1 * OoOooOOOO + Oo0oO0ooo
  elif '<rutubeplaylist>' in oO0Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   try :
    i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   except : i1II1Iiii1I11 = O0O0OO0O0O0
   Oo0oOOo ( name , I1I1I , 90 , IIiIi1iI , i1II1Iiii1I11 )
   if 88 - 88: I1i1iI1i - I1I1i1 * o0OO0 * I1i1iI1i . I1i1iI1i
  elif '<folder>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for name , url , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    Oo0oOOo ( name , url , 1 , IIiIi1iI , i1II1Iiii1I11 )
    if 33 - 33: Ooooo + iIii1I111I11I * iI1 / Oo0ooO0oo0oO - Oo0oO0ooo
  elif '<m3u>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for name , url , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    Oo0oOOo ( name , url , 10 , IIiIi1iI , i1II1Iiii1I11 )
    if 54 - 54: Ooooo / OoOooOOOO . iI1 % iIii1I111I11I
  elif '<rutube>' in oO0Ii1iIiII1ii1 :
   o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?rutube>(.+?)</rutube>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
   for name , url , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
    I1I1I = 'https://rutube.ru/play/embed/' + url + '?wmode=opaque&fakeFullscreen=1'
    Oo0oOOo ( name , I1I1I , 2 , IIiIi1iI , i1II1Iiii1I11 )
  else :
   o0oO = re . compile ( '<link>(.+?)</link>' ) . findall ( oO0Ii1iIiII1ii1 )
   if len ( o0oO ) == 1 :
    o00oooO0Oo = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 )
    o0O0OOO0Ooo = len ( O0Oo000ooO00 )
    for name , url , IIiIi1iI , i1II1Iiii1I11 in o00oooO0Oo :
     I1III ( name , url , 2 , IIiIi1iI , i1II1Iiii1I11 )
   elif len ( o0oO ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : i1II1Iiii1I11 = O0O0OO0O0O0
    I1III ( name , I1I1I , 3 , IIiIi1iI , i1II1Iiii1I11 )
    if 57 - 57: i11iIiiIii . OOoOoo00oo - ii1IiIi11 - iI1 + oO0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 63 - 63: oO0 * iIii1I111I11I
def ooiIi1 ( name , url , iconimage ) :
 OoOOoOooooOOo = [ ]
 oOo0O = [ ]
 oo0O0 = [ ]
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iI = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iI ) [ 0 ]
 o0oO = re . compile ( '<link>(.+?)</link>' ) . findall ( iI )
 ii1iII1II = 1
 for OO0O000 in o0oO :
  iiIiI1i1 = OO0O000
  if '(' in OO0O000 :
   OO0O000 = OO0O000 . split ( '(' ) [ 0 ]
   oO0O00oOOoooO = str ( iiIiI1i1 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   OoOOoOooooOOo . append ( OO0O000 )
   oOo0O . append ( oO0O00oOOoooO )
  else :
   OoOOoOooooOOo . append ( OO0O000 )
   oOo0O . append ( 'Link ' + str ( ii1iII1II ) )
  ii1iII1II = ii1iII1II + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 IiIi11iI = O00ooooo00 . select ( name , oOo0O )
 if IiIi11iI < 0 :
  quit ( )
 else :
  url = OoOOoOooooOOo [ IiIi11iI ]
  print url
  if 83 - 83: o00 % I11iii11IIi % IiIIIiI1I1 % OOoOoo00oo
 url = OoOOoOooooOOo [ IiIi11iI ]
 name = oOo0O [ IiIi11iI ]
 OoO000O0Oo ( name , url , iiiii )
 if 63 - 63: Oo0ooO0oo0oO * i11iIiiIii % Oo0ooO0oo0oO * i11iIiiIii
def iI1111iiii ( name , url , iconimage ) :
 if 67 - 67: I1i1iI1i / Oo0oO0ooo * ii1IiIi11 + oooO
 OoOOoOooooOOo = [ ]
 oOo0O = [ ]
 oo0O0 = [ ]
 OooOo0ooo = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iI = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 o0oO = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iI )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iI ) [ 0 ]
 if 71 - 71: Ooooo + ii1IiIi11
 iI1111ii1I = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 45 - 45: o00ooo0 + OOo0o0
 ii1iII1II = 1
 if 94 - 94: iI1 . o00ooo0 - OOo0o0 % o0OO0 - I1I1i1
 for OO0O000 in o0oO :
  iiIiI1i1 = OO0O000
  if '(' in OO0O000 :
   OO0O000 = OO0O000 . split ( '(' ) [ 0 ]
   oO0O00oOOoooO = str ( iiIiI1i1 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   OoOOoOooooOOo . append ( OO0O000 )
   oOo0O . append ( oO0O00oOOoooO )
   OooOo0ooo . append ( 'Stream ' + str ( ii1iII1II ) )
  else :
   OoOOoOooooOOo . append ( OO0O000 )
   oOo0O . append ( 'Link ' + str ( ii1iII1II ) )
   if 72 - 72: ii1IiIi11
  ii1iII1II = ii1iII1II + 1
  if 1 - 1: I1I1i1 * O00OooO0 * I1i1iI1i + IiIIIiI1I1
 name = '[COLOR red]' + name + '[/COLOR]'
 if 33 - 33: o0OO0 * OOo0o0 - Ooooo % Ooooo
 O00ooooo00 = xbmcgui . Dialog ( )
 IiIi11iI = O00ooooo00 . select ( name , oOo0O )
 if IiIi11iI < 0 :
  quit ( )
 else :
  ooOOoooooo = oOo0O [ IiIi11iI ]
  II1I = "/"
  if not ooOOoooooo . endswith ( II1I ) :
   O0 = ooOOoooooo + "/"
  else :
   O0 = ooOOoooooo
  url = iI1111ii1I + OoOOoOooooOOo [ IiIi11iI ] + "%26referer=" + O0
  if 18 - 18: Ooooo / I11iii11IIi * Ooooo + Ooooo * i11iIiiIii * OOoOoo00oo
 name = oOo0O [ IiIi11iI ]
 OoO000O0Oo ( name , url , iiiii )
 if 11 - 11: IiIIIiI1I1 / oO0 - O00OooO0 * I1i1iI1i + I1i1iI1i . oO0
def i1I1i111Ii ( name , url , iconimage ) :
 if 67 - 67: Oo0oO0ooo . o00ooo0
 i1i1iI1iiiI = [ ]
 Ooo0oOooo0 = [ ]
 if 61 - 61: oO0 - OoOooOOOO - o00ooo0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iI = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 o0oO = re . compile ( '<rutubeplaylist>(.+?)</rutubeplaylist>' ) . findall ( iI )
 if 25 - 25: o0OO0 * oooO + OOoOoo00oo . OOo0o0 . OOo0o0
 for OO0O000 in o0oO :
  iiIiI1i1 = OO0O000
  if '(' in OO0O000 :
   OO0O000 = OO0O000 . split ( '(' ) [ 0 ]
   oO0O00oOOoooO = str ( iiIiI1i1 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   i1i1iI1iiiI . append ( oO0O00oOOoooO )
   Ooo0oOooo0 . append ( OO0O000 )
   oOooO = list ( zip ( i1i1iI1iiiI , Ooo0oOooo0 ) )
   if 10 - 10: oO0 % oO0 - oO0 . iIii1I111I11I
 o0OoOo00o0o = sorted ( oOooO )
 if 41 - 41: IiIIIiI1I1 % I1I1i1 - I11iii11IIi * Ooooo * I11iii11IIi
 for OOOoOO0o , url in o0OoOo00o0o :
  i1II1 = OOOO0OOoO0O0 ( url )
  O0Oo000ooO00 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   i11i1 = re . compile ( 'title="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
   if OOOoOO0o . lower ( ) in i11i1 . lower ( ) :
    i11i1 = i11i1 . replace ( '.' , ' ' )
    I1III ( i11i1 , url , 2 , iconimage , iconimage , '' )
    if 42 - 42: i11iIiiIii * Oo0ooO0oo0oO / OOoOoo00oo . i11iIiiIii % oooO
 try :
  O0Oo000ooO00 = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( i1II1 )
  i1iI = str ( O0Oo000ooO00 )
  IiI1iiiIii = re . compile ( 'href="(.+?)"' ) . findall ( i1iI ) [ 1 ]
  url = IiI1iiiIii + "|SPLIT|" + OOOoOO0o
  Oo0oOOo ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 7 - 7: Ooooo * I1I1i1 - IiIIIiI1I1 + OoOooOOOO * Oo0oO0ooo % I1I1i1
def iI1i111I1Ii ( name , url , iconimage ) :
 if 25 - 25: Ooooo - iIii1I111I11I
 url , OOOoOO0o = url . split ( "|SPLIT|" )
 if 10 - 10: o00 / iI1 % I1i1iI1i * oooO % OOoOoo00oo
 i1II1 = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( i1II1 )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  i11i1 = re . compile ( 'title="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
  if OOOoOO0o . lower ( ) in i11i1 . lower ( ) :
   i11i1 = i11i1 . replace ( '.' , ' ' )
   I1III ( i11i1 , url , 2 , iconimage , iconimage , '' )
   if 48 - 48: IiIIIiI1I1 / Ooooo . Oo0ooO0oo0oO * oO0 * iI1 / o00ooo0
 try :
  O0Oo000ooO00 = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( i1II1 )
  i1iI = str ( O0Oo000ooO00 )
  IiI1iiiIii = re . compile ( 'href="(.+?)"' ) . findall ( i1iI ) [ 1 ]
  url = IiI1iiiIii + "|SPLIT|" + OOOoOO0o
  Oo0oOOo ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 92 - 92: I11iii11IIi % I11iii11IIi - OOo0o0 / oO0
def I11IIIi ( name , url , iconimage ) :
 if 15 - 15: OOoOoo00oo * I1I1i1
 oo0OooOOo0 , iIii11I = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 oo0OooOOo0 += urllib . unquote_plus ( iIii11I )
 url = regex . resolve ( oo0OooOOo0 )
 if 16 - 16: iIii1I111I11I + oO0
 OoO000O0Oo ( name , url , iconimage )
 if 66 - 66: iIii1I111I11I / iI1 * I1i1iI1i + I1i1iI1i % oooO
def IIii1111 ( ) :
 if 42 - 42: oooO / OOo0o0 . iI1 + iI1 % oO0 + i11iIiiIii
 I1III ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 I1III ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 I1III ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 Oo0oOOo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 Oo0oOOo ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 56 - 56: OOo0o0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 28 - 28: iIii1I111I11I . iIii1I111I11I % Oo0ooO0oo0oO * Oo0ooO0oo0oO . OOo0o0 / iIii1I111I11I
def iII1i1 ( ) :
 if 85 - 85: ii1IiIi11 * I11iii11IIi . o0OO0 - i11iIiiIii
 Oo0oOOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 18 - 18: ii1IiIi11 + O00OooO0 - o0OO0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 53 - 53: o00ooo0
def Ooo00Oo ( ) :
 if 93 - 93: OOoOoo00oo * ii1IiIi11
 Oo0oOOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 72 - 72: I1i1iI1i . iIii1I111I11I / I11iii11IIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 90 - 90: Oo0ooO0oo0oO % IiIIIiI1I1
def OoO0O00O0oo0O ( ) :
 if 36 - 36: OoOooOOOO + o0OO0 - ii1IiIi11 - o0OO0 % oooO . iI1
 ii1iII1II = 0
 i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  ii1iII1II = ii1iII1II + 1
  oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1IiiiI1iI = oO0Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ii1iII1II ) + '[/COLOR]' , i1IiiiI1iI , 12 , iiiii , O0O0OO0O0O0 )
  if 74 - 74: i11iIiiIii . Oo0oO0ooo
 i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  ii1iII1II = ii1iII1II + 1
  oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1IiiiI1iI = oO0Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ii1iII1II ) + '[/COLOR]' , i1IiiiI1iI , 12 , iiiii , O0O0OO0O0O0 )
  if 36 - 36: I1i1iI1i . I1I1i1
 i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  ii1iII1II = ii1iII1II + 1
  oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1IiiiI1iI = oO0Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ii1iII1II ) + '[/COLOR]' , i1IiiiI1iI , 12 , iiiii , O0O0OO0O0O0 )
  if 56 - 56: I11iii11IIi . OOoOoo00oo . Oo0oO0ooo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 39 - 39: o0OO0 + Ooooo
def OoOooOoO ( url ) :
 if 43 - 43: o00 . iI1 / OOoOoo00oo
 i1II1 = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
 if 20 - 20: Oo0oO0ooo
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  IIiIi1iI = re . compile ( '<img.+?src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , IIiIi1iI , O0O0OO0O0O0 )
  if 95 - 95: iIii1I111I11I - Oo0oO0ooo
 try :
  I1ii1ii11i1I = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( i1II1 ) [ 0 ]
  Oo0oOOo ( '[COLOR yellow]Next Page -->[/COLOR]' , I1ii1ii11i1I , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 58 - 58: iIii1I111I11I + I11iii11IIi
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 12 - 12: OOo0o0 - OOoOoo00oo % oO0 * oooO
def i11IIIiI11 ( url ) :
 if 8 - 8: I1I1i1 + Ooooo - OOo0o0 % I11iii11IIi % OOo0o0 * iI1
 i1II1 = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( i1II1 )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  try :
   i1OOO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except :
   i1OOO = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 9 - 9: I11iii11IIi - i11iIiiIii - OoOooOOOO * ii1IiIi11 + IiIIIiI1I1
def iIIII ( url ) :
 if 45 - 45: OOoOoo00oo % Oo0oO0ooo - i11iIiiIii
 i1II1 = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( i1II1 )
 ii1iiIiIII1ii = 0
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  try :
   i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<img.+?src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except : ii1iiIiIII1ii = 1
  if 82 - 82: iIii1I111I11I
  if ii1iiIiIII1ii == 0 :
   Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , IIiIi1iI , O0O0OO0O0O0 )
  ii1iiIiIII1ii = 0
  if 65 - 65: IiIIIiI1I1 . I1i1iI1i / OOoOoo00oo . o00ooo0 * I1I1i1
 try :
  I1ii1ii11i1I = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( i1II1 ) [ 0 ]
  Oo0oOOo ( '[COLOR yellow]Next Page -->[/COLOR]' , I1ii1ii11i1I , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 19 - 19: i11iIiiIii + I1i1iI1i - I11iii11IIi - oooO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 21 - 21: o0OO0 % O00OooO0 . Oo0oO0ooo / o00 + O00OooO0
def OOOO0O00o ( url ) :
 if 62 - 62: Oo0ooO0oo0oO
 i1II = datetime . date . today ( )
 iI1I = datetime . datetime . strftime ( i1II , '%A %d %B %Y' )
 if 100 - 100: Oo0ooO0oo0oO + oO0 / I11iii11IIi . i11iIiiIii
 I1III ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iI1I ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 14 - 14: OOo0o0 * OoOooOOOO + iIii1I111I11I + o0OO0 + i11iIiiIii
 i1II1 = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( i1II1 )
 ii1iiIiIII1ii = 0
 ii1iII1II = 0
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  try :
   i11i1 = re . compile ( 'title="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   try :
    oOoO0 = re . compile ( '<p>(.+?)</p>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   except : oOoO0 = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<img src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except : ii1iiIiIII1ii = 1
  if 77 - 77: Oo0ooO0oo0oO . iIii1I111I11I % iIii1I111I11I + i11iIiiIii
  if ii1iiIiIII1ii == 0 :
   if 'vs' in i11i1 :
    i1OOO = '[COLOR dodgerblue]' + i11i1 + ' - ' + '[/COLOR][COLOR green]' + oOoO0 + '[/COLOR]'
    ii1iII1II = ii1iII1II + 1
    I1III ( i1OOO , url , 206 , IIiIi1iI , O0O0OO0O0O0 , '' )
  ii1iiIiIII1ii = 0
  if 72 - 72: Oo0ooO0oo0oO * ii1IiIi11 % IiIIIiI1I1 / I1I1i1
 if ii1iII1II == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 35 - 35: IiIIIiI1I1 + o00ooo0 % OOoOoo00oo % oooO + iI1
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 17 - 17: o00ooo0
def iiIi1i ( name , url , iconimage ) :
 if 27 - 27: OoOooOOOO * IiIIIiI1I1 . Ooooo % O00OooO0 * O00OooO0 . o00ooo0
 i1II1 = OOOO0OOoO0O0 ( url )
 O0OOoOOO0oO = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( i1II1 ) [ 0 ]
 if 28 - 28: IiIIIiI1I1 + i11iIiiIii / oooO % oO0 % I11iii11IIi - o0OO0
 if not "http" in O0OOoOOO0oO :
  O0OOoOOO0oO = O0OOoOOO0oO . replace ( "//" , "" )
  url = "http://" + O0OOoOOO0oO
 else :
  url = O0OOoOOO0oO
  if 54 - 54: o00ooo0 + o00
 oOOO0oo0 = url
 if 46 - 46: O00OooO0
 ii1iIi1iIiI1i = OOOO0OOoO0O0 ( url )
 O0OOoOOO0oO = re . compile ( "atob(.+?)," ) . findall ( ii1iIi1iIiI1i ) [ 0 ]
 O0OOoOOO0oO = O0OOoOOO0oO . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( O0OOoOOO0oO )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + oOOO0oo0 + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 OoO000O0Oo ( name , url , iconimage )
 if 40 - 40: o00ooo0 % OoOooOOOO
def ooo0o00 ( url ) :
 if 99 - 99: o0OO0 . oooO + Oo0ooO0oo0oO
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 32 - 32: ii1IiIi11 . Oo0ooO0oo0oO % Oo0ooO0oo0oO * i11iIiiIii - I1I1i1 - oooO
  if '<display>eWVz</display>' in oO0Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1II1Iiii1I11 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   url = base64 . b64decode ( url )
   IIiIi1iI = base64 . b64decode ( IIiIi1iI )
   i1II1Iiii1I11 = base64 . b64decode ( i1II1Iiii1I11 )
   Oo0oOOo ( i1OOO , url , 220 , IIiIi1iI , i1II1Iiii1I11 , '' )
   if 63 - 63: I1I1i1
def Oo0 ( url ) :
 if 59 - 59: Oo0oO0ooo * o00 . o0OO0
 i1II1 = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( i1II1 )
 if 56 - 56: ii1IiIi11 - iIii1I111I11I % Oo0oO0ooo - OOo0o0
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  i1OOO = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  try :
   Oo00O = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except : Oo00O = "SD"
  Oo00O = '[COLOR yellow]' + Oo00O + '[/COLOR]'
  IIiIi1iI = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  i1OOO = i1OOO . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 12 - 12: OOo0o0 - IiIIIiI1I1 * Ooooo
  I1III ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR] - ' + Oo00O , url , 212 , IIiIi1iI , O0O0OO0O0O0 , '' )
  if 14 - 14: I11iii11IIi - ii1IiIi11 % ii1IiIi11 * o0OO0 . i11iIiiIii / o0OO0
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( i1II1 ) [ 0 ]
  IiI1iiiIii = 'http://www.fmovies.se/' + url
  Oo0oOOo ( "Next Page -->" , IiI1iiiIii , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 79 - 79: OOo0o0 - oooO + OOo0o0 . iI1
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 28 - 28: o00ooo0 - iIii1I111I11I
def o00o000oo ( url ) :
 if 44 - 44: Oo0oO0ooo - oooO % Oo0ooO0oo0oO
 i1II1 = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( i1II1 )
 if 71 - 71: IiIIIiI1I1 . ii1IiIi11 - I1i1iI1i % ii1IiIi11 . o00
 if 89 - 89: iIii1I111I11I . o0OO0 / OOoOoo00oo % oO0 . I11iii11IIi
def IiiI1i ( url ) :
 if 51 - 51: O00OooO0
 if "iptvembed" in url :
  i1II1 = OOOO0OOoO0O0 ( url )
  O0Oo000ooO00 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = oO0Ii1iIiII1ii1
   if 25 - 25: I1i1iI1i + O00OooO0 * OOoOoo00oo
 if "sourcetv" in url :
  i1II1 = OOOO0OOoO0O0 ( url )
  O0Oo000ooO00 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = oO0Ii1iIiII1ii1
   if 92 - 92: Oo0oO0ooo + oooO + o0OO0 / OOo0o0 + Ooooo
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 I1i11ii = [ ]
 for i111iI , OOo , url in I1iIi1iIiiIiI :
  i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : url }
  I1i11ii . append ( i1i11I1I1iii1 )
 list = [ ]
 for I1iii11 in I1i11ii :
  i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
  I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
  for ooo0O , iII1iii in I1iIi1iIiiIiI :
   i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
  list . append ( i1i11I1I1iii1 )
  if 12 - 12: OoOooOOOO
 O0iII1 = 0
 for I1iii11 in list :
  O0iII1 = 1
  i1OOO = II ( I1iii11 [ "display_name" ] )
  url = II ( I1iii11 [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   I1III ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   Oo0oOOo ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 46 - 46: oO0 / Oo0ooO0oo0oO % iIii1I111I11I . Oo0ooO0oo0oO * iIii1I111I11I
 if O0iII1 == 0 :
  I1III ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 38 - 38: OOoOoo00oo - iIii1I111I11I / o0OO0 . Ooooo
def i1iiIiI1Ii1i ( url ) :
 if 22 - 22: O00OooO0 / i11iIiiIii
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I1I1I = url
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 62 - 62: I1I1i1 / OOoOoo00oo
  o0oO = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 )
  if len ( o0oO ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + IIiIi1iI
   i1OOO = '[COLOR mediumpurple]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 20 , IIiIi1iI , IIiIi1iI )
   if 7 - 7: I1i1iI1i . O00OooO0
  elif len ( o0oO ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = I1I1I + "!" + i1OOO + "!" + IIiIi1iI
   i1OOO = '[COLOR mediumpurple]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 22 , IIiIi1iI , IIiIi1iI )
   if 53 - 53: ii1IiIi11 % ii1IiIi11 * OOo0o0 + oO0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 92 - 92: I1i1iI1i + o00ooo0 / ii1IiIi11 * o0OO0
def O00oOo00o0o ( url ) :
 if 85 - 85: iIii1I111I11I + I1i1iI1i * iIii1I111I11I - Ooooo % i11iIiiIii
 i1II = datetime . date . today ( )
 iI1I = datetime . datetime . strftime ( i1II , '%A %d %B %Y' )
 if 71 - 71: OOoOoo00oo - IiIIIiI1I1 / oO0 * oO0 / o00ooo0 . o00ooo0
 I1III ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iI1I ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 53 - 53: Ooooo
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 I1I1I = url
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 21 - 21: oooO
  o0oO = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 )
  if len ( o0oO ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + IIiIi1iI
   i1OOO = '[COLOR mediumpurple]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 20 , IIiIi1iI , IIiIi1iI )
   if 92 - 92: i11iIiiIii / Ooooo - iIii1I111I11I % IiIIIiI1I1 * Ooooo + I11iii11IIi
  elif len ( o0oO ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IIiIi1iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   url = I1I1I + "!" + i1OOO + "!" + IIiIi1iI
   i1OOO = '[COLOR mediumpurple]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 22 , IIiIi1iI , IIiIi1iI )
   if 11 - 11: I1i1iI1i . Ooooo
def Oo0000oOo ( ) :
 if 31 - 31: oooO . Ooooo * IiIIIiI1I1 + i11iIiiIii * iI1
 i1II = datetime . date . today ( )
 iI1I = datetime . datetime . strftime ( i1II , '%A %d %B %Y' )
 if 93 - 93: OOoOoo00oo / Oo0ooO0oo0oO * o00ooo0 % I1i1iI1i * o0OO0 * oooO
 I1III ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iI1I ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 I1III ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 64 - 64: o00 + o0OO0 / Oo0ooO0oo0oO / I11iii11IIi . IiIIIiI1I1 % O00OooO0
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 O0Oo000ooO00 = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( o00OO00OoO )
 i1iI = str ( O0Oo000ooO00 )
 iiI1I1ii = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( i1iI )
 for oO0Ii1iIiII1ii1 in iiI1I1ii :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in oO0Ii1iIiII1ii1 :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i11i1 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    IIiIi1iI = re . compile ( 'src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     o0ooO = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
     o0ooO = OoOOOo0o0ooo ( o0ooO )
    except : o0ooO = "null"
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + i11i1 + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    i1OOO = I1iiiiI1iI ( i1OOO )
    i1IiiiI1iI = i11i1 + "!" + o0ooO . lower ( ) + "!" + IIiIi1iI
    Oo0oOOo ( i1OOO , i1IiiiI1iI , 20 , IIiIi1iI , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i11i1 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    try :
     o0ooO = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    except : o0ooO = "null"
    IIiIi1iI = re . compile ( 'src="(.+?)"' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + i11i1 + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    i1OOO = I1iiiiI1iI ( i1OOO )
    i1IiiiI1iI = i11i1 + "!" + o0ooO . lower ( ) + "!" + IIiIi1iI
    Oo0oOOo ( i1OOO , i1IiiiI1iI , 20 , IIiIi1iI , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 43 - 43: iI1 - I1i1iI1i
def ii1iI ( name , url , iconimage ) :
 if 49 - 49: OOo0o0 . O00OooO0 / I1I1i1 + o00
 try :
  url , ii11i , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 35 - 35: OOoOoo00oo * iIii1I111I11I - I1I1i1 % OOo0o0
 oOo00O000Oo0 = [ ]
 if 18 - 18: iIii1I111I11I * I1I1i1 . I1I1i1 * iI1 * o00 * Ooooo
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iI = re . compile ( '<title>' + re . escape ( ii11i ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iI ) [ 0 ]
 o0oO = re . compile ( '<search>(.+?)</search>' ) . findall ( iI )
 for OO0O000 in o0oO :
  oOo00O000Oo0 . append ( OO0O000 )
  if 92 - 92: I11iii11IIi
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 40 - 40: oO0 / O00OooO0
 OOOoO000 = 0
 if 57 - 57: o00
 oOOOoo = [ ]
 Ii1ii111i1 = [ ]
 i1i1i1I = [ ]
 I1IiiI . update ( 0 )
 oOoo000 = 0
 if 87 - 87: I1i1iI1i - OOo0o0 / O00OooO0 . i11iIiiIii * I1i1iI1i
 if O00o0o0000o0o == "true" :
  oOoo000 = 1
  i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if OOOoO000 < 100 :
    I1IiiI . update ( OOOoO000 )
    OOOoO000 = OOOoO000 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1i11ii = [ ]
   for i111iI , OOo , url in I1iIi1iIiiIiI :
    i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : url }
    I1i11ii . append ( i1i11I1I1iii1 )
   OO00 = [ ]
   for I1iii11 in I1i11ii :
    i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
    I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
    for ooo0O , iII1iii in I1iIi1iIiiIiI :
     i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
    OO00 . append ( i1i11I1I1iii1 )
    if 28 - 28: iI1 - i11iIiiIii . OOoOoo00oo + O00OooO0 / OOoOoo00oo
   for I1iii11 in OO00 :
    name = II ( I1iii11 [ "display_name" ] )
    url = II ( I1iii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOOoo . append ( name )
    Ii1ii111i1 . append ( url )
    if "hd" in name . lower ( ) :
     i1i1i1I . append ( "1" )
    else :
     i1i1i1I . append ( "0" )
    oOooO = list ( zip ( i1i1i1I , oOOOoo , Ii1ii111i1 ) )
    if 35 - 35: O00OooO0
 if O0Oo == "true" :
  oOoo000 = 1
  i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if OOOoO000 < 100 :
    I1IiiI . update ( OOOoO000 )
    OOOoO000 = OOOoO000 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1i11ii = [ ]
   for i111iI , OOo , url in I1iIi1iIiiIiI :
    i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : url }
    I1i11ii . append ( i1i11I1I1iii1 )
   OO00 = [ ]
   for I1iii11 in I1i11ii :
    i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
    I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
    for ooo0O , iII1iii in I1iIi1iIiiIiI :
     i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
    OO00 . append ( i1i11I1I1iii1 )
    if 75 - 75: I11iii11IIi / OOoOoo00oo . O00OooO0 * OoOooOOOO - o00
   for I1iii11 in OO00 :
    name = II ( I1iii11 [ "display_name" ] )
    url = II ( I1iii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOOoo . append ( name )
    Ii1ii111i1 . append ( url )
    if "hd" in name . lower ( ) :
     i1i1i1I . append ( "1" )
    else :
     i1i1i1I . append ( "0" )
    oOooO = list ( zip ( i1i1i1I , oOOOoo , Ii1ii111i1 ) )
    if 41 - 41: ii1IiIi11
 if oo == "true" :
  oOoo000 = 1
  i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if OOOoO000 < 100 :
    I1IiiI . update ( OOOoO000 )
    OOOoO000 = OOOoO000 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1i11ii = [ ]
   for i111iI , OOo , url in I1iIi1iIiiIiI :
    i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : url }
    I1i11ii . append ( i1i11I1I1iii1 )
   OO00 = [ ]
   for I1iii11 in I1i11ii :
    i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
    I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
    for ooo0O , iII1iii in I1iIi1iIiiIiI :
     i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
    OO00 . append ( i1i11I1I1iii1 )
    if 77 - 77: Ooooo
   for I1iii11 in OO00 :
    name = II ( I1iii11 [ "display_name" ] )
    url = II ( I1iii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOOoo . append ( name )
    Ii1ii111i1 . append ( url )
    if "hd" in name . lower ( ) :
     i1i1i1I . append ( "1" )
    else :
     i1i1i1I . append ( "0" )
    oOooO = list ( zip ( i1i1i1I , oOOOoo , Ii1ii111i1 ) )
    if 65 - 65: o00 . Oo0oO0ooo % iI1 * I1I1i1
 if oOoo000 == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 38 - 38: oO0 / iIii1I111I11I % I11iii11IIi
 o0OoOo00o0o = sorted ( oOooO , key = lambda iIii11I : int ( iIii11I [ 0 ] ) , reverse = True )
 I1IIIiii1 = sorted ( oOo00O000Oo0 )
 if 65 - 65: oooO / o00 * ii1IiIi11 . iIii1I111I11I * iI1 % OoOooOOOO
 i1IIIII11I1IiI = 0
 if 69 - 69: IiIIIiI1I1 - I1I1i1 / i11iIiiIii + OOoOoo00oo % I1i1iI1i
 I1IiiI . update ( 100 )
 if 73 - 73: ii1IiIi11 - Ooooo
 I1III ( '                    [COLOR yellow][I]LINKS FOR ' + ii11i . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 I1III ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 68 - 68: iIii1I111I11I * I1i1iI1i * Oo0ooO0oo0oO . o00
 if 81 - 81: OoOooOOOO / o0OO0 + oooO + ii1IiIi11 / Oo0oO0ooo
 for o0ooO in I1IIIiii1 :
  if 27 - 27: oO0 * O00OooO0
  I1III ( '                                  [COLOR mediumpurple][I]' + o0ooO . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 59 - 59: O00OooO0 . O00OooO0 - o00 + O00OooO0 . o00ooo0 . I1I1i1
  i1iI = o0ooO . split ( ' ' )
  if 57 - 57: Oo0oO0ooo + ii1IiIi11 % iI1 + iI1 / o00 . ii1IiIi11
  for I1iIII1 , name , url in o0OoOo00o0o :
   if 39 - 39: I1i1iI1i
   i1i1I = 0
   if 25 - 25: Oo0ooO0oo0oO + OOoOoo00oo + iIii1I111I11I / o00 / oooO
   for o0O0Oo00Oo0o in i1iI :
    if 74 - 74: I11iii11IIi / i11iIiiIii - o00 * OOo0o0
    if not o0O0Oo00Oo0o . lower ( ) in name . lower ( ) :
     i1i1I = 1
     if 5 - 5: OoOooOOOO - OoOooOOOO . I11iii11IIi + oO0 - OoOooOOOO . iI1
   if i1i1I == 0 :
    i1IIIII11I1IiI = i1IIIII11I1IiI + 1
    if "hd" in name . lower ( ) :
     I1III ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( i1IIIII11I1IiI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     I1III ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( i1IIIII11I1IiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 31 - 31: o00 - Oo0ooO0oo0oO - Oo0ooO0oo0oO % oooO
  if i1IIIII11I1IiI == 0 :
   I1III ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 12 - 12: Oo0ooO0oo0oO
  i1iI = ""
  if 20 - 20: OOo0o0 / o00ooo0
 I1IiiI . close ( )
 if 71 - 71: oO0 . o00ooo0
def o0 ( name , url , iconimage ) :
 if 91 - 91: Oo0ooO0oo0oO % OOo0o0 . Oo0ooO0oo0oO % o00ooo0 / o00 * oO0
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 10 - 10: o00 . iIii1I111I11I
 OOOoO000 = 0
 try :
  ii11i , o0ooO , iconimage = url . split ( '!' )
 except :
  try :
   o0ooO , iconimage = url . split ( '!' )
   ii11i = o0ooO
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 32 - 32: ii1IiIi11 . O00OooO0 . I1i1iI1i - I1I1i1 + iI1
 ooO0oO00O0o = 0
 if 70 - 70: Ooooo
 if "all " in name . lower ( ) :
  o0ooO = o0ooO . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  ii11i = ii11i . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  ooO0oO00O0o = 1
  if 16 - 16: iIii1I111I11I - I1i1iI1i % I11iii11IIi
 oOOOoo = [ ]
 Ii1ii111i1 = [ ]
 i1i1i1I = [ ]
 I1IiiI . update ( 0 )
 oOoo000 = 0
 if O00o0o0000o0o == "true" :
  oOoo000 = 1
  i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if OOOoO000 < 100 :
    I1IiiI . update ( OOOoO000 )
    OOOoO000 = OOOoO000 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1i11ii = [ ]
   for i111iI , OOo , url in I1iIi1iIiiIiI :
    i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : url }
    I1i11ii . append ( i1i11I1I1iii1 )
   OO00 = [ ]
   for I1iii11 in I1i11ii :
    i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
    I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
    for ooo0O , iII1iii in I1iIi1iIiiIiI :
     i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
    OO00 . append ( i1i11I1I1iii1 )
    if 36 - 36: OoOooOOOO
   for I1iii11 in OO00 :
    name = II ( I1iii11 [ "display_name" ] )
    url = II ( I1iii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOOoo . append ( name )
    Ii1ii111i1 . append ( url )
    if "hd" in name . lower ( ) :
     i1i1i1I . append ( "1" )
    else :
     i1i1i1I . append ( "0" )
    oOooO = list ( zip ( i1i1i1I , oOOOoo , Ii1ii111i1 ) )
    if 84 - 84: Ooooo . I1I1i1 . o00 . oooO / ii1IiIi11 % OOoOoo00oo
 if O0Oo == "true" :
  oOoo000 = 1
  i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if OOOoO000 < 100 :
    I1IiiI . update ( OOOoO000 )
    OOOoO000 = OOOoO000 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1i11ii = [ ]
   for i111iI , OOo , url in I1iIi1iIiiIiI :
    i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : url }
    I1i11ii . append ( i1i11I1I1iii1 )
   OO00 = [ ]
   for I1iii11 in I1i11ii :
    i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
    I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
    for ooo0O , iII1iii in I1iIi1iIiiIiI :
     i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
    OO00 . append ( i1i11I1I1iii1 )
    if 57 - 57: Oo0oO0ooo % oooO - OoOooOOOO . Oo0oO0ooo / I11iii11IIi % iIii1I111I11I
   for I1iii11 in OO00 :
    name = II ( I1iii11 [ "display_name" ] )
    url = II ( I1iii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOOoo . append ( name )
    Ii1ii111i1 . append ( url )
    if "hd" in name . lower ( ) :
     i1i1i1I . append ( "1" )
    else :
     i1i1i1I . append ( "0" )
    oOooO = list ( zip ( i1i1i1I , oOOOoo , Ii1ii111i1 ) )
    if 56 - 56: iI1 . iIii1I111I11I . O00OooO0 * oO0 . IiIIIiI1I1 / o0OO0
 if oo == "true" :
  oOoo000 = 1
  i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
  for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
   if OOOoO000 < 100 :
    I1IiiI . update ( OOOoO000 )
    OOOoO000 = OOOoO000 + 3
   oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = oO0Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   I1i11ii = [ ]
   for i111iI , OOo , url in I1iIi1iIiiIiI :
    i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : url }
    I1i11ii . append ( i1i11I1I1iii1 )
   OO00 = [ ]
   for I1iii11 in I1i11ii :
    i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
    I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
    for ooo0O , iII1iii in I1iIi1iIiiIiI :
     i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
    OO00 . append ( i1i11I1I1iii1 )
    if 23 - 23: o00ooo0 + iIii1I111I11I + O00OooO0 + I1I1i1
   for I1iii11 in OO00 :
    name = II ( I1iii11 [ "display_name" ] )
    url = II ( I1iii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOOoo . append ( name )
    Ii1ii111i1 . append ( url )
    if "hd" in name . lower ( ) :
     i1i1i1I . append ( "1" )
    else :
     i1i1i1I . append ( "0" )
    oOooO = list ( zip ( i1i1i1I , oOOOoo , Ii1ii111i1 ) )
    if 12 - 12: Oo0ooO0oo0oO - OOoOoo00oo + i11iIiiIii
 if oOoo000 == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 10 - 10: Oo0oO0ooo - o00ooo0 - IiIIIiI1I1 % I11iii11IIi
 o0OoOo00o0o = sorted ( oOooO , key = lambda iIii11I : int ( iIii11I [ 0 ] ) , reverse = True )
 if 6 - 6: OOoOoo00oo + iI1
 i1IIIII11I1IiI = 0
 if 48 - 48: Oo0ooO0oo0oO % o00ooo0 % iIii1I111I11I + IiIIIiI1I1
 I1IiiI . update ( 100 )
 if 30 - 30: i11iIiiIii % Oo0ooO0oo0oO . oooO % Oo0ooO0oo0oO
 I1III ( '                                [COLOR yellow][I]LINKS FOR ' + ii11i . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 I1III ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 i1iI = o0ooO . split ( ' ' )
 for I1iIII1 , name , url in o0OoOo00o0o :
  if ooO0oO00O0o == 1 :
   oOO00oO00O0OO = name
   if 96 - 96: oO0
  i1i1I = 0
  if 54 - 54: Ooooo
  for o0O0Oo00Oo0o in i1iI :
   if 84 - 84: Ooooo - OOoOoo00oo / oooO
   if not o0O0Oo00Oo0o . lower ( ) in name . lower ( ) :
    i1i1I = 1
    if 13 - 13: O00OooO0 - I11iii11IIi - IiIIIiI1I1
  if i1i1I == 0 :
   i1IIIII11I1IiI = i1IIIII11I1IiI + 1
   if ooO0oO00O0o == 1 :
    if "hd" in name . lower ( ) :
     I1III ( '                                          [COLOR blue] ' + str ( oOO00oO00O0OO ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     I1III ( '                                          [COLOR blue] ' + str ( oOO00oO00O0OO ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     I1III ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( i1IIIII11I1IiI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     I1III ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( i1IIIII11I1IiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 92 - 92: IiIIIiI1I1 / oO0 * I1I1i1 . oooO % o00
 if i1IIIII11I1IiI == 0 :
  I1III ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 71 - 71: Ooooo % o00ooo0 - o00 - OoOooOOOO + OoOooOOOO * IiIIIiI1I1
 I1IiiI . close ( )
 if 51 - 51: Oo0ooO0oo0oO / oO0 + OoOooOOOO - oooO + iIii1I111I11I
def IIii1i1iii1 ( term ) :
 if 70 - 70: i11iIiiIii % iIii1I111I11I
 OoOOoOooooOOo = [ ]
 oOo0O = [ ]
 if 11 - 11: O00OooO0 % OOoOoo00oo % ii1IiIi11 / o00 % Ooooo - I11iii11IIi
 i1II1 = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0Oo000ooO00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1II1 )
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  oO0Ii1iIiII1ii1 = oO0Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1IiiiI1iI = oO0Ii1iIiII1ii1
  if 96 - 96: OOoOoo00oo / o00 . ii1IiIi11 - iIii1I111I11I * oooO * iI1
  i1IiiiI1iI = i1IiiiI1iI . replace ( '#AAASTREAM:' , '#A:' )
  i1IiiiI1iI = i1IiiiI1iI . replace ( '#EXTINF:' , '#A:' )
  I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i1IiiiI1iI )
  I1i11ii = [ ]
  for i111iI , OOo , i1IiiiI1iI in I1iIi1iIiiIiI :
   i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : i1IiiiI1iI }
   I1i11ii . append ( i1i11I1I1iii1 )
  list = [ ]
  for I1iii11 in I1i11ii :
   i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
   I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
   for ooo0O , iII1iii in I1iIi1iIiiIiI :
    i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
   list . append ( i1i11I1I1iii1 )
   if 76 - 76: ii1IiIi11 - o00 * OoOooOOOO / I1i1iI1i
  for I1iii11 in list :
   i1OOO = II ( I1iii11 [ "display_name" ] )
   i1IiiiI1iI = II ( I1iii11 [ "url" ] )
   i1IiiiI1iI = i1IiiiI1iI . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in i1OOO . lower ( ) :
    OoOOoOooooOOo . append ( i1IiiiI1iI )
    oOo0O . append ( i1OOO )
    if 18 - 18: I1I1i1 + Oo0ooO0oo0oO - o00 - Oo0oO0ooo
 O00ooooo00 = xbmcgui . Dialog ( )
 IiIi11iI = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , oOo0O )
 if IiIi11iI < 0 :
  quit ( )
  if 71 - 71: I1i1iI1i
 i1IiiiI1iI = OoOOoOooooOOo [ IiIi11iI ]
 i1OOO = oOo0O [ IiIi11iI ]
 OoO000O0Oo ( i1OOO , i1IiiiI1iI , iiiii )
 if 33 - 33: Ooooo
def OOO0ooo ( name , url , iconimage ) :
 if 7 - 7: OOo0o0 + o00ooo0 . Oo0oO0ooo / I11iii11IIi
 list = I111i1I1 ( url )
 if 62 - 62: OoOooOOOO * Ooooo / I11iii11IIi * OOo0o0
 II1Ii1iI1i1 = 0
 oOoO = open ( IiII , mode = 'r' ) ; o0OoO000O = oOoO . read ( ) ; oOoO . close ( )
 o0OoO000O = o0OoO000O . replace ( '\n' , '' )
 O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o0OoO000O )
 O0iII1 = 0
 for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
  if 94 - 94: oO0 . o0OO0 / ii1IiIi11 . OOoOoo00oo - o00ooo0
  iIi1III1I = re . compile ( '<url>(.+?)</url>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  if 71 - 71: Ooooo
  if url == iIi1III1I :
   II1Ii1iI1i1 = 1
   if 11 - 11: o0OO0 / I1I1i1 % OoOooOOOO + OOo0o0 + Oo0ooO0oo0oO
 for I1iii11 in list :
  name = II ( I1iii11 [ "display_name" ] )
  url = II ( I1iii11 [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if II1Ii1iI1i1 == 1 :
   if 40 - 40: IiIIIiI1I1 - OoOooOOOO . ii1IiIi11 * I11iii11IIi % Ooooo
   oOoO = open ( iI1Ii11111iIi , mode = 'r' ) ; o0OoO000O = oOoO . read ( ) ; oOoO . close ( )
   o0OoO000O = o0OoO000O . replace ( '\n' , '' )
   O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o0OoO000O )
   for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
    if 56 - 56: i11iIiiIii . OOo0o0 - Oo0oO0ooo * oooO
    oOOoo0 = re . compile ( '<name>(.+?)</name>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
    if 20 - 20: O00OooO0 % O00OooO0
    OOooo0O = oOOoo0 . replace ( ' ' , '' )
    iiI1iIIiI = name . replace ( ' ' , '' )
    if OOooo0O . lower ( ) in iiI1iIIiI . lower ( ) :
     if 57 - 57: I1I1i1 / o00ooo0 . o00ooo0
     oOoO = open ( i1i1II , mode = 'r' ) ; o0OoO000O = oOoO . read ( ) ; oOoO . close ( )
     o0OoO000O = o0OoO000O . replace ( '\n' , '' )
     O0Oo000ooO00 = re . compile ( '<item>(.+?)</item>' ) . findall ( o0OoO000O )
     for oO0Ii1iIiII1ii1 in O0Oo000ooO00 :
      if 74 - 74: Oo0ooO0oo0oO * O00OooO0 % oO0
      iiI11iIi = re . compile ( '<replace>(.+?)</replace>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
      if 89 - 89: o0OO0
      name = name . lower ( ) . replace ( iiI11iIi , '' )
      if 2 - 2: OOoOoo00oo . OOoOoo00oo + OOoOoo00oo * OOo0o0
     I1III ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 100 - 100: I11iii11IIi % ii1IiIi11 / oooO
  else : I1III ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 30 - 30: I11iii11IIi - OoOooOOOO - iIii1I111I11I
def I111i1I1 ( url ) :
 if 81 - 81: OOo0o0 . I1i1iI1i + OoOooOOOO * IiIIIiI1I1
 ooOoOo = IIIii1II1II ( url )
 ooOoOo = ooOoOo . replace ( '#AAASTREAM:' , '#A:' )
 ooOoOo = ooOoOo . replace ( '#EXTINF:' , '#A:' )
 I1iIi1iIiiIiI = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( ooOoOo )
 I1i11ii = [ ]
 for i111iI , OOo , url in I1iIi1iIiiIiI :
  i1i11I1I1iii1 = { "params" : i111iI , "display_name" : OOo , "url" : url }
  I1i11ii . append ( i1i11I1I1iii1 )
 list = [ ]
 for I1iii11 in I1i11ii :
  i1i11I1I1iii1 = { "display_name" : I1iii11 [ "display_name" ] , "url" : I1iii11 [ "url" ] }
  I1iIi1iIiiIiI = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1iii11 [ "params" ] )
  for ooo0O , iII1iii in I1iIi1iIiiIiI :
   i1i11I1I1iii1 [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iII1iii . strip ( )
  list . append ( i1i11I1I1iii1 )
  if 21 - 21: oO0 + i11iIiiIii + Oo0oO0ooo * OOo0o0 % iIii1I111I11I % o00
 return list
 if 55 - 55: I11iii11IIi - OoOooOOOO
 if 84 - 84: Ooooo + I11iii11IIi - oO0 * oO0
def Ooo ( ) :
 if 65 - 65: I11iii11IIi / oooO
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 12 - 12: oooO % oO0
def i1i ( name , url , iconimage ) :
 if 5 - 5: iI1 . OOoOoo00oo . o00 . I1i1iI1i
 Oo0OooO0 = datetime . datetime . now ( )
 oO00oOo0OOO = Oo0OooO0 . day
 if 23 - 23: o00ooo0 . OOo0o0 * I1I1i1
 iIi1IiI = oO00oOo0OOO
 if 14 - 14: O00OooO0 % iI1 % I11iii11IIi - i11iIiiIii
 o0OO000ooOo = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOo00OooO0oO = datetime . datetime . strftime ( o0OO000ooOo , '%A - %d %B %Y' )
 I1IIi = 'http://www.predictz.com/predictions/'
 if 69 - 69: ii1IiIi11 + I11iii11IIi + o00 - Oo0oO0ooo / oooO
 O0O0ooOOO = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 O0o = datetime . datetime . strftime ( O0O0ooOOO , '%A - %d %B %Y' )
 iIiiiiI1II1I1 = datetime . datetime . strftime ( O0O0ooOOO , '%d' )
 OoO0ooO = 'http://www.predictz.com/predictions/tomorrow/'
 if 52 - 52: i11iIiiIii / o00ooo0
 i1IIII1iii11I = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 oo0OoOooo = datetime . datetime . strftime ( i1IIII1iii11I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 O00O00O000OOO = datetime . datetime . strftime ( i1IIII1iii11I , '%y%m%d' )
 iIOo0O = 'http://www.predictz.com/predictions/20' + str ( O00O00O000OOO )
 if 1 - 1: o0OO0 / iIii1I111I11I % Ooooo . I11iii11IIi + O00OooO0
 I1Ii11iiiI = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 i1II1IiIII111 = datetime . datetime . strftime ( I1Ii11iiiI , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiiIi1IIII1i = datetime . datetime . strftime ( I1Ii11iiiI , '%y%m%d' )
 O0ooOoO = 'http://www.predictz.com/predictions/20' + str ( IiiIi1IIII1i )
 if 26 - 26: oO0 / I11iii11IIi - o00ooo0 + oooO
 IiiIi = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIIi = datetime . datetime . strftime ( IiiIi , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO00O00oOO = datetime . datetime . strftime ( IiiIi , '%y%m%d' )
 I1 = 'http://www.predictz.com/predictions/20' + str ( ooO00O00oOO )
 if 48 - 48: Oo0oO0ooo + OOoOoo00oo + o00 * i11iIiiIii
 if 13 - 13: I1i1iI1i * iI1 - ii1IiIi11 / OoOooOOOO + oooO + O00OooO0
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOo00OooO0oO ) + '[/B][/COLOR]' , I1IIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( O0o ) + '[/B][/COLOR]' , OoO0ooO , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo0OoOooo ) , iIOo0O , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1II1IiIII111 ) , O0ooOoO , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIIi ) , I1 , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 39 - 39: Oo0ooO0oo0oO - I1i1iI1i
def oO0oooooo ( name , url , iconimage ) :
 if 65 - 65: O00OooO0 + I11iii11IIi
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 i1iI = str ( O0Oo000ooO00 )
 iiI1I1ii = re . compile ( '<tr(.+?)</tr>' ) . findall ( i1iI )
 for oO0Ii1iIiII1ii1 in iiI1I1ii :
  try :
   oOoO0 = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR red][B]' + oOoO0 + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   i11i1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   Ooo0O0 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i11i1 = ooo0 ( i11i1 )
   Ooo0O0 = ooo0 ( Ooo0O0 )
   I1III ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + Ooo0O0 + ' [/B][/COLOR]| [COLOR mediumpurple]' + i11i1 + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 55 - 55: I11iii11IIi
def ooO0o ( name , url , iconimage ) :
 if 25 - 25: Oo0ooO0oo0oO - iIii1I111I11I
 Oo0OooO0 = datetime . datetime . now ( )
 oO00oOo0OOO = Oo0OooO0 . day
 if 3 - 3: Oo0oO0ooo * IiIIIiI1I1 + o00 - I1I1i1
 iIi1IiI = oO00oOo0OOO
 if 97 - 97: OOoOoo00oo / iI1 - OOo0o0 - Oo0oO0ooo - Oo0oO0ooo
 o0OO000ooOo = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOo00OooO0oO = datetime . datetime . strftime ( o0OO000ooOo , '%A - %d %B %Y' )
 I1IIi = 'http://www.predictz.com/predictions/'
 if 54 - 54: I11iii11IIi + Oo0oO0ooo / iIii1I111I11I . Oo0oO0ooo * oO0
 O0O0ooOOO = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 O0o = datetime . datetime . strftime ( O0O0ooOOO , '%A - %d %B %Y' )
 iIiiiiI1II1I1 = datetime . datetime . strftime ( O0O0ooOOO , '%d' )
 OoO0ooO = 'http://www.predictz.com/predictions/tomorrow/'
 if 1 - 1: oO0 * I1I1i1 . o00ooo0 / I11iii11IIi . OOoOoo00oo + I11iii11IIi
 i1IIII1iii11I = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 oo0OoOooo = datetime . datetime . strftime ( i1IIII1iii11I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 O00O00O000OOO = datetime . datetime . strftime ( i1IIII1iii11I , '%y%m%d' )
 iIOo0O = 'http://www.predictz.com/predictions/20' + str ( O00O00O000OOO )
 if 17 - 17: I11iii11IIi + I1I1i1 / ii1IiIi11 / iIii1I111I11I * OoOooOOOO
 I1Ii11iiiI = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 i1II1IiIII111 = datetime . datetime . strftime ( I1Ii11iiiI , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiiIi1IIII1i = datetime . datetime . strftime ( I1Ii11iiiI , '%y%m%d' )
 O0ooOoO = 'http://www.predictz.com/predictions/20' + str ( IiiIi1IIII1i )
 if 29 - 29: I1I1i1 % I1i1iI1i * iI1 / o00 - iI1
 IiiIi = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIIi = datetime . datetime . strftime ( IiiIi , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO00O00oOO = datetime . datetime . strftime ( IiiIi , '%y%m%d' )
 I1 = 'http://www.predictz.com/predictions/20' + str ( ooO00O00oOO )
 if 19 - 19: i11iIiiIii
 if 54 - 54: o00 . oooO
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOo00OooO0oO ) + '[/B][/COLOR]' , I1IIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( O0o ) + '[/B][/COLOR]' , OoO0ooO , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo0OoOooo ) , iIOo0O , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1II1IiIII111 ) , O0ooOoO , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIIi ) , I1 , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 73 - 73: oO0 . Oo0oO0ooo
def II1i11i1iIi11 ( name , url , iconimage ) :
 if 83 - 83: ii1IiIi11
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 i1iI = str ( O0Oo000ooO00 )
 iiI1I1ii = re . compile ( '<tr(.+?)</tr>' ) . findall ( i1iI )
 for oO0Ii1iIiII1ii1 in iiI1I1ii :
  try :
   oOoO0 = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR red][B]' + oOoO0 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   i11i1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1iI1I1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IiIi1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 1 ]
   oo00ooOoo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 2 ]
   i11i1 = ooo0 ( i11i1 )
   I1III ( '[COLOR mediumpurple][B]' + i11i1 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + I1iI1I1 + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + IiIi1 + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + oo00ooOoo + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 28 - 28: ii1IiIi11
def iIIIiiiI11I ( name , url , iconimage ) :
 if 6 - 6: ii1IiIi11 % o00ooo0 . ii1IiIi11 * ii1IiIi11
 Oo0OooO0 = datetime . datetime . now ( )
 oO00oOo0OOO = Oo0OooO0 . day
 if 81 - 81: OoOooOOOO / Oo0ooO0oo0oO + O00OooO0
 iIi1IiI = oO00oOo0OOO
 if 49 - 49: OoOooOOOO / I1i1iI1i / Oo0oO0ooo
 o0OO000ooOo = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOo00OooO0oO = datetime . datetime . strftime ( o0OO000ooOo , '%A - %d %B %Y' )
 I1IIi = 'http://www.predictz.com/predictions/'
 if 74 - 74: Ooooo % OOoOoo00oo
 O0O0ooOOO = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 O0o = datetime . datetime . strftime ( O0O0ooOOO , '%A - %d %B %Y' )
 iIiiiiI1II1I1 = datetime . datetime . strftime ( O0O0ooOOO , '%d' )
 OoO0ooO = 'http://www.predictz.com/predictions/tomorrow/'
 if 7 - 7: o00
 i1IIII1iii11I = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 oo0OoOooo = datetime . datetime . strftime ( i1IIII1iii11I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 O00O00O000OOO = datetime . datetime . strftime ( i1IIII1iii11I , '%y%m%d' )
 iIOo0O = 'http://www.predictz.com/predictions/20' + str ( O00O00O000OOO )
 if 27 - 27: iI1 . I1i1iI1i + i11iIiiIii
 I1Ii11iiiI = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 i1II1IiIII111 = datetime . datetime . strftime ( I1Ii11iiiI , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiiIi1IIII1i = datetime . datetime . strftime ( I1Ii11iiiI , '%y%m%d' )
 O0ooOoO = 'http://www.predictz.com/predictions/20' + str ( IiiIi1IIII1i )
 if 86 - 86: oooO / OOo0o0 - OOo0o0 + OOoOoo00oo + iI1
 IiiIi = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIIi = datetime . datetime . strftime ( IiiIi , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO00O00oOO = datetime . datetime . strftime ( IiiIi , '%y%m%d' )
 I1 = 'http://www.predictz.com/predictions/20' + str ( ooO00O00oOO )
 if 33 - 33: OOo0o0 . iIii1I111I11I . O00OooO0 . o00ooo0
 if 49 - 49: OOoOoo00oo
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOo00OooO0oO ) + '[/B][/COLOR]' , I1IIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( O0o ) + '[/B][/COLOR]' , OoO0ooO , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo0OoOooo ) , iIOo0O , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1II1IiIII111 ) , O0ooOoO , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIIi ) , I1 , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 84 - 84: oooO - I11iii11IIi / o0OO0 - Ooooo
def ii1iI1II11ii ( name , url , iconimage ) :
 if 8 - 8: IiIIIiI1I1 * o0OO0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 i1iI = str ( O0Oo000ooO00 )
 iiI1I1ii = re . compile ( '<tr(.+?)</tr>' ) . findall ( i1iI )
 for oO0Ii1iIiII1ii1 in iiI1I1ii :
  try :
   oOoO0 = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR red][B]' + oOoO0 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   i11i1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1IIIII11I1IiI , i1I = i11i1 . split ( ' v ' )
   OOoO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IiIIII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 1 ]
   oOOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 2 ]
   oo0oO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 3 ]
   IIi11i1II = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 4 ]
   OO0ooo0o0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 5 ]
   oO0ooOoO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 6 ]
   ooO0000o00O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 7 ]
   O0Ooo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 8 ]
   oO00oOOo0Oo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 9 ]
   if 5 - 5: OOo0o0 . o0OO0 / I11iii11IIi % I1I1i1
   if OOoO == "W" :
    OOoO = '[COLOR lime]W[/COLOR]'
   elif OOoO == "D" :
    OOoO = '[COLOR yellow]D[/COLOR]'
   else : OOoO = '[COLOR red]L[/COLOR]'
   if 60 - 60: o00 / Oo0ooO0oo0oO + OOoOoo00oo . i11iIiiIii
   if IiIIII == "W" :
    IiIIII = '[COLOR lime]W[/COLOR]'
   elif IiIIII == "D" :
    IiIIII = '[COLOR yellow]D[/COLOR]'
   else : IiIIII = '[COLOR red]L[/COLOR]'
   if 40 - 40: OOo0o0
   if oOOo == "W" :
    oOOo = '[COLOR lime]W[/COLOR]'
   elif oOOo == "D" :
    oOOo = '[COLOR yellow]D[/COLOR]'
   else : oOOo = '[COLOR red]L[/COLOR]'
   if 78 - 78: Oo0ooO0oo0oO
   if oo0oO0 == "W" :
    oo0oO0 = '[COLOR lime]W[/COLOR]'
   elif oo0oO0 == "D" :
    oo0oO0 = '[COLOR yellow]D[/COLOR]'
   else : oo0oO0 = '[COLOR red]L[/COLOR]'
   if 56 - 56: I1i1iI1i - oooO - o00ooo0
   if IIi11i1II == "W" :
    IIi11i1II = '[COLOR lime]W[/COLOR]'
   elif IIi11i1II == "D" :
    IIi11i1II = '[COLOR yellow]D[/COLOR]'
   else : IIi11i1II = '[COLOR red]L[/COLOR]'
   if 8 - 8: Ooooo / OoOooOOOO . Oo0oO0ooo + OOoOoo00oo / i11iIiiIii
   if OO0ooo0o0 == "W" :
    OO0ooo0o0 = '[COLOR lime]W[/COLOR]'
   elif OO0ooo0o0 == "D" :
    OO0ooo0o0 = '[COLOR yellow]D[/COLOR]'
   else : OO0ooo0o0 = '[COLOR red]L[/COLOR]'
   if 31 - 31: IiIIIiI1I1 - Oo0ooO0oo0oO + iIii1I111I11I . I11iii11IIi / O00OooO0 % Oo0ooO0oo0oO
   if oO0ooOoO == "W" :
    oO0ooOoO = '[COLOR lime]W[/COLOR]'
   elif oO0ooOoO == "D" :
    oO0ooOoO = '[COLOR yellow]D[/COLOR]'
   else : oO0ooOoO = '[COLOR red]L[/COLOR]'
   if 6 - 6: O00OooO0 * i11iIiiIii % Oo0ooO0oo0oO % i11iIiiIii + OOo0o0 / o00ooo0
   if ooO0000o00O == "W" :
    ooO0000o00O = '[COLOR lime]W[/COLOR]'
   elif ooO0000o00O == "D" :
    ooO0000o00O = '[COLOR yellow]D[/COLOR]'
   else : ooO0000o00O = '[COLOR red]L[/COLOR]'
   if 53 - 53: oooO + Oo0ooO0oo0oO
   if O0Ooo == "W" :
    O0Ooo = '[COLOR lime]W[/COLOR]'
   elif O0Ooo == "D" :
    O0Ooo = '[COLOR yellow]D[/COLOR]'
   else : O0Ooo = '[COLOR red]L[/COLOR]'
   if 70 - 70: OOoOoo00oo
   if oO00oOOo0Oo == "W" :
    oO00oOOo0Oo = '[COLOR lime]W[/COLOR]'
   elif oO00oOOo0Oo == "D" :
    oO00oOOo0Oo = '[COLOR yellow]D[/COLOR]'
   else : oO00oOOo0Oo = '[COLOR red]L[/COLOR]'
   if 67 - 67: I1i1iI1i
   i1IIIII11I1IiI = ooo0 ( i1IIIII11I1IiI )
   i1I = ooo0 ( i1I )
   I1III ( '[COLOR mediumpurple][B]' + i1IIIII11I1IiI + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[B]' + OOoO + '  ' + IiIIII + '  ' + oOOo + '  ' + oo0oO0 + '  ' + IIi11i1II + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR mediumpurple][B]' + i1I + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[B]' + OO0ooo0o0 + '  ' + oO0ooOoO + '  ' + ooO0000o00O + '  ' + O0Ooo + '  ' + oO00oOOo0Oo + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 29 - 29: o0OO0 - i11iIiiIii - o00 + OoOooOOOO * O00OooO0
def IiI1ii1Ii ( name , url , iconimage ) :
 if 51 - 51: i11iIiiIii * OOo0o0 / Oo0oO0ooo
 Oo0OooO0 = datetime . datetime . now ( )
 oO00oOo0OOO = Oo0OooO0 . day
 if 40 - 40: Oo0oO0ooo
 iIi1IiI = oO00oOo0OOO
 if 36 - 36: IiIIIiI1I1 / iIii1I111I11I - O00OooO0 - O00OooO0
 o0OO000ooOo = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOo00OooO0oO = datetime . datetime . strftime ( o0OO000ooOo , '%A - %d %B %Y' )
 I1IIi = 'http://www.predictz.com/predictions/'
 if 82 - 82: OOoOoo00oo
 O0O0ooOOO = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 O0o = datetime . datetime . strftime ( O0O0ooOOO , '%A - %d %B %Y' )
 iIiiiiI1II1I1 = datetime . datetime . strftime ( O0O0ooOOO , '%d' )
 OoO0ooO = 'http://www.predictz.com/predictions/tomorrow/'
 if 29 - 29: O00OooO0
 i1IIII1iii11I = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 oo0OoOooo = datetime . datetime . strftime ( i1IIII1iii11I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 O00O00O000OOO = datetime . datetime . strftime ( i1IIII1iii11I , '%y%m%d' )
 iIOo0O = 'http://www.predictz.com/predictions/20' + str ( O00O00O000OOO )
 if 66 - 66: I11iii11IIi
 I1Ii11iiiI = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 i1II1IiIII111 = datetime . datetime . strftime ( I1Ii11iiiI , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiiIi1IIII1i = datetime . datetime . strftime ( I1Ii11iiiI , '%y%m%d' )
 O0ooOoO = 'http://www.predictz.com/predictions/20' + str ( IiiIi1IIII1i )
 if 97 - 97: o00ooo0 - I1i1iI1i / Ooooo * Oo0oO0ooo
 IiiIi = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 iIIi = datetime . datetime . strftime ( IiiIi , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO00O00oOO = datetime . datetime . strftime ( IiiIi , '%y%m%d' )
 I1 = 'http://www.predictz.com/predictions/20' + str ( ooO00O00oOO )
 if 55 - 55: OOo0o0 . iIii1I111I11I
 if 87 - 87: OOo0o0 % Oo0ooO0oo0oO
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOo00OooO0oO ) + '[/B][/COLOR]' , I1IIi , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( O0o ) + '[/B][/COLOR]' , OoO0ooO , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo0OoOooo ) , iIOo0O , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1II1IiIII111 ) , O0ooOoO , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIIi ) , I1 , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 100 - 100: Ooooo . Oo0oO0ooo * Ooooo - Oo0oO0ooo . oooO * ii1IiIi11
def oO000o ( name , url , iconimage ) :
 if 78 - 78: I1i1iI1i
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 i1iI = str ( O0Oo000ooO00 )
 iiI1I1ii = re . compile ( '<tr(.+?)</tr>' ) . findall ( i1iI )
 for oO0Ii1iIiII1ii1 in iiI1I1ii :
  try :
   oOoO0 = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR red][B]' + oOoO0 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   i11i1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   i1IIIII11I1IiI , i1I = i11i1 . split ( ' v ' )
   if 77 - 77: OOoOoo00oo / o00ooo0 / I11iii11IIi % OoOooOOOO
   Ooo0O0 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   I1iI1I1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IiIi1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 1 ]
   oo00ooOoo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 2 ]
   OOoO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
   IiIIII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 1 ]
   oOOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 2 ]
   oo0oO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 3 ]
   IIi11i1II = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 4 ]
   OO0ooo0o0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 5 ]
   oO0ooOoO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 6 ]
   ooO0000o00O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 7 ]
   O0Ooo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 8 ]
   oO00oOOo0Oo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 9 ]
   if 48 - 48: oooO - O00OooO0 + Oo0ooO0oo0oO + I1i1iI1i
   if OOoO == "W" :
    OOoO = '[COLOR lime]W[/COLOR]'
   elif OOoO == "D" :
    OOoO = '[COLOR yellow]D[/COLOR]'
   else : OOoO = '[COLOR red]L[/COLOR]'
   if 4 - 4: o00 . oooO + ii1IiIi11 * Ooooo . IiIIIiI1I1
   if IiIIII == "W" :
    IiIIII = '[COLOR lime]W[/COLOR]'
   elif IiIIII == "D" :
    IiIIII = '[COLOR yellow]D[/COLOR]'
   else : IiIIII = '[COLOR red]L[/COLOR]'
   if 87 - 87: oO0 / I1I1i1 / i11iIiiIii
   if oOOo == "W" :
    oOOo = '[COLOR lime]W[/COLOR]'
   elif oOOo == "D" :
    oOOo = '[COLOR yellow]D[/COLOR]'
   else : oOOo = '[COLOR red]L[/COLOR]'
   if 74 - 74: iI1 / OOoOoo00oo % OOo0o0
   if oo0oO0 == "W" :
    oo0oO0 = '[COLOR lime]W[/COLOR]'
   elif oo0oO0 == "D" :
    oo0oO0 = '[COLOR yellow]D[/COLOR]'
   else : oo0oO0 = '[COLOR red]L[/COLOR]'
   if 88 - 88: oO0 - i11iIiiIii % OOo0o0 * oooO + OOoOoo00oo
   if IIi11i1II == "W" :
    IIi11i1II = '[COLOR lime]W[/COLOR]'
   elif IIi11i1II == "D" :
    IIi11i1II = '[COLOR yellow]D[/COLOR]'
   else : IIi11i1II = '[COLOR red]L[/COLOR]'
   if 52 - 52: o00 . Oo0oO0ooo + oO0 % I1I1i1
   if OO0ooo0o0 == "W" :
    OO0ooo0o0 = '[COLOR lime]W[/COLOR]'
   elif OO0ooo0o0 == "D" :
    OO0ooo0o0 = '[COLOR yellow]D[/COLOR]'
   else : OO0ooo0o0 = '[COLOR red]L[/COLOR]'
   if 62 - 62: OOo0o0
   if oO0ooOoO == "W" :
    oO0ooOoO = '[COLOR lime]W[/COLOR]'
   elif oO0ooOoO == "D" :
    oO0ooOoO = '[COLOR yellow]D[/COLOR]'
   else : oO0ooOoO = '[COLOR red]L[/COLOR]'
   if 15 - 15: oooO + ii1IiIi11 . OoOooOOOO * I1I1i1 . oO0
   if ooO0000o00O == "W" :
    ooO0000o00O = '[COLOR lime]W[/COLOR]'
   elif ooO0000o00O == "D" :
    ooO0000o00O = '[COLOR yellow]D[/COLOR]'
   else : ooO0000o00O = '[COLOR red]L[/COLOR]'
   if 18 - 18: o00ooo0 % o00 + Ooooo % ii1IiIi11
   if O0Ooo == "W" :
    O0Ooo = '[COLOR lime]W[/COLOR]'
   elif O0Ooo == "D" :
    O0Ooo = '[COLOR yellow]D[/COLOR]'
   else : O0Ooo = '[COLOR red]L[/COLOR]'
   if 72 - 72: Oo0ooO0oo0oO
   if oO00oOOo0Oo == "W" :
    oO00oOOo0Oo = '[COLOR lime]W[/COLOR]'
   elif oO00oOOo0Oo == "D" :
    oO00oOOo0Oo = '[COLOR yellow]D[/COLOR]'
   else : oO00oOOo0Oo = '[COLOR red]L[/COLOR]'
   if 45 - 45: I11iii11IIi - OOo0o0 % Ooooo
   i1IIIII11I1IiI = ooo0 ( i1IIIII11I1IiI )
   i1I = ooo0 ( i1I )
   i11i1 = ooo0 ( i11i1 )
   Ooo0O0 = ooo0 ( Ooo0O0 )
   I1III ( '[COLOR blue][B]' + i11i1 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + Ooo0O0 + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]' + i1IIIII11I1IiI + ' Form: - [/COLOR][B]' + OOoO + '  ' + IiIIII + '  ' + oOOo + '  ' + oo0oO0 + '  ' + IIi11i1II + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]' + i1I + ' Form - [/COLOR][B]' + OO0ooo0o0 + '  ' + oO0ooOoO + '  ' + ooO0000o00O + '  ' + O0Ooo + '  ' + oO00oOOo0Oo + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]' + i1IIIII11I1IiI + ' Win[/COLOR][COLOR dodgerblue][B] (' + I1iI1I1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + IiIi1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '[COLOR orange]' + i1I + ' Win[/COLOR][COLOR dodgerblue][B] (' + oo00ooOoo + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   I1III ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 38 - 38: Ooooo % OoOooOOOO - I1i1iI1i
  except : pass
  if 87 - 87: I1I1i1 % Oo0oO0ooo
def ooooOoO0O ( name , url , iconimage ) :
 if 1 - 1: OOoOoo00oo / I1I1i1 + iI1 . OOo0o0 / OOoOoo00oo - iIii1I111I11I
 ii111i1iI = [ ]
 I1I1iII1i = [ ]
 iiIIii = [ ]
 oO0Oo0O0 = [ ]
 I1iIiI1IiIIII = [ ]
 if 18 - 18: IiIIIiI1I1 % i11iIiiIii . Oo0ooO0oo0oO - iIii1I111I11I
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.livescores.com' )
 O0Oo000ooO00 = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( o00OO00OoO )
 i1iI = str ( O0Oo000ooO00 )
 iiI1I1ii = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( i1iI )
 for oO0Ii1iIiII1ii1 in iiI1I1ii :
  OOOOoo = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  IIii1 = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  try :
   Ooo0O0 = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except :
   Ooo0O0 = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( oO0Ii1iIiII1ii1 ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 35 - 35: i11iIiiIii - Oo0oO0ooo / OoOooOOOO + ii1IiIi11 * iI1
  if "minute" in time . lower ( ) :
   I1iIiI1IiIIII . append ( '3' )
  elif "ht" in time . lower ( ) :
   I1iIiI1IiIIII . append ( '3' )
  elif "ft" in time . lower ( ) :
   I1iIiI1IiIIII . append ( '2' )
  else : I1iIiI1IiIIII . append ( '1' )
  if 49 - 49: OOo0o0 * ii1IiIi11 + oooO + iIii1I111I11I
  ii111i1iI . append ( OOOOoo )
  I1I1iII1i . append ( IIii1 )
  iiIIii . append ( Ooo0O0 )
  oO0Oo0O0 . append ( time )
  oOooO = list ( zip ( I1iIiI1IiIIII , ii111i1iI , I1I1iII1i , iiIIii , oO0Oo0O0 ) )
  if 30 - 30: OOo0o0 / OoOooOOOO / O00OooO0 % IiIIIiI1I1 + o00
 I1III ( '[COLOR dodgerblue][B]The scores will update every 10 seconds.[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 I1III ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 4 - 4: iIii1I111I11I - I11iii11IIi - O00OooO0 - oooO % i11iIiiIii / I1I1i1
 o0OoOo00o0o = sorted ( oOooO , key = lambda iIii11I : int ( iIii11I [ 0 ] ) , reverse = True )
 i1iii11 = 0
 oO = 0
 o0O0o0000o0O0 = 0
 for o0OoOoOOoOo0o , iIiii , IiIii1ii , IIiI1i , iII1 in o0OoOo00o0o :
  if o0OoOoOOoOo0o == "3" :
   if i1iii11 == 0 :
    I1III ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    i1iii11 = 1
  elif o0OoOoOOoOo0o == "2" :
   if oO == 0 :
    I1III ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    oO = 1
  elif o0OoOoOOoOo0o == "1" :
   if o0O0o0000o0O0 == 0 :
    I1III ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    o0O0o0000o0O0 = 1
  iII1 = iII1 . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  IIiI1i = IIiI1i . replace ( " " , "" )
  I1III ( '[COLOR red][B]' + iII1 + "[/B][/COLOR]- [COLOR blue]" + IIiI1i + "[/COLOR] | [COLOR white]" + iIiii + "vs" + IiIii1ii + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 70 - 70: iIii1I111I11I / OoOooOOOO % IiIIIiI1I1 - ii1IiIi11
def i1II11Iii1I ( ) :
 if 92 - 92: OoOooOOOO % O00OooO0 % oO0
 i1iI = ''
 iIi1Ii = xbmc . Keyboard ( i1iI , 'Enter Search Term' )
 iIi1Ii . doModal ( )
 if iIi1Ii . isConfirmed ( ) :
  i1iI = iIi1Ii . getText ( )
  if len ( i1iI ) > 1 :
   i1IiiiI1iI = i1iI + "!" + iiiii
   o0 ( "all " + i1iI , i1IiiiI1iI , iiiii )
  else : quit ( )
  if 11 - 11: Oo0oO0ooo % ii1IiIi11 - I1I1i1 - iI1 + OOo0o0
def o0O0O0 ( name , url , iconimage ) :
 if 55 - 55: o0OO0 - Ooooo
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 58 - 58: oO0 - iIii1I111I11I - I1i1iI1i
def I1iiiiI1iI ( text ) :
 if 96 - 96: Oo0ooO0oo0oO
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 82 - 82: oO0 + o0OO0 - O00OooO0 % iI1 * i11iIiiIii
 return text
 if 15 - 15: OOo0o0
def ooo0 ( text ) :
 if 39 - 39: OoOooOOOO / OOoOoo00oo / Oo0oO0ooo * Ooooo
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 44 - 44: o0OO0 + IiIIIiI1I1 . Oo0ooO0oo0oO + I11iii11IIi / o0OO0 - oooO
 return text
 if 83 - 83: O00OooO0 * oooO / I11iii11IIi
def OoOOOo0o0ooo ( text ) :
 if 32 - 32: OOo0o0 + oO0 - I1i1iI1i
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 39 - 39: I1i1iI1i * OoOooOOOO * o0OO0 . oooO . I1I1i1 + IiIIIiI1I1
 return text
 if 9 - 9: oO0 + iI1 % I1i1iI1i + OOo0o0
def OoO000O0Oo ( name , url , iconimage ) :
 if 56 - 56: I1i1iI1i + OOoOoo00oo - iIii1I111I11I
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]Opening link...[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 24 - 24: OOo0o0 + IiIIIiI1I1 + oooO - Oo0ooO0oo0oO
 if "pl_type=user" in url :
  i1II1 = OOOO0OOoO0O0 ( url )
  url = re . compile ( '<meta property="og:video:iframe" content="(.+?)">' ) . findall ( i1II1 ) [ 0 ]
  if 49 - 49: oooO . IiIIIiI1I1 * oO0 % O00OooO0 . o0OO0
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 48 - 48: o0OO0 * ii1IiIi11 - o0OO0 / ii1IiIi11 + oO0
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 52 - 52: I1I1i1 % ii1IiIi11 * o00
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  I1IiIii11I = urlresolver . HostedMediaFile ( url ) . resolve ( )
  i1iii1ii = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  i1iii1ii . setPath ( I1IiIii11I )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( I1IiIii11I , i1iii1ii , False )
  quit ( )
 else :
  I1IiIii11I = url
  i1iii1ii = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  i1iii1ii . setPath ( I1IiIii11I )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( I1IiIii11I , i1iii1ii , False )
  quit ( )
  if 18 - 18: I1I1i1 . o00 % oO0 % ii1IiIi11
def i11111IIIII ( ) :
 if 87 - 87: Oo0ooO0oo0oO . I1i1iI1i * oO0
 OOOo = xbmc . getInfoLabel ( "System.BuildVersion" )
 o0ooOo00O = float ( OOOo [ : 4 ] )
 if o0ooOo00O >= 11.0 and o0ooOo00O <= 11.9 :
  Ii1i1I1 = 'Eden'
 elif o0ooOo00O >= 12.0 and o0ooOo00O <= 12.9 :
  Ii1i1I1 = 'Frodo'
 elif o0ooOo00O >= 13.0 and o0ooOo00O <= 13.9 :
  Ii1i1I1 = 'Gotham'
 elif o0ooOo00O >= 14.0 and o0ooOo00O <= 14.9 :
  Ii1i1I1 = 'Helix'
 elif o0ooOo00O >= 15.0 and o0ooOo00O <= 15.9 :
  Ii1i1I1 = 'Isengard'
 elif o0ooOo00O >= 16.0 and o0ooOo00O <= 16.9 :
  Ii1i1I1 = 'Jarvis'
 elif o0ooOo00O >= 17.0 and o0ooOo00O <= 17.9 :
  Ii1i1I1 = 'Krypton'
 else : Ii1i1I1 = "Decline"
 if 97 - 97: Ooooo . IiIIIiI1I1 - Ooooo + Oo0oO0ooo * o00
 return Ii1i1I1
 if 10 - 10: ii1IiIi11 + oooO % I1i1iI1i - Oo0oO0ooo
def OOOO0OOoO0O0 ( url ) :
 if 70 - 70: OoOooOOOO - iIii1I111I11I
 iIi = urllib2 . Request ( url )
 iIi . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 ooOoOo = urllib2 . urlopen ( iIi )
 o00OO00OoO = ooOoOo . read ( )
 ooOoOo . close ( )
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return o00OO00OoO
 if 29 - 29: o0OO0 . Ooooo
def IIIii1II1II ( url ) :
 if 66 - 66: iI1 * Oo0ooO0oo0oO % Oo0ooO0oo0oO * O00OooO0 - IiIIIiI1I1 - O00OooO0
 iIi = urllib2 . Request ( url )
 iIi . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 ooOoOo = urllib2 . urlopen ( iIi )
 o00OO00OoO = ooOoOo . read ( )
 ooOoOo . close ( )
 return o00OO00OoO
 if 70 - 70: Ooooo + iI1
def II ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 93 - 93: Ooooo + ii1IiIi11
 if 33 - 33: o0OO0
 if 78 - 78: o0OO0 / o00 * I1I1i1
 if 50 - 50: I1i1iI1i - Oo0ooO0oo0oO + o00ooo0 % Ooooo - Oo0ooO0oo0oO % o0OO0
 if 58 - 58: O00OooO0 + Oo0ooO0oo0oO
def Oo00OO0OO ( ) :
 if 85 - 85: OOo0o0 % IiIIIiI1I1 . oO0 % Ooooo - I11iii11IIi
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 69 - 69: IiIIIiI1I1 - OOo0o0 . IiIIIiI1I1
 if os . path . exists ( Oooo000o ) == True :
  for iIiiIi11IIi , Oo0oO , II1ii1ii11I1 in os . walk ( Oooo000o ) :
   o0ooOO0o = 0
   o0ooOO0o += len ( II1ii1ii11I1 )
   if o0ooOO0o > 0 :
    for oOoO in II1ii1ii11I1 :
     try :
      if ( oOoO . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( iIiiIi11IIi , oOoO ) )
     except :
      pass
    for ooo0i1iI1i1I1 in Oo0oO :
     try :
      shutil . rmtree ( os . path . join ( iIiiIi11IIi , ooo0i1iI1i1I1 ) )
     except :
      pass
      if 99 - 99: IiIIIiI1I1 / Oo0ooO0oo0oO - ii1IiIi11 * OOoOoo00oo % Oo0oO0ooo
   else :
    pass
    if 13 - 13: I1I1i1
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for iIiiIi11IIi , Oo0oO , II1ii1ii11I1 in os . walk ( IiIi11iIIi1Ii ) :
   o0ooOO0o = 0
   o0ooOO0o += len ( II1ii1ii11I1 )
   if o0ooOO0o > 0 :
    for oOoO in II1ii1ii11I1 :
     try :
      if ( oOoO . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( iIiiIi11IIi , oOoO ) )
     except :
      pass
    for ooo0i1iI1i1I1 in Oo0oO :
     try :
      shutil . rmtree ( os . path . join ( iIiiIi11IIi , ooo0i1iI1i1I1 ) )
     except :
      pass
      if 70 - 70: Ooooo + o0OO0 . iI1 * ii1IiIi11
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iiII111iIII1Ii = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 19 - 19: iI1 * Oo0oO0ooo % i11iIiiIii
  for iIiiIi11IIi , Oo0oO , II1ii1ii11I1 in os . walk ( iiII111iIII1Ii ) :
   o0ooOO0o = 0
   o0ooOO0o += len ( II1ii1ii11I1 )
   if 24 - 24: OOo0o0
   if o0ooOO0o > 0 :
    for oOoO in II1ii1ii11I1 :
     os . unlink ( os . path . join ( iIiiIi11IIi , oOoO ) )
    for ooo0i1iI1i1I1 in Oo0oO :
     shutil . rmtree ( os . path . join ( iIiiIi11IIi , ooo0i1iI1i1I1 ) )
     if 10 - 10: OOo0o0 % ii1IiIi11 / OoOooOOOO
   else :
    pass
  i11Ii1iIiII = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 81 - 81: oooO . I1i1iI1i * oO0 % O00OooO0 . oooO
  for iIiiIi11IIi , Oo0oO , II1ii1ii11I1 in os . walk ( i11Ii1iIiII ) :
   o0ooOO0o = 0
   o0ooOO0o += len ( II1ii1ii11I1 )
   if 60 - 60: OoOooOOOO / Oo0oO0ooo
   if o0ooOO0o > 0 :
    for oOoO in II1ii1ii11I1 :
     os . unlink ( os . path . join ( iIiiIi11IIi , oOoO ) )
    for ooo0i1iI1i1I1 in Oo0oO :
     shutil . rmtree ( os . path . join ( iIiiIi11IIi , ooo0i1iI1i1I1 ) )
     if 78 - 78: oooO . O00OooO0
   else :
    pass
    if 38 - 38: oO0 + O00OooO0
 OOO00 = IiiI11Iiiii ( )
 if 15 - 15: I11iii11IIi + oooO . IiIIIiI1I1 - Oo0ooO0oo0oO / o0OO0 % Oo0ooO0oo0oO
 for oO0O in OOO00 :
  Oo00o0O0O = xbmc . translatePath ( oO0O . path )
  if os . path . exists ( Oo00o0O0O ) == True :
   for iIiiIi11IIi , Oo0oO , II1ii1ii11I1 in os . walk ( Oo00o0O0O ) :
    o0ooOO0o = 0
    o0ooOO0o += len ( II1ii1ii11I1 )
    if o0ooOO0o > 0 :
     for oOoO in II1ii1ii11I1 :
      os . unlink ( os . path . join ( iIiiIi11IIi , oOoO ) )
     for ooo0i1iI1i1I1 in Oo0oO :
      shutil . rmtree ( os . path . join ( iIiiIi11IIi , ooo0i1iI1i1I1 ) )
      if 84 - 84: oooO % o00ooo0
    else :
     pass
     if 33 - 33: OOoOoo00oo * OOoOoo00oo . IiIIIiI1I1 . i11iIiiIii
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 48 - 48: OOo0o0 . ii1IiIi11 + oO0 % OOoOoo00oo / i11iIiiIii
def OoO ( ) :
 i111i = [ ]
 II1III1i1iiI = sys . argv [ 2 ]
 if len ( II1III1i1iiI ) >= 2 :
  i111iI = sys . argv [ 2 ]
  I11i11i1 = i111iI . replace ( '?' , '' )
  if ( i111iI [ len ( i111iI ) - 1 ] == '/' ) :
   i111iI = i111iI [ 0 : len ( i111iI ) - 2 ]
  OOO = I11i11i1 . split ( '&' )
  i111i = { }
  for ii1iII1II in range ( len ( OOO ) ) :
   ii1i1iiI = { }
   ii1i1iiI = OOO [ ii1iII1II ] . split ( '=' )
   if ( len ( ii1i1iiI ) ) == 2 :
    i111i [ ii1i1iiI [ 0 ] ] = ii1i1iiI [ 1 ]
 return i111i
 if 94 - 94: o00ooo0 * o00ooo0 % o00 + OoOooOOOO
def Oo0oOOo ( name , url , mode , iconimage , fanart , description = '' ) :
 if 28 - 28: Oo0oO0ooo
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 o0000o0Oo = True
 i1iii1ii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1iii1ii . setProperty ( "fanart_Image" , fanart )
 i1iii1ii . setProperty ( "icon_Image" , iconimage )
 o0000o0Oo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11 , listitem = i1iii1ii , isFolder = True )
 return o0000o0Oo
 if 90 - 90: Oo0ooO0oo0oO * o00
def I1III ( name , url , mode , iconimage , fanart , description = '' ) :
 if 70 - 70: OOo0o0 * o00 - IiIIIiI1I1
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 o0000o0Oo = True
 i1iii1ii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1iii1ii . setProperty ( "fanart_Image" , fanart )
 i1iii1ii . setProperty ( "icon_Image" , iconimage )
 o0000o0Oo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11 , listitem = i1iii1ii , isFolder = False )
 return o0000o0Oo
 if 55 - 55: Oo0oO0ooo
i111iI = OoO ( ) ; i1IiiiI1iI = None ; i1OOO = None ; Ii1i1 = None ; oOoO00 = None ; IIiIi1iI = None ; i1II1Iiii1I11 = None
try : oOoO00 = urllib . unquote_plus ( i111iI [ "site" ] )
except : pass
try : i1IiiiI1iI = urllib . unquote_plus ( i111iI [ "url" ] )
except : pass
try : i1OOO = urllib . unquote_plus ( i111iI [ "name" ] )
except : pass
try : Ii1i1 = int ( i111iI [ "mode" ] )
except : pass
try : IIiIi1iI = urllib . unquote_plus ( i111iI [ "iconimage" ] )
except : pass
try : i1II1Iiii1I11 = urllib . unquote_plus ( i111iI [ "fanart" ] )
except : pass
if 45 - 45: ii1IiIi11 . I1i1iI1i
if Ii1i1 == None or i1IiiiI1iI == None or len ( i1IiiiI1iI ) < 1 : iii11 ( )
elif Ii1i1 == 1 : I1iI1iIi111i ( i1OOO , i1IiiiI1iI )
elif Ii1i1 == 2 : OoO000O0Oo ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 3 : ooiIi1 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 4 : PLAYSD ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 8 : iI1111iiii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 9 : AUTO_UPDATER ( i1OOO )
elif Ii1i1 == 10 : OOO0ooo ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 11 : IIii1111 ( )
elif Ii1i1 == 12 : IiiI1i ( i1IiiiI1iI )
elif Ii1i1 == 19 : i1iiIiI1Ii1i ( i1IiiiI1iI )
elif Ii1i1 == 20 : o0 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 21 : O00oOo00o0o ( i1IiiiI1iI )
elif Ii1i1 == 22 : ii1iI ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 23 : Oo0000oOo ( )
elif Ii1i1 == 24 : iII1i1 ( )
elif Ii1i1 == 25 : Ooo00Oo ( )
elif Ii1i1 == 26 : Ooo ( )
elif Ii1i1 == 30 : I11IIIi ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 40 : i1i ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 41 : oO0oooooo ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 50 : ooO0o ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 51 : II1i11i1iIi11 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 60 : iIIIiiiI11I ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 61 : ii1iI1II11ii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 70 : IiI1ii1Ii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 71 : oO000o ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 80 : ooooOoO0O ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 90 : i1I1i111Ii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 91 : iI1i111I1Ii ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 100 : i1II11Iii1I ( )
elif Ii1i1 == 500 : Oo00OO0OO ( )
elif Ii1i1 == 201 : OoO0O00O0oo0O ( )
elif Ii1i1 == 202 : OoOooOoO ( i1IiiiI1iI )
elif Ii1i1 == 203 : i11IIIiI11 ( i1IiiiI1iI )
elif Ii1i1 == 204 : iIIII ( i1IiiiI1iI )
elif Ii1i1 == 205 : OOOO0O00o ( i1IiiiI1iI )
elif Ii1i1 == 206 : iiIi1i ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 210 : ooo0o00 ( i1IiiiI1iI )
elif Ii1i1 == 220 : Oo0 ( i1IiiiI1iI )
elif Ii1i1 == 221 : o00o000oo ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 800 : o0O0O0 ( i1OOO , i1IiiiI1iI , IIiIi1iI )
elif Ii1i1 == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 27 - 27: ii1IiIi11 * I11iii11IIi . oO0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if Ii1i1 == 80 :
 xbmc . sleep ( 10000 )
 xbmc . executebuiltin ( 'Container.Refresh' )