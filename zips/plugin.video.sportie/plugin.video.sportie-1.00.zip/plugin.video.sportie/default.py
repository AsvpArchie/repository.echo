import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,urlresolver,liveresolver
import base64
import requests

addon_id        = 'plugin.video.sportie'
fanart          = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon            = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
baseurl 		= base64.decodestring('aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51LnhtbA==') 
                                                             
def GetMenu():

	link=open_url(baseurl)
	match= re.compile('<item>(.+?)</item>').findall(link)
	for item in match:
	
		if '<sportsdevil>' in item:
			links=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(item)
			if len(links)==1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]            
				url=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(item)[0]
				referer=re.compile('<referer>(.+?)</referer>').findall(item)[0]
				check = referer
				suffix = "/"
				if not check.endswith(suffix):
					refer = check + "/"
				else:
					refer = check
				link = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' +url
				url = link + '%26referer=' +refer
				addLink(name,url,4,iconimage,fanart)   
			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				addLink(name,url2,8,iconimage,fanart)       
                
		elif '<folder>'in item:
			data=re.compile('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
			for name,url,iconimage,fanart in data:
				addDir(name,url,1,iconimage,fanart)
		elif '<m3u>'in item:
			data=re.compile('<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
			for name,url,iconimage,fanart in data:
				addDir(name,url,10,iconimage,fanart)
		else:
			links=re.compile('<link>(.+?)</link>').findall(item)
			if len(links)==1:
				data=re.compile('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
				lcount=len(match)
				for name,url,iconimage,fanart in data:
					addLink(name,url,2,iconimage,fanart)
			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]
				addLink(name,baseurl,3,iconimage,fanart)
                        
def GetContent(name,url,iconimage,fanart):

	url2 = url
	link=open_url(url)

	match= re.compile('<item>(.+?)</item>').findall(link)
	for item in match:
		if '<sportsdevil>' in item:
			links=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(item)
			if len(links)==1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]            
				url=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(item)[0]
				referer=re.compile('<referer>(.+?)</referer>').findall(item)[0]
				check = referer
				suffix = "/"
				if not check.endswith(suffix):
					refer = check + "/"
				else:
					refer = check
				link = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' +url
				url = link + '%26referer=' +refer
				addLink(name,url,4,iconimage,fanart)   

			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				addLink(name,url2,8,iconimage,fanart)

		elif '<folder>'in item:
			data=re.compile('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
			for name,url,iconimage,fanart in data:
				addDir(name,url,1,iconimage,fanart)
		elif '<m3u>'in item:
			data=re.compile('<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
			for name,url,iconimage,fanart in data:
				addDir(name,url,10,iconimage,fanart)
		else:
			links=re.compile('<link>(.+?)</link>').findall(item)
			if len(links)==1:
				data=re.compile('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
				lcount=len(match)
				for name,url,iconimage,fanart in data:
					addLink(name,url,2,iconimage,fanart)
			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]
				addLink(name,url2,3,iconimage,fanart)  
                        
def GETMULTI(name,url,iconimage):
	streamurl=[]
	streamname=[]
	streamicon=[]
	link=open_url(url)
	urls=re.compile('<title>'+re.escape(name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
	iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(urls)[0]
	links=re.compile('<link>(.+?)</link>').findall(urls)
	i=1
	for sturl in links:
                sturl2=sturl
                if '(' in sturl:
                        sturl=sturl.split('(')[0]
                        caption=str(sturl2.split('(')[1].replace(')',''))
                        streamurl.append(sturl)
                        streamname.append(caption)
                else:
                        streamurl.append( sturl )
                        streamname.append( 'Link '+str(i) )
                i=i+1
	name='[COLOR red]'+name+'[/COLOR]'
	dialog = xbmcgui.Dialog()
	select = dialog.select(name,streamname)
	if select < 0:
		quit()
	else:
		url = streamurl[select]
		print url
		if urlresolver.HostedMediaFile(url).valid_url(): stream_url = urlresolver.HostedMediaFile(url).resolve()
                elif liveresolver.isValid(url)==True: stream_url=liveresolver.resolve(url)
                else: stream_url=url
                liz = xbmcgui.ListItem(name,iconImage='DefaultVideo.png', thumbnailImage=iconimage)
                liz.setPath(stream_url)
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
                
def GETMULTI_SD(name,url,iconimage):

    sdbase = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url='
    streamurl=[]
    streamname=[]
    streamicon=[]
    streamnumber=[]
    link=open_url(url)
    urls=re.compile('<title>'+re.escape(name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
    links=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(urls)
    iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(urls)[0]
    i=1

    for sturl in links:
                sturl2=sturl
                if '(' in sturl:
                        sturl=sturl.split('(')[0]
                        caption=str(sturl2.split('(')[1].replace(')',''))
                        streamurl.append(sturl)
                        streamname.append(caption)
                        streamnumber.append('Stream ' + str(i))
                else:
                        streamurl.append( sturl )
                        streamname.append( 'Link '+str(i) )

                i=i+1

    name='[COLOR red]'+name+'[/COLOR]'

    dialog = xbmcgui.Dialog()
    select = dialog.select(name,streamname)
    if select < 0:
        quit()
    else:
        check = streamname[select]
        suffix = "/"
        if not check.endswith(suffix):
              refer = check + "/"
        else:
              refer = check
        url = sdbase + streamurl[select] + "%26referer=" + refer
        print url

        xbmc.Player().play(url)

def PLAYSD(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage); liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        xbmc.Player ().play(url, liz, False)

def READ_M3U(name,url,iconimage):

    list = CREATE_M3U_LIST(url)
    for channel in list:
        name = GetEncodeString(channel["display_name"])
        url = GetEncodeString(channel["url"])
        url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
        addLink(name ,url, 2, '', '','')

def CREATE_M3U_LIST(url):

    response = requests.get(url)
    response = response.content
    response = response.replace('#AAASTREAM:','#A:')
    response = response.replace('#EXTINF:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
    li = []
    for params, display_name, url in matches:
        item_data = {"params": params, "display_name": display_name, "url": url}
        li.append(item_data)
    list = []
    for channel in li:
        item_data = {"display_name": channel["display_name"], "url": channel["url"]}
        matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
        for field, value in matches:
            item_data[field.strip().lower().replace('-', '_')] = value.strip()
        list.append(item_data)
	
    return list

def PLAYLINK(name,url,iconimage):

	if not'http'in url:url='http://'+url

	if "plugin://" in url:
		url = "PlayMedia("+url+")"
		xbmc.executebuiltin(url)	
		quit()
	elif urlresolver.HostedMediaFile(url).valid_url(): stream_url = urlresolver.HostedMediaFile(url).resolve()
	elif liveresolver.isValid(url)==True: stream_url=liveresolver.resolve(url)
	else: stream_url=url
	liz = xbmcgui.ListItem(name,iconImage='DefaultVideo.png', thumbnailImage=iconimage)
	liz.setPath(stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def open_url(url):

    req = urllib2.Request(url)
    req.add_header('User-Agent', base64.b64decode(b'VGhlV2l6YXJkSXNIZXJl'))
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    link=link.replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')#.replace('></','>x</')
    return link
	
def GetEncodeString(str):
	try:
		import chardet
		str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
	except:
		try:
			str = str.encode("utf-8")
		except:
			pass
	return str

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]                    
        return param
	
def addDir(name,url,mode,iconimage,fanart,description=''):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)+"&fanart="+urllib.quote_plus(fanart)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
    liz.setProperty('fanart_image', fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addLink(name, url, mode, iconimage, fanart, description=''):

	if '.ts'in url:
		url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name='+name+'&amp;url='+url
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	if not "plugin://" in url:
		liz.setProperty("IsPlayable","true")
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: fanart=urllib.unquote_plus(params["fanart"])
except: pass
 
if mode==None or url==None or len(url)<1: GetMenu()
elif mode==1:GetContent(name,url,iconimage,fanart)
elif mode==2:PLAYLINK(name,url,iconimage)
elif mode==3:GETMULTI(name,url,iconimage)
elif mode==4:PLAYSD(name,url,iconimage)
elif mode==8:GETMULTI_SD(name,url,iconimage)
elif mode==10:READ_M3U(name,url,iconimage)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
