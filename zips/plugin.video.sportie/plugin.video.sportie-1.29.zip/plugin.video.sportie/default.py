import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluX21lbnUueG1s' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = xbmc . translatePath ( 'special://home/addons/program.plexus' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
Oooo000o = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oo0O = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
OOo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
Ii1IIii11 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 55 - 55: i1111 - i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
oO000OoOoo00o = plugintools . get_setting ( "scrape1" )
iiiI11 = plugintools . get_setting ( "scrape2" )
OOooO = plugintools . get_setting ( "scrape3" )
if 58 - 58: i11iiII + OooooO0oOO + oOo0 / oo0Ooo0
I1I11I1I1I = IiiIII111iI + '|SPLIT|' + o0O
checker . check ( I1I11I1I1I )
if 90 - 90: i1IIiiiii + i1iIIIiI1I - OoO000 % OooOoO0Oo + iiIIiIiIi
if not os . path . isfile ( ooo0OO ) :
 plugintools . open_settings_dialog ( )
 if 38 - 38: i1IIiiiii / I11i1i11i1I
if not os . path . exists ( IiII ) :
 os . makedirs ( IiII )
 if 76 - 76: oooO0oo0oOOOO / oo0ooO0oOOOOo . i1IIi11111i * i1IIiiiii - oOo0
if not os . path . isfile ( i1i1II ) :
 Oooo = open ( i1i1II , 'w' )
 if 67 - 67: oOo0 / i111I % oo0Ooo0 - ooO0oo0oO0
if not os . path . isfile ( iI1Ii11111iIi ) :
 Oooo = open ( iI1Ii11111iIi , 'w' )
 if 82 - 82: i11iIiiIii . oOo0 / I11i1i11i1I * oooO0oo0oOOOO % OooooO0oOO % ooO0oo0oO0
if not os . path . isfile ( O0oo0OO0 ) :
 Oooo = open ( O0oo0OO0 , 'w' )
 if 78 - 78: ooO0oo0oO0 - i1IIiiiii * oo + oo0ooO0oOOOOo + i1iIIIiI1I + i1iIIIiI1I
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 11 - 11: i1iIIIiI1I - oo % iiIIiIiIi % i1iIIIiI1I / OOO0O - oo
class o0o0oOOOo0oo ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 80 - 80: oo0Ooo0 * i11iIiiIii / OooOoO0Oo
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 9 - 9: i1IIiiiii + OooooO0oOO % i1IIiiiii + II1Ii1iI1i . oOo0
III1i1i = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 26 - 26: i111I
class IiiI11Iiiii :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 18 - 18: oo0ooO0oOOOOo
  if 28 - 28: oOo0 - OoO000 . OoO000 + OOO0O - i111I + oooO0oo0oOOOO
  if 95 - 95: oo % OooooO0oOO . oooO0oo0oOOOO
  if 15 - 15: iiIIiIiIi / i1IIiiiii . i1IIiiiii - II1Ii1iI1i
def o00oOO0 ( ) :
 oOoo = 5
 iIii11I = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 OOO0OOO00oo = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 31 - 31: i1111 - oOo0 . OooOoO0Oo % OOO0O - oooO0oo0oOOOO
 iii11 = [ ]
 if 58 - 58: oOo0 * i11iIiiIii / OOO0O % OooOoO0Oo - i11iiII / OooooO0oOO
 for ii11i1 in range ( oOoo ) :
  iii11 . append ( IiiI11Iiiii ( iIii11I [ ii11i1 ] , OOO0OOO00oo [ ii11i1 ] ) )
  if 29 - 29: i11iiII % i1IIi11111i + iiIIiIiIi / oo0ooO0oOOOOo + oOo0 * oo0ooO0oOOOOo
 return iii11
 if 42 - 42: i1IIiiiii + OooooO0oOO
def o0O0o0Oo ( ) :
 if 16 - 16: oooO0oo0oOOOO - OooOoO0Oo * ooO0oo0oO0 + i1iIIIiI1I
 Ii11iII1 = Oo0O0O0ooO0O ( OOo )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = i1i1II
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 70 - 70: OoO000 * I11i1i11i1I * oo0Ooo0 / i1IIiiiii
 Ii11iII1 = Oo0O0O0ooO0O ( iiI1iIiI )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = iI1Ii11111iIi
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 88 - 88: oooO0oo0oOOOO
 Ii11iII1 = Oo0O0O0ooO0O ( Ii1IIii11 )
 if len ( Ii11iII1 ) > 1 :
  IIIIii = O0oo0OO0
  O0o0 = open ( IIIIii )
  OO00Oo = O0o0 . read ( )
  if OO00Oo == Ii11iII1 : pass
  else :
   O0OOO0OOoO0O = open ( IIIIii , "w" )
   O0OOO0OOoO0O . write ( Ii11iII1 )
   O0OOO0OOoO0O . close ( )
   if 64 - 64: oo0Ooo0 * oooO0oo0oOOOO + OoO000 - oOo0 + i11iIiiIii * i1IIiiiii
 iII = o0 ( II1 )
 ooOooo000oOO = II1
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 80 - 80: OooooO0oOO + oOo0 - oOo0 % i1iIIIiI1I
  if '<search>display</search>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 97 - 97: iiIIiIiIi % i1iIIIiI1I * i1IIiiiii + oo0ooO0oOOOOo . oOo0 + oOo0
  elif '<arenavision>display</arenavision>' in Oo0OoO00oOO0o :
   if os . path . exists ( oO00oOo ) :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    II11i1I11Ii1i ( OoOO0oo0o , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
    if 59 - 59: ooO0oo0oO0 * i11iIiiIii / i11iiII * II1Ii1iI1i * oooO0oo0oOOOO
  elif '<vip>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 83 - 83: oo / OooOoO0Oo . OOO0O / OoO000 . OOO0O . oOo0
  elif '<divider>null</divider>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( OoOO0oo0o , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 96 - 96: I11i1i11i1I
   if 45 - 45: oooO0oo0oOOOO * oo0ooO0oOOOOo % I11i1i11i1I * i111I + i1iIIIiI1I . OOO0O
   if 67 - 67: i11iIiiIii - II1Ii1iI1i % i11iiII . oooO0oo0oOOOO
   if 77 - 77: OoO000 / i1IIi11111i
   if 15 - 15: OoO000 . ooO0oo0oO0 . i111I / i11iIiiIii - i1IIiiiii . II1Ii1iI1i
   if 33 - 33: oo0Ooo0 . oo0ooO0oOOOOo
  elif '<m3ulists>display</m3ulists>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   II11i1I11Ii1i ( OoOO0oo0o , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 75 - 75: oo0ooO0oOOOOo % oo0ooO0oOOOOo . OooOoO0Oo
   if 5 - 5: oo0ooO0oOOOOo * iiIIiIiIi + OOO0O . oOo0 + OOO0O
   if 91 - 91: oooO0oo0oOOOO
   if 61 - 61: i1111
   if 64 - 64: iiIIiIiIi / OOO0O - oooO0oo0oOOOO - oo0Ooo0
   if 86 - 86: oo0Ooo0 % OOO0O / i1IIi11111i / OOO0O
   if 42 - 42: oo
   if 67 - 67: OooOoO0Oo . i1iIIIiI1I . oooO0oo0oOOOO
   if 10 - 10: i11iiII % i11iiII - ooO0oo0oO0 / oOo0 + i1IIiiiii
   if 87 - 87: OooooO0oOO * i11iiII + oOo0 / ooO0oo0oO0 / i1iIIIiI1I
   if 37 - 37: i1iIIIiI1I - iiIIiIiIi * OooooO0oOO % i11iIiiIii - OooOoO0Oo
   if 83 - 83: oo0Ooo0 / i1IIi11111i
   if 34 - 34: OoO000
   if 57 - 57: OooooO0oOO . oo0Ooo0 . II1Ii1iI1i
   if 42 - 42: oo0Ooo0 + i11iiII % oooO0oo0oOOOO
   if 6 - 6: OooooO0oOO
   if 68 - 68: OOO0O - oo
   if 28 - 28: oo . oOo0 / oOo0 + I11i1i11i1I . i11iiII
   if 1 - 1: ooO0oo0oO0 / i1111
   if 33 - 33: oo0Ooo0
   if 18 - 18: oo0ooO0oOOOOo % i1iIIIiI1I * oooO0oo0oOOOO
   if 87 - 87: i11iIiiIii
  elif '<sportsdevil>' in Oo0OoO00oOO0o :
   OO0Oooo0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O000oo = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    IIi1I11I1II = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    OooOoooOo = IIi1I11I1II
    ii11IIII11I = "/"
    if not OooOoooOo . endswith ( ii11IIII11I ) :
     OOooo = OooOoooOo + "/"
    else :
     OOooo = OooOoooOo
    iII = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( OoOO0oo0o ) + '%26url=' + O000oo
    O000oo = iII + '%26referer=' + OOooo
    O0oOoOO ( OoOO0oo0o , O000oo , 4 , Oo0oOOOoOooOo , oOooOOOoOo )
   elif len ( OO0Oooo0 ) > 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O0oOoOO ( OoOO0oo0o , ooOooo000oOO + 'NOTPLAY' , 8 , Oo0oOOOoOooOo , oOooOOOoOo )
  elif '<plexus>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   O0oOoOO ( OoOO0oo0o , ooOooo000oOO + 'NOTPLAY' , 7 , Oo0oOOOoOooOo , oOooOOOoOo )
  elif '<rutubeplaylist>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   II11i1I11Ii1i ( OoOO0oo0o , ooOooo000oOO , 90 , Oo0oOOOoOooOo , oOooOOOoOo )
  elif '<folder>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for OoOO0oo0o , O000oo , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    II11i1I11Ii1i ( OoOO0oo0o , O000oo , 1 , Oo0oOOOoOooOo , oOooOOOoOo )
  elif '<m3u>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for OoOO0oo0o , O000oo , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    II11i1I11Ii1i ( OoOO0oo0o , O000oo , 10 , Oo0oOOOoOooOo , oOooOOOoOo )
  else :
   OO0Oooo0 = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
    OOoO00 = len ( Oo0oOOo )
    for OoOO0oo0o , O000oo , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
     O0oOoOO ( OoOO0oo0o , O000oo , 2 , Oo0oOOOoOooOo , oOooOOOoOo )
   elif len ( OO0Oooo0 ) > 1 :
    OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    O0oOoOO ( OoOO0oo0o , II1 , 3 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 40 - 40: i1IIi11111i * i1IIiiiii + oOo0 % i1iIIIiI1I
 OOOOOoo0 = open ( IIi1IiiiI1Ii ) . read ( )
 ii1 = OOOOOoo0 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo0oOOo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ii1 ) )
 for Oo0OoO00oOO0o in Oo0oOOo :
  I1iI1iIi111i = float ( Oo0OoO00oOO0o )
 OOOOOoo0 = open ( I11i11Ii ) . read ( )
 ii1 = OOOOOoo0 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo0oOOo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ii1 ) )
 for Oo0OoO00oOO0o in Oo0oOOo :
  iiIi1IIi1I = float ( Oo0OoO00oOO0o )
  if 84 - 84: iiIIiIiIi * i1111 + I11i1i11i1I
 O0oOoOO ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( I1iI1iIi111i ) + "[/COLOR]" , 'url' , 999 , iiiii , oOooOOOoOo , '' )
 O0oOoOO ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( iiIi1IIi1I ) + "[/COLOR]" , 'url' , 999 , iiiii , oOooOOOoOo , '' )
 if 53 - 53: i1iIIIiI1I % i1111 . OoO000 - ooO0oo0oO0 - OoO000 * i1111
 ooO0oOOooOo0 = i1I1ii11i1Iii ( )
 if 26 - 26: oo0Ooo0 - ooO0oo0oO0 - i1IIi11111i / oo . OOO0O % ooO0oo0oO0
 if ooO0oOOooOo0 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif ooO0oOOooOo0 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 91 - 91: oo0ooO0oOOOOo . ooO0oo0oO0 / OooooO0oOO + II1Ii1iI1i
def I1i ( name , url ) :
 if 53 - 53: i11iiII * OOO0O + iiIIiIiIi - i1111
 hash = [ ]
 ooOooo000oOO = url
 iII = o0 ( url )
 if 2 - 2: oo0Ooo0 + i1IIiiiii - i1IIi11111i % oo0ooO0oOOOOo . i1iIIIiI1I
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 18 - 18: oOo0 + i1iIIIiI1I - i1IIiiiii . i1111 + i11iIiiIii
  if '<search>' in Oo0OoO00oOO0o :
   if 20 - 20: OooOoO0Oo
   OO0Oooo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = name + "!" + url + "!" + Oo0oOOOoOooOo
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    II11i1I11Ii1i ( name , url , 20 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
    if 52 - 52: i1111 - i111I % i1IIiiiii + i1IIi11111i * I11i1i11i1I . OoO000
   elif len ( OO0Oooo0 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = ooOooo000oOO + "!" + name + "!" + Oo0oOOOoOooOo
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    II11i1I11Ii1i ( name , url , 22 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
    if 75 - 75: iiIIiIiIi + OOO0O + oo0ooO0oOOOOo * oo0Ooo0 % OooooO0oOO . i1iIIIiI1I
  elif '<regex>' in Oo0OoO00oOO0o :
   oO = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Oo0OoO00oOO0o )
   oO = '' . join ( oO )
   I1Ii1I1 = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( oO )
   oO = urllib . quote_plus ( oO )
   if 28 - 28: oooO0oo0oOOOO * I11i1i11i1I - oOo0 % ooO0oo0oO0 * i1IIiiiii - i11iIiiIii
   IIII11 = hashlib . md5 ( )
   for IIIIii1I in oO : IIII11 . update ( str ( IIIIii1I ) )
   IIII11 = str ( IIII11 . hexdigest ( ) )
   if 39 - 39: i1111 / iiIIiIiIi + OooOoO0Oo / OOO0O
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Oo0OoO00oOO0o = re . sub ( '<regex>.+?</regex>' , '' , Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Oo0OoO00oOO0o )
   Oo0OoO00oOO0o = re . sub ( '<link></link>' , '' , Oo0OoO00oOO0o )
   if 13 - 13: OoO000 + oooO0oo0oOOOO + i1iIIIiI1I % i1IIi11111i / oo0ooO0oOOOOo . OoO000
   name = re . sub ( '<meta>.+?</meta>' , '' , Oo0OoO00oOO0o )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 86 - 86: OooooO0oOO * oo0ooO0oOOOOo % II1Ii1iI1i . i1IIiiiii . i11iIiiIii
   try : oOOoo00O00o = re . findall ( '<date>(.+?)</date>' , Oo0OoO00oOO0o ) [ 0 ]
   except : oOOoo00O00o = ''
   if re . search ( r'\d+' , oOOoo00O00o ) : name += ' [COLOR red] Updated %s[/COLOR]' % oOOoo00O00o
   if 98 - 98: oOo0 + OoO000 + OooooO0oOO % i111I
   try : oooooo0O000o = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Oo0OoO00oOO0o ) [ 0 ]
   except : oooooo0O000o = iiiii
   if 64 - 64: i1IIi11111i . oo0ooO0oOOOOo - OooOoO0Oo / i111I
   try : O0O0ooOOO = re . findall ( '<fanart>(.+?)</fanart>' , Oo0OoO00oOO0o ) [ 0 ]
   except : O0O0ooOOO = O0O0OO0O0O0
   if 77 - 77: OOO0O - i1111 - iiIIiIiIi
   try : IiiiIIiIi1 = re . findall ( '<meta>(.+?)</meta>' , Oo0OoO00oOO0o ) [ 0 ]
   except : IiiiIIiIi1 = '0'
   if 74 - 74: ooO0oo0oO0 * i11iiII + OOO0O / II1Ii1iI1i / i1111 . I11i1i11i1I
   try : url = re . findall ( '<link>(.+?)</link>' , Oo0OoO00oOO0o ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % IiiiIIiIi1 )
   url = '<preset>search</preset>%s' % IiiiIIiIi1 if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % IiiiIIiIi1 )
   url = '<preset>searchsd</preset>%s' % IiiiIIiIi1 if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 62 - 62: i111I * i1IIi11111i
   if not oO == '' :
    hash . append ( { 'regex' : IIII11 , 'response' : oO } )
    url += '|regex=%s' % oO
    if 58 - 58: OOO0O % oo0ooO0oOOOOo
   O0oOoOO ( name , url , 30 , oooooo0O000o , O0O0ooOOO )
   if 50 - 50: OooOoO0Oo . oo0ooO0oOOOOo
  elif '<sportsdevil>' in Oo0OoO00oOO0o :
   OO0Oooo0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     IIi1I11I1II = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : IIi1I11I1II = "None"
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    OooOoooOo = IIi1I11I1II
    ii11IIII11I = "/"
    if not OooOoooOo . endswith ( ii11IIII11I ) :
     OOooo = OooOoooOo + "/"
    else :
     OOooo = OooOoooOo
    iII = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = iII + '%26referer=' + OOooo
    O0oOoOO ( name , url , 2 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 97 - 97: oooO0oo0oOOOO + OOO0O
   elif len ( OO0Oooo0 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    O0oOoOO ( name , ooOooo000oOO + 'NOTPLAY' , 8 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 89 - 89: oo0ooO0oOOOOo + oo * oo0Ooo0 * i1IIiiiii
  elif '<plexus>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   O0oOoOO ( name , ooOooo000oOO + 'NOTPLAY' , 7 , Oo0oOOOoOooOo , oOooOOOoOo )
   if 37 - 37: i111I - oooO0oo0oOOOO - oo0ooO0oOOOOo
  elif '<rutubeplaylist>' in Oo0OoO00oOO0o :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : oOooOOOoOo = O0O0OO0O0O0
   II11i1I11Ii1i ( name , ooOooo000oOO , 90 , Oo0oOOOoOooOo , oOooOOOoOo )
   if 77 - 77: oOo0 * ooO0oo0oO0
  elif '<folder>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    II11i1I11Ii1i ( name , url , 1 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 98 - 98: i1IIi11111i % i1IIiiiii * i111I
  elif '<m3u>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    II11i1I11Ii1i ( name , url , 10 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 51 - 51: ooO0oo0oO0 . OOO0O / OooooO0oOO + oo0ooO0oOOOOo
  elif '<rutube>' in Oo0OoO00oOO0o :
   i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?rutube>(.+?)</rutube>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
   for name , url , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
    ooOooo000oOO = 'https://rutube.ru/play/embed/' + url + '?wmode=opaque&fakeFullscreen=1'
    II11i1I11Ii1i ( name , ooOooo000oOO , 2 , Oo0oOOOoOooOo , oOooOOOoOo )
  else :
   OO0Oooo0 = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o )
   if len ( OO0Oooo0 ) == 1 :
    i1Iii1i1I = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o )
    OOoO00 = len ( Oo0oOOo )
    for name , url , Oo0oOOOoOooOo , oOooOOOoOo in i1Iii1i1I :
     O0oOoOO ( name , url , 2 , Oo0oOOOoOooOo , oOooOOOoOo )
   elif len ( OO0Oooo0 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oOooOOOoOo = O0O0OO0O0O0
    O0oOoOO ( name , ooOooo000oOO , 3 , Oo0oOOOoOooOo , oOooOOOoOo )
    if 33 - 33: iiIIiIiIi . i1111 % i1iIIIiI1I + oo0ooO0oOOOOo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 71 - 71: I11i1i11i1I % oOo0
def O00oO000O0O ( name , url , iconimage ) :
 I1i1i1iii = [ ]
 I1111i = [ ]
 iIIii = [ ]
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o00O0O ) [ 0 ]
 OO0Oooo0 = re . compile ( '<link>(.+?)</link>' ) . findall ( o00O0O )
 IIIIii1I = 1
 for ii1iii1i in OO0Oooo0 :
  Iii1I1111ii = ii1iii1i
  if '(' in ii1iii1i :
   ii1iii1i = ii1iii1i . split ( '(' ) [ 0 ]
   ooOoO00 = str ( Iii1I1111ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( ooOoO00 )
  else :
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( 'Link ' + str ( IIIIii1I ) )
  IIIIii1I = IIIIii1I + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 Ii1IIiI1i = O00ooooo00 . select ( name , I1111i )
 if Ii1IIiI1i < 0 :
  quit ( )
 else :
  url = I1i1i1iii [ Ii1IIiI1i ]
  print url
  if 78 - 78: i11iiII
 url = I1i1i1iii [ Ii1IIiI1i ]
 name = I1111i [ Ii1IIiI1i ]
 o0Oo0oO0oOO00 ( name , url , iiiii )
 if 92 - 92: i111I * OooOoO0Oo
def o0000oO ( name , url , iconimage ) :
 if 11 - 11: iiIIiIiIi / OOO0O - OoO000 * i111I + i111I . OOO0O
 I1i1i1iii = [ ]
 I1111i = [ ]
 iIIii = [ ]
 i1I1i111Ii = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 OO0Oooo0 = re . compile ( '<plexus>(.+?)</plexus>' ) . findall ( o00O0O )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o00O0O ) [ 0 ]
 if 67 - 67: i1IIi11111i . II1Ii1iI1i
 i1i1iI1iiiI = "plugin://program.plexus/?url="
 Ooo0oOooo0 = "&mode=1&name=acestream+"
 IIIIii1I = 0
 if 61 - 61: OOO0O - oOo0 - II1Ii1iI1i
 for ii1iii1i in OO0Oooo0 :
  IIIIii1I = IIIIii1I + 1
  if 25 - 25: oooO0oo0oOOOO * oo0Ooo0 + i11iiII . oo0ooO0oOOOOo . oo0ooO0oOOOOo
  Iii1I1111ii = ii1iii1i
  if '(' in ii1iii1i :
   ii1iii1i = ii1iii1i . split ( '(' ) [ 0 ]
   ooOoO00 = str ( Iii1I1111ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( ooOoO00 )
   i1I1i111Ii . append ( 'Stream ' + str ( IIIIii1I ) )
  else :
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( 'Link ' + str ( IIIIii1I ) )
   ooOoO00 = name
   if 58 - 58: i1IIi11111i
   if 53 - 53: II1Ii1iI1i
 if IIIIii1I > 1 :
  O00ooooo00 = xbmcgui . Dialog ( )
  Ii1IIiI1i = O00ooooo00 . select ( name , I1111i )
  if Ii1IIiI1i < 0 :
   quit ( )
  else :
   o0OOOoO0 = I1i1i1iii [ Ii1IIiI1i ]
   if not 'acestream://' in o0OOOoO0 :
    o0OOOoO0 = 'acestream://' + o0OOOoO0
   url = i1i1iI1iiiI + o0OOOoO0 + Ooo0oOooo0 + I1111i [ Ii1IIiI1i ]
   name = I1111i [ Ii1IIiI1i ]
 else :
  o0OOOoO0 = ii1iii1i
  if not 'acestream://' in o0OOOoO0 :
   o0OOOoO0 = 'acestream://' + o0OOOoO0
  url = i1i1iI1iiiI + o0OOOoO0 + Ooo0oOooo0 + ooOoO00
  name = ooOoO00
  if 73 - 73: oo0Ooo0 % i11iIiiIii - i1IIi11111i
 o0Oo0oO0oOO00 ( name , url , iiiii )
 if 7 - 7: oooO0oo0oOOOO * i11iIiiIii * i1IIiiiii + iiIIiIiIi % oo - iiIIiIiIi
def II1IIIIiII1i ( name , url , iconimage ) :
 if 1 - 1: i1111
 I1i1i1iii = [ ]
 I1111i = [ ]
 iIIii = [ ]
 i1I1i111Ii = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 OO0Oooo0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( o00O0O )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o00O0O ) [ 0 ]
 if 68 - 68: i1iIIIiI1I - i1IIi11111i / OooOoO0Oo / oo0Ooo0
 I11iiii = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 60 - 60: oo0Ooo0 . II1Ii1iI1i + OoO000 / oo0ooO0oOOOOo . i1111
 IIIIii1I = 1
 if 82 - 82: i11iiII / i1IIi11111i % ooO0oo0oO0 / II1Ii1iI1i - i1IIi11111i
 for ii1iii1i in OO0Oooo0 :
  Iii1I1111ii = ii1iii1i
  if '(' in ii1iii1i :
   ii1iii1i = ii1iii1i . split ( '(' ) [ 0 ]
   ooOoO00 = str ( Iii1I1111ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( ooOoO00 )
   i1I1i111Ii . append ( 'Stream ' + str ( IIIIii1I ) )
  else :
   I1i1i1iii . append ( ii1iii1i )
   I1111i . append ( 'Link ' + str ( IIIIii1I ) )
   if 7 - 7: OooOoO0Oo * oo - iiIIiIiIi + oOo0 * i1IIi11111i % oo
  IIIIii1I = IIIIii1I + 1
  if 15 - 15: OOO0O % i1IIi11111i * oo0Ooo0
 name = '[COLOR red]' + name + '[/COLOR]'
 if 81 - 81: iiIIiIiIi - ooO0oo0oO0 - II1Ii1iI1i / OooOoO0Oo - oooO0oo0oOOOO * oo0Ooo0
 O00ooooo00 = xbmcgui . Dialog ( )
 Ii1IIiI1i = O00ooooo00 . select ( name , I1111i )
 if Ii1IIiI1i < 0 :
  quit ( )
 else :
  OooOoooOo = I1111i [ Ii1IIiI1i ]
  ii11IIII11I = "/"
  if not OooOoooOo . endswith ( ii11IIII11I ) :
   OOooo = OooOoooOo + "/"
  else :
   OOooo = OooOoooOo
  url = I11iiii + I1i1i1iii [ Ii1IIiI1i ] + "%26referer=" + OOooo
  if 20 - 20: OooooO0oOO % OoO000
 name = I1111i [ Ii1IIiI1i ]
 o0Oo0oO0oOO00 ( name , url , iiiii )
 if 19 - 19: i11iiII % OoO000 + iiIIiIiIi / OooOoO0Oo . iiIIiIiIi
def IiIi1I1 ( name , url , iconimage ) :
 if 39 - 39: i1111 + OOO0O - iiIIiIiIi . OOO0O
 OOOooo = [ ]
 OooO0OO = [ ]
 if 69 - 69: iiIIiIiIi % OooooO0oOO
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 OO0Oooo0 = re . compile ( '<rutubeplaylist>(.+?)</rutubeplaylist>' ) . findall ( o00O0O )
 if 50 - 50: i111I % oo0Ooo0
 for ii1iii1i in OO0Oooo0 :
  Iii1I1111ii = ii1iii1i
  if '(' in ii1iii1i :
   ii1iii1i = ii1iii1i . split ( '(' ) [ 0 ]
   ooOoO00 = str ( Iii1I1111ii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   OOOooo . append ( ooOoO00 )
   OooO0OO . append ( ii1iii1i )
   IIii1111 = list ( zip ( OOOooo , OooO0OO ) )
   if 42 - 42: oo0Ooo0 / oo0ooO0oOOOOo . OooooO0oOO + OooooO0oOO % OOO0O + i11iIiiIii
 oo0o0000 = sorted ( IIii1111 )
 if 11 - 11: ooO0oo0oO0
 for IiIIII1i11I , url in oo0o0000 :
  OOO = o0 ( url )
  Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   iII1 = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
   if IiIIII1i11I . lower ( ) == "all" :
    iII1 = iII1 . replace ( '.' , ' ' )
    O0oOoOO ( iII1 , url , 2 , iconimage , iconimage , '' )
   elif IiIIII1i11I . lower ( ) in iII1 . lower ( ) :
    iII1 = iII1 . replace ( '.' , ' ' )
    O0oOoOO ( iII1 , url , 2 , iconimage , iconimage , '' )
    if 57 - 57: oo0ooO0oOOOOo . II1Ii1iI1i . OoO000 * i11iIiiIii + OooOoO0Oo . OoO000
 try :
  Oo0oOOo = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( OOO )
  oo0O00Oooo0O0 = str ( Oo0oOOo )
  I11 = re . compile ( 'href="(.+?)"' ) . findall ( oo0O00Oooo0O0 ) [ 1 ]
  url = I11 + "|SPLIT|" + IiIIII1i11I
  II11i1I11Ii1i ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 51 - 51: oo . i1IIi11111i * iiIIiIiIi % i1IIiiiii + i1111 . iiIIiIiIi
def iI1IiI11ii1I1 ( name , url , iconimage ) :
 if 32 - 32: i11iIiiIii
 url , IiIIII1i11I = url . split ( "|SPLIT|" )
 if 31 - 31: ooO0oo0oO0 / oo / i11iiII
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  iII1 = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
  if IiIIII1i11I . lower ( ) == "all" :
   iII1 = iII1 . replace ( '.' , ' ' )
   O0oOoOO ( iII1 , url , 2 , iconimage , iconimage , '' )
  elif IiIIII1i11I . lower ( ) in iII1 . lower ( ) :
   iII1 = iII1 . replace ( '.' , ' ' )
   O0oOoOO ( iII1 , url , 2 , iconimage , iconimage , '' )
   if 41 - 41: I11i1i11i1I
 try :
  Oo0oOOo = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( OOO )
  oo0O00Oooo0O0 = str ( Oo0oOOo )
  I11 = re . compile ( 'href="(.+?)"' ) . findall ( oo0O00Oooo0O0 ) [ 1 ]
  url = I11 + "|SPLIT|" + IiIIII1i11I
  II11i1I11Ii1i ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 10 - 10: I11i1i11i1I / I11i1i11i1I / OooOoO0Oo . OooOoO0Oo
def OOoo ( name , url , iconimage ) :
 if 50 - 50: oo
 O0o0 , ii11i1 = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 O0o0 += urllib . unquote_plus ( ii11i1 )
 url = regex . resolve ( O0o0 )
 if 43 - 43: i1111 . OooooO0oOO / i11iiII
 o0Oo0oO0oOO00 ( name , url , iconimage )
 if 20 - 20: i1IIi11111i
def o0oO000oo ( ) :
 if 95 - 95: iiIIiIiIi / iiIIiIiIi
 O0oOoOO ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 O0oOoOO ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 O0oOoOO ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 II11i1I11Ii1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 II11i1I11Ii1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 30 - 30: i11iiII + I11i1i11i1I / I11i1i11i1I % i11iiII . i11iiII
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 55 - 55: iiIIiIiIi - oo0Ooo0 + i1111 + i1iIIIiI1I % i1IIiiiii
def iiI11i1II ( ) :
 if 51 - 51: oo0ooO0oOOOOo % I11i1i11i1I % oo0ooO0oOOOOo * oooO0oo0oOOOO - oOo0 % I11i1i11i1I
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 65 - 65: iiIIiIiIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 68 - 68: iiIIiIiIi % i11iIiiIii + i1111
def OOOO0OOO ( ) :
 if 3 - 3: oo
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 97 - 97: OooOoO0Oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 15 - 15: II1Ii1iI1i + OOO0O
def iii1i1I1i1 ( ) :
 if 25 - 25: i11iiII . iiIIiIiIi
 IIIIii1I = 0
 OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IIIIii1I = IIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  O000oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( IIIIii1I ) + '[/COLOR]' , O000oo , 12 , iiiii , O0O0OO0O0O0 )
  if 24 - 24: OooooO0oOO / i11iIiiIii + OooooO0oOO
 OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IIIIii1I = IIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  O000oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( IIIIii1I ) + '[/COLOR]' , O000oo , 12 , iiiii , O0O0OO0O0O0 )
  if 20 - 20: oo0Ooo0 + i1IIiiiii / oooO0oo0oOOOO % ooO0oo0oO0
 OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  IIIIii1I = IIIIii1I + 1
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  O000oo = Oo0OoO00oOO0o
  II11i1I11Ii1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( IIIIii1I ) + '[/COLOR]' , O000oo , 12 , iiiii , O0O0OO0O0O0 )
  if 88 - 88: OOO0O / i1111
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 87 - 87: i11iiII - i11iiII - i1iIIIiI1I + OooooO0oOO
def OOoooiIIiIiI1I1 ( url ) :
 if 56 - 56: i1IIi11111i . oooO0oo0oOOOO + I11i1i11i1I
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 if 1 - 1: i1iIIIiI1I
 for Oo0OoO00oOO0o in Oo0oOOo :
  OoOO0oo0o = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  Oo0oOOOoOooOo = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 12 , Oo0oOOOoOooOo , O0O0OO0O0O0 )
  if 97 - 97: oOo0 + i1iIIIiI1I + oooO0oo0oOOOO + i11iIiiIii
 try :
  oOoO0 = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( OOO ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR yellow]Next Page -->[/COLOR]' , oOoO0 , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 77 - 77: ooO0oo0oO0 . i1iIIIiI1I % i1iIIIiI1I + i11iIiiIii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 72 - 72: ooO0oo0oO0 * i1IIiiiii % iiIIiIiIi / oo
def I11i1II ( ) :
 if 72 - 72: ooO0oo0oO0 . II1Ii1iI1i / I11i1i11i1I . i1111
 OOO = o0 ( 'http://arenavision.in/schedule' )
 Oo0oOOo = re . compile ( '<tr><td class="auto-style3"(.+?)</tr>' , re . DOTALL ) . findall ( OOO )
 if 54 - 54: i1111 % i1111
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   oOOoo00O00o = re . compile ( '190px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   time = re . compile ( '182px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo00000o0o = re . compile ( '188px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0OOoOOO0oO = re . compile ( '685px">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I1ii11 = re . compile ( '317px">(.+?) ' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O000oo = O0OOoOOO0oO + '|SPLIT|' + I1ii11
   O0oOoOO ( '[COLOR blue][B]' + O0OOoOOO0oO + '[/B][/COLOR] - [COLOR white]' + oOOoo00O00o + ' | [COLOR orangered][B]' + time + '[/B][/COLOR] | ' + Oo00000o0o + '[/COLOR]' , O000oo , 97 , iiiii , O0O0OO0O0O0 )
  except : pass
 ooO0oOOooOo0 = i1I1ii11i1Iii ( )
 if 74 - 74: I11i1i11i1I - oo0ooO0oOOOOo . II1Ii1iI1i
 if ooO0oOOooOo0 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif ooO0oOOooOo0 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 43 - 43: i1iIIIiI1I / i1IIi11111i
def OO0oo0O ( name , url , iconimage ) :
 if 13 - 13: i11iIiiIii + II1Ii1iI1i * ooO0oo0oO0 % i111I - i1111 * oOo0
 name , url = url . split ( '|SPLIT|' )
 if 26 - 26: i111I * i1IIi11111i + oOo0
 IiIii1i111 = "null"
 iI = "null"
 if 74 - 74: i1IIi11111i
 if "-" in url :
  IiIii1i111 , iI = url . split ( '-' )
  if 89 - 89: i1IIiiiii
  ooOoOO0OoO00o = O00ooooo00 . select ( "[COLOR red]Please select an stream[/COLOR]" , [ '[COLOR white]Link 1[/COLOR]' , '[COLOR white]Link 2[/COLOR]' ] )
  if 11 - 11: I11i1i11i1I - i1IIi11111i * i1111 . i11iiII . OooooO0oOO
  if ooOoOO0OoO00o == 0 : url = 'http://arenavision.in/av' + IiIii1i111
  elif ooOoOO0OoO00o == 1 : url = 'http://arenavision.in/av' + iI
  else : quit ( )
  if 61 - 61: i1iIIIiI1I % i1IIi11111i - oo0ooO0oOOOOo - i1111 % oooO0oo0oOOOO
 else : url = 'http://arenavision.in/av' + url
 if 90 - 90: ooO0oo0oO0 + i11iiII + iiIIiIiIi - OooOoO0Oo * OoO000 . i11iiII
 I11iiiii1II ( name , url , iconimage )
 if 51 - 51: oooO0oo0oOOOO % OooooO0oOO - i1111
 if 31 - 31: i1iIIIiI1I / I11i1i11i1I - i1iIIIiI1I - oOo0
def I11iiiii1II ( name , url , iconimage ) :
 if 7 - 7: i1iIIIiI1I % oooO0oo0oOOOO . OOO0O + i1IIi11111i - oo0Ooo0
 try :
  OOO = o0 ( url )
  Oo0oOOo = re . compile ( 'this.loadPlayer(.+?),' , re . DOTALL ) . findall ( OOO ) [ 0 ]
  url = Oo0oOOo . replace ( '(' , '' ) . replace ( ')' , '' ) . replace ( '"' , '' ) . replace ( ' ' , '' )
  if 75 - 75: oo0Ooo0
  ooOooo000oOO = 'plugin://program.plexus/?url=acestream://' + str ( url ) + '&mode=1&name=acestream+' + str ( name )
  if 71 - 71: iiIIiIiIi
  o0Oo0oO0oOO00 ( name , ooOooo000oOO , iconimage )
 except : quit ( )
 if 53 - 53: i111I % i1IIiiiii . OoO000 / i11iIiiIii % i1iIIIiI1I
def iIiIIIIIii ( url ) :
 if 58 - 58: oo0ooO0oOOOOo / OoO000 . OOO0O / i111I + OooOoO0Oo
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except :
   OoOO0oo0o = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 86 - 86: oo0Ooo0 * i1IIi11111i + oo0Ooo0 + i1111
def i1i111iI ( url ) :
 if 29 - 29: i11iiII / II1Ii1iI1i . i1IIi11111i - OOO0O - OOO0O - i1IIiiiii
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( OOO )
 IiiIiI111iI = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   OoOO0oo0o = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : IiiIiI111iI = 1
  if 85 - 85: oo0ooO0oOOOOo . OOO0O / iiIIiIiIi . oooO0oo0oOOOO % OooOoO0Oo
  if IiiIiI111iI == 0 :
   II11i1I11Ii1i ( '[COLOR dodgerblue]' + OoOO0oo0o + '[/COLOR]' , url , 12 , Oo0oOOOoOooOo , O0O0OO0O0O0 )
  IiiIiI111iI = 0
  if 90 - 90: I11i1i11i1I % oooO0oo0oOOOO * ooO0oo0oO0 . i1iIIIiI1I
 try :
  oOoO0 = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( OOO ) [ 0 ]
  II11i1I11Ii1i ( '[COLOR yellow]Next Page -->[/COLOR]' , oOoO0 , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 8 - 8: iiIIiIiIi + i1111 / i1iIIIiI1I / oo0Ooo0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 74 - 74: oooO0oo0oOOOO / II1Ii1iI1i
def OoO ( url ) :
 if 41 - 41: II1Ii1iI1i * i1111 / i111I . oOo0
 O0 = datetime . date . today ( )
 iII1II = datetime . datetime . strftime ( O0 , '%A %d %B %Y' )
 if 46 - 46: OOO0O / ooO0oo0oO0 % i1iIIIiI1I . ooO0oo0oO0 * i1iIIIiI1I
 O0oOoOO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iII1II ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 38 - 38: i11iiII - i1iIIIiI1I / oooO0oo0oOOOO . OooOoO0Oo
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( OOO )
 IiiIiI111iI = 0
 IIIIii1I = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  try :
   iII1 = re . compile ( 'title="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   try :
    i1iiIiI1Ii1i = re . compile ( '<p>(.+?)</p>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   except : i1iiIiI1Ii1i = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<img src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : IiiIiI111iI = 1
  if 22 - 22: OoO000 / i11iIiiIii
  if IiiIiI111iI == 0 :
   if 'vs' in iII1 :
    OoOO0oo0o = '[COLOR dodgerblue]' + iII1 + ' - ' + '[/COLOR][COLOR green]' + i1iiIiI1Ii1i + '[/COLOR]'
    IIIIii1I = IIIIii1I + 1
    O0oOoOO ( OoOO0oo0o , url , 206 , Oo0oOOOoOooOo , O0O0OO0O0O0 , '' )
  IiiIiI111iI = 0
  if 62 - 62: oo / i11iiII
 if IIIIii1I == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 7 - 7: i111I . OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 53 - 53: i1IIiiiii % i1IIiiiii * oo0ooO0oOOOOo + OOO0O
def Oooo00 ( name , url , iconimage ) :
 if 6 - 6: i1IIiiiii - iiIIiIiIi * oOo0 . i1iIIIiI1I / oooO0oo0oOOOO * iiIIiIiIi
 OOO = o0 ( url )
 II11iI111i1 = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( OOO ) [ 0 ]
 if 95 - 95: i111I - OoO000 * i1IIi11111i + OOO0O
 if not "http" in II11iI111i1 :
  II11iI111i1 = II11iI111i1 . replace ( "//" , "" )
  url = "http://" + II11iI111i1
 else :
  url = II11iI111i1
  if 10 - 10: oo0ooO0oOOOOo / i11iIiiIii
 o00 = url
 if 85 - 85: i11iiII . OooOoO0Oo
 O0O0Ooooo000 = o0 ( url )
 II11iI111i1 = re . compile ( "atob(.+?)," ) . findall ( O0O0Ooooo000 ) [ 0 ]
 II11iI111i1 = II11iI111i1 . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( II11iI111i1 )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + o00 + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 o0Oo0oO0oOO00 ( name , url , iconimage )
 if 65 - 65: oOo0 * OooOoO0Oo
def ooo0o000O ( url ) :
 if 100 - 100: OooooO0oOO . iiIIiIiIi * i11iiII / ooO0oo0oO0 * II1Ii1iI1i % iiIIiIiIi
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 17 - 17: oo0Ooo0 . OoO000 - i1111 + oooO0oo0oOOOO / ooO0oo0oO0 / i11iIiiIii
  if '<display>eWVz</display>' in Oo0OoO00oOO0o :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   oOooOOOoOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OoOO0oo0o = base64 . b64decode ( OoOO0oo0o )
   url = base64 . b64decode ( url )
   Oo0oOOOoOooOo = base64 . b64decode ( Oo0oOOOoOooOo )
   oOooOOOoOo = base64 . b64decode ( oOooOOOoOo )
   II11i1I11Ii1i ( OoOO0oo0o , url , 220 , Oo0oOOOoOooOo , oOooOOOoOo , '' )
   if 39 - 39: OoO000 * I11i1i11i1I + ooO0oo0oO0 - OoO000 + oOo0
def o0iiiI1I1iIIIi1 ( url ) :
 if 17 - 17: ooO0oo0oO0 . i111I / oo0Ooo0 % i1111 % II1Ii1iI1i / i11iIiiIii
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOO )
 if 58 - 58: I11i1i11i1I . i1111 + OooooO0oOO - i11iIiiIii / i1111 / oooO0oo0oOOOO
 for Oo0OoO00oOO0o in Oo0oOOo :
  OoOO0oo0o = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   oOOoOo = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : oOOoOo = "SD"
  oOOoOo = '[COLOR yellow]' + oOOoOo + '[/COLOR]'
  Oo0oOOOoOooOo = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  OoOO0oo0o = OoOO0oo0o . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 89 - 89: i1111 + II1Ii1iI1i + i1111
  O0oOoOO ( '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR] - ' + oOOoOo , url , 212 , Oo0oOOOoOooOo , O0O0OO0O0O0 , '' )
  if 7 - 7: oooO0oo0oOOOO % oo0ooO0oOOOOo + i11iiII * i1iIIIiI1I - i1iIIIiI1I
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( OOO ) [ 0 ]
  I11 = 'http://www.fmovies.se/' + url
  II11i1I11Ii1i ( "Next Page -->" , I11 , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 42 - 42: OOO0O * OOO0O * OooOoO0Oo . oo0Ooo0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 51 - 51: oOo0 % ooO0oo0oO0 - i111I % iiIIiIiIi * ooO0oo0oO0 % oo
def oO0o00oOOooO0 ( url ) :
 if 79 - 79: oo - ooO0oo0oO0 + i1IIiiiii - OooOoO0Oo
 OOO = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOO )
 if 93 - 93: i1111 . i1IIi11111i - I11i1i11i1I + OOO0O
 if 61 - 61: i1111
def Ii1ii111i1 ( url ) :
 if 31 - 31: oOo0 + oooO0oo0oOOOO
 if "iptvembed" in url :
  OOO = o0 ( url )
  Oo0oOOo = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '</pre>' , '' )
   url = Oo0OoO00oOO0o
   if 87 - 87: iiIIiIiIi
 if "sourcetv" in url :
  OOO = o0 ( url )
  Oo0oOOo = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '</pre>' , '' )
   url = Oo0OoO00oOO0o
   if 45 - 45: oo / i111I - i1iIIIiI1I / i1IIiiiii % OoO000
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 oOoOOo000oOoO0 = [ ]
 for OoOo00o0OO , ii1IIIIiI11 , url in OoOIii11iI11i1I :
  iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : url }
  oOoOOo000oOoO0 . append ( iI1IIIii )
 list = [ ]
 for I1ii11 in oOoOOo000oOoO0 :
  iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
  OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
  for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
   iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
  list . append ( iI1IIIii )
  if 4 - 4: i111I - II1Ii1iI1i % i1IIiiiii - oOo0 * oo0ooO0oOOOOo
 Ooooo00o0OoO = 0
 for I1ii11 in list :
  Ooooo00o0OoO = 1
  OoOO0oo0o = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
  url = oooo0O0O0o0 ( I1ii11 [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   O0oOoOO ( '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   II11i1I11Ii1i ( '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 51 - 51: i1111 + OoO000 . II1Ii1iI1i . i11iiII + OOO0O * i1IIi11111i
 if Ooooo00o0OoO == 0 :
  O0oOoOO ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 72 - 72: OooooO0oOO + OooooO0oOO / i1111 . i111I % i1IIiiiii
def III ( url ) :
 if 41 - 41: i11iIiiIii + I11i1i11i1I / i1IIi11111i . i111I % OooooO0oOO % II1Ii1iI1i
 iII = o0 ( url )
 ooOooo000oOO = url
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 70 - 70: I11i1i11i1I . i111I - i1iIIIiI1I
  OO0Oooo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
  if len ( OO0Oooo0 ) == 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = OoOO0oo0o + "!" + url + "!" + Oo0oOOOoOooOo
   OoOO0oo0o = '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 20 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
   if 30 - 30: i11iiII % i1IIi11111i
  elif len ( OO0Oooo0 ) > 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = ooOooo000oOO + "!" + OoOO0oo0o + "!" + Oo0oOOOoOooOo
   OoOO0oo0o = '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 22 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
   if 89 - 89: OooOoO0Oo + i111I + OooOoO0Oo * II1Ii1iI1i + ooO0oo0oO0 % oo0Ooo0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 59 - 59: oOo0 + i11iIiiIii
def oo0OOo0O ( url ) :
 if 39 - 39: i111I + OooooO0oOO % oOo0 / oOo0
 O0 = datetime . date . today ( )
 iII1II = datetime . datetime . strftime ( O0 , '%A %d %B %Y' )
 if 27 - 27: i1iIIIiI1I . oo0Ooo0 . ooO0oo0oO0 . ooO0oo0oO0
 O0oOoOO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iII1II ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 20 - 20: oo0ooO0oOOOOo / II1Ii1iI1i
 iII = o0 ( url )
 ooOooo000oOO = url
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 71 - 71: OOO0O . II1Ii1iI1i
  OO0Oooo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o )
  if len ( OO0Oooo0 ) == 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = OoOO0oo0o + "!" + url + "!" + Oo0oOOOoOooOo
   OoOO0oo0o = '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 20 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
   if 94 - 94: oOo0 . OooOoO0Oo
  elif len ( OO0Oooo0 ) > 1 :
   OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   Oo0oOOOoOooOo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   url = ooOooo000oOO + "!" + OoOO0oo0o + "!" + Oo0oOOOoOooOo
   OoOO0oo0o = '[COLOR mediumpurple]' + OoOO0oo0o + '[/COLOR]'
   II11i1I11Ii1i ( OoOO0oo0o , url , 22 , Oo0oOOOoOooOo , Oo0oOOOoOooOo )
   if 84 - 84: oooO0oo0oOOOO . oo0Ooo0 - i1111 . iiIIiIiIi / i1111
def iii1 ( ) :
 if 32 - 32: i1IIiiiii . OoO000 . i111I - oo + OooooO0oOO
 O0 = datetime . date . today ( )
 iII1II = datetime . datetime . strftime ( O0 , '%A %d %B %Y' )
 if 88 - 88: i1iIIIiI1I
 O0oOoOO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( iII1II ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 O0oOoOO ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 19 - 19: i1111 * OoO000 + i1IIiiiii
 iII = o0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 Oo0oOOo = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 O0o = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in O0o :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in Oo0OoO00oOO0o :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iII1 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    Oo0oOOOoOooOo = re . compile ( 'src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oO00oO = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
     oO00oO = i11i1iIiii ( oO00oO )
    except : oO00oO = "null"
    OoOO0oo0o = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + iII1 + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    OoOO0oo0o = OOO00OO0oOo ( OoOO0oo0o )
    O000oo = iII1 + "!" + oO00oO . lower ( ) + "!" + Oo0oOOOoOooOo
    II11i1I11Ii1i ( OoOO0oo0o , O000oo , 20 , Oo0oOOOoOooOo , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    iII1 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    try :
     oO00oO = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    except : oO00oO = "null"
    Oo0oOOOoOooOo = re . compile ( 'src="(.+?)"' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    OoOO0oo0o = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + iII1 + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    OoOO0oo0o = OOO00OO0oOo ( OoOO0oo0o )
    O000oo = iII1 + "!" + oO00oO . lower ( ) + "!" + Oo0oOOOoOooOo
    II11i1I11Ii1i ( OoOO0oo0o , O000oo , 20 , Oo0oOOOoOooOo , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 35 - 35: i1iIIIiI1I + iiIIiIiIi - OooooO0oOO . i1iIIIiI1I . OoO000
def oo0ooOO ( name , url , iconimage ) :
 if 24 - 24: oo % oo * ooO0oo0oO0
 try :
  url , IIIiIiIi11Ii , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 23 - 23: OooooO0oOO - oOo0 + oo0Ooo0
 II11 = [ ]
 if 30 - 30: i11iIiiIii % ooO0oo0oO0 . oo0Ooo0 % ooO0oo0oO0
 iII = o0 ( url )
 o00O0O = re . compile ( '<title>' + re . escape ( IIIiIiIi11Ii ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o00O0O ) [ 0 ]
 OO0Oooo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( o00O0O )
 for ii1iii1i in OO0Oooo0 :
  II11 . append ( ii1iii1i )
  if 62 - 62: I11i1i11i1I * OOO0O
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 79 - 79: oo . i1iIIIiI1I * i1IIiiiii - oOo0 + iiIIiIiIi
 ii11II1i = 0
 if 58 - 58: I11i1i11i1I . OoO000 - I11i1i11i1I - OooOoO0Oo * i1IIiiiii
 IIiI11i1111Ii = [ ]
 o00O0OoOO = [ ]
 O00o00O = [ ]
 I1IiiI . update ( 0 )
 ii1iii11i1 = 0
 if 4 - 4: OoO000 . OoO000 % i11iiII % i1IIiiiii / i1IIiiiii
 if oO000OoOoo00o == "true" :
  ii1iii11i1 = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if ii11II1i < 100 :
    I1IiiI . update ( ii11II1i )
    ii11II1i = ii11II1i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   oOoOOo000oOoO0 = [ ]
   for OoOo00o0OO , ii1IIIIiI11 , url in OoOIii11iI11i1I :
    iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : url }
    oOoOOo000oOoO0 . append ( iI1IIIii )
   II11iIiiI1111 = [ ]
   for I1ii11 in oOoOOo000oOoO0 :
    iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
    OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
    for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
     iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
    II11iIiiI1111 . append ( iI1IIIii )
    if 71 - 71: oo0ooO0oOOOOo % i1IIiiiii - i1111 * i111I
   for I1ii11 in II11iIiiI1111 :
    name = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
    url = oooo0O0O0o0 ( I1ii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIiI11i1111Ii . append ( name )
    o00O0OoOO . append ( url )
    if "hd" in name . lower ( ) :
     O00o00O . append ( "1" )
    else :
     O00o00O . append ( "0" )
    IIii1111 = list ( zip ( O00o00O , IIiI11i1111Ii , o00O0OoOO ) )
    if 69 - 69: oo0ooO0oOOOOo / I11i1i11i1I
 if iiiI11 == "true" :
  ii1iii11i1 = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if ii11II1i < 100 :
    I1IiiI . update ( ii11II1i )
    ii11II1i = ii11II1i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   oOoOOo000oOoO0 = [ ]
   for OoOo00o0OO , ii1IIIIiI11 , url in OoOIii11iI11i1I :
    iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : url }
    oOoOOo000oOoO0 . append ( iI1IIIii )
   II11iIiiI1111 = [ ]
   for I1ii11 in oOoOOo000oOoO0 :
    iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
    OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
    for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
     iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
    II11iIiiI1111 . append ( iI1IIIii )
    if 43 - 43: i11iiII . i1IIi11111i / i111I % i111I
   for I1ii11 in II11iIiiI1111 :
    name = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
    url = oooo0O0O0o0 ( I1ii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIiI11i1111Ii . append ( name )
    o00O0OoOO . append ( url )
    if "hd" in name . lower ( ) :
     O00o00O . append ( "1" )
    else :
     O00o00O . append ( "0" )
    IIii1111 = list ( zip ( O00o00O , IIiI11i1111Ii , o00O0OoOO ) )
    if 33 - 33: OooOoO0Oo
 if OOooO == "true" :
  ii1iii11i1 = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if ii11II1i < 100 :
    I1IiiI . update ( ii11II1i )
    ii11II1i = ii11II1i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   oOoOOo000oOoO0 = [ ]
   for OoOo00o0OO , ii1IIIIiI11 , url in OoOIii11iI11i1I :
    iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : url }
    oOoOOo000oOoO0 . append ( iI1IIIii )
   II11iIiiI1111 = [ ]
   for I1ii11 in oOoOOo000oOoO0 :
    iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
    OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
    for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
     iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
    II11iIiiI1111 . append ( iI1IIIii )
    if 62 - 62: i11iiII + i1IIiiiii + II1Ii1iI1i / i111I
   for I1ii11 in II11iIiiI1111 :
    name = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
    url = oooo0O0O0o0 ( I1ii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIiI11i1111Ii . append ( name )
    o00O0OoOO . append ( url )
    if "hd" in name . lower ( ) :
     O00o00O . append ( "1" )
    else :
     O00o00O . append ( "0" )
    IIii1111 = list ( zip ( O00o00O , IIiI11i1111Ii , o00O0OoOO ) )
    if 7 - 7: oo0ooO0oOOOOo + II1Ii1iI1i . i1IIi11111i / I11i1i11i1I
 if ii1iii11i1 == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 22 - 22: iiIIiIiIi - iiIIiIiIi % oOo0 . OooOoO0Oo + OooooO0oOO
 oo0o0000 = sorted ( IIii1111 , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 Oo00OOo00O = sorted ( II11 )
 if 81 - 81: OoO000 . oo0ooO0oOOOOo / OooOoO0Oo
 OOOOOoo0 = 0
 if 17 - 17: i11iIiiIii - oOo0 . OoO000 % ooO0oo0oO0 + oo0Ooo0 - iiIIiIiIi
 I1IiiI . update ( 100 )
 if 78 - 78: oo0Ooo0 * OOO0O . oooO0oo0oOOOO / oooO0oo0oOOOO
 O0oOoOO ( '                    [COLOR yellow][I]LINKS FOR ' + IIIiIiIi11Ii . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O0oOoOO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 80 - 80: II1Ii1iI1i - I11i1i11i1I / oo - i11iIiiIii
 if 68 - 68: OooooO0oOO - i11iiII % oooO0oo0oOOOO % OooOoO0Oo
 for oO00oO in Oo00OOo00O :
  if 11 - 11: oooO0oo0oOOOO / oo % oOo0 + oo0ooO0oOOOOo + ooO0oo0oO0
  O0oOoOO ( '                                  [COLOR mediumpurple][I]' + oO00oO . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 40 - 40: iiIIiIiIi - oOo0 . i1IIiiiii * I11i1i11i1I % OooOoO0Oo
  oo0O00Oooo0O0 = oO00oO . split ( ' ' )
  if 56 - 56: i11iIiiIii . oo0ooO0oOOOOo - i1IIi11111i * oo0Ooo0
  for oOOoo0 , name , url in oo0o0000 :
   if 20 - 20: OoO000 % OoO000
   OOooo0O = 0
   if 34 - 34: oOo0
   for IiIIiIIIiIii in oo0O00Oooo0O0 :
    if 23 - 23: i1iIIIiI1I + oo0Ooo0 . OOO0O * i1IIi11111i + i11iiII
    if not IiIIiIIIiIii . lower ( ) in name . lower ( ) :
     OOooo0O = 1
     if 18 - 18: OoO000 * oo0ooO0oOOOOo . OoO000 / oooO0oo0oOOOO
   if OOooo0O == 0 :
    OOOOOoo0 = OOOOOoo0 + 1
    if "hd" in name . lower ( ) :
     O0oOoOO ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( OOOOOoo0 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O0oOoOO ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( OOOOOoo0 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 8 - 8: oo0ooO0oOOOOo
  if OOOOOoo0 == 0 :
   O0oOoOO ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 4 - 4: i11iiII + i11iiII * iiIIiIiIi - OOO0O
  oo0O00Oooo0O0 = ""
  if 78 - 78: i1IIiiiii / i1111 % OOO0O
 I1IiiI . close ( )
 if 52 - 52: oOo0 - i1iIIIiI1I * OooooO0oOO
def Ii1I11I ( name , url , iconimage ) :
 if 36 - 36: oooO0oo0oOOOO + I11i1i11i1I
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 5 - 5: I11i1i11i1I * OOO0O
 ii11II1i = 0
 try :
  IIIiIiIi11Ii , oO00oO , iconimage = url . split ( '!' )
 except :
  try :
   oO00oO , iconimage = url . split ( '!' )
   IIIiIiIi11Ii = oO00oO
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 46 - 46: iiIIiIiIi
 I11iIiII = 0
 if 66 - 66: I11i1i11i1I - oo0ooO0oOOOOo * OoO000 + OOO0O + oo0ooO0oOOOOo - ooO0oo0oO0
 if "all " in name . lower ( ) :
  oO00oO = oO00oO . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  IIIiIiIi11Ii = IIIiIiIi11Ii . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  I11iIiII = 1
  if 17 - 17: OooooO0oOO
 IIiI11i1111Ii = [ ]
 o00O0OoOO = [ ]
 O00o00O = [ ]
 I1IiiI . update ( 0 )
 ii1iii11i1 = 0
 if oO000OoOoo00o == "true" :
  ii1iii11i1 = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if ii11II1i < 100 :
    I1IiiI . update ( ii11II1i )
    ii11II1i = ii11II1i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   oOoOOo000oOoO0 = [ ]
   for OoOo00o0OO , ii1IIIIiI11 , url in OoOIii11iI11i1I :
    iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : url }
    oOoOOo000oOoO0 . append ( iI1IIIii )
   II11iIiiI1111 = [ ]
   for I1ii11 in oOoOOo000oOoO0 :
    iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
    OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
    for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
     iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
    II11iIiiI1111 . append ( iI1IIIii )
    if 22 - 22: oo0Ooo0 + ooO0oo0oO0
   for I1ii11 in II11iIiiI1111 :
    name = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
    url = oooo0O0O0o0 ( I1ii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIiI11i1111Ii . append ( name )
    o00O0OoOO . append ( url )
    if "hd" in name . lower ( ) :
     O00o00O . append ( "1" )
    else :
     O00o00O . append ( "0" )
    IIii1111 = list ( zip ( O00o00O , IIiI11i1111Ii , o00O0OoOO ) )
    if 24 - 24: OOO0O % II1Ii1iI1i + i1iIIIiI1I . i11iIiiIii . i11iiII
 if iiiI11 == "true" :
  ii1iii11i1 = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if ii11II1i < 100 :
    I1IiiI . update ( ii11II1i )
    ii11II1i = ii11II1i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   oOoOOo000oOoO0 = [ ]
   for OoOo00o0OO , ii1IIIIiI11 , url in OoOIii11iI11i1I :
    iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : url }
    oOoOOo000oOoO0 . append ( iI1IIIii )
   II11iIiiI1111 = [ ]
   for I1ii11 in oOoOOo000oOoO0 :
    iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
    OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
    for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
     iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
    II11iIiiI1111 . append ( iI1IIIii )
    if 17 - 17: i11iiII . i1111 . iiIIiIiIi / i11iiII
   for I1ii11 in II11iIiiI1111 :
    name = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
    url = oooo0O0O0o0 ( I1ii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIiI11i1111Ii . append ( name )
    o00O0OoOO . append ( url )
    if "hd" in name . lower ( ) :
     O00o00O . append ( "1" )
    else :
     O00o00O . append ( "0" )
    IIii1111 = list ( zip ( O00o00O , IIiI11i1111Ii , o00O0OoOO ) )
    if 57 - 57: oo0Ooo0
 if OOooO == "true" :
  ii1iii11i1 = 1
  OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for Oo0OoO00oOO0o in Oo0oOOo :
   if ii11II1i < 100 :
    I1IiiI . update ( ii11II1i )
    ii11II1i = ii11II1i + 3
   Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
   url = Oo0OoO00oOO0o
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   oOoOOo000oOoO0 = [ ]
   for OoOo00o0OO , ii1IIIIiI11 , url in OoOIii11iI11i1I :
    iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : url }
    oOoOOo000oOoO0 . append ( iI1IIIii )
   II11iIiiI1111 = [ ]
   for I1ii11 in oOoOOo000oOoO0 :
    iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
    OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
    for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
     iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
    II11iIiiI1111 . append ( iI1IIIii )
    if 67 - 67: oo . iiIIiIiIi
   for I1ii11 in II11iIiiI1111 :
    name = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
    url = oooo0O0O0o0 ( I1ii11 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    IIiI11i1111Ii . append ( name )
    o00O0OoOO . append ( url )
    if "hd" in name . lower ( ) :
     O00o00O . append ( "1" )
    else :
     O00o00O . append ( "0" )
    IIii1111 = list ( zip ( O00o00O , IIiI11i1111Ii , o00O0OoOO ) )
    if 87 - 87: OooooO0oOO % i1IIiiiii
 if ii1iii11i1 == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 83 - 83: i1111 - oo0Ooo0
 oo0o0000 = sorted ( IIii1111 , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 if 35 - 35: II1Ii1iI1i - ooO0oo0oO0 + II1Ii1iI1i
 OOOOOoo0 = 0
 if 86 - 86: ooO0oo0oO0 + OOO0O . i11iIiiIii - i1IIiiiii
 I1IiiI . update ( 100 )
 if 51 - 51: OOO0O
 O0oOoOO ( '                                [COLOR yellow][I]LINKS FOR ' + IIIiIiIi11Ii . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O0oOoOO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 oo0O00Oooo0O0 = oO00oO . split ( ' ' )
 for oOOoo0 , name , url in oo0o0000 :
  if I11iIiII == 1 :
   I11IIIiIi11 = name
   if 39 - 39: i1IIiiiii % oooO0oo0oOOOO % OOO0O . II1Ii1iI1i
  OOooo0O = 0
  if 86 - 86: oo * i111I
  for IiIIiIIIiIii in oo0O00Oooo0O0 :
   if 71 - 71: ooO0oo0oO0 - oOo0 . i1IIi11111i % i111I + oOo0
   if not IiIIiIIIiIii . lower ( ) in name . lower ( ) :
    OOooo0O = 1
    if 26 - 26: I11i1i11i1I + oOo0 / oo % OOO0O % i11iiII + i1111
  if OOooo0O == 0 :
   OOOOOoo0 = OOOOOoo0 + 1
   if I11iIiII == 1 :
    if "hd" in name . lower ( ) :
     O0oOoOO ( '                                          [COLOR blue] ' + str ( I11IIIiIi11 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O0oOoOO ( '                                          [COLOR blue] ' + str ( I11IIIiIi11 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     O0oOoOO ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( OOOOOoo0 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     O0oOoOO ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( OOOOOoo0 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 31 - 31: oo0Ooo0 % oOo0 * oo0Ooo0
 if OOOOOoo0 == 0 :
  O0oOoOO ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 45 - 45: II1Ii1iI1i . i1IIi11111i + oOo0 - i111I % iiIIiIiIi
 I1IiiI . close ( )
 if 1 - 1: ooO0oo0oO0
def ooi1II1I ( term ) :
 if 95 - 95: oo - oOo0 / i1111 % i11iiII . oo0ooO0oOOOOo
 I1i1i1iii = [ ]
 I1111i = [ ]
 if 24 - 24: II1Ii1iI1i . i11iIiiIii
 OOO = o0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Oo0oOOo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for Oo0OoO00oOO0o in Oo0oOOo :
  Oo0OoO00oOO0o = Oo0OoO00oOO0o . replace ( '<br />' , '\n' )
  O000oo = Oo0OoO00oOO0o
  if 16 - 16: I11i1i11i1I % i11iiII + oo0Ooo0 - oooO0oo0oOOOO . i1iIIIiI1I / OooOoO0Oo
  O000oo = O000oo . replace ( '#AAASTREAM:' , '#A:' )
  O000oo = O000oo . replace ( '#EXTINF:' , '#A:' )
  OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O000oo )
  oOoOOo000oOoO0 = [ ]
  for OoOo00o0OO , ii1IIIIiI11 , O000oo in OoOIii11iI11i1I :
   iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : O000oo }
   oOoOOo000oOoO0 . append ( iI1IIIii )
  list = [ ]
  for I1ii11 in oOoOOo000oOoO0 :
   iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
   OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
   for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
    iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
   list . append ( iI1IIIii )
   if 35 - 35: OooooO0oOO / OooOoO0Oo / i1111 - ooO0oo0oO0 + i1111 . OooOoO0Oo
  for I1ii11 in list :
   OoOO0oo0o = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
   O000oo = oooo0O0O0o0 ( I1ii11 [ "url" ] )
   O000oo = O000oo . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in OoOO0oo0o . lower ( ) :
    I1i1i1iii . append ( O000oo )
    I1111i . append ( OoOO0oo0o )
    if 81 - 81: i1iIIIiI1I * oOo0 - i11iiII * i1IIiiiii % OOO0O * OOO0O
 O00ooooo00 = xbmcgui . Dialog ( )
 Ii1IIiI1i = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , I1111i )
 if Ii1IIiI1i < 0 :
  quit ( )
  if 59 - 59: ooO0oo0oO0
 O000oo = I1i1i1iii [ Ii1IIiI1i ]
 OoOO0oo0o = I1111i [ Ii1IIiI1i ]
 o0Oo0oO0oOO00 ( OoOO0oo0o , O000oo , iiiii )
 if 7 - 7: oOo0 * i1IIi11111i / oo0ooO0oOOOOo * i11iIiiIii
def o00II1i111 ( name , url , iconimage ) :
 if 50 - 50: OoO000 % II1Ii1iI1i
 list = iii11II1I ( url )
 if 5 - 5: OOO0O - OoO000 * OoO000
 IiiIi1IIII1i = 0
 Oooo = open ( iI1Ii11111iIi , mode = 'r' ) ; O0ooOoO = Oooo . read ( ) ; Oooo . close ( )
 O0ooOoO = O0ooOoO . replace ( '\n' , '' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( O0ooOoO )
 Ooooo00o0OoO = 0
 for Oo0OoO00oOO0o in Oo0oOOo :
  if 26 - 26: OOO0O / I11i1i11i1I - II1Ii1iI1i + oo0Ooo0
  IiiIi = re . compile ( '<url>(.+?)</url>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  if 10 - 10: oo / I11i1i11i1I
  if url == IiiIi :
   IiiIi1IIII1i = 1
   if 15 - 15: i1iIIIiI1I . OOO0O / i1iIIIiI1I * oo0Ooo0 - i1IIi11111i % i11iiII
 for I1ii11 in list :
  name = oooo0O0O0o0 ( I1ii11 [ "display_name" ] )
  url = oooo0O0O0o0 ( I1ii11 [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if IiiIi1IIII1i == 1 :
   if 57 - 57: oooO0oo0oOOOO % OOO0O % OooooO0oOO
   Oooo = open ( i1i1II , mode = 'r' ) ; O0ooOoO = Oooo . read ( ) ; Oooo . close ( )
   O0ooOoO = O0ooOoO . replace ( '\n' , '' )
   Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( O0ooOoO )
   for Oo0OoO00oOO0o in Oo0oOOo :
    if 45 - 45: i11iiII + i1111 * i11iIiiIii
    IiIIi1I1I11Ii = re . compile ( '<name>(.+?)</name>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
    if 64 - 64: i111I
    oO0oooooo = IiIIi1I1I11Ii . replace ( ' ' , '' )
    o0OO0Oo = name . replace ( ' ' , '' )
    if oO0oooooo . lower ( ) in o0OO0Oo . lower ( ) :
     if 3 - 3: OooOoO0Oo - oooO0oo0oOOOO % ooO0oo0oO0 / OoO000 . oo0ooO0oOOOOo
     Oooo = open ( O0oo0OO0 , mode = 'r' ) ; O0ooOoO = Oooo . read ( ) ; Oooo . close ( )
     O0ooOoO = O0ooOoO . replace ( '\n' , '' )
     Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( O0ooOoO )
     for Oo0OoO00oOO0o in Oo0oOOo :
      if 3 - 3: oooO0oo0oOOOO % i111I / oOo0
      ooOoo0oO0OoO0 = re . compile ( '<replace>(.+?)</replace>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
      if 70 - 70: OooooO0oOO - OooooO0oOO
      name = name . lower ( ) . replace ( ooOoo0oO0OoO0 , '' )
      if 57 - 57: i1IIi11111i - oo0ooO0oOOOOo + oo % I11i1i11i1I
     O0oOoOO ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 26 - 26: i1iIIIiI1I . i1iIIIiI1I
  else : O0oOoOO ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 35 - 35: OooOoO0Oo . OOO0O * i11iIiiIii
def iii11II1I ( url ) :
 if 44 - 44: i11iIiiIii / I11i1i11i1I
 Ii1IIi = Oo0O0O0ooO0O ( url )
 Ii1IIi = Ii1IIi . replace ( '#AAASTREAM:' , '#A:' )
 Ii1IIi = Ii1IIi . replace ( '#EXTINF:' , '#A:' )
 OoOIii11iI11i1I = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( Ii1IIi )
 oOoOOo000oOoO0 = [ ]
 for OoOo00o0OO , ii1IIIIiI11 , url in OoOIii11iI11i1I :
  iI1IIIii = { "params" : OoOo00o0OO , "display_name" : ii1IIIIiI11 , "url" : url }
  oOoOOo000oOoO0 . append ( iI1IIIii )
 list = [ ]
 for I1ii11 in oOoOOo000oOoO0 :
  iI1IIIii = { "display_name" : I1ii11 [ "display_name" ] , "url" : I1ii11 [ "url" ] }
  OoOIii11iI11i1I = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1ii11 [ "params" ] )
  for I1i11ii11 , OO00O0oOO in OoOIii11iI11i1I :
   iI1IIIii [ I1i11ii11 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OO00O0oOO . strip ( )
  list . append ( iI1IIIii )
  if 43 - 43: OooOoO0Oo % i1iIIIiI1I
 return list
 if 69 - 69: i1iIIIiI1I % oo
 if 86 - 86: OooooO0oOO / OooooO0oOO
def IiiI ( ) :
 if 19 - 19: i1111
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 72 - 72: i111I / i1IIi11111i + i1IIiiiii / OOO0O * i1IIiiiii
def Ii1iIi111i1i1 ( name , url , iconimage ) :
 if 45 - 45: OOO0O . oo0ooO0oOOOOo % OOO0O * i1IIi11111i % i1IIi11111i
 oOoOo00ooOooo = datetime . datetime . now ( )
 Ii = oOoOo00ooOooo . day
 if 79 - 79: I11i1i11i1I - i111I . oooO0oo0oOOOO
 OOoO00oo0000O = Ii
 if 20 - 20: ooO0oo0oO0 + OOO0O * i1111 + i111I % i111I
 I11Ii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIiII = datetime . datetime . strftime ( I11Ii , '%A - %d %B %Y' )
 i1i1IIIIIIIi = 'http://www.predictz.com/predictions/'
 if 65 - 65: oo0ooO0oOOOOo
 I1ii1II1iII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 II1i = datetime . datetime . strftime ( I1ii1II1iII , '%A - %d %B %Y' )
 o0OO00oo = datetime . datetime . strftime ( I1ii1II1iII , '%d' )
 i1i1IiIiIi1Ii = 'http://www.predictz.com/predictions/tomorrow/'
 if 64 - 64: oOo0 + i111I * i111I
 i1I = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 iiI1I1IIi11i1 = datetime . datetime . strftime ( i1I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1II1iii1i = datetime . datetime . strftime ( i1I , '%y%m%d' )
 OOO0o = 'http://www.predictz.com/predictions/20' + str ( i1II1iii1i )
 if 4 - 4: I11i1i11i1I . II1Ii1iI1i - i1iIIIiI1I
 i111i11I1Ii1I = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iI1I11iIIi1 = datetime . datetime . strftime ( i111i11I1Ii1I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIIi1I = datetime . datetime . strftime ( i111i11I1Ii1I , '%y%m%d' )
 IiiIiiIi = 'http://www.predictz.com/predictions/20' + str ( iIIi1I )
 if 40 - 40: oo0ooO0oOOOOo
 oOO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 o0oo0o0o0 = datetime . datetime . strftime ( oOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIii1 = datetime . datetime . strftime ( oOO , '%y%m%d' )
 Ooo0oO0 = 'http://www.predictz.com/predictions/20' + str ( iIii1 )
 if 86 - 86: oooO0oo0oOOOO
 if 95 - 95: i1iIIIiI1I * oOo0 . OOO0O . II1Ii1iI1i . II1Ii1iI1i - oo0ooO0oOOOOo
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIiII ) + '[/B][/COLOR]' , i1i1IIIIIIIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( II1i ) + '[/B][/COLOR]' , i1i1IiIiIi1Ii , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iiI1I1IIi11i1 ) , OOO0o , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iI1I11iIIi1 ) , IiiIiiIi , 41 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0oo0o0o0 ) , Ooo0oO0 , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 26 - 26: ooO0oo0oO0 % i11iIiiIii % i11iiII
def oo0O ( name , url , iconimage ) :
 if 6 - 6: I11i1i11i1I . OoO000 / OoO000 - i11iIiiIii
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 O0o = re . compile ( '<tr(.+?)</tr>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in O0o :
  try :
   i1iiIiI1Ii1i = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR red][B]' + i1iiIiI1Ii1i + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iII1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OO0oIiII1iiI = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   iII1 = iIIoO0O000oOoo0O ( iII1 )
   OO0oIiII1iiI = iIIoO0O000oOoo0O ( OO0oIiII1iiI )
   O0oOoOO ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + OO0oIiII1iiI + ' [/B][/COLOR]| [COLOR mediumpurple]' + iII1 + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 9 - 9: OooooO0oOO * II1Ii1iI1i - II1Ii1iI1i
def IiIiiI11i1Ii ( name , url , iconimage ) :
 if 100 - 100: OooOoO0Oo . i1IIi11111i * OooOoO0Oo - i1IIi11111i . oo0Ooo0 * i1IIiiiii
 oOoOo00ooOooo = datetime . datetime . now ( )
 Ii = oOoOo00ooOooo . day
 if 89 - 89: oo + OoO000 * OooOoO0Oo
 OOoO00oo0000O = Ii
 if 28 - 28: i111I . OooooO0oOO % i11iiII / II1Ii1iI1i / oOo0
 I11Ii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIiII = datetime . datetime . strftime ( I11Ii , '%A - %d %B %Y' )
 i1i1IIIIIIIi = 'http://www.predictz.com/predictions/'
 if 36 - 36: oo0ooO0oOOOOo + oo0Ooo0 - OoO000 + ooO0oo0oO0 + i111I
 I1ii1II1iII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 II1i = datetime . datetime . strftime ( I1ii1II1iII , '%A - %d %B %Y' )
 o0OO00oo = datetime . datetime . strftime ( I1ii1II1iII , '%d' )
 i1i1IiIiIi1Ii = 'http://www.predictz.com/predictions/tomorrow/'
 if 4 - 4: i1111 . oo0Ooo0 + i1IIiiiii * OooOoO0Oo . iiIIiIiIi
 i1I = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 iiI1I1IIi11i1 = datetime . datetime . strftime ( i1I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1II1iii1i = datetime . datetime . strftime ( i1I , '%y%m%d' )
 OOO0o = 'http://www.predictz.com/predictions/20' + str ( i1II1iii1i )
 if 87 - 87: OOO0O / oo / i11iIiiIii
 i111i11I1Ii1I = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iI1I11iIIi1 = datetime . datetime . strftime ( i111i11I1Ii1I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIIi1I = datetime . datetime . strftime ( i111i11I1Ii1I , '%y%m%d' )
 IiiIiiIi = 'http://www.predictz.com/predictions/20' + str ( iIIi1I )
 if 74 - 74: OooooO0oOO / i11iiII % oo0ooO0oOOOOo
 oOO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 o0oo0o0o0 = datetime . datetime . strftime ( oOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIii1 = datetime . datetime . strftime ( oOO , '%y%m%d' )
 Ooo0oO0 = 'http://www.predictz.com/predictions/20' + str ( iIii1 )
 if 88 - 88: OOO0O - i11iIiiIii % oo0ooO0oOOOOo * oo0Ooo0 + i11iiII
 if 52 - 52: i1111 . i1IIi11111i + OOO0O % oo
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIiII ) + '[/B][/COLOR]' , i1i1IIIIIIIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( II1i ) + '[/B][/COLOR]' , i1i1IiIiIi1Ii , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iiI1I1IIi11i1 ) , OOO0o , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iI1I11iIIi1 ) , IiiIiiIi , 51 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0oo0o0o0 ) , Ooo0oO0 , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 62 - 62: oo0ooO0oOOOOo
def I1i111i ( name , url , iconimage ) :
 if 42 - 42: i11iiII / II1Ii1iI1i % OOO0O
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 O0o = re . compile ( '<tr(.+?)</tr>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in O0o :
  try :
   i1iiIiI1Ii1i = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR red][B]' + i1iiIiI1Ii1i + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iII1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I11iiIIII1I1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1IIi1i1Ii1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   Iii = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   iII1 = iIIoO0O000oOoo0O ( iII1 )
   O0oOoOO ( '[COLOR mediumpurple][B]' + iII1 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + I11iiIIII1I1 + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + i1IIi1i1Ii1 + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + Iii + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 63 - 63: OoO000 + oo0ooO0oOOOOo
def IIII ( name , url , iconimage ) :
 if 8 - 8: oo0ooO0oOOOOo / i11iiII - i11iIiiIii % ooO0oo0oO0
 oOoOo00ooOooo = datetime . datetime . now ( )
 Ii = oOoOo00ooOooo . day
 if 66 - 66: OoO000
 OOoO00oo0000O = Ii
 if 67 - 67: OooOoO0Oo / oo . oOo0 / oOo0 - i1IIiiiii - i111I
 I11Ii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIiII = datetime . datetime . strftime ( I11Ii , '%A - %d %B %Y' )
 i1i1IIIIIIIi = 'http://www.predictz.com/predictions/'
 if 46 - 46: oooO0oo0oOOOO * I11i1i11i1I / oooO0oo0oOOOO + oo
 I1ii1II1iII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 II1i = datetime . datetime . strftime ( I1ii1II1iII , '%A - %d %B %Y' )
 o0OO00oo = datetime . datetime . strftime ( I1ii1II1iII , '%d' )
 i1i1IiIiIi1Ii = 'http://www.predictz.com/predictions/tomorrow/'
 if 56 - 56: oOo0 . i1111
 i1I = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 iiI1I1IIi11i1 = datetime . datetime . strftime ( i1I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1II1iii1i = datetime . datetime . strftime ( i1I , '%y%m%d' )
 OOO0o = 'http://www.predictz.com/predictions/20' + str ( i1II1iii1i )
 if 53 - 53: OooooO0oOO % oo0Ooo0 . iiIIiIiIi - OOO0O
 i111i11I1Ii1I = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iI1I11iIIi1 = datetime . datetime . strftime ( i111i11I1Ii1I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIIi1I = datetime . datetime . strftime ( i111i11I1Ii1I , '%y%m%d' )
 IiiIiiIi = 'http://www.predictz.com/predictions/20' + str ( iIIi1I )
 if 69 - 69: i1111 * i1IIi11111i - iiIIiIiIi - ooO0oo0oO0 + oo0ooO0oOOOOo - OooooO0oOO
 oOO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 o0oo0o0o0 = datetime . datetime . strftime ( oOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIii1 = datetime . datetime . strftime ( oOO , '%y%m%d' )
 Ooo0oO0 = 'http://www.predictz.com/predictions/20' + str ( iIii1 )
 if 50 - 50: oo0Ooo0 - iiIIiIiIi
 if 1 - 1: OooooO0oOO
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIiII ) + '[/B][/COLOR]' , i1i1IIIIIIIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( II1i ) + '[/B][/COLOR]' , i1i1IiIiIi1Ii , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iiI1I1IIi11i1 ) , OOO0o , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iI1I11iIIi1 ) , IiiIiiIi , 61 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0oo0o0o0 ) , Ooo0oO0 , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 12 - 12: iiIIiIiIi % i1IIi11111i + OooooO0oOO - II1Ii1iI1i . i1IIiiiii / i1IIi11111i
def o0IiiiI111I ( name , url , iconimage ) :
 if 49 - 49: oo0ooO0oOOOOo * i1IIiiiii + oo0Ooo0 + i1iIIIiI1I
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 O0o = re . compile ( '<tr(.+?)</tr>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in O0o :
  try :
   i1iiIiI1Ii1i = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR red][B]' + i1iiIiI1Ii1i + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iII1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OOOOOoo0 , ii1 = iII1 . split ( ' v ' )
   IIi11 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   ooo0O0OOO000o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   iiI1iii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   OOoOOo00O0o0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 3 ]
   Oo0O0Oo00O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 4 ]
   iIoo0ooooO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 5 ]
   iiIIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 6 ]
   i1i = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 7 ]
   iIIiI1iiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 8 ]
   I11Ii111I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 9 ]
   if 98 - 98: ooO0oo0oO0 + OooOoO0Oo % OOO0O + oo0Ooo0 % OOO0O
   if IIi11 == "W" :
    IIi11 = '[COLOR lime]W[/COLOR]'
   elif IIi11 == "D" :
    IIi11 = '[COLOR yellow]D[/COLOR]'
   else : IIi11 = '[COLOR red]L[/COLOR]'
   if 24 - 24: OooooO0oOO * OooOoO0Oo
   if ooo0O0OOO000o == "W" :
    ooo0O0OOO000o = '[COLOR lime]W[/COLOR]'
   elif ooo0O0OOO000o == "D" :
    ooo0O0OOO000o = '[COLOR yellow]D[/COLOR]'
   else : ooo0O0OOO000o = '[COLOR red]L[/COLOR]'
   if 40 - 40: i1IIiiiii - OOO0O * OOO0O . OOO0O + i111I
   if iiI1iii == "W" :
    iiI1iii = '[COLOR lime]W[/COLOR]'
   elif iiI1iii == "D" :
    iiI1iii = '[COLOR yellow]D[/COLOR]'
   else : iiI1iii = '[COLOR red]L[/COLOR]'
   if 77 - 77: ooO0oo0oO0 . i1IIiiiii % OooooO0oOO / i1IIiiiii
   if OOoOOo00O0o0 == "W" :
    OOoOOo00O0o0 = '[COLOR lime]W[/COLOR]'
   elif OOoOOo00O0o0 == "D" :
    OOoOOo00O0o0 = '[COLOR yellow]D[/COLOR]'
   else : OOoOOo00O0o0 = '[COLOR red]L[/COLOR]'
   if 54 - 54: OooooO0oOO + iiIIiIiIi - I11i1i11i1I
   if Oo0O0Oo00O == "W" :
    Oo0O0Oo00O = '[COLOR lime]W[/COLOR]'
   elif Oo0O0Oo00O == "D" :
    Oo0O0Oo00O = '[COLOR yellow]D[/COLOR]'
   else : Oo0O0Oo00O = '[COLOR red]L[/COLOR]'
   if 35 - 35: i1IIiiiii - i1IIiiiii + II1Ii1iI1i - oooO0oo0oOOOO - OooOoO0Oo
   if iIoo0ooooO == "W" :
    iIoo0ooooO = '[COLOR lime]W[/COLOR]'
   elif iIoo0ooooO == "D" :
    iIoo0ooooO = '[COLOR yellow]D[/COLOR]'
   else : iIoo0ooooO = '[COLOR red]L[/COLOR]'
   if 58 - 58: OOO0O - i1iIIIiI1I - i111I
   if iiIIi == "W" :
    iiIIi = '[COLOR lime]W[/COLOR]'
   elif iiIIi == "D" :
    iiIIi = '[COLOR yellow]D[/COLOR]'
   else : iiIIi = '[COLOR red]L[/COLOR]'
   if 96 - 96: ooO0oo0oO0
   if i1i == "W" :
    i1i = '[COLOR lime]W[/COLOR]'
   elif i1i == "D" :
    i1i = '[COLOR yellow]D[/COLOR]'
   else : i1i = '[COLOR red]L[/COLOR]'
   if 82 - 82: OOO0O + oooO0oo0oOOOO - OoO000 % OooooO0oOO * i11iIiiIii
   if iIIiI1iiI == "W" :
    iIIiI1iiI = '[COLOR lime]W[/COLOR]'
   elif iIIiI1iiI == "D" :
    iIIiI1iiI = '[COLOR yellow]D[/COLOR]'
   else : iIIiI1iiI = '[COLOR red]L[/COLOR]'
   if 15 - 15: oo0ooO0oOOOOo
   if I11Ii111I == "W" :
    I11Ii111I = '[COLOR lime]W[/COLOR]'
   elif I11Ii111I == "D" :
    I11Ii111I = '[COLOR yellow]D[/COLOR]'
   else : I11Ii111I = '[COLOR red]L[/COLOR]'
   if 39 - 39: oOo0 / i11iiII / i1IIi11111i * OooOoO0Oo
   OOOOOoo0 = iIIoO0O000oOoo0O ( OOOOOoo0 )
   ii1 = iIIoO0O000oOoo0O ( ii1 )
   O0oOoOO ( '[COLOR mediumpurple][B]' + OOOOOoo0 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[B]' + IIi11 + '  ' + ooo0O0OOO000o + '  ' + iiI1iii + '  ' + OOoOOo00O0o0 + '  ' + Oo0O0Oo00O + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR mediumpurple][B]' + ii1 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[B]' + iIoo0ooooO + '  ' + iiIIi + '  ' + i1i + '  ' + iIIiI1iiI + '  ' + I11Ii111I + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 44 - 44: oooO0oo0oOOOO + iiIIiIiIi . ooO0oo0oO0 + I11i1i11i1I / oooO0oo0oOOOO - oo0Ooo0
def o0o0OoOOOOOo ( name , url , iconimage ) :
 if 39 - 39: i111I * oOo0 * oooO0oo0oOOOO . oo0Ooo0 . oo + iiIIiIiIi
 oOoOo00ooOooo = datetime . datetime . now ( )
 Ii = oOoOo00ooOooo . day
 if 9 - 9: OOO0O + OooooO0oOO % i111I + oo0ooO0oOOOOo
 OOoO00oo0000O = Ii
 if 56 - 56: i111I + i11iiII - i1iIIIiI1I
 I11Ii = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 iIiII = datetime . datetime . strftime ( I11Ii , '%A - %d %B %Y' )
 i1i1IIIIIIIi = 'http://www.predictz.com/predictions/'
 if 24 - 24: oo0ooO0oOOOOo + iiIIiIiIi + oo0Ooo0 - ooO0oo0oO0
 I1ii1II1iII = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 II1i = datetime . datetime . strftime ( I1ii1II1iII , '%A - %d %B %Y' )
 o0OO00oo = datetime . datetime . strftime ( I1ii1II1iII , '%d' )
 i1i1IiIiIi1Ii = 'http://www.predictz.com/predictions/tomorrow/'
 if 49 - 49: oo0Ooo0 . iiIIiIiIi * OOO0O % OoO000 . oooO0oo0oOOOO
 i1I = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 iiI1I1IIi11i1 = datetime . datetime . strftime ( i1I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 i1II1iii1i = datetime . datetime . strftime ( i1I , '%y%m%d' )
 OOO0o = 'http://www.predictz.com/predictions/20' + str ( i1II1iii1i )
 if 48 - 48: oooO0oo0oOOOO * i1IIiiiii - oooO0oo0oOOOO / i1IIiiiii + OOO0O
 i111i11I1Ii1I = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iI1I11iIIi1 = datetime . datetime . strftime ( i111i11I1Ii1I , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIIi1I = datetime . datetime . strftime ( i111i11I1Ii1I , '%y%m%d' )
 IiiIiiIi = 'http://www.predictz.com/predictions/20' + str ( iIIi1I )
 if 52 - 52: oo % i1IIiiiii * i1111
 oOO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 o0oo0o0o0 = datetime . datetime . strftime ( oOO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIii1 = datetime . datetime . strftime ( oOO , '%y%m%d' )
 Ooo0oO0 = 'http://www.predictz.com/predictions/20' + str ( iIii1 )
 if 4 - 4: oo0Ooo0 % oooO0oo0oOOOO - i111I + iiIIiIiIi . OooooO0oOO % i1111
 if 9 - 9: i1111 * i1111 . i11iIiiIii * ooO0oo0oO0
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iIiII ) + '[/B][/COLOR]' , i1i1IIIIIIIi , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( II1i ) + '[/B][/COLOR]' , i1i1IiIiIi1Ii , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iiI1I1IIi11i1 ) , OOO0o , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( iI1I11iIIi1 ) , IiiIiiIi , 71 , iiiii , O0O0OO0O0O0 , '' )
 II11i1I11Ii1i ( str ( o0oo0o0o0 ) , Ooo0oO0 , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 18 - 18: oo . i1111 % OOO0O % i1IIiiiii
def oo0 ( name , url , iconimage ) :
 if 16 - 16: i1IIiiiii * oo / OooooO0oOO
 iII = o0 ( url )
 Oo0oOOo = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 O0o = re . compile ( '<tr(.+?)</tr>' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in O0o :
  try :
   i1iiIiI1Ii1i = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR red][B]' + i1iiIiI1Ii1i + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   iII1 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   OOOOOoo0 , ii1 = iII1 . split ( ' v ' )
   if 22 - 22: OooooO0oOO + ooO0oo0oO0 % I11i1i11i1I / oo0Ooo0 / i1IIiiiii
   OO0oIiII1iiI = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   I11iiIIII1I1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   i1IIi1i1Ii1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   Iii = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   IIi11 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
   ooo0O0OOO000o = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 1 ]
   iiI1iii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 2 ]
   OOoOOo00O0o0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 3 ]
   Oo0O0Oo00O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 4 ]
   iIoo0ooooO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 5 ]
   iiIIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 6 ]
   i1i = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 7 ]
   iIIiI1iiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 8 ]
   I11Ii111I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 9 ]
   if 54 - 54: OOO0O % OoO000 . i11iIiiIii
   if IIi11 == "W" :
    IIi11 = '[COLOR lime]W[/COLOR]'
   elif IIi11 == "D" :
    IIi11 = '[COLOR yellow]D[/COLOR]'
   else : IIi11 = '[COLOR red]L[/COLOR]'
   if 93 - 93: iiIIiIiIi % i11iIiiIii % OooOoO0Oo
   if ooo0O0OOO000o == "W" :
    ooo0O0OOO000o = '[COLOR lime]W[/COLOR]'
   elif ooo0O0OOO000o == "D" :
    ooo0O0OOO000o = '[COLOR yellow]D[/COLOR]'
   else : ooo0O0OOO000o = '[COLOR red]L[/COLOR]'
   if 64 - 64: OooOoO0Oo + i1IIi11111i * oooO0oo0oOOOO / I11i1i11i1I - oo0Ooo0 % oo0Ooo0
   if iiI1iii == "W" :
    iiI1iii = '[COLOR lime]W[/COLOR]'
   elif iiI1iii == "D" :
    iiI1iii = '[COLOR yellow]D[/COLOR]'
   else : iiI1iii = '[COLOR red]L[/COLOR]'
   if 59 - 59: oOo0 + i111I
   if OOoOOo00O0o0 == "W" :
    OOoOOo00O0o0 = '[COLOR lime]W[/COLOR]'
   elif OOoOOo00O0o0 == "D" :
    OOoOOo00O0o0 = '[COLOR yellow]D[/COLOR]'
   else : OOoOOo00O0o0 = '[COLOR red]L[/COLOR]'
   if 55 - 55: i11iIiiIii % ooO0oo0oO0 . II1Ii1iI1i + i111I / i11iIiiIii
   if Oo0O0Oo00O == "W" :
    Oo0O0Oo00O = '[COLOR lime]W[/COLOR]'
   elif Oo0O0Oo00O == "D" :
    Oo0O0Oo00O = '[COLOR yellow]D[/COLOR]'
   else : Oo0O0Oo00O = '[COLOR red]L[/COLOR]'
   if 10 - 10: i1iIIIiI1I - OooooO0oOO * ooO0oo0oO0 % ooO0oo0oO0 * OoO000 - i11iiII
   if iIoo0ooooO == "W" :
    iIoo0ooooO = '[COLOR lime]W[/COLOR]'
   elif iIoo0ooooO == "D" :
    iIoo0ooooO = '[COLOR yellow]D[/COLOR]'
   else : iIoo0ooooO = '[COLOR red]L[/COLOR]'
   if 97 - 97: i1111 % OooOoO0Oo + OooOoO0Oo - oo / i1IIiiiii * i1IIi11111i
   if iiIIi == "W" :
    iiIIi = '[COLOR lime]W[/COLOR]'
   elif iiIIi == "D" :
    iiIIi = '[COLOR yellow]D[/COLOR]'
   else : iiIIi = '[COLOR red]L[/COLOR]'
   if 17 - 17: i1IIiiiii
   if i1i == "W" :
    i1i = '[COLOR lime]W[/COLOR]'
   elif i1i == "D" :
    i1i = '[COLOR yellow]D[/COLOR]'
   else : i1i = '[COLOR red]L[/COLOR]'
   if 39 - 39: iiIIiIiIi . i1111
   if iIIiI1iiI == "W" :
    iIIiI1iiI = '[COLOR lime]W[/COLOR]'
   elif iIIiI1iiI == "D" :
    iIIiI1iiI = '[COLOR yellow]D[/COLOR]'
   else : iIIiI1iiI = '[COLOR red]L[/COLOR]'
   if 45 - 45: OooooO0oOO * OOO0O / ooO0oo0oO0
   if I11Ii111I == "W" :
    I11Ii111I = '[COLOR lime]W[/COLOR]'
   elif I11Ii111I == "D" :
    I11Ii111I = '[COLOR yellow]D[/COLOR]'
   else : I11Ii111I = '[COLOR red]L[/COLOR]'
   if 77 - 77: OooOoO0Oo - oo0Ooo0
   OOOOOoo0 = iIIoO0O000oOoo0O ( OOOOOoo0 )
   ii1 = iIIoO0O000oOoo0O ( ii1 )
   iII1 = iIIoO0O000oOoo0O ( iII1 )
   OO0oIiII1iiI = iIIoO0O000oOoo0O ( OO0oIiII1iiI )
   O0oOoOO ( '[COLOR blue][B]' + iII1 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + OO0oIiII1iiI + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]' + OOOOOoo0 + ' Form: - [/COLOR][B]' + IIi11 + '  ' + ooo0O0OOO000o + '  ' + iiI1iii + '  ' + OOoOOo00O0o0 + '  ' + Oo0O0Oo00O + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]' + ii1 + ' Form - [/COLOR][B]' + iIoo0ooooO + '  ' + iiIIi + '  ' + i1i + '  ' + iIIiI1iiI + '  ' + I11Ii111I + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]' + OOOOOoo0 + ' Win[/COLOR][COLOR dodgerblue][B] (' + I11iiIIII1I1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + i1IIi1i1Ii1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '[COLOR orange]' + ii1 + ' Win[/COLOR][COLOR dodgerblue][B] (' + Iii + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   O0oOoOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 11 - 11: i11iiII
  except : pass
  if 26 - 26: ooO0oo0oO0 * OooOoO0Oo - oOo0
def III1II111Ii1 ( name , url , iconimage ) :
 if 82 - 82: OooOoO0Oo - oOo0 + oo
 OO0 = [ ]
 iIiiIi11IIi = [ ]
 Oo0 = [ ]
 oOII1ii1ii11I1 = [ ]
 o0ooOO0o = [ ]
 if 71 - 71: i111I
 iII = o0 ( 'http://www.livescores.com' )
 Oo0oOOo = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( iII )
 oo0O00Oooo0O0 = str ( Oo0oOOo )
 O0o = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( oo0O00Oooo0O0 )
 for Oo0OoO00oOO0o in O0o :
  iIiI1iI1i1I = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  Oo0Oo000OO = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   OO0oIiII1iiI = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except :
   OO0oIiII1iiI = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 13 - 13: oo
  if "minute" in time . lower ( ) :
   o0ooOO0o . append ( '3' )
  elif "ht" in time . lower ( ) :
   o0ooOO0o . append ( '3' )
  elif "ft" in time . lower ( ) :
   o0ooOO0o . append ( '2' )
  else : o0ooOO0o . append ( '1' )
  if 70 - 70: OooOoO0Oo + oooO0oo0oOOOO . OooooO0oOO * i1IIiiiii
  OO0 . append ( iIiI1iI1i1I )
  iIiiIi11IIi . append ( Oo0Oo000OO )
  Oo0 . append ( OO0oIiII1iiI )
  oOII1ii1ii11I1 . append ( time )
  IIii1111 = list ( zip ( o0ooOO0o , OO0 , iIiiIi11IIi , Oo0 , oOII1ii1ii11I1 ) )
  if 2 - 2: i111I . oOo0 . OoO000
 O0oOoOO ( '[COLOR dodgerblue][B]The scores will update every 10 seconds.[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 O0oOoOO ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 42 - 42: oOo0 % OooooO0oOO / oo - OooooO0oOO * i11iIiiIii
 oo0o0000 = sorted ( IIii1111 , key = lambda ii11i1 : int ( ii11i1 [ 0 ] ) , reverse = True )
 iI1IiiiIiI1Ii = 0
 Oo000 = 0
 iiIiII11i1 = 0
 for oOo00Ooo0o0 , i1IiII1i1I , iI1ii1ii1I , iI1IIi11i1I1 , O00oo in oo0o0000 :
  if oOo00Ooo0o0 == "3" :
   if iI1IiiiIiI1Ii == 0 :
    O0oOoOO ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    iI1IiiiIiI1Ii = 1
  elif oOo00Ooo0o0 == "2" :
   if Oo000 == 0 :
    O0oOoOO ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    Oo000 = 1
  elif oOo00Ooo0o0 == "1" :
   if iiIiII11i1 == 0 :
    O0oOoOO ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    iiIiII11i1 = 1
  O00oo = O00oo . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  iI1IIi11i1I1 = iI1IIi11i1I1 . replace ( " " , "" )
  O0oOoOO ( '[COLOR red][B]' + O00oo + "[/B][/COLOR]- [COLOR blue]" + iI1IIi11i1I1 + "[/COLOR] | [COLOR white]" + i1IiII1i1I + "vs" + iI1ii1ii1I + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 58 - 58: ooO0oo0oO0 - i11iIiiIii - i11iIiiIii * i1IIiiiii + oo0ooO0oOOOOo . OOO0O
def OoOo00o ( ) :
 if 30 - 30: OOO0O . oo0Ooo0 / oo0Ooo0 * i11iIiiIii
 oo0O00Oooo0O0 = ''
 II1III1i1iiI = xbmc . Keyboard ( oo0O00Oooo0O0 , 'Enter Search Term' )
 II1III1i1iiI . doModal ( )
 if II1III1i1iiI . isConfirmed ( ) :
  oo0O00Oooo0O0 = II1III1i1iiI . getText ( )
  if len ( oo0O00Oooo0O0 ) > 1 :
   O000oo = oo0O00Oooo0O0 + "!" + iiiii
   Ii1I11I ( "all " + oo0O00Oooo0O0 , O000oo , iiiii )
  else : quit ( )
  if 27 - 27: i1IIiiiii - oooO0oo0oOOOO % oo0Ooo0 * OooOoO0Oo . OoO000 % ooO0oo0oO0
def IiIi1i ( name , url , iconimage ) :
 if 99 - 99: OOO0O . OooOoO0Oo
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 59 - 59: oo0Ooo0 / I11i1i11i1I / oOo0 / oooO0oo0oOOOO / OOO0O + oo0ooO0oOOOOo
def OOO00OO0oOo ( text ) :
 if 13 - 13: oo0ooO0oOOOOo % OooooO0oOO / OooOoO0Oo % OooOoO0Oo % oooO0oo0oOOOO
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 90 - 90: OoO000 . iiIIiIiIi / ooO0oo0oO0
 return text
 if 28 - 28: OoO000 + OooooO0oOO - iiIIiIiIi / ooO0oo0oO0 - i1IIi11111i
def iIIoO0O000oOoo0O ( text ) :
 if 45 - 45: oooO0oo0oOOOO / II1Ii1iI1i * OooooO0oOO * oo
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 35 - 35: i11iiII / i1iIIIiI1I % i1IIi11111i + ooO0oo0oO0
 return text
 if 79 - 79: OOO0O / iiIIiIiIi
def i11i1iIiii ( text ) :
 if 77 - 77: I11i1i11i1I
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 46 - 46: OooOoO0Oo
 return text
 if 72 - 72: i1iIIIiI1I * oOo0
def o0Oo0oO0oOO00 ( name , url , iconimage ) :
 if 67 - 67: II1Ii1iI1i
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]Opening link...[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 5 - 5: i1111 . i111I
 if "pl_type=user" in url :
  OOO = o0 ( url )
  url = re . compile ( '<meta property="og:video:iframe" content="(.+?)">' ) . findall ( OOO ) [ 0 ]
  if 57 - 57: i1IIi11111i
 if not "plugin" in url :
  try :
   if not 'http' in url : url = 'http://' + url
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 35 - 35: i111I - OooOoO0Oo / oo
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 50 - 50: OOO0O
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  i1i1Ii11Ii = urlresolver . HostedMediaFile ( url ) . resolve ( )
  O000oOo = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  O000oOo . setPath ( i1i1Ii11Ii )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( i1i1Ii11Ii , O000oOo , False )
  quit ( )
 else :
  i1i1Ii11Ii = url
  O000oOo = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  O000oOo . setPath ( i1i1Ii11Ii )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( i1i1Ii11Ii , O000oOo , False )
  quit ( )
  if 41 - 41: oooO0oo0oOOOO + OooooO0oOO . II1Ii1iI1i - i1111 * oo0ooO0oOOOOo . oo
def i1I1ii11i1Iii ( ) :
 if 68 - 68: oo0ooO0oOOOOo
 i11Ii1IIi = xbmc . getInfoLabel ( "System.BuildVersion" )
 Ii1I11i11I1i = float ( i11Ii1IIi [ : 4 ] )
 if Ii1I11i11I1i >= 11.0 and Ii1I11i11I1i <= 11.9 :
  oO00 = 'Eden'
 elif Ii1I11i11I1i >= 12.0 and Ii1I11i11I1i <= 12.9 :
  oO00 = 'Frodo'
 elif Ii1I11i11I1i >= 13.0 and Ii1I11i11I1i <= 13.9 :
  oO00 = 'Gotham'
 elif Ii1I11i11I1i >= 14.0 and Ii1I11i11I1i <= 14.9 :
  oO00 = 'Helix'
 elif Ii1I11i11I1i >= 15.0 and Ii1I11i11I1i <= 15.9 :
  oO00 = 'Isengard'
 elif Ii1I11i11I1i >= 16.0 and Ii1I11i11I1i <= 16.9 :
  oO00 = 'Jarvis'
 elif Ii1I11i11I1i >= 17.0 and Ii1I11i11I1i <= 17.9 :
  oO00 = 'Krypton'
 else : oO00 = "Decline"
 if 7 - 7: oooO0oo0oOOOO % OooOoO0Oo + i11iiII + i1IIiiiii % i111I . I11i1i11i1I
 return oO00
 if 56 - 56: i1iIIIiI1I
def o0 ( url ) :
 if 84 - 84: OOO0O - i11iIiiIii
 i1II1II1iii1i = urllib2 . Request ( url )
 i1II1II1iii1i . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 Ii1IIi = urllib2 . urlopen ( i1II1II1iii1i )
 iII = Ii1IIi . read ( )
 Ii1IIi . close ( )
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return iII
 if 75 - 75: OoO000 - OOO0O - ooO0oo0oO0 % oo0ooO0oOOOOo
def Oo0O0O0ooO0O ( url ) :
 if 58 - 58: oooO0oo0oOOOO . OoO000 / i111I . oo / I11i1i11i1I * i1111
 i1II1II1iii1i = urllib2 . Request ( url )
 i1II1II1iii1i . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 Ii1IIi = urllib2 . urlopen ( i1II1II1iii1i )
 iII = Ii1IIi . read ( )
 Ii1IIi . close ( )
 return iII
 if 53 - 53: i1IIiiiii - oooO0oo0oOOOO / oo0ooO0oOOOOo % i1iIIIiI1I * i1IIi11111i % oOo0
def oooo0O0O0o0 ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 69 - 69: i11iiII
 if 83 - 83: oo0ooO0oOOOOo
 if 38 - 38: OooOoO0Oo + i111I . II1Ii1iI1i
 if 19 - 19: i1iIIIiI1I - oo0ooO0oOOOOo - i1IIiiiii - OOO0O . i1iIIIiI1I . OooOoO0Oo
 if 48 - 48: i1iIIIiI1I + OoO000
def O0o0o0 ( ) :
 if 15 - 15: ooO0oo0oO0 . oooO0oo0oOOOO
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 70 - 70: i1IIiiiii . i11iIiiIii % i1IIiiiii . oooO0oo0oOOOO - ooO0oo0oO0
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for i111i1iIi1 , OoO0oO , IiiI1iiI1III1i in os . walk ( IiIi11iIIi1Ii ) :
   iii1i11 = 0
   iii1i11 += len ( IiiI1iiI1III1i )
   if iii1i11 > 0 :
    for Oooo in IiiI1iiI1III1i :
     try :
      if ( Oooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( i111i1iIi1 , Oooo ) )
     except :
      pass
    for oooOo in OoO0oO :
     try :
      shutil . rmtree ( os . path . join ( i111i1iIi1 , oooOo ) )
     except :
      pass
      if 98 - 98: i1111 - i111I * oooO0oo0oOOOO
   else :
    pass
    if 85 - 85: i111I % OOO0O * ooO0oo0oO0
 if os . path . exists ( Oo0O ) == True :
  for i111i1iIi1 , OoO0oO , IiiI1iiI1III1i in os . walk ( Oo0O ) :
   iii1i11 = 0
   iii1i11 += len ( IiiI1iiI1III1i )
   if iii1i11 > 0 :
    for Oooo in IiiI1iiI1III1i :
     try :
      if ( Oooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( i111i1iIi1 , Oooo ) )
     except :
      pass
    for oooOo in OoO0oO :
     try :
      shutil . rmtree ( os . path . join ( i111i1iIi1 , oooOo ) )
     except :
      pass
      if 44 - 44: ooO0oo0oO0 . i11iiII + OooOoO0Oo . iiIIiIiIi
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  II1i11 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 28 - 28: i1111 - OooooO0oOO % OOO0O + oo - OOO0O
  for i111i1iIi1 , OoO0oO , IiiI1iiI1III1i in os . walk ( II1i11 ) :
   iii1i11 = 0
   iii1i11 += len ( IiiI1iiI1III1i )
   if 28 - 28: i1111 . OooooO0oOO + oooO0oo0oOOOO . oooO0oo0oOOOO . oOo0
   if iii1i11 > 0 :
    for Oooo in IiiI1iiI1III1i :
     os . unlink ( os . path . join ( i111i1iIi1 , Oooo ) )
    for oooOo in OoO0oO :
     shutil . rmtree ( os . path . join ( i111i1iIi1 , oooOo ) )
     if 98 - 98: i111I % oooO0oo0oOOOO - oooO0oo0oOOOO
   else :
    pass
  OoOOoO0O0oO = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 92 - 92: I11i1i11i1I / i11iIiiIii + i11iiII
  for i111i1iIi1 , OoO0oO , IiiI1iiI1III1i in os . walk ( OoOOoO0O0oO ) :
   iii1i11 = 0
   iii1i11 += len ( IiiI1iiI1III1i )
   if 87 - 87: OOO0O % ooO0oo0oO0
   if iii1i11 > 0 :
    for Oooo in IiiI1iiI1III1i :
     os . unlink ( os . path . join ( i111i1iIi1 , Oooo ) )
    for oooOo in OoO0oO :
     shutil . rmtree ( os . path . join ( i111i1iIi1 , oooOo ) )
     if 72 - 72: oOo0 . oOo0 - i11iiII
   else :
    pass
    if 48 - 48: I11i1i11i1I - iiIIiIiIi + I11i1i11i1I - i1IIi11111i * i11iIiiIii . i1iIIIiI1I
 iii11 = o00oOO0 ( )
 if 35 - 35: OoO000 . oooO0oo0oOOOO + I11i1i11i1I + oOo0 + II1Ii1iI1i
 for OooOooO0O0o0 in iii11 :
  OOO0o0 = xbmc . translatePath ( OooOooO0O0o0 . path )
  if os . path . exists ( OOO0o0 ) == True :
   for i111i1iIi1 , OoO0oO , IiiI1iiI1III1i in os . walk ( OOO0o0 ) :
    iii1i11 = 0
    iii1i11 += len ( IiiI1iiI1III1i )
    if iii1i11 > 0 :
     for Oooo in IiiI1iiI1III1i :
      os . unlink ( os . path . join ( i111i1iIi1 , Oooo ) )
     for oooOo in OoO0oO :
      shutil . rmtree ( os . path . join ( i111i1iIi1 , oooOo ) )
      if 34 - 34: i1IIi11111i % I11i1i11i1I - OOO0O + i1iIIIiI1I
    else :
     pass
     if 79 - 79: i1111 - iiIIiIiIi . II1Ii1iI1i + oooO0oo0oOOOO % oooO0oo0oOOOO * i1IIi11111i
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 7 - 7: II1Ii1iI1i + oOo0 % i1iIIIiI1I / oo0ooO0oOOOOo + II1Ii1iI1i
def I1ii11I ( ) :
 II1II1IIII = [ ]
 i1iiiiI1IiIIii = sys . argv [ 2 ]
 if len ( i1iiiiI1IiIIii ) >= 2 :
  OoOo00o0OO = sys . argv [ 2 ]
  IIIIiii = OoOo00o0OO . replace ( '?' , '' )
  if ( OoOo00o0OO [ len ( OoOo00o0OO ) - 1 ] == '/' ) :
   OoOo00o0OO = OoOo00o0OO [ 0 : len ( OoOo00o0OO ) - 2 ]
  Ii11Ii1iI = IIIIiii . split ( '&' )
  II1II1IIII = { }
  for IIIIii1I in range ( len ( Ii11Ii1iI ) ) :
   OOOo00 = { }
   OOOo00 = Ii11Ii1iI [ IIIIii1I ] . split ( '=' )
   if ( len ( OOOo00 ) ) == 2 :
    II1II1IIII [ OOOo00 [ 0 ] ] = OOOo00 [ 1 ]
 return II1II1IIII
 if 15 - 15: oo0Ooo0
def II11i1I11Ii1i ( name , url , mode , iconimage , fanart , description = '' ) :
 if 94 - 94: OooOoO0Oo % i1111 * II1Ii1iI1i * ooO0oo0oO0
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 oO0oOoo0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 II1iI11 = True
 O000oOo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 O000oOo . setProperty ( "fanart_Image" , fanart )
 O000oOo . setProperty ( "icon_Image" , iconimage )
 II1iI11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO0oOoo0O , listitem = O000oOo , isFolder = True )
 return II1iI11
 if 88 - 88: oo0Ooo0 + i11iIiiIii % OooooO0oOO * oOo0 * oOo0 * i1IIiiiii
def O0oOoOO ( name , url , mode , iconimage , fanart , description = '' ) :
 if 24 - 24: iiIIiIiIi / i1iIIIiI1I + OoO000 . OoO000
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 oO0oOoo0O = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 II1iI11 = True
 O000oOo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 O000oOo . setProperty ( "fanart_Image" , fanart )
 O000oOo . setProperty ( "icon_Image" , iconimage )
 II1iI11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO0oOoo0O , listitem = O000oOo , isFolder = False )
 return II1iI11
 if 39 - 39: iiIIiIiIi + oooO0oo0oOOOO / II1Ii1iI1i % OoO000 / OooooO0oOO * OoO000
OoOo00o0OO = I1ii11I ( ) ; O000oo = None ; OoOO0oo0o = None ; o0OO00000 = None ; OO00OoI1iIIiiiI = None ; Oo0oOOOoOooOo = None ; oOooOOOoOo = None
try : OO00OoI1iIIiiiI = urllib . unquote_plus ( OoOo00o0OO [ "site" ] )
except : pass
try : O000oo = urllib . unquote_plus ( OoOo00o0OO [ "url" ] )
except : pass
try : OoOO0oo0o = urllib . unquote_plus ( OoOo00o0OO [ "name" ] )
except : pass
try : o0OO00000 = int ( OoOo00o0OO [ "mode" ] )
except : pass
try : Oo0oOOOoOooOo = urllib . unquote_plus ( OoOo00o0OO [ "iconimage" ] )
except : pass
try : oOooOOOoOo = urllib . unquote_plus ( OoOo00o0OO [ "fanart" ] )
except : pass
if 97 - 97: i1iIIIiI1I % i1IIiiiii % OOO0O / i1111 % oOo0
if o0OO00000 == None or O000oo == None or len ( O000oo ) < 1 : o0O0o0Oo ( )
elif o0OO00000 == 1 : I1i ( OoOO0oo0o , O000oo )
elif o0OO00000 == 2 : o0Oo0oO0oOO00 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 3 : O00oO000O0O ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 4 : PLAYSD ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 7 : o0000oO ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 8 : II1IIIIiII1i ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 9 : AUTO_UPDATER ( OoOO0oo0o )
elif o0OO00000 == 10 : o00II1i111 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 11 : o0oO000oo ( )
elif o0OO00000 == 12 : Ii1ii111i1 ( O000oo )
elif o0OO00000 == 19 : III ( O000oo )
elif o0OO00000 == 20 : Ii1I11I ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 21 : oo0OOo0O ( O000oo )
elif o0OO00000 == 22 : oo0ooOO ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 23 : iii1 ( )
elif o0OO00000 == 24 : iiI11i1II ( )
elif o0OO00000 == 25 : OOOO0OOO ( )
elif o0OO00000 == 26 : IiiI ( )
elif o0OO00000 == 30 : OOoo ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 40 : Ii1iIi111i1i1 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 41 : oo0O ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 50 : IiIiiI11i1Ii ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 51 : I1i111i ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 60 : IIII ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 61 : o0IiiiI111I ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 70 : o0o0OoOOOOOo ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 71 : oo0 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 80 : III1II111Ii1 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 90 : IiIi1I1 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 91 : iI1IiI11ii1I1 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 95 : I11i1II ( )
elif o0OO00000 == 96 : I11iiiii1II ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 97 : OO0oo0O ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 100 : OoOo00o ( )
elif o0OO00000 == 500 : O0o0o0 ( )
elif o0OO00000 == 201 : iii1i1I1i1 ( )
elif o0OO00000 == 202 : OOoooiIIiIiI1I1 ( O000oo )
elif o0OO00000 == 203 : iIiIIIIIii ( O000oo )
elif o0OO00000 == 204 : i1i111iI ( O000oo )
elif o0OO00000 == 205 : OoO ( O000oo )
elif o0OO00000 == 206 : Oooo00 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 210 : ooo0o000O ( O000oo )
elif o0OO00000 == 220 : o0iiiI1I1iIIIi1 ( O000oo )
elif o0OO00000 == 221 : oO0o00oOOooO0 ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 800 : IiIi1i ( OoOO0oo0o , O000oo , Oo0oOOOoOooOo )
elif o0OO00000 == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 83 - 83: oo / OoO000 / OoO000 * OooOoO0Oo / OooOoO0Oo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if o0OO00000 == 80 :
 xbmc . sleep ( 10000 )
 xbmc . executebuiltin ( 'Container.Refresh' )