import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,urlresolver,liveresolver,hashlib
import base64
import requests
from resources.lib.modules import regex

addon_id            = 'plugin.video.sportie'
AddonTitle          = '[COLOR mediumpurple][B]SPORTIE[/B][/COLOR]'
fanarts             = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon                = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
baseurl 		    = base64.decodestring('aHR0cDovL3RkYnJlcG8uY29tL3ByaXZhdGUvYWRkb25zL3Nwb3J0aWUvTUFJTl9NRU5VLnhtbA==') 
dialog              = xbmcgui.Dialog()
dp                  = xbmcgui.DialogProgress()
GET_VERSION         =  xbmc.translatePath('special://home/addons/' + addon_id + '/addon.xml')
GET_REPO_VERSION    =  xbmc.translatePath('special://home/addons/repository.echo/addon.xml')
BASE_UPDATE         = base64.b64decode(b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=')
BASE_REPO_UPDATE    = base64.b64decode(b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==')

headers = {
    'User-Agent': base64.b64decode(b'VGhlV2l6YXJkSXNIZXJl'),
}

def GetMenu():

	a=open(GET_VERSION).read()
	b=a.replace('\n',' ').replace('\r',' ')
	match=re.compile('name=".+?".+?version="(.+?)".+?provider-name=".+?">').findall(str(b))
	for item in match:
		new_version = float(item)
	
	#addDir('[COLOR yellow][B]Search Sportie[/B][/COLOR]',baseurl,100,icon,fanarts)
	#addDir('SCRAPER TEST',baseurl,11,icon,fanarts)

	link=open_url(baseurl)
	match= re.compile('<item>(.+?)</item>').findall(link)
	for item in match:
	
		if '<vipchannels>' in item:
			name=re.compile('<title>(.+?)</title>').findall(item)[0]
			url=re.compile('<vipchannels>(.+?)</vipchannels>').findall(item)[0]            
			addDir(name,url,19,icon,fanarts)

		elif '<vipgames>' in item:
			name=re.compile('<title>(.+?)</title>').findall(item)[0]
			url=re.compile('<vipgames>(.+?)</vipgames>').findall(item)[0]            
			addDir(name,url,21,icon,fanarts)

		elif '<m3ulists>display</m3ulists>' in item:
			name=re.compile('<title>(.+?)</title>').findall(item)[0]
			addDir(name,baseurl,11,icon,fanarts)

		elif '<sportsdevil>' in item:
			links=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(item)
			if len(links)==1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]            
				url=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(item)[0]
				referer=re.compile('<referer>(.+?)</referer>').findall(item)[0]
				check = referer
				suffix = "/"
				if not check.endswith(suffix):
					refer = check + "/"
				else:
					refer = check
				link = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title='+str(name)+'%26url=' + url
				url = link + '%26referer=' +refer
				addLink(name,url,4,iconimage,fanart)   
			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				addLink(name,url2+'NOTPLAY',8,iconimage,fanart)       
                
		elif '<folder>'in item:
			data=re.compile('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
			for name,url,iconimage,fanart in data:
				addDir(name,url,1,iconimage,fanart)
		elif '<m3u>'in item:
			data=re.compile('<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
			for name,url,iconimage,fanart in data:
				addDir(name,url,10,iconimage,fanart)
		else:
			links=re.compile('<link>(.+?)</link>').findall(item)
			if len(links)==1:
				data=re.compile('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
				lcount=len(match)
				for name,url,iconimage,fanart in data:
					addLink(name,url,2,iconimage,fanart)
			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]
				addLink(name,baseurl,3,iconimage,fanart)

	addItem('[COLOR grey][B]VER ' + str(new_version) + ' - CHECK FOR UPDATES[/B][/COLOR]',baseurl,9,icon,fanarts,"")

def GetContent(name,url):

	hash = []
	url2 = url
	link=open_url(url)

	match= re.compile('<item>(.+?)</item>').findall(link)
	for item in match:
	
		if '<regex>' in item:
			regdata = re.compile('(<regex>.+?</regex>)', re.MULTILINE|re.DOTALL).findall(item)
			regdata = ''.join(regdata)
			reglist = re.compile('(<listrepeat>.+?</listrepeat>)', re.MULTILINE|re.DOTALL).findall(regdata)
			regdata = urllib.quote_plus(regdata)

			reghash = hashlib.md5()
			for i in regdata: reghash.update(str(i))
			reghash = str(reghash.hexdigest())

			item = item.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
			item = re.sub('<regex>.+?</regex>','', item)
			item = re.sub('<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>','', item)
			item = re.sub('<link></link>','', item)
			
			name = re.sub('<meta>.+?</meta>','', item)
			try: name = re.findall('<title>(.+?)</title>', name)[0]
			except: name = re.findall('<name>(.+?)</name>', name)[0]

			try: date = re.findall('<date>(.+?)</date>', item)[0]
			except: date = ''
			if re.search(r'\d+', date): name += ' [COLOR red] Updated %s[/COLOR]' % date

			try: image2 = re.findall('<thumbnail>(.+?)</thumbnail>', item)[0]
			except: image2 = icon

			try: fanart2 = re.findall('<fanart>(.+?)</fanart>', item)[0]
			except: fanart2 = fanarts

			try: meta = re.findall('<meta>(.+?)</meta>', item)[0]
			except: meta = '0'

			try: url = re.findall('<link>(.+?)</link>', item)[0]
			except: url = '0'
			url = url.replace('>search<', '><preset>search</preset>%s<' % meta)
			url = '<preset>search</preset>%s' % meta if url == 'search' else url
			url = url.replace('>searchsd<', '><preset>searchsd</preset>%s<' % meta)
			url = '<preset>searchsd</preset>%s' % meta if url == 'searchsd' else url
			url = re.sub('<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>','', url)

			if not regdata == '':
				hash.append({'regex': reghash, 'response': regdata})
				url += '|regex=%s' % regdata

			addLink(name,url,30,image2,fanart2)

		elif '<sportsdevil>' in item:
			links=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(item)
			if len(links)==1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]         				
				url=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(item)[0]
				try:
					referer=re.compile('<referer>(.+?)</referer>').findall(item)[0]
				except: referer = "None"
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]  
				try:
					fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]   
				except: fanart = fanarts
				check = referer
				suffix = "/"
				if not check.endswith(suffix):
					refer = check + "/"
				else:
					refer = check
				link = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title='+str(name)+'%26url=' + url
				url = link + '%26referer=' +refer
				addLink(name,url,2,iconimage,fanart)

			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				try:
					fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]   
				except: fanart = fanarts
				addLink(name,url2+'NOTPLAY',8,iconimage,fanart)

		elif '<folder>'in item:
			data=re.compile('<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
			for name,url,iconimage,fanart in data:
				addDir(name,url,1,iconimage,fanart)
		elif '<m3u>'in item:
			data=re.compile('<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
			for name,url,iconimage,fanart in data:
				addDir(name,url,10,iconimage,fanart)
		else:
			links=re.compile('<link>(.+?)</link>').findall(item)
			if len(links)==1:
				data=re.compile('<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>').findall(item)
				lcount=len(match)
				for name,url,iconimage,fanart in data:
					addLink(name,url,2,iconimage,fanart)
			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				try:
					fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]
				except: fanart = fanarts
				addLink(name,url2,3,iconimage,fanart)  

def GETMULTI(name,url,iconimage):
	streamurl=[]
	streamname=[]
	streamicon=[]
	link=open_url(url)
	urls=re.compile('<title>'+re.escape(name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
	iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(urls)[0]
	links=re.compile('<link>(.+?)</link>').findall(urls)
	i=1
	for sturl in links:
                sturl2=sturl
                if '(' in sturl:
                        sturl=sturl.split('(')[0]
                        caption=str(sturl2.split('(')[1].replace(')',''))
                        streamurl.append(sturl)
                        streamname.append(caption)
                else:
                        streamurl.append( sturl )
                        streamname.append( 'Link '+str(i) )
                i=i+1
	name='[COLOR red]'+name+'[/COLOR]'
	dialog = xbmcgui.Dialog()
	select = dialog.select(name,streamname)
	if select < 0:
		quit()
	else:
		url = streamurl[select]
		print url

	url = streamurl[select]
	name = streamname[select]
	PLAYLINK(name,url,icon)
                
def GETMULTI_SD(name,url,iconimage):

    streamurl=[]
    streamname=[]
    streamicon=[]
    streamnumber=[]
    url = url.replace('NOTPLAY','')
    link=open_url(url)
    urls=re.compile('<title>'+re.escape(name)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
    links=re.compile('<sportsdevil>(.+?)</sportsdevil>').findall(urls)
    iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(urls)[0]
	
    sdbase = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title='+str(name)+'%26url='

    i=1

    for sturl in links:
                sturl2=sturl
                if '(' in sturl:
                        sturl=sturl.split('(')[0]
                        caption=str(sturl2.split('(')[1].replace(')',''))
                        streamurl.append(sturl)
                        streamname.append(caption)
                        streamnumber.append('Stream ' + str(i))
                else:
                        streamurl.append( sturl )
                        streamname.append( 'Link '+str(i) )

                i=i+1

    name='[COLOR red]'+name+'[/COLOR]'

    dialog = xbmcgui.Dialog()
    select = dialog.select(name,streamname)
    if select < 0:
        quit()
    else:
        check = streamname[select]
        suffix = "/"
        if not check.endswith(suffix):
              refer = check + "/"
        else:
              refer = check
        url = sdbase + streamurl[select] + "%26referer=" + refer

    name = streamname[select]
    PLAYLINK(name,url,icon)

def GET_REGEX(name,url,iconimage):

	r, x = re.findall('(.+?)\|regex=(.+?)$', url)[0]
	r += urllib.unquote_plus(x)
	url = regex.resolve(r)

	PLAYLINK(name,url,iconimage)

def SCRAPE_M3U8():

	i = 0
	result = requests.get('http://dvbsat.ru/smf/index.php?action=recent;start=0')
	match = re.compile('#EXTM3U(.+?)</div>',re.DOTALL).findall(result.content)
	for item in match:
		i = i + 1
		item = item.replace('<br />','\n')
		url = item
		addDir('[COLOR green][B]LIST[/COLOR][COLOR blue] ' + str(i) + '[/B][/COLOR]',url,12,icon,fanarts)

	result = requests.get('http://dvbsat.ru/smf/index.php?action=recent;start=10')
	match = re.compile('#EXTM3U(.+?)</div>',re.DOTALL).findall(result.content)
	for item in match:
		i = i + 1
		item = item.replace('<br />','\n')
		url = item
		addDir('[COLOR green][B]LIST[/COLOR][COLOR blue] ' + str(i) + '[/B][/COLOR]',url,12,icon,fanarts)
		
	result = requests.get('http://dvbsat.ru/smf/index.php?action=recent;start=20')
	match = re.compile('#EXTM3U(.+?)</div>',re.DOTALL).findall(result.content)
	for item in match:
		i = i + 1
		item = item.replace('<br />','\n')
		url = item
		addDir('[COLOR green][B]LIST[/COLOR][COLOR blue] ' + str(i) + '[/B][/COLOR]',url,12,icon,fanarts)

def GENERATE_M3U8(url):

    url = url.replace('#AAASTREAM:','#A:')
    url = url.replace('#EXTINF:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(url)
    li = []
    for params, display_name, url in matches:
        item_data = {"params": params, "display_name": display_name, "url": url}
        li.append(item_data)
    list = []
    for channel in li:
        item_data = {"display_name": channel["display_name"], "url": channel["url"]}
        matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
        for field, value in matches:
            item_data[field.strip().lower().replace('-', '_')] = value.strip()
        list.append(item_data)

    for channel in list:
        name = GetEncodeString(channel["display_name"])
        url = GetEncodeString(channel["url"])
        url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
        if not ".m3u8" in url:
		
            addLink(name,url,2,icon,fanarts,'')
        else:
            addDir(name,url,10,icon,fanarts,'')

def GET_SEARCH_TERMS(url):

	addDir('[COLOR yellow][B]Search Sportie[/B][/COLOR]',baseurl,100,icon,fanarts)

	link=open_url(url)
	match= re.compile('<item>(.+?)</item>').findall(link)
	for item in match:

			name=re.compile('<title>(.+?)</title>').findall(item)[0]
			iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
			fanart=re.compile('<fanart>(.+?)</fanart>').findall(item)[0]  
			url = name + '!' + iconimage
			addDir('[COLOR blue][B]'+name+'[/B][/COLOR]',url,20,iconimage,fanart)

	xbmc.executebuiltin('Container.SetViewMode(500)')

def GET_SEARCH_GAMES(url):

	link=open_url(url)
	url2 = url
	match= re.compile('<item>(.+?)</item>').findall(link)
	for item in match:
	
			links=re.compile('<search>(.+?)</search>').findall(item)
			if len(links)==1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]         				
				url=re.compile('<search>(.+?)</search>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				url = name + "!" + url + "!" + iconimage
				name = '[COLOR mediumpurple][B]' + name + '[/COLOR][/B]'
				addDir(name,url,20,iconimage,fanart)
				

			elif len(links)>1:
				name=re.compile('<title>(.+?)</title>').findall(item)[0]
				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
				url = url2 + "!" + name + "!" + iconimage
				name = '[COLOR mediumpurple][B]' + name + '[/COLOR][/B]'
				addDir(name,url,22,iconimage,fanart)

#			elif len(links)>1:
#				name=re.compile('<title>(.+?)</title>',re.DOTALL).findall(item)[0]
#				url=re.compile('<search>(.+?)</search>').findall(item)
#				iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(item)[0]
#				for sturl in links:
#					#multiple = str(multiple) + " " + str(sturl)
##					termlist.append(sturl)		
#
#			url = name + "!" + termlist + "!" + iconimage
#			addDir(name,url,20,iconimage,fanart)


def SEARCH_THROUGH_M3U_MULTI(name,url,iconimage):

	try:
		url,DISPLAY_NAME,iconimage = url.split('!')
	except: 
		dialog.ok(AddonTitle, "[COLOR green]Sorry there was a problem processing your request.[/COLOR]","[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]")
		quit()

	termlist=[]

	link=open_url(url)
	urls=re.compile('<title>'+re.escape(DISPLAY_NAME)+'</title>(.+?)</item>',re.DOTALL).findall(link)[0]
	iconimage=re.compile('<thumbnail>(.+?)</thumbnail>').findall(urls)[0]
	links=re.compile('<search>(.+?)</search>').findall(urls)
	for sturl in links:
		termlist.append( sturl )

	dp.create(AddonTitle,"[COLOR blue]We are just getting the channels links for you.[/COLOR]",'[COLOR yellow]Please wait...[/COLOR]','')	
	dp.update(0)

	z = 0

	namelist=[]
	urllist=[]
	countlist=[]
	dp.update(0)
	result = requests.get('http://dvbsat.ru/smf/index.php?action=recent;start=0')
	match = re.compile('#EXTM3U(.+?)</div>',re.DOTALL).findall(result.content)
	for item in match:
		if z < 100:
			dp.update(z)
			z = z + 10
		item = item.replace('<br />','\n')
		url = item
		url = url.replace('#AAASTREAM:','#A:')
		url = url.replace('#EXTINF:','#A:')
		matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(url)
		li = []
		for params, display_name, url in matches:
			item_data = {"params": params, "display_name": display_name, "url": url}
			li.append(item_data)
		lists = []
		for channel in li:
			item_data = {"display_name": channel["display_name"], "url": channel["url"]}
			matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
			for field, value in matches:
				item_data[field.strip().lower().replace('-', '_')] = value.strip()
			lists.append(item_data)

		for channel in lists:
			name = GetEncodeString(channel["display_name"])
			url = GetEncodeString(channel["url"])
			url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
			namelist.append(name)				
			urllist.append(url)		
			if "hd" in name.lower():
				countlist.append("1")
			else:
				countlist.append("0")
			combinedlists = list(zip(countlist,namelist,urllist))
	tup = sorted(combinedlists, key=lambda x: int(x[0]),reverse=True)
	term_tup = sorted(termlist)

	a = 0
	
	dp.update(100)

	addLink('                    [COLOR yellow][B][I]LINKS FOR ' + DISPLAY_NAME.upper() + '[/I][/B][/COLOR]',url,999,iconimage,fanarts,'')
	addLink('================================================================',url,999,iconimage,fanarts,'')
	
	for term in term_tup:
		addLink('                                  [COLOR mediumpurple][B][I]' + term.upper() + ' LINKS[/I][/B][/COLOR]',url,999,iconimage,fanarts,'')
		term = term.replace(' ','')
		name = name.replace(' ','')
		for count,name,url in tup:
			if term.lower() in name.lower():
				a = a + 1
				if "hd" in name.lower():
					addLink('                                             [COLOR green][B]LINK[/COLOR][COLOR blue] ' + str(a) + '[/COLOR] - [COLOR red]HD[/COLOR][/B]',url,2,iconimage,fanarts,'')
				else:
					addLink('                                             [COLOR green][B]LINK[/COLOR][COLOR blue] ' + str(a) + '[/COLOR] - [COLOR white]SD[/COLOR][/B]',url,2,iconimage,fanarts,'')
		if a == 0:
			addLink('                                      [COLOR white][B]NO LINKS FOUND[/COLOR][/B]',url,999,iconimage,fanarts,'')

	dp.close()

def SEARCH_THROUGH_M3U(name,url,iconimage):

	dp.create(AddonTitle,"[COLOR blue]We are just getting the channels links for you.[/COLOR]",'[COLOR yellow]Please wait...[/COLOR]','')	
	dp.update(0)

	z = 0
	try:
		DISPLAY_NAME,term,iconimage = url.split('!')
	except:
		try:
			term,iconimage = url.split('!')
			DISPLAY_NAME = term
		except: 
			dialog.ok(AddonTitle, "[COLOR green]Sorry there was a problem processing your request.[/COLOR]","[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]")
			quit()

	flag = 0

	if "all" in name.lower():
		term = term.replace('all','').replace('ALL','').replace('All','')
		DISPLAY_NAME = DISPLAY_NAME.replace('all','').replace('ALL','').replace('All','')
		flag=1

	namelist=[]
	urllist=[]
	countlist=[]
	dp.update(0)
	result = requests.get('http://dvbsat.ru/smf/index.php?action=recent;start=0')
	match = re.compile('#EXTM3U(.+?)</div>',re.DOTALL).findall(result.content)
	for item in match:
		if z < 100:
			dp.update(z)
			z = z + 10
		item = item.replace('<br />','\n')
		url = item
		url = url.replace('#AAASTREAM:','#A:')
		url = url.replace('#EXTINF:','#A:')
		matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(url)
		li = []
		for params, display_name, url in matches:
			item_data = {"params": params, "display_name": display_name, "url": url}
			li.append(item_data)
		lists = []
		for channel in li:
			item_data = {"display_name": channel["display_name"], "url": channel["url"]}
			matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
			for field, value in matches:
				item_data[field.strip().lower().replace('-', '_')] = value.strip()
			lists.append(item_data)

		for channel in lists:
			name = GetEncodeString(channel["display_name"])
			url = GetEncodeString(channel["url"])
			url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
			namelist.append(name)				
			urllist.append(url)		
			if "hd" in name.lower():
				countlist.append("1")
			else:
				countlist.append("0")
			combinedlists = list(zip(countlist,namelist,urllist))
	tup = sorted(combinedlists, key=lambda x: int(x[0]),reverse=True)
	
	a = 0
	
	dp.update(100)

	addLink('                                [COLOR yellow][B][I]LINKS FOR ' + DISPLAY_NAME.upper() + '[/I][/B][/COLOR]',url,999,iconimage,fanarts,'')
	addLink('================================================================',url,999,iconimage,fanarts,'')
	for count,name,url in tup:
		term = term.replace(' ','')
		if flag == 1:
			new_name = name
		name = name.replace(' ','')
		if term.lower() in name.lower():
			a = a + 1
			if flag == 1:
				if "hd" in name.lower():
					addLink('                                          [COLOR blue][B] ' + str(new_name) + '[/COLOR] - [COLOR red]HD[/COLOR][/B]',url,2,iconimage,fanarts,'')
				else:
					addLink('                                          [COLOR blue][B] ' + str(new_name) + '[/COLOR] - [COLOR white]SD[/COLOR][/B]',url,2,iconimage,fanarts,'')
			else:
				if "hd" in name.lower():
					addLink('                                             [COLOR green][B]LINK[/COLOR][COLOR blue] ' + str(a) + '[/COLOR] - [COLOR red]HD[/COLOR][/B]',url,2,iconimage,fanarts,'')
				else:
					addLink('                                             [COLOR green][B]LINK[/COLOR][COLOR blue] ' + str(a) + '[/COLOR] - [COLOR white]SD[/COLOR][/B]',url,2,iconimage,fanarts,'')

	if a == 0:
		addLink('                                      [COLOR white][B]NO LINKS FOUND[/COLOR][/B]',url,999,iconimage,fanarts,'')

	dp.close()

def SEARCH_THROUGH_M3U_DIALOG(term):

	streamurl=[]
	streamname=[]

	result = requests.get('http://dvbsat.ru/smf/index.php?action=recent;start=0')
	match = re.compile('#EXTM3U(.+?)</div>',re.DOTALL).findall(result.content)
	for item in match:
		item = item.replace('<br />','\n')
		url = item

		url = url.replace('#AAASTREAM:','#A:')
		url = url.replace('#EXTINF:','#A:')
		matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(url)
		li = []
		for params, display_name, url in matches:
			item_data = {"params": params, "display_name": display_name, "url": url}
			li.append(item_data)
		list = []
		for channel in li:
			item_data = {"display_name": channel["display_name"], "url": channel["url"]}
			matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
			for field, value in matches:
				item_data[field.strip().lower().replace('-', '_')] = value.strip()
			list.append(item_data)

		for channel in list:
			name = GetEncodeString(channel["display_name"])
			url = GetEncodeString(channel["url"])
			url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
			if term.lower() in name.lower():
				streamurl.append(url)
				streamname.append(name)

	dialog = xbmcgui.Dialog()
	select = dialog.select('[COLOR yellow][B]Search Term: [/B][I]' + term + '[/I][/COLOR]',streamname)
	if select < 0:
		quit()

	url = streamurl[select]
	name = streamname[select]
	PLAYLINK(name,url,icon)

def READ_M3U(name,url,iconimage):

    list = CREATE_M3U_LIST(url)
    for channel in list:
        name = GetEncodeString(channel["display_name"])
        url = GetEncodeString(channel["url"])
        url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
        addLink(name ,url, 2, '', '','')

def CREATE_M3U_LIST(url):

    response = requests.get(url, headers=headers)
    response = response.content
    response = response.replace('#AAASTREAM:','#A:')
    response = response.replace('#EXTINF:','#A:')
    matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(response)
    li = []
    for params, display_name, url in matches:
        item_data = {"params": params, "display_name": display_name, "url": url}
        li.append(item_data)
    list = []
    for channel in li:
        item_data = {"display_name": channel["display_name"], "url": channel["url"]}
        matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
        for field, value in matches:
            item_data[field.strip().lower().replace('-', '_')] = value.strip()
        list.append(item_data)
	
    return list

def SEARCH():

    string =''
    keyboard = xbmc.Keyboard(string, 'Enter Search Term')
    keyboard.doModal()
    if keyboard.isConfirmed():
        string = keyboard.getText()
        if len(string)>1:
            url = string + "!" + icon
            SEARCH_THROUGH_M3U(string,url,icon)
        else: quit()

#######################################################################
#			AUTO UPDATER
#######################################################################

def AUTO_UPDATER(name):

	found = 0

	try:
		open_url("http://www.google.com")
	except:
		dialog.ok(AddonTitle,'[COLOR red][B]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/B][/COLOR]')
		sys.exit(0)

	try:
		dp.create(AddonTitle,"Checking for repository updates",'', 'Please Wait...')	
		dp.update(0)
		a=open(GET_REPO_VERSION).read()
		b=a.replace('\n',' ').replace('\r',' ')
		match=re.compile('name=".+?".+?version="(.+?)".+?provider-name=".+?">').findall(str(b))
		for item in match:
			dp.update(25)
			new_version = float(item) + 0.01
			url = BASE_REPO_UPDATE + str(new_version) + '.zip'
			result = requests.get(url)
			if "Not Found" not in result.content:
				found = 1
				dp.update(75)
				path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
				if not os.path.exists(path):
					os.makedirs(path)
				lib=os.path.join(path, 'repoupdate.zip')
				try: os.remove(lib)
				except: pass
				dp.update(100)
				dp.update(0,"","Downloading Update Please Wait","")
				import downloader
				downloader.download(url, lib, dp)
				addonfolder = xbmc.translatePath(os.path.join('special://','home/addons'))
				dp.update(0,"","Extracting Update Please Wait","")
				import extract
				extract.all(lib,addonfolder,dp)
				try: os.remove(lib)
				except: pass
				xbmc.executebuiltin("UpdateLocalAddons")
				xbmc.executebuiltin("UpdateAddonRepos")
				dialog.ok(AddonTitle,"ECHO repository was updated to " + str(new_version) + ', you may need to restart the addon for changes to take effect')

		dp.update(75,"Checking for addon updates")
		a=open(GET_VERSION).read()
		b=a.replace('\n',' ').replace('\r',' ')
		match=re.compile('name=".+?".+?version="(.+?)".+?provider-name=".+?">').findall(str(b))
		for item in match:
			new_version = float(item) + 0.01
			url = BASE_UPDATE + str(new_version) + '.zip'
			result = requests.get(url)
			if "Not Found" not in result.content:
				found = 1
				dp.update(75)
				path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
				if not os.path.exists(path):
					os.makedirs(path)
				lib=os.path.join(path, 'wizupdate.zip')
				try: os.remove(lib)
				except: pass
				dp.update(100)
				dp.update(0,"","Downloading Update Please Wait","")
				import downloader
				downloader.download(url, lib, dp)
				addonfolder = xbmc.translatePath(os.path.join('special://','home/addons'))
				dp.update(0,"","Extracting Update Please Wait","")
				import extract
				extract.all(lib,addonfolder,dp)
				try: os.remove(lib)
				except: pass
				xbmc.executebuiltin("UpdateLocalAddons")
				xbmc.executebuiltin("UpdateAddonRepos")
				dp.update(100)
				dp.close
				dialog.ok(AddonTitle,"Sportie was updated to " + str(new_version) + ', you may need to restart the addon for changes to take effect')
	except:
		dialog.ok(AddonTitle,'Sorry! We encountered an error whilst checking for updates. You can make Kodi force check the repository for updates as an alternative if you wish.')
		quit()

	if dp.iscanceled():
		dp.close()
	else:
		if found == 0:
			if not name == "no dialog":
				dialog.ok(AddonTitle,"There are no updates at this time.")
				quit()

def PLAYLINK(name,url,iconimage):

	try:
		if not'http'in url:url='http://'+url
	except: 
		dialog.ok(AddonTitle, "[COLOR green]Sorry there was a problem playing this link.[/COLOR]","[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]")
		quit()

	if not 'f4m'in url:
		if '.ts'in url:
			url = url.replace('.ts','.m3u8')
			url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url		
	if "plugin://" in url:
		url = "PlayMedia("+url+")"
		xbmc.executebuiltin(url)
		quit()
	elif urlresolver.HostedMediaFile(url).valid_url(): stream_url = urlresolver.HostedMediaFile(url).resolve()
	elif liveresolver.isValid(url)==True: stream_url=liveresolver.resolve(url)
	else: stream_url=url
	liz = xbmcgui.ListItem(name,iconImage='DefaultVideo.png', thumbnailImage=iconimage)
	liz.setPath(stream_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

def open_url(url):

    req = urllib2.Request(url)
    req.add_header('User-Agent', base64.b64decode(b'VGhlV2l6YXJkSXNIZXJl'))
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    link=link.replace('\n','').replace('\r','').replace('<fanart></fanart>','<fanart>x</fanart>').replace('<thumbnail></thumbnail>','<thumbnail>x</thumbnail>').replace('<utube>','<link>https://www.youtube.com/watch?v=').replace('</utube>','</link>')#.replace('></','>x</')
    return link
	
def GetEncodeString(str):
	try:
		import chardet
		str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
	except:
		try:
			str = str.encode("utf-8")
		except:
			pass
	return str

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]                    
        return param
	
def addDir(name,url,mode,iconimage,fanart,description=''):

	if "imgur" in iconimage:
		if not ".jpg" in iconimage:
			if not ".png" in iconimage:
				iconimage = iconimage + ".jpg"
	if "imgur" in fanart:
		if not ".jpg" in fanart:
			if not ".png" in fanart:
				fanart = fanart + ".jpg"
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, 'plot': description } )
	liz.setProperty('fanart_image', fanart)
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addLink(name, url, mode, iconimage, fanart, description=''):

	if "imgur" in iconimage:
		if not ".jpg" in iconimage:
			if not ".png" in iconimage:
				iconimage = iconimage + ".jpg"
	if "imgur" in fanart:
		if not ".jpg" in fanart:
			if not ".png" in fanart:
				fanart = fanart + ".jpg"
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setProperty('fanart_image', fanart)
	if "plugin://" in url:
		liz.setProperty("IsPlayable","false")
	elif "NOTPLAY" in url:
		liz.setProperty("IsPlayable","false")
	elif ".ts" in url:
		liz.setProperty("IsPlayable","false")
	else: liz.setProperty("IsPlayable","true")
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&description="+str(description)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

def addItem(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	liz.setProperty( "Fanart_Image", fanart )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: fanart=urllib.unquote_plus(params["fanart"])
except: pass
 
if mode==None or url==None or len(url)<1: GetMenu()
elif mode==1:GetContent(name,url)
elif mode==2:PLAYLINK(name,url,iconimage)
elif mode==3:GETMULTI(name,url,iconimage)
elif mode==4:PLAYSD(name,url,iconimage)
elif mode==8:GETMULTI_SD(name,url,iconimage)
elif mode==9:AUTO_UPDATER(name)
elif mode==10:READ_M3U(name,url,iconimage)
elif mode==11:SCRAPE_M3U8()
elif mode==12:GENERATE_M3U8(url)
elif mode==19:GET_SEARCH_TERMS(url)
elif mode==20:SEARCH_THROUGH_M3U(name,url,iconimage)
elif mode==21:GET_SEARCH_GAMES(url)
elif mode==22:SEARCH_THROUGH_M3U_MULTI(name,url,iconimage)
elif mode==30:GET_REGEX(name,url,iconimage)
elif mode==100:SEARCH()
xbmcplugin.endOfDirectory(int(sys.argv[1]))
