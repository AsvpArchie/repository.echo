import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
import plugintools
import datetime
from resources . lib . modules import regex
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
if 91 - 91: Ii1I . OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
O0oO = plugintools . get_setting ( "scrape1" )
o0oO0 = plugintools . get_setting ( "scrape2" )
oo00 = plugintools . get_setting ( "scrape3" )
if 88 - 88: O0Oo0oO0o . II1iI . i1iIii1Ii1II
#######################################################################
#						Cache Functions
#######################################################################
if 1 - 1: O0Oooo00
class Ooo0 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 89 - 89: I111i1i1111i - Ii1Ii1iiii11 % I1I1i1
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 18 - 18: iiIIIIi1i1 / OOoOoo00oo - iI1 + OOooO % ooO00oo - O000oo
i1iIIi1 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 50 - 50: i11iIiiIii - OOoOoo00oo
class oo0Ooo0 :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 46 - 46: O000oo % O000oo - Ii1Ii1iiii11 * O0Oooo00 % iI1
  if 55 - 55: i1iIii1Ii1II % o0000oOoOoO0o / OOoOoo00oo - Ii1Ii1iiii11 - Ii1I / i1I1ii1II1iII
  if 28 - 28: OoOO - o0000oOoOoO0o
  if 70 - 70: II1iI . II1iI - II1iI / I111i1i1111i * I1I1i1
def OoO000 ( ) :
 IIiiIiI1 = 5
 iiIiIIi = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 ooOoo0O = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 76 - 76: Ii1I / O0Oooo00 . oooO0oo0oOOOO * OOoOoo00oo - I1I1i1
 Oooo = [ ]
 if 67 - 67: I1I1i1 / OoOO0ooOOoo0O % iiIIIIi1i1 - OoOO
 for Ooo in range ( IIiiIiI1 ) :
  Oooo . append ( oo0Ooo0 ( iiIiIIi [ Ooo ] , ooOoo0O [ Ooo ] ) )
  if 68 - 68: iiIIIIi1i1 + I1I1i1 . OoOO - OOooO % OoOO - O000oo
 return Oooo
 if 79 - 79: O0Oo0oO0o + oooO0oo0oOOOO - iI1
def oO00O00o0OOO0 ( ) :
 if 27 - 27: Ii1I % o0000oOoOoO0o * Ii1Ii1iiii11 + i11iIiiIii + OoOO0ooOOoo0O * o0000oOoOoO0o
 if not os . path . isfile ( ooo0OO ) :
  plugintools . open_settings_dialog ( )
  if 80 - 80: iiIIIIi1i1 * i11iIiiIii / ooO00oo
 I11II1i = open ( IIi1IiiiI1Ii ) . read ( )
 IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  I1IIIii = float ( IIiiiiiiIi1I1 )
  if 95 - 95: II1iI % Ii1Ii1iiii11 . Ii1I
 I1i1I = oOO00oOO ( II1 )
 I1i1I = base64 . b64decode ( I1i1I )
 I1i1I = I1i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 75 - 75: o0000oOoOoO0o / OoOO0ooOOoo0O - Ii1I / i1iIii1Ii1II . i1I1ii1II1iII - o0000oOoOoO0o
  if '<search>ZGlzcGxheQ==</search>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 13 - 13: ooO00oo % i1iIii1Ii1II - i11iIiiIii . oooO0oo0oOOOO + i1I1ii1II1iII
  elif '<vip>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 10 - 10: I111i1i1111i * O000oo * i1I1ii1II1iII % OOoOoo00oo . I1I1i1 + ooO00oo
  elif '<divider>bnVsbA==</divider>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   IIiIi11i1 ( O000OO0 , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 29 - 29: I111i1i1111i % oooO0oo0oOOOO + O000oo / O0Oooo00 + I1I1i1 * O0Oooo00
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   I11iii1Ii ( O000OO0 , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 42 - 42: OOoOoo00oo + Ii1Ii1iiii11
   if 76 - 76: ooO00oo - II1iI
   if 70 - 70: O000oo
   if 61 - 61: I111i1i1111i . I111i1i1111i
   if 10 - 10: i1iIii1Ii1II * iI1 . iiIIIIi1i1 + i1I1ii1II1iII - O000oo * o0000oOoOoO0o
   if 56 - 56: O0Oooo00 * OOooO * i1I1ii1II1iII
   if 80 - 80: O0Oooo00 * i1I1ii1II1iII % i1I1ii1II1iII
   if 59 - 59: OoOO + oooO0oo0oOOOO - O0Oooo00 - oooO0oo0oOOOO + I1I1i1 / I111i1i1111i
   if 24 - 24: iiIIIIi1i1 . iI1 % I1I1i1 + O000oo % i1iIii1Ii1II
   if 4 - 4: OOooO - II1iI * i1iIii1Ii1II - iiIIIIi1i1
   if 41 - 41: i1iIii1Ii1II . oooO0oo0oOOOO * Ii1Ii1iiii11 % OOooO
   if 86 - 86: oooO0oo0oOOOO + OOoOoo00oo % i11iIiiIii * Ii1Ii1iiii11 . O000oo * iiIIIIi1i1
   if 44 - 44: Ii1Ii1iiii11
   if 88 - 88: ooO00oo % OOoOoo00oo . i1I1ii1II1iII
   if 38 - 38: O0Oooo00
   if 57 - 57: Ii1I / Ii1Ii1iiii11 * ooO00oo / i1iIii1Ii1II . i1I1ii1II1iII
   if 26 - 26: iI1
   if 91 - 91: II1iI . I111i1i1111i + II1iI - iI1 / OoOO0ooOOoo0O
   if 39 - 39: I111i1i1111i / O000oo - i1I1ii1II1iII
   if 98 - 98: I111i1i1111i / iiIIIIi1i1 % Ii1Ii1iiii11 . i1iIii1Ii1II
   if 91 - 91: Ii1Ii1iiii11 % O0Oo0oO0o
   if 64 - 64: iiIIIIi1i1 % iI1 - ooO00oo - Ii1Ii1iiii11
  elif '<sportsdevil>' in IIiiiiiiIi1I1 :
   i1ii1iiI = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1ii1iiI ) == 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O00O0oOO00O00 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    i1 = re . compile ( '<referer>(.+?)</referer>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    O0o0O00Oo0o0 = base64 . b64decode ( O0o0O00Oo0o0 )
    O00O0oOO00O00 = base64 . b64decode ( O00O0oOO00O00 )
    i1 = base64 . b64decode ( i1 )
    Oo00 = i1
    i1i = "/"
    if not Oo00 . endswith ( i1i ) :
     iiI111I1iIiI = Oo00 + "/"
    else :
     iiI111I1iIiI = Oo00
    I1i1I = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( O000OO0 ) + '%26url=' + O00O0oOO00O00
    O00O0oOO00O00 = I1i1I + '%26referer=' + iiI111I1iIiI
    IIiIi11i1 ( O000OO0 , O00O0oOO00O00 , 4 , O0o0O00Oo0o0 , II )
   elif len ( i1ii1iiI ) > 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    O0o0O00Oo0o0 = base64 . b64decode ( O0o0O00Oo0o0 )
    IIiIi11i1 ( O000OO0 , url2 + 'NOTPLAY' , 8 , O0o0O00Oo0o0 , II )
    if 45 - 45: Ii1I * O0Oooo00 % O0Oo0oO0o * OoOO0ooOOoo0O + iI1 . i1iIii1Ii1II
  elif '<folder>' in IIiiiiiiIi1I1 :
   Oo0ooOo0o = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 , II in Oo0ooOo0o :
    O000OO0 = base64 . b64decode ( O000OO0 )
    O00O0oOO00O00 = base64 . b64decode ( O00O0oOO00O00 )
    O0o0O00Oo0o0 = base64 . b64decode ( O0o0O00Oo0o0 )
    II = base64 . b64decode ( II )
    I11iii1Ii ( O000OO0 , O00O0oOO00O00 , 1 , O0o0O00Oo0o0 , II )
  elif '<m3u>' in IIiiiiiiIi1I1 :
   Oo0ooOo0o = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 , II in Oo0ooOo0o :
    O000OO0 = base64 . b64decode ( O000OO0 )
    O00O0oOO00O00 = base64 . b64decode ( O00O0oOO00O00 )
    O0o0O00Oo0o0 = base64 . b64decode ( O0o0O00Oo0o0 )
    II = base64 . b64decode ( II )
    I11iii1Ii ( O000OO0 , O00O0oOO00O00 , 10 , O0o0O00Oo0o0 , II )
  else :
   i1ii1iiI = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1ii1iiI ) == 1 :
    Oo0ooOo0o = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
    Ii1i1 = len ( ooooooO0oo )
    for O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 , II in Oo0ooOo0o :
     O000OO0 = base64 . b64decode ( O000OO0 )
     O00O0oOO00O00 = base64 . b64decode ( O00O0oOO00O00 )
     O0o0O00Oo0o0 = base64 . b64decode ( O0o0O00Oo0o0 )
     II = base64 . b64decode ( II )
     IIiIi11i1 ( O000OO0 , O00O0oOO00O00 , 2 , O0o0O00Oo0o0 , II )
   elif len ( i1ii1iiI ) > 1 :
    O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    II = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = base64 . b64decode ( O000OO0 )
    O0o0O00Oo0o0 = base64 . b64decode ( O0o0O00Oo0o0 )
    II = base64 . b64decode ( II )
    IIiIi11i1 ( O000OO0 , II1 , 3 , O0o0O00Oo0o0 , II )
    if 15 - 15: i1I1ii1II1iII
 IIiIi11i1 ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '[COLOR dodgerblue]VER ' + str ( I1IIIii ) + '[/COLOR][COLOR yellow] - CHECK FOR UPDATES[/COLOR]' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 if 18 - 18: i11iIiiIii . o0000oOoOoO0o % OoOO0ooOOoo0O / Ii1I
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 75 - 75: i1iIii1Ii1II % O0Oooo00 % O0Oooo00 . ooO00oo
def III1iII1I1ii ( name , url ) :
 if 61 - 61: i1I1ii1II1iII
 hash = [ ]
 O0OOO = url
 I1i1I = oOO00oOO ( url )
 if 10 - 10: I1I1i1 * iiIIIIi1i1 % i1iIii1Ii1II / oooO0oo0oOOOO / i1iIii1Ii1II
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 42 - 42: II1iI
  if '<regex>' in IIiiiiiiIi1I1 :
   o0o = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( IIiiiiiiIi1I1 )
   o0o = '' . join ( o0o )
   o00 = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( o0o )
   o0o = urllib . quote_plus ( o0o )
   if 56 - 56: oooO0oo0oOOOO - O0Oo0oO0o . OOoOoo00oo - OOooO
   OOOoOoo0O = hashlib . md5 ( )
   for O000OOo00oo in o0o : OOOoOoo0O . update ( str ( O000OOo00oo ) )
   OOOoOoo0O = str ( OOOoOoo0O . hexdigest ( ) )
   if 71 - 71: i11iIiiIii + OOooO
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   IIiiiiiiIi1I1 = re . sub ( '<regex>.+?</regex>' , '' , IIiiiiiiIi1I1 )
   IIiiiiiiIi1I1 = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , IIiiiiiiIi1I1 )
   IIiiiiiiIi1I1 = re . sub ( '<link></link>' , '' , IIiiiiiiIi1I1 )
   if 57 - 57: Ii1Ii1iiii11 . iiIIIIi1i1 . o0000oOoOoO0o
   name = re . sub ( '<meta>.+?</meta>' , '' , IIiiiiiiIi1I1 )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 42 - 42: iiIIIIi1i1 + I111i1i1111i % Ii1I
   try : i1iIIIi1i = re . findall ( '<date>(.+?)</date>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : i1iIIIi1i = ''
   if re . search ( r'\d+' , i1iIIIi1i ) : name += ' [COLOR red] Updated %s[/COLOR]' % i1iIIIi1i
   if 43 - 43: i1iIii1Ii1II % I1I1i1
   try : iiiiiiii1 = re . findall ( '<thumbnail>(.+?)</thumbnail>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : iiiiiiii1 = iiiii
   if 18 - 18: O0Oooo00 % iI1 * Ii1I
   try : o0 = re . findall ( '<fanart>(.+?)</fanart>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : o0 = O0O0OO0O0O0
   if 87 - 87: iiIIIIi1i1 - OoOO + oooO0oo0oOOOO . iI1
   try : Oo0oOOOoOooOo = re . findall ( '<meta>(.+?)</meta>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : Oo0oOOOoOooOo = '0'
   if 51 - 51: iiIIIIi1i1 + iI1 % OoOO / Ii1Ii1iiii11 / I1I1i1 % OoOO0ooOOoo0O
   try : url = re . findall ( '<link>(.+?)</link>' , IIiiiiiiIi1I1 ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % Oo0oOOOoOooOo )
   url = '<preset>search</preset>%s' % Oo0oOOOoOooOo if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % Oo0oOOOoOooOo )
   url = '<preset>searchsd</preset>%s' % Oo0oOOOoOooOo if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 78 - 78: OOoOoo00oo % ooO00oo + I111i1i1111i
   if not o0o == '' :
    hash . append ( { 'regex' : OOOoOoo0O , 'response' : o0o } )
    url += '|regex=%s' % o0o
    if 64 - 64: Ii1Ii1iiii11 * Ii1I . oooO0oo0oOOOO + i1I1ii1II1iII
   IIiIi11i1 ( name , url , 30 , iiiiiiii1 , o0 )
   if 6 - 6: i1iIii1Ii1II / iI1 . OOooO . OOooO
  elif '<sportsdevil>' in IIiiiiiiIi1I1 :
   i1ii1iiI = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1ii1iiI ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     i1 = re . compile ( '<referer>(.+?)</referer>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : i1 = "None"
    O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     II = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : II = O0O0OO0O0O0
    Oo00 = i1
    i1i = "/"
    if not Oo00 . endswith ( i1i ) :
     iiI111I1iIiI = Oo00 + "/"
    else :
     iiI111I1iIiI = Oo00
    I1i1I = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = I1i1I + '%26referer=' + iiI111I1iIiI
    IIiIi11i1 ( name , url , 2 , O0o0O00Oo0o0 , II )
    if 62 - 62: I111i1i1111i + OOooO % iI1 + I1I1i1
   elif len ( i1ii1iiI ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     II = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : II = O0O0OO0O0O0
    IIiIi11i1 ( name , O0OOO + 'NOTPLAY' , 8 , O0o0O00Oo0o0 , II )
    if 33 - 33: Ii1I . OOooO . oooO0oo0oOOOO
  elif '<folder>' in IIiiiiiiIi1I1 :
   Oo0ooOo0o = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for name , url , O0o0O00Oo0o0 , II in Oo0ooOo0o :
    I11iii1Ii ( name , url , 1 , O0o0O00Oo0o0 , II )
    if 72 - 72: o0000oOoOoO0o / II1iI + OoOO0ooOOoo0O - O0Oo0oO0o
  elif '<m3u>' in IIiiiiiiIi1I1 :
   Oo0ooOo0o = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
   for name , url , O0o0O00Oo0o0 , II in Oo0ooOo0o :
    I11iii1Ii ( name , url , 10 , O0o0O00Oo0o0 , II )
    if 29 - 29: I111i1i1111i + Ii1Ii1iiii11 % Ii1I
  else :
   i1ii1iiI = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 )
   if len ( i1ii1iiI ) == 1 :
    Oo0ooOo0o = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 )
    Ii1i1 = len ( ooooooO0oo )
    for name , url , O0o0O00Oo0o0 , II in Oo0ooOo0o :
     IIiIi11i1 ( name , url , 2 , O0o0O00Oo0o0 , II )
   elif len ( i1ii1iiI ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     II = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : II = O0O0OO0O0O0
    IIiIi11i1 ( name , O0OOO , 3 , O0o0O00Oo0o0 , II )
    if 10 - 10: iiIIIIi1i1 / ooO00oo - oooO0oo0oOOOO * OoOO - oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 97 - 97: I111i1i1111i + oooO0oo0oOOOO * OOoOoo00oo + I1I1i1 % iI1
def OOOOOoo0 ( name , url , iconimage ) :
 ii1 = [ ]
 I1iI1iIi111i = [ ]
 iiIi1IIi1I = [ ]
 I1i1I = oOO00oOO ( url )
 o0OoOO000ooO0 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0OoOO000ooO0 ) [ 0 ]
 i1ii1iiI = re . compile ( '<link>(.+?)</link>' ) . findall ( o0OoOO000ooO0 )
 O000OOo00oo = 1
 for o0o0o0oO0oOO in i1ii1iiI :
  ii1Ii11I = o0o0o0oO0oOO
  if '(' in o0o0o0oO0oOO :
   o0o0o0oO0oOO = o0o0o0oO0oOO . split ( '(' ) [ 0 ]
   o00o0 = str ( ii1Ii11I . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   ii1 . append ( o0o0o0oO0oOO )
   I1iI1iIi111i . append ( o00o0 )
  else :
   ii1 . append ( o0o0o0oO0oOO )
   I1iI1iIi111i . append ( 'Link ' + str ( O000OOo00oo ) )
  O000OOo00oo = O000OOo00oo + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 ii = O00ooooo00 . select ( name , I1iI1iIi111i )
 if ii < 0 :
  quit ( )
 else :
  url = ii1 [ ii ]
  print url
  if 84 - 84: O0Oooo00 % i1I1ii1II1iII . i11iIiiIii / II1iI
 url = ii1 [ ii ]
 name = I1iI1iIi111i [ ii ]
 o0O ( name , url , iiiii )
 if 2 - 2: OoOO / Ii1Ii1iiii11 + II1iI / I1I1i1
def IIOOOO0oo0 ( name , url , iconimage ) :
 if 35 - 35: OOoOoo00oo - oooO0oo0oOOOO % O0Oooo00 . OoOO0ooOOoo0O % OOoOoo00oo
 ii1 = [ ]
 I1iI1iIi111i = [ ]
 iiIi1IIi1I = [ ]
 I1i1Iiiii = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 I1i1I = oOO00oOO ( url )
 o0OoOO000ooO0 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 i1ii1iiI = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( o0OoOO000ooO0 )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0OoOO000ooO0 ) [ 0 ]
 if 94 - 94: O0Oooo00 * OOoOoo00oo / O0Oo0oO0o / OOoOoo00oo
 oO0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 75 - 75: O000oo + i1iIii1Ii1II + O0Oooo00 * iiIIIIi1i1 % Ii1Ii1iiii11 . iI1
 O000OOo00oo = 1
 if 55 - 55: I1I1i1 . oooO0oo0oOOOO
 for o0o0o0oO0oOO in i1ii1iiI :
  ii1Ii11I = o0o0o0oO0oOO
  if '(' in o0o0o0oO0oOO :
   o0o0o0oO0oOO = o0o0o0oO0oOO . split ( '(' ) [ 0 ]
   o00o0 = str ( ii1Ii11I . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   ii1 . append ( o0o0o0oO0oOO )
   I1iI1iIi111i . append ( o00o0 )
   I1i1Iiiii . append ( 'Stream ' + str ( O000OOo00oo ) )
  else :
   ii1 . append ( o0o0o0oO0oOO )
   I1iI1iIi111i . append ( 'Link ' + str ( O000OOo00oo ) )
   if 61 - 61: O0Oo0oO0o % OOooO . O0Oo0oO0o
  O000OOo00oo = O000OOo00oo + 1
  if 100 - 100: ooO00oo * Ii1I
 name = '[COLOR red]' + name + '[/COLOR]'
 if 64 - 64: I1I1i1 % OoOO * Ii1Ii1iiii11
 O00ooooo00 = xbmcgui . Dialog ( )
 ii = O00ooooo00 . select ( name , I1iI1iIi111i )
 if ii < 0 :
  quit ( )
 else :
  Oo00 = I1iI1iIi111i [ ii ]
  i1i = "/"
  if not Oo00 . endswith ( i1i ) :
   iiI111I1iIiI = Oo00 + "/"
  else :
   iiI111I1iIiI = Oo00
  url = oO0 + ii1 [ ii ] + "%26referer=" + iiI111I1iIiI
  if 79 - 79: Ii1I
 name = I1iI1iIi111i [ ii ]
 o0O ( name , url , iiiii )
 if 78 - 78: I111i1i1111i + I1I1i1 - ooO00oo
def IIIIii1I ( name , url , iconimage ) :
 if 39 - 39: i1I1ii1II1iII / O000oo + ooO00oo / i1iIii1Ii1II
 I1Ii11i , Ooo = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 I1Ii11i += urllib . unquote_plus ( Ooo )
 url = regex . resolve ( I1Ii11i )
 if 35 - 35: O0Oooo00
 o0O ( name , url , iconimage )
 if 90 - 90: ooO00oo % OOoOoo00oo - OoOO - OoOO / i11iIiiIii % I111i1i1111i
def IIii11I1 ( ) :
 if 83 - 83: O000oo
 IIiIi11i1 ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 I11iii1Ii ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 65 - 65: oooO0oo0oOOOO % OOoOoo00oo * Ii1Ii1iiii11
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 19 - 19: ooO00oo + OoOO . OoOO0ooOOoo0O . iiIIIIi1i1 / ooO00oo + OOooO
def oOooOOo0o ( ) :
 if 66 - 66: iI1 - iI1 - i11iIiiIii . I111i1i1111i - I1I1i1
 I11iii1Ii ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 77 - 77: i1iIii1Ii1II - i1I1ii1II1iII - O000oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 49 - 49: i1I1ii1II1iII % Ii1I . i1iIii1Ii1II + Ii1Ii1iiii11 / oooO0oo0oOOOO
def O0oOOoOooooO ( ) :
 if 62 - 62: OoOO0ooOOoo0O * oooO0oo0oOOOO
 I11iii1Ii ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 I11iii1Ii ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 58 - 58: i1iIii1Ii1II % O0Oooo00
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 50 - 50: ooO00oo . O0Oooo00
def ooO0OO ( ) :
 if 54 - 54: OOooO + OOoOoo00oo % II1iI + OoOO0ooOOoo0O - Ii1I - O0Oooo00
 O000OOo00oo = 0
 o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OOo00oo = O000OOo00oo + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O00O0oOO00O00 = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( O000OOo00oo ) + '[/COLOR]' , O00O0oOO00O00 , 12 , iiiii , O0O0OO0O0O0 )
  if 14 - 14: i1iIii1Ii1II + Ii1Ii1iiii11
 o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OOo00oo = O000OOo00oo + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O00O0oOO00O00 = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( O000OOo00oo ) + '[/COLOR]' , O00O0oOO00O00 , 12 , iiiii , O0O0OO0O0O0 )
  if 52 - 52: OoOO0ooOOoo0O - O000oo
 o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OOo00oo = O000OOo00oo + 1
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O00O0oOO00O00 = IIiiiiiiIi1I1
  I11iii1Ii ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( O000OOo00oo ) + '[/COLOR]' , O00O0oOO00O00 , 12 , iiiii , O0O0OO0O0O0 )
  if 74 - 74: iI1 + O0Oooo00
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 71 - 71: O0Oo0oO0o % I1I1i1
def O00oO000O0O ( url ) :
 if 18 - 18: iI1 - I1I1i1 . ooO00oo . OoOO
 o0o0O0O00oOOo = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 if 2 - 2: I1I1i1 . II1iI
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OO0 = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  O0o0O00Oo0o0 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 12 , O0o0O00Oo0o0 , O0O0OO0O0O0 )
  if 78 - 78: iiIIIIi1i1 * OoOO . oooO0oo0oOOOO / O0Oooo00 - OoOO0ooOOoo0O / ooO00oo
 try :
  i1I1IiiIi1i = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( o0o0O0O00oOOo ) [ 0 ]
  I11iii1Ii ( '[COLOR yellow]Next Page -->[/COLOR]' , i1I1IiiIi1i , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 29 - 29: oooO0oo0oOOOO % oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 94 - 94: OoOO / O0Oo0oO0o % iI1 * iI1 * i1I1ii1II1iII
def IIiIiI ( url ) :
 if 94 - 94: Ii1Ii1iiii11 . o0000oOoOoO0o - O0Oooo00 % Ii1I - II1iI
 o0o0O0O00oOOo = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   O000OO0 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except :
   O000OO0 = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 72 - 72: OOoOoo00oo
def II11Ii1iI1iII ( url ) :
 if 73 - 73: OoOO0ooOOoo0O * OoOO0ooOOoo0O * O000oo * i1iIii1Ii1II + O000oo * ooO00oo
 o0o0O0O00oOOo = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 oo0o0OO0 = 0
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   O000OO0 = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0o0O00Oo0o0 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : oo0o0OO0 = 1
  if 86 - 86: OoOO / i1iIii1Ii1II . i1I1ii1II1iII
  if oo0o0OO0 == 0 :
   I11iii1Ii ( '[COLOR dodgerblue]' + O000OO0 + '[/COLOR]' , url , 12 , O0o0O00Oo0o0 , O0O0OO0O0O0 )
  oo0o0OO0 = 0
  if 19 - 19: I111i1i1111i % OoOO0ooOOoo0O % OOooO * O0Oooo00 % Ii1I
 try :
  i1I1IiiIi1i = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( o0o0O0O00oOOo ) [ 0 ]
  I11iii1Ii ( '[COLOR yellow]Next Page -->[/COLOR]' , i1I1IiiIi1i , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 67 - 67: oooO0oo0oOOOO . o0000oOoOoO0o
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 27 - 27: O000oo % oooO0oo0oOOOO
def o0oooOO00 ( url ) :
 if 32 - 32: ooO00oo
 Iii1 = datetime . date . today ( )
 oOOOoo00 = datetime . datetime . strftime ( Iii1 , '%A %d %B %Y' )
 if 9 - 9: Ii1I % Ii1I - O0Oooo00
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( oOOOoo00 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 51 - 51: oooO0oo0oOOOO . OoOO - I111i1i1111i / Ii1I
 o0o0O0O00oOOo = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 oo0o0OO0 = 0
 O000OOo00oo = 0
 for IIiiiiiiIi1I1 in ooooooO0oo :
  try :
   OOOoO00 = re . compile ( 'title="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   try :
    IIiIi11i1i = re . compile ( '<p>(.+?)</p>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   except : IIiIi11i1i = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0o0O00Oo0o0 = re . compile ( '<img src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : oo0o0OO0 = 1
  if 41 - 41: O000oo % II1iI - O0Oo0oO0o * ooO00oo * O0Oo0oO0o
  if oo0o0OO0 == 0 :
   if 'vs' in OOOoO00 :
    O000OO0 = '[COLOR dodgerblue]' + OOOoO00 + ' - ' + '[/COLOR][COLOR green]' + IIiIi11i1i + '[/COLOR]'
    O000OOo00oo = O000OOo00oo + 1
    IIiIi11i1 ( O000OO0 , url , 206 , O0o0O00Oo0o0 , O0O0OO0O0O0 , '' )
  oo0o0OO0 = 0
  if 69 - 69: I1I1i1 - OoOO0ooOOoo0O + O0Oooo00 - iiIIIIi1i1
 if O000OOo00oo == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 23 - 23: i11iIiiIii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 30 - 30: O0Oooo00 - o0000oOoOoO0o % i1I1ii1II1iII + iiIIIIi1i1 * OoOO
def o0ooooO0o0O ( name , url , iconimage ) :
 if 24 - 24: Ii1I * O0Oooo00
 o0o0O0O00oOOo = oOO00oOO ( url )
 IiI1iiiIii = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( o0o0O0O00oOOo ) [ 0 ]
 if 7 - 7: ooO00oo * II1iI - O000oo + I1I1i1 * oooO0oo0oOOOO % II1iI
 if not "http" in IiI1iiiIii :
  IiI1iiiIii = IiI1iiiIii . replace ( "//" , "" )
  url = "http://" + IiI1iiiIii
 else :
  url = IiI1iiiIii
  if 15 - 15: i1iIii1Ii1II % oooO0oo0oOOOO * iiIIIIi1i1
 O0OoooO0 = url
 if 85 - 85: iiIIIIi1i1
 iI1i11II1i = oOO00oOO ( url )
 IiI1iiiIii = re . compile ( "atob(.+?)," ) . findall ( iI1i11II1i ) [ 0 ]
 IiI1iiiIii = IiI1iiiIii . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( IiI1iiiIii )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + O0OoooO0 + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 o0O ( name , url , iconimage )
 if 96 - 96: ooO00oo
def oOoOo0O0OOOoO ( url ) :
 if 50 - 50: O000oo
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 47 - 47: O0Oo0oO0o * I111i1i1111i + OoOO / ooO00oo / II1iI - OoOO0ooOOoo0O
  if '<display>eWVz</display>' in IIiiiiiiIi1I1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   II = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O000OO0 = base64 . b64decode ( O000OO0 )
   url = base64 . b64decode ( url )
   O0o0O00Oo0o0 = base64 . b64decode ( O0o0O00Oo0o0 )
   II = base64 . b64decode ( II )
   I11iii1Ii ( O000OO0 , url , 220 , O0o0O00Oo0o0 , II , '' )
   if 33 - 33: i1iIii1Ii1II * I1I1i1 - i1I1ii1II1iII
def OOo0o0O0O ( url ) :
 if 65 - 65: i11iIiiIii
 o0o0O0O00oOOo = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 if 85 - 85: OOoOoo00oo % iI1 + iiIIIIi1i1 / O0Oooo00 . Ii1Ii1iiii11 + I1I1i1
 for IIiiiiiiIi1I1 in ooooooO0oo :
  O000OO0 = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  try :
   ooOoOo0 = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  except : ooOoOo0 = "SD"
  ooOoOo0 = '[COLOR yellow]' + ooOoOo0 + '[/COLOR]'
  O0o0O00Oo0o0 = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  O000OO0 = O000OO0 . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 2 - 2: iI1 % OoOO * OoOO . O0Oooo00 / iI1
  IIiIi11i1 ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR] - ' + ooOoOo0 , url , 212 , O0o0O00Oo0o0 , O0O0OO0O0O0 , '' )
  if 27 - 27: II1iI + O000oo - o0000oOoOoO0o
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( o0o0O0O00oOOo ) [ 0 ]
  O00oOOooo = 'http://www.fmovies.se/' + url
  I11iii1Ii ( "Next Page -->" , O00oOOooo , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 50 - 50: I111i1i1111i % Ii1I * O0Oooo00
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 5 - 5: OOooO * i1iIii1Ii1II
def i1Ii1i1I11Iii ( url ) :
 if 25 - 25: OOooO + OOoOoo00oo / O000oo . O0Oooo00 % Ii1I * II1iI
 o0o0O0O00oOOo = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 if 84 - 84: O000oo % OOoOoo00oo + i11iIiiIii
 if 28 - 28: O0Oo0oO0o + II1iI * I1I1i1 % Ii1Ii1iiii11 . iiIIIIi1i1 % Ii1I
def I1iiiiIii ( url ) :
 if 19 - 19: II1iI - O0Oo0oO0o . Ii1I
 if "iptvembed" in url :
  o0o0O0O00oOOo = oOO00oOO ( url )
  ooooooO0oo = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '</pre>' , '' )
   url = IIiiiiiiIi1I1
   if 60 - 60: i1I1ii1II1iII + O0Oo0oO0o
 if "sourcetv" in url :
  o0o0O0O00oOOo = oOO00oOO ( url )
  ooooooO0oo = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '</pre>' , '' )
   url = IIiiiiiiIi1I1
   if 9 - 9: O000oo * OoOO0ooOOoo0O - OoOO + i1iIii1Ii1II / II1iI . II1iI
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 iiI1iI111ii1i = [ ]
 for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
  O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
  iiI1iI111ii1i . append ( O0 )
 list = [ ]
 for i11I1I1I in iiI1iI111ii1i :
  O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
  iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
  for oOOOo00O00O , iIIIII1I in iiIIi :
   O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
  list . append ( O0 )
  if 51 - 51: OoOO . O000oo + OoOO
 oOoOO = 0
 for i11I1I1I in list :
  oOoOO = 1
  O000OO0 = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
  url = Ii1i1O0o ( i11I1I1I [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   IIiIi11i1 ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   I11iii1Ii ( '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 18 - 18: I111i1i1111i
 if oOoOO == 0 :
  IIiIi11i1 ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 96 - 96: OoOO0ooOOoo0O + Ii1Ii1iiii11
def iiII1i11i ( url ) :
 if 11 - 11: oooO0oo0oOOOO / i1I1ii1II1iII + O0Oooo00 * I111i1i1111i - I111i1i1111i - oooO0oo0oOOOO
 I1i1I = oOO00oOO ( url )
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 85 - 85: iiIIIIi1i1 % Ii1Ii1iiii11 / OoOO . OoOO
  O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  iIIiIiI1I1 = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  II = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
  url = O000OO0 + '!' + iIIiIiI1I1 + '!' + O0o0O00Oo0o0
  I11iii1Ii ( '[COLOR blue]' + O000OO0 + '[/COLOR]' , url , 20 , O0o0O00Oo0o0 , II )
  if 56 - 56: oooO0oo0oOOOO . Ii1I + O0Oo0oO0o
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 1 - 1: iI1
def O0O0Ooo ( url ) :
 if 77 - 77: O0Oooo00 / OoOO0ooOOoo0O
 Iii1 = datetime . date . today ( )
 oOOOoo00 = datetime . datetime . strftime ( Iii1 , '%A %d %B %Y' )
 if 46 - 46: O0Oooo00 % OoOO . iI1 % iI1 + i11iIiiIii
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( oOOOoo00 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 72 - 72: OoOO * OOoOoo00oo % O000oo / II1iI
 I1i1I = oOO00oOO ( url )
 O0OOO = url
 ooooooO0oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I1i1I )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  if 35 - 35: O000oo + o0000oOoOoO0o % I111i1i1111i % iiIIIIi1i1 + Ii1Ii1iiii11
  i1ii1iiI = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 )
  if len ( i1ii1iiI ) == 1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = O000OO0 + "!" + url + "!" + O0o0O00Oo0o0
   O000OO0 = '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]'
   I11iii1Ii ( O000OO0 , url , 20 , O0o0O00Oo0o0 , O0o0O00Oo0o0 )
   if 17 - 17: o0000oOoOoO0o
   if 21 - 21: O0Oo0oO0o
  elif len ( i1ii1iiI ) > 1 :
   O000OO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   O0o0O00Oo0o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
   url = O0OOO + "!" + O000OO0 + "!" + O0o0O00Oo0o0
   O000OO0 = '[COLOR mediumpurple]' + O000OO0 + '[/COLOR]'
   I11iii1Ii ( O000OO0 , url , 22 , O0o0O00Oo0o0 , O0o0O00Oo0o0 )
   if 29 - 29: iiIIIIi1i1 / i1I1ii1II1iII / O000oo * I1I1i1
   if 10 - 10: ooO00oo % OOooO * OOooO . iiIIIIi1i1 / OOoOoo00oo % I1I1i1
   if 49 - 49: II1iI / Ii1Ii1iiii11 + Ii1I * O0Oooo00
   if 28 - 28: O000oo + i11iIiiIii / iiIIIIi1i1 % i1iIii1Ii1II % O0Oo0oO0o - Ii1I
   if 54 - 54: o0000oOoOoO0o + i1I1ii1II1iII
   if 83 - 83: I111i1i1111i - oooO0oo0oOOOO + I1I1i1
   if 5 - 5: OOoOoo00oo
   if 46 - 46: OOooO
   if 45 - 45: O000oo
   if 21 - 21: Ii1Ii1iiii11 . ooO00oo . I1I1i1 / O0Oo0oO0o / ooO00oo
   if 17 - 17: I1I1i1 / I1I1i1 / iiIIIIi1i1
   if 1 - 1: o0000oOoOoO0o . i11iIiiIii % I1I1i1
   if 82 - 82: OoOO + O0Oo0oO0o . OoOO % OOooO / OOoOoo00oo . OOoOoo00oo
def IIi ( ) :
 if 66 - 66: Ii1Ii1iiii11 % II1iI . I1I1i1
 Iii1 = datetime . date . today ( )
 oOOOoo00 = datetime . datetime . strftime ( Iii1 , '%A %d %B %Y' )
 if 86 - 86: OoOO
 IIiIi11i1 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( oOOOoo00 ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 IIiIi11i1 ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 76 - 76: O000oo + OoOO / Ii1I / I111i1i1111i
 I1i1I = oOO00oOO ( 'http://www.oddschecker.com/tv-sports-calendar' )
 ooooooO0oo = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( I1i1I )
 O00OoOO0oo0 = str ( ooooooO0oo )
 oOO = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( O00OoOO0oo0 )
 for IIiiiiiiIi1I1 in oOO :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in IIiiiiiiIi1I1 :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    OOOoO00 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O0o0O00Oo0o0 = re . compile ( 'src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     iIIiIiI1I1 = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
     iIIiIiI1I1 = O0o0OO0000ooo ( iIIiIiI1I1 )
    except : iIIiIiI1I1 = "null"
    O000OO0 = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + OOOoO00 + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    O000OO0 = iIIII1iIIii ( O000OO0 )
    O00O0oOO00O00 = OOOoO00 + "!" + iIIiIiI1I1 . lower ( ) + "!" + O0o0O00Oo0o0
    I11iii1Ii ( O000OO0 , O00O0oOO00O00 , 20 , O0o0O00Oo0o0 , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    OOOoO00 = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    try :
     iIIiIiI1I1 = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    except : iIIiIiI1I1 = "null"
    O0o0O00Oo0o0 = re . compile ( 'src="(.+?)"' ) . findall ( IIiiiiiiIi1I1 ) [ 0 ]
    O000OO0 = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + OOOoO00 + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    O000OO0 = iIIII1iIIii ( O000OO0 )
    O00O0oOO00O00 = OOOoO00 + "!" + iIIiIiI1I1 . lower ( ) + "!" + O0o0O00Oo0o0
    I11iii1Ii ( O000OO0 , O00O0oOO00O00 , 20 , O0o0O00Oo0o0 , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 52 - 52: O0Oooo00 % O0Oo0oO0o
def Oo000ooOOO ( name , url , iconimage ) :
 if 31 - 31: OoOO % iiIIIIi1i1 % O000oo . OOoOoo00oo - iiIIIIi1i1
 try :
  url , ii11i1ii1Ii , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 46 - 46: I111i1i1111i + i1I1ii1II1iII + OoOO
 OOo0 = [ ]
 if 25 - 25: OoOO0ooOOoo0O + OOooO * I111i1i1111i
 I1i1I = oOO00oOO ( url )
 o0OoOO000ooO0 = re . compile ( '<title>' + re . escape ( ii11i1ii1Ii ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( I1i1I ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( o0OoOO000ooO0 ) [ 0 ]
 i1ii1iiI = re . compile ( '<search>(.+?)</search>' ) . findall ( o0OoOO000ooO0 )
 for o0o0o0oO0oOO in i1ii1iiI :
  OOo0 . append ( o0o0o0oO0oOO )
  if 92 - 92: oooO0oo0oOOOO + iiIIIIi1i1 + Ii1I / O0Oooo00 + ooO00oo
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 18 - 18: O000oo * i1iIii1Ii1II . iI1 / I111i1i1111i / i11iIiiIii
 IIIIIo0ooOoO000oO = 0
 if 85 - 85: O0Oooo00 . i1iIii1Ii1II / O000oo . Ii1I % ooO00oo
 OO0ooo0oOO = [ ]
 oo000 = [ ]
 iiOoO = [ ]
 I1IiiI . update ( 0 )
 Iiiiii111i1ii = 0
 if 25 - 25: I1I1i1 - O000oo / i11iIiiIii
 if O0oO == "true" :
  Iiiiii111i1ii = 1
  o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if IIIIIo0ooOoO000oO < 100 :
    I1IiiI . update ( IIIIIo0ooOoO000oO )
    IIIIIo0ooOoO000oO = IIIIIo0ooOoO000oO + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0 )
   iiI1ii11i1 = [ ]
   for i11I1I1I in iiI1iI111ii1i :
    O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
    for oOOOo00O00O , iIIIII1I in iiIIi :
     O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
    iiI1ii11i1 . append ( O0 )
    if 38 - 38: I111i1i1111i - iI1 / Ii1I . ooO00oo
   for i11I1I1I in iiI1ii11i1 :
    name = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
    url = Ii1i1O0o ( i11I1I1I [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OO0ooo0oOO . append ( name )
    oo000 . append ( url )
    if "hd" in name . lower ( ) :
     iiOoO . append ( "1" )
    else :
     iiOoO . append ( "0" )
    i1iiIiI1Ii1i = list ( zip ( iiOoO , OO0ooo0oOO , oo000 ) )
    if 22 - 22: OOooO / i11iIiiIii
 if o0oO0 == "true" :
  Iiiiii111i1ii = 1
  o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if IIIIIo0ooOoO000oO < 100 :
    I1IiiI . update ( IIIIIo0ooOoO000oO )
    IIIIIo0ooOoO000oO = IIIIIo0ooOoO000oO + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0 )
   iiI1ii11i1 = [ ]
   for i11I1I1I in iiI1iI111ii1i :
    O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
    for oOOOo00O00O , iIIIII1I in iiIIi :
     O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
    iiI1ii11i1 . append ( O0 )
    if 62 - 62: II1iI / I111i1i1111i
   for i11I1I1I in iiI1ii11i1 :
    name = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
    url = Ii1i1O0o ( i11I1I1I [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OO0ooo0oOO . append ( name )
    oo000 . append ( url )
    if "hd" in name . lower ( ) :
     iiOoO . append ( "1" )
    else :
     iiOoO . append ( "0" )
    i1iiIiI1Ii1i = list ( zip ( iiOoO , OO0ooo0oOO , oo000 ) )
    if 7 - 7: OoOO0ooOOoo0O . OOooO
 if oo00 == "true" :
  Iiiiii111i1ii = 1
  o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if IIIIIo0ooOoO000oO < 100 :
    I1IiiI . update ( IIIIIo0ooOoO000oO )
    IIIIIo0ooOoO000oO = IIIIIo0ooOoO000oO + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0 )
   iiI1ii11i1 = [ ]
   for i11I1I1I in iiI1iI111ii1i :
    O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
    for oOOOo00O00O , iIIIII1I in iiIIi :
     O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
    iiI1ii11i1 . append ( O0 )
    if 53 - 53: OOoOoo00oo % OOoOoo00oo * O0Oooo00 + i1iIii1Ii1II
   for i11I1I1I in iiI1ii11i1 :
    name = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
    url = Ii1i1O0o ( i11I1I1I [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OO0ooo0oOO . append ( name )
    oo000 . append ( url )
    if "hd" in name . lower ( ) :
     iiOoO . append ( "1" )
    else :
     iiOoO . append ( "0" )
    i1iiIiI1Ii1i = list ( zip ( iiOoO , OO0ooo0oOO , oo000 ) )
    if 92 - 92: OoOO0ooOOoo0O + o0000oOoOoO0o / OOoOoo00oo * Ii1I
 if Iiiiii111i1ii == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 100 - 100: O000oo % OoOO * i1I1ii1II1iII - iI1
 oo00O00oO000o = sorted ( i1iiIiI1Ii1i , key = lambda Ooo : int ( Ooo [ 0 ] ) , reverse = True )
 OOo00OoO = sorted ( OOo0 )
 if 10 - 10: O0Oooo00 / i11iIiiIii
 I11II1i = 0
 if 92 - 92: iiIIIIi1i1 . ooO00oo
 I1IiiI . update ( 100 )
 if 85 - 85: I111i1i1111i . ooO00oo
 IIiIi11i1 ( '                    [COLOR yellow][I]LINKS FOR ' + ii11i1ii1Ii . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 78 - 78: O000oo * ooO00oo + OoOO + OoOO / ooO00oo . OOoOoo00oo
 if 97 - 97: O000oo / ooO00oo % o0000oOoOoO0o % I111i1i1111i
 for iIIiIiI1I1 in OOo00OoO :
  if 18 - 18: OoOO % iiIIIIi1i1
  IIiIi11i1 ( '                                  [COLOR mediumpurple][I]' + iIIiIiI1I1 . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 95 - 95: O000oo + i11iIiiIii * ooO00oo - o0000oOoOoO0o * ooO00oo - OoOO
  O00OoOO0oo0 = iIIiIiI1I1 . split ( ' ' )
  if 75 - 75: OoOO0ooOOoo0O * OOooO
  for I1Iiiiiii , name , url in oo00O00oO000o :
   if 39 - 39: OOooO * O0Oo0oO0o + OoOO - OOooO + I1I1i1
   o0iiiI1I1iIIIi1 = 0
   if 17 - 17: OoOO . OoOO0ooOOoo0O / iiIIIIi1i1 % i1I1ii1II1iII % o0000oOoOoO0o / i11iIiiIii
   for OOO in O00OoOO0oo0 :
    if 30 - 30: OoOO0ooOOoo0O - OoOO0ooOOoo0O . Ii1I / iI1
    if not OOO . lower ( ) in name . lower ( ) :
     o0iiiI1I1iIIIi1 = 1
     if 31 - 31: I1I1i1 + O0Oooo00 . OoOO0ooOOoo0O
   if o0iiiI1I1iIIIi1 == 0 :
    I11II1i = I11II1i + 1
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 89 - 89: i1I1ii1II1iII + o0000oOoOoO0o + i1I1ii1II1iII
  if I11II1i == 0 :
   IIiIi11i1 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 7 - 7: Ii1I % O0Oooo00 + I111i1i1111i * iI1 - iI1
  O00OoOO0oo0 = ""
  if 42 - 42: i1iIii1Ii1II * i1iIii1Ii1II * ooO00oo . iiIIIIi1i1
 I1IiiI . close ( )
 if 51 - 51: I1I1i1 % OoOO - OoOO0ooOOoo0O % O000oo * OoOO % II1iI
def oO0o00oOOooO0 ( name , url , iconimage ) :
 if 79 - 79: II1iI - OoOO + OOoOoo00oo - ooO00oo
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 93 - 93: i1I1ii1II1iII . oooO0oo0oOOOO - O0Oo0oO0o + i1iIii1Ii1II
 IIIIIo0ooOoO000oO = 0
 try :
  ii11i1ii1Ii , iIIiIiI1I1 , iconimage = url . split ( '!' )
 except :
  try :
   iIIiIiI1I1 , iconimage = url . split ( '!' )
   ii11i1ii1Ii = iIIiIiI1I1
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 61 - 61: i1I1ii1II1iII
 Ii1ii111i1 = 0
 if 31 - 31: I1I1i1 + Ii1I
 if "all " in name . lower ( ) :
  iIIiIiI1I1 = iIIiIiI1I1 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  ii11i1ii1Ii = ii11i1ii1Ii . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  Ii1ii111i1 = 1
  if 87 - 87: O000oo
 OO0ooo0oOO = [ ]
 oo000 = [ ]
 iiOoO = [ ]
 I1IiiI . update ( 0 )
 Iiiiii111i1ii = 0
 if O0oO == "true" :
  Iiiiii111i1ii = 1
  o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if IIIIIo0ooOoO000oO < 100 :
    I1IiiI . update ( IIIIIo0ooOoO000oO )
    IIIIIo0ooOoO000oO = IIIIIo0ooOoO000oO + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0 )
   iiI1ii11i1 = [ ]
   for i11I1I1I in iiI1iI111ii1i :
    O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
    for oOOOo00O00O , iIIIII1I in iiIIi :
     O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
    iiI1ii11i1 . append ( O0 )
    if 45 - 45: II1iI / OoOO0ooOOoo0O - iI1 / OOoOoo00oo % OOooO
   for i11I1I1I in iiI1ii11i1 :
    name = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
    url = Ii1i1O0o ( i11I1I1I [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OO0ooo0oOO . append ( name )
    oo000 . append ( url )
    if "hd" in name . lower ( ) :
     iiOoO . append ( "1" )
    else :
     iiOoO . append ( "0" )
    i1iiIiI1Ii1i = list ( zip ( iiOoO , OO0ooo0oOO , oo000 ) )
    if 83 - 83: oooO0oo0oOOOO . OoOO - OOooO * i11iIiiIii
 if o0oO0 == "true" :
  Iiiiii111i1ii = 1
  o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if IIIIIo0ooOoO000oO < 100 :
    I1IiiI . update ( IIIIIo0ooOoO000oO )
    IIIIIo0ooOoO000oO = IIIIIo0ooOoO000oO + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0 )
   iiI1ii11i1 = [ ]
   for i11I1I1I in iiI1iI111ii1i :
    O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
    for oOOOo00O00O , iIIIII1I in iiIIi :
     O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
    iiI1ii11i1 . append ( O0 )
    if 20 - 20: o0000oOoOoO0o * ooO00oo + i1I1ii1II1iII % O0Oooo00 % Ii1Ii1iiii11
   for i11I1I1I in iiI1ii11i1 :
    name = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
    url = Ii1i1O0o ( i11I1I1I [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OO0ooo0oOO . append ( name )
    oo000 . append ( url )
    if "hd" in name . lower ( ) :
     iiOoO . append ( "1" )
    else :
     iiOoO . append ( "0" )
    i1iiIiI1Ii1i = list ( zip ( iiOoO , OO0ooo0oOO , oo000 ) )
    if 13 - 13: O0Oo0oO0o
 if oo00 == "true" :
  Iiiiii111i1ii = 1
  o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   if IIIIIo0ooOoO000oO < 100 :
    I1IiiI . update ( IIIIIo0ooOoO000oO )
    IIIIIo0ooOoO000oO = IIIIIo0ooOoO000oO + 3
   IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
   url = IIiiiiiiIi1I1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   iiI1iI111ii1i = [ ]
   for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
    O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
    iiI1iI111ii1i . append ( O0 )
   iiI1ii11i1 = [ ]
   for i11I1I1I in iiI1iI111ii1i :
    O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
    iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
    for oOOOo00O00O , iIIIII1I in iiIIi :
     O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
    iiI1ii11i1 . append ( O0 )
    if 60 - 60: I111i1i1111i * oooO0oo0oOOOO
   for i11I1I1I in iiI1ii11i1 :
    name = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
    url = Ii1i1O0o ( i11I1I1I [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    OO0ooo0oOO . append ( name )
    oo000 . append ( url )
    if "hd" in name . lower ( ) :
     iiOoO . append ( "1" )
    else :
     iiOoO . append ( "0" )
    i1iiIiI1Ii1i = list ( zip ( iiOoO , OO0ooo0oOO , oo000 ) )
    if 17 - 17: I1I1i1 % O0Oo0oO0o / I111i1i1111i . OOooO * I1I1i1 - i1I1ii1II1iII
 if Iiiiii111i1ii == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 41 - 41: OOoOoo00oo
 oo00O00oO000o = sorted ( i1iiIiI1Ii1i , key = lambda Ooo : int ( Ooo [ 0 ] ) , reverse = True )
 if 77 - 77: ooO00oo
 I11II1i = 0
 if 65 - 65: i1I1ii1II1iII . oooO0oo0oOOOO % Ii1Ii1iiii11 * II1iI
 I1IiiI . update ( 100 )
 if 38 - 38: i1iIii1Ii1II / iI1 % O0Oo0oO0o
 IIiIi11i1 ( '                                [COLOR yellow][I]LINKS FOR ' + ii11i1ii1Ii . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 IIiIi11i1 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 O00OoOO0oo0 = iIIiIiI1I1 . split ( ' ' )
 for I1Iiiiiii , name , url in oo00O00oO000o :
  if Ii1ii111i1 == 1 :
   I1IIIiii1 = name
   if 65 - 65: iiIIIIi1i1 / i1I1ii1II1iII * OOoOoo00oo . iI1 * Ii1Ii1iiii11 % I1I1i1
  o0iiiI1I1iIIIi1 = 0
  if 69 - 69: O000oo - II1iI / i11iIiiIii + I111i1i1111i % OoOO0ooOOoo0O
  for OOO in O00OoOO0oo0 :
   if 73 - 73: OOoOoo00oo - ooO00oo
   if not OOO . lower ( ) in name . lower ( ) :
    o0iiiI1I1iIIIi1 = 1
    if 68 - 68: iI1 * OoOO0ooOOoo0O * OoOO . i1I1ii1II1iII
  if o0iiiI1I1iIIIi1 == 0 :
   I11II1i = I11II1i + 1
   if Ii1ii111i1 == 1 :
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                          [COLOR blue] ' + str ( I1IIIiii1 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                          [COLOR blue] ' + str ( I1IIIiii1 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     IIiIi11i1 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( I11II1i ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 81 - 81: I1I1i1 / Ii1I + iiIIIIi1i1 + OOoOoo00oo / oooO0oo0oOOOO
 if I11II1i == 0 :
  IIiIi11i1 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 27 - 27: i1iIii1Ii1II * OOooO
 I1IiiI . close ( )
 if 59 - 59: OOooO . OOooO - i1I1ii1II1iII + OOooO . o0000oOoOoO0o . II1iI
def Oo00OOo ( term ) :
 if 64 - 64: i1I1ii1II1iII
 ii1 = [ ]
 I1iI1iIi111i = [ ]
 if 77 - 77: i1iIii1Ii1II % OOoOoo00oo
 o0o0O0O00oOOo = oOO00oOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 ooooooO0oo = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0o0O0O00oOOo )
 for IIiiiiiiIi1I1 in ooooooO0oo :
  IIiiiiiiIi1I1 = IIiiiiiiIi1I1 . replace ( '<br />' , '\n' )
  O00O0oOO00O00 = IIiiiiiiIi1I1
  if 9 - 9: II1iI - O0Oo0oO0o * OoOO0ooOOoo0O . O0Oo0oO0o
  O00O0oOO00O00 = O00O0oOO00O00 . replace ( '#AAASTREAM:' , '#A:' )
  O00O0oOO00O00 = O00O0oOO00O00 . replace ( '#EXTINF:' , '#A:' )
  iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O00O0oOO00O00 )
  iiI1iI111ii1i = [ ]
  for Ii1IIiI1IiIII , OO0Oo000OOOoO , O00O0oOO00O00 in iiIIi :
   O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : O00O0oOO00O00 }
   iiI1iI111ii1i . append ( O0 )
  list = [ ]
  for i11I1I1I in iiI1iI111ii1i :
   O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
   iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
   for oOOOo00O00O , iIIIII1I in iiIIi :
    O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
   list . append ( O0 )
   if 2 - 2: OoOO0ooOOoo0O % I1I1i1
  for i11I1I1I in list :
   O000OO0 = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
   O00O0oOO00O00 = Ii1i1O0o ( i11I1I1I [ "url" ] )
   O00O0oOO00O00 = O00O0oOO00O00 . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in O000OO0 . lower ( ) :
    ii1 . append ( O00O0oOO00O00 )
    I1iI1iIi111i . append ( O000OO0 )
    if 63 - 63: oooO0oo0oOOOO % OoOO
 O00ooooo00 = xbmcgui . Dialog ( )
 ii = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , I1iI1iIi111i )
 if ii < 0 :
  quit ( )
  if 39 - 39: iI1 / i1I1ii1II1iII / I111i1i1111i % oooO0oo0oOOOO
 O00O0oOO00O00 = ii1 [ ii ]
 O000OO0 = I1iI1iIi111i [ ii ]
 o0O ( O000OO0 , O00O0oOO00O00 , iiiii )
 if 89 - 89: ooO00oo + OoOO0ooOOoo0O + ooO00oo * o0000oOoOoO0o + OoOO % iiIIIIi1i1
def oOo0oO ( name , url , iconimage ) :
 if 5 - 5: I1I1i1 - I1I1i1 . O0Oo0oO0o + i1iIii1Ii1II - I1I1i1 . Ii1Ii1iiii11
 list = IiIi1i1ii ( url )
 for i11I1I1I in list :
  name = Ii1i1O0o ( i11I1I1I [ "display_name" ] )
  url = Ii1i1O0o ( i11I1I1I [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  IIiIi11i1 ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 11 - 11: i1I1ii1II1iII / O0Oooo00
def IiIi1i1ii ( url ) :
 if 21 - 21: i11iIiiIii / o0000oOoOoO0o + oooO0oo0oOOOO * I1I1i1 . ooO00oo
 OoO = oo0oO ( url )
 OoO = OoO . replace ( '#AAASTREAM:' , '#A:' )
 OoO = OoO . replace ( '#EXTINF:' , '#A:' )
 iiIIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( OoO )
 iiI1iI111ii1i = [ ]
 for Ii1IIiI1IiIII , OO0Oo000OOOoO , url in iiIIi :
  O0 = { "params" : Ii1IIiI1IiIII , "display_name" : OO0Oo000OOOoO , "url" : url }
  iiI1iI111ii1i . append ( O0 )
 list = [ ]
 for i11I1I1I in iiI1iI111ii1i :
  O0 = { "display_name" : i11I1I1I [ "display_name" ] , "url" : i11I1I1I [ "url" ] }
  iiIIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11I1I1I [ "params" ] )
  for oOOOo00O00O , iIIIII1I in iiIIi :
   O0 [ oOOOo00O00O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iIIIII1I . strip ( )
  list . append ( O0 )
  if 10 - 10: i1I1ii1II1iII . iI1
 return list
 if 32 - 32: OOoOoo00oo . OOooO . OoOO0ooOOoo0O - II1iI + Ii1Ii1iiii11
def ooO0oO00O0o ( ) :
 if 70 - 70: ooO00oo
 O00OoOO0oo0 = ''
 i11iIIi11 = xbmc . Keyboard ( O00OoOO0oo0 , 'Enter Search Term' )
 i11iIIi11 . doModal ( )
 if i11iIIi11 . isConfirmed ( ) :
  O00OoOO0oo0 = i11iIIi11 . getText ( )
  if len ( O00OoOO0oo0 ) > 1 :
   O00O0oOO00O00 = O00OoOO0oo0 + "!" + iiiii
   oO0o00oOOooO0 ( "all " + O00OoOO0oo0 , O00O0oOO00O00 , iiiii )
  else : quit ( )
  if 98 - 98: ooO00oo
def iiI1II11II1i ( name , url , iconimage ) :
 if 67 - 67: I1I1i1 + O0Oo0oO0o
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 84 - 84: Ii1I * OoOO0ooOOoo0O - OOooO * OOooO
  if 8 - 8: O000oo / o0000oOoOoO0o . Ii1Ii1iiii11
  if 41 - 41: iI1 + II1iI
  if 86 - 86: i1iIii1Ii1II . OoOO - II1iI
  if 56 - 56: Ii1I
def OOo00 ( name ) :
 if 37 - 37: o0000oOoOoO0o
 oOoOO = 0
 if 46 - 46: i1iIii1Ii1II - iiIIIIi1i1 - OOoOoo00oo . o0000oOoOoO0o
 try :
  oOO00oOO ( "http://www.google.com" )
 except :
  O00ooooo00 . ok ( Oo0Ooo , '[COLOR red]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/COLOR]' )
  sys . exit ( 0 )
  if 35 - 35: i1I1ii1II1iII * iiIIIIi1i1 - OoOO0ooOOoo0O . iiIIIIi1i1 . iiIIIIi1i1
 try :
  I1IiiI . create ( Oo0Ooo , "Checking for repository updates" , '' , 'Please Wait...' )
  I1IiiI . update ( 0 )
  I11II1i = open ( I11i11Ii ) . read ( )
  IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   I1IiiI . update ( 25 )
   I1IIIii = float ( IIiiiiiiIi1I1 ) + 0.01
   O00O0oOO00O00 = OOOo0 + str ( I1IIIii ) + '.zip'
   o0o0O0O00oOOo = oOO00oOO ( O00O0oOO00O00 )
   if "Not Found" not in o0o0O0O00oOOo :
    oOoOO = 1
    I1IiiI . update ( 75 )
    i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( i1iIIi1 ) :
     os . makedirs ( i1iIIi1 )
    I1II = os . path . join ( i1iIIi1 , 'repoupdate.zip' )
    try : os . remove ( I1II )
    except : pass
    I1IiiI . update ( 100 )
    I1IiiI . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( O00O0oOO00O00 , I1II , I1IiiI )
    OO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    I1IiiI . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( I1II , OO0 , I1IiiI )
    try : os . remove ( I1II )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    O00ooooo00 . ok ( Oo0Ooo , "ECHO repository was updated to " + str ( I1IIIii ) + ', you may need to restart the addon for changes to take effect' )
    if 84 - 84: i1iIii1Ii1II % O000oo - i1iIii1Ii1II . O0Oooo00
  I1IiiI . update ( 75 , "Checking for addon updates" )
  I11II1i = open ( IIi1IiiiI1Ii ) . read ( )
  IIIII = I11II1i . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  ooooooO0oo = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( IIIII ) )
  for IIiiiiiiIi1I1 in ooooooO0oo :
   I1IIIii = float ( IIiiiiiiIi1I1 ) + 0.01
   O00O0oOO00O00 = oO00oOo + str ( I1IIIii ) + '.zip'
   o0o0O0O00oOOo = oOO00oOO ( O00O0oOO00O00 )
   if "Not Found" not in o0o0O0O00oOOo :
    oOoOO = 1
    I1IiiI . update ( 75 )
    i1iIIi1 = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( i1iIIi1 ) :
     os . makedirs ( i1iIIi1 )
    I1II = os . path . join ( i1iIIi1 , 'wizupdate.zip' )
    try : os . remove ( I1II )
    except : pass
    I1IiiI . update ( 100 )
    I1IiiI . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( O00O0oOO00O00 , I1II , I1IiiI )
    OO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    I1IiiI . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( I1II , OO0 , I1IiiI )
    try : os . remove ( I1II )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    I1IiiI . update ( 100 )
    I1IiiI . close
    O00ooooo00 . ok ( Oo0Ooo , "Sportie was updated to " + str ( I1IIIii ) + ', you may need to restart the addon for changes to take effect' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , 'Sorry! We encountered an error whilst checking for updates. You can make Kodi force check the repository for updates as an alternative if you wish.' )
  quit ( )
  if 5 - 5: i1iIii1Ii1II * ooO00oo - I111i1i1111i / OoOO % Ii1Ii1iiii11 + OOooO
 if I1IiiI . iscanceled ( ) :
  I1IiiI . close ( )
 else :
  if oOoOO == 0 :
   if not name == "no dialog" :
    O00ooooo00 . ok ( Oo0Ooo , "There are no updates at this time." )
    quit ( )
    if 51 - 51: ooO00oo * i1I1ii1II1iII % O000oo
def iIIII1iIIii ( text ) :
 if 98 - 98: II1iI . iiIIIIi1i1 % i1I1ii1II1iII
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 71 - 71: ooO00oo % o0000oOoOoO0o - i1I1ii1II1iII - I1I1i1 + I1I1i1 * O000oo
 return text
 if 51 - 51: OoOO / i1iIii1Ii1II + I1I1i1 - iiIIIIi1i1 + iI1
def O0o0OO0000ooo ( text ) :
 if 29 - 29: O0Oooo00 % OoOO . OoOO0ooOOoo0O % OoOO0ooOOoo0O % i1I1ii1II1iII / iI1
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 70 - 70: i11iIiiIii % iI1
 return text
 if 11 - 11: OOooO % I111i1i1111i % OOoOoo00oo / i1I1ii1II1iII % ooO00oo - O0Oo0oO0o
def o0O ( name , url , iconimage ) :
 if 96 - 96: I111i1i1111i / i1I1ii1II1iII . OOoOoo00oo - iI1 * iiIIIIi1i1 * Ii1Ii1iiii11
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 76 - 76: OOoOoo00oo - i1I1ii1II1iII * I1I1i1 / OoOO0ooOOoo0O
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 18 - 18: II1iI + OoOO - i1I1ii1II1iII - oooO0oo0oOOOO
 ooo = url
 OOOO0oooo = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 OOOO0oooo . setPath ( ooo )
 xbmc . Player ( ) . play ( ooo , OOOO0oooo , False )
 if 51 - 51: Ii1I - o0000oOoOoO0o / oooO0oo0oOOOO
def oOO00oOO ( url ) :
 if 37 - 37: O0Oooo00 % O000oo
 O0II11i11II = urllib2 . Request ( url )
 O0II11i11II . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 OoO = urllib2 . urlopen ( O0II11i11II )
 I1i1I = OoO . read ( )
 OoO . close ( )
 I1i1I = I1i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return I1i1I
 if 29 - 29: O0Oo0oO0o % II1iI % OOooO . O0Oooo00 / OoOO0ooOOoo0O * O000oo
def oo0oO ( url ) :
 if 54 - 54: Ii1I
 O0II11i11II = urllib2 . Request ( url )
 O0II11i11II . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 OoO = urllib2 . urlopen ( O0II11i11II )
 I1i1I = OoO . read ( )
 OoO . close ( )
 return I1i1I
 if 68 - 68: II1iI * O0Oooo00 . O000oo % Ii1Ii1iiii11 % ooO00oo
def Ii1i1O0o ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 75 - 75: i1iIii1Ii1II
 if 34 - 34: Ii1I
 if 80 - 80: o0000oOoOoO0o - O0Oo0oO0o / II1iI - i11iIiiIii
 if 68 - 68: Ii1Ii1iiii11 - I111i1i1111i % Ii1I % ooO00oo
 if 11 - 11: Ii1I / II1iI % I1I1i1 + O0Oooo00 + OoOO
def I1i1111I ( ) :
 if 95 - 95: OoOO - I111i1i1111i . ooO00oo - oooO0oo0oOOOO
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 75 - 75: II1iI + O0Oooo00 - o0000oOoOoO0o . OoOO0ooOOoo0O * OOoOoo00oo / OOooO
 if os . path . exists ( Oooo000o ) == True :
  for OOOooo0OooOoO , oOoOOOo , ii1I in os . walk ( Oooo000o ) :
   o0OOoOoO00 = 0
   o0OOoOoO00 += len ( ii1I )
   if o0OOoOoO00 > 0 :
    for I1iii in ii1I :
     try :
      if ( I1iii . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( OOOooo0OooOoO , I1iii ) )
     except :
      pass
    for oOO0OO0O in oOoOOOo :
     try :
      shutil . rmtree ( os . path . join ( OOOooo0OooOoO , oOO0OO0O ) )
     except :
      pass
      if 78 - 78: OOoOoo00oo / i1I1ii1II1iII % i1iIii1Ii1II
   else :
    pass
    if 52 - 52: I1I1i1 - iI1 * Ii1Ii1iiii11
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for OOOooo0OooOoO , oOoOOOo , ii1I in os . walk ( IiIi11iIIi1Ii ) :
   o0OOoOoO00 = 0
   o0OOoOoO00 += len ( ii1I )
   if o0OOoOoO00 > 0 :
    for I1iii in ii1I :
     try :
      if ( I1iii . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( OOOooo0OooOoO , I1iii ) )
     except :
      pass
    for oOO0OO0O in oOoOOOo :
     try :
      shutil . rmtree ( os . path . join ( OOOooo0OooOoO , oOO0OO0O ) )
     except :
      pass
      if 17 - 17: OoOO0ooOOoo0O + I1I1i1 * iiIIIIi1i1 * i1iIii1Ii1II
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iiIii1I = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 47 - 47: O000oo . iiIIIIi1i1 / O0Oooo00
  for OOOooo0OooOoO , oOoOOOo , ii1I in os . walk ( iiIii1I ) :
   o0OOoOoO00 = 0
   o0OOoOoO00 += len ( ii1I )
   if 83 - 83: O0Oooo00 / I1I1i1 / I1I1i1 + O0Oooo00 * ooO00oo + O0Oooo00
   if o0OOoOoO00 > 0 :
    for I1iii in ii1I :
     os . unlink ( os . path . join ( OOOooo0OooOoO , I1iii ) )
    for oOO0OO0O in oOoOOOo :
     shutil . rmtree ( os . path . join ( OOOooo0OooOoO , oOO0OO0O ) )
     if 36 - 36: i1iIii1Ii1II + O0Oooo00 - OoOO0ooOOoo0O . Ii1Ii1iiii11 . OoOO0ooOOoo0O / O0Oo0oO0o
   else :
    pass
  o00O = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 48 - 48: iI1 . i11iIiiIii
  for OOOooo0OooOoO , oOoOOOo , ii1I in os . walk ( o00O ) :
   o0OOoOoO00 = 0
   o0OOoOoO00 += len ( ii1I )
   if 5 - 5: Ii1Ii1iiii11 . I111i1i1111i . i1I1ii1II1iII . OoOO0ooOOoo0O
   if o0OOoOoO00 > 0 :
    for I1iii in ii1I :
     os . unlink ( os . path . join ( OOOooo0OooOoO , I1iii ) )
    for oOO0OO0O in oOoOOOo :
     shutil . rmtree ( os . path . join ( OOOooo0OooOoO , oOO0OO0O ) )
     if 96 - 96: i11iIiiIii - I1I1i1 % Ii1I / II1iI
   else :
    pass
    if 100 - 100: iI1 / OOoOoo00oo - OoOO0ooOOoo0O % i1I1ii1II1iII - oooO0oo0oOOOO % i1iIii1Ii1II
 Oooo = OoO000 ( )
 if 60 - 60: OoOO + o0000oOoOoO0o
 for OooOOo0 in Oooo :
  ooO000O = xbmc . translatePath ( OooOOo0 . path )
  if os . path . exists ( ooO000O ) == True :
   for OOOooo0OooOoO , oOoOOOo , ii1I in os . walk ( ooO000O ) :
    o0OOoOoO00 = 0
    o0OOoOoO00 += len ( ii1I )
    if o0OOoOoO00 > 0 :
     for I1iii in ii1I :
      os . unlink ( os . path . join ( OOOooo0OooOoO , I1iii ) )
     for oOO0OO0O in oOoOOOo :
      shutil . rmtree ( os . path . join ( OOOooo0OooOoO , oOO0OO0O ) )
      if 53 - 53: O0Oooo00 . iI1 / OOoOoo00oo
    else :
     pass
     if 39 - 39: OOoOoo00oo % Ii1I % i1iIii1Ii1II . o0000oOoOoO0o
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 86 - 86: II1iI * OoOO0ooOOoo0O
def OooO0oOo ( ) :
 oOOo00O0OOOo = [ ]
 i11I1I1iiI = sys . argv [ 2 ]
 if len ( i11I1I1iiI ) >= 2 :
  Ii1IIiI1IiIII = sys . argv [ 2 ]
  I1i1iii1Ii = Ii1IIiI1IiIII . replace ( '?' , '' )
  if ( Ii1IIiI1IiIII [ len ( Ii1IIiI1IiIII ) - 1 ] == '/' ) :
   Ii1IIiI1IiIII = Ii1IIiI1IiIII [ 0 : len ( Ii1IIiI1IiIII ) - 2 ]
  iI = I1i1iii1Ii . split ( '&' )
  oOOo00O0OOOo = { }
  for O000OOo00oo in range ( len ( iI ) ) :
   O0O00OOo = { }
   O0O00OOo = iI [ O000OOo00oo ] . split ( '=' )
   if ( len ( O0O00OOo ) ) == 2 :
    oOOo00O0OOOo [ O0O00OOo [ 0 ] ] = O0O00OOo [ 1 ]
 return oOOo00O0OOOo
 if 66 - 66: i11iIiiIii / O0Oooo00 - OoOO0ooOOoo0O / o0000oOoOoO0o . i11iIiiIii
def I11iii1Ii ( name , url , mode , iconimage , fanart , description = '' ) :
 if 16 - 16: O0Oo0oO0o % I111i1i1111i + iiIIIIi1i1 - Ii1I . iI1 / ooO00oo
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 IIi1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 iii = True
 OOOO0oooo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 OOOO0oooo . setProperty ( "fanart_Image" , fanart )
 OOOO0oooo . setProperty ( "icon_Image" , iconimage )
 iii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIi1I , listitem = OOOO0oooo , isFolder = True )
 return iii
 if 95 - 95: OOooO * I111i1i1111i % O000oo % OOoOoo00oo - OOoOoo00oo
def IIiIi11i1 ( name , url , mode , iconimage , fanart , description = '' ) :
 if 97 - 97: I111i1i1111i + OoOO . Ii1I
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 IIi1I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 iii = True
 OOOO0oooo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 OOOO0oooo . setProperty ( "fanart_Image" , fanart )
 OOOO0oooo . setProperty ( "icon_Image" , iconimage )
 iii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIi1I , listitem = OOOO0oooo , isFolder = False )
 return iii
 if 64 - 64: o0000oOoOoO0o % O000oo / i11iIiiIii - o0000oOoOoO0o % I1I1i1 . iI1
Ii1IIiI1IiIII = OooO0oOo ( ) ; O00O0oOO00O00 = None ; O000OO0 = None ; II1i111 = None ; i1iiiIii11 = None ; O0o0O00Oo0o0 = None ; II = None
try : i1iiiIii11 = urllib . unquote_plus ( Ii1IIiI1IiIII [ "site" ] )
except : pass
try : O00O0oOO00O00 = urllib . unquote_plus ( Ii1IIiI1IiIII [ "url" ] )
except : pass
try : O000OO0 = urllib . unquote_plus ( Ii1IIiI1IiIII [ "name" ] )
except : pass
try : II1i111 = int ( Ii1IIiI1IiIII [ "mode" ] )
except : pass
try : O0o0O00Oo0o0 = urllib . unquote_plus ( Ii1IIiI1IiIII [ "iconimage" ] )
except : pass
try : II = urllib . unquote_plus ( Ii1IIiI1IiIII [ "fanart" ] )
except : pass
if 67 - 67: O0Oooo00 % i1iIii1Ii1II . i1iIii1Ii1II - O000oo
if II1i111 == None or O00O0oOO00O00 == None or len ( O00O0oOO00O00 ) < 1 : oO00O00o0OOO0 ( )
elif II1i111 == 1 : III1iII1I1ii ( O000OO0 , O00O0oOO00O00 )
elif II1i111 == 2 : o0O ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 3 : OOOOOoo0 ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 4 : PLAYSD ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 8 : IIOOOO0oo0 ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 9 : OOo00 ( O000OO0 )
elif II1i111 == 10 : oOo0oO ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 11 : IIii11I1 ( )
elif II1i111 == 12 : I1iiiiIii ( O00O0oOO00O00 )
elif II1i111 == 19 : iiII1i11i ( O00O0oOO00O00 )
elif II1i111 == 20 : oO0o00oOOooO0 ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 21 : O0O0Ooo ( O00O0oOO00O00 )
elif II1i111 == 22 : Oo000ooOOO ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 23 : IIi ( )
elif II1i111 == 24 : oOooOOo0o ( )
elif II1i111 == 25 : O0oOOoOooooO ( )
elif II1i111 == 30 : IIIIii1I ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 100 : ooO0oO00O0o ( )
elif II1i111 == 500 : I1i1111I ( )
elif II1i111 == 201 : ooO0OO ( )
elif II1i111 == 202 : O00oO000O0O ( O00O0oOO00O00 )
elif II1i111 == 203 : IIiIiI ( O00O0oOO00O00 )
elif II1i111 == 204 : II11Ii1iI1iII ( O00O0oOO00O00 )
elif II1i111 == 205 : o0oooOO00 ( O00O0oOO00O00 )
elif II1i111 == 206 : o0ooooO0o0O ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 210 : oOoOo0O0OOOoO ( O00O0oOO00O00 )
elif II1i111 == 220 : OOo0o0O0O ( O00O0oOO00O00 )
elif II1i111 == 221 : i1Ii1i1I11Iii ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
elif II1i111 == 800 : iiI1II11II1i ( O000OO0 , O00O0oOO00O00 , O0o0O00Oo0o0 )
if 90 - 90: O000oo + i1I1ii1II1iII * I111i1i1111i / OOoOoo00oo . O0Oooo00 + O0Oooo00
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )