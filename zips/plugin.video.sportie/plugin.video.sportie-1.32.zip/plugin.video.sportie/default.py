import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluX21lbnUueG1s' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = xbmc . translatePath ( 'special://home/addons/program.plexus' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
Oooo000o = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oo0O = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
OOo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
Ii1IIii11 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 55 - 55: i1111 - i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
oO000OoOoo00o = "true"
iiiI11 = "false"
OOooO = "false"
try :
 oO000OoOoo00o = plugintools . get_setting ( "scrape1" )
 iiiI11 = plugintools . get_setting ( "scrape2" )
 OOooO = plugintools . get_setting ( "scrape3" )
except :
 oO000OoOoo00o = "true"
 iiiI11 = "false"
 OOooO = "false"
 if 58 - 58: i11iiII + OooooO0oOO + oOo0 / oo0Ooo0
I1I11I1I1I = IiiIII111iI + '|SPLIT|' + o0O
checker . check ( I1I11I1I1I )
if 90 - 90: i1IIiiiii + i1iIIIiI1I - OoO000 % OooOoO0Oo + iiIIiIiIi
if not os . path . exists ( IiII ) :
 os . makedirs ( IiII )
 if 38 - 38: i1IIiiiii / I11i1i11i1I
if not os . path . isfile ( i1i1II ) :
 OooO0 = open ( i1i1II , 'w' )
 if 35 - 35: oOo0 % OooOoO0Oo % i11iIiiIii / i111I
if not os . path . isfile ( iI1Ii11111iIi ) :
 OooO0 = open ( iI1Ii11111iIi , 'w' )
 if 13 - 13: II1Ii1iI1i - i1IIiiiii % OooooO0oOO / ooO0oo0oO0 % i1iIIIiI1I
if not os . path . isfile ( O0oo0OO0 ) :
 OooO0 = open ( O0oo0OO0 , 'w' )
 if 97 - 97: i11iIiiIii
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 32 - 32: I11i1i11i1I * oooO0oo0oOOOO % OooooO0oOO % i1IIiiiii . OoO000
class o0OOOOO00o0O0 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 71 - 71: iiIIiIiIi % i1iIIIiI1I / oo0ooO0oOOOOo
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 49 - 49: i1111 % i1iIIIiI1I * oooO0oo0oOOOO
oOOo0oo = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 80 - 80: oo0Ooo0 * i11iIiiIii / OooOoO0Oo
class I11II1i :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 23 - 23: i11iiII / oo0ooO0oOOOOo + oo0Ooo0 + oo0Ooo0 / i1111
  if 26 - 26: i111I
  if 12 - 12: i111I % OOO0O / iiIIiIiIi % oo0ooO0oOOOOo
  if 29 - 29: i111I
def iI ( ) :
 I1i1I1II = 5
 i1 = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 IiIiiI = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 31 - 31: i1IIiiiii . i1IIiiiii - oo0ooO0oOOOOo / oo + iiIIiIiIi * i1IIi11111i
 O0ooOooooO = [ ]
 if 60 - 60: oo0Ooo0 / oo0Ooo0
 for I1II1III11iii in range ( I1i1I1II ) :
  O0ooOooooO . append ( I11II1i ( i1 [ I1II1III11iii ] , IiIiiI [ I1II1III11iii ] ) )
  if 75 - 75: ooO0oo0oO0 / oOo0 % oo0ooO0oOOOOo * OOO0O
 return O0ooOooooO
 if 9 - 9: oo
def i11 ( ) :
 if 58 - 58: oOo0 * i11iIiiIii / OOO0O % OooOoO0Oo - i11iiII / OooooO0oOO
 ii11i1 = IIIii1II1II ( OOo )
 if len ( ii11i1 ) > 1 :
  i1I1iI = i1i1II
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 83 - 83: i11iiII / iiIIiIiIi
 ii11i1 = IIIii1II1II ( iiI1iIiI )
 if len ( ii11i1 ) > 1 :
  i1I1iI = iI1Ii11111iIi
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 49 - 49: oo0ooO0oOOOOo
 ii11i1 = IIIii1II1II ( Ii1IIii11 )
 if len ( ii11i1 ) > 1 :
  i1I1iI = O0oo0OO0
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 35 - 35: OOO0O - i111I / i11iiII % II1Ii1iI1i
 o00OO00OoO = OOOO0OOoO0O0 ( II1 )
 O0Oo000ooO00 = II1
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 62 - 62: ooO0oo0oO0 * OOO0O
  if '<search>display</search>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo ( i1OOO , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 58 - 58: i1111 * oOo0 * i11iiII / oOo0
  elif '<arenavision>display</arenavision>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   if os . path . exists ( oO00oOo ) : Oo0oOOo ( i1OOO , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : oO0o0OOOO ( '[COLOR darkgray]' + i1OOO + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 68 - 68: i1iIIIiI1I - OooOoO0Oo - i1IIi11111i - i11iiII + oo0Ooo0
   if 10 - 10: i111I % ooO0oo0oO0
  elif '<vip>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo ( i1OOO , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 54 - 54: OooOoO0Oo - i1111 % OOO0O % oo0Ooo0 % ooO0oo0oO0 + iiIIiIiIi
  elif '<divider>null</divider>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( i1OOO , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 15 - 15: oo0Ooo0 * iiIIiIiIi * I11i1i11i1I % i11iIiiIii % OOO0O - oOo0
   if 68 - 68: OooOoO0Oo % II1Ii1iI1i . OoO000 . i11iiII
   if 92 - 92: i1iIIIiI1I . OooOoO0Oo
   if 31 - 31: OooOoO0Oo . OOO0O / oooO0oo0oOOOO
   if 89 - 89: OOO0O
   if 68 - 68: oo * i111I % oooO0oo0oOOOO + oo + iiIIiIiIi
  elif '<m3ulists>display</m3ulists>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo ( i1OOO , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 4 - 4: iiIIiIiIi + oooO0oo0oOOOO * oOo0
   if 55 - 55: I11i1i11i1I + ooO0oo0oO0 / OOO0O * OooooO0oOO - i11iIiiIii - i1IIiiiii
   if 25 - 25: i11iiII
   if 7 - 7: II1Ii1iI1i / i1IIi11111i * OooOoO0Oo . OoO000 . ooO0oo0oO0
   if 13 - 13: oOo0 / i11iIiiIii
   if 2 - 2: i1IIi11111i / oooO0oo0oOOOO / oo0ooO0oOOOOo % OOO0O % i1IIiiiii
   if 52 - 52: oo0ooO0oOOOOo
   if 95 - 95: i1IIiiiii
   if 87 - 87: iiIIiIiIi + OOO0O . oOo0 + OOO0O
   if 91 - 91: oooO0oo0oOOOO
   if 61 - 61: i1111
   if 64 - 64: iiIIiIiIi / OOO0O - oooO0oo0oOOOO - oo0Ooo0
   if 86 - 86: oo0Ooo0 % OOO0O / i1IIi11111i / OOO0O
   if 42 - 42: oo
   if 67 - 67: OooOoO0Oo . i1iIIIiI1I . oooO0oo0oOOOO
   if 10 - 10: i11iiII % i11iiII - ooO0oo0oO0 / oOo0 + i1IIiiiii
   if 87 - 87: OooooO0oOO * i11iiII + oOo0 / ooO0oo0oO0 / i1iIIIiI1I
   if 37 - 37: i1iIIIiI1I - iiIIiIiIi * OooooO0oOO % i11iIiiIii - OooOoO0Oo
   if 83 - 83: oo0Ooo0 / i1IIi11111i
   if 34 - 34: OoO000
   if 57 - 57: OooooO0oOO . oo0Ooo0 . II1Ii1iI1i
   if 42 - 42: oo0Ooo0 + i11iiII % oooO0oo0oOOOO
  elif '<sportsdevil>' in Ii1iIiII1ii1 :
   i1iIIIi1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    i1iI11i1ii11 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    OOooo0O00o = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    oOOoOooOo = OOooo0O00o
    O000oo = "/"
    if not oOOoOooOo . endswith ( O000oo ) :
     IIi1I11I1II = oOOoOooOo + "/"
    else :
     IIi1I11I1II = oOOoOooOo
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( i1OOO ) + '%26url=' + i1iI11i1ii11
    i1iI11i1ii11 = o00OO00OoO + '%26referer=' + IIi1I11I1II
    oO0o0OOOO ( i1OOO , i1iI11i1ii11 , 4 , iI1iIIiiii , OooOoooOo )
   elif len ( i1iIIIi1i ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    oO0o0OOOO ( i1OOO , O0Oo000ooO00 + 'NOTPLAY' , 8 , iI1iIIiiii , OooOoooOo )
  elif '<plexus>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OooOoooOo = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : oO0o0OOOO ( i1OOO , O0Oo000ooO00 + 'NOTPLAY' , 7 , iI1iIIiiii , OooOoooOo )
   else : oO0o0OOOO ( '[COLOR darkgray]' + i1OOO + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 46 - 46: i1iIIIiI1I
  elif '<rutubeplaylist>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OooOoooOo = O0O0OO0O0O0
   Oo0oOOo ( i1OOO , O0Oo000ooO00 , 90 , iI1iIIiiii , OooOoooOo )
  elif '<folder>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for i1OOO , i1iI11i1ii11 , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    Oo0oOOo ( i1OOO , i1iI11i1ii11 , 1 , iI1iIIiiii , OooOoooOo )
  elif '<m3u>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for i1OOO , i1iI11i1ii11 , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    Oo0oOOo ( i1OOO , i1iI11i1ii11 , 10 , iI1iIIiiii , OooOoooOo )
  else :
   i1iIIIi1i = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
    i1I = len ( oO0 )
    for i1OOO , i1iI11i1ii11 , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
     oO0o0OOOO ( i1OOO , i1iI11i1ii11 , 2 , iI1iIIiiii , OooOoooOo )
   elif len ( i1iIIIi1i ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    oO0o0OOOO ( i1OOO , II1 , 3 , iI1iIIiiii , OooOoooOo )
    if 72 - 72: II1Ii1iI1i / oo + i111I - I11i1i11i1I
 iI1Iii = open ( IIi1IiiiI1Ii ) . read ( )
 oO00OOoO00 = iI1Iii . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 oO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( oO00OOoO00 ) )
 for Ii1iIiII1ii1 in oO0 :
  IiI111111IIII = float ( Ii1iIiII1ii1 )
 iI1Iii = open ( I11i11Ii ) . read ( )
 oO00OOoO00 = iI1Iii . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 oO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( oO00OOoO00 ) )
 for Ii1iIiII1ii1 in oO0 :
  i1Ii = float ( Ii1iIiII1ii1 )
  if 14 - 14: i1iIIIiI1I
 oO0o0OOOO ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( IiI111111IIII ) + "[/COLOR]" , 'url' , 999 , iiiii , OooOoooOo , '' )
 oO0o0OOOO ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( i1Ii ) + "[/COLOR]" , 'url' , 999 , iiiii , OooOoooOo , '' )
 if 11 - 11: OoO000 * i1IIi11111i . ooO0oo0oO0 % i111I + i1iIIIiI1I
 OOO = oo0OOo0 ( )
 if 47 - 47: OooOoO0Oo + OOO0O * I11i1i11i1I / iiIIiIiIi - i1iIIIiI1I % ooO0oo0oO0
 if OOO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 26 - 26: i11iiII * i1iIIIiI1I . i1111 * i1IIiiiii
def II1iiiIi1 ( name , url ) :
 if 38 - 38: OooOoO0Oo
 hash = [ ]
 O0Oo000ooO00 = url
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 if 84 - 84: ooO0oo0oO0 % i1iIIIiI1I / ooO0oo0oO0 % oo0Ooo0
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 45 - 45: oooO0oo0oOOOO
  if '<search>' in Ii1iIiII1ii1 :
   if 26 - 26: oo0Ooo0 - ooO0oo0oO0 - i1IIi11111i / oo . OOO0O % ooO0oo0oO0
   i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = name + "!" + url + "!" + iI1iIIiiii
    name = '[COLOR white]' + name + '[/COLOR]'
    Oo0oOOo ( name , url , 20 , iI1iIIiiii , iI1iIIiiii )
    if 91 - 91: oo0ooO0oOOOOo . ooO0oo0oO0 / OooooO0oOO + II1Ii1iI1i
   elif len ( i1iIIIi1i ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = O0Oo000ooO00 + "!" + name + "!" + iI1iIIiiii
    name = '[COLOR white]' + name + '[/COLOR]'
    Oo0oOOo ( name , url , 22 , iI1iIIiiii , iI1iIIiiii )
    if 42 - 42: iiIIiIiIi . oo0ooO0oOOOOo . iiIIiIiIi - i11iiII
  elif '<fightclubsearch>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<fightclubsearch>(.+?)</fightclubsearch>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = 'true|SPLIT|' + url
   Oo0oOOo ( name , url , 222 , iiiii , O0O0OO0O0O0 )
   if 40 - 40: iiIIiIiIi - i11iIiiIii / i1IIiiiii
  elif '<fightclubterms>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<fightclubterms>(.+?)</fightclubterms>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = 'false|SPLIT|' + url + '|SPLIT|' + O0Oo000ooO00 + '|SPLIT|' + name
   Oo0oOOo ( name , url , 222 , iiiii , O0O0OO0O0O0 )
   if 35 - 35: i1IIiiiii - i1IIi11111i % oo0ooO0oOOOOo . i111I % i1IIiiiii
  elif '<arenavision>display</arenavision>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   if os . path . exists ( oO00oOo ) : Oo0oOOo ( name , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : oO0o0OOOO ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 47 - 47: i1iIIIiI1I - i1IIiiiii . i1111 + i111I . i11iIiiIii
  elif '<divider>null</divider>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( name , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 94 - 94: oo0ooO0oOOOOo * i1IIiiiii / I11i1i11i1I / i1IIiiiii
  elif '<regex>' in Ii1iIiII1ii1 :
   oO0O0OO0O = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Ii1iIiII1ii1 )
   oO0O0OO0O = '' . join ( oO0O0OO0O )
   OO = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( oO0O0OO0O )
   oO0O0OO0O = urllib . quote_plus ( oO0O0OO0O )
   if 83 - 83: oooO0oo0oOOOO / i1IIi11111i - oo - oOo0
   iI1i11iII111 = hashlib . md5 ( )
   for Iii1IIII11I in oO0O0OO0O : iI1i11iII111 . update ( str ( Iii1IIII11I ) )
   iI1i11iII111 = str ( iI1i11iII111 . hexdigest ( ) )
   if 77 - 77: I11i1i11i1I - II1Ii1iI1i - oo0Ooo0 . OOO0O
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Ii1iIiII1ii1 = re . sub ( '<regex>.+?</regex>' , '' , Ii1iIiII1ii1 )
   Ii1iIiII1ii1 = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Ii1iIiII1ii1 )
   Ii1iIiII1ii1 = re . sub ( '<link></link>' , '' , Ii1iIiII1ii1 )
   if 39 - 39: i1111 / iiIIiIiIi + OooOoO0Oo / OOO0O
   name = re . sub ( '<meta>.+?</meta>' , '' , Ii1iIiII1ii1 )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 13 - 13: OoO000 + oooO0oo0oOOOO + i1iIIIiI1I % i1IIi11111i / oo0ooO0oOOOOo . OoO000
   try : OO0Oooo0oOO0O = re . findall ( '<date>(.+?)</date>' , Ii1iIiII1ii1 ) [ 0 ]
   except : OO0Oooo0oOO0O = ''
   if re . search ( r'\d+' , OO0Oooo0oOO0O ) : name += ' [COLOR red] Updated %s[/COLOR]' % OO0Oooo0oOO0O
   if 62 - 62: i1IIi11111i
   try : O00o0OO0 = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Ii1iIiII1ii1 ) [ 0 ]
   except : O00o0OO0 = iiiii
   if 35 - 35: OooooO0oOO % iiIIiIiIi / OooOoO0Oo + ooO0oo0oO0 . i111I . i1IIi11111i
   try : o00oOOooOOo0o = re . findall ( '<fanart>(.+?)</fanart>' , Ii1iIiII1ii1 ) [ 0 ]
   except : o00oOOooOOo0o = O0O0OO0O0O0
   if 66 - 66: i1iIIIiI1I - i1iIIIiI1I - i11iIiiIii . i11iiII - oOo0
   try : oOOo0O00o = re . findall ( '<meta>(.+?)</meta>' , Ii1iIiII1ii1 ) [ 0 ]
   except : oOOo0O00o = '0'
   if 8 - 8: oo
   try : url = re . findall ( '<link>(.+?)</link>' , Ii1iIiII1ii1 ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % oOOo0O00o )
   url = '<preset>search</preset>%s' % oOOo0O00o if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % oOOo0O00o )
   url = '<preset>searchsd</preset>%s' % oOOo0O00o if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 49 - 49: i1IIi11111i - oo0Ooo0
   if not oO0O0OO0O == '' :
    hash . append ( { 'regex' : iI1i11iII111 , 'response' : oO0O0OO0O } )
    url += '|regex=%s' % oO0O0OO0O
    if 74 - 74: ooO0oo0oO0 * i11iiII + OOO0O / II1Ii1iI1i / i1111 . I11i1i11i1I
   oO0o0OOOO ( name , url , 30 , O00o0OO0 , o00oOOooOOo0o )
   if 62 - 62: i111I * i1IIi11111i
  elif '<sportsdevil>' in Ii1iIiII1ii1 :
   i1iIIIi1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OOooo0O00o = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OOooo0O00o = "None"
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OooOoooOo = O0O0OO0O0O0
    oOOoOooOo = OOooo0O00o
    O000oo = "/"
    if not oOOoOooOo . endswith ( O000oo ) :
     IIi1I11I1II = oOOoOooOo + "/"
    else :
     IIi1I11I1II = oOOoOooOo
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = o00OO00OoO + '%26referer=' + IIi1I11I1II
    oO0o0OOOO ( name , url , 2 , iI1iIIiiii , OooOoooOo )
    if 58 - 58: OOO0O % oo0ooO0oOOOOo
   elif len ( i1iIIIi1i ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OooOoooOo = O0O0OO0O0O0
    oO0o0OOOO ( name , O0Oo000ooO00 + 'NOTPLAY' , 8 , iI1iIIiiii , OooOoooOo )
    if 50 - 50: OooOoO0Oo . oo0ooO0oOOOOo
  elif '<plexus>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OooOoooOo = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : oO0o0OOOO ( name , O0Oo000ooO00 + 'NOTPLAY' , 7 , iI1iIIiiii , OooOoooOo )
   else : oO0o0OOOO ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 97 - 97: oooO0oo0oOOOO + OOO0O
  elif '<rutubeplaylist>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OooOoooOo = O0O0OO0O0O0
   Oo0oOOo ( name , O0Oo000ooO00 , 90 , iI1iIIiiii , OooOoooOo )
   if 89 - 89: oo0ooO0oOOOOo + oo * oo0Ooo0 * i1IIiiiii
  elif '<folder>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    Oo0oOOo ( name , url , 1 , iI1iIIiiii , OooOoooOo )
    if 37 - 37: i111I - oooO0oo0oOOOO - oo0ooO0oOOOOo
  elif '<m3u>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    Oo0oOOo ( name , url , 10 , iI1iIIiiii , OooOoooOo )
    if 77 - 77: oOo0 * ooO0oo0oO0
  elif '<rutube>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?rutube>(.+?)</rutube>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    O0Oo000ooO00 = 'https://rutube.ru/play/embed/' + url + '?wmode=opaque&fakeFullscreen=1'
    Oo0oOOo ( name , O0Oo000ooO00 , 2 , iI1iIIiiii , OooOoooOo )
  else :
   i1iIIIi1i = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
    i1I = len ( oO0 )
    for name , url , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
     oO0o0OOOO ( name , url , 2 , iI1iIIiiii , OooOoooOo )
   elif len ( i1iIIIi1i ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OooOoooOo = O0O0OO0O0O0
    oO0o0OOOO ( name , O0Oo000ooO00 , 3 , iI1iIIiiii , OooOoooOo )
    if 98 - 98: i1IIi11111i % i1IIiiiii * i111I
 OOO = oo0OOo0 ( )
 if 51 - 51: ooO0oo0oO0 . OOO0O / OooooO0oOO + oo0ooO0oOOOOo
 if OOO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 33 - 33: iiIIiIiIi . i1111 % i1iIIIiI1I + oo0ooO0oOOOOo
def oO00O000oO0 ( name , url , iconimage ) :
 O0OoOO0o = [ ]
 ooooo0O0000oo = [ ]
 iIii1II11 = [ ]
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 OooOo0ooo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( OooOo0ooo ) [ 0 ]
 i1iIIIi1i = re . compile ( '<link>(.+?)</link>' ) . findall ( OooOo0ooo )
 Iii1IIII11I = 1
 for o00oo0 in i1iIIIi1i :
  I11ii1IIiIi = o00oo0
  if '(' in o00oo0 :
   o00oo0 = o00oo0 . split ( '(' ) [ 0 ]
   OoOOo0OOoO = str ( I11ii1IIiIi . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   O0OoOO0o . append ( o00oo0 )
   ooooo0O0000oo . append ( OoOOo0OOoO )
  else :
   O0OoOO0o . append ( o00oo0 )
   ooooo0O0000oo . append ( 'Link ' + str ( Iii1IIII11I ) )
  Iii1IIII11I = Iii1IIII11I + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 ooO0O00Oo0o = O00ooooo00 . select ( name , ooooo0O0000oo )
 if ooO0O00Oo0o < 0 :
  quit ( )
 else :
  url = O0OoOO0o [ ooO0O00Oo0o ]
  print url
  if 65 - 65: i11iiII . oo0Ooo0 - OooOoO0Oo * OoO000 / OooOoO0Oo / iiIIiIiIi
 url = O0OoOO0o [ ooO0O00Oo0o ]
 name = ooooo0O0000oo [ ooO0O00Oo0o ]
 i111iIi1i1II1 ( name , url , iiiii )
 if 86 - 86: ooO0oo0oO0 / OOO0O . i1111
def II1i111Ii1i ( name , url , iconimage ) :
 if 15 - 15: i1111 / II1Ii1iI1i
 O0OoOO0o = [ ]
 ooooo0O0000oo = [ ]
 iIii1II11 = [ ]
 O0oO0 = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 OooOo0ooo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 i1iIIIi1i = re . compile ( '<plexus>(.+?)</plexus>' ) . findall ( OooOo0ooo )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( OooOo0ooo ) [ 0 ]
 if 7 - 7: i1IIi11111i
 I1ii1iIiii1I = "plugin://program.plexus/?url="
 IIIii11 = "&mode=1&name=acestream+"
 Iii1IIII11I = 0
 if 9 - 9: oooO0oo0oOOOO % oooO0oo0oOOOO - oo0ooO0oOOOOo
 for o00oo0 in i1iIIIi1i :
  Iii1IIII11I = Iii1IIII11I + 1
  if 51 - 51: i1IIi11111i . ooO0oo0oO0 - i11iiII / oooO0oo0oOOOO
  I11ii1IIiIi = o00oo0
  if '(' in o00oo0 :
   o00oo0 = o00oo0 . split ( '(' ) [ 0 ]
   OoOOo0OOoO = str ( I11ii1IIiIi . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   O0OoOO0o . append ( o00oo0 )
   ooooo0O0000oo . append ( OoOOo0OOoO )
   O0oO0 . append ( 'Stream ' + str ( Iii1IIII11I ) )
  else :
   O0OoOO0o . append ( o00oo0 )
   ooooo0O0000oo . append ( 'Link ' + str ( Iii1IIII11I ) )
   OoOOo0OOoO = name
   if 52 - 52: oo0ooO0oOOOOo + oooO0oo0oOOOO + i1iIIIiI1I + I11i1i11i1I % i1iIIIiI1I
   if 75 - 75: i1IIi11111i . iiIIiIiIi . oooO0oo0oOOOO * OooOoO0Oo
 if Iii1IIII11I > 1 :
  O00ooooo00 = xbmcgui . Dialog ( )
  ooO0O00Oo0o = O00ooooo00 . select ( name , ooooo0O0000oo )
  if ooO0O00Oo0o < 0 :
   quit ( )
  else :
   i11II1I11I1 = O0OoOO0o [ ooO0O00Oo0o ]
   if not 'acestream://' in i11II1I11I1 :
    i11II1I11I1 = 'acestream://' + i11II1I11I1
   url = I1ii1iIiii1I + i11II1I11I1 + IIIii11 + ooooo0O0000oo [ ooO0O00Oo0o ]
   name = ooooo0O0000oo [ ooO0O00Oo0o ]
 else :
  i11II1I11I1 = o00oo0
  if not 'acestream://' in i11II1I11I1 :
   i11II1I11I1 = 'acestream://' + i11II1I11I1
  url = I1ii1iIiii1I + i11II1I11I1 + IIIii11 + OoOOo0OOoO
  name = OoOOo0OOoO
  if 67 - 67: i1IIi11111i - oo0ooO0oOOOOo / oo0Ooo0 - II1Ii1iI1i
 i111iIi1i1II1 ( name , url , iiiii )
 if 1 - 1: i1111
def O0oOo00o ( name , url , iconimage ) :
 if 81 - 81: OoO000 % II1Ii1iI1i . ooO0oo0oO0
 O0OoOO0o = [ ]
 ooooo0O0000oo = [ ]
 iIii1II11 = [ ]
 O0oO0 = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 OooOo0ooo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 i1iIIIi1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( OooOo0ooo )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( OooOo0ooo ) [ 0 ]
 if 4 - 4: i11iIiiIii % oo % II1Ii1iI1i / OoO000
 I11iI = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 68 - 68: ooO0oo0oO0 / oOo0
 Iii1IIII11I = 1
 if 23 - 23: OooOoO0Oo . OoO000
 for o00oo0 in i1iIIIi1i :
  I11ii1IIiIi = o00oo0
  if '(' in o00oo0 :
   o00oo0 = o00oo0 . split ( '(' ) [ 0 ]
   OoOOo0OOoO = str ( I11ii1IIiIi . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   O0OoOO0o . append ( o00oo0 )
   ooooo0O0000oo . append ( OoOOo0OOoO )
   O0oO0 . append ( 'Stream ' + str ( Iii1IIII11I ) )
  else :
   O0OoOO0o . append ( o00oo0 )
   ooooo0O0000oo . append ( 'Link ' + str ( Iii1IIII11I ) )
   if 92 - 92: OOO0O + OooOoO0Oo * i1IIiiiii % i1IIi11111i
  Iii1IIII11I = Iii1IIII11I + 1
  if 42 - 42: I11i1i11i1I
 name = '[COLOR red]' + name + '[/COLOR]'
 if 76 - 76: i1IIi11111i * i1iIIIiI1I % OooOoO0Oo
 O00ooooo00 = xbmcgui . Dialog ( )
 ooO0O00Oo0o = O00ooooo00 . select ( name , ooooo0O0000oo )
 if ooO0O00Oo0o < 0 :
  quit ( )
 else :
  oOOoOooOo = ooooo0O0000oo [ ooO0O00Oo0o ]
  O000oo = "/"
  if not oOOoOooOo . endswith ( O000oo ) :
   IIi1I11I1II = oOOoOooOo + "/"
  else :
   IIi1I11I1II = oOOoOooOo
  url = I11iI + O0OoOO0o [ ooO0O00Oo0o ] + "%26referer=" + IIi1I11I1II
  if 57 - 57: ooO0oo0oO0 - II1Ii1iI1i / OooOoO0Oo - oooO0oo0oOOOO * i111I % i1111
 name = ooooo0O0000oo [ ooO0O00Oo0o ]
 i111iIi1i1II1 ( name , url , iiiii )
 if 68 - 68: i111I * oo0Ooo0 % OOO0O - OoO000
def I1 ( name , url , iconimage ) :
 if 97 - 97: iiIIiIiIi
 ii1I1IIIi = [ ]
 o0OOOOooo = [ ]
 if 94 - 94: i111I + I11i1i11i1I / OOO0O * oOo0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 OooOo0ooo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 i1iIIIi1i = re . compile ( '<rutubeplaylist>(.+?)</rutubeplaylist>' ) . findall ( OooOo0ooo )
 if 69 - 69: iiIIiIiIi % OooooO0oOO
 for o00oo0 in i1iIIIi1i :
  I11ii1IIiIi = o00oo0
  if '(' in o00oo0 :
   o00oo0 = o00oo0 . split ( '(' ) [ 0 ]
   OoOOo0OOoO = str ( I11ii1IIiIi . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   ii1I1IIIi . append ( OoOOo0OOoO )
   o0OOOOooo . append ( o00oo0 )
   ii1I1IIii11 = list ( zip ( ii1I1IIIi , o0OOOOooo ) )
   if 67 - 67: i1iIIIiI1I + oo0Ooo0 / oo0ooO0oOOOOo . OooooO0oOO + oOo0
 ooOoOo0 = sorted ( ii1I1IIii11 )
 if 2 - 2: i1iIIIiI1I % ooO0oo0oO0 * ooO0oo0oO0 . oo0ooO0oOOOOo / i1iIIIiI1I
 for iII1i1 , url in ooOoOo0 :
  O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   ooo00Ooo = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
   if iII1i1 . lower ( ) == "all" :
    ooo00Ooo = ooo00Ooo . replace ( '.' , ' ' )
    oO0o0OOOO ( ooo00Ooo , url , 2 , iconimage , iconimage , '' )
   elif iII1i1 . lower ( ) in ooo00Ooo . lower ( ) :
    ooo00Ooo = ooo00Ooo . replace ( '.' , ' ' )
    oO0o0OOOO ( ooo00Ooo , url , 2 , iconimage , iconimage , '' )
    if 93 - 93: i11iIiiIii - i1IIi11111i * i11iiII * oo0Ooo0 % oooO0oo0oOOOO + i111I
 try :
  oO0 = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( O0oOOoooOO0O )
  I1i1i1 = str ( oO0 )
  OoO0O00O0oo0O = re . compile ( 'href="(.+?)"' ) . findall ( I1i1i1 ) [ 1 ]
  url = OoO0O00O0oo0O + "|SPLIT|" + iII1i1
  Oo0oOOo ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 36 - 36: oOo0 + oooO0oo0oOOOO - i1IIiiiii - oooO0oo0oOOOO % oo0Ooo0 . OooooO0oOO
def ooo ( name , url , iconimage ) :
 if 36 - 36: i111I . oo
 url , iII1i1 = url . split ( "|SPLIT|" )
 if 56 - 56: I11i1i11i1I . i11iiII . i1IIi11111i
 O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 for Ii1iIiII1ii1 in oO0 :
  ooo00Ooo = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
  if iII1i1 . lower ( ) == "all" :
   ooo00Ooo = ooo00Ooo . replace ( '.' , ' ' )
   oO0o0OOOO ( ooo00Ooo , url , 2 , iconimage , iconimage , '' )
  elif iII1i1 . lower ( ) in ooo00Ooo . lower ( ) :
   ooo00Ooo = ooo00Ooo . replace ( '.' , ' ' )
   oO0o0OOOO ( ooo00Ooo , url , 2 , iconimage , iconimage , '' )
   if 39 - 39: oooO0oo0oOOOO + OooOoO0Oo
 try :
  oO0 = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( O0oOOoooOO0O )
  I1i1i1 = str ( oO0 )
  OoO0O00O0oo0O = re . compile ( 'href="(.+?)"' ) . findall ( I1i1i1 ) [ 1 ]
  url = OoO0O00O0oo0O + "|SPLIT|" + iII1i1
  Oo0oOOo ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 91 - 91: i111I - ooO0oo0oO0 + OOO0O / oo . OOO0O + oooO0oo0oOOOO
def iIiii1iI1 ( url ) :
 if 33 - 33: OoO000 % ooO0oo0oO0 * i1IIi11111i
 try :
  o00o0 , url = url . split ( '|SPLIT|' )
 except : o00o0 , url , O0Oo000ooO00 , i1OOO = url . split ( '|SPLIT|' )
 if 50 - 50: I11i1i11i1I / I11i1i11i1I % i11iiII . i11iiII
 if o00o0 == 'true' :
  I1i1i1 = ''
  O0O0Oo00 = xbmc . Keyboard ( I1i1i1 , 'Enter Search Term' )
  O0O0Oo00 . doModal ( )
  if O0O0Oo00 . isConfirmed ( ) :
   I1i1i1 = O0O0Oo00 . getText ( )
   if len ( I1i1i1 ) > 1 :
    iII1i1 = I1i1i1 . lower ( )
   else : quit ( )
   if 80 - 80: OooooO0oOO + oOo0 / oo0Ooo0
  oOOO00O0O0OOo = [ ]
  OOo00O = [ ]
  OooOOOO = [ ]
  ii1I1IIii11 = [ ]
  if 45 - 45: i11iiII % i1IIi11111i - i11iIiiIii
  I1IiiI . create ( Oo0Ooo , "[COLOR white]We are searching for " + iII1i1 + ".[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
  I1IiiI . update ( 0 )
  if 11 - 11: ooO0oo0oO0 * ooO0oo0oO0 * i1IIi11111i
  Iii1IIII11I = 1
  iII1ii1 = 0
  O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '<search>(.+?)</search>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  I1i1iiiI1 = len ( oO0 )
  for Ii1iIiII1ii1 in oO0 :
   iIIi = 100 * int ( Iii1IIII11I ) / int ( I1i1iiiI1 )
   I1IiiI . update ( iIIi , '' , '[COLOR blue]Searching list ' + str ( Iii1IIII11I ) + ' of ' + str ( I1i1iiiI1 ) + '[/COLOR]' )
   oO0o00oo0 = OOOO0OOoO0O0 ( Ii1iIiII1ii1 )
   oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( oO0o00oo0 )
   for ii1IIII in oO0 :
    ooo00Ooo = re . compile ( 'title="(.+?)"' ) . findall ( ii1IIII ) [ 0 ]
    url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( ii1IIII ) [ 0 ]
    iI1iIIiiii = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( ii1IIII ) [ 0 ]
    iI1iIIiiii = "https://pic.rutube.ru" + iI1iIIiiii + "size=l"
    ooo00Ooo = ooo00Ooo . replace ( '.' , ' ' )
    if iII1i1 in ooo00Ooo . lower ( ) :
     iII1ii1 = iII1ii1 + 1
     oOOO00O0O0OOo . append ( ooo00Ooo )
     OOo00O . append ( url )
     OooOOOO . append ( iI1iIIiiii )
     ii1I1IIii11 = list ( zip ( oOOO00O0O0OOo , OOo00O , OooOOOO ) )
     if 59 - 59: OooooO0oOO * oo0Ooo0 % i1111
   Iii1IIII11I = Iii1IIII11I + 1
   if 62 - 62: ooO0oo0oO0
  ooOoOo0 = sorted ( ii1I1IIii11 )
  oO0o0OOOO ( '[B][COLOR dodgerblue]We found ' + str ( iII1ii1 ) + ' matches for ' + iII1i1 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  oO0o0OOOO ( '#######################################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  for i1OOO , url , iI1iIIiiii in ooOoOo0 :
   oO0o0OOOO ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 2 , iI1iIIiiii , iI1iIIiiii , '' )
   if 12 - 12: oOo0 / oo0ooO0oOOOOo
   if 42 - 42: I11i1i11i1I
   if 19 - 19: OooooO0oOO % i11iiII * ooO0oo0oO0 + i1IIi11111i
 else :
  if 46 - 46: I11i1i11i1I
  oOOO00O0O0OOo = [ ]
  OOo00O = [ ]
  OooOOOO = [ ]
  ii1I1IIii11 = [ ]
  if 1 - 1: i1iIIIiI1I
  I1IiiI . create ( Oo0Ooo , "[COLOR white]We are searching for " + i1OOO + ".[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
  I1IiiI . update ( 0 )
  if 97 - 97: oOo0 + i1iIIIiI1I + oooO0oo0oOOOO + i11iIiiIii
  Iii1IIII11I = 1
  iII1ii1 = 0
  O0oOOoooOO0O = OOOO0OOoO0O0 ( O0Oo000ooO00 )
  OooOo0ooo = re . compile ( '<title>' + re . escape ( i1OOO ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0oOOoooOO0O ) [ 0 ]
  i1iIIIi1i = re . compile ( '<term>(.+?)</term>' ) . findall ( OooOo0ooo )
  oO0o00oo0 = OOOO0OOoO0O0 ( url )
  oOoO0 = re . compile ( '<search>(.+?)</search>' , re . DOTALL ) . findall ( oO0o00oo0 )
  I1i1iiiI1 = len ( oOoO0 )
  for Ii1iIiII1ii1 in oOoO0 :
   iIIi = 100 * int ( Iii1IIII11I ) / int ( I1i1iiiI1 )
   I1IiiI . update ( iIIi , '' , '[COLOR blue]Searching list ' + str ( Iii1IIII11I ) + ' of ' + str ( I1i1iiiI1 ) + '[/COLOR]' )
   oO0o00oo0 = OOOO0OOoO0O0 ( Ii1iIiII1ii1 )
   oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( oO0o00oo0 )
   for ii1IIII in oO0 :
    ooo00Ooo = re . compile ( 'title="(.+?)"' ) . findall ( ii1IIII ) [ 0 ]
    url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( ii1IIII ) [ 0 ]
    iI1iIIiiii = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( ii1IIII ) [ 0 ]
    iI1iIIiiii = "https://pic.rutube.ru" + iI1iIIiiii + "size=l"
    ooo00Ooo = ooo00Ooo . replace ( '.' , ' ' )
    for iII1i1 in i1iIIIi1i :
     if iII1i1 . lower ( ) in ooo00Ooo . lower ( ) :
      iII1ii1 = iII1ii1 + 1
      oOOO00O0O0OOo . append ( ooo00Ooo )
      OOo00O . append ( url )
      OooOOOO . append ( iI1iIIiiii )
      ii1I1IIii11 = list ( zip ( oOOO00O0O0OOo , OOo00O , OooOOOO ) )
      if 77 - 77: ooO0oo0oO0 . i1iIIIiI1I % i1iIIIiI1I + i11iIiiIii
   Iii1IIII11I = Iii1IIII11I + 1
   if 72 - 72: ooO0oo0oO0 * i1IIiiiii % iiIIiIiIi / oo
  ooOoOo0 = sorted ( ii1I1IIii11 )
  oO0o0OOOO ( '[B][COLOR dodgerblue]' + i1OOO + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  oO0o0OOOO ( '#######################################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  for i1OOO , url , iI1iIIiiii in ooOoOo0 :
   oO0o0OOOO ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 2 , iI1iIIiiii , iI1iIIiiii , '' )
   if 35 - 35: iiIIiIiIi + II1Ii1iI1i % i11iiII % oo0Ooo0 + OooooO0oOO
def iiiI ( name , url , iconimage ) :
 if 29 - 29: oo0Ooo0 / i1111 / iiIIiIiIi * oOo0
 oo0OooOOo0 , I1II1III11iii = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 oo0OooOOo0 += urllib . unquote_plus ( I1II1III11iii )
 url = regex . resolve ( oo0OooOOo0 )
 if 10 - 10: OooOoO0Oo % OoO000 * OoO000 . oo0Ooo0 / i1IIiiiii % oOo0
 i111iIi1i1II1 ( name , url , iconimage )
 if 49 - 49: oo / OooooO0oOO + oooO0oo0oOOOO * oo0ooO0oOOOOo
def I1ii11 ( ) :
 if 74 - 74: I11i1i11i1I - oo0ooO0oOOOOo . II1Ii1iI1i
 oO0o0OOOO ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 Oo0oOOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 Oo0oOOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 43 - 43: i1iIIIiI1I / i1IIi11111i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 58 - 58: i1IIi11111i + i11iIiiIii % i1IIiiiii . OOO0O
def Ii1i1iI ( ) :
 if 16 - 16: oOo0 / I11i1i11i1I / i111I * i1IIi11111i + II1Ii1iI1i % oOo0
 Oo0oOOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 71 - 71: OOO0O
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 14 - 14: i11iIiiIii % oOo0
def OooO0oo ( ) :
 if 89 - 89: i1IIiiiii
 Oo0oOOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 76 - 76: iiIIiIiIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 15 - 15: oOo0 . oo0Ooo0 + i111I - oo
def Oo0 ( ) :
 if 59 - 59: i1IIi11111i * i1111 . oooO0oo0oOOOO
 Iii1IIII11I = 0
 O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 for Ii1iIiII1ii1 in oO0 :
  Iii1IIII11I = Iii1IIII11I + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1iI11i1ii11 = Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( Iii1IIII11I ) + '[/COLOR]' , i1iI11i1ii11 , 12 , iiiii , O0O0OO0O0O0 )
  if 56 - 56: i1IIiiiii - i1iIIIiI1I % i1IIi11111i - oo0ooO0oOOOOo
 O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 for Ii1iIiII1ii1 in oO0 :
  Iii1IIII11I = Iii1IIII11I + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1iI11i1ii11 = Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( Iii1IIII11I ) + '[/COLOR]' , i1iI11i1ii11 , 12 , iiiii , O0O0OO0O0O0 )
  if 51 - 51: oooO0oo0oOOOO / iiIIiIiIi * ooO0oo0oO0 + i11iiII + oo0ooO0oOOOOo
 O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 for Ii1iIiII1ii1 in oO0 :
  Iii1IIII11I = Iii1IIII11I + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1iI11i1ii11 = Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( Iii1IIII11I ) + '[/COLOR]' , i1iI11i1ii11 , 12 , iiiii , O0O0OO0O0O0 )
  if 98 - 98: ooO0oo0oO0 * i11iiII * oOo0 + iiIIiIiIi % i11iIiiIii % oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 27 - 27: oooO0oo0oOOOO
def OOO0oOOoo ( url ) :
 if 52 - 52: oo0ooO0oOOOOo % I11i1i11i1I
 O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 if 64 - 64: oooO0oo0oOOOO % oo0Ooo0 % oooO0oo0oOOOO * oo . OooooO0oOO + i1IIi11111i
 for Ii1iIiII1ii1 in oO0 :
  i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  iI1iIIiiii = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , iI1iIIiiii , O0O0OO0O0O0 )
  if 75 - 75: oo0Ooo0 . i111I % oo0ooO0oOOOOo * oo0Ooo0 % i111I
 try :
  I11i1 = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( O0oOOoooOO0O ) [ 0 ]
  Oo0oOOo ( '[COLOR yellow]Next Page -->[/COLOR]' , I11i1 , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 28 - 28: oo0Ooo0
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 58 - 58: OOO0O
def iIiiI1iI ( ) :
 if 5 - 5: OOO0O / i111I + OoO000 * OooOoO0Oo - oo % i1IIi11111i
 O0oOOoooOO0O = OOOO0OOoO0O0 ( 'http://arenavision.in/schedule' )
 oO0 = re . compile ( '<tr><td class="auto-style3"(.+?)</tr>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 if 42 - 42: oooO0oo0oOOOO / oo0ooO0oOOOOo + i111I * iiIIiIiIi % iiIIiIiIi
 for Ii1iIiII1ii1 in oO0 :
  try :
   OO0Oooo0oOO0O = re . compile ( '190px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   time = re . compile ( '182px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   i1iIi = re . compile ( '188px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   IIIII = re . compile ( '685px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   o0ooOoO000oO = re . compile ( '317px">(.+?) ' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   i1iI11i1ii11 = IIIII + '|SPLIT|' + o0ooOoO000oO
   oO0o0OOOO ( '[COLOR blue][B]' + IIIII + '[/B][/COLOR] - [COLOR white]' + OO0Oooo0oOO0O + ' | [COLOR orangered][B]' + time + '[/B][/COLOR] | ' + i1iIi + '[/COLOR]' , i1iI11i1ii11 , 97 , iiiii , O0O0OO0O0O0 )
  except : pass
 OOO = oo0OOo0 ( )
 if 85 - 85: oo0ooO0oOOOOo . OOO0O / iiIIiIiIi . oooO0oo0oOOOO % OooOoO0Oo
 if OOO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 90 - 90: I11i1i11i1I % oooO0oo0oOOOO * ooO0oo0oO0 . i1iIIIiI1I
def I1iii11 ( name , url , iconimage ) :
 if 74 - 74: oooO0oo0oOOOO / II1Ii1iI1i
 name , url = url . split ( '|SPLIT|' )
 if 78 - 78: i111I . oo + iiIIiIiIi - II1Ii1iI1i
 ii1 = "null"
 O0 = "null"
 if 33 - 33: II1Ii1iI1i
 if "-" in url :
  ii1 , O0 = url . split ( '-' )
  if 36 - 36: i1111 % i11iIiiIii * OOO0O + oo0Ooo0
  iii11i1IIII = O00ooooo00 . select ( "[COLOR red]Please select an stream[/COLOR]" , [ '[COLOR white]Link 1[/COLOR]' , '[COLOR white]Link 2[/COLOR]' ] )
  if 26 - 26: oooO0oo0oOOOO . oo * OooOoO0Oo . i1IIi11111i % i11iIiiIii
  if iii11i1IIII == 0 : url = 'http://arenavision.in/av' + ii1
  elif iii11i1IIII == 1 : url = 'http://arenavision.in/av' + O0
  else : quit ( )
  if 47 - 47: i1iIIIiI1I - I11i1i11i1I
 else : url = 'http://arenavision.in/av' + url
 if 3 - 3: II1Ii1iI1i / i1111 / i11iIiiIii * II1Ii1iI1i - i1111
 Ii ( name , url , iconimage )
 if 14 - 14: oo0ooO0oOOOOo * OooooO0oOO
 if 81 - 81: i1IIiiiii * oo0ooO0oOOOOo + OooOoO0Oo + I11i1i11i1I - i111I
def Ii ( name , url , iconimage ) :
 if 32 - 32: i1IIiiiii * oooO0oo0oOOOO
 try :
  O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( 'this.loadPlayer(.+?),' , re . DOTALL ) . findall ( O0oOOoooOO0O ) [ 0 ]
  url = oO0 . replace ( '(' , '' ) . replace ( ')' , '' ) . replace ( '"' , '' ) . replace ( ' ' , '' )
  if 100 - 100: iiIIiIiIi % ooO0oo0oO0 * i1111 - i1iIIIiI1I
  O0Oo000ooO00 = 'plugin://program.plexus/?url=acestream://' + str ( url ) + '&mode=1&name=acestream+' + str ( name )
  if 92 - 92: iiIIiIiIi
  i111iIi1i1II1 ( name , O0Oo000ooO00 , iconimage )
 except : quit ( )
 if 22 - 22: I11i1i11i1I % i1iIIIiI1I * i11iiII / oOo0 % i11iIiiIii * oo0Ooo0
def Oo00OoOo ( url ) :
 if 24 - 24: i11iIiiIii - OooOoO0Oo
 O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 for Ii1iIiII1ii1 in oO0 :
  try :
   i1OOO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except :
   i1OOO = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 21 - 21: oo0Ooo0
def OoO00 ( url ) :
 if 85 - 85: I11i1i11i1I * I11i1i11i1I * i1IIi11111i . i111I . i1IIiiiii * iiIIiIiIi
 O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 o000oOoo0o000 = 0
 for Ii1iIiII1ii1 in oO0 :
  try :
   i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : o000oOoo0o000 = 1
  if 40 - 40: i11iIiiIii * OooOoO0Oo - II1Ii1iI1i * OooOoO0Oo - oo0Ooo0 . II1Ii1iI1i
  if o000oOoo0o000 == 0 :
   Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , iI1iIIiiii , O0O0OO0O0O0 )
  o000oOoo0o000 = 0
  if 99 - 99: oooO0oo0oOOOO * oo0Ooo0
 try :
  I11i1 = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( O0oOOoooOO0O ) [ 0 ]
  Oo0oOOo ( '[COLOR yellow]Next Page -->[/COLOR]' , I11i1 , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 64 - 64: i1111 + oooO0oo0oOOOO / ooO0oo0oO0 / I11i1i11i1I . iiIIiIiIi % OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 50 - 50: ooO0oo0oO0 - OoO000 + oOo0
def o0 ( url ) :
 if 30 - 30: oooO0oo0oOOOO * i111I
 I1iIIIi1 = datetime . date . today ( )
 Iii = datetime . datetime . strftime ( I1iIIIi1 , '%A %d %B %Y' )
 if 19 - 19: oo0Ooo0 % i1111 / i11iIiiIii / i1iIIIiI1I - i111I
 oO0o0OOOO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( Iii ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 37 - 37: oOo0 / i111I - i11iIiiIii
 O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 o000oOoo0o000 = 0
 Iii1IIII11I = 0
 for Ii1iIiII1ii1 in oO0 :
  try :
   ooo00Ooo = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    i1iIiIi1I = re . compile ( '<p>(.+?)</p>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : i1iIiIi1I = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<img src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : o000oOoo0o000 = 1
  if 45 - 45: II1Ii1iI1i + i1111
  if o000oOoo0o000 == 0 :
   if 'vs' in ooo00Ooo :
    i1OOO = '[COLOR dodgerblue]' + ooo00Ooo + ' - ' + '[/COLOR][COLOR blue]' + i1iIiIi1I + '[/COLOR]'
    Iii1IIII11I = Iii1IIII11I + 1
    oO0o0OOOO ( i1OOO , url , 206 , iI1iIIiiii , O0O0OO0O0O0 , '' )
  o000oOoo0o000 = 0
  if 7 - 7: oooO0oo0oOOOO % oo0ooO0oOOOOo + i11iiII * i1iIIIiI1I - i1iIIIiI1I
 if Iii1IIII11I == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 42 - 42: OOO0O * OOO0O * OooOoO0Oo . oo0Ooo0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 51 - 51: oOo0 % ooO0oo0oO0 - i111I % iiIIiIiIi * ooO0oo0oO0 % oo
def oO0o00oOOooO0 ( name , url , iconimage ) :
 if 79 - 79: oo - ooO0oo0oO0 + i1IIiiiii - OooOoO0Oo
 O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
 OoO = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( O0oOOoooOO0O ) [ 0 ]
 if 35 - 35: OOO0O + i11iIiiIii - i1111
 if not "http" in OoO :
  OoO = OoO . replace ( "//" , "" )
  url = "http://" + OoO
 else :
  url = OoO
  if 15 - 15: i11iIiiIii % i1IIi11111i * oo0Ooo0 / OooOoO0Oo
 oooO0o0o0O0 = url
 if 27 - 27: i111I - i1iIIIiI1I / oo0Ooo0
 OOooOo00oo0 = OOOO0OOoO0O0 ( url )
 OoO = re . compile ( "atob(.+?)," ) . findall ( OOooOo00oo0 ) [ 0 ]
 OoO = OoO . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( OoO )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + oooO0o0o0O0 + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 i111iIi1i1II1 ( name , url , iconimage )
 if 84 - 84: OooOoO0Oo + oo0Ooo0
def IIiiIIi1 ( url ) :
 if 59 - 59: OoO000 . oOo0 % i1111
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 39 - 39: i11iiII
  if '<display>eWVz</display>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   url = base64 . b64decode ( url )
   iI1iIIiiii = base64 . b64decode ( iI1iIIiiii )
   OooOoooOo = base64 . b64decode ( OooOoooOo )
   Oo0oOOo ( i1OOO , url , 220 , iI1iIIiiii , OooOoooOo , '' )
   if 97 - 97: oOo0 - oo / i1IIiiiii . i11iIiiIii % OooooO0oOO * OooooO0oOO
def ii1IIIIiI11 ( url ) :
 if 40 - 40: oo0ooO0oOOOOo
 O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 if 67 - 67: OooooO0oOO + i1111 - oooO0oo0oOOOO . OooooO0oOO * i1111 * oo0Ooo0
 for Ii1iIiII1ii1 in oO0 :
  i1OOO = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   o00 = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : o00 = "SD"
  o00 = '[COLOR yellow]' + o00 + '[/COLOR]'
  iI1iIIiiii = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  i1OOO = i1OOO . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 81 - 81: oOo0 - oo0Ooo0 % iiIIiIiIi - oo / I11i1i11i1I
  oO0o0OOOO ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR] - ' + o00 , url , 212 , iI1iIIiiii , O0O0OO0O0O0 , '' )
  if 4 - 4: i111I - II1Ii1iI1i % i1IIiiiii - oOo0 * oo0ooO0oOOOOo
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( O0oOOoooOO0O ) [ 0 ]
  OoO0O00O0oo0O = 'http://www.fmovies.se/' + url
  Oo0oOOo ( "Next Page -->" , OoO0O00O0oo0O , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 85 - 85: i111I * ooO0oo0oO0 . i1iIIIiI1I / i111I % i1IIi11111i % oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 36 - 36: i1IIiiiii / i1111 / OoO000 / OoO000 + i11iiII
def oO0Ooo0ooOO0 ( url ) :
 if 46 - 46: i1IIiiiii % OOO0O
 O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 if 64 - 64: i11iIiiIii - i1111
 if 77 - 77: OOO0O % i1IIiiiii
def II1IiiIii ( url ) :
 if 84 - 84: OooooO0oOO % II1Ii1iI1i
 if "iptvembed" in url :
  O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = Ii1iIiII1ii1
   if 70 - 70: I11i1i11i1I . i111I - i1iIIIiI1I
 if "sourcetv" in url :
  O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = Ii1iIiII1ii1
   if 30 - 30: i11iiII % i1IIi11111i
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 ii1IiIIi1i = [ ]
 for oOOo0OOOOo0Oo , OOo0o , url in O0Oo00 :
  oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : url }
  ii1IiIIi1i . append ( oooii1iiIi1 )
 list = [ ]
 for o0ooOoO000oO in ii1IiIIi1i :
  oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
  O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
  for i111iiI1ii , IIiii in O0Oo00 :
   oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
  list . append ( oooii1iiIi1 )
  if 30 - 30: oo0Ooo0 / i1IIiiiii . OoO000 . i111I - I11i1i11i1I
 Ii1iI1iI11I1 = 0
 for o0ooOoO000oO in list :
  Ii1iI1iI11I1 = 1
  i1OOO = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
  url = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   oO0o0OOOO ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   Oo0oOOo ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 98 - 98: OooOoO0Oo
 if Ii1iI1iI11I1 == 0 :
  oO0o0OOOO ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 12 - 12: i1111 . oo0Ooo0 / oOo0
def O00OO0oO ( url ) :
 if 25 - 25: I11i1i11i1I % i11iiII * iiIIiIiIi
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = url
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 6 - 6: i1iIIIiI1I . OoO000 * OOO0O . II1Ii1iI1i
  i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
  if len ( i1iIIIi1i ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + iI1iIIiiii
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 20 , iI1iIIiiii , iI1iIIiiii )
   if 98 - 98: II1Ii1iI1i
  elif len ( i1iIIIi1i ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = O0Oo000ooO00 + "!" + i1OOO + "!" + iI1iIIiiii
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 22 , iI1iIIiiii , iI1iIIiiii )
   if 65 - 65: OOO0O / oo % OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 45 - 45: OOO0O
def oOooOO ( url ) :
 if 31 - 31: oOo0 / I11i1i11i1I * II1Ii1iI1i . OOO0O
 I1iIIIi1 = datetime . date . today ( )
 Iii = datetime . datetime . strftime ( I1iIIIi1 , '%A %d %B %Y' )
 if 57 - 57: oOo0 + ooO0oo0oO0 % II1Ii1iI1i % i1IIi11111i
 oO0o0OOOO ( '[COLOR dodgerblue]EVENTS FOR ' + str ( Iii ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 83 - 83: oo0ooO0oOOOOo / i11iIiiIii % ooO0oo0oO0 . oo0Ooo0 % OooooO0oOO . i111I
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = url
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 94 - 94: i1IIiiiii + ooO0oo0oO0 % oo
  i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
  if len ( i1iIIIi1i ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + iI1iIIiiii
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 20 , iI1iIIiiii , iI1iIIiiii )
   if 93 - 93: i1IIiiiii - oOo0 + ooO0oo0oO0 * oo0ooO0oOOOOo + OooOoO0Oo . i1iIIIiI1I
  elif len ( i1iIIIi1i ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = O0Oo000ooO00 + "!" + i1OOO + "!" + iI1iIIiiii
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 22 , iI1iIIiiii , iI1iIIiiii )
   if 49 - 49: i111I * oo0Ooo0 - I11i1i11i1I . OooooO0oOO
def O000o0 ( ) :
 if 98 - 98: oo . oo0Ooo0 % i1111
 I1iIIIi1 = datetime . date . today ( )
 Iii = datetime . datetime . strftime ( I1iIIIi1 , '%A %d %B %Y' )
 if 71 - 71: OooOoO0Oo % II1Ii1iI1i - i1111 - oOo0 + oOo0 * iiIIiIiIi
 oO0o0OOOO ( '[COLOR dodgerblue]EVENTS FOR ' + str ( Iii ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 51 - 51: ooO0oo0oO0 / OOO0O + oOo0 - oo0Ooo0 + i1iIIIiI1I
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 oO0 = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( o00OO00OoO )
 I1i1i1 = str ( oO0 )
 oOoO0 = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( I1i1i1 )
 for Ii1iIiII1ii1 in oOoO0 :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in Ii1iIiII1ii1 :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    ooo00Ooo = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( 'src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     IIii1i1iii1 = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
     IIii1i1iii1 = oo0o0000Oo0 ( IIii1i1iii1 )
    except : IIii1i1iii1 = "null"
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + ooo00Ooo + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    i1OOO = o0O00oOoo ( i1OOO )
    i1iI11i1ii11 = ooo00Ooo + "!" + IIii1i1iii1 . lower ( ) + "!" + iI1iIIiiii
    Oo0oOOo ( i1OOO , i1iI11i1ii11 , 20 , iI1iIIiiii , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    ooo00Ooo = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     IIii1i1iii1 = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : IIii1i1iii1 = "null"
    iI1iIIiiii = re . compile ( 'src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + ooo00Ooo + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    i1OOO = o0O00oOoo ( i1OOO )
    i1iI11i1ii11 = ooo00Ooo + "!" + IIii1i1iii1 . lower ( ) + "!" + iI1iIIiiii
    Oo0oOOo ( i1OOO , i1iI11i1ii11 , 20 , iI1iIIiiii , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 63 - 63: i1iIIIiI1I * oo0Ooo0 * i1IIiiiii - OooooO0oOO - i1IIiiiii
def o0oo ( name , url , iconimage ) :
 if 52 - 52: i11iiII + i11iiII . i1111
 try :
  url , IiiIIIII1iii , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 7 - 7: oo0ooO0oOOOOo + II1Ii1iI1i . i1IIi11111i / I11i1i11i1I
 I111i1I1 = [ ]
 if 62 - 62: oOo0 * OooOoO0Oo / I11i1i11i1I * oo0ooO0oOOOOo
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 OooOo0ooo = re . compile ( '<title>' + re . escape ( IiiIIIII1iii ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( OooOo0ooo ) [ 0 ]
 i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( OooOo0ooo )
 for o00oo0 in i1iIIIi1i :
  I111i1I1 . append ( o00oo0 )
  if 29 - 29: I11i1i11i1I % oo % OoO000 . oo0ooO0oOOOOo / i111I * iiIIiIiIi
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 54 - 54: oooO0oo0oOOOO
 OOoO000O00oO = 0
 if 34 - 34: oooO0oo0oOOOO
 oOOO00O0O0OOo = [ ]
 OOo00O = [ ]
 OooOOOo0 = [ ]
 I1IiiI . update ( 0 )
 O0O0o0o0o = 0
 if 9 - 9: I11i1i11i1I + OOO0O - ooO0oo0oO0 - i1IIiiiii + oo0ooO0oOOOOo
 if oO000OoOoo00o == "true" :
  O0O0o0o0o = 1
  O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   if OOoO000O00oO < 100 :
    I1IiiI . update ( OOoO000O00oO )
    OOoO000O00oO = OOoO000O00oO + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ii1IiIIi1i = [ ]
   for oOOo0OOOOo0Oo , OOo0o , url in O0Oo00 :
    oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : url }
    ii1IiIIi1i . append ( oooii1iiIi1 )
   o000O0OOoo = [ ]
   for o0ooOoO000oO in ii1IiIIi1i :
    oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
    O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
    for i111iiI1ii , IIiii in O0Oo00 :
     oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
    o000O0OOoo . append ( oooii1iiIi1 )
    if 60 - 60: i1IIi11111i * OooOoO0Oo % oo + OooooO0oOO
   for o0ooOoO000oO in o000O0OOoo :
    name = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
    url = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOO00O0O0OOo . append ( name )
    OOo00O . append ( url )
    if "hd" in name . lower ( ) :
     OooOOOo0 . append ( "1" )
    else :
     OooOOOo0 . append ( "0" )
    ii1I1IIii11 = list ( zip ( OooOOOo0 , oOOO00O0O0OOo , OOo00O ) )
    if 52 - 52: II1Ii1iI1i
 if iiiI11 == "true" :
  O0O0o0o0o = 1
  O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   if OOoO000O00oO < 100 :
    I1IiiI . update ( OOoO000O00oO )
    OOoO000O00oO = OOoO000O00oO + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ii1IiIIi1i = [ ]
   for oOOo0OOOOo0Oo , OOo0o , url in O0Oo00 :
    oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : url }
    ii1IiIIi1i . append ( oooii1iiIi1 )
   o000O0OOoo = [ ]
   for o0ooOoO000oO in ii1IiIIi1i :
    oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
    O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
    for i111iiI1ii , IIiii in O0Oo00 :
     oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
    o000O0OOoo . append ( oooii1iiIi1 )
    if 84 - 84: i1IIiiiii / OoO000
   for o0ooOoO000oO in o000O0OOoo :
    name = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
    url = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOO00O0O0OOo . append ( name )
    OOo00O . append ( url )
    if "hd" in name . lower ( ) :
     OooOOOo0 . append ( "1" )
    else :
     OooOOOo0 . append ( "0" )
    ii1I1IIii11 = list ( zip ( OooOOOo0 , oOOO00O0O0OOo , OOo00O ) )
    if 86 - 86: OOO0O * i1111 - oooO0oo0oOOOO . OOO0O % ooO0oo0oO0 / oOo0
 if OOooO == "true" :
  O0O0o0o0o = 1
  O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   if OOoO000O00oO < 100 :
    I1IiiI . update ( OOoO000O00oO )
    OOoO000O00oO = OOoO000O00oO + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ii1IiIIi1i = [ ]
   for oOOo0OOOOo0Oo , OOo0o , url in O0Oo00 :
    oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : url }
    ii1IiIIi1i . append ( oooii1iiIi1 )
   o000O0OOoo = [ ]
   for o0ooOoO000oO in ii1IiIIi1i :
    oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
    O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
    for i111iiI1ii , IIiii in O0Oo00 :
     oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
    o000O0OOoo . append ( oooii1iiIi1 )
    if 11 - 11: i1IIi11111i * OooooO0oOO + i11iiII / i11iiII
   for o0ooOoO000oO in o000O0OOoo :
    name = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
    url = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOO00O0O0OOo . append ( name )
    OOo00O . append ( url )
    if "hd" in name . lower ( ) :
     OooOOOo0 . append ( "1" )
    else :
     OooOOOo0 . append ( "0" )
    ii1I1IIii11 = list ( zip ( OooOOOo0 , oOOO00O0O0OOo , OOo00O ) )
    if 37 - 37: i11iIiiIii + II1Ii1iI1i
 if O0O0o0o0o == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 23 - 23: i1iIIIiI1I + oo0Ooo0 . OOO0O * i1IIi11111i + i11iiII
 ooOoOo0 = sorted ( ii1I1IIii11 , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 I1iIi1iiiIiI = sorted ( I111i1I1 )
 if 41 - 41: i11iiII * iiIIiIiIi - i1IIiiiii + I11i1i11i1I
 iI1Iii = 0
 if 23 - 23: i1111 % oo0ooO0oOOOOo + oo0ooO0oOOOOo + i1iIIIiI1I - i1iIIIiI1I
 I1IiiI . update ( 100 )
 if 62 - 62: oo0ooO0oOOOOo
 oO0o0OOOO ( '[COLOR dodgerblue][B]LINKS FOR ' + IiiIIIII1iii . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 45 - 45: oOo0 * iiIIiIiIi
 if 74 - 74: II1Ii1iI1i + oooO0oo0oOOOO + I11i1i11i1I
 for IIii1i1iii1 in I1iIi1iiiIiI :
  if 5 - 5: I11i1i11i1I * OOO0O
  oO0o0OOOO ( '[COLOR orangered][B]' + IIii1i1iii1 . upper ( ) + ' LINKS[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 46 - 46: iiIIiIiIi
  I1i1i1 = IIii1i1iii1 . split ( ' ' )
  if 33 - 33: i1iIIIiI1I - i1111 * i111I - I11i1i11i1I - oOo0
  for O0OO0O , name , url in ooOoOo0 :
   if 49 - 49: ooO0oo0oO0 - oooO0oo0oOOOO . II1Ii1iI1i - i111I
   Ii1 = 0
   if 73 - 73: II1Ii1iI1i + i1iIIIiI1I . i11iIiiIii
   for IIi in I1i1i1 :
    if 58 - 58: i1111
    if not IIi . lower ( ) in name . lower ( ) :
     Ii1 = 1
     if 19 - 19: i11iiII - oo0Ooo0 . i1111 - oo . OoO000 * i111I
   if Ii1 == 0 :
    iI1Iii = iI1Iii + 1
    if "hd" in name . lower ( ) :
     oO0o0OOOO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iI1Iii ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO0o0OOOO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iI1Iii ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 84 - 84: i1iIIIiI1I % oOo0 / oo0Ooo0 / i1IIi11111i
  if iI1Iii == 0 :
   oO0o0OOOO ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 46 - 46: I11i1i11i1I / II1Ii1iI1i . oo0ooO0oOOOOo * oo
  I1i1i1 = ""
  if 15 - 15: OOO0O
 I1IiiI . close ( )
 if 62 - 62: i1IIiiiii
def ooO000O ( name , url , iconimage ) :
 if 53 - 53: oo0ooO0oOOOOo . i1iIIIiI1I / i1IIiiiii
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 39 - 39: i1IIiiiii % oooO0oo0oOOOO % OOO0O . II1Ii1iI1i
 OOoO000O00oO = 0
 try :
  IiiIIIII1iii , IIii1i1iii1 , iconimage = url . split ( '!' )
 except :
  try :
   IIii1i1iii1 , iconimage = url . split ( '!' )
   IiiIIIII1iii = IIii1i1iii1
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 86 - 86: oo * i111I
 OooO0oOo = 0
 if 66 - 66: oo * I11i1i11i1I
 if "all " in name . lower ( ) :
  IIii1i1iii1 = IIii1i1iii1 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  IiiIIIII1iii = IiiIIIII1iii . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  OooO0oOo = 1
  if 28 - 28: oo % OOO0O % i11iiII + i1IIi11111i / i1IIi11111i
 oOOO00O0O0OOo = [ ]
 OOo00O = [ ]
 OooOOOo0 = [ ]
 I1IiiI . update ( 0 )
 O0O0o0o0o = 0
 if oO000OoOoo00o == "true" :
  O0O0o0o0o = 1
  O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   if OOoO000O00oO < 100 :
    I1IiiI . update ( OOoO000O00oO )
    OOoO000O00oO = OOoO000O00oO + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ii1IiIIi1i = [ ]
   for oOOo0OOOOo0Oo , OOo0o , url in O0Oo00 :
    oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : url }
    ii1IiIIi1i . append ( oooii1iiIi1 )
   o000O0OOoo = [ ]
   for o0ooOoO000oO in ii1IiIIi1i :
    oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
    O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
    for i111iiI1ii , IIiii in O0Oo00 :
     oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
    o000O0OOoo . append ( oooii1iiIi1 )
    if 71 - 71: oOo0 * oo % i111I % oo / i1IIi11111i
   for o0ooOoO000oO in o000O0OOoo :
    name = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
    url = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOO00O0O0OOo . append ( name )
    OOo00O . append ( url )
    if "hd" in name . lower ( ) :
     OooOOOo0 . append ( "1" )
    else :
     OooOOOo0 . append ( "0" )
    ii1I1IIii11 = list ( zip ( OooOOOo0 , oOOO00O0O0OOo , OOo00O ) )
    if 56 - 56: i111I % i11iIiiIii * ooO0oo0oO0 . oo * oooO0oo0oOOOO
 if iiiI11 == "true" :
  O0O0o0o0o = 1
  O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   if OOoO000O00oO < 100 :
    I1IiiI . update ( OOoO000O00oO )
    OOoO000O00oO = OOoO000O00oO + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ii1IiIIi1i = [ ]
   for oOOo0OOOOo0Oo , OOo0o , url in O0Oo00 :
    oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : url }
    ii1IiIIi1i . append ( oooii1iiIi1 )
   o000O0OOoo = [ ]
   for o0ooOoO000oO in ii1IiIIi1i :
    oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
    O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
    for i111iiI1ii , IIiii in O0Oo00 :
     oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
    o000O0OOoo . append ( oooii1iiIi1 )
    if 23 - 23: i11iIiiIii
   for o0ooOoO000oO in o000O0OOoo :
    name = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
    url = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOO00O0O0OOo . append ( name )
    OOo00O . append ( url )
    if "hd" in name . lower ( ) :
     OooOOOo0 . append ( "1" )
    else :
     OooOOOo0 . append ( "0" )
    ii1I1IIii11 = list ( zip ( OooOOOo0 , oOOO00O0O0OOo , OOo00O ) )
    if 39 - 39: oo0ooO0oOOOOo - i11iiII % i1iIIIiI1I * oo - oOo0 / i1iIIIiI1I
 if OOooO == "true" :
  O0O0o0o0o = 1
  O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
  for Ii1iIiII1ii1 in oO0 :
   if OOoO000O00oO < 100 :
    I1IiiI . update ( OOoO000O00oO )
    OOoO000O00oO = OOoO000O00oO + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   ii1IiIIi1i = [ ]
   for oOOo0OOOOo0Oo , OOo0o , url in O0Oo00 :
    oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : url }
    ii1IiIIi1i . append ( oooii1iiIi1 )
   o000O0OOoo = [ ]
   for o0ooOoO000oO in ii1IiIIi1i :
    oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
    O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
    for i111iiI1ii , IIiii in O0Oo00 :
     oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
    o000O0OOoo . append ( oooii1iiIi1 )
    if 29 - 29: i11iiII
   for o0ooOoO000oO in o000O0OOoo :
    name = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
    url = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOO00O0O0OOo . append ( name )
    OOo00O . append ( url )
    if "hd" in name . lower ( ) :
     OooOOOo0 . append ( "1" )
    else :
     OooOOOo0 . append ( "0" )
    ii1I1IIii11 = list ( zip ( OooOOOo0 , oOOO00O0O0OOo , OOo00O ) )
    if 52 - 52: i11iIiiIii / II1Ii1iI1i
 if O0O0o0o0o == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 1 - 1: iiIIiIiIi
 ooOoOo0 = sorted ( ii1I1IIii11 , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 if 78 - 78: i11iiII + oo0Ooo0 - oooO0oo0oOOOO
 iI1Iii = 0
 if 10 - 10: OooOoO0Oo % i1IIi11111i
 I1IiiI . update ( 100 )
 if 97 - 97: i111I - OooOoO0Oo
 oO0o0OOOO ( '[COLOR dodgerblue][B]LINKS FOR ' + IiiIIIII1iii . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 I1i1i1 = IIii1i1iii1 . split ( ' ' )
 for O0OO0O , name , url in ooOoOo0 :
  if OooO0oOo == 1 :
   oooo00 = name
   if 96 - 96: i11iiII % iiIIiIiIi % i1IIiiiii - iiIIiIiIi % OOO0O + i11iiII
  Ii1 = 0
  if 3 - 3: oooO0oo0oOOOO
  for IIi in I1i1i1 :
   if 64 - 64: II1Ii1iI1i % iiIIiIiIi / i11iIiiIii - II1Ii1iI1i % oOo0 . i1iIIIiI1I
   if not IIi . lower ( ) in name . lower ( ) :
    Ii1 = 1
    if 8 - 8: I11i1i11i1I + i1111 * oOo0 * OOO0O * oo0Ooo0 / OoO000
  if Ii1 == 0 :
   iI1Iii = iI1Iii + 1
   if OooO0oOo == 1 :
    if "hd" in name . lower ( ) :
     oO0o0OOOO ( '[COLOR blue] ' + str ( oooo00 ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO0o0OOOO ( '[COLOR blue] ' + str ( oooo00 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     oO0o0OOOO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iI1Iii ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO0o0OOOO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iI1Iii ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 21 - 21: OooooO0oOO / i111I
 if iI1Iii == 0 :
  oO0o0OOOO ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 11 - 11: oOo0 % i1IIiiiii - i11iIiiIii - OooooO0oOO + iiIIiIiIi + OoO000
 I1IiiI . close ( )
 if 87 - 87: OooOoO0Oo * II1Ii1iI1i / i11iiII
def IIII1i1 ( term ) :
 if 70 - 70: i11iIiiIii % i11iiII / i1IIi11111i
 O0OoOO0o = [ ]
 ooooo0O0000oo = [ ]
 if 62 - 62: II1Ii1iI1i - OOO0O
 O0oOOoooOO0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oOOoooOO0O )
 for Ii1iIiII1ii1 in oO0 :
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1iI11i1ii11 = Ii1iIiII1ii1
  if 62 - 62: II1Ii1iI1i + I11i1i11i1I % OoO000
  i1iI11i1ii11 = i1iI11i1ii11 . replace ( '#AAASTREAM:' , '#A:' )
  i1iI11i1ii11 = i1iI11i1ii11 . replace ( '#EXTINF:' , '#A:' )
  O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i1iI11i1ii11 )
  ii1IiIIi1i = [ ]
  for oOOo0OOOOo0Oo , OOo0o , i1iI11i1ii11 in O0Oo00 :
   oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : i1iI11i1ii11 }
   ii1IiIIi1i . append ( oooii1iiIi1 )
  list = [ ]
  for o0ooOoO000oO in ii1IiIIi1i :
   oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
   O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
   for i111iiI1ii , IIiii in O0Oo00 :
    oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
   list . append ( oooii1iiIi1 )
   if 28 - 28: i11iiII . II1Ii1iI1i
  for o0ooOoO000oO in list :
   i1OOO = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
   i1iI11i1ii11 = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
   i1iI11i1ii11 = i1iI11i1ii11 . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in i1OOO . lower ( ) :
    O0OoOO0o . append ( i1iI11i1ii11 )
    ooooo0O0000oo . append ( i1OOO )
    if 10 - 10: oo / I11i1i11i1I
 O00ooooo00 = xbmcgui . Dialog ( )
 ooO0O00Oo0o = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , ooooo0O0000oo )
 if ooO0O00Oo0o < 0 :
  quit ( )
  if 15 - 15: i1iIIIiI1I . OOO0O / i1iIIIiI1I * oo0Ooo0 - i1IIi11111i % i11iiII
 i1iI11i1ii11 = O0OoOO0o [ ooO0O00Oo0o ]
 i1OOO = ooooo0O0000oo [ ooO0O00Oo0o ]
 i111iIi1i1II1 ( i1OOO , i1iI11i1ii11 , iiiii )
 if 57 - 57: oooO0oo0oOOOO % OOO0O % OooooO0oOO
def iI1iii ( name , url , iconimage ) :
 if 87 - 87: i11iiII / i111I - I11i1i11i1I % OOO0O % OoO000 % I11i1i11i1I
 list = Ii1I1iiiiii ( url )
 if 65 - 65: OoO000 + I11i1i11i1I
 Ooo0O0 = 0
 OooO0 = open ( iI1Ii11111iIi , mode = 'r' ) ; ooo0 = OooO0 . read ( ) ; OooO0 . close ( )
 ooo0 = ooo0 . replace ( '\n' , '' )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( ooo0 )
 Ii1iI1iI11I1 = 0
 for Ii1iIiII1ii1 in oO0 :
  if 55 - 55: I11i1i11i1I
  ooO0o = re . compile ( '<url>(.+?)</url>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  if 25 - 25: ooO0oo0oO0 - i1iIIIiI1I
  if url == ooO0o :
   Ooo0O0 = 1
   if 3 - 3: i1IIi11111i * iiIIiIiIi + i1111 - oo
 for o0ooOoO000oO in list :
  name = I1i11iIIi11 ( o0ooOoO000oO [ "display_name" ] )
  url = I1i11iIIi11 ( o0ooOoO000oO [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if Ooo0O0 == 1 :
   if 97 - 97: i11iiII / OooooO0oOO - oo0ooO0oOOOOo - i1IIi11111i - i1IIi11111i
   OooO0 = open ( i1i1II , mode = 'r' ) ; ooo0 = OooO0 . read ( ) ; OooO0 . close ( )
   ooo0 = ooo0 . replace ( '\n' , '' )
   oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( ooo0 )
   for Ii1iIiII1ii1 in oO0 :
    if 54 - 54: I11i1i11i1I + i1IIi11111i / i1iIIIiI1I . i1IIi11111i * OOO0O
    IIiIiiiIIIIi1 = re . compile ( '<name>(.+?)</name>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    if 39 - 39: oo / i1IIiiiii / OooOoO0Oo
    O00O0 = IIiIiiiIIIIi1 . replace ( ' ' , '' )
    iIiIiiiIi = name . replace ( ' ' , '' )
    if O00O0 . lower ( ) in iIiIiiiIi . lower ( ) :
     if 11 - 11: oo0Ooo0 % II1Ii1iI1i
     OooO0 = open ( O0oo0OO0 , mode = 'r' ) ; ooo0 = OooO0 . read ( ) ; OooO0 . close ( )
     ooo0 = ooo0 . replace ( '\n' , '' )
     oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( ooo0 )
     for Ii1iIiII1ii1 in oO0 :
      if 16 - 16: i1IIi11111i + iiIIiIiIi % OOO0O
      o0o0oOo000o0 = re . compile ( '<replace>(.+?)</replace>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
      if 25 - 25: oo0Ooo0 + OOO0O . oo0ooO0oOOOOo % OOO0O * oOo0
      name = name . lower ( ) . replace ( o0o0oOo000o0 , '' )
      if 32 - 32: i11iIiiIii - OooOoO0Oo
     oO0o0OOOO ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 53 - 53: i111I - OoO000
  else : oO0o0OOOO ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 87 - 87: OooooO0oOO . i1IIi11111i
def Ii1I1iiiiii ( url ) :
 if 17 - 17: i1IIiiiii . i11iIiiIii
 IIIiiiI = IIIii1II1II ( url )
 IIIiiiI = IIIiiiI . replace ( '#AAASTREAM:' , '#A:' )
 IIIiiiI = IIIiiiI . replace ( '#EXTINF:' , '#A:' )
 O0Oo00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IIIiiiI )
 ii1IiIIi1i = [ ]
 for oOOo0OOOOo0Oo , OOo0o , url in O0Oo00 :
  oooii1iiIi1 = { "params" : oOOo0OOOOo0Oo , "display_name" : OOo0o , "url" : url }
  ii1IiIIi1i . append ( oooii1iiIi1 )
 list = [ ]
 for o0ooOoO000oO in ii1IiIIi1i :
  oooii1iiIi1 = { "display_name" : o0ooOoO000oO [ "display_name" ] , "url" : o0ooOoO000oO [ "url" ] }
  O0Oo00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0ooOoO000oO [ "params" ] )
  for i111iiI1ii , IIiii in O0Oo00 :
   oooii1iiIi1 [ i111iiI1ii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = IIiii . strip ( )
  list . append ( oooii1iiIi1 )
  if 94 - 94: oooO0oo0oOOOO - oo0Ooo0 - ooO0oo0oO0 % iiIIiIiIi / i1IIiiiii % i1iIIIiI1I
 return list
 if 44 - 44: I11i1i11i1I % ooO0oo0oO0
 if 90 - 90: i1111 + i111I % i111I
def I11Ii ( ) :
 if 16 - 16: I11i1i11i1I / i11iIiiIii
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 64 - 64: i11iIiiIii / i1IIiiiii * II1Ii1iI1i
def OOOOOOoO ( name , url , iconimage ) :
 if 12 - 12: i1iIIIiI1I . OoO000 . OOO0O / oooO0oo0oOOOO
 OO0oOOo0o = datetime . datetime . now ( )
 I1III11iiii11i1 = OO0oOOo0o . day
 if 54 - 54: II1Ii1iI1i - OooooO0oOO
 IiIIII = I1III11iiii11i1
 if 89 - 89: oo / i1IIi11111i
 IIi1iI1 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 IIi11i1II = datetime . datetime . strftime ( IIi1iI1 , '%A - %d %B %Y' )
 OO0ooo0o0 = 'http://www.predictz.com/predictions/'
 if 69 - 69: i11iiII - OooOoO0Oo
 iiIIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 i111i11I1Ii1I = datetime . datetime . strftime ( iiIIi1 , '%A - %d %B %Y' )
 iI1I11iIIi1 = datetime . datetime . strftime ( iiIIi1 , '%d' )
 iIIi1I = 'http://www.predictz.com/predictions/tomorrow/'
 if 45 - 45: II1Ii1iI1i - I11i1i11i1I / oooO0oo0oOOOO . i11iiII
 iI1 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 iIIiI1ii = datetime . datetime . strftime ( iI1 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oo0OOoOoo0O0O = datetime . datetime . strftime ( iI1 , '%y%m%d' )
 iiI11ii1111 = 'http://www.predictz.com/predictions/20' + str ( oo0OOoOoo0O0O )
 if 2 - 2: OOO0O . II1Ii1iI1i . II1Ii1iI1i - i1111 - OOO0O
 ooOOooo0Oo = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 oo0O0o = datetime . datetime . strftime ( ooOOooo0Oo , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OO0oIiII1iiI = datetime . datetime . strftime ( ooOOooo0Oo , '%y%m%d' )
 iII = 'http://www.predictz.com/predictions/20' + str ( OO0oIiII1iiI )
 if 63 - 63: oo0ooO0oOOOOo * i1iIIIiI1I
 O0oOoo0OoO0O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 oo00 = datetime . datetime . strftime ( O0oOoo0OoO0O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiI1 = datetime . datetime . strftime ( O0oOoo0OoO0O , '%y%m%d' )
 oOo00o00oO = 'http://www.predictz.com/predictions/20' + str ( IiI1 )
 if 95 - 95: i1IIi11111i
 if 88 - 88: OoO000 % oo + OooOoO0Oo + OooOoO0Oo * i1111
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IIi11i1II ) + '[/B][/COLOR]' , OO0ooo0o0 , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( i111i11I1Ii1I ) + '[/B][/COLOR]' , iIIi1I , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIIiI1ii ) , iiI11ii1111 , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo0O0o ) , iII , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo00 ) , oOo00o00oO , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 78 - 78: i111I
def OOoo0 ( name , url , iconimage ) :
 if 36 - 36: oo0ooO0oOOOOo + oo0Ooo0 - OoO000 + ooO0oo0oO0 + i111I
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 I1i1i1 = str ( oO0 )
 oOoO0 = re . compile ( '<tr(.+?)</tr>' ) . findall ( I1i1i1 )
 for Ii1iIiII1ii1 in oOoO0 :
  try :
   i1iIiIi1I = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR red][B]' + i1iIiIi1I + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   ooo00Ooo = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   IiI1i111IiIiIi1 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   ooo00Ooo = i1II11II1 ( ooo00Ooo )
   IiI1i111IiIiIi1 = i1II11II1 ( IiI1i111IiIiIi1 )
   oO0o0OOOO ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + IiI1i111IiIiIi1 + ' [/B][/COLOR]| [COLOR mediumpurple]' + ooo00Ooo + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 5 - 5: I11i1i11i1I - i11iiII % OooooO0oOO - i1111 . i1IIi11111i + i1iIIIiI1I
def iiIi1I1i1 ( name , url , iconimage ) :
 if 94 - 94: oo . i111I + oo0Ooo0 - OOO0O / i1111
 OO0oOOo0o = datetime . datetime . now ( )
 I1III11iiii11i1 = OO0oOOo0o . day
 if 70 - 70: oo0Ooo0 % ooO0oo0oO0 . I11i1i11i1I + I11i1i11i1I - oo0ooO0oOOOOo % OooOoO0Oo
 IiIIII = I1III11iiii11i1
 if 38 - 38: OooOoO0Oo % oOo0 - i111I
 IIi1iI1 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 IIi11i1II = datetime . datetime . strftime ( IIi1iI1 , '%A - %d %B %Y' )
 OO0ooo0o0 = 'http://www.predictz.com/predictions/'
 if 87 - 87: oo % i1IIi11111i
 iiIIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 i111i11I1Ii1I = datetime . datetime . strftime ( iiIIi1 , '%A - %d %B %Y' )
 iI1I11iIIi1 = datetime . datetime . strftime ( iiIIi1 , '%d' )
 iIIi1I = 'http://www.predictz.com/predictions/tomorrow/'
 if 77 - 77: ooO0oo0oO0 - II1Ii1iI1i . OooooO0oOO
 iI1 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 iIIiI1ii = datetime . datetime . strftime ( iI1 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oo0OOoOoo0O0O = datetime . datetime . strftime ( iI1 , '%y%m%d' )
 iiI11ii1111 = 'http://www.predictz.com/predictions/20' + str ( oo0OOoOoo0O0O )
 if 26 - 26: oo0ooO0oOOOOo * OoO000 . II1Ii1iI1i
 ooOOooo0Oo = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 oo0O0o = datetime . datetime . strftime ( ooOOooo0Oo , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OO0oIiII1iiI = datetime . datetime . strftime ( ooOOooo0Oo , '%y%m%d' )
 iII = 'http://www.predictz.com/predictions/20' + str ( OO0oIiII1iiI )
 if 59 - 59: oooO0oo0oOOOO + II1Ii1iI1i - oo0ooO0oOOOOo
 O0oOoo0OoO0O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 oo00 = datetime . datetime . strftime ( O0oOoo0OoO0O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiI1 = datetime . datetime . strftime ( O0oOoo0OoO0O , '%y%m%d' )
 oOo00o00oO = 'http://www.predictz.com/predictions/20' + str ( IiI1 )
 if 62 - 62: i11iIiiIii % oOo0 . OoO000 . oOo0
 if 84 - 84: i11iIiiIii * oo
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IIi11i1II ) + '[/B][/COLOR]' , OO0ooo0o0 , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( i111i11I1Ii1I ) + '[/B][/COLOR]' , iIIi1I , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIIiI1ii ) , iiI11ii1111 , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo0O0o ) , iII , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo00 ) , oOo00o00oO , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 18 - 18: oOo0 - i1IIiiiii - OOO0O / OooOoO0Oo - oooO0oo0oOOOO
def iiIIii ( name , url , iconimage ) :
 if 70 - 70: oo0ooO0oOOOOo - oOo0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 I1i1i1 = str ( oO0 )
 oOoO0 = re . compile ( '<tr(.+?)</tr>' ) . findall ( I1i1i1 )
 for Ii1iIiII1ii1 in oOoO0 :
  try :
   i1iIiIi1I = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR red][B]' + i1iIiIi1I + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   ooo00Ooo = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0O000oOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OoOOOO = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   I1iiIi111I = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   ooo00Ooo = i1II11II1 ( ooo00Ooo )
   oO0o0OOOO ( '[COLOR mediumpurple][B]' + ooo00Ooo + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + oO0O000oOo + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + OoOOOO + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + I1iiIi111I + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 34 - 34: i11iIiiIii - i1111 / i1IIi11111i % oo0ooO0oOOOOo
def iI1IiiiI11 ( name , url , iconimage ) :
 if 80 - 80: OooooO0oOO + oo0ooO0oOOOOo * i1IIiiiii + oo
 OO0oOOo0o = datetime . datetime . now ( )
 I1III11iiii11i1 = OO0oOOo0o . day
 if 75 - 75: oo0Ooo0 / oo0ooO0oOOOOo / oOo0 / OoO000 % iiIIiIiIi + i1111
 IiIIII = I1III11iiii11i1
 if 4 - 4: i1iIIIiI1I - I11i1i11i1I - OoO000 - oo0Ooo0 % i11iIiiIii / oo
 IIi1iI1 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 IIi11i1II = datetime . datetime . strftime ( IIi1iI1 , '%A - %d %B %Y' )
 OO0ooo0o0 = 'http://www.predictz.com/predictions/'
 if 50 - 50: iiIIiIiIi + II1Ii1iI1i
 iiIIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 i111i11I1Ii1I = datetime . datetime . strftime ( iiIIi1 , '%A - %d %B %Y' )
 iI1I11iIIi1 = datetime . datetime . strftime ( iiIIi1 , '%d' )
 iIIi1I = 'http://www.predictz.com/predictions/tomorrow/'
 if 31 - 31: i1IIiiiii
 iI1 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 iIIiI1ii = datetime . datetime . strftime ( iI1 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oo0OOoOoo0O0O = datetime . datetime . strftime ( iI1 , '%y%m%d' )
 iiI11ii1111 = 'http://www.predictz.com/predictions/20' + str ( oo0OOoOoo0O0O )
 if 78 - 78: i11iIiiIii + oo0ooO0oOOOOo + OooOoO0Oo / oo0ooO0oOOOOo % ooO0oo0oO0 % OoO000
 ooOOooo0Oo = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 oo0O0o = datetime . datetime . strftime ( ooOOooo0Oo , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OO0oIiII1iiI = datetime . datetime . strftime ( ooOOooo0Oo , '%y%m%d' )
 iII = 'http://www.predictz.com/predictions/20' + str ( OO0oIiII1iiI )
 if 83 - 83: ooO0oo0oO0 % OOO0O % oo0ooO0oOOOOo % OooOoO0Oo . i11iiII % oooO0oo0oOOOO
 O0oOoo0OoO0O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 oo00 = datetime . datetime . strftime ( O0oOoo0OoO0O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiI1 = datetime . datetime . strftime ( O0oOoo0OoO0O , '%y%m%d' )
 oOo00o00oO = 'http://www.predictz.com/predictions/20' + str ( IiI1 )
 if 47 - 47: oo0ooO0oOOOOo
 if 66 - 66: i1IIi11111i - OoO000
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IIi11i1II ) + '[/B][/COLOR]' , OO0ooo0o0 , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( i111i11I1Ii1I ) + '[/B][/COLOR]' , iIIi1I , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIIiI1ii ) , iiI11ii1111 , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo0O0o ) , iII , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo00 ) , oOo00o00oO , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 33 - 33: i1IIi11111i / oo
def iiIIi ( name , url , iconimage ) :
 if 36 - 36: oo0Ooo0 . i1111
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 I1i1i1 = str ( oO0 )
 oOoO0 = re . compile ( '<tr(.+?)</tr>' ) . findall ( I1i1i1 )
 for Ii1iIiII1ii1 in oOoO0 :
  try :
   i1iIiIi1I = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR red][B]' + i1iIiIi1I + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   ooo00Ooo = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1Iii , oO00OOoO00 = ooo00Ooo . split ( ' v ' )
   iIIiI1iiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   I11Ii111I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   Oo00OO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   oo0O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 3 ]
   oO00OoOOOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 4 ]
   Oo0o0OOOOO0O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 5 ]
   I1I1IiIi1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 6 ]
   oOO0o0oo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 7 ]
   oOo000O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 8 ]
   iIIooO0o0O0Oo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 9 ]
   if 1 - 1: ooO0oo0oO0 + I11i1i11i1I / oooO0oo0oOOOO - i1iIIIiI1I % OoO000 + OoO000
   if iIIiI1iiI == "W" :
    iIIiI1iiI = '[COLOR lime]W[/COLOR]'
   elif iIIiI1iiI == "D" :
    iIIiI1iiI = '[COLOR yellow]D[/COLOR]'
   else : iIIiI1iiI = '[COLOR red]L[/COLOR]'
   if 24 - 24: i1IIi11111i + I11i1i11i1I + oOo0 - i111I + I11i1i11i1I
   if I11Ii111I == "W" :
    I11Ii111I = '[COLOR lime]W[/COLOR]'
   elif I11Ii111I == "D" :
    I11Ii111I = '[COLOR yellow]D[/COLOR]'
   else : I11Ii111I = '[COLOR red]L[/COLOR]'
   if 93 - 93: iiIIiIiIi . ooO0oo0oO0 % i11iIiiIii . OOO0O % iiIIiIiIi + oooO0oo0oOOOO
   if Oo00OO0 == "W" :
    Oo00OO0 = '[COLOR lime]W[/COLOR]'
   elif Oo00OO0 == "D" :
    Oo00OO0 = '[COLOR yellow]D[/COLOR]'
   else : Oo00OO0 = '[COLOR red]L[/COLOR]'
   if 65 - 65: i1IIiiiii + oo - i111I
   if oo0O == "W" :
    oo0O = '[COLOR lime]W[/COLOR]'
   elif oo0O == "D" :
    oo0O = '[COLOR yellow]D[/COLOR]'
   else : oo0O = '[COLOR red]L[/COLOR]'
   if 51 - 51: I11i1i11i1I + OooooO0oOO / i1iIIIiI1I - II1Ii1iI1i
   if oO00OoOOOo == "W" :
    oO00OoOOOo = '[COLOR lime]W[/COLOR]'
   elif oO00OoOOOo == "D" :
    oO00OoOOOo = '[COLOR yellow]D[/COLOR]'
   else : oO00OoOOOo = '[COLOR red]L[/COLOR]'
   if 51 - 51: I11i1i11i1I - i11iiII * oo0Ooo0
   if Oo0o0OOOOO0O == "W" :
    Oo0o0OOOOO0O = '[COLOR lime]W[/COLOR]'
   elif Oo0o0OOOOO0O == "D" :
    Oo0o0OOOOO0O = '[COLOR yellow]D[/COLOR]'
   else : Oo0o0OOOOO0O = '[COLOR red]L[/COLOR]'
   if 12 - 12: ooO0oo0oO0 % iiIIiIiIi % iiIIiIiIi
   if I1I1IiIi1 == "W" :
    I1I1IiIi1 = '[COLOR lime]W[/COLOR]'
   elif I1I1IiIi1 == "D" :
    I1I1IiIi1 = '[COLOR yellow]D[/COLOR]'
   else : I1I1IiIi1 = '[COLOR red]L[/COLOR]'
   if 78 - 78: OoO000 . OOO0O . oo0Ooo0
   if oOO0o0oo0 == "W" :
    oOO0o0oo0 = '[COLOR lime]W[/COLOR]'
   elif oOO0o0oo0 == "D" :
    oOO0o0oo0 = '[COLOR yellow]D[/COLOR]'
   else : oOO0o0oo0 = '[COLOR red]L[/COLOR]'
   if 97 - 97: OooooO0oOO
   if oOo000O == "W" :
    oOo000O = '[COLOR lime]W[/COLOR]'
   elif oOo000O == "D" :
    oOo000O = '[COLOR yellow]D[/COLOR]'
   else : oOo000O = '[COLOR red]L[/COLOR]'
   if 80 - 80: i1IIi11111i . i1IIiiiii
   if iIIooO0o0O0Oo == "W" :
    iIIooO0o0O0Oo = '[COLOR lime]W[/COLOR]'
   elif iIIooO0o0O0Oo == "D" :
    iIIooO0o0O0Oo = '[COLOR yellow]D[/COLOR]'
   else : iIIooO0o0O0Oo = '[COLOR red]L[/COLOR]'
   if 47 - 47: oo0Ooo0 + iiIIiIiIi + i1111 % i11iIiiIii
   iI1Iii = i1II11II1 ( iI1Iii )
   oO00OOoO00 = i1II11II1 ( oO00OOoO00 )
   oO0o0OOOO ( '[COLOR mediumpurple][B]' + iI1Iii + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[B]' + iIIiI1iiI + '  ' + I11Ii111I + '  ' + Oo00OO0 + '  ' + oo0O + '  ' + oO00OoOOOo + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR mediumpurple][B]' + oO00OOoO00 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[B]' + Oo0o0OOOOO0O + '  ' + I1I1IiIi1 + '  ' + oOO0o0oo0 + '  ' + oOo000O + '  ' + iIIooO0o0O0Oo + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 93 - 93: i11iiII % OOO0O . oooO0oo0oOOOO / i1iIIIiI1I * OooooO0oOO
def i1iii1ii ( name , url , iconimage ) :
 if 18 - 18: oo . i1111 % OOO0O % i1IIiiiii
 OO0oOOo0o = datetime . datetime . now ( )
 I1III11iiii11i1 = OO0oOOo0o . day
 if 87 - 87: ooO0oo0oO0 . i111I * OOO0O
 IiIIII = I1III11iiii11i1
 if 100 - 100: oo / II1Ii1iI1i - i1IIi11111i % i1IIiiiii - ooO0oo0oO0
 IIi1iI1 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 IIi11i1II = datetime . datetime . strftime ( IIi1iI1 , '%A - %d %B %Y' )
 OO0ooo0o0 = 'http://www.predictz.com/predictions/'
 if 17 - 17: oo0Ooo0 / oo0ooO0oOOOOo % I11i1i11i1I
 iiIIi1 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 i111i11I1Ii1I = datetime . datetime . strftime ( iiIIi1 , '%A - %d %B %Y' )
 iI1I11iIIi1 = datetime . datetime . strftime ( iiIIi1 , '%d' )
 iIIi1I = 'http://www.predictz.com/predictions/tomorrow/'
 if 71 - 71: OoO000 . OooOoO0Oo . oo
 iI1 = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 iIIiI1ii = datetime . datetime . strftime ( iI1 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oo0OOoOoo0O0O = datetime . datetime . strftime ( iI1 , '%y%m%d' )
 iiI11ii1111 = 'http://www.predictz.com/predictions/20' + str ( oo0OOoOoo0O0O )
 if 68 - 68: i11iIiiIii % OooooO0oOO * oo * OoO000 * i1111 + oooO0oo0oOOOO
 ooOOooo0Oo = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 oo0O0o = datetime . datetime . strftime ( ooOOooo0Oo , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 OO0oIiII1iiI = datetime . datetime . strftime ( ooOOooo0Oo , '%y%m%d' )
 iII = 'http://www.predictz.com/predictions/20' + str ( OO0oIiII1iiI )
 if 66 - 66: oo0Ooo0 % i11iiII % i111I
 O0oOoo0OoO0O = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 oo00 = datetime . datetime . strftime ( O0oOoo0OoO0O , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 IiI1 = datetime . datetime . strftime ( O0oOoo0OoO0O , '%y%m%d' )
 oOo00o00oO = 'http://www.predictz.com/predictions/20' + str ( IiI1 )
 if 34 - 34: oo0ooO0oOOOOo / i1iIIIiI1I % oooO0oo0oOOOO . oo . II1Ii1iI1i
 if 29 - 29: oooO0oo0oOOOO . OooOoO0Oo
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( IIi11i1II ) + '[/B][/COLOR]' , OO0ooo0o0 , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( i111i11I1Ii1I ) + '[/B][/COLOR]' , iIIi1I , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( iIIiI1ii ) , iiI11ii1111 , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo0O0o ) , iII , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oo00 ) , oOo00o00oO , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 66 - 66: OooooO0oOO * ooO0oo0oO0 % ooO0oo0oO0 * OoO000 - iiIIiIiIi - OoO000
def o0O0oO0 ( name , url , iconimage ) :
 if 77 - 77: oooO0oo0oOOOO . i1IIiiiii
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 I1i1i1 = str ( oO0 )
 oOoO0 = re . compile ( '<tr(.+?)</tr>' ) . findall ( I1i1i1 )
 for Ii1iIiII1ii1 in oOoO0 :
  try :
   i1iIiIi1I = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR red][B]' + i1iIiIi1I + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   ooo00Ooo = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1Iii , oO00OOoO00 = ooo00Ooo . split ( ' v ' )
   if 39 - 39: iiIIiIiIi . i1111
   IiI1i111IiIiIi1 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0O000oOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OoOOOO = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   I1iiIi111I = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   iIIiI1iiI = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   I11Ii111I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   Oo00OO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   oo0O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 3 ]
   oO00OoOOOo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 4 ]
   Oo0o0OOOOO0O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 5 ]
   I1I1IiIi1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 6 ]
   oOO0o0oo0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 7 ]
   oOo000O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 8 ]
   iIIooO0o0O0Oo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 9 ]
   if 45 - 45: OooooO0oOO * OOO0O / ooO0oo0oO0
   if iIIiI1iiI == "W" :
    iIIiI1iiI = '[COLOR lime]W[/COLOR]'
   elif iIIiI1iiI == "D" :
    iIIiI1iiI = '[COLOR yellow]D[/COLOR]'
   else : iIIiI1iiI = '[COLOR red]L[/COLOR]'
   if 77 - 77: OooOoO0Oo - oo0Ooo0
   if I11Ii111I == "W" :
    I11Ii111I = '[COLOR lime]W[/COLOR]'
   elif I11Ii111I == "D" :
    I11Ii111I = '[COLOR yellow]D[/COLOR]'
   else : I11Ii111I = '[COLOR red]L[/COLOR]'
   if 11 - 11: i11iiII
   if Oo00OO0 == "W" :
    Oo00OO0 = '[COLOR lime]W[/COLOR]'
   elif Oo00OO0 == "D" :
    Oo00OO0 = '[COLOR yellow]D[/COLOR]'
   else : Oo00OO0 = '[COLOR red]L[/COLOR]'
   if 26 - 26: ooO0oo0oO0 * OooOoO0Oo - oOo0
   if oo0O == "W" :
    oo0O = '[COLOR lime]W[/COLOR]'
   elif oo0O == "D" :
    oo0O = '[COLOR yellow]D[/COLOR]'
   else : oo0O = '[COLOR red]L[/COLOR]'
   if 27 - 27: i11iiII * OooOoO0Oo - oo + i1IIiiiii * i1IIiiiii
   if oO00OoOOOo == "W" :
    oO00OoOOOo = '[COLOR lime]W[/COLOR]'
   elif oO00OoOOOo == "D" :
    oO00OoOOOo = '[COLOR yellow]D[/COLOR]'
   else : oO00OoOOOo = '[COLOR red]L[/COLOR]'
   if 55 - 55: iiIIiIiIi
   if Oo0o0OOOOO0O == "W" :
    Oo0o0OOOOO0O = '[COLOR lime]W[/COLOR]'
   elif Oo0o0OOOOO0O == "D" :
    Oo0o0OOOOO0O = '[COLOR yellow]D[/COLOR]'
   else : Oo0o0OOOOO0O = '[COLOR red]L[/COLOR]'
   if 82 - 82: OooOoO0Oo - oOo0 + oo
   if I1I1IiIi1 == "W" :
    I1I1IiIi1 = '[COLOR lime]W[/COLOR]'
   elif I1I1IiIi1 == "D" :
    I1I1IiIi1 = '[COLOR yellow]D[/COLOR]'
   else : I1I1IiIi1 = '[COLOR red]L[/COLOR]'
   if 64 - 64: oo0ooO0oOOOOo . oooO0oo0oOOOO * i1IIiiiii + i111I - I11i1i11i1I . i111I
   if oOO0o0oo0 == "W" :
    oOO0o0oo0 = '[COLOR lime]W[/COLOR]'
   elif oOO0o0oo0 == "D" :
    oOO0o0oo0 = '[COLOR yellow]D[/COLOR]'
   else : oOO0o0oo0 = '[COLOR red]L[/COLOR]'
   if 70 - 70: I11i1i11i1I - OooooO0oOO . ooO0oo0oO0 % oo0Ooo0 / OOO0O - oooO0oo0oOOOO
   if oOo000O == "W" :
    oOo000O = '[COLOR lime]W[/COLOR]'
   elif oOo000O == "D" :
    oOo000O = '[COLOR yellow]D[/COLOR]'
   else : oOo000O = '[COLOR red]L[/COLOR]'
   if 55 - 55: i1iIIIiI1I - oo
   if iIIooO0o0O0Oo == "W" :
    iIIooO0o0O0Oo = '[COLOR lime]W[/COLOR]'
   elif iIIooO0o0O0Oo == "D" :
    iIIooO0o0O0Oo = '[COLOR yellow]D[/COLOR]'
   else : iIIooO0o0O0Oo = '[COLOR red]L[/COLOR]'
   if 100 - 100: oooO0oo0oOOOO
   iI1Iii = i1II11II1 ( iI1Iii )
   oO00OOoO00 = i1II11II1 ( oO00OOoO00 )
   ooo00Ooo = i1II11II1 ( ooo00Ooo )
   IiI1i111IiIiIi1 = i1II11II1 ( IiI1i111IiIiIi1 )
   oO0o0OOOO ( '[COLOR blue][B]' + ooo00Ooo + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + IiI1i111IiIiIi1 + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]' + iI1Iii + ' Form: - [/COLOR][B]' + iIIiI1iiI + '  ' + I11Ii111I + '  ' + Oo00OO0 + '  ' + oo0O + '  ' + oO00OoOOOo + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]' + oO00OOoO00 + ' Form - [/COLOR][B]' + Oo0o0OOOOO0O + '  ' + I1I1IiIi1 + '  ' + oOO0o0oo0 + '  ' + oOo000O + '  ' + iIIooO0o0O0Oo + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]' + iI1Iii + ' Win[/COLOR][COLOR dodgerblue][B] (' + oO0O000oOo + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + OoOOOO + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]' + oO00OOoO00 + ' Win[/COLOR][COLOR dodgerblue][B] (' + I1iiIi111I + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 79 - 79: ooO0oo0oO0
  except : pass
  if 81 - 81: oOo0 + ooO0oo0oO0 * OooOoO0Oo - ooO0oo0oO0 . oOo0
def I1ii ( name , url , iconimage ) :
 if 80 - 80: i11iiII / ooO0oo0oO0 % OOO0O
 oO000o0Oo00 = [ ]
 OooO0O = [ ]
 IiOoOoooO0O00 = [ ]
 oOO0OooO0 = [ ]
 OoooOo = [ ]
 if 37 - 37: II1Ii1iI1i - oOo0 % i111I / oOo0 % iiIIiIiIi
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.livescores.com' )
 oO0 = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( o00OO00OoO )
 I1i1i1 = str ( oO0 )
 oOoO0 = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( I1i1i1 )
 for Ii1iIiII1ii1 in oOoO0 :
  iiIiII11i1 = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  oOo00Ooo0o0 = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   IiI1i111IiIiIi1 = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except :
   IiI1i111IiIiIi1 = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 33 - 33: oo0Ooo0
  if "minute" in time . lower ( ) :
   OoooOo . append ( '3' )
  elif "ht" in time . lower ( ) :
   OoooOo . append ( '3' )
  elif "ft" in time . lower ( ) :
   OoooOo . append ( '2' )
  else : OoooOo . append ( '1' )
  if 87 - 87: OOO0O / OoO000 + ooO0oo0oO0
  oO000o0Oo00 . append ( iiIiII11i1 )
  OooO0O . append ( oOo00Ooo0o0 )
  IiOoOoooO0O00 . append ( IiI1i111IiIiIi1 )
  oOO0OooO0 . append ( time )
  ii1I1IIii11 = list ( zip ( OoooOo , oO000o0Oo00 , OooO0O , IiOoOoooO0O00 , oOO0OooO0 ) )
  if 93 - 93: ooO0oo0oO0 + OooooO0oOO % iiIIiIiIi
 oO0o0OOOO ( '[COLOR dodgerblue][B]The scores will update every 10 seconds.[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 21 - 21: oOo0
 ooOoOo0 = sorted ( ii1I1IIii11 , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 iIiI1I1IIi11 = 0
 I1I1i11 = 0
 i1IiIi1i = 0
 for II , IIiIi11iiIi , i11iI11I1I , Ii1iiIi1I11i , O0OOO in ooOoOo0 :
  if II == "3" :
   if iIiI1I1IIi11 == 0 :
    oO0o0OOOO ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    iIiI1I1IIi11 = 1
  elif II == "2" :
   if I1I1i11 == 0 :
    oO0o0OOOO ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    I1I1i11 = 1
  elif II == "1" :
   if i1IiIi1i == 0 :
    oO0o0OOOO ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    i1IiIi1i = 1
  O0OOO = O0OOO . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  Ii1iiIi1I11i = Ii1iiIi1I11i . replace ( " " , "" )
  oO0o0OOOO ( '[COLOR red][B]' + O0OOO + "[/B][/COLOR]- [COLOR blue]" + Ii1iiIi1I11i + "[/COLOR] | [COLOR white]" + IIiIi11iiIi + "vs" + i11iI11I1I + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 37 - 37: oooO0oo0oOOOO - oo0Ooo0
def IiI1O0oO ( ) :
 if 27 - 27: oooO0oo0oOOOO / OOO0O + ooO0oo0oO0 - oOo0 % oo0ooO0oOOOOo
 I1i1i1 = ''
 O0O0Oo00 = xbmc . Keyboard ( I1i1i1 , 'Enter Search Term' )
 O0O0Oo00 . doModal ( )
 if O0O0Oo00 . isConfirmed ( ) :
  I1i1i1 = O0O0Oo00 . getText ( )
  if len ( I1i1i1 ) > 1 :
   i1iI11i1ii11 = I1i1i1 + "!" + iiiii
   ooO000O ( "all " + I1i1i1 , i1iI11i1ii11 , iiiii )
  else : quit ( )
  if 30 - 30: OooOoO0Oo % OooOoO0Oo % OoO000 . OOO0O
def I1ii1 ( name , url , iconimage ) :
 if 50 - 50: OooooO0oOO - iiIIiIiIi / ooO0oo0oO0 - oo + i1111 - oooO0oo0oOOOO
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 88 - 88: OooooO0oOO * oo
def o0O00oOoo ( text ) :
 if 35 - 35: i11iiII / i1iIIIiI1I % i1IIi11111i + ooO0oo0oO0
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 79 - 79: OOO0O / iiIIiIiIi
 return text
 if 77 - 77: I11i1i11i1I
def i1II11II1 ( text ) :
 if 46 - 46: OooOoO0Oo
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 72 - 72: i1iIIIiI1I * oOo0
 return text
 if 67 - 67: II1Ii1iI1i
def oo0o0000Oo0 ( text ) :
 if 5 - 5: i1111 . i111I
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 57 - 57: i1IIi11111i
 return text
 if 35 - 35: i111I - OooOoO0Oo / oo
def i111iIi1i1II1 ( name , url , iconimage ) :
 if 50 - 50: OOO0O
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]Opening link...[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 33 - 33: oo0Ooo0
 if "pl_type=user" in url :
  O0oOOoooOO0O = OOOO0OOoO0O0 ( url )
  url = re . compile ( '<meta property="og:video:iframe" content="(.+?)">' ) . findall ( O0oOOoooOO0O ) [ 0 ]
  if 98 - 98: OOO0O % i1111
 if not "plugin" in url :
  try :
   if not 'http' in url : url = 'http://' + url
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 95 - 95: ooO0oo0oO0 - OooOoO0Oo - oOo0 + OooOoO0Oo % i11iiII . i1IIi11111i
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 41 - 41: oooO0oo0oOOOO + OooooO0oOO . II1Ii1iI1i - i1111 * oo0ooO0oOOOOo . oo
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  oooO00Oo = urlresolver . HostedMediaFile ( url ) . resolve ( )
  ooO00o = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  ooO00o . setPath ( oooO00Oo )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( oooO00Oo , ooO00o , False )
  quit ( )
 else :
  oooO00Oo = url
  ooO00o = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  ooO00o . setPath ( oooO00Oo )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( oooO00Oo , ooO00o , False )
  quit ( )
  if 73 - 73: i1iIIIiI1I * i1iIIIiI1I / iiIIiIiIi
def oo0OOo0 ( ) :
 if 43 - 43: i11iiII . II1Ii1iI1i . OoO000 + oooO0oo0oOOOO * i1IIiiiii * oooO0oo0oOOOO
 II11ii = xbmc . getInfoLabel ( "System.BuildVersion" )
 I1oOooo00O = float ( II11ii [ : 4 ] )
 if I1oOooo00O >= 11.0 and I1oOooo00O <= 11.9 :
  OO0ooo0 = 'Eden'
 elif I1oOooo00O >= 12.0 and I1oOooo00O <= 12.9 :
  OO0ooo0 = 'Frodo'
 elif I1oOooo00O >= 13.0 and I1oOooo00O <= 13.9 :
  OO0ooo0 = 'Gotham'
 elif I1oOooo00O >= 14.0 and I1oOooo00O <= 14.9 :
  OO0ooo0 = 'Helix'
 elif I1oOooo00O >= 15.0 and I1oOooo00O <= 15.9 :
  OO0ooo0 = 'Isengard'
 elif I1oOooo00O >= 16.0 and I1oOooo00O <= 16.9 :
  OO0ooo0 = 'Jarvis'
 elif I1oOooo00O >= 17.0 and I1oOooo00O <= 17.9 :
  OO0ooo0 = 'Krypton'
 else : OO0ooo0 = "Decline"
 if 7 - 7: i11iiII - OooooO0oOO * oOo0 + oo0ooO0oOOOOo . i11iiII
 return OO0ooo0
 if 85 - 85: oooO0oo0oOOOO
def OOOO0OOoO0O0 ( url ) :
 if 32 - 32: i111I . oo / I11i1i11i1I * oo0ooO0oOOOOo / oo0ooO0oOOOOo * i1IIiiiii
 iI111i11iI1 = urllib2 . Request ( url )
 iI111i11iI1 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 IIIiiiI = urllib2 . urlopen ( iI111i11iI1 )
 o00OO00OoO = IIIiiiI . read ( )
 IIIiiiI . close ( )
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return o00OO00OoO
 if 2 - 2: OOO0O + OooOoO0Oo + i111I . II1Ii1iI1i
def IIIii1II1II ( url ) :
 if 19 - 19: i1iIIIiI1I - oo0ooO0oOOOOo - i1IIiiiii - OOO0O . i1iIIIiI1I . OooOoO0Oo
 iI111i11iI1 = urllib2 . Request ( url )
 iI111i11iI1 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 IIIiiiI = urllib2 . urlopen ( iI111i11iI1 )
 o00OO00OoO = IIIiiiI . read ( )
 IIIiiiI . close ( )
 return o00OO00OoO
 if 48 - 48: i1iIIIiI1I + OoO000
def I1i11iIIi11 ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 60 - 60: oo0Ooo0 + i1iIIIiI1I . OoO000 / II1Ii1iI1i . ooO0oo0oO0
 if 14 - 14: oOo0
 if 79 - 79: i1IIiiiii
 if 76 - 76: ooO0oo0oO0
 if 80 - 80: ooO0oo0oO0 . oooO0oo0oOOOO / i1IIiiiii % i1IIiiiii
def ooOo000OoO0o ( ) :
 if 58 - 58: i11iiII
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 2 - 2: i1111 / OooOoO0Oo
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for OoOoO0oOOooo , oo0 , Ooii1IIi1ii in os . walk ( IiIi11iIIi1Ii ) :
   oo0OoOOooO = 0
   oo0OoOOooO += len ( Ooii1IIi1ii )
   if oo0OoOOooO > 0 :
    for OooO0 in Ooii1IIi1ii :
     try :
      if ( OooO0 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( OoOoO0oOOooo , OooO0 ) )
     except :
      pass
    for o0o0OO0o00o0O in oo0 :
     try :
      shutil . rmtree ( os . path . join ( OoOoO0oOOooo , o0o0OO0o00o0O ) )
     except :
      pass
      if 28 - 28: oo - OooooO0oOO + OOO0O + i1IIiiiii / ooO0oo0oO0
   else :
    pass
    if 26 - 26: ooO0oo0oO0 - oooO0oo0oOOOO . oooO0oo0oOOOO
 if os . path . exists ( Oo0O ) == True :
  for OoOoO0oOOooo , oo0 , Ooii1IIi1ii in os . walk ( Oo0O ) :
   oo0OoOOooO = 0
   oo0OoOOooO += len ( Ooii1IIi1ii )
   if oo0OoOOooO > 0 :
    for OooO0 in Ooii1IIi1ii :
     try :
      if ( OooO0 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( OoOoO0oOOooo , OooO0 ) )
     except :
      pass
    for o0o0OO0o00o0O in oo0 :
     try :
      shutil . rmtree ( os . path . join ( OoOoO0oOOooo , o0o0OO0o00o0O ) )
     except :
      pass
      if 68 - 68: oOo0 + OooooO0oOO . oooO0oo0oOOOO . i1IIiiiii % II1Ii1iI1i % oOo0
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  i1I1iIoOOoO = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 87 - 87: OOO0O % ooO0oo0oO0
  for OoOoO0oOOooo , oo0 , Ooii1IIi1ii in os . walk ( i1I1iIoOOoO ) :
   oo0OoOOooO = 0
   oo0OoOOooO += len ( Ooii1IIi1ii )
   if 72 - 72: oOo0 . oOo0 - i11iiII
   if oo0OoOOooO > 0 :
    for OooO0 in Ooii1IIi1ii :
     os . unlink ( os . path . join ( OoOoO0oOOooo , OooO0 ) )
    for o0o0OO0o00o0O in oo0 :
     shutil . rmtree ( os . path . join ( OoOoO0oOOooo , o0o0OO0o00o0O ) )
     if 48 - 48: I11i1i11i1I - iiIIiIiIi + I11i1i11i1I - i1IIi11111i * i11iIiiIii . i1iIIIiI1I
   else :
    pass
  I1iIIIiI = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 60 - 60: i1IIi11111i . i11iIiiIii + OOO0O / i11iiII * i1111 * oOo0
  for OoOoO0oOOooo , oo0 , Ooii1IIi1ii in os . walk ( I1iIIIiI ) :
   oo0OoOOooO = 0
   oo0OoOOooO += len ( Ooii1IIi1ii )
   if 59 - 59: I11i1i11i1I + i1iIIIiI1I - oOo0 . oo0ooO0oOOOOo + i1IIi11111i % OooooO0oOO
   if oo0OoOOooO > 0 :
    for OooO0 in Ooii1IIi1ii :
     os . unlink ( os . path . join ( OoOoO0oOOooo , OooO0 ) )
    for o0o0OO0o00o0O in oo0 :
     shutil . rmtree ( os . path . join ( OoOoO0oOOooo , o0o0OO0o00o0O ) )
     if 37 - 37: i1iIIIiI1I + i1iIIIiI1I % oo0ooO0oOOOOo
   else :
    pass
    if 29 - 29: iiIIiIiIi
 O0ooOooooO = iI ( )
 if 41 - 41: oooO0oo0oOOOO % i1iIIIiI1I
 for i1iIi1IIiIII1 in O0ooOooooO :
  i1Ii11I1II = xbmc . translatePath ( i1iIi1IIiIII1 . path )
  if os . path . exists ( i1Ii11I1II ) == True :
   for OoOoO0oOOooo , oo0 , Ooii1IIi1ii in os . walk ( i1Ii11I1II ) :
    oo0OoOOooO = 0
    oo0OoOOooO += len ( Ooii1IIi1ii )
    if oo0OoOOooO > 0 :
     for OooO0 in Ooii1IIi1ii :
      os . unlink ( os . path . join ( OoOoO0oOOooo , OooO0 ) )
     for o0o0OO0o00o0O in oo0 :
      shutil . rmtree ( os . path . join ( OoOoO0oOOooo , o0o0OO0o00o0O ) )
      if 77 - 77: OooooO0oOO - I11i1i11i1I - ooO0oo0oO0
    else :
     pass
     if 16 - 16: oo / i1iIIIiI1I / II1Ii1iI1i . i1iIIIiI1I + OooooO0oOO
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 26 - 26: ooO0oo0oO0 + II1Ii1iI1i / OOO0O % i11iiII
def IiiIi11Ii1iI1 ( ) :
 oOo00o = [ ]
 II111i1ii1iII = sys . argv [ 2 ]
 if len ( II111i1ii1iII ) >= 2 :
  oOOo0OOOOo0Oo = sys . argv [ 2 ]
  ooo0OoO = oOOo0OOOOo0Oo . replace ( '?' , '' )
  if ( oOOo0OOOOo0Oo [ len ( oOOo0OOOOo0Oo ) - 1 ] == '/' ) :
   oOOo0OOOOo0Oo = oOOo0OOOOo0Oo [ 0 : len ( oOOo0OOOOo0Oo ) - 2 ]
  iiI1111I11i1I = ooo0OoO . split ( '&' )
  oOo00o = { }
  for Iii1IIII11I in range ( len ( iiI1111I11i1I ) ) :
   O00oOo0O0o00O = { }
   O00oOo0O0o00O = iiI1111I11i1I [ Iii1IIII11I ] . split ( '=' )
   if ( len ( O00oOo0O0o00O ) ) == 2 :
    oOo00o [ O00oOo0O0o00O [ 0 ] ] = O00oOo0O0o00O [ 1 ]
 return oOo00o
 if 91 - 91: i1111 * i1iIIIiI1I . II1Ii1iI1i
def Oo0oOOo ( name , url , mode , iconimage , fanart , description = '' ) :
 if 22 - 22: OooooO0oOO * i1IIiiiii * i11iIiiIii + i1iIIIiI1I * OOO0O * oo
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 O000OOO00Ooo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OoOOoooO000 = True
 ooO00o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 ooO00o . setProperty ( "fanart_Image" , fanart )
 ooO00o . setProperty ( "icon_Image" , iconimage )
 OoOOoooO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O000OOO00Ooo , listitem = ooO00o , isFolder = True )
 return OoOOoooO000
 if 85 - 85: i1IIi11111i % oo0Ooo0 + oOo0 / i1IIiiiii % i111I
def oO0o0OOOO ( name , url , mode , iconimage , fanart , description = '' ) :
 if 42 - 42: OooOoO0Oo * OoO000
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 O000OOO00Ooo = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OoOOoooO000 = True
 ooO00o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 ooO00o . setProperty ( "fanart_Image" , fanart )
 ooO00o . setProperty ( "icon_Image" , iconimage )
 OoOOoooO000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O000OOO00Ooo , listitem = ooO00o , isFolder = False )
 return OoOOoooO000
 if 23 - 23: OooooO0oOO * OooOoO0Oo - i111I * i111I % oo + i1111
oOOo0OOOOo0Oo = IiiIi11Ii1iI1 ( ) ; i1iI11i1ii11 = None ; i1OOO = None ; ii1I1I1i1i11i = None ; iI1i1IIiiiI1 = None ; iI1iIIiiii = None ; OooOoooOo = None
try : iI1i1IIiiiI1 = urllib . unquote_plus ( oOOo0OOOOo0Oo [ "site" ] )
except : pass
try : i1iI11i1ii11 = urllib . unquote_plus ( oOOo0OOOOo0Oo [ "url" ] )
except : pass
try : i1OOO = urllib . unquote_plus ( oOOo0OOOOo0Oo [ "name" ] )
except : pass
try : ii1I1I1i1i11i = int ( oOOo0OOOOo0Oo [ "mode" ] )
except : pass
try : iI1iIIiiii = urllib . unquote_plus ( oOOo0OOOOo0Oo [ "iconimage" ] )
except : pass
try : OooOoooOo = urllib . unquote_plus ( oOOo0OOOOo0Oo [ "fanart" ] )
except : pass
if 37 - 37: i11iIiiIii + i1IIi11111i . oOo0 % oo0Ooo0 % oo0Ooo0
if ii1I1I1i1i11i == None or i1iI11i1ii11 == None or len ( i1iI11i1ii11 ) < 1 : i11 ( )
elif ii1I1I1i1i11i == 1 : II1iiiIi1 ( i1OOO , i1iI11i1ii11 )
elif ii1I1I1i1i11i == 2 : i111iIi1i1II1 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 3 : oO00O000oO0 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 4 : PLAYSD ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 7 : II1i111Ii1i ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 8 : O0oOo00o ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 9 : AUTO_UPDATER ( i1OOO )
elif ii1I1I1i1i11i == 10 : iI1iii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 11 : I1ii11 ( )
elif ii1I1I1i1i11i == 12 : II1IiiIii ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 19 : O00OO0oO ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 20 : ooO000O ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 21 : oOooOO ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 22 : o0oo ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 23 : O000o0 ( )
elif ii1I1I1i1i11i == 24 : Ii1i1iI ( )
elif ii1I1I1i1i11i == 25 : OooO0oo ( )
elif ii1I1I1i1i11i == 26 : I11Ii ( )
elif ii1I1I1i1i11i == 30 : iiiI ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 40 : OOOOOOoO ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 41 : OOoo0 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 50 : iiIi1I1i1 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 51 : iiIIii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 60 : iI1IiiiI11 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 61 : iiIIi ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 70 : i1iii1ii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 71 : o0O0oO0 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 80 : I1ii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 90 : I1 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 91 : ooo ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 95 : iIiiI1iI ( )
elif ii1I1I1i1i11i == 96 : Ii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 97 : I1iii11 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 100 : IiI1O0oO ( )
elif ii1I1I1i1i11i == 500 : ooOo000OoO0o ( )
elif ii1I1I1i1i11i == 201 : Oo0 ( )
elif ii1I1I1i1i11i == 202 : OOO0oOOoo ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 203 : Oo00OoOo ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 204 : OoO00 ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 205 : o0 ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 206 : oO0o00oOOooO0 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 210 : IIiiIIi1 ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 220 : ii1IIIIiI11 ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 221 : oO0Ooo0ooOO0 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 222 : iIiii1iI1 ( i1iI11i1ii11 )
elif ii1I1I1i1i11i == 800 : I1ii1 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif ii1I1I1i1i11i == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 26 - 26: oooO0oo0oOOOO
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if ii1I1I1i1i11i == 80 :
 xbmc . sleep ( 10000 )
 xbmc . executebuiltin ( 'Container.Refresh' )