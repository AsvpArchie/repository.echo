import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
import datetime
from resources . lib . modules import regex
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
II1 = xbmcgui . Dialog ( )
O00ooooo00 = xbmcgui . DialogProgress ( )
I1IiiI = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
I11i11Ii = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
OOOo0 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
if 59 - 59: I11i / Ii1I
#######################################################################
#						Cache Functions
#######################################################################
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
class O0oOO0o0 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 9 - 9: o0o - OOO0o0o
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 40 - 40: II / oo00 * i1I1Ii1iI1ii * o0oOoO00o . i1
oOOoo00O0O = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 15 - 15: I11iii11IIi
class O00o0o0000o0o :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 88 - 88: o0ooo / OOO0O / I1ii * oOOOo0o0O + i1 % o0oOoO00o
  if 37 - 37: o0oOoO00o
  if 34 - 34: i1 * ooOoO0o
  if 31 - 31: I1Ii111 + o0o . I1ii
def OoOooOOOO ( ) :
 i11iiII = 5
 I1iiiiI1iII = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 IiIi11i = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 43 - 43: II * I11i
 I111I11 = [ ]
 if 62 - 62: o0ooo - OOO0O - OOO0o0o % IiII / i1I1Ii1iI1ii
 for OoooooOoo in range ( i11iiII ) :
  I111I11 . append ( O00o0o0000o0o ( I1iiiiI1iII [ OoooooOoo ] , IiIi11i [ OoooooOoo ] ) )
  if 70 - 70: o0o . o0o - o0o / oo00 * o0oOoO00o
 return I111I11
 if 86 - 86: i11iIiiIii + I11iii11IIi + oOOOo0o0O * i1 + II
def oOoO ( ) :
 if 68 - 68: OOO0o0o . i1I1Ii1iI1ii . i11iIiiIii
 IIiI = open ( I1IiiI ) . read ( )
 iI11iiiI1II = IIiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0oooo0Oo00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iI11iiiI1II ) )
 for Ii11iii11I in O0oooo0Oo00 :
  oOo00Oo00O = float ( Ii11iii11I )
  if 43 - 43: ooOoO0o - o0ooo * Ii1I
 O0O00o0OOO0 = Ii1iIIIi1ii ( ooo0OO )
 O0O00o0OOO0 = base64 . b64decode ( O0O00o0OOO0 )
 O0O00o0OOO0 = O0O00o0OOO0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 80 - 80: i1 * i11iIiiIii / I1ii
  if '<search>ZGlzcGxheQ==</search>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   IIIII ( I11II1i , ooo0OO , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 75 - 75: I1Ii111 % I1Ii111
  elif '<vip>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   IIIII ( I11II1i , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 13 - 13: II . I11iii11IIi
  elif '<divider>bnVsbA==</divider>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   i11Iiii ( I11II1i , ooo0OO , 999 , iiiii , O0O0OO0O0O0 )
   if 23 - 23: II . I1Ii111
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   IIIII ( I11II1i , ooo0OO , 11 , iiiii , O0O0OO0O0O0 )
   if 98 - 98: Ii1I % OOO0o0o * oo00 * OOO0o0o
   if 45 - 45: I1ii . OOO0o0o
   if 83 - 83: i1I1Ii1iI1ii . Ii1I . oo00
   if 31 - 31: I11iii11IIi . I11iii11IIi - II / o0o + oOOOo0o0O * ooOoO0o
   if 63 - 63: I1ii % IiII / iII111i - iII111i
   if 8 - 8: OOO0o0o
   if 60 - 60: i1 / i1
   if 46 - 46: I11iii11IIi * o0oOoO00o - o0o * i1I1Ii1iI1ii - I1ii
   if 83 - 83: iII111i
   if 31 - 31: I1Ii111 - o0oOoO00o . I1ii % OOO0o0o - I11i
   if 4 - 4: I1Ii111 / oOOOo0o0O . o0ooo
   if 58 - 58: o0oOoO00o * i11iIiiIii / OOO0o0o % I1ii - oo00 / i1I1Ii1iI1ii
   if 50 - 50: ooOoO0o
   if 34 - 34: ooOoO0o * I1Ii111 % o0ooo * OOO0o0o - ooOoO0o
   if 33 - 33: II + o0oOoO00o * o0o - o00O0oo / i1I1Ii1iI1ii % I11iii11IIi
   if 21 - 21: o0o * Ii1I % i1I1Ii1iI1ii * IiII
   if 16 - 16: I11i - I1ii * Ii1I + o0ooo
   if 50 - 50: I1Ii111 - oOOOo0o0O * oo00 / I1ii + II
   if 88 - 88: I11iii11IIi / I1ii + o0ooo - I1Ii111 / oOOOo0o0O - OOO0o0o
   if 15 - 15: oo00 + OOO0o0o - iII111i / o0oOoO00o
   if 58 - 58: i11iIiiIii % i1
   if 71 - 71: o0oOoO00o + oOOOo0o0O % i11iIiiIii + oo00 - OOO0O
  elif '<sportsdevil>' in Ii11iii11I :
   oO0OOoO0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii11iii11I )
   if len ( oO0OOoO0 ) == 1 :
    I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    i111IiI1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii11iii11I ) [ 0 ]
    O0 = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii11iii11I ) [ 0 ]
    I11II1i = base64 . b64decode ( I11II1i )
    I111Ii111 = base64 . b64decode ( I111Ii111 )
    i111IiI1I = base64 . b64decode ( i111IiI1I )
    O0 = base64 . b64decode ( O0 )
    iII = O0
    o0 = "/"
    if not iII . endswith ( o0 ) :
     ooOooo000oOO = iII + "/"
    else :
     ooOooo000oOO = iII
    O0O00o0OOO0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( I11II1i ) + '%26url=' + i111IiI1I
    i111IiI1I = O0O00o0OOO0 + '%26referer=' + ooOooo000oOO
    i11Iiii ( I11II1i , i111IiI1I , 4 , I111Ii111 , Oo0oOOo )
   elif len ( oO0OOoO0 ) > 1 :
    I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    I11II1i = base64 . b64decode ( I11II1i )
    I111Ii111 = base64 . b64decode ( I111Ii111 )
    i11Iiii ( I11II1i , url2 + 'NOTPLAY' , 8 , I111Ii111 , Oo0oOOo )
    if 58 - 58: I1Ii111 * o0oOoO00o * oo00 / o0oOoO00o
  elif '<folder>' in Ii11iii11I :
   oO0o0OOOO = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
   for I11II1i , i111IiI1I , I111Ii111 , Oo0oOOo in oO0o0OOOO :
    I11II1i = base64 . b64decode ( I11II1i )
    i111IiI1I = base64 . b64decode ( i111IiI1I )
    I111Ii111 = base64 . b64decode ( I111Ii111 )
    Oo0oOOo = base64 . b64decode ( Oo0oOOo )
    IIIII ( I11II1i , i111IiI1I , 1 , I111Ii111 , Oo0oOOo )
  elif '<m3u>' in Ii11iii11I :
   oO0o0OOOO = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
   for I11II1i , i111IiI1I , I111Ii111 , Oo0oOOo in oO0o0OOOO :
    I11II1i = base64 . b64decode ( I11II1i )
    i111IiI1I = base64 . b64decode ( i111IiI1I )
    I111Ii111 = base64 . b64decode ( I111Ii111 )
    Oo0oOOo = base64 . b64decode ( Oo0oOOo )
    IIIII ( I11II1i , i111IiI1I , 10 , I111Ii111 , Oo0oOOo )
  else :
   oO0OOoO0 = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii11iii11I )
   if len ( oO0OOoO0 ) == 1 :
    oO0o0OOOO = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
    O0O0OoOO0 = len ( O0oooo0Oo00 )
    for I11II1i , i111IiI1I , I111Ii111 , Oo0oOOo in oO0o0OOOO :
     I11II1i = base64 . b64decode ( I11II1i )
     i111IiI1I = base64 . b64decode ( i111IiI1I )
     I111Ii111 = base64 . b64decode ( I111Ii111 )
     Oo0oOOo = base64 . b64decode ( Oo0oOOo )
     i11Iiii ( I11II1i , i111IiI1I , 2 , I111Ii111 , Oo0oOOo )
   elif len ( oO0OOoO0 ) > 1 :
    I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    Oo0oOOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
    I11II1i = base64 . b64decode ( I11II1i )
    I111Ii111 = base64 . b64decode ( I111Ii111 )
    Oo0oOOo = base64 . b64decode ( Oo0oOOo )
    i11Iiii ( I11II1i , ooo0OO , 3 , I111Ii111 , Oo0oOOo )
    if 10 - 10: iII111i % Ii1I
 i11Iiii ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , ooo0OO , 500 , iiiii , O0O0OO0O0O0 , "" )
 i11Iiii ( '[COLOR dodgerblue]VER ' + str ( oOo00Oo00O ) + '[/COLOR][COLOR yellow] - CHECK FOR UPDATES[/COLOR]' , ooo0OO , 9 , iiiii , O0O0OO0O0O0 , "" )
 if 54 - 54: I1ii - I1Ii111 % OOO0o0o % i1 % Ii1I + oOOOo0o0O
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 15 - 15: i1 * oOOOo0o0O * o00O0oo % i11iIiiIii % OOO0o0o - o0oOoO00o
def O0ooo0O0oo0 ( name , url ) :
 if 91 - 91: Ii1I + I1ii
 hash = [ ]
 i1i = url
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 if 46 - 46: I1ii % i1 + o0o . OOO0o0o . o0o
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 96 - 96: o00O0oo
  if '<regex>' in Ii11iii11I :
   Ii1I1IIii1II = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Ii11iii11I )
   Ii1I1IIii1II = '' . join ( Ii1I1IIii1II )
   O0ii1ii1ii = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( Ii1I1IIii1II )
   Ii1I1IIii1II = urllib . quote_plus ( Ii1I1IIii1II )
   if 91 - 91: OOO0O
   iiIii = hashlib . md5 ( )
   for ooo0O in Ii1I1IIii1II : iiIii . update ( str ( ooo0O ) )
   iiIii = str ( iiIii . hexdigest ( ) )
   if 75 - 75: II % II . I1ii
   Ii11iii11I = Ii11iii11I . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Ii11iii11I = re . sub ( '<regex>.+?</regex>' , '' , Ii11iii11I )
   Ii11iii11I = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Ii11iii11I )
   Ii11iii11I = re . sub ( '<link></link>' , '' , Ii11iii11I )
   if 5 - 5: II * oOOOo0o0O + OOO0o0o . o0oOoO00o + OOO0o0o
   name = re . sub ( '<meta>.+?</meta>' , '' , Ii11iii11I )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 91 - 91: I11i
   try : oOOo0 = re . findall ( '<date>(.+?)</date>' , Ii11iii11I ) [ 0 ]
   except : oOOo0 = ''
   if re . search ( r'\d+' , oOOo0 ) : name += ' [COLOR red] Updated %s[/COLOR]' % oOOo0
   if 54 - 54: I11i - OOO0O % o0oOoO00o
   try : OOoO = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Ii11iii11I ) [ 0 ]
   except : OOoO = iiiii
   if 46 - 46: o0o . o00O0oo - iII111i
   try : ooo00OOOooO = re . findall ( '<fanart>(.+?)</fanart>' , Ii11iii11I ) [ 0 ]
   except : ooo00OOOooO = O0O0OO0O0O0
   if 67 - 67: i1 * i1I1Ii1iI1ii * oo00 + o0oOoO00o / IiII
   try : I1I111 = re . findall ( '<meta>(.+?)</meta>' , Ii11iii11I ) [ 0 ]
   except : I1I111 = '0'
   if 82 - 82: i11iIiiIii - o0ooo * iII111i / i1
   try : url = re . findall ( '<link>(.+?)</link>' , Ii11iii11I ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % I1I111 )
   url = '<preset>search</preset>%s' % I1I111 if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % I1I111 )
   url = '<preset>searchsd</preset>%s' % I1I111 if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 31 - 31: OOO0O . o0o - Ii1I
   if not Ii1I1IIii1II == '' :
    hash . append ( { 'regex' : iiIii , 'response' : Ii1I1IIii1II } )
    url += '|regex=%s' % Ii1I1IIii1II
    if 64 - 64: i1
   i11Iiii ( name , url , 30 , OOoO , ooo00OOOooO )
   if 22 - 22: o00O0oo + I11iii11IIi % oo00
  elif '<sportsdevil>' in Ii11iii11I :
   oO0OOoO0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii11iii11I )
   if len ( oO0OOoO0 ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     O0 = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii11iii11I ) [ 0 ]
    except : O0 = "None"
    I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     Oo0oOOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
    except : Oo0oOOo = O0O0OO0O0O0
    iII = O0
    o0 = "/"
    if not iII . endswith ( o0 ) :
     ooOooo000oOO = iII + "/"
    else :
     ooOooo000oOO = iII
    O0O00o0OOO0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = O0O00o0OOO0 + '%26referer=' + ooOooo000oOO
    i11Iiii ( name , url , 2 , I111Ii111 , Oo0oOOo )
    if 9 - 9: iII111i
   elif len ( oO0OOoO0 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     Oo0oOOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
    except : Oo0oOOo = O0O0OO0O0O0
    i11Iiii ( name , i1i + 'NOTPLAY' , 8 , I111Ii111 , Oo0oOOo )
    if 62 - 62: o0oOoO00o / o0o + I11iii11IIi / o0o . I1Ii111
  elif '<folder>' in Ii11iii11I :
   oO0o0OOOO = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
   for name , url , I111Ii111 , Oo0oOOo in oO0o0OOOO :
    IIIII ( name , url , 1 , I111Ii111 , Oo0oOOo )
    if 68 - 68: i11iIiiIii % oo00 + i11iIiiIii
  elif '<m3u>' in Ii11iii11I :
   oO0o0OOOO = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
   for name , url , I111Ii111 , Oo0oOOo in oO0o0OOOO :
    IIIII ( name , url , 10 , I111Ii111 , Oo0oOOo )
    if 31 - 31: I1Ii111 . ooOoO0o
  else :
   oO0OOoO0 = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii11iii11I )
   if len ( oO0OOoO0 ) == 1 :
    oO0o0OOOO = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
    O0O0OoOO0 = len ( O0oooo0Oo00 )
    for name , url , I111Ii111 , Oo0oOOo in oO0o0OOOO :
     i11Iiii ( name , url , 2 , I111Ii111 , Oo0oOOo )
   elif len ( oO0OOoO0 ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     Oo0oOOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
    except : Oo0oOOo = O0O0OO0O0O0
    i11Iiii ( name , i1i , 3 , I111Ii111 , Oo0oOOo )
    if 1 - 1: o00O0oo / II % o0ooo * OOO0O . i11iIiiIii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 2 - 2: oo00 * i1 - Ii1I + ooOoO0o . i1I1Ii1iI1ii % o0ooo
def ooOOOoOooOoO ( name , url , iconimage ) :
 o00oooO0Oo = [ ]
 o0O0OOO0Ooo = [ ]
 iiIiI = [ ]
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 I1 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0O00o0OOO0 ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I1 ) [ 0 ]
 oO0OOoO0 = re . compile ( '<link>(.+?)</link>' ) . findall ( I1 )
 ooo0O = 1
 for OOO00O0O in oO0OOoO0 :
  iii = OOO00O0O
  if '(' in OOO00O0O :
   OOO00O0O = OOO00O0O . split ( '(' ) [ 0 ]
   oOooOOOoOo = str ( iii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   o00oooO0Oo . append ( OOO00O0O )
   o0O0OOO0Ooo . append ( oOooOOOoOo )
  else :
   o00oooO0Oo . append ( OOO00O0O )
   o0O0OOO0Ooo . append ( 'Link ' + str ( ooo0O ) )
  ooo0O = ooo0O + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 II1 = xbmcgui . Dialog ( )
 i1Iii1i1I = II1 . select ( name , o0O0OOO0Ooo )
 if i1Iii1i1I < 0 :
  quit ( )
 else :
  url = o00oooO0Oo [ i1Iii1i1I ]
  print url
  if 91 - 91: oo00 + ooOoO0o . o0oOoO00o * oo00 + ooOoO0o * o00O0oo
 url = o00oooO0Oo [ i1Iii1i1I ]
 name = o0O0OOO0Ooo [ i1Iii1i1I ]
 O000OOOOOo ( name , url , iiiii )
 if 22 - 22: IiII + I11i . Ii1I * o0ooo % i11iIiiIii * ooOoO0o
def oo000o ( name , url , iconimage ) :
 if 44 - 44: IiII % I1Ii111 + i1
 o00oooO0Oo = [ ]
 o0O0OOO0Ooo = [ ]
 iiIiI = [ ]
 I1I1I = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 I1 = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0O00o0OOO0 ) [ 0 ]
 oO0OOoO0 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( I1 )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I1 ) [ 0 ]
 if 95 - 95: I1Ii111 + II + o0ooo * Ii1I % i1I1Ii1iI1ii / OOO0O
 o0o0o0oO0oOO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 3 - 3: II
 ooo0O = 1
 if 24 - 24: i11iIiiIii + o0ooo * I11iii11IIi - I1Ii111 . o0oOoO00o % Ii1I
 for OOO00O0O in oO0OOoO0 :
  iii = OOO00O0O
  if '(' in OOO00O0O :
   OOO00O0O = OOO00O0O . split ( '(' ) [ 0 ]
   oOooOOOoOo = str ( iii . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   o00oooO0Oo . append ( OOO00O0O )
   o0O0OOO0Ooo . append ( oOooOOOoOo )
   I1I1I . append ( 'Stream ' + str ( ooo0O ) )
  else :
   o00oooO0Oo . append ( OOO00O0O )
   o0O0OOO0Ooo . append ( 'Link ' + str ( ooo0O ) )
   if 71 - 71: I11i . o0ooo / II
  ooo0O = ooo0O + 1
  if 73 - 73: I1Ii111 . i11iIiiIii / I11iii11IIi + OOO0o0o
 name = '[COLOR red]' + name + '[/COLOR]'
 if 12 - 12: i11iIiiIii - IiII - o0o . IiII - o0oOoO00o + I11i
 II1 = xbmcgui . Dialog ( )
 i1Iii1i1I = II1 . select ( name , o0O0OOO0Ooo )
 if i1Iii1i1I < 0 :
  quit ( )
 else :
  iII = o0O0OOO0Ooo [ i1Iii1i1I ]
  o0 = "/"
  if not iII . endswith ( o0 ) :
   ooOooo000oOO = iII + "/"
  else :
   ooOooo000oOO = iII
  url = o0o0o0oO0oOO + o00oooO0Oo [ i1Iii1i1I ] + "%26referer=" + ooOooo000oOO
  if 98 - 98: II
 name = o0O0OOO0Ooo [ i1Iii1i1I ]
 O000OOOOOo ( name , url , iiiii )
 if 51 - 51: o00O0oo - i1I1Ii1iI1ii + I1Ii111 * I11iii11IIi . i1 + i1I1Ii1iI1ii
def OoO0o ( name , url , iconimage ) :
 if 78 - 78: i1I1Ii1iI1ii % I11i % I11iii11IIi
 ii , OoooooOoo = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 ii += urllib . unquote_plus ( OoooooOoo )
 url = regex . resolve ( ii )
 if 5 - 5: oOOOo0o0O - I1Ii111 - iII111i % I11iii11IIi + ooOoO0o * Ii1I
 O000OOOOOo ( name , url , iconimage )
 if 37 - 37: OOO0O % oOOOo0o0O + OOO0o0o + II * i1 % I11i
def OooOoOO0 ( ) :
 if 36 - 36: OOO0O
 i11Iiii ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 i11Iiii ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 i11Iiii ( "################################################################" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 IIIII ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , ooo0OO , 201 , iiiii , O0O0OO0O0O0 )
 IIIII ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 IIIII ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 36 - 36: oOOOo0o0O / I11i * o00O0oo - o0oOoO00o % Ii1I * i1I1Ii1iI1ii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 79 - 79: I11i
def oOO00O ( ) :
 if 77 - 77: o00O0oo - IiII - i1 . OOO0o0o
 IIIII ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , ooo0OO , 25 , iiiii , O0O0OO0O0O0 , '' )
 IIIII ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 39 - 39: I1Ii111 / oOOOo0o0O + I1ii / OOO0o0o
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 13 - 13: OOO0O + I11i + o0ooo % ooOoO0o / II . OOO0O
def OO0Oooo0oOO0O ( ) :
 if 62 - 62: ooOoO0o
 IIIII ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , ooo0OO , 23 , iiiii , O0O0OO0O0O0 , '' )
 IIIII ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 100 - 100: I11iii11IIi - I11i % i1I1Ii1iI1ii * o0oOoO00o + ooOoO0o
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 88 - 88: iII111i - o0o * I11i * iII111i . iII111i
def I111iI ( ) :
 if 56 - 56: ooOoO0o
 ooo0O = 0
 O0oO = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO )
 for Ii11iii11I in O0oooo0Oo00 :
  ooo0O = ooo0O + 1
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  i111IiI1I = Ii11iii11I
  IIIII ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ooo0O ) + '[/COLOR]' , i111IiI1I , 12 , iiiii , O0O0OO0O0O0 )
  if 73 - 73: oo00 * i11iIiiIii % i1I1Ii1iI1ii . oo00
 O0oO = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO )
 for Ii11iii11I in O0oooo0Oo00 :
  ooo0O = ooo0O + 1
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  i111IiI1I = Ii11iii11I
  IIIII ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ooo0O ) + '[/COLOR]' , i111IiI1I , 12 , iiiii , O0O0OO0O0O0 )
  if 66 - 66: i1I1Ii1iI1ii + i1I1Ii1iI1ii + oOOOo0o0O / o0ooo + o0oOoO00o
 O0oO = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO )
 for Ii11iii11I in O0oooo0Oo00 :
  ooo0O = ooo0O + 1
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  i111IiI1I = Ii11iii11I
  IIIII ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( ooo0O ) + '[/COLOR]' , i111IiI1I , 12 , iiiii , O0O0OO0O0O0 )
  if 30 - 30: I11i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 44 - 44: i1I1Ii1iI1ii / i1 / i1
def OOO ( url ) :
 if 32 - 32: IiII / I1Ii111 . o00O0oo
 O0oO = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( O0oO )
 if 62 - 62: iII111i * ooOoO0o
 for Ii11iii11I in O0oooo0Oo00 :
  I11II1i = re . compile ( 'title="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  I111Ii111 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  IIIII ( '[COLOR dodgerblue]' + I11II1i + '[/COLOR]' , url , 12 , I111Ii111 , O0O0OO0O0O0 )
  if 58 - 58: OOO0o0o % II
 try :
  i1OOoO = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( O0oO ) [ 0 ]
  IIIII ( '[COLOR yellow]Next Page -->[/COLOR]' , i1OOoO , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 89 - 89: II + o0o * i1 * I11iii11IIi
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 37 - 37: iII111i - I11i - II
def o0o0O0O00oOOo ( url ) :
 if 14 - 14: OOO0o0o + i1I1Ii1iI1ii
 O0oO = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( O0oO )
 for Ii11iii11I in O0oooo0Oo00 :
  try :
   I11II1i = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii11iii11I ) [ 0 ]
  except :
   I11II1i = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Ii11iii11I ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  IIIII ( '[COLOR dodgerblue]' + I11II1i + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 52 - 52: iII111i - oOOOo0o0O
def o0O0o0 ( url ) :
 if 37 - 37: oo00 * i1 % i11iIiiIii % oOOOo0o0O + I11iii11IIi
 O0oO = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( O0oO )
 OOoOO0o0o0 = 0
 for Ii11iii11I in O0oooo0Oo00 :
  try :
   I11II1i = re . compile ( 'title="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
   I111Ii111 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  except : OOoOO0o0o0 = 1
  if 11 - 11: ooOoO0o
  if OOoOO0o0o0 == 0 :
   IIIII ( '[COLOR dodgerblue]' + I11II1i + '[/COLOR]' , url , 12 , I111Ii111 , O0O0OO0O0O0 )
  OOoOO0o0o0 = 0
  if 16 - 16: I11iii11IIi + OOO0O * I11i % IiII . ooOoO0o
 try :
  i1OOoO = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( O0oO ) [ 0 ]
  IIIII ( '[COLOR yellow]Next Page -->[/COLOR]' , i1OOoO , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 67 - 67: iII111i / ooOoO0o * I11iii11IIi + i1
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 65 - 65: iII111i - oo00 / oOOOo0o0O / I1Ii111 / IiII
def o00oo0 ( url ) :
 if 38 - 38: oOOOo0o0O % I1Ii111 % i1 / o0o + OOO0o0o / IiII
 OoOOo0OOoO = datetime . date . today ( )
 ooO0O00Oo0o = datetime . datetime . strftime ( OoOOo0OOoO , '%A %d %B %Y' )
 if 65 - 65: oo00 . i1 - I1ii * OOO0O / I1ii / oOOOo0o0O
 i11Iiii ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( ooO0O00Oo0o ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 i11Iiii ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 40 - 40: oOOOo0o0O * OOO0O * i11iIiiIii
 O0oO = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( O0oO )
 OOoOO0o0o0 = 0
 ooo0O = 0
 for Ii11iii11I in O0oooo0Oo00 :
  try :
   oo0OO00OoooOo = re . compile ( 'title="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
   try :
    II1i111Ii1i = re . compile ( '<p>(.+?)</p>' ) . findall ( Ii11iii11I ) [ 0 ]
   except : II1i111Ii1i = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Ii11iii11I ) [ 0 ]
   I111Ii111 = re . compile ( '<img src="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  except : OOoOO0o0o0 = 1
  if 15 - 15: I1Ii111 / IiII
  if OOoOO0o0o0 == 0 :
   if 'vs' in oo0OO00OoooOo :
    I11II1i = '[COLOR dodgerblue]' + oo0OO00OoooOo + ' - ' + '[/COLOR][COLOR green]' + II1i111Ii1i + '[/COLOR]'
    ooo0O = ooo0O + 1
    i11Iiii ( I11II1i , url , 206 , I111Ii111 , O0O0OO0O0O0 , '' )
  OOoOO0o0o0 = 0
  if 76 - 76: i1 / o0oOoO00o . I11i % ooOoO0o . II + OOO0O
 if ooo0O == 0 :
  II1 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 71 - 71: I1ii . I1Ii111
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 62 - 62: iII111i . i1
def oOOOoo00 ( name , url , iconimage ) :
 if 9 - 9: I11i % I11i - II
 O0oO = Ii1iIIIi1ii ( url )
 OoO = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( O0oO ) [ 0 ]
 if 12 - 12: I11i - II
 if not "http" in OoO :
  OoO = OoO . replace ( "//" , "" )
  url = "http://" + OoO
 else :
  url = OoO
  if 81 - 81: OOO0o0o - OOO0o0o . o0ooo
 o0OoOo00o0o = url
 if 41 - 41: oOOOo0o0O % o0o - o00O0oo * I1ii * o00O0oo
 OOOoOO0o = Ii1iIIIi1ii ( url )
 OoO = re . compile ( "atob(.+?)," ) . findall ( OOOoOO0o ) [ 0 ]
 OoO = OoO . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( OoO )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + o0OoOo00o0o + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 O000OOOOOo ( name , url , iconimage )
 if 1 - 1: I1Ii111
def O0oOo00o ( url ) :
 if 81 - 81: OOO0O % IiII . Ii1I
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 4 - 4: i11iIiiIii % o0o % IiII / OOO0O
  if '<display>eWVz</display>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii11iii11I ) [ 0 ]
   I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
   Oo0oOOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   url = base64 . b64decode ( url )
   I111Ii111 = base64 . b64decode ( I111Ii111 )
   Oo0oOOo = base64 . b64decode ( Oo0oOOo )
   IIIII ( I11II1i , url , 220 , I111Ii111 , Oo0oOOo , '' )
   if 6 - 6: o0ooo / ooOoO0o % o0oOoO00o - ooOoO0o
def iiii111II ( url ) :
 if 50 - 50: o0oOoO00o * ooOoO0o % Ii1I + I11iii11IIi + o0ooo + ooOoO0o
 O0oO = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( O0oO )
 if 71 - 71: oo00 * oo00 * IiII . i1I1Ii1iI1ii / I1ii
 for Ii11iii11I in O0oooo0Oo00 :
  I11II1i = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Ii11iii11I ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Ii11iii11I ) [ 0 ]
  try :
   ooo0O0o00O = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Ii11iii11I ) [ 0 ]
  except : ooo0O0o00O = "SD"
  ooo0O0o00O = '[COLOR yellow]' + ooo0O0o00O + '[/COLOR]'
  I111Ii111 = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  I11II1i = I11II1i . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 48 - 48: oOOOo0o0O / I1ii . Ii1I * OOO0o0o * i1I1Ii1iI1ii / IiII
  i11Iiii ( '[COLOR mediumpurple]' + I11II1i + '[/COLOR] - ' + ooo0O0o00O , url , 212 , I111Ii111 , O0O0OO0O0O0 , '' )
  if 92 - 92: o00O0oo % o00O0oo - II / OOO0o0o
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( O0oO ) [ 0 ]
  I11IIIi = 'http://www.fmovies.se/' + url
  IIIII ( "Next Page -->" , I11IIIi , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 15 - 15: oo00 * o0o
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 16 - 16: o0ooo + OOO0o0o
def O00OO ( url ) :
 if 17 - 17: i1 / I1ii + i1I1Ii1iI1ii - i11iIiiIii . o0ooo
 O0oO = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( O0oO )
 if 95 - 95: o0o % IiII * i11iIiiIii % o00O0oo - i1I1Ii1iI1ii
 if 67 - 67: OOO0o0o + oo00 . II . I1Ii111
def o000ooooO0o ( url ) :
 if 40 - 40: oo00 + IiII * o0oOoO00o
 if "iptvembed" in url :
  O0oO = Ii1iIIIi1ii ( url )
  O0oooo0Oo00 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( O0oO )
  for Ii11iii11I in O0oooo0Oo00 :
   Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
   Ii11iii11I = Ii11iii11I . replace ( '</pre>' , '' )
   url = Ii11iii11I
   if 85 - 85: I11iii11IIi * o00O0oo . I11i - i11iIiiIii
 if "sourcetv" in url :
  O0oO = Ii1iIIIi1ii ( url )
  O0oooo0Oo00 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( O0oO )
  for Ii11iii11I in O0oooo0Oo00 :
   Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
   Ii11iii11I = Ii11iii11I . replace ( '</pre>' , '' )
   url = Ii11iii11I
   if 18 - 18: I11iii11IIi + OOO0O - I11i
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 i1Ii1i1I11Iii = [ ]
 for I1i1i1 , OoO0O00O0oo0O , url in o00O :
  I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : url }
  i1Ii1i1I11Iii . append ( I1IiI11 )
 list = [ ]
 for iI1iiiiIii in i1Ii1i1I11Iii :
  I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
  o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
  for iIiIiIiI , i11 in o00O :
   I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11 . strip ( )
  list . append ( I1IiI11 )
  if 98 - 98: o00O0oo / ooOoO0o . I11i + o0o
 iiIiii1iI1i = 0
 for iI1iiiiIii in list :
  iiIiii1iI1i = 1
  I11II1i = I1ii1ii11i1I ( iI1iiiiIii [ "display_name" ] )
  url = I1ii1ii11i1I ( iI1iiiiIii [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   i11Iiii ( '[COLOR mediumpurple]' + I11II1i + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   IIIII ( '[COLOR mediumpurple]' + I11II1i + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 58 - 58: o0ooo + o00O0oo
 if iiIiii1iI1i == 0 :
  i11Iiii ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 12 - 12: II - oo00 % OOO0o0o * i1
def i11IIIiI11 ( url ) :
 if 8 - 8: o0o + I1ii - II % o00O0oo % II * i1I1Ii1iI1ii
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 9 - 9: o00O0oo - i11iIiiIii - o0oOoO00o * I11iii11IIi + oOOOo0o0O
  I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
  iIIII = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii11iii11I ) [ 0 ]
  I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
  Oo0oOOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
  url = I11II1i + '!' + iIIII + '!' + I111Ii111
  IIIII ( '[COLOR blue]' + I11II1i + '[/COLOR]' , url , 20 , I111Ii111 , Oo0oOOo )
  if 45 - 45: oo00 % ooOoO0o - i11iIiiIii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 11 - 11: Ii1I * Ii1I * ooOoO0o
def iII1ii1 ( url ) :
 if 12 - 12: o0oOoO00o - oOOOo0o0O . iII111i / oo00 . IiII * o0o
 OoOOo0OOoO = datetime . date . today ( )
 ooO0O00Oo0o = datetime . datetime . strftime ( OoOOo0OOoO , '%A %d %B %Y' )
 if 19 - 19: i11iIiiIii + iII111i - o00O0oo - i1
 i11Iiii ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( ooO0O00Oo0o ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 i11Iiii ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 21 - 21: I11i % OOO0O . ooOoO0o / I1Ii111 + OOO0O
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 i1i = url
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 53 - 53: i1I1Ii1iI1ii - ooOoO0o - i1I1Ii1iI1ii * o0ooo
  oO0OOoO0 = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii11iii11I )
  if len ( oO0OOoO0 ) == 1 :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii11iii11I ) [ 0 ]
   I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
   url = I11II1i + "!" + url + "!" + I111Ii111
   I11II1i = '[COLOR mediumpurple]' + I11II1i + '[/COLOR]'
   IIIII ( I11II1i , url , 20 , I111Ii111 , I111Ii111 )
   if 71 - 71: I11i - Ii1I
   if 12 - 12: o0oOoO00o / II
  elif len ( oO0OOoO0 ) > 1 :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   I111Ii111 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
   url = i1i + "!" + I11II1i + "!" + I111Ii111
   I11II1i = '[COLOR mediumpurple]' + I11II1i + '[/COLOR]'
   IIIII ( I11II1i , url , 22 , I111Ii111 , I111Ii111 )
   if 42 - 42: o00O0oo
   if 19 - 19: i1I1Ii1iI1ii % oo00 * Ii1I + ooOoO0o
   if 46 - 46: o00O0oo
   if 1 - 1: o0ooo
   if 97 - 97: o0oOoO00o + o0ooo + I11i + i11iIiiIii
   if 77 - 77: II / iII111i
   if 46 - 46: II % Ii1I . o0ooo % o0ooo + i11iIiiIii
   if 72 - 72: Ii1I * I11iii11IIi % oOOOo0o0O / o0o
   if 35 - 35: oOOOo0o0O + IiII % oo00 % i1 + i1I1Ii1iI1ii
   if 17 - 17: IiII
   if 21 - 21: o00O0oo
   if 29 - 29: i1 / I1Ii111 / oOOOo0o0O * o0oOoO00o
   if 10 - 10: I1ii % OOO0O * OOO0O . i1 / I11iii11IIi % o0oOoO00o
def IIII1 ( ) :
 if 10 - 10: I1ii / oOOOo0o0O + i11iIiiIii / I11iii11IIi
 OoOOo0OOoO = datetime . date . today ( )
 ooO0O00Oo0o = datetime . datetime . strftime ( OoOOo0OOoO , '%A %d %B %Y' )
 if 74 - 74: o0oOoO00o + I11i + IiII - IiII + I1Ii111
 i11Iiii ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( ooO0O00Oo0o ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 i11Iiii ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 83 - 83: oo00 - ooOoO0o + o0oOoO00o
 O0O00o0OOO0 = Ii1iIIIi1ii ( 'http://www.oddschecker.com/tv-sports-calendar' )
 O0oooo0Oo00 = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( O0O00o0OOO0 )
 iIi1Ii1i1iI = str ( O0oooo0Oo00 )
 IIiI1 = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( iIi1Ii1i1iI )
 for Ii11iii11I in IIiI1 :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in Ii11iii11I :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Ii11iii11I ) [ 0 ]
    oo0OO00OoooOo = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Ii11iii11I ) [ 0 ]
    I111Ii111 = re . compile ( 'src="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     iIIII = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
     iIIII = i1iI1 ( iIIII )
    except : iIIII = "null"
    I11II1i = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + oo0OO00OoooOo + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    I11II1i = ii1 ( I11II1i )
    i111IiI1I = oo0OO00OoooOo + "!" + iIIII . lower ( ) + "!" + I111Ii111
    IIIII ( I11II1i , i111IiI1I , 20 , I111Ii111 , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Ii11iii11I ) [ 0 ]
    oo0OO00OoooOo = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     iIIII = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
    except : iIIII = "null"
    I111Ii111 = re . compile ( 'src="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
    I11II1i = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + oo0OO00OoooOo + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    I11II1i = ii1 ( I11II1i )
    i111IiI1I = oo0OO00OoooOo + "!" + iIIII . lower ( ) + "!" + I111Ii111
    IIIII ( I11II1i , i111IiI1I , 20 , I111Ii111 , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 1 - 1: oOOOo0o0O % Ii1I + o00O0oo . Ii1I % ooOoO0o
def o0o0oOoOO0O ( name , url , iconimage ) :
 if 16 - 16: OOO0O % Ii1I . I11iii11IIi
 try :
  url , oooooOOO000Oo , iconimage = url . split ( '!' )
 except :
  II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 52 - 52: I1Ii111 % OOO0O . OOO0o0o * Ii1I
 I111i1II = [ ]
 if 69 - 69: I11iii11IIi * I11i . i11iIiiIii / I11iii11IIi . II
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 I1 = re . compile ( '<title>' + re . escape ( oooooOOO000Oo ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0O00o0OOO0 ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( I1 ) [ 0 ]
 oO0OOoO0 = re . compile ( '<search>(.+?)</search>' ) . findall ( I1 )
 for OOO00O0O in oO0OOoO0 :
  I111i1II . append ( OOO00O0O )
  if 63 - 63: i1 + II . I1Ii111 - ooOoO0o
 O00ooooo00 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 O00ooooo00 . update ( 0 )
 if 52 - 52: II % o00O0oo
 Oo000ooOOO = 0
 if 31 - 31: Ii1I % i1 % oOOOo0o0O . I11iii11IIi - i1
 ii11i1ii1Ii = [ ]
 iIIiiI1 = [ ]
 I1ii11I1 = [ ]
 O00ooooo00 . update ( 0 )
 O0oO = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO )
 for Ii11iii11I in O0oooo0Oo00 :
  if Oo000ooOOO < 100 :
   O00ooooo00 . update ( Oo000ooOOO )
   Oo000ooOOO = Oo000ooOOO + 10
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  url = Ii11iii11I
  url = url . replace ( '#AAASTREAM:' , '#A:' )
  url = url . replace ( '#EXTINF:' , '#A:' )
  o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
  i1Ii1i1I11Iii = [ ]
  for I1i1i1 , OoO0O00O0oo0O , url in o00O :
   I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : url }
   i1Ii1i1I11Iii . append ( I1IiI11 )
  oO0oo = [ ]
  for iI1iiiiIii in i1Ii1i1I11Iii :
   I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
   o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
   for iIiIiIiI , i11 in o00O :
    I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11 . strip ( )
   oO0oo . append ( I1IiI11 )
   if 38 - 38: iII111i * oOOOo0o0O % I11i * OOO0o0o
  for iI1iiiiIii in oO0oo :
   name = I1ii1ii11i1I ( iI1iiiiIii [ "display_name" ] )
   url = I1ii1ii11i1I ( iI1iiiiIii [ "url" ] )
   url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   ii11i1ii1Ii . append ( name )
   iIIiiI1 . append ( url )
   if "hd" in name . lower ( ) :
    I1ii11I1 . append ( "1" )
   else :
    I1ii11I1 . append ( "0" )
   IIiiI = list ( zip ( I1ii11I1 , ii11i1ii1Ii , iIIiiI1 ) )
 III1i11 = sorted ( IIiiI , key = lambda OoooooOoo : int ( OoooooOoo [ 0 ] ) , reverse = True )
 iiI111 = sorted ( I111i1II )
 if 1 - 1: i1 * II . OOO0o0o / I11i
 IIiI = 0
 if 100 - 100: I1ii . II * o00O0oo % I11i * I11i
 O00ooooo00 . update ( 100 )
 if 14 - 14: oo00 . oOOOo0o0O + I1Ii111 / o0ooo / i1
 i11Iiii ( '                    [COLOR yellow][I]LINKS FOR ' + oooooOOO000Oo . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 i11Iiii ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 74 - 74: I11i / IiII
 if 78 - 78: iII111i . o0o + oOOOo0o0O - IiII
 for iIIII in iiI111 :
  if 31 - 31: iII111i . o0oOoO00o
  i11Iiii ( '                                  [COLOR mediumpurple][I]' + iIIII . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 83 - 83: o0ooo . I11i / o00O0oo / o0oOoO00o - I1Ii111
  iIi1Ii1i1iI = iIIII . split ( ' ' )
  if 100 - 100: o0o
  for II1i , name , url in III1i11 :
   if 2 - 2: Ii1I * o00O0oo % i1I1Ii1iI1ii - I1Ii111 - o0ooo
   iIi11iiIiI1I = 0
   if 3 - 3: IiII / I1Ii111 / i11iIiiIii * IiII - I1Ii111
   for Ii in iIi1Ii1i1iI :
    if 14 - 14: II * i1I1Ii1iI1ii
    if not Ii . lower ( ) in name . lower ( ) :
     iIi11iiIiI1I = 1
     if 81 - 81: I11iii11IIi * II + I1ii + o00O0oo - iII111i
   if iIi11iiIiI1I == 0 :
    IIiI = IIiI + 1
    if "hd" in name . lower ( ) :
     i11Iiii ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( IIiI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     i11Iiii ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( IIiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 32 - 32: I11iii11IIi * I11i
  if IIiI == 0 :
   i11Iiii ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 100 - 100: oOOOo0o0O % Ii1I * I1Ii111 - o0ooo
  iIi1Ii1i1iI = ""
  if 92 - 92: oOOOo0o0O
 O00ooooo00 . close ( )
 if 22 - 22: o00O0oo % o0ooo * oo00 / o0oOoO00o % i11iIiiIii * i1
def Oo00OoOo ( name , url , iconimage ) :
 if 24 - 24: i11iIiiIii - I1ii
 O00ooooo00 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 O00ooooo00 . update ( 0 )
 if 21 - 21: i1
 Oo000ooOOO = 0
 try :
  oooooOOO000Oo , iIIII , iconimage = url . split ( '!' )
 except :
  try :
   iIIII , iconimage = url . split ( '!' )
   oooooOOO000Oo = iIIII
  except :
   II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 92 - 92: i11iIiiIii / I1ii - o0ooo % oOOOo0o0O * I1ii + o00O0oo
 ii1Oo0000oOo = 0
 if 31 - 31: i1 . I1ii * oOOOo0o0O + i11iIiiIii * i1I1Ii1iI1ii
 if "all " in name . lower ( ) :
  iIIII = iIIII . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  oooooOOO000Oo = oooooOOO000Oo . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  ii1Oo0000oOo = 1
  if 93 - 93: oo00 / Ii1I * IiII % iII111i * I11i * i1
 ii11i1ii1Ii = [ ]
 iIIiiI1 = [ ]
 I1ii11I1 = [ ]
 O00ooooo00 . update ( 0 )
 O0oO = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO )
 for Ii11iii11I in O0oooo0Oo00 :
  if Oo000ooOOO < 100 :
   O00ooooo00 . update ( Oo000ooOOO )
   Oo000ooOOO = Oo000ooOOO + 10
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  url = Ii11iii11I
  url = url . replace ( '#AAASTREAM:' , '#A:' )
  url = url . replace ( '#EXTINF:' , '#A:' )
  o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
  i1Ii1i1I11Iii = [ ]
  for I1i1i1 , OoO0O00O0oo0O , url in o00O :
   I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : url }
   i1Ii1i1I11Iii . append ( I1IiI11 )
  oO0oo = [ ]
  for iI1iiiiIii in i1Ii1i1I11Iii :
   I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
   o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
   for iIiIiIiI , i11 in o00O :
    I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11 . strip ( )
   oO0oo . append ( I1IiI11 )
   if 64 - 64: I1Ii111 + I11i / Ii1I / o00O0oo . oOOOo0o0O % OOO0O
  for iI1iiiiIii in oO0oo :
   name = I1ii1ii11i1I ( iI1iiiiIii [ "display_name" ] )
   url = I1ii1ii11i1I ( iI1iiiiIii [ "url" ] )
   url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   ii11i1ii1Ii . append ( name )
   iIIiiI1 . append ( url )
   if "hd" in name . lower ( ) :
    I1ii11I1 . append ( "1" )
   else :
    I1ii11I1 . append ( "0" )
   IIiiI = list ( zip ( I1ii11I1 , ii11i1ii1Ii , iIIiiI1 ) )
 III1i11 = sorted ( IIiiI , key = lambda OoooooOoo : int ( OoooooOoo [ 0 ] ) , reverse = True )
 if 50 - 50: Ii1I - OOO0O + o0oOoO00o
 IIiI = 0
 if 69 - 69: I11i
 O00ooooo00 . update ( 100 )
 if 85 - 85: oOOOo0o0O / I11i
 i11Iiii ( '                                [COLOR yellow][I]LINKS FOR ' + oooooOOO000Oo . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 i11Iiii ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 iIi1Ii1i1iI = iIIII . split ( ' ' )
 for II1i , name , url in III1i11 :
  if ii1Oo0000oOo == 1 :
   iI1iIIIi1i = name
   if 89 - 89: Ii1I
  iIi11iiIiI1I = 0
  if 21 - 21: i1 % i1
  for Ii in iIi1Ii1i1iI :
   if 27 - 27: i11iIiiIii / oo00
   if not Ii . lower ( ) in name . lower ( ) :
    iIi11iiIiI1I = 1
    if 84 - 84: o00O0oo
  if iIi11iiIiI1I == 0 :
   IIiI = IIiI + 1
   if ii1Oo0000oOo == 1 :
    if "hd" in name . lower ( ) :
     i11Iiii ( '                                          [COLOR blue] ' + str ( iI1iIIIi1i ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     i11Iiii ( '                                          [COLOR blue] ' + str ( iI1iIIIi1i ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     i11Iiii ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( IIiI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     i11Iiii ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( IIiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 43 - 43: i1I1Ii1iI1ii - iII111i
 if IIiI == 0 :
  i11Iiii ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 3 - 3: I11i / o0ooo
 O00ooooo00 . close ( )
 if 31 - 31: o0oOoO00o + II . iII111i
def ooOooo0 ( term ) :
 if 67 - 67: ooOoO0o
 o00oooO0Oo = [ ]
 o0O0OOO0Ooo = [ ]
 if 55 - 55: oo00 - o0ooo * II + OOO0o0o * OOO0o0o * I11i
 O0oO = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( O0oO )
 for Ii11iii11I in O0oooo0Oo00 :
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  i111IiI1I = Ii11iii11I
  if 91 - 91: I1ii - o0oOoO00o % Ii1I - iII111i % oOOOo0o0O
  i111IiI1I = i111IiI1I . replace ( '#AAASTREAM:' , '#A:' )
  i111IiI1I = i111IiI1I . replace ( '#EXTINF:' , '#A:' )
  o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i111IiI1I )
  i1Ii1i1I11Iii = [ ]
  for I1i1i1 , OoO0O00O0oo0O , i111IiI1I in o00O :
   I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : i111IiI1I }
   i1Ii1i1I11Iii . append ( I1IiI11 )
  list = [ ]
  for iI1iiiiIii in i1Ii1i1I11Iii :
   I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
   o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
   for iIiIiIiI , i11 in o00O :
    I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11 . strip ( )
   list . append ( I1IiI11 )
   if 98 - 98: o0o . o0o * i1I1Ii1iI1ii * I1Ii111 * I1ii
  for iI1iiiiIii in list :
   I11II1i = I1ii1ii11i1I ( iI1iiiiIii [ "display_name" ] )
   i111IiI1I = I1ii1ii11i1I ( iI1iiiiIii [ "url" ] )
   i111IiI1I = i111IiI1I . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in I11II1i . lower ( ) :
    o00oooO0Oo . append ( i111IiI1I )
    o0O0OOO0Ooo . append ( I11II1i )
    if 92 - 92: o00O0oo
 II1 = xbmcgui . Dialog ( )
 i1Iii1i1I = II1 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , o0O0OOO0Ooo )
 if i1Iii1i1I < 0 :
  quit ( )
  if 40 - 40: OOO0o0o / OOO0O
 i111IiI1I = o00oooO0Oo [ i1Iii1i1I ]
 I11II1i = o0O0OOO0Ooo [ i1Iii1i1I ]
 O000OOOOOo ( I11II1i , i111IiI1I , iiiii )
 if 79 - 79: o0o - Ii1I + I11iii11IIi - I1ii
def OoOiIIiii ( name , url , iconimage ) :
 if 61 - 61: OOO0O . IiII / I1ii % i11iIiiIii * o0ooo
 list = i1i1i1I ( url )
 for iI1iiiiIii in list :
  name = I1ii1ii11i1I ( iI1iiiiIii [ "display_name" ] )
  url = I1ii1ii11i1I ( iI1iiiiIii [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  i11Iiii ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 83 - 83: i1I1Ii1iI1ii + iII111i
def i1i1i1I ( url ) :
 if 22 - 22: I11iii11IIi % o0ooo * iII111i - II / Ii1I
 Oo = OO00 ( url )
 Oo = Oo . replace ( '#AAASTREAM:' , '#A:' )
 Oo = Oo . replace ( '#EXTINF:' , '#A:' )
 o00O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( Oo )
 i1Ii1i1I11Iii = [ ]
 for I1i1i1 , OoO0O00O0oo0O , url in o00O :
  I1IiI11 = { "params" : I1i1i1 , "display_name" : OoO0O00O0oo0O , "url" : url }
  i1Ii1i1I11Iii . append ( I1IiI11 )
 list = [ ]
 for iI1iiiiIii in i1Ii1i1I11Iii :
  I1IiI11 = { "display_name" : iI1iiiiIii [ "display_name" ] , "url" : iI1iiiiIii [ "url" ] }
  o00O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iI1iiiiIii [ "params" ] )
  for iIiIiIiI , i11 in o00O :
   I1IiI11 [ iIiIiIiI . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i11 . strip ( )
  list . append ( I1IiI11 )
  if 28 - 28: i1I1Ii1iI1ii - i11iIiiIii . oo00 + OOO0O / oo00
 return list
 if 35 - 35: OOO0O
def OOoO0 ( ) :
 if 86 - 86: I1Ii111 % i11iIiiIii + I11iii11IIi % i11iIiiIii
 iIi1Ii1i1iI = ''
 Ooo0o0OOO = xbmc . Keyboard ( iIi1Ii1i1iI , 'Enter Search Term' )
 Ooo0o0OOO . doModal ( )
 if Ooo0o0OOO . isConfirmed ( ) :
  iIi1Ii1i1iI = Ooo0o0OOO . getText ( )
  if len ( iIi1Ii1i1iI ) > 1 :
   i111IiI1I = iIi1Ii1i1iI + "!" + iiiii
   Oo00OoOo ( "all " + iIi1Ii1i1iI , i111IiI1I , iiiii )
  else : quit ( )
  if 35 - 35: o0oOoO00o + o0ooo
def iI1IIIii ( name , url , iconimage ) :
 if 7 - 7: OOO0O - i1 / I1Ii111 * I11iii11IIi . o0ooo * o0ooo
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 61 - 61: i1 % oOOOo0o0O - o0o / o00O0oo
  if 4 - 4: iII111i - IiII % I11iii11IIi - o0oOoO00o * II
  if 85 - 85: iII111i * Ii1I . o0ooo / iII111i % ooOoO0o % I11i
  if 36 - 36: I11iii11IIi / I1Ii111 / OOO0O / OOO0O + oo00
  if 95 - 95: OOO0O
def Ooo0oo ( name ) :
 if 41 - 41: OOO0o0o * i1 / OOO0o0o % i1I1Ii1iI1ii
 iiIiii1iI1i = 0
 if 18 - 18: I1Ii111 . iII111i % OOO0o0o % I11iii11IIi
 try :
  Ii1iIIIi1ii ( "http://www.google.com" )
 except :
  II1 . ok ( Oo0Ooo , '[COLOR red]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/COLOR]' )
  sys . exit ( 0 )
  if 9 - 9: o0o - o00O0oo * iII111i . o00O0oo
 try :
  O00ooooo00 . create ( Oo0Ooo , "Checking for repository updates" , '' , 'Please Wait...' )
  O00ooooo00 . update ( 0 )
  IIiI = open ( IIi1IiiiI1Ii ) . read ( )
  iI11iiiI1II = IIiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  O0oooo0Oo00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iI11iiiI1II ) )
  for Ii11iii11I in O0oooo0Oo00 :
   O00ooooo00 . update ( 25 )
   oOo00Oo00O = float ( Ii11iii11I ) + 0.01
   i111IiI1I = oO00oOo + str ( oOo00Oo00O ) + '.zip'
   O0oO = Ii1iIIIi1ii ( i111IiI1I )
   if "Not Found" not in O0oO :
    iiIiii1iI1i = 1
    O00ooooo00 . update ( 75 )
    oOOoo00O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( oOOoo00O0O ) :
     os . makedirs ( oOOoo00O0O )
    ii1Ii1IiIIi = os . path . join ( oOOoo00O0O , 'repoupdate.zip' )
    try : os . remove ( ii1Ii1IiIIi )
    except : pass
    O00ooooo00 . update ( 100 )
    O00ooooo00 . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( i111IiI1I , ii1Ii1IiIIi , O00ooooo00 )
    o0OO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    O00ooooo00 . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( ii1Ii1IiIIi , o0OO0 , O00ooooo00 )
    try : os . remove ( ii1Ii1IiIIi )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    II1 . ok ( Oo0Ooo , "ECHO repository was updated to " + str ( oOo00Oo00O ) + ', you may need to restart the addon for changes to take effect' )
    if 100 - 100: o00O0oo * I1ii / I1ii
  O00ooooo00 . update ( 75 , "Checking for addon updates" )
  IIiI = open ( I1IiiI ) . read ( )
  iI11iiiI1II = IIiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  O0oooo0Oo00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iI11iiiI1II ) )
  for Ii11iii11I in O0oooo0Oo00 :
   oOo00Oo00O = float ( Ii11iii11I ) + 0.01
   i111IiI1I = I11i11Ii + str ( oOo00Oo00O ) + '.zip'
   O0oO = Ii1iIIIi1ii ( i111IiI1I )
   if "Not Found" not in O0oO :
    iiIiii1iI1i = 1
    O00ooooo00 . update ( 75 )
    oOOoo00O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( oOOoo00O0O ) :
     os . makedirs ( oOOoo00O0O )
    ii1Ii1IiIIi = os . path . join ( oOOoo00O0O , 'wizupdate.zip' )
    try : os . remove ( ii1Ii1IiIIi )
    except : pass
    O00ooooo00 . update ( 100 )
    O00ooooo00 . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( i111IiI1I , ii1Ii1IiIIi , O00ooooo00 )
    o0OO0 = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    O00ooooo00 . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( ii1Ii1IiIIi , o0OO0 , O00ooooo00 )
    try : os . remove ( ii1Ii1IiIIi )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    O00ooooo00 . update ( 100 )
    O00ooooo00 . close
    II1 . ok ( Oo0Ooo , "Sportie was updated to " + str ( oOo00Oo00O ) + ', you may need to restart the addon for changes to take effect' )
 except :
  II1 . ok ( Oo0Ooo , 'Sorry! We encountered an error whilst checking for updates. You can make Kodi force check the repository for updates as an alternative if you wish.' )
  quit ( )
  if 41 - 41: Ii1I % i1
 if O00ooooo00 . iscanceled ( ) :
  O00ooooo00 . close ( )
 else :
  if iiIiii1iI1i == 0 :
   if not name == "no dialog" :
    II1 . ok ( Oo0Ooo , "There are no updates at this time." )
    quit ( )
    if 59 - 59: o0oOoO00o + i11iIiiIii
def ii1 ( text ) :
 if 88 - 88: i11iIiiIii - oOOOo0o0O
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 67 - 67: o0oOoO00o . o00O0oo + OOO0o0o - iII111i
 return text
 if 70 - 70: o0oOoO00o / I1Ii111 - Ii1I - o0ooo
def i1iI1 ( text ) :
 if 11 - 11: Ii1I . iII111i . I1Ii111 / IiII - i1
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 30 - 30: OOO0o0o
 return text
 if 21 - 21: i11iIiiIii / I1ii % o0oOoO00o * I11i . i1 - Ii1I
def O000OOOOOo ( name , url , iconimage ) :
 if 26 - 26: I1Ii111 * OOO0o0o
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 10 - 10: I1Ii111 . o0ooo
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 32 - 32: I11iii11IIi . OOO0O . iII111i - o0o + i1I1Ii1iI1ii
 ooO0oO00O0o = url
 ooOO00oOOo000 = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 ooOO00oOOo000 . setPath ( ooO0oO00O0o )
 xbmc . Player ( ) . play ( ooO0oO00O0o , ooOO00oOOo000 , False )
 if 14 - 14: o0o . I1Ii111 . i1 / I11iii11IIi % oo00 - oOOOo0o0O
def Ii1iIIIi1ii ( url ) :
 if 67 - 67: i1 - o0oOoO00o . IiII
 I1I1iI = urllib2 . Request ( url )
 I1I1iI . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 Oo = urllib2 . urlopen ( I1I1iI )
 O0O00o0OOO0 = Oo . read ( )
 Oo . close ( )
 O0O00o0OOO0 = O0O00o0OOO0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return O0O00o0OOO0
 if 16 - 16: OOO0O * OOO0o0o . oOOOo0o0O / IiII . o0o - IiII
def OO00 ( url ) :
 if 46 - 46: OOO0O + Ii1I + o0oOoO00o + o0o . oo00
 I1I1iI = urllib2 . Request ( url )
 I1I1iI . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 Oo = urllib2 . urlopen ( I1I1iI )
 O0O00o0OOO0 = Oo . read ( )
 Oo . close ( )
 return O0O00o0OOO0
 if 1 - 1: i1I1Ii1iI1ii
def I1ii1ii11i1I ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 62 - 62: IiII - o0oOoO00o
 if 96 - 96: IiII . oo00 + i1I1Ii1iI1ii
 if 48 - 48: Ii1I % IiII % o0ooo + oOOOo0o0O
 if 30 - 30: i11iIiiIii % Ii1I . i1 % Ii1I
 if 62 - 62: o00O0oo * OOO0o0o
def OO0 ( ) :
 if 84 - 84: OOO0o0o % oOOOo0o0O - OOO0o0o . II
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 5 - 5: OOO0o0o * I1ii - oo00 / Ii1I % i1I1Ii1iI1ii + OOO0O
 if os . path . exists ( OOOo0 ) == True :
  for o00o00OoO00o0 , OOoOoO00O0O0o , iI1I11i in os . walk ( OOOo0 ) :
   Ooo0o0oo = 0
   Ooo0o0oo += len ( iI1I11i )
   if Ooo0o0oo > 0 :
    for Ii1i1i1111 in iI1I11i :
     try :
      if ( Ii1i1i1111 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o00o00OoO00o0 , Ii1i1i1111 ) )
     except :
      pass
    for o0oO0O00oOo in OOoOoO00O0O0o :
     try :
      shutil . rmtree ( os . path . join ( o00o00OoO00o0 , o0oO0O00oOo ) )
     except :
      pass
      if 26 - 26: OOO0O % I1ii % i1I1Ii1iI1ii % I11iii11IIi
   else :
    pass
    if 55 - 55: oOOOo0o0O % iII111i / iII111i % iII111i
 if os . path . exists ( Oooo000o ) == True :
  for o00o00OoO00o0 , OOoOoO00O0O0o , iI1I11i in os . walk ( Oooo000o ) :
   Ooo0o0oo = 0
   Ooo0o0oo += len ( iI1I11i )
   if Ooo0o0oo > 0 :
    for Ii1i1i1111 in iI1I11i :
     try :
      if ( Ii1i1i1111 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o00o00OoO00o0 , Ii1i1i1111 ) )
     except :
      pass
    for o0oO0O00oOo in OOoOoO00O0O0o :
     try :
      shutil . rmtree ( os . path . join ( o00o00OoO00o0 , o0oO0O00oOo ) )
     except :
      pass
      if 52 - 52: oo00 + oo00 . I1Ii111
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  Iii = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 6 - 6: o0oOoO00o - oo00 + I11iii11IIi + IiII / I11i / II
  for o00o00OoO00o0 , OOoOoO00O0O0o , iI1I11i in os . walk ( Iii ) :
   Ooo0o0oo = 0
   Ooo0o0oo += len ( iI1I11i )
   if 42 - 42: IiII . ooOoO0o / IiII + I11iii11IIi
   if Ooo0o0oo > 0 :
    for Ii1i1i1111 in iI1I11i :
     os . unlink ( os . path . join ( o00o00OoO00o0 , Ii1i1i1111 ) )
    for o0oO0O00oOo in OOoOoO00O0O0o :
     shutil . rmtree ( os . path . join ( o00o00OoO00o0 , o0oO0O00oOo ) )
     if 54 - 54: oOOOo0o0O % o0oOoO00o . I1ii + i1I1Ii1iI1ii - o0oOoO00o * ooOoO0o
   else :
    pass
  OOo00O = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 81 - 81: OOO0O . II / I1ii
  for o00o00OoO00o0 , OOoOoO00O0O0o , iI1I11i in os . walk ( OOo00O ) :
   Ooo0o0oo = 0
   Ooo0o0oo += len ( iI1I11i )
   if 17 - 17: i11iIiiIii - o0oOoO00o . OOO0O % Ii1I + i1 - oOOOo0o0O
   if Ooo0o0oo > 0 :
    for Ii1i1i1111 in iI1I11i :
     os . unlink ( os . path . join ( o00o00OoO00o0 , Ii1i1i1111 ) )
    for o0oO0O00oOo in OOoOoO00O0O0o :
     shutil . rmtree ( os . path . join ( o00o00OoO00o0 , o0oO0O00oOo ) )
     if 78 - 78: i1 * OOO0o0o . I11i / I11i
   else :
    pass
    if 80 - 80: IiII - o00O0oo / o0o - i11iIiiIii
 I111I11 = OoOooOOOO ( )
 if 68 - 68: i1I1Ii1iI1ii - oo00 % I11i % I1ii
 for Ii1II in I111I11 :
  ooO0O0o0 = xbmc . translatePath ( Ii1II . path )
  if os . path . exists ( ooO0O0o0 ) == True :
   for o00o00OoO00o0 , OOoOoO00O0O0o , iI1I11i in os . walk ( ooO0O0o0 ) :
    Ooo0o0oo = 0
    Ooo0o0oo += len ( iI1I11i )
    if Ooo0o0oo > 0 :
     for Ii1i1i1111 in iI1I11i :
      os . unlink ( os . path . join ( o00o00OoO00o0 , Ii1i1i1111 ) )
     for o0oO0O00oOo in OOoOoO00O0O0o :
      shutil . rmtree ( os . path . join ( o00o00OoO00o0 , o0oO0O00oOo ) )
      if 92 - 92: o00O0oo % oo00 * Ii1I - oo00 . II
    else :
     pass
     if 95 - 95: I1ii % ooOoO0o
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 II1 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 42 - 42: iII111i - o0ooo / iII111i / I11iii11IIi
def O0OOooo0OooOo ( ) :
 OOOoO = [ ]
 oOooo = sys . argv [ 2 ]
 if len ( oOooo ) >= 2 :
  I1i1i1 = sys . argv [ 2 ]
  oo00OOoOoO00 = I1i1i1 . replace ( '?' , '' )
  if ( I1i1i1 [ len ( I1i1i1 ) - 1 ] == '/' ) :
   I1i1i1 = I1i1i1 [ 0 : len ( I1i1i1 ) - 2 ]
  I1iii = oo00OOoOoO00 . split ( '&' )
  OOOoO = { }
  for ooo0O in range ( len ( I1iii ) ) :
   oOO0OO0O = { }
   oOO0OO0O = I1iii [ ooo0O ] . split ( '=' )
   if ( len ( oOO0OO0O ) ) == 2 :
    OOOoO [ oOO0OO0O [ 0 ] ] = oOO0OO0O [ 1 ]
 return OOOoO
 if 78 - 78: I11iii11IIi / I1Ii111 % OOO0o0o
def IIIII ( name , url , mode , iconimage , fanart , description = '' ) :
 if 52 - 52: o0oOoO00o - o0ooo * i1I1Ii1iI1ii
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 Ii1I11I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 iiIii1I = True
 ooOO00oOOo000 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 ooOO00oOOo000 . setProperty ( "fanart_Image" , fanart )
 ooOO00oOOo000 . setProperty ( "icon_Image" , iconimage )
 iiIii1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1I11I , listitem = ooOO00oOOo000 , isFolder = True )
 return iiIii1I
 if 47 - 47: oOOOo0o0O . i1 / II
def i11Iiii ( name , url , mode , iconimage , fanart , description = '' ) :
 if 83 - 83: II / o0oOoO00o / o0oOoO00o + II * I1ii + II
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 Ii1I11I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 iiIii1I = True
 ooOO00oOOo000 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 ooOO00oOOo000 . setProperty ( "fanart_Image" , fanart )
 ooOO00oOOo000 . setProperty ( "icon_Image" , iconimage )
 iiIii1I = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1I11I , listitem = ooOO00oOOo000 , isFolder = False )
 return iiIii1I
 if 36 - 36: OOO0o0o + II - iII111i . i1I1Ii1iI1ii . iII111i / o00O0oo
I1i1i1 = O0OOooo0OooOo ( ) ; i111IiI1I = None ; I11II1i = None ; o00Oi1i = None ; IIi = None ; I111Ii111 = None ; Oo0oOOo = None
try : IIi = urllib . unquote_plus ( I1i1i1 [ "site" ] )
except : pass
try : i111IiI1I = urllib . unquote_plus ( I1i1i1 [ "url" ] )
except : pass
try : I11II1i = urllib . unquote_plus ( I1i1i1 [ "name" ] )
except : pass
try : o00Oi1i = int ( I1i1i1 [ "mode" ] )
except : pass
try : I111Ii111 = urllib . unquote_plus ( I1i1i1 [ "iconimage" ] )
except : pass
try : Oo0oOOo = urllib . unquote_plus ( I1i1i1 [ "fanart" ] )
except : pass
if 58 - 58: I1Ii111
if o00Oi1i == None or i111IiI1I == None or len ( i111IiI1I ) < 1 : oOoO ( )
elif o00Oi1i == 1 : O0ooo0O0oo0 ( I11II1i , i111IiI1I )
elif o00Oi1i == 2 : O000OOOOOo ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 3 : ooOOOoOooOoO ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 4 : PLAYSD ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 8 : oo000o ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 9 : Ooo0oo ( I11II1i )
elif o00Oi1i == 10 : OoOiIIiii ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 11 : OooOoOO0 ( )
elif o00Oi1i == 12 : o000ooooO0o ( i111IiI1I )
elif o00Oi1i == 19 : i11IIIiI11 ( i111IiI1I )
elif o00Oi1i == 20 : Oo00OoOo ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 21 : iII1ii1 ( i111IiI1I )
elif o00Oi1i == 22 : o0o0oOoOO0O ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 23 : IIII1 ( )
elif o00Oi1i == 24 : oOO00O ( )
elif o00Oi1i == 25 : OO0Oooo0oOO0O ( )
elif o00Oi1i == 30 : OoO0o ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 100 : OOoO0 ( )
elif o00Oi1i == 500 : OO0 ( )
elif o00Oi1i == 201 : I111iI ( )
elif o00Oi1i == 202 : OOO ( i111IiI1I )
elif o00Oi1i == 203 : o0o0O0O00oOOo ( i111IiI1I )
elif o00Oi1i == 204 : o0O0o0 ( i111IiI1I )
elif o00Oi1i == 205 : o00oo0 ( i111IiI1I )
elif o00Oi1i == 206 : oOOOoo00 ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 210 : O0oOo00o ( i111IiI1I )
elif o00Oi1i == 220 : iiii111II ( i111IiI1I )
elif o00Oi1i == 221 : O00OO ( I11II1i , i111IiI1I , I111Ii111 )
elif o00Oi1i == 800 : iI1IIIii ( I11II1i , i111IiI1I , I111Ii111 )
if 19 - 19: oo00 - i1 . I1Ii111 - o0o . OOO0O * iII111i
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )