import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/repository.txt' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
O0oOO0o0 = plugintools . get_setting ( "scrape1" )
i1ii1iIII = plugintools . get_setting ( "scrape2" )
Oo0oO0oo0oO00 = plugintools . get_setting ( "scrape3" )
if 8 - 8: OOo00O0Oo0oO / ooO
IiIiI11iIi = o0O + '|SPLIT|' + Oo
checker . check ( IiIiI11iIi )
if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
#######################################################################
#						Cache Functions
#######################################################################
if 87 - 87: oO0o0o0ooO0oO / I1i1I - OoOoo0 % iIiiI1 % OOooO % OOoO00o
class II111iiii ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 48 - 48: I1Ii . i11iIiiIii - OoOoo0 % IIii11I1 . I1Ii / i1IIi11111i
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 6 - 6: i1111 * iIiiI1
O00O0O0O0 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 75 - 75: ooOoO0o / OoOoo0 - i1IIi11111i
class oo :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 28 - 28: IiII - ooOoO0o
  if 70 - 70: IIii11I1 . IIii11I1 - IIii11I1 / I11i1i11i1I * oO0o0o0ooO0oO
  if 86 - 86: i11iIiiIii + OoOoo0 + I1Ii * I1i1I + i1IIi11111i
  if 61 - 61: IIii11I1 / i11iIiiIii
def IiIiIi ( ) :
 II = 5
 iI = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 iI11iiiI1II = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 79 - 79: OOoO00o % i11iIiiIii / IiII . oO0o0o0ooO0oO
 o0oO0o00oo = [ ]
 if 32 - 32: ooO * iII111i % Iiii % OoOoo0 . OOooO
 for o0OOOOO00o0O0 in range ( II ) :
  o0oO0o00oo . append ( oo ( iI [ o0OOOOO00o0O0 ] , iI11iiiI1II [ o0OOOOO00o0O0 ] ) )
  if 71 - 71: I1Ii % iIiiI1 / i1IIi11111i
 return o0oO0o00oo
 if 49 - 49: o00O0oo % iIiiI1 * iII111i
def oOOo0oo ( ) :
 if 80 - 80: I1i1I * i11iIiiIii / OOoO00o
 if not os . path . isfile ( ooo0OO ) :
  plugintools . open_settings_dialog ( )
  if 9 - 9: OoOoo0 + Iiii % OoOoo0 + ooOoO0o . oO0o0o0ooO0oO
 III1i1i = iiI1 ( II1 )
 III1i1i = base64 . b64decode ( III1i1i )
 III1i1i = III1i1i . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 i11Iiii = re . compile ( '<item>(.+?)</item>' ) . findall ( III1i1i )
 for iII1i1I1II in i11Iiii :
  if 45 - 45: OOoO00o . i1111
  if '<search>ZGlzcGxheQ==</search>' in iII1i1I1II :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   oO = base64 . b64decode ( oO )
   ii1i1I1i ( oO , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 53 - 53: OOooO + OOo00O0Oo0oO * Iiii
  elif '<vip>' in iII1i1I1II :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   oO = base64 . b64decode ( oO )
   ii1i1I1i ( oO , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 61 - 61: ooOoO0o * oO0o0o0ooO0oO / I1Ii111 . i11iIiiIii . i1111
  elif '<divider>bnVsbA==</divider>' in iII1i1I1II :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   o00O ( oO , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 69 - 69: Iiii % OOoO00o - i1IIi11111i + OOoO00o - iII111i % I1Ii111
   if 31 - 31: o00O0oo - oO0o0o0ooO0oO . OOoO00o % i1111 - iII111i
   if 4 - 4: o00O0oo / I1Ii . iIiiI1
   if 58 - 58: oO0o0o0ooO0oO * i11iIiiIii / i1111 % OOoO00o - I11i1i11i1I / Iiii
   if 50 - 50: OOo00O0Oo0oO
   if 34 - 34: OOo00O0Oo0oO * o00O0oo % iIiiI1 * i1111 - OOo00O0Oo0oO
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in iII1i1I1II :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   oO = base64 . b64decode ( oO )
   ii1i1I1i ( oO , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 33 - 33: i1IIi11111i + oO0o0o0ooO0oO * IIii11I1 - ooO / Iiii % OoOoo0
   if 21 - 21: IIii11I1 * IiII % Iiii * ooOoO0o
   if 16 - 16: iII111i - OOoO00o * IiII + iIiiI1
   if 50 - 50: o00O0oo - I1Ii * I11i1i11i1I / OOoO00o + i1IIi11111i
   if 88 - 88: OoOoo0 / OOoO00o + iIiiI1 - o00O0oo / I1Ii - i1111
   if 15 - 15: I11i1i11i1I + i1111 - I1Ii111 / oO0o0o0ooO0oO
   if 58 - 58: i11iIiiIii % I1i1I
   if 71 - 71: oO0o0o0ooO0oO + I1Ii % i11iIiiIii + I11i1i11i1I - OOooO
   if 88 - 88: i1111 - IIii11I1 % oO0o0o0ooO0oO
   if 16 - 16: OOo00O0Oo0oO * Iiii % OOooO
   if 86 - 86: OOo00O0Oo0oO + OoOoo0 % i11iIiiIii * Iiii . I1Ii * I1i1I
   if 44 - 44: Iiii
   if 88 - 88: OOoO00o % OoOoo0 . o00O0oo
   if 38 - 38: i1IIi11111i
   if 57 - 57: iII111i / Iiii * OOoO00o / i1111 . o00O0oo
   if 26 - 26: iIiiI1
   if 91 - 91: IIii11I1 . I11i1i11i1I + IIii11I1 - iIiiI1 / I1Ii111
   if 39 - 39: I11i1i11i1I / I1Ii - o00O0oo
   if 98 - 98: I11i1i11i1I / I1i1I % Iiii . i1111
   if 91 - 91: Iiii % ooO
   if 64 - 64: I1i1I % iIiiI1 - OOoO00o - Iiii
   if 31 - 31: I1i1I - o00O0oo . I1i1I
  elif '<sportsdevil>' in iII1i1I1II :
   i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iII1i1I1II )
   if len ( i1I11i1I ) == 1 :
    oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
    O0O0oOO00O00o = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iII1i1I1II ) [ 0 ]
    iI1ii11iIi1i = re . compile ( '<referer>(.+?)</referer>' ) . findall ( iII1i1I1II ) [ 0 ]
    oO = base64 . b64decode ( oO )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    iI1ii11iIi1i = base64 . b64decode ( iI1ii11iIi1i )
    iiI111I1iIiI = iI1ii11iIi1i
    IIIi1I1IIii1II = "/"
    if not iiI111I1iIiI . endswith ( IIIi1I1IIii1II ) :
     O0 = iiI111I1iIiI + "/"
    else :
     O0 = iiI111I1iIiI
    III1i1i = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( oO ) + '%26url=' + O0O0oOO00O00o
    O0O0oOO00O00o = III1i1i + '%26referer=' + O0
    o00O ( oO , O0O0oOO00O00o , 4 , Oo0o00 , ii1ii1ii )
   elif len ( i1I11i1I ) > 1 :
    oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
    oO = base64 . b64decode ( oO )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    o00O ( oO , url2 + 'NOTPLAY' , 8 , Oo0o00 , ii1ii1ii )
    if 91 - 91: OOooO
  elif '<folder>' in iII1i1I1II :
   iiIii = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II )
   for oO , O0O0oOO00O00o , Oo0o00 , ii1ii1ii in iiIii :
    oO = base64 . b64decode ( oO )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    ii1ii1ii = base64 . b64decode ( ii1ii1ii )
    ii1i1I1i ( oO , O0O0oOO00O00o , 1 , Oo0o00 , ii1ii1ii )
  elif '<m3u>' in iII1i1I1II :
   iiIii = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II )
   for oO , O0O0oOO00O00o , Oo0o00 , ii1ii1ii in iiIii :
    oO = base64 . b64decode ( oO )
    O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    ii1ii1ii = base64 . b64decode ( ii1ii1ii )
    ii1i1I1i ( oO , O0O0oOO00O00o , 10 , Oo0o00 , ii1ii1ii )
  else :
   i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( iII1i1I1II )
   if len ( i1I11i1I ) == 1 :
    iiIii = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II )
    ooo0O = len ( i11Iiii )
    for oO , O0O0oOO00O00o , Oo0o00 , ii1ii1ii in iiIii :
     oO = base64 . b64decode ( oO )
     O0O0oOO00O00o = base64 . b64decode ( O0O0oOO00O00o )
     Oo0o00 = base64 . b64decode ( Oo0o00 )
     ii1ii1ii = base64 . b64decode ( ii1ii1ii )
     o00O ( oO , O0O0oOO00O00o , 2 , Oo0o00 , ii1ii1ii )
   elif len ( i1I11i1I ) > 1 :
    oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
    ii1ii1ii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II ) [ 0 ]
    oO = base64 . b64decode ( oO )
    Oo0o00 = base64 . b64decode ( Oo0o00 )
    ii1ii1ii = base64 . b64decode ( ii1ii1ii )
    o00O ( oO , II1 , 3 , Oo0o00 , ii1ii1ii )
    if 75 - 75: i1IIi11111i % i1IIi11111i . OOoO00o
 III1iII1I1ii = open ( IIi1IiiiI1Ii ) . read ( )
 oOOo0 = III1iII1I1ii . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 i11Iiii = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( oOOo0 ) )
 for iII1i1I1II in i11Iiii :
  oo00O00oO = float ( iII1i1I1II )
 III1iII1I1ii = open ( I11i11Ii ) . read ( )
 oOOo0 = III1iII1I1ii . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 i11Iiii = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( oOOo0 ) )
 for iII1i1I1II in i11Iiii :
  iIiIIIi = float ( iII1i1I1II )
  if 93 - 93: iIiiI1
 o00O ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 ii1i1I1i ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 ii1i1I1i ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 ii1i1I1i ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 ii1i1I1i ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 o00O ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 o00O ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 o00O ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 o00O ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( oo00O00oO ) + "[/COLOR]" , 'url' , 999 , iiiii , ii1ii1ii , '' )
 o00O ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( iIiIIIi ) + "[/COLOR]" , 'url' , 999 , iiiii , ii1ii1ii , '' )
 if 10 - 10: I1i1I
 OOooOO000 = OOoOoo ( )
 if 85 - 85: I11i1i11i1I % iIiiI1 % I1Ii
 if OOooOO000 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOooOO000 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 82 - 82: i11iIiiIii - iIiiI1 * I1Ii111 / I1i1I
def i1 ( name , url ) :
 if 57 - 57: Iiii . I1i1I . ooOoO0o
 hash = [ ]
 i11Iii = url
 III1i1i = iiI1 ( url )
 if 16 - 16: o00O0oo % i1111 - o00O0oo + OoOoo0
 i11Iiii = re . compile ( '<item>(.+?)</item>' ) . findall ( III1i1i )
 for iII1i1I1II in i11Iiii :
  if 12 - 12: oO0o0o0ooO0oO / oO0o0o0ooO0oO + i11iIiiIii
  if '<search>' in iII1i1I1II :
   if 40 - 40: OOo00O0Oo0oO . IiII / OOo00O0Oo0oO / i11iIiiIii
   i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( iII1i1I1II )
   if len ( i1I11i1I ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( iII1i1I1II ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
    url = name + "!" + url + "!" + Oo0o00
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    ii1i1I1i ( name , url , 20 , Oo0o00 , Oo0o00 )
    if 75 - 75: I1i1I + i1IIi11111i
   elif len ( i1I11i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
    url = i11Iii + "!" + name + "!" + Oo0o00
    name = '[COLOR mediumpurple]' + name + '[/COLOR]'
    ii1i1I1i ( name , url , 22 , Oo0o00 , Oo0o00 )
    if 84 - 84: OOooO . i11iIiiIii . OOooO * I11i1i11i1I - I1i1I
  elif '<regex>' in iII1i1I1II :
   ii = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( iII1i1I1II )
   ii = '' . join ( ii )
   O0o0oOOOoOo = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( ii )
   ii = urllib . quote_plus ( ii )
   if 17 - 17: i1IIi11111i . OOo00O0Oo0oO * iIiiI1 % iIiiI1
   iI1I = hashlib . md5 ( )
   for I11I1II in ii : iI1I . update ( str ( I11I1II ) )
   iI1I = str ( iI1I . hexdigest ( ) )
   if 63 - 63: I1Ii111 - IIii11I1 . o00O0oo / i1IIi11111i . i1111 / iII111i
   iII1i1I1II = iII1i1I1II . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   iII1i1I1II = re . sub ( '<regex>.+?</regex>' , '' , iII1i1I1II )
   iII1i1I1II = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , iII1i1I1II )
   iII1i1I1II = re . sub ( '<link></link>' , '' , iII1i1I1II )
   if 84 - 84: OOooO
   name = re . sub ( '<meta>.+?</meta>' , '' , iII1i1I1II )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 86 - 86: i1111 - OoOoo0 - IIii11I1 * iIiiI1
   try : oooo0O0 = re . findall ( '<date>(.+?)</date>' , iII1i1I1II ) [ 0 ]
   except : oooo0O0 = ''
   if re . search ( r'\d+' , oooo0O0 ) : name += ' [COLOR red] Updated %s[/COLOR]' % oooo0O0
   if 51 - 51: IIii11I1 / IIii11I1
   try : ooOOO0 = re . findall ( '<thumbnail>(.+?)</thumbnail>' , iII1i1I1II ) [ 0 ]
   except : ooOOO0 = iiiii
   if 65 - 65: iII111i
   try : oO00OOoO00 = re . findall ( '<fanart>(.+?)</fanart>' , iII1i1I1II ) [ 0 ]
   except : oO00OOoO00 = O0O0OO0O0O0
   if 40 - 40: OOo00O0Oo0oO * OoOoo0 + oO0o0o0ooO0oO % iIiiI1
   try : OOOOOoo0 = re . findall ( '<meta>(.+?)</meta>' , iII1i1I1II ) [ 0 ]
   except : OOOOOoo0 = '0'
   if 49 - 49: iII111i . iIiiI1
   try : url = re . findall ( '<link>(.+?)</link>' , iII1i1I1II ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % OOOOOoo0 )
   url = '<preset>search</preset>%s' % OOOOOoo0 if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % OOOOOoo0 )
   url = '<preset>searchsd</preset>%s' % OOOOOoo0 if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 11 - 11: OOooO * OOo00O0Oo0oO . IiII % I1Ii111 + iIiiI1
   if not ii == '' :
    hash . append ( { 'regex' : iI1I , 'response' : ii } )
    url += '|regex=%s' % ii
    if 78 - 78: IIii11I1 . oO0o0o0ooO0oO + IIii11I1 / I1i1I / IIii11I1
   o00O ( name , url , 30 , ooOOO0 , oO00OOoO00 )
   if 54 - 54: i1111 % iIiiI1
  elif '<sportsdevil>' in iII1i1I1II :
   i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iII1i1I1II )
   if len ( i1I11i1I ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iII1i1I1II ) [ 0 ]
    try :
     iI1ii11iIi1i = re . compile ( '<referer>(.+?)</referer>' ) . findall ( iII1i1I1II ) [ 0 ]
    except : iI1ii11iIi1i = "None"
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
    try :
     ii1ii1ii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II ) [ 0 ]
    except : ii1ii1ii = O0O0OO0O0O0
    iiI111I1iIiI = iI1ii11iIi1i
    IIIi1I1IIii1II = "/"
    if not iiI111I1iIiI . endswith ( IIIi1I1IIii1II ) :
     O0 = iiI111I1iIiI + "/"
    else :
     O0 = iiI111I1iIiI
    III1i1i = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = III1i1i + '%26referer=' + O0
    o00O ( name , url , 2 , Oo0o00 , ii1ii1ii )
    if 37 - 37: i1111 * ooO / I1Ii - iIiiI1 % o00O0oo . Iiii
   elif len ( i1I11i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
    try :
     ii1ii1ii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II ) [ 0 ]
    except : ii1ii1ii = O0O0OO0O0O0
    o00O ( name , i11Iii + 'NOTPLAY' , 8 , Oo0o00 , ii1ii1ii )
    if 88 - 88: iIiiI1 . o00O0oo * o00O0oo % OOoO00o
  elif '<folder>' in iII1i1I1II :
   iiIii = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II )
   for name , url , Oo0o00 , ii1ii1ii in iiIii :
    ii1i1I1i ( name , url , 1 , Oo0o00 , ii1ii1ii )
    if 15 - 15: ooOoO0o * OOo00O0Oo0oO + i11iIiiIii
  elif '<m3u>' in iII1i1I1II :
   iiIii = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II )
   for name , url , Oo0o00 , ii1ii1ii in iiIii :
    ii1i1I1i ( name , url , 10 , Oo0o00 , ii1ii1ii )
    if 6 - 6: I1Ii / i11iIiiIii + iIiiI1 * Iiii
  else :
   i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( iII1i1I1II )
   if len ( i1I11i1I ) == 1 :
    iiIii = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II )
    ooo0O = len ( i11Iiii )
    for name , url , Oo0o00 , ii1ii1ii in iiIii :
     o00O ( name , url , 2 , Oo0o00 , ii1ii1ii )
   elif len ( i1I11i1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
    Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
    try :
     ii1ii1ii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II ) [ 0 ]
    except : ii1ii1ii = O0O0OO0O0O0
    o00O ( name , i11Iii , 3 , Oo0o00 , ii1ii1ii )
    if 80 - 80: o00O0oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 83 - 83: I1i1I . i11iIiiIii + o00O0oo . i1IIi11111i * I1i1I
def oooO0 ( name , url , iconimage ) :
 iIiIiiIIiIIi = [ ]
 oO0OOOO0 = [ ]
 iI1I11iiI1i = [ ]
 III1i1i = iiI1 ( url )
 oO0o0Ooooo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( III1i1i ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0o0Ooooo ) [ 0 ]
 i1I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( oO0o0Ooooo )
 I11I1II = 1
 for OOo0oO00ooO00 in i1I11i1I :
  oOO0O00oO0Ooo = OOo0oO00ooO00
  if '(' in OOo0oO00ooO00 :
   OOo0oO00ooO00 = OOo0oO00ooO00 . split ( '(' ) [ 0 ]
   oO0Oo0O0o = str ( oOO0O00oO0Ooo . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   iIiIiiIIiIIi . append ( OOo0oO00ooO00 )
   oO0OOOO0 . append ( oO0Oo0O0o )
  else :
   iIiIiiIIiIIi . append ( OOo0oO00ooO00 )
   oO0OOOO0 . append ( 'Link ' + str ( I11I1II ) )
  I11I1II = I11I1II + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( name , oO0OOOO0 )
 if OO < 0 :
  quit ( )
 else :
  url = iIiIiiIIiIIi [ OO ]
  print url
  if 37 - 37: I1Ii % Iiii . i11iIiiIii % OoOoo0 . ooO
 url = iIiIiiIIiIIi [ OO ]
 name = oO0OOOO0 [ OO ]
 I11I1IIII ( name , url , iiiii )
 if 25 - 25: I1i1I
def iiiI1i1I ( name , url , iconimage ) :
 if 13 - 13: OOooO + iII111i + iIiiI1 % OOo00O0Oo0oO / i1IIi11111i . OOooO
 iIiIiiIIiIIi = [ ]
 oO0OOOO0 = [ ]
 iI1I11iiI1i = [ ]
 OO0Oooo0oOO0O = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 III1i1i = iiI1 ( url )
 oO0o0Ooooo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( III1i1i ) [ 0 ]
 i1I11i1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( oO0o0Ooooo )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0o0Ooooo ) [ 0 ]
 if 62 - 62: OOo00O0Oo0oO
 O00o0OO0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 35 - 35: Iiii % I1Ii / OOoO00o + IiII . I1Ii111 . OOo00O0Oo0oO
 I11I1II = 1
 if 71 - 71: OOooO * o00O0oo * Iiii
 for OOo0oO00ooO00 in i1I11i1I :
  oOO0O00oO0Ooo = OOo0oO00ooO00
  if '(' in OOo0oO00ooO00 :
   OOo0oO00ooO00 = OOo0oO00ooO00 . split ( '(' ) [ 0 ]
   oO0Oo0O0o = str ( oOO0O00oO0Ooo . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   iIiIiiIIiIIi . append ( OOo0oO00ooO00 )
   oO0OOOO0 . append ( oO0Oo0O0o )
   OO0Oooo0oOO0O . append ( 'Stream ' + str ( I11I1II ) )
  else :
   iIiIiiIIiIIi . append ( OOo0oO00ooO00 )
   oO0OOOO0 . append ( 'Link ' + str ( I11I1II ) )
   if 56 - 56: OOo00O0Oo0oO
  I11I1II = I11I1II + 1
  if 54 - 54: OOoO00o / oO0o0o0ooO0oO . Iiii % iIiiI1
 name = '[COLOR red]' + name + '[/COLOR]'
 if 57 - 57: i11iIiiIii . I11i1i11i1I - OoOoo0 - Iiii + i1111
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( name , oO0OOOO0 )
 if OO < 0 :
  quit ( )
 else :
  iiI111I1iIiI = oO0OOOO0 [ OO ]
  IIIi1I1IIii1II = "/"
  if not iiI111I1iIiI . endswith ( IIIi1I1IIii1II ) :
   O0 = iiI111I1iIiI + "/"
  else :
   O0 = iiI111I1iIiI
  url = O00o0OO0 + iIiIiiIIiIIi [ OO ] + "%26referer=" + O0
  if 63 - 63: i1111 * iIiiI1
 name = oO0OOOO0 [ OO ]
 I11I1IIII ( name , url , iiiii )
 if 69 - 69: iII111i . IIii11I1
def ii1111iII ( name , url , iconimage ) :
 if 32 - 32: ooOoO0o / o00O0oo . ooO
 oooOo0OOOoo0 , o0OOOOO00o0O0 = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 oooOo0OOOoo0 += urllib . unquote_plus ( o0OOOOO00o0O0 )
 url = regex . resolve ( oooOo0OOOoo0 )
 if 51 - 51: ooO / i1111 . oO0o0o0ooO0oO * i1IIi11111i + IIii11I1 * OOooO
 I11I1IIII ( name , url , iconimage )
 if 73 - 73: IIii11I1 + I1Ii111 - iII111i - OoOoo0 - o00O0oo
def O0O ( ) :
 if 80 - 80: OoOoo0 * i1IIi11111i / i1IIi11111i
 o00O ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 o00O ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 o00O ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 ii1i1I1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 ii1i1I1i ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 5 - 5: OOo00O0Oo0oO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 48 - 48: i1IIi11111i - Iiii / I1Ii111
def OO0O0 ( ) :
 if 30 - 30: oO0o0o0ooO0oO + I11i1i11i1I * I1i1I % i11iIiiIii % i1111
 ii1i1I1i ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 97 - 97: I11i1i11i1I % I11i1i11i1I % Iiii / iIiiI1 - IiII
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 69 - 69: OOoO00o
def ii1I1 ( ) :
 if 93 - 93: iII111i % ooOoO0o . oO0o0o0ooO0oO / OOo00O0Oo0oO - OOoO00o / OOo00O0Oo0oO
 ii1i1I1i ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 36 - 36: Iiii % Iiii % ooOoO0o / ooOoO0o - I1Ii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 30 - 30: I1i1I / OOo00O0Oo0oO
def Iii1I1111ii ( ) :
 if 72 - 72: o00O0oo + ooOoO0o + i1IIi11111i
 I11I1II = 0
 OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for iII1i1I1II in i11Iiii :
  I11I1II = I11I1II + 1
  iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = iII1i1I1II
  ii1i1I1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( I11I1II ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 25 - 25: Iiii - IIii11I1 . IiII % i11iIiiIii % I11i1i11i1I
 OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for iII1i1I1II in i11Iiii :
  I11I1II = I11I1II + 1
  iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = iII1i1I1II
  ii1i1I1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( I11I1II ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 93 - 93: OOooO * I1Ii111 + I1Ii
 OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for iII1i1I1II in i11Iiii :
  I11I1II = I11I1II + 1
  iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = iII1i1I1II
  ii1i1I1i ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( I11I1II ) + '[/COLOR]' , O0O0oOO00O00o , 12 , iiiii , O0O0OO0O0O0 )
  if 33 - 33: iII111i * i1IIi11111i - OOoO00o % OOoO00o
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 18 - 18: OOoO00o / ooO * OOoO00o + OOoO00o * i11iIiiIii * I11i1i11i1I
def I1II1 ( url ) :
 if 86 - 86: IiII / i1111 . o00O0oo
 OOO = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 if 19 - 19: I11i1i11i1I % I1Ii111 % OOooO * i1IIi11111i % iII111i
 for iII1i1I1II in i11Iiii :
  oO = re . compile ( 'title="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
  Oo0o00 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
  ii1i1I1i ( '[COLOR dodgerblue]' + oO + '[/COLOR]' , url , 12 , Oo0o00 , O0O0OO0O0O0 )
  if 67 - 67: OOo00O0Oo0oO . ooOoO0o
 try :
  i1i1iI1iiiI = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( OOO ) [ 0 ]
  ii1i1I1i ( '[COLOR yellow]Next Page -->[/COLOR]' , i1i1iI1iiiI , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 51 - 51: OOo00O0Oo0oO % OOoO00o . Iiii / IiII / I1i1I . Iiii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 42 - 42: i1IIi11111i + ooOoO0o - OoOoo0 / OOooO
def iiIiIIIiiI ( url ) :
 if 12 - 12: iII111i - i1IIi11111i
 OOO = iiI1 ( url )
 i11Iiii = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( OOO )
 for iII1i1I1II in i11Iiii :
  try :
   oO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
  except :
   oO = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
  ii1i1I1i ( '[COLOR dodgerblue]' + oO + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 81 - 81: i1111 - i1111 . iIiiI1
def o0OoOo00o0o ( url ) :
 if 41 - 41: I1Ii % IIii11I1 - ooO * OOoO00o * ooO
 OOO = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( OOO )
 OOOoOO0o = 0
 for iII1i1I1II in i11Iiii :
  try :
   oO = re . compile ( 'title="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
   Oo0o00 = re . compile ( '<img.+?src="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
  except : OOOoOO0o = 1
  if 1 - 1: o00O0oo
  if OOOoOO0o == 0 :
   ii1i1I1i ( '[COLOR dodgerblue]' + oO + '[/COLOR]' , url , 12 , Oo0o00 , O0O0OO0O0O0 )
  OOOoOO0o = 0
  if 68 - 68: iIiiI1 - OOo00O0Oo0oO / OOoO00o / I1i1I
 try :
  i1i1iI1iiiI = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( OOO ) [ 0 ]
  ii1i1I1i ( '[COLOR yellow]Next Page -->[/COLOR]' , i1i1iI1iiiI , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 12 - 12: OoOoo0 + i11iIiiIii * IiII / I11i1i11i1I . I1i1I
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 5 - 5: ooOoO0o + OOooO / i1IIi11111i . iIiiI1 / I1i1I
def IiiiIiii11 ( url ) :
 if 92 - 92: i1111 + OOoO00o * OoOoo0 % OOo00O0Oo0oO
 i1I1i1 = datetime . date . today ( )
 O0OoooO0 = datetime . datetime . strftime ( i1I1i1 , '%A %d %B %Y' )
 if 85 - 85: I1i1I
 o00O ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( O0OoooO0 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 o00O ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 20 - 20: Iiii % OOooO
 OOO = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( OOO )
 OOOoOO0o = 0
 I11I1II = 0
 for iII1i1I1II in i11Iiii :
  try :
   III1i1i11i = re . compile ( 'title="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
   try :
    oOo0 = re . compile ( '<p>(.+?)</p>' ) . findall ( iII1i1I1II ) [ 0 ]
   except : oOo0 = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( iII1i1I1II ) [ 0 ]
   Oo0o00 = re . compile ( '<img src="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
  except : OOOoOO0o = 1
  if 56 - 56: i1IIi11111i + o00O0oo + i1111 - I1Ii . i1111
  if OOOoOO0o == 0 :
   if 'vs' in III1i1i11i :
    oO = '[COLOR dodgerblue]' + III1i1i11i + ' - ' + '[/COLOR][COLOR green]' + oOo0 + '[/COLOR]'
    I11I1II = I11I1II + 1
    o00O ( oO , url , 206 , Oo0o00 , O0O0OO0O0O0 , '' )
  OOOoOO0o = 0
  if 84 - 84: IIii11I1 + ooOoO0o - o00O0oo . I11i1i11i1I * I1Ii111 + OOo00O0Oo0oO
 if I11I1II == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 38 - 38: oO0o0o0ooO0oO + o00O0oo % I1Ii % i1111 - OoOoo0 / I1Ii111
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 73 - 73: i1IIi11111i * iII111i - i11iIiiIii
def O0O0o0oOOO ( name , url , iconimage ) :
 if 67 - 67: i1111 + I11i1i11i1I . i1IIi11111i . o00O0oo
 OOO = iiI1 ( url )
 o000ooooO0o = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( OOO ) [ 0 ]
 if 40 - 40: I11i1i11i1I + ooOoO0o * oO0o0o0ooO0oO
 if not "http" in o000ooooO0o :
  o000ooooO0o = o000ooooO0o . replace ( "//" , "" )
  url = "http://" + o000ooooO0o
 else :
  url = o000ooooO0o
  if 85 - 85: OoOoo0 * ooO . iII111i - i11iIiiIii
 i1I1iIi = url
 if 22 - 22: i1111 * iII111i . OOooO * i11iIiiIii - OOo00O0Oo0oO * I1Ii
 OOooo0O0o0 = iiI1 ( url )
 o000ooooO0o = re . compile ( "atob(.+?)," ) . findall ( OOooo0O0o0 ) [ 0 ]
 o000ooooO0o = o000ooooO0o . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( o000ooooO0o )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + i1I1iIi + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 I11I1IIII ( name , url , iconimage )
 if 14 - 14: i1IIi11111i % iII111i * iIiiI1 + OoOoo0 + ooO * OoOoo0
def iII1I1IiI11ii ( url ) :
 if 72 - 72: OOo00O0Oo0oO % i11iIiiIii . ooO / o00O0oo
 III1i1i = iiI1 ( url )
 i11Iiii = re . compile ( '<item>(.+?)</item>' ) . findall ( III1i1i )
 for iII1i1I1II in i11Iiii :
  if 14 - 14: I11i1i11i1I + IIii11I1
  if '<display>eWVz</display>' in iII1i1I1II :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( iII1i1I1II ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
   ii1ii1ii = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( iII1i1I1II ) [ 0 ]
   oO = base64 . b64decode ( oO )
   url = base64 . b64decode ( url )
   Oo0o00 = base64 . b64decode ( Oo0o00 )
   ii1ii1ii = base64 . b64decode ( ii1ii1ii )
   ii1i1I1i ( oO , url , 220 , Oo0o00 , ii1ii1ii , '' )
   if 3 - 3: I11i1i11i1I . ooO / o00O0oo
def i11IiIiiIiII ( url ) :
 if 49 - 49: o00O0oo
 OOO = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOO )
 if 25 - 25: I1Ii111 - OOo00O0Oo0oO . OOo00O0Oo0oO * Iiii
 for iII1i1I1II in i11Iiii :
  oO = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( iII1i1I1II ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( iII1i1I1II ) [ 0 ]
  try :
   o000oo = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( iII1i1I1II ) [ 0 ]
  except : o000oo = "SD"
  o000oo = '[COLOR yellow]' + o000oo + '[/COLOR]'
  Oo0o00 = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
  oO = oO . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 95 - 95: I1Ii / I1Ii
  o00O ( '[COLOR mediumpurple]' + oO + '[/COLOR] - ' + o000oo , url , 212 , Oo0o00 , O0O0OO0O0O0 , '' )
  if 30 - 30: I11i1i11i1I + ooO / ooO % I11i1i11i1I . I11i1i11i1I
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( OOO ) [ 0 ]
  O0O0Oo00 = 'http://www.fmovies.se/' + url
  ii1i1I1i ( "Next Page -->" , O0O0Oo00 , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 80 - 80: Iiii + oO0o0o0ooO0oO / I1i1I
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 79 - 79: I1Ii
def i11I1I1I ( url ) :
 if 64 - 64: OoOoo0
 OOO = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOO )
 if 66 - 66: i11iIiiIii - oO0o0o0ooO0oO * ooO
 if 76 - 76: i11iIiiIii + i1IIi11111i / I11i1i11i1I - IIii11I1 - OoOoo0 + I11i1i11i1I
def ooI1i ( url ) :
 if 32 - 32: i1111 / IIii11I1 + oO0o0o0ooO0oO
 if "iptvembed" in url :
  OOO = iiI1 ( url )
  i11Iiii = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( OOO )
  for iII1i1I1II in i11Iiii :
   iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
   iII1i1I1II = iII1i1I1II . replace ( '</pre>' , '' )
   url = iII1i1I1II
   if 32 - 32: IiII % iIiiI1
 if "sourcetv" in url :
  OOO = iiI1 ( url )
  i11Iiii = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( OOO )
  for iII1i1I1II in i11Iiii :
   iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
   iII1i1I1II = iII1i1I1II . replace ( '</pre>' , '' )
   url = iII1i1I1II
   if 65 - 65: I1Ii . I1Ii111 / I11i1i11i1I . ooOoO0o * IIii11I1
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 Iii1iiIi1II = [ ]
 for OO0O00oOo , ii1II , url in IiIiII1 :
  iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : url }
  Iii1iiIi1II . append ( iI1IOooOoOo )
 list = [ ]
 for III1I1Iii1iiI in Iii1iiIi1II :
  iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
  IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
  for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
   iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
  list . append ( iI1IOooOoOo )
  if 82 - 82: I1i1I + I1Ii111 - ooOoO0o . ooOoO0o
 iIi1i = 0
 for III1I1Iii1iiI in list :
  iIi1i = 1
  oO = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
  url = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   o00O ( '[COLOR mediumpurple]' + oO + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   ii1i1I1i ( '[COLOR mediumpurple]' + oO + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 77 - 77: I11i1i11i1I + IIii11I1 / Iiii + iII111i * i1IIi11111i
 if iIi1i == 0 :
  o00O ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 28 - 28: I1Ii + i11iIiiIii / I1i1I % i1111 % ooO - iII111i
def ooo0OOO ( url ) :
 if 49 - 49: i11iIiiIii % OoOoo0 . i1111
 III1i1i = iiI1 ( url )
 i11Iii = url
 i11Iiii = re . compile ( '<item>(.+?)</item>' ) . findall ( III1i1i )
 for iII1i1I1II in i11Iiii :
  if 13 - 13: i11iIiiIii + ooOoO0o * IiII % I1Ii111 - o00O0oo * oO0o0o0ooO0oO
  i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( iII1i1I1II )
  if len ( i1I11i1I ) == 1 :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( iII1i1I1II ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
   url = oO + "!" + url + "!" + Oo0o00
   oO = '[COLOR mediumpurple]' + oO + '[/COLOR]'
   ii1i1I1i ( oO , url , 20 , Oo0o00 , Oo0o00 )
   if 26 - 26: I1Ii111 * OOo00O0Oo0oO + oO0o0o0ooO0oO
  elif len ( i1I11i1I ) > 1 :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
   url = i11Iii + "!" + oO + "!" + Oo0o00
   oO = '[COLOR mediumpurple]' + oO + '[/COLOR]'
   ii1i1I1i ( oO , url , 22 , Oo0o00 , Oo0o00 )
   if 24 - 24: i11iIiiIii % IiII + oO0o0o0ooO0oO / i11iIiiIii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 70 - 70: IIii11I1 * iII111i . I1i1I + OOo00O0Oo0oO . OOooO
def Ii1iIiII1Ii ( url ) :
 if 42 - 42: iII111i * OoOoo0 . ooO - OOo00O0Oo0oO * IiII
 i1I1i1 = datetime . date . today ( )
 O0OoooO0 = datetime . datetime . strftime ( i1I1i1 , '%A %d %B %Y' )
 if 28 - 28: I11i1i11i1I
 o00O ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( O0OoooO0 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 o00O ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 61 - 61: oO0o0o0ooO0oO % oO0o0o0ooO0oO * i1IIi11111i / i1IIi11111i
 III1i1i = iiI1 ( url )
 i11Iii = url
 i11Iiii = re . compile ( '<item>(.+?)</item>' ) . findall ( III1i1i )
 for iII1i1I1II in i11Iiii :
  if 75 - 75: OOooO . I1Ii
  i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( iII1i1I1II )
  if len ( i1I11i1I ) == 1 :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( iII1i1I1II ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
   url = oO + "!" + url + "!" + Oo0o00
   oO = '[COLOR mediumpurple]' + oO + '[/COLOR]'
   ii1i1I1i ( oO , url , 20 , Oo0o00 , Oo0o00 )
   if 50 - 50: i1111
  elif len ( i1I11i1I ) > 1 :
   oO = re . compile ( '<title>(.+?)</title>' ) . findall ( iII1i1I1II ) [ 0 ]
   Oo0o00 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iII1i1I1II ) [ 0 ]
   url = i11Iii + "!" + oO + "!" + Oo0o00
   oO = '[COLOR mediumpurple]' + oO + '[/COLOR]'
   ii1i1I1i ( oO , url , 22 , Oo0o00 , Oo0o00 )
   if 60 - 60: I1Ii * IiII * I11i1i11i1I * ooO
def O0ooooo0OOOO0 ( ) :
 if 9 - 9: o00O0oo - i1IIi11111i / iIiiI1 / i1IIi11111i
 i1I1i1 = datetime . date . today ( )
 O0OoooO0 = datetime . datetime . strftime ( i1I1i1 , '%A %d %B %Y' )
 if 40 - 40: oO0o0o0ooO0oO * oO0o0o0ooO0oO . iIiiI1 % iII111i
 o00O ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( O0OoooO0 ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 o00O ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 9 - 9: Iiii + I1i1I / I1i1I
 III1i1i = iiI1 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 i11Iiii = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( III1i1i )
 Ii1I11ii1i = str ( i11Iiii )
 O0iIiIIIIIii = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( Ii1I11ii1i )
 for iII1i1I1II in O0iIiIIIIIii :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in iII1i1I1II :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( iII1i1I1II ) [ 0 ]
    III1i1i11i = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
    Oo0o00 = re . compile ( 'src="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( iII1i1I1II ) [ 0 ]
    try :
     OOo0 = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
     OOo0 = ii11I1 ( OOo0 )
    except : OOo0 = "null"
    oO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + III1i1i11i + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    oO = oO0oo ( oO )
    O0O0oOO00O00o = III1i1i11i + "!" + OOo0 . lower ( ) + "!" + Oo0o00
    ii1i1I1i ( oO , O0O0oOO00O00o , 20 , Oo0o00 , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( iII1i1I1II ) [ 0 ]
    III1i1i11i = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
    try :
     OOo0 = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
    except : OOo0 = "null"
    Oo0o00 = re . compile ( 'src="(.+?)"' ) . findall ( iII1i1I1II ) [ 0 ]
    oO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + III1i1i11i + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    oO = oO0oo ( oO )
    O0O0oOO00O00o = III1i1i11i + "!" + OOo0 . lower ( ) + "!" + Oo0o00
    ii1i1I1i ( oO , O0O0oOO00O00o , 20 , Oo0o00 , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 38 - 38: I1Ii111 * I1Ii % iII111i * i1111
def IIiiI ( name , url , iconimage ) :
 if 31 - 31: I11i1i11i1I + OoOoo0 + OOoO00o / OoOoo0
 try :
  url , iiI111 , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 1 - 1: I1i1I * i1IIi11111i . i1111 / iII111i
 O00 = [ ]
 if 52 - 52: I1Ii + iII111i . iIiiI1 . I11i1i11i1I . IIii11I1
 III1i1i = iiI1 ( url )
 oO0o0Ooooo = re . compile ( '<title>' + re . escape ( iiI111 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( III1i1i ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( oO0o0Ooooo ) [ 0 ]
 i1I11i1I = re . compile ( '<search>(.+?)</search>' ) . findall ( oO0o0Ooooo )
 for OOo0oO00ooO00 in i1I11i1I :
  O00 . append ( OOo0oO00ooO00 )
  if 97 - 97: OOo00O0Oo0oO / iIiiI1
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 71 - 71: o00O0oo / ooOoO0o . I11i1i11i1I % I1Ii111 . i1111
 Iiiiii111i1ii = 0
 if 25 - 25: oO0o0o0ooO0oO - I1Ii / i11iIiiIii
 iiI1ii11i1 = [ ]
 IIi1ii1Ii = [ ]
 OoOoO = [ ]
 I1IiiI . update ( 0 )
 o0 = 0
 if 18 - 18: o00O0oo / OOooO
 if O0oOO0o0 == "true" :
  o0 = 1
  OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for iII1i1I1II in i11Iiii :
   if Iiiiii111i1ii < 100 :
    I1IiiI . update ( Iiiiii111i1ii )
    Iiiiii111i1ii = Iiiiii111i1ii + 3
   iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
   url = iII1i1I1II
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   Iii1iiIi1II = [ ]
   for OO0O00oOo , ii1II , url in IiIiII1 :
    iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : url }
    Iii1iiIi1II . append ( iI1IOooOoOo )
   IiIIii1 = [ ]
   for III1I1Iii1iiI in Iii1iiIi1II :
    iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
    IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
    for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
     iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
    IiIIii1 . append ( iI1IOooOoOo )
    if 53 - 53: OoOoo0 % OoOoo0 * i1IIi11111i + i1111
   for III1I1Iii1iiI in IiIIii1 :
    name = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
    url = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iiI1ii11i1 . append ( name )
    IIi1ii1Ii . append ( url )
    if "hd" in name . lower ( ) :
     OoOoO . append ( "1" )
    else :
     OoOoO . append ( "0" )
    Oooo00 = list ( zip ( OoOoO , iiI1ii11i1 , IIi1ii1Ii ) )
    if 6 - 6: OoOoo0 - I1Ii * oO0o0o0ooO0oO . iIiiI1 / iII111i * I1Ii
 if i1ii1iIII == "true" :
  o0 = 1
  OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for iII1i1I1II in i11Iiii :
   if Iiiiii111i1ii < 100 :
    I1IiiI . update ( Iiiiii111i1ii )
    Iiiiii111i1ii = Iiiiii111i1ii + 3
   iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
   url = iII1i1I1II
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   Iii1iiIi1II = [ ]
   for OO0O00oOo , ii1II , url in IiIiII1 :
    iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : url }
    Iii1iiIi1II . append ( iI1IOooOoOo )
   IiIIii1 = [ ]
   for III1I1Iii1iiI in Iii1iiIi1II :
    iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
    IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
    for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
     iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
    IiIIii1 . append ( iI1IOooOoOo )
    if 22 - 22: ooO % iIiiI1 * I11i1i11i1I / oO0o0o0ooO0oO % i11iIiiIii * I1i1I
   for III1I1Iii1iiI in IiIIii1 :
    name = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
    url = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iiI1ii11i1 . append ( name )
    IIi1ii1Ii . append ( url )
    if "hd" in name . lower ( ) :
     OoOoO . append ( "1" )
    else :
     OoOoO . append ( "0" )
    Oooo00 = list ( zip ( OoOoO , iiI1ii11i1 , IIi1ii1Ii ) )
    if 95 - 95: I1Ii111 - OOooO * OOo00O0Oo0oO + i1111
 if Oo0oO0oo0oO00 == "true" :
  o0 = 1
  OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for iII1i1I1II in i11Iiii :
   if Iiiiii111i1ii < 100 :
    I1IiiI . update ( Iiiiii111i1ii )
    Iiiiii111i1ii = Iiiiii111i1ii + 3
   iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
   url = iII1i1I1II
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   Iii1iiIi1II = [ ]
   for OO0O00oOo , ii1II , url in IiIiII1 :
    iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : url }
    Iii1iiIi1II . append ( iI1IOooOoOo )
   IiIIii1 = [ ]
   for III1I1Iii1iiI in Iii1iiIi1II :
    iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
    IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
    for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
     iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
    IiIIii1 . append ( iI1IOooOoOo )
    if 10 - 10: i1IIi11111i / i11iIiiIii
   for III1I1Iii1iiI in IiIIii1 :
    name = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
    url = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iiI1ii11i1 . append ( name )
    IIi1ii1Ii . append ( url )
    if "hd" in name . lower ( ) :
     OoOoO . append ( "1" )
    else :
     OoOoO . append ( "0" )
    Oooo00 = list ( zip ( OoOoO , iiI1ii11i1 , IIi1ii1Ii ) )
    if 92 - 92: I1i1I . OOoO00o
 if o0 == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 85 - 85: I11i1i11i1I . OOoO00o
 O0O0Ooooo000 = sorted ( Oooo00 , key = lambda o0OOOOO00o0O0 : int ( o0OOOOO00o0O0 [ 0 ] ) , reverse = True )
 o000oOoo0o000 = sorted ( O00 )
 if 40 - 40: i11iIiiIii * OOoO00o - ooOoO0o * OOoO00o - I1i1I . ooOoO0o
 III1iII1I1ii = 0
 if 99 - 99: iII111i * I1i1I
 I1IiiI . update ( 100 )
 if 64 - 64: o00O0oo + iII111i / IiII / ooO . I1Ii % OOooO
 o00O ( '                    [COLOR yellow][I]LINKS FOR ' + iiI111 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 o00O ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 50 - 50: IiII - OOooO + oO0o0o0ooO0oO
 if 69 - 69: iII111i
 for OOo0 in o000oOoo0o000 :
  if 85 - 85: I1Ii / iII111i
  o00O ( '                                  [COLOR mediumpurple][I]' + OOo0 . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 18 - 18: i1IIi11111i % iII111i * I11i1i11i1I
  Ii1I11ii1i = OOo0 . split ( ' ' )
  if 62 - 62: OOoO00o . OOooO . I1Ii111
  for i111 , name , url in O0O0Ooooo000 :
   if 27 - 27: i11iIiiIii / I11i1i11i1I
   oOoOOo = 0
   if 3 - 3: iII111i / iIiiI1
   for iIiIi1I in Ii1I11ii1i :
    if 45 - 45: ooOoO0o + o00O0oo
    if not iIiIi1I . lower ( ) in name . lower ( ) :
     oOoOOo = 1
     if 7 - 7: iII111i % i1IIi11111i + I11i1i11i1I * iIiiI1 - iIiiI1
   if oOoOOo == 0 :
    III1iII1I1ii = III1iII1I1ii + 1
    if "hd" in name . lower ( ) :
     o00O ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( III1iII1I1ii ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     o00O ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( III1iII1I1ii ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 42 - 42: i1111 * i1111 * OOoO00o . I1i1I
  if III1iII1I1ii == 0 :
   o00O ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 51 - 51: oO0o0o0ooO0oO % IiII - I1Ii111 % I1Ii * IiII % IIii11I1
  Ii1I11ii1i = ""
  if 99 - 99: Iiii * o00O0oo * OOoO00o
 I1IiiI . close ( )
 if 92 - 92: ooO
def iI11I ( name , url , iconimage ) :
 if 53 - 53: IiII + OoOoo0 - OOoO00o
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 93 - 93: o00O0oo . OOo00O0Oo0oO - ooO + i1111
 Iiiiii111i1ii = 0
 try :
  iiI111 , OOo0 , iconimage = url . split ( '!' )
 except :
  try :
   OOo0 , iconimage = url . split ( '!' )
   iiI111 = OOo0
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 61 - 61: o00O0oo
 Ii1ii111i1 = 0
 if 31 - 31: oO0o0o0ooO0oO + iII111i
 if "all " in name . lower ( ) :
  OOo0 = OOo0 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  iiI111 = iiI111 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  Ii1ii111i1 = 1
  if 87 - 87: I1Ii
 iiI1ii11i1 = [ ]
 IIi1ii1Ii = [ ]
 OoOoO = [ ]
 I1IiiI . update ( 0 )
 o0 = 0
 if O0oOO0o0 == "true" :
  o0 = 1
  OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for iII1i1I1II in i11Iiii :
   if Iiiiii111i1ii < 100 :
    I1IiiI . update ( Iiiiii111i1ii )
    Iiiiii111i1ii = Iiiiii111i1ii + 3
   iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
   url = iII1i1I1II
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   Iii1iiIi1II = [ ]
   for OO0O00oOo , ii1II , url in IiIiII1 :
    iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : url }
    Iii1iiIi1II . append ( iI1IOooOoOo )
   IiIIii1 = [ ]
   for III1I1Iii1iiI in Iii1iiIi1II :
    iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
    IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
    for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
     iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
    IiIIii1 . append ( iI1IOooOoOo )
    if 45 - 45: IIii11I1 / I1Ii111 - iIiiI1 / OoOoo0 % OOooO
   for III1I1Iii1iiI in IiIIii1 :
    name = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
    url = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iiI1ii11i1 . append ( name )
    IIi1ii1Ii . append ( url )
    if "hd" in name . lower ( ) :
     OoOoO . append ( "1" )
    else :
     OoOoO . append ( "0" )
    Oooo00 = list ( zip ( OoOoO , iiI1ii11i1 , IIi1ii1Ii ) )
    if 83 - 83: OOo00O0Oo0oO . IiII - OOooO * i11iIiiIii
 if i1ii1iIII == "true" :
  o0 = 1
  OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for iII1i1I1II in i11Iiii :
   if Iiiiii111i1ii < 100 :
    I1IiiI . update ( Iiiiii111i1ii )
    Iiiiii111i1ii = Iiiiii111i1ii + 3
   iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
   url = iII1i1I1II
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   Iii1iiIi1II = [ ]
   for OO0O00oOo , ii1II , url in IiIiII1 :
    iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : url }
    Iii1iiIi1II . append ( iI1IOooOoOo )
   IiIIii1 = [ ]
   for III1I1Iii1iiI in Iii1iiIi1II :
    iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
    IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
    for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
     iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
    IiIIii1 . append ( iI1IOooOoOo )
    if 20 - 20: ooOoO0o * OOoO00o + o00O0oo % i1IIi11111i % Iiii
   for III1I1Iii1iiI in IiIIii1 :
    name = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
    url = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iiI1ii11i1 . append ( name )
    IIi1ii1Ii . append ( url )
    if "hd" in name . lower ( ) :
     OoOoO . append ( "1" )
    else :
     OoOoO . append ( "0" )
    Oooo00 = list ( zip ( OoOoO , iiI1ii11i1 , IIi1ii1Ii ) )
    if 13 - 13: ooO
 if Oo0oO0oo0oO00 == "true" :
  o0 = 1
  OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
  for iII1i1I1II in i11Iiii :
   if Iiiiii111i1ii < 100 :
    I1IiiI . update ( Iiiiii111i1ii )
    Iiiiii111i1ii = Iiiiii111i1ii + 3
   iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
   url = iII1i1I1II
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   Iii1iiIi1II = [ ]
   for OO0O00oOo , ii1II , url in IiIiII1 :
    iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : url }
    Iii1iiIi1II . append ( iI1IOooOoOo )
   IiIIii1 = [ ]
   for III1I1Iii1iiI in Iii1iiIi1II :
    iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
    IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
    for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
     iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
    IiIIii1 . append ( iI1IOooOoOo )
    if 60 - 60: I11i1i11i1I * OOo00O0Oo0oO
   for III1I1Iii1iiI in IiIIii1 :
    name = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
    url = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    iiI1ii11i1 . append ( name )
    IIi1ii1Ii . append ( url )
    if "hd" in name . lower ( ) :
     OoOoO . append ( "1" )
    else :
     OoOoO . append ( "0" )
    Oooo00 = list ( zip ( OoOoO , iiI1ii11i1 , IIi1ii1Ii ) )
    if 17 - 17: oO0o0o0ooO0oO % ooO / I11i1i11i1I . OOooO * oO0o0o0ooO0oO - o00O0oo
 if o0 == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 41 - 41: OoOoo0
 O0O0Ooooo000 = sorted ( Oooo00 , key = lambda o0OOOOO00o0O0 : int ( o0OOOOO00o0O0 [ 0 ] ) , reverse = True )
 if 77 - 77: OOoO00o
 III1iII1I1ii = 0
 if 65 - 65: o00O0oo . OOo00O0Oo0oO % Iiii * IIii11I1
 I1IiiI . update ( 100 )
 if 38 - 38: i1111 / iIiiI1 % ooO
 o00O ( '                                [COLOR yellow][I]LINKS FOR ' + iiI111 . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 o00O ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 Ii1I11ii1i = OOo0 . split ( ' ' )
 for i111 , name , url in O0O0Ooooo000 :
  if Ii1ii111i1 == 1 :
   I1IIIiii1 = name
   if 65 - 65: I1i1I / o00O0oo * OoOoo0 . iIiiI1 * Iiii % oO0o0o0ooO0oO
  oOoOOo = 0
  if 69 - 69: I1Ii - IIii11I1 / i11iIiiIii + I11i1i11i1I % I1Ii111
  for iIiIi1I in Ii1I11ii1i :
   if 73 - 73: OoOoo0 - OOoO00o
   if not iIiIi1I . lower ( ) in name . lower ( ) :
    oOoOOo = 1
    if 68 - 68: iIiiI1 * I1Ii111 * IiII . o00O0oo
  if oOoOOo == 0 :
   III1iII1I1ii = III1iII1I1ii + 1
   if Ii1ii111i1 == 1 :
    if "hd" in name . lower ( ) :
     o00O ( '                                          [COLOR blue] ' + str ( I1IIIiii1 ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     o00O ( '                                          [COLOR blue] ' + str ( I1IIIiii1 ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     o00O ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( III1iII1I1ii ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     o00O ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( III1iII1I1ii ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 81 - 81: oO0o0o0ooO0oO / iII111i + I1i1I + OoOoo0 / OOo00O0Oo0oO
 if III1iII1I1ii == 0 :
  o00O ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 27 - 27: i1111 * OOooO
 I1IiiI . close ( )
 if 59 - 59: OOooO . OOooO - o00O0oo + OOooO . ooOoO0o . IIii11I1
def Oo00OOo ( term ) :
 if 64 - 64: o00O0oo
 iIiIiiIIiIIi = [ ]
 oO0OOOO0 = [ ]
 if 77 - 77: i1111 % OoOoo0
 OOO = iiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 i11Iiii = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO )
 for iII1i1I1II in i11Iiii :
  iII1i1I1II = iII1i1I1II . replace ( '<br />' , '\n' )
  O0O0oOO00O00o = iII1i1I1II
  if 9 - 9: IIii11I1 - ooO * I1Ii111 . ooO
  O0O0oOO00O00o = O0O0oOO00O00o . replace ( '#AAASTREAM:' , '#A:' )
  O0O0oOO00O00o = O0O0oOO00O00o . replace ( '#EXTINF:' , '#A:' )
  IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O0O0oOO00O00o )
  Iii1iiIi1II = [ ]
  for OO0O00oOo , ii1II , O0O0oOO00O00o in IiIiII1 :
   iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : O0O0oOO00O00o }
   Iii1iiIi1II . append ( iI1IOooOoOo )
  list = [ ]
  for III1I1Iii1iiI in Iii1iiIi1II :
   iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
   IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
   for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
    iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
   list . append ( iI1IOooOoOo )
   if 2 - 2: I1Ii111 % oO0o0o0ooO0oO
  for III1I1Iii1iiI in list :
   oO = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
   O0O0oOO00O00o = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
   O0O0oOO00O00o = O0O0oOO00O00o . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in oO . lower ( ) :
    iIiIiiIIiIIi . append ( O0O0oOO00O00o )
    oO0OOOO0 . append ( oO )
    if 63 - 63: OOo00O0Oo0oO % IiII
 O00ooooo00 = xbmcgui . Dialog ( )
 OO = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , oO0OOOO0 )
 if OO < 0 :
  quit ( )
  if 39 - 39: iIiiI1 / o00O0oo / I11i1i11i1I % OOo00O0Oo0oO
 O0O0oOO00O00o = iIiIiiIIiIIi [ OO ]
 oO = oO0OOOO0 [ OO ]
 I11I1IIII ( oO , O0O0oOO00O00o , iiiii )
 if 89 - 89: OOoO00o + I1Ii111 + OOoO00o * ooOoO0o + IiII % I1i1I
def oOo0oO ( name , url , iconimage ) :
 if 5 - 5: oO0o0o0ooO0oO - oO0o0o0ooO0oO . ooO + i1111 - oO0o0o0ooO0oO . Iiii
 list = IiIi1i1ii ( url )
 for III1I1Iii1iiI in list :
  name = I1i11111i1i11 ( III1I1Iii1iiI [ "display_name" ] )
  url = I1i11111i1i11 ( III1I1Iii1iiI [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  o00O ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 11 - 11: o00O0oo / i1IIi11111i
def IiIi1i1ii ( url ) :
 if 21 - 21: i11iIiiIii / ooOoO0o + OOo00O0Oo0oO * oO0o0o0ooO0oO . OOoO00o
 OoO = oo0oO ( url )
 OoO = OoO . replace ( '#AAASTREAM:' , '#A:' )
 OoO = OoO . replace ( '#EXTINF:' , '#A:' )
 IiIiII1 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( OoO )
 Iii1iiIi1II = [ ]
 for OO0O00oOo , ii1II , url in IiIiII1 :
  iI1IOooOoOo = { "params" : OO0O00oOo , "display_name" : ii1II , "url" : url }
  Iii1iiIi1II . append ( iI1IOooOoOo )
 list = [ ]
 for III1I1Iii1iiI in Iii1iiIi1II :
  iI1IOooOoOo = { "display_name" : III1I1Iii1iiI [ "display_name" ] , "url" : III1I1Iii1iiI [ "url" ] }
  IiIiII1 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( III1I1Iii1iiI [ "params" ] )
  for i1Iii11I1i , Oo00o0OO0O00o in IiIiII1 :
   iI1IOooOoOo [ i1Iii11I1i . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = Oo00o0OO0O00o . strip ( )
  list . append ( iI1IOooOoOo )
  if 10 - 10: o00O0oo . iIiiI1
 return list
 if 32 - 32: OoOoo0 . OOooO . I1Ii111 - IIii11I1 + Iiii
 if 88 - 88: iIiiI1
def iiI11I1i1i1iI ( ) :
 if 60 - 60: I1Ii111 % ooO + oO0o0o0ooO0oO . I1Ii * IiII
 ii1i1I1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 ii1i1I1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 ii1i1I1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 ii1i1I1i ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 93 - 93: IIii11I1
def i111I ( name , url , iconimage ) :
 if 57 - 57: OOo00O0Oo0oO % I1i1I - oO0o0o0ooO0oO . OOo00O0Oo0oO / ooO % iIiiI1
 OOI1iIi1iiIIiI = datetime . datetime . now ( )
 oOoOOoOOooOO = OOI1iIi1iiIIiI . day
 if 31 - 31: oO0o0o0ooO0oO / ooO * ooOoO0o . i1111
 OO0o0oO = oOoOOoOOooOO
 if 83 - 83: i1IIi11111i / i11iIiiIii % IiII . I1i1I % Iiii . I1Ii111
 o00oO00 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OO0oOOo = datetime . datetime . strftime ( o00oO00 , '%A - %d %B %Y' )
 OO0oO0o = 'http://www.predictz.com/predictions/'
 if 39 - 39: i1IIi11111i * I1Ii + OoOoo0 * o00O0oo
 OoO00o0 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 OOoOoO00O0O0o = datetime . datetime . strftime ( OoO00o0 , '%A - %d %B %Y' )
 iI1I11i = datetime . datetime . strftime ( OoO00o0 , '%d' )
 Ooo0o0oo = 'http://www.predictz.com/predictions/tomorrow/'
 if 26 - 26: o00O0oo % i11iIiiIii % IiII % I1i1I * I1i1I * I11i1i11i1I
 IiI1I11iIii = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 O000O0OO00oo = datetime . datetime . strftime ( IiI1I11iIii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oOOO = datetime . datetime . strftime ( IiI1I11iIii , '%y%m%d' )
 ooo0oooo0 = 'http://www.predictz.com/predictions/20' + str ( oOOO )
 if 62 - 62: I11i1i11i1I + OoOoo0 + ooOoO0o / I1Ii111
 IIiiii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iI111i1I1II = datetime . datetime . strftime ( IIiiii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 O00OO = datetime . datetime . strftime ( IIiiii , '%y%m%d' )
 II1Ii1iI1i1 = 'http://www.predictz.com/predictions/20' + str ( O00OO )
 if 54 - 54: iII111i
 OOoO000O00oO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 i1OoOO = datetime . datetime . strftime ( OOoO000O00oO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIII1I1i1i = datetime . datetime . strftime ( OOoO000O00oO , '%y%m%d' )
 o0OIIiI1I1 = 'http://www.predictz.com/predictions/20' + str ( iIII1I1i1i )
 if 15 - 15: OoOoo0 * ooO % I11i1i11i1I * IiII - i11iIiiIii
 if 60 - 60: OOo00O0Oo0oO * OOoO00o % IIii11I1 + Iiii
 ii1i1I1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OO0oOOo ) + '[/B][/COLOR]' , OO0oO0o , 41 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOoOoO00O0O0o ) + '[/B][/COLOR]' , Ooo0o0oo , 41 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( O000O0OO00oo ) , ooo0oooo0 , 41 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( iI111i1I1II ) , II1Ii1iI1i1 , 41 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( i1OoOO ) , o0OIIiI1I1 , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 52 - 52: ooOoO0o
def o000 ( name , url , iconimage ) :
 if 94 - 94: i1IIi11111i + iII111i / I1i1I . OOo00O0Oo0oO + oO0o0o0ooO0oO . IiII
 III1i1i = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( III1i1i )
 Ii1I11ii1i = str ( i11Iiii )
 O0iIiIIIIIii = re . compile ( '<tr(.+?)</tr>' ) . findall ( Ii1I11ii1i )
 for iII1i1I1II in O0iIiIIIIIii :
  try :
   oOo0 = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR red][B]' + oOo0 + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   III1i1i11i = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   OOOoO = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 0 ]
   III1i1i11i = oOooo ( III1i1i11i )
   OOOoO = oOooo ( OOOoO )
   o00O ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + OOOoO + ' [/B][/COLOR]| [COLOR mediumpurple]' + III1i1i11i + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 74 - 74: IiII * OOooO % i1111
def iiI11iIi ( name , url , iconimage ) :
 if 89 - 89: iII111i
 OOI1iIi1iiIIiI = datetime . datetime . now ( )
 oOoOOoOOooOO = OOI1iIi1iiIIiI . day
 if 2 - 2: I11i1i11i1I . I11i1i11i1I + I11i1i11i1I * i1IIi11111i
 OO0o0oO = oOoOOoOOooOO
 if 100 - 100: ooO % OoOoo0 / I1i1I
 o00oO00 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OO0oOOo = datetime . datetime . strftime ( o00oO00 , '%A - %d %B %Y' )
 OO0oO0o = 'http://www.predictz.com/predictions/'
 if 30 - 30: ooO - oO0o0o0ooO0oO - iIiiI1
 OoO00o0 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 OOoOoO00O0O0o = datetime . datetime . strftime ( OoO00o0 , '%A - %d %B %Y' )
 iI1I11i = datetime . datetime . strftime ( OoO00o0 , '%d' )
 Ooo0o0oo = 'http://www.predictz.com/predictions/tomorrow/'
 if 81 - 81: i1IIi11111i . I1Ii111 + oO0o0o0ooO0oO * I1Ii
 IiI1I11iIii = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 O000O0OO00oo = datetime . datetime . strftime ( IiI1I11iIii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oOOO = datetime . datetime . strftime ( IiI1I11iIii , '%y%m%d' )
 ooo0oooo0 = 'http://www.predictz.com/predictions/20' + str ( oOOO )
 if 74 - 74: ooOoO0o + iII111i + ooO
 IIiiii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iI111i1I1II = datetime . datetime . strftime ( IIiiii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 O00OO = datetime . datetime . strftime ( IIiiii , '%y%m%d' )
 II1Ii1iI1i1 = 'http://www.predictz.com/predictions/20' + str ( O00OO )
 if 5 - 5: ooO * i1111
 OOoO000O00oO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 i1OoOO = datetime . datetime . strftime ( OOoO000O00oO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIII1I1i1i = datetime . datetime . strftime ( OOoO000O00oO , '%y%m%d' )
 o0OIIiI1I1 = 'http://www.predictz.com/predictions/20' + str ( iIII1I1i1i )
 if 46 - 46: I1Ii
 if 33 - 33: iIiiI1 - o00O0oo * I1Ii111 - ooO - oO0o0o0ooO0oO
 ii1i1I1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OO0oOOo ) + '[/B][/COLOR]' , OO0oO0o , 51 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOoOoO00O0O0o ) + '[/B][/COLOR]' , Ooo0o0oo , 51 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( O000O0OO00oo ) , ooo0oooo0 , 51 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( iI111i1I1II ) , II1Ii1iI1i1 , 51 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( i1OoOO ) , o0OIIiI1I1 , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 84 - 84: OOoO00o + ooO - i1111 * i1111
def Ooo ( name , url , iconimage ) :
 if 65 - 65: ooO / I1i1I
 III1i1i = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( III1i1i )
 Ii1I11ii1i = str ( i11Iiii )
 O0iIiIIIIIii = re . compile ( '<tr(.+?)</tr>' ) . findall ( Ii1I11ii1i )
 for iII1i1I1II in O0iIiIIIIIii :
  try :
   oOo0 = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR red][B]' + oOo0 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   III1i1i11i = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   i1IIii1iiIi = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   oooo0OOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 1 ]
   OoO00 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 2 ]
   III1i1i11i = oOooo ( III1i1i11i )
   o00O ( '[COLOR mediumpurple][B]' + III1i1i11i + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + i1IIii1iiIi + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + oooo0OOo + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + OoO00 + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 18 - 18: OoOoo0 - I1Ii111 % o00O0oo - OOo00O0Oo0oO % i1111
def ooo0OOiIi1IiI ( name , url , iconimage ) :
 if 14 - 14: OOooO % Iiii % ooO - i11iIiiIii
 OOI1iIi1iiIIiI = datetime . datetime . now ( )
 oOoOOoOOooOO = OOI1iIi1iiIIiI . day
 if 53 - 53: OoOoo0 % ooO
 OO0o0oO = oOoOOoOOooOO
 if 59 - 59: oO0o0o0ooO0oO % IiII . ooOoO0o + o00O0oo * OOooO
 o00oO00 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OO0oOOo = datetime . datetime . strftime ( o00oO00 , '%A - %d %B %Y' )
 OO0oO0o = 'http://www.predictz.com/predictions/'
 if 41 - 41: OoOoo0 % I11i1i11i1I
 OoO00o0 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 OOoOoO00O0O0o = datetime . datetime . strftime ( OoO00o0 , '%A - %d %B %Y' )
 iI1I11i = datetime . datetime . strftime ( OoO00o0 , '%d' )
 Ooo0o0oo = 'http://www.predictz.com/predictions/tomorrow/'
 if 12 - 12: oO0o0o0ooO0oO
 IiI1I11iIii = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 O000O0OO00oo = datetime . datetime . strftime ( IiI1I11iIii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oOOO = datetime . datetime . strftime ( IiI1I11iIii , '%y%m%d' )
 ooo0oooo0 = 'http://www.predictz.com/predictions/20' + str ( oOOO )
 if 69 - 69: I1Ii111 + oO0o0o0ooO0oO
 IIiiii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iI111i1I1II = datetime . datetime . strftime ( IIiiii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 O00OO = datetime . datetime . strftime ( IIiiii , '%y%m%d' )
 II1Ii1iI1i1 = 'http://www.predictz.com/predictions/20' + str ( O00OO )
 if 26 - 26: ooO + oO0o0o0ooO0oO / IIii11I1 % i1111 % I11i1i11i1I + o00O0oo
 OOoO000O00oO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 i1OoOO = datetime . datetime . strftime ( OOoO000O00oO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIII1I1i1i = datetime . datetime . strftime ( OOoO000O00oO , '%y%m%d' )
 o0OIIiI1I1 = 'http://www.predictz.com/predictions/20' + str ( iIII1I1i1i )
 if 31 - 31: I1i1I % oO0o0o0ooO0oO * I1i1I
 if 45 - 45: ooOoO0o . OOo00O0Oo0oO + oO0o0o0ooO0oO - I1Ii111 % I1Ii
 ii1i1I1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OO0oOOo ) + '[/B][/COLOR]' , OO0oO0o , 61 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOoOoO00O0O0o ) + '[/B][/COLOR]' , Ooo0o0oo , 61 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( O000O0OO00oo ) , ooo0oooo0 , 61 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( iI111i1I1II ) , II1Ii1iI1i1 , 61 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( i1OoOO ) , o0OIIiI1I1 , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 1 - 1: IiII
def ooi1II1I ( name , url , iconimage ) :
 if 95 - 95: IIii11I1 - oO0o0o0ooO0oO / o00O0oo % I11i1i11i1I . i1IIi11111i
 III1i1i = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( III1i1i )
 Ii1I11ii1i = str ( i11Iiii )
 O0iIiIIIIIii = re . compile ( '<tr(.+?)</tr>' ) . findall ( Ii1I11ii1i )
 for iII1i1I1II in O0iIiIIIIIii :
  try :
   oOo0 = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR red][B]' + oOo0 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   III1i1i11i = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   III1iII1I1ii , oOOo0 = III1i1i11i . split ( ' v ' )
   iii1IIII1iii11I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 0 ]
   oo0OoOooo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 1 ]
   O00O00O000OOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 2 ]
   iIOo0O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 3 ]
   Ii11 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 4 ]
   II1i111 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 5 ]
   i1iiiIii11 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 6 ]
   OOoOOO000O0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 7 ]
   oOo0II1i11I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 8 ]
   iiIiIiII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 9 ]
   if 37 - 37: I1i1I / OOooO + o00O0oo
   if iii1IIII1iii11I == "W" :
    iii1IIII1iii11I = '[COLOR lime]W[/COLOR]'
   elif iii1IIII1iii11I == "D" :
    iii1IIII1iii11I = '[COLOR yellow]D[/COLOR]'
   else : iii1IIII1iii11I = '[COLOR red]L[/COLOR]'
   if 18 - 18: I11i1i11i1I
   if oo0OoOooo == "W" :
    oo0OoOooo = '[COLOR lime]W[/COLOR]'
   elif oo0OoOooo == "D" :
    oo0OoOooo = '[COLOR yellow]D[/COLOR]'
   else : oo0OoOooo = '[COLOR red]L[/COLOR]'
   if 23 - 23: o00O0oo
   if O00O00O000OOO == "W" :
    O00O00O000OOO = '[COLOR lime]W[/COLOR]'
   elif O00O00O000OOO == "D" :
    O00O00O000OOO = '[COLOR yellow]D[/COLOR]'
   else : O00O00O000OOO = '[COLOR red]L[/COLOR]'
   if 24 - 24: IiII + IiII * iIiiI1
   if iIOo0O == "W" :
    iIOo0O = '[COLOR lime]W[/COLOR]'
   elif iIOo0O == "D" :
    iIOo0O = '[COLOR yellow]D[/COLOR]'
   else : iIOo0O = '[COLOR red]L[/COLOR]'
   if 18 - 18: iIiiI1 * I1i1I - OoOoo0
   if Ii11 == "W" :
    Ii11 = '[COLOR lime]W[/COLOR]'
   elif Ii11 == "D" :
    Ii11 = '[COLOR yellow]D[/COLOR]'
   else : Ii11 = '[COLOR red]L[/COLOR]'
   if 31 - 31: ooO - iII111i % i1111 % Iiii
   if II1i111 == "W" :
    II1i111 = '[COLOR lime]W[/COLOR]'
   elif II1i111 == "D" :
    II1i111 = '[COLOR yellow]D[/COLOR]'
   else : II1i111 = '[COLOR red]L[/COLOR]'
   if 45 - 45: I11i1i11i1I + o00O0oo * i11iIiiIii
   if i1iiiIii11 == "W" :
    i1iiiIii11 = '[COLOR lime]W[/COLOR]'
   elif i1iiiIii11 == "D" :
    i1iiiIii11 = '[COLOR yellow]D[/COLOR]'
   else : i1iiiIii11 = '[COLOR red]L[/COLOR]'
   if 13 - 13: I1Ii111 * Iiii - OoOoo0 / oO0o0o0ooO0oO + I1i1I + OOooO
   if OOoOOO000O0 == "W" :
    OOoOOO000O0 = '[COLOR lime]W[/COLOR]'
   elif OOoOOO000O0 == "D" :
    OOoOOO000O0 = '[COLOR yellow]D[/COLOR]'
   else : OOoOOO000O0 = '[COLOR red]L[/COLOR]'
   if 39 - 39: IiII - I1Ii111
   if oOo0II1i11I1 == "W" :
    oOo0II1i11I1 = '[COLOR lime]W[/COLOR]'
   elif oOo0II1i11I1 == "D" :
    oOo0II1i11I1 = '[COLOR yellow]D[/COLOR]'
   else : oOo0II1i11I1 = '[COLOR red]L[/COLOR]'
   if 81 - 81: I11i1i11i1I - iII111i * I1Ii111
   if iiIiIiII == "W" :
    iiIiIiII = '[COLOR lime]W[/COLOR]'
   elif iiIiIiII == "D" :
    iiIiIiII = '[COLOR yellow]D[/COLOR]'
   else : iiIiIiII = '[COLOR red]L[/COLOR]'
   if 23 - 23: o00O0oo / Iiii
   III1iII1I1ii = oOooo ( III1iII1I1ii )
   oOOo0 = oOooo ( oOOo0 )
   o00O ( '[COLOR mediumpurple][B]' + III1iII1I1ii + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[B]' + iii1IIII1iii11I + '  ' + oo0OoOooo + '  ' + O00O00O000OOO + '  ' + iIOo0O + '  ' + Ii11 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR mediumpurple][B]' + oOOo0 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[B]' + II1i111 + '  ' + i1iiiIii11 + '  ' + OOoOOO000O0 + '  ' + oOo0II1i11I1 + '  ' + iiIiIiII + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 28 - 28: ooO * I1Ii - IIii11I1
def iI11iiii1I ( name , url , iconimage ) :
 if 3 - 3: iII111i % I1Ii111 / oO0o0o0ooO0oO
 OOI1iIi1iiIIiI = datetime . datetime . now ( )
 oOoOOoOOooOO = OOI1iIi1iiIIiI . day
 if 89 - 89: o00O0oo / Iiii
 OO0o0oO = oOoOOoOOooOO
 if 14 - 14: oO0o0o0ooO0oO . OOo00O0Oo0oO * I1Ii + o00O0oo - I1Ii + oO0o0o0ooO0oO
 o00oO00 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 OO0oOOo = datetime . datetime . strftime ( o00oO00 , '%A - %d %B %Y' )
 OO0oO0o = 'http://www.predictz.com/predictions/'
 if 18 - 18: Iiii - i1IIi11111i - OOo00O0Oo0oO - OOo00O0Oo0oO
 OoO00o0 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 OOoOoO00O0O0o = datetime . datetime . strftime ( OoO00o0 , '%A - %d %B %Y' )
 iI1I11i = datetime . datetime . strftime ( OoO00o0 , '%d' )
 Ooo0o0oo = 'http://www.predictz.com/predictions/tomorrow/'
 if 54 - 54: ooO + OOo00O0Oo0oO / iIiiI1 . OOo00O0Oo0oO * i1111
 IiI1I11iIii = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 O000O0OO00oo = datetime . datetime . strftime ( IiI1I11iIii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oOOO = datetime . datetime . strftime ( IiI1I11iIii , '%y%m%d' )
 ooo0oooo0 = 'http://www.predictz.com/predictions/20' + str ( oOOO )
 if 1 - 1: i1111 * IIii11I1 . ooOoO0o / ooO . I11i1i11i1I + ooO
 IIiiii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 iI111i1I1II = datetime . datetime . strftime ( IIiiii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 O00OO = datetime . datetime . strftime ( IIiiii , '%y%m%d' )
 II1Ii1iI1i1 = 'http://www.predictz.com/predictions/20' + str ( O00OO )
 if 17 - 17: ooO + IIii11I1 / OoOoo0 / iIiiI1 * oO0o0o0ooO0oO
 OOoO000O00oO = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 i1OoOO = datetime . datetime . strftime ( OOoO000O00oO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 iIII1I1i1i = datetime . datetime . strftime ( OOoO000O00oO , '%y%m%d' )
 o0OIIiI1I1 = 'http://www.predictz.com/predictions/20' + str ( iIII1I1i1i )
 if 29 - 29: IIii11I1 % I1Ii111 * Iiii / o00O0oo - Iiii
 if 19 - 19: i11iIiiIii
 ii1i1I1i ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OO0oOOo ) + '[/B][/COLOR]' , OO0oO0o , 71 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( OOoOoO00O0O0o ) + '[/B][/COLOR]' , Ooo0o0oo , 71 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( O000O0OO00oo ) , ooo0oooo0 , 71 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( iI111i1I1II ) , II1Ii1iI1i1 , 71 , iiiii , O0O0OO0O0O0 , '' )
 ii1i1I1i ( str ( i1OoOO ) , o0OIIiI1I1 , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 54 - 54: o00O0oo . I1i1I
def oOO ( name , url , iconimage ) :
 if 32 - 32: i1111 * OOo00O0Oo0oO % I1Ii * OoOoo0 . iII111i
 III1i1i = iiI1 ( url )
 i11Iiii = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( III1i1i )
 Ii1I11ii1i = str ( i11Iiii )
 O0iIiIIIIIii = re . compile ( '<tr(.+?)</tr>' ) . findall ( Ii1I11ii1i )
 for iII1i1I1II in O0iIiIIIIIii :
  try :
   oOo0 = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR red][B]' + oOo0 + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   III1i1i11i = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   III1iII1I1ii , oOOo0 = III1i1i11i . split ( ' v ' )
   if 48 - 48: iIiiI1 * iIiiI1
   OOOoO = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 0 ]
   i1IIii1iiIi = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 0 ]
   oooo0OOo = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 1 ]
   OoO00 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( iII1i1I1II ) [ 2 ]
   iii1IIII1iii11I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 0 ]
   oo0OoOooo = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 1 ]
   O00O00O000OOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 2 ]
   iIOo0O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 3 ]
   Ii11 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 4 ]
   II1i111 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 5 ]
   i1iiiIii11 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 6 ]
   OOoOOO000O0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 7 ]
   oOo0II1i11I1 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 8 ]
   iiIiIiII = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( iII1i1I1II ) [ 9 ]
   if 13 - 13: OoOoo0 / I1i1I + i1111 . i1IIi11111i % I1Ii
   if iii1IIII1iii11I == "W" :
    iii1IIII1iii11I = '[COLOR lime]W[/COLOR]'
   elif iii1IIII1iii11I == "D" :
    iii1IIII1iii11I = '[COLOR yellow]D[/COLOR]'
   else : iii1IIII1iii11I = '[COLOR red]L[/COLOR]'
   if 48 - 48: OOo00O0Oo0oO / i11iIiiIii - i1IIi11111i * Iiii / I1Ii111
   if oo0OoOooo == "W" :
    oo0OoOooo = '[COLOR lime]W[/COLOR]'
   elif oo0OoOooo == "D" :
    oo0OoOooo = '[COLOR yellow]D[/COLOR]'
   else : oo0OoOooo = '[COLOR red]L[/COLOR]'
   if 89 - 89: IiII / OOo00O0Oo0oO - o00O0oo / OoOoo0 . i11iIiiIii . OoOoo0
   if O00O00O000OOO == "W" :
    O00O00O000OOO = '[COLOR lime]W[/COLOR]'
   elif O00O00O000OOO == "D" :
    O00O00O000OOO = '[COLOR yellow]D[/COLOR]'
   else : O00O00O000OOO = '[COLOR red]L[/COLOR]'
   if 48 - 48: iII111i + iII111i . OOoO00o - I1Ii
   if iIOo0O == "W" :
    iIOo0O = '[COLOR lime]W[/COLOR]'
   elif iIOo0O == "D" :
    iIOo0O = '[COLOR yellow]D[/COLOR]'
   else : iIOo0O = '[COLOR red]L[/COLOR]'
   if 63 - 63: Iiii
   if Ii11 == "W" :
    Ii11 = '[COLOR lime]W[/COLOR]'
   elif Ii11 == "D" :
    Ii11 = '[COLOR yellow]D[/COLOR]'
   else : Ii11 = '[COLOR red]L[/COLOR]'
   if 71 - 71: ooOoO0o . OoOoo0 * iIiiI1 % I1Ii111 + oO0o0o0ooO0oO
   if II1i111 == "W" :
    II1i111 = '[COLOR lime]W[/COLOR]'
   elif II1i111 == "D" :
    II1i111 = '[COLOR yellow]D[/COLOR]'
   else : II1i111 = '[COLOR red]L[/COLOR]'
   if 36 - 36: OOooO
   if i1iiiIii11 == "W" :
    i1iiiIii11 = '[COLOR lime]W[/COLOR]'
   elif i1iiiIii11 == "D" :
    i1iiiIii11 = '[COLOR yellow]D[/COLOR]'
   else : i1iiiIii11 = '[COLOR red]L[/COLOR]'
   if 49 - 49: oO0o0o0ooO0oO / I1Ii111 / OOo00O0Oo0oO
   if OOoOOO000O0 == "W" :
    OOoOOO000O0 = '[COLOR lime]W[/COLOR]'
   elif OOoOOO000O0 == "D" :
    OOoOOO000O0 = '[COLOR yellow]D[/COLOR]'
   else : OOoOOO000O0 = '[COLOR red]L[/COLOR]'
   if 74 - 74: OOoO00o % I11i1i11i1I
   if oOo0II1i11I1 == "W" :
    oOo0II1i11I1 = '[COLOR lime]W[/COLOR]'
   elif oOo0II1i11I1 == "D" :
    oOo0II1i11I1 = '[COLOR yellow]D[/COLOR]'
   else : oOo0II1i11I1 = '[COLOR red]L[/COLOR]'
   if 7 - 7: o00O0oo
   if iiIiIiII == "W" :
    iiIiIiII = '[COLOR lime]W[/COLOR]'
   elif iiIiIiII == "D" :
    iiIiIiII = '[COLOR yellow]D[/COLOR]'
   else : iiIiIiII = '[COLOR red]L[/COLOR]'
   if 27 - 27: Iiii . I1Ii111 + i11iIiiIii
   III1iII1I1ii = oOooo ( III1iII1I1ii )
   oOOo0 = oOooo ( oOOo0 )
   III1i1i11i = oOooo ( III1i1i11i )
   OOOoO = oOooo ( OOOoO )
   o00O ( '[COLOR blue][B]' + III1i1i11i + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + OOOoO + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR orange]' + III1iII1I1ii + ' Form: - [/COLOR][B]' + iii1IIII1iii11I + '  ' + oo0OoOooo + '  ' + O00O00O000OOO + '  ' + iIOo0O + '  ' + Ii11 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR orange]' + oOOo0 + ' Form - [/COLOR][B]' + II1i111 + '  ' + i1iiiIii11 + '  ' + OOoOOO000O0 + '  ' + oOo0II1i11I1 + '  ' + iiIiIiII + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR orange]' + III1iII1I1ii + ' Win[/COLOR][COLOR dodgerblue][B] (' + i1IIii1iiIi + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + oooo0OOo + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '[COLOR orange]' + oOOo0 + ' Win[/COLOR][COLOR dodgerblue][B] (' + OoO00 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   o00O ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 86 - 86: I1i1I / i1IIi11111i - i1IIi11111i + I11i1i11i1I + Iiii
  except : pass
  if 33 - 33: i1IIi11111i . iIiiI1 . OOooO . ooOoO0o
def i1II1iII ( ) :
 if 8 - 8: i1111 / iII111i * iII111i % OOoO00o - ooO + I1i1I
 Ii1I11ii1i = ''
 ooIi1IiIiIi1IiI = xbmc . Keyboard ( Ii1I11ii1i , 'Enter Search Term' )
 ooIi1IiIiIi1IiI . doModal ( )
 if ooIi1IiIiIi1IiI . isConfirmed ( ) :
  Ii1I11ii1i = ooIi1IiIiIi1IiI . getText ( )
  if len ( Ii1I11ii1i ) > 1 :
   O0O0oOO00O00o = Ii1I11ii1i + "!" + iiiii
   iI11I ( "all " + Ii1I11ii1i , O0O0oOO00O00o , iiiii )
  else : quit ( )
  if 36 - 36: OOooO - I1Ii111 / IIii11I1
def iIIi1iI1I1IIi ( name , url , iconimage ) :
 if 77 - 77: I1Ii / ooO + I1Ii % i1IIi11111i - OOo00O0Oo0oO * OOo00O0Oo0oO
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 23 - 23: iIiiI1 . o00O0oo % I11i1i11i1I - I1Ii111 * ooO . IiII
def oO0oo ( text ) :
 if 37 - 37: iIiiI1 / ooO . I1i1I * I1i1I
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 80 - 80: oO0o0o0ooO0oO % I11i1i11i1I
 return text
 if 91 - 91: I1i1I / iII111i - OoOoo0 . OOo00O0Oo0oO
def oOooo ( text ) :
 if 82 - 82: OOooO * oO0o0o0ooO0oO / Iiii
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 2 - 2: OOo00O0Oo0oO + i1IIi11111i . i1IIi11111i . iII111i / I1i1I
 return text
 if 40 - 40: i1IIi11111i - o00O0oo / ooO
def ii11I1 ( text ) :
 if 14 - 14: I11i1i11i1I
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 5 - 5: i1IIi11111i . IiII % IiII
 return text
 if 56 - 56: I1Ii111 - I1i1I - ooOoO0o
def I11I1IIII ( name , url , iconimage ) :
 if 8 - 8: OOoO00o / oO0o0o0ooO0oO . OOo00O0Oo0oO + I11i1i11i1I / i11iIiiIii
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 31 - 31: I1Ii - IiII + iIiiI1 . ooO / OOooO % IiII
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 6 - 6: OOooO * i11iIiiIii % IiII % i11iIiiIii + i1IIi11111i / ooOoO0o
 o0o0oOO = url
 i1IiI = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 i1IiI . setProperty ( "IsPlayable" , "true" )
 i1IiI . setPath ( o0o0oOO )
 xbmc . Player ( ) . play ( o0o0oOO , i1IiI , False )
 quit ( )
 if 1 - 1: OOooO / OOooO - i11iIiiIii
def OOoOoo ( ) :
 if 87 - 87: ooO / iII111i * OOooO / i1IIi11111i
 I1iiIII = xbmc . getInfoLabel ( "System.BuildVersion" )
 iIi1I1 = float ( I1iiIII [ : 4 ] )
 if iIi1I1 >= 11.0 and iIi1I1 <= 11.9 :
  O0oOoo0OoO0O = 'Eden'
 elif iIi1I1 >= 12.0 and iIi1I1 <= 12.9 :
  O0oOoo0OoO0O = 'Frodo'
 elif iIi1I1 >= 13.0 and iIi1I1 <= 13.9 :
  O0oOoo0OoO0O = 'Gotham'
 elif iIi1I1 >= 14.0 and iIi1I1 <= 14.9 :
  O0oOoo0OoO0O = 'Helix'
 elif iIi1I1 >= 15.0 and iIi1I1 <= 15.9 :
  O0oOoo0OoO0O = 'Isengard'
 elif iIi1I1 >= 16.0 and iIi1I1 <= 16.9 :
  O0oOoo0OoO0O = 'Jarvis'
 elif iIi1I1 >= 17.0 and iIi1I1 <= 17.9 :
  O0oOoo0OoO0O = 'Krypton'
 else : O0oOoo0OoO0O = "Decline"
 if 63 - 63: I1Ii111 / I1Ii
 return O0oOoo0OoO0O
 if 91 - 91: ooOoO0o - IiII
def iiI1 ( url ) :
 if 55 - 55: OOo00O0Oo0oO * i1IIi11111i % I1Ii . IiII * OOoO00o
 o0oo0000 = urllib2 . Request ( url )
 o0oo0000 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 OoO = urllib2 . urlopen ( o0oo0000 )
 III1i1i = OoO . read ( )
 OoO . close ( )
 III1i1i = III1i1i . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return III1i1i
 if 42 - 42: OOoO00o + OOoO00o * o00O0oo
def oo0oO ( url ) :
 if 78 - 78: I1Ii111
 o0oo0000 = urllib2 . Request ( url )
 o0oo0000 . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 OoO = urllib2 . urlopen ( o0oo0000 )
 III1i1i = OoO . read ( )
 OoO . close ( )
 return III1i1i
 if 77 - 77: I11i1i11i1I / ooOoO0o / ooO % oO0o0o0ooO0oO
def I1i11111i1i11 ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 48 - 48: I1i1I - OOooO + IiII + I1Ii111
 if 4 - 4: o00O0oo . I1i1I + OoOoo0 * OOoO00o . I1Ii
 if 87 - 87: i1111 / IIii11I1 / i11iIiiIii
 if 74 - 74: Iiii / I11i1i11i1I % i1IIi11111i
 if 88 - 88: i1111 - i11iIiiIii % i1IIi11111i * I1i1I + I11i1i11i1I
def OoiIIIiIi1I1i ( ) :
 if 78 - 78: IiII % i1111 + I11i1i11i1I / ooOoO0o % o00O0oo + oO0o0o0ooO0oO
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 91 - 91: IiII % IIii11I1 . i1IIi11111i + OoOoo0 + i1IIi11111i
 if os . path . exists ( Oooo000o ) == True :
  for o00OOo , oOo0OOoooO , iIi1iIIIiIiI in os . walk ( Oooo000o ) :
   OooOo000o0o = 0
   OooOo000o0o += len ( iIi1iIIIiIiI )
   if OooOo000o0o > 0 :
    for iI1I1iII1i in iIi1iIIIiIiI :
     try :
      if ( iI1I1iII1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o00OOo , iI1I1iII1i ) )
     except :
      pass
    for iiIIii in oOo0OOoooO :
     try :
      shutil . rmtree ( os . path . join ( o00OOo , iiIIii ) )
     except :
      pass
      if 70 - 70: i1IIi11111i - oO0o0o0ooO0oO
   else :
    pass
    if 62 - 62: I1i1I
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for o00OOo , oOo0OOoooO , iIi1iIIIiIiI in os . walk ( IiIi11iIIi1Ii ) :
   OooOo000o0o = 0
   OooOo000o0o += len ( iIi1iIIIiIiI )
   if OooOo000o0o > 0 :
    for iI1I1iII1i in iIi1iIIIiIiI :
     try :
      if ( iI1I1iII1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o00OOo , iI1I1iII1i ) )
     except :
      pass
    for iiIIii in oOo0OOoooO :
     try :
      shutil . rmtree ( os . path . join ( o00OOo , iiIIii ) )
     except :
      pass
      if 63 - 63: oO0o0o0ooO0oO + I1Ii * Iiii / i1IIi11111i / ooO * IiII
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  OOoO00ooO = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 12 - 12: I1Ii % OOo00O0Oo0oO + Iiii - ooOoO0o . OoOoo0 / OOo00O0Oo0oO
  for o00OOo , oOo0OOoooO , iIi1iIIIiIiI in os . walk ( OOoO00ooO ) :
   OooOo000o0o = 0
   OooOo000o0o += len ( iIi1iIIIiIiI )
   if 51 - 51: oO0o0o0ooO0oO . OOo00O0Oo0oO
   if OooOo000o0o > 0 :
    for iI1I1iII1i in iIi1iIIIiIiI :
     os . unlink ( os . path . join ( o00OOo , iI1I1iII1i ) )
    for iiIIii in oOo0OOoooO :
     shutil . rmtree ( os . path . join ( o00OOo , iiIIii ) )
     if 73 - 73: I1Ii111 . OOo00O0Oo0oO / OOoO00o % OoOoo0
   else :
    pass
  o0OO0O00o = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 73 - 73: ooOoO0o - oO0o0o0ooO0oO
  for o00OOo , oOo0OOoooO , iIi1iIIIiIiI in os . walk ( o0OO0O00o ) :
   OooOo000o0o = 0
   OooOo000o0o += len ( iIi1iIIIiIiI )
   if 80 - 80: I1Ii + i11iIiiIii / Iiii * I11i1i11i1I * I11i1i11i1I + OOooO
   if OooOo000o0o > 0 :
    for iI1I1iII1i in iIi1iIIIiIiI :
     os . unlink ( os . path . join ( o00OOo , iI1I1iII1i ) )
    for iiIIii in oOo0OOoooO :
     shutil . rmtree ( os . path . join ( o00OOo , iiIIii ) )
     if 76 - 76: i11iIiiIii / i1111 + i1111 / ooOoO0o * OOo00O0Oo0oO
   else :
    pass
    if 12 - 12: OOoO00o % i11iIiiIii + i1IIi11111i + OOoO00o / I1i1I
 o0oO0o00oo = IiIiIi ( )
 if 53 - 53: OOooO . OOoO00o % IiII % i1111 % I1i1I
 for o0OoOoOOoOo0o in o0oO0o00oo :
  iIiii = xbmc . translatePath ( o0OoOoOOoOo0o . path )
  if os . path . exists ( iIiii ) == True :
   for o00OOo , oOo0OOoooO , iIi1iIIIiIiI in os . walk ( iIiii ) :
    OooOo000o0o = 0
    OooOo000o0o += len ( iIi1iIIIiIiI )
    if OooOo000o0o > 0 :
     for iI1I1iII1i in iIi1iIIIiIiI :
      os . unlink ( os . path . join ( o00OOo , iI1I1iII1i ) )
     for iiIIii in oOo0OOoooO :
      shutil . rmtree ( os . path . join ( o00OOo , iiIIii ) )
      if 2 - 2: ooOoO0o - OOo00O0Oo0oO + I1i1I . o00O0oo
    else :
     pass
     if 25 - 25: Iiii
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 34 - 34: i1111 . IiII % iII111i
def iI11Ii111 ( ) :
 OOo00OO00Oo = [ ]
 I1I1I11Ii = sys . argv [ 2 ]
 if len ( I1I1I11Ii ) >= 2 :
  OO0O00oOo = sys . argv [ 2 ]
  ii1Iii1 = OO0O00oOo . replace ( '?' , '' )
  if ( OO0O00oOo [ len ( OO0O00oOo ) - 1 ] == '/' ) :
   OO0O00oOo = OO0O00oOo [ 0 : len ( OO0O00oOo ) - 2 ]
  o0OOOOO0O = ii1Iii1 . split ( '&' )
  OOo00OO00Oo = { }
  for I11I1II in range ( len ( o0OOOOO0O ) ) :
   I1I1IiIi1 = { }
   I1I1IiIi1 = o0OOOOO0O [ I11I1II ] . split ( '=' )
   if ( len ( I1I1IiIi1 ) ) == 2 :
    OOo00OO00Oo [ I1I1IiIi1 [ 0 ] ] = I1I1IiIi1 [ 1 ]
 return OOo00OO00Oo
 if 58 - 58: i1111 - iIiiI1 - I1Ii111
def ii1i1I1i ( name , url , mode , iconimage , fanart , description = '' ) :
 if 96 - 96: IiII
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 OOOo00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OoIIi1iI = True
 i1IiI = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1IiI . setProperty ( "fanart_Image" , fanart )
 i1IiI . setProperty ( "icon_Image" , iconimage )
 OoIIi1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOo00 , listitem = i1IiI , isFolder = True )
 return OoIIi1iI
 if 92 - 92: IIii11I1 * I1Ii
def o00O ( name , url , mode , iconimage , fanart , description = '' ) :
 if 35 - 35: i11iIiiIii
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 OOOo00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OoIIi1iI = True
 i1IiI = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1IiI . setProperty ( "fanart_Image" , fanart )
 i1IiI . setProperty ( "icon_Image" , iconimage )
 OoIIi1iI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOo00 , listitem = i1IiI , isFolder = False )
 return OoIIi1iI
 if 99 - 99: o00O0oo . i1IIi11111i + iII111i
OO0O00oOo = iI11Ii111 ( ) ; O0O0oOO00O00o = None ; oO = None ; O00o0O = None ; iIIIiI = None ; Oo0o00 = None ; ii1ii1ii = None
try : iIIIiI = urllib . unquote_plus ( OO0O00oOo [ "site" ] )
except : pass
try : O0O0oOO00O00o = urllib . unquote_plus ( OO0O00oOo [ "url" ] )
except : pass
try : oO = urllib . unquote_plus ( OO0O00oOo [ "name" ] )
except : pass
try : O00o0O = int ( OO0O00oOo [ "mode" ] )
except : pass
try : Oo0o00 = urllib . unquote_plus ( OO0O00oOo [ "iconimage" ] )
except : pass
try : ii1ii1ii = urllib . unquote_plus ( OO0O00oOo [ "fanart" ] )
except : pass
if 93 - 93: I1Ii . IiII % i11iIiiIii . i1111 % I1Ii + iII111i
if O00o0O == None or O0O0oOO00O00o == None or len ( O0O0oOO00O00o ) < 1 : oOOo0oo ( )
elif O00o0O == 1 : i1 ( oO , O0O0oOO00O00o )
elif O00o0O == 2 : I11I1IIII ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 3 : oooO0 ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 4 : PLAYSD ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 8 : iiiI1i1I ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 9 : AUTO_UPDATER ( oO )
elif O00o0O == 10 : oOo0oO ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 11 : O0O ( )
elif O00o0O == 12 : ooI1i ( O0O0oOO00O00o )
elif O00o0O == 19 : ooo0OOO ( O0O0oOO00O00o )
elif O00o0O == 20 : iI11I ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 21 : Ii1iIiII1Ii ( O0O0oOO00O00o )
elif O00o0O == 22 : IIiiI ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 23 : O0ooooo0OOOO0 ( )
elif O00o0O == 24 : OO0O0 ( )
elif O00o0O == 25 : ii1I1 ( )
elif O00o0O == 26 : iiI11I1i1i1iI ( )
elif O00o0O == 30 : ii1111iII ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 40 : i111I ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 41 : o000 ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 50 : iiI11iIi ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 51 : Ooo ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 60 : ooo0OOiIi1IiI ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 61 : ooi1II1I ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 70 : iI11iiii1I ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 71 : oOO ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 100 : i1II1iII ( )
elif O00o0O == 500 : OoiIIIiIi1I1i ( )
elif O00o0O == 201 : Iii1I1111ii ( )
elif O00o0O == 202 : I1II1 ( O0O0oOO00O00o )
elif O00o0O == 203 : iiIiIIIiiI ( O0O0oOO00O00o )
elif O00o0O == 204 : o0OoOo00o0o ( O0O0oOO00O00o )
elif O00o0O == 205 : IiiiIiii11 ( O0O0oOO00O00o )
elif O00o0O == 206 : O0O0o0oOOO ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 210 : iII1I1IiI11ii ( O0O0oOO00O00o )
elif O00o0O == 220 : i11IiIiiIiII ( O0O0oOO00O00o )
elif O00o0O == 221 : i11I1I1I ( oO , O0O0oOO00O00o , Oo0o00 )
elif O00o0O == 800 : iIIi1iI1I1IIi ( oO , O0O0oOO00O00o , Oo0o00 )
if 65 - 65: OoOoo0 + IIii11I1 - I1Ii111
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )