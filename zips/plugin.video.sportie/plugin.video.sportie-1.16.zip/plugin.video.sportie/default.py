import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
import datetime
from resources . lib . modules import regex
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
II1 = xbmcgui . Dialog ( )
O00ooooo00 = xbmcgui . DialogProgress ( )
I1IiiI = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
I11i11Ii = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
oO00oOo = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
OOOo0 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oooo000o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
if 59 - 59: I11i / Ii1I
#######################################################################
#						Cache Functions
#######################################################################
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
class O0oOO0o0 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 9 - 9: o0o - OOO0o0o
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 40 - 40: II / oo00 * i1I1Ii1iI1ii * o0oOoO00o . i1
oOOoo00O0O = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 15 - 15: I11iii11IIi
class O00o0o0000o0o :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 88 - 88: o0ooo / OOO0O / I1ii * oOOOo0o0O + i1 % o0oOoO00o
  if 37 - 37: o0oOoO00o
  if 34 - 34: i1 * ooOoO0o
  if 31 - 31: I1Ii111 + o0o . I1ii
def OoOooOOOO ( ) :
 i11iiII = 5
 I1iiiiI1iII = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 IiIi11i = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 43 - 43: II * I11i
 I111I11 = [ ]
 if 62 - 62: o0ooo - OOO0O - OOO0o0o % IiII / i1I1Ii1iI1ii
 for OoooooOoo in range ( i11iiII ) :
  I111I11 . append ( O00o0o0000o0o ( I1iiiiI1iII [ OoooooOoo ] , IiIi11i [ OoooooOoo ] ) )
  if 70 - 70: o0o . o0o - o0o / oo00 * o0oOoO00o
 return I111I11
 if 86 - 86: i11iIiiIii + I11iii11IIi + oOOOo0o0O * i1 + II
def oOoO ( ) :
 if 68 - 68: OOO0o0o . i1I1Ii1iI1ii . i11iIiiIii
 IIiI = open ( I1IiiI ) . read ( )
 iI11iiiI1II = IIiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 O0oooo0Oo00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iI11iiiI1II ) )
 for Ii11iii11I in O0oooo0Oo00 :
  oOo00Oo00O = float ( Ii11iii11I )
  if 43 - 43: ooOoO0o - o0ooo * Ii1I
 O0O00o0OOO0 = Ii1iIIIi1ii ( ooo0OO )
 O0O00o0OOO0 = base64 . b64decode ( O0O00o0OOO0 )
 O0O00o0OOO0 = O0O00o0OOO0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 80 - 80: i1 * i11iIiiIii / I1ii
  if '<search>ZGlzcGxheQ==</search>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   IIIII ( I11II1i , ooo0OO , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 75 - 75: I1Ii111 % I1Ii111
  elif '<vipchannels>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   iI1 = re . compile ( '<vipchannels>(.+?)</vipchannels>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   iI1 = base64 . b64decode ( iI1 )
   IIIII ( I11II1i , iI1 , 19 , iiiii , O0O0OO0O0O0 )
   if 19 - 19: i1 + oOOOo0o0O
  elif '<vipgames>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   iI1 = re . compile ( '<vipgames>(.+?)</vipgames>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   iI1 = base64 . b64decode ( iI1 )
   IIIII ( I11II1i , iI1 , 21 , iiiii , O0O0OO0O0O0 )
   if 53 - 53: iII111i . IiII
  elif '<m3ulists>ZGlzcGxheQ==</m3ulists>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   IIIII ( I11II1i , ooo0OO , 11 , iiiii , O0O0OO0O0O0 )
   if 18 - 18: II
  elif '<sportsscrape>ZGlzcGxheQ==</sportsscrape>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   iI1 = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   iI1 = base64 . b64decode ( iI1 )
   IIIII ( I11II1i , iI1 , 205 , iiiii , O0O0OO0O0O0 )
   if 28 - 28: o0oOoO00o - OOO0O . OOO0O + OOO0o0o - iII111i + I11i
   if 95 - 95: o0o % i1I1Ii1iI1ii . I11i
   if 15 - 15: oOOOo0o0O / I11iii11IIi . I11iii11IIi - IiII
   if 53 - 53: OOO0O + ooOoO0o * i1I1Ii1iI1ii
   if 61 - 61: IiII * o0oOoO00o / iII111i . i11iIiiIii . OOO0o0o
   if 60 - 60: i1 / i1
   if 46 - 46: I11iii11IIi * o0oOoO00o - o0o * i1I1Ii1iI1ii - I1ii
   if 83 - 83: iII111i
   if 31 - 31: I1Ii111 - o0oOoO00o . I1ii % OOO0o0o - I11i
   if 4 - 4: I1Ii111 / oOOOo0o0O . o0ooo
   if 58 - 58: o0oOoO00o * i11iIiiIii / OOO0o0o % I1ii - oo00 / i1I1Ii1iI1ii
   if 50 - 50: ooOoO0o
   if 34 - 34: ooOoO0o * I1Ii111 % o0ooo * OOO0o0o - ooOoO0o
   if 33 - 33: II + o0oOoO00o * o0o - o00O0oo / i1I1Ii1iI1ii % I11iii11IIi
   if 21 - 21: o0o * Ii1I % i1I1Ii1iI1ii * IiII
  elif '<sportsdevil>' in Ii11iii11I :
   Ii11Ii1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii11iii11I )
   if len ( Ii11Ii1I ) == 1 :
    I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    iI1 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii11iii11I ) [ 0 ]
    I11i1I1I = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii11iii11I ) [ 0 ]
    I11II1i = base64 . b64decode ( I11II1i )
    O00oO = base64 . b64decode ( O00oO )
    iI1 = base64 . b64decode ( iI1 )
    I11i1I1I = base64 . b64decode ( I11i1I1I )
    oO0Oo = I11i1I1I
    oOOoo0Oo = "/"
    if not oO0Oo . endswith ( oOOoo0Oo ) :
     o00OO00OoO = oO0Oo + "/"
    else :
     o00OO00OoO = oO0Oo
    O0O00o0OOO0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( I11II1i ) + '%26url=' + iI1
    iI1 = O0O00o0OOO0 + '%26referer=' + o00OO00OoO
    OOOO0OOoO0O0 ( I11II1i , iI1 , 4 , O00oO , O0Oo000ooO00 )
   elif len ( Ii11Ii1I ) > 1 :
    I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    I11II1i = base64 . b64decode ( I11II1i )
    O00oO = base64 . b64decode ( O00oO )
    OOOO0OOoO0O0 ( I11II1i , url2 + 'NOTPLAY' , 8 , O00oO , O0Oo000ooO00 )
    if 75 - 75: i1I1Ii1iI1ii . o0o * o0oOoO00o
  elif '<folder>' in Ii11iii11I :
   ooOoOO0oo0O = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
   for I11II1i , iI1 , O00oO , O0Oo000ooO00 in ooOoOO0oo0O :
    I11II1i = base64 . b64decode ( I11II1i )
    iI1 = base64 . b64decode ( iI1 )
    O00oO = base64 . b64decode ( O00oO )
    O0Oo000ooO00 = base64 . b64decode ( O0Oo000ooO00 )
    IIIII ( I11II1i , iI1 , 1 , O00oO , O0Oo000ooO00 )
  elif '<m3u>' in Ii11iii11I :
   ooOoOO0oo0O = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
   for I11II1i , iI1 , O00oO , O0Oo000ooO00 in ooOoOO0oo0O :
    I11II1i = base64 . b64decode ( I11II1i )
    iI1 = base64 . b64decode ( iI1 )
    O00oO = base64 . b64decode ( O00oO )
    O0Oo000ooO00 = base64 . b64decode ( O0Oo000ooO00 )
    IIIII ( I11II1i , iI1 , 10 , O00oO , O0Oo000ooO00 )
  else :
   Ii11Ii1I = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii11iii11I )
   if len ( Ii11Ii1I ) == 1 :
    ooOoOO0oo0O = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
    IIi = len ( O0oooo0Oo00 )
    for I11II1i , iI1 , O00oO , O0Oo000ooO00 in ooOoOO0oo0O :
     I11II1i = base64 . b64decode ( I11II1i )
     iI1 = base64 . b64decode ( iI1 )
     O00oO = base64 . b64decode ( O00oO )
     O0Oo000ooO00 = base64 . b64decode ( O0Oo000ooO00 )
     OOOO0OOoO0O0 ( I11II1i , iI1 , 2 , O00oO , O0Oo000ooO00 )
   elif len ( Ii11Ii1I ) > 1 :
    I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    O0Oo000ooO00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
    I11II1i = base64 . b64decode ( I11II1i )
    O00oO = base64 . b64decode ( O00oO )
    O0Oo000ooO00 = base64 . b64decode ( O0Oo000ooO00 )
    OOOO0OOoO0O0 ( I11II1i , ooo0OO , 3 , O00oO , O0Oo000ooO00 )
    if 26 - 26: o0ooo
 OOOO0OOoO0O0 ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , ooo0OO , 500 , iiiii , O0O0OO0O0O0 , "" )
 OOOO0OOoO0O0 ( '[COLOR dodgerblue]VER ' + str ( oOo00Oo00O ) + '[/COLOR][COLOR yellow] - CHECK FOR UPDATES[/COLOR]' , ooo0OO , 9 , iiiii , O0O0OO0O0O0 , "" )
 if 91 - 91: o0o . oo00 + o0o - o0ooo / iII111i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 39 - 39: oo00 / oOOOo0o0O - I1Ii111
def OO00o ( name , url ) :
 if 61 - 61: I1Ii111 * i1I1Ii1iI1ii % o00O0oo
 hash = [ ]
 O0O0O0OoOO = url
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 if 74 - 74: I1Ii111
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 75 - 75: II . oOOOo0o0O
  if '<regex>' in Ii11iii11I :
   Oo0O00Oo0o0 = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Ii11iii11I )
   Oo0O00Oo0o0 = '' . join ( Oo0O00Oo0o0 )
   O00O0oOO00O00 = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( Oo0O00Oo0o0 )
   Oo0O00Oo0o0 = urllib . quote_plus ( Oo0O00Oo0o0 )
   if 11 - 11: OOO0O . oo00
   o0 = hashlib . md5 ( )
   for oo0oOo in Oo0O00Oo0o0 : o0 . update ( str ( oo0oOo ) )
   o0 = str ( o0 . hexdigest ( ) )
   if 89 - 89: OOO0o0o
   Ii11iii11I = Ii11iii11I . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Ii11iii11I = re . sub ( '<regex>.+?</regex>' , '' , Ii11iii11I )
   Ii11iii11I = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Ii11iii11I )
   Ii11iii11I = re . sub ( '<link></link>' , '' , Ii11iii11I )
   if 68 - 68: o0o * iII111i % I11i + o0o + oOOOo0o0O
   name = re . sub ( '<meta>.+?</meta>' , '' , Ii11iii11I )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 4 - 4: oOOOo0o0O + I11i * o0oOoO00o
   try : OOoo0O = re . findall ( '<date>(.+?)</date>' , Ii11iii11I ) [ 0 ]
   except : OOoo0O = ''
   if re . search ( r'\d+' , OOoo0O ) : name += ' [COLOR red] Updated %s[/COLOR]' % OOoo0O
   if 67 - 67: i11iIiiIii - IiII % oo00 . I11i
   try : o0oo = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Ii11iii11I ) [ 0 ]
   except : o0oo = iiiii
   if 91 - 91: OOO0O
   try : iiIii = re . findall ( '<fanart>(.+?)</fanart>' , Ii11iii11I ) [ 0 ]
   except : iiIii = O0O0OO0O0O0
   if 79 - 79: iII111i / I11i
   try : OO0OoO0o00 = re . findall ( '<meta>(.+?)</meta>' , Ii11iii11I ) [ 0 ]
   except : OO0OoO0o00 = '0'
   if 53 - 53: I11i * o0o + o0oOoO00o
   try : url = re . findall ( '<link>(.+?)</link>' , Ii11iii11I ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % OO0OoO0o00 )
   url = '<preset>search</preset>%s' % OO0OoO0o00 if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % OO0OoO0o00 )
   url = '<preset>searchsd</preset>%s' % OO0OoO0o00 if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 50 - 50: I11i . I11i - i1I1Ii1iI1ii / ooOoO0o - II * OOO0o0o
   if not Oo0O00Oo0o0 == '' :
    hash . append ( { 'regex' : o0 , 'response' : Oo0O00Oo0o0 } )
    url += '|regex=%s' % Oo0O00Oo0o0
    if 61 - 61: i1
   OOOO0OOoO0O0 ( name , url , 30 , o0oo , iiIii )
   if 86 - 86: i1 % OOO0o0o / ooOoO0o / OOO0o0o
  elif '<sportsdevil>' in Ii11iii11I :
   Ii11Ii1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii11iii11I )
   if len ( Ii11Ii1I ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     I11i1I1I = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii11iii11I ) [ 0 ]
    except : I11i1I1I = "None"
    O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     O0Oo000ooO00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
    except : O0Oo000ooO00 = O0O0OO0O0O0
    oO0Oo = I11i1I1I
    oOOoo0Oo = "/"
    if not oO0Oo . endswith ( oOOoo0Oo ) :
     o00OO00OoO = oO0Oo + "/"
    else :
     o00OO00OoO = oO0Oo
    O0O00o0OOO0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = O0O00o0OOO0 + '%26referer=' + o00OO00OoO
    OOOO0OOoO0O0 ( name , url , 2 , O00oO , O0Oo000ooO00 )
    if 42 - 42: o0o
   elif len ( Ii11Ii1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     O0Oo000ooO00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
    except : O0Oo000ooO00 = O0O0OO0O0O0
    OOOO0OOoO0O0 ( name , O0O0O0OoOO + 'NOTPLAY' , 8 , O00oO , O0Oo000ooO00 )
    if 67 - 67: I1ii . o0ooo . I11i
  elif '<folder>' in Ii11iii11I :
   ooOoOO0oo0O = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
   for name , url , O00oO , O0Oo000ooO00 in ooOoOO0oo0O :
    IIIII ( name , url , 1 , O00oO , O0Oo000ooO00 )
    if 10 - 10: oo00 % oo00 - Ii1I / o0oOoO00o + I11iii11IIi
  elif '<m3u>' in Ii11iii11I :
   ooOoOO0oo0O = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
   for name , url , O00oO , O0Oo000ooO00 in ooOoOO0oo0O :
    IIIII ( name , url , 10 , O00oO , O0Oo000ooO00 )
    if 87 - 87: i1I1Ii1iI1ii * oo00 + o0oOoO00o / Ii1I / o0ooo
  else :
   Ii11Ii1I = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii11iii11I )
   if len ( Ii11Ii1I ) == 1 :
    ooOoOO0oo0O = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I )
    IIi = len ( O0oooo0Oo00 )
    for name , url , O00oO , O0Oo000ooO00 in ooOoOO0oo0O :
     OOOO0OOoO0O0 ( name , url , 2 , O00oO , O0Oo000ooO00 )
   elif len ( Ii11Ii1I ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
    O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
    try :
     O0Oo000ooO00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
    except : O0Oo000ooO00 = O0O0OO0O0O0
    OOOO0OOoO0O0 ( name , O0O0O0OoOO , 3 , O00oO , O0Oo000ooO00 )
    if 37 - 37: o0ooo - oOOOo0o0O * i1I1Ii1iI1ii % i11iIiiIii - I1ii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 83 - 83: i1 / ooOoO0o
def iIIiIi1iIII1 ( name , url , iconimage ) :
 Ooo = [ ]
 OOOOo = [ ]
 oo0O0oO = [ ]
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 ooooo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0O00o0OOO0 ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( ooooo ) [ 0 ]
 Ii11Ii1I = re . compile ( '<link>(.+?)</link>' ) . findall ( ooooo )
 oo0oOo = 1
 for II1I in Ii11Ii1I :
  O0 = II1I
  if '(' in II1I :
   II1I = II1I . split ( '(' ) [ 0 ]
   i1II1Iiii1I11 = str ( O0 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   Ooo . append ( II1I )
   OOOOo . append ( i1II1Iiii1I11 )
  else :
   Ooo . append ( II1I )
   OOOOo . append ( 'Link ' + str ( oo0oOo ) )
  oo0oOo = oo0oOo + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 II1 = xbmcgui . Dialog ( )
 IIII = II1 . select ( name , OOOOo )
 if IIII < 0 :
  quit ( )
 else :
  url = Ooo [ IIII ]
  print url
  if 32 - 32: iII111i / Ii1I - II
 url = Ooo [ IIII ]
 name = OOOOo [ IIII ]
 o00oooO0Oo ( name , url , iiiii )
 if 78 - 78: I11iii11IIi % I1ii + oo00
def OOooOoooOoOo ( name , url , iconimage ) :
 if 84 - 84: OOO0O
 Ooo = [ ]
 OOOOo = [ ]
 oo0O0oO = [ ]
 OOO00O0O = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 ooooo = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0O00o0OOO0 ) [ 0 ]
 Ii11Ii1I = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( ooooo )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( ooooo ) [ 0 ]
 if 33 - 33: I11i . OOO0O . ooOoO0o
 OoOO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 53 - 53: o00O0oo
 oo0oOo = 1
 if 29 - 29: oo00 + i1I1Ii1iI1ii % I11i
 for II1I in Ii11Ii1I :
  O0 = II1I
  if '(' in II1I :
   II1I = II1I . split ( '(' ) [ 0 ]
   i1II1Iiii1I11 = str ( O0 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   Ooo . append ( II1I )
   OOOOo . append ( i1II1Iiii1I11 )
   OOO00O0O . append ( 'Stream ' + str ( oo0oOo ) )
  else :
   Ooo . append ( II1I )
   OOOOo . append ( 'Link ' + str ( oo0oOo ) )
   if 10 - 10: i1 / I1ii - ooOoO0o * Ii1I - ooOoO0o
  oo0oOo = oo0oOo + 1
  if 97 - 97: oo00 + ooOoO0o * I11iii11IIi + o0oOoO00o % o0ooo
 name = '[COLOR red]' + name + '[/COLOR]'
 if 74 - 74: i1I1Ii1iI1ii - o00O0oo + iII111i + I1ii / OOO0o0o
 II1 = xbmcgui . Dialog ( )
 IIII = II1 . select ( name , OOOOo )
 if IIII < 0 :
  quit ( )
 else :
  oO0Oo = OOOOo [ IIII ]
  oOOoo0Oo = "/"
  if not oO0Oo . endswith ( oOOoo0Oo ) :
   o00OO00OoO = oO0Oo + "/"
  else :
   o00OO00OoO = oO0Oo
  url = OoOO + Ooo [ IIII ] + "%26referer=" + o00OO00OoO
  if 23 - 23: I11i
 name = OOOOo [ IIII ]
 o00oooO0Oo ( name , url , iiiii )
 if 85 - 85: I11iii11IIi
def OO ( name , url , iconimage ) :
 if 77 - 77: o00O0oo
 I1iII1iIi1I , OoooooOoo = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 I1iII1iIi1I += urllib . unquote_plus ( OoooooOoo )
 url = regex . resolve ( I1iII1iIi1I )
 if 54 - 54: OOO0o0o % o0ooo
 o00oooO0Oo ( name , url , iconimage )
 if 37 - 37: OOO0o0o * o00O0oo / oOOOo0o0O - o0ooo % I1Ii111 . i1I1Ii1iI1ii
def O00 ( ) :
 if 29 - 29: I1ii / o0o . IiII * ooOoO0o + i11iIiiIii
 OOOO0OOoO0O0 ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 OOOO0OOoO0O0 ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 OOOO0OOoO0O0 ( "################################################################" , ooo0OO , 999 , iiiii , O0O0OO0O0O0 , '' )
 IIIII ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , ooo0OO , 201 , iiiii , O0O0OO0O0O0 )
 IIIII ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 IIIII ( '[COLOR green]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 6 - 6: oOOOo0o0O / i11iIiiIii + o0ooo * i1I1Ii1iI1ii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 80 - 80: I1Ii111
def O0O ( ) :
 if 1 - 1: I1Ii111
 oo0oOo = 0
 OOooooO0Oo = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 for Ii11iii11I in O0oooo0Oo00 :
  oo0oOo = oo0oOo + 1
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  iI1 = Ii11iii11I
  IIIII ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( oo0oOo ) + '[/COLOR]' , iI1 , 12 , iiiii , O0O0OO0O0O0 )
  if 91 - 91: II . Ii1I / i1I1Ii1iI1ii + IiII
 OOooooO0Oo = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 for Ii11iii11I in O0oooo0Oo00 :
  oo0oOo = oo0oOo + 1
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  iI1 = Ii11iii11I
  IIIII ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( oo0oOo ) + '[/COLOR]' , iI1 , 12 , iiiii , O0O0OO0O0O0 )
  if 42 - 42: oOOOo0o0O . II . oOOOo0o0O - oo00
 OOooooO0Oo = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 for Ii11iii11I in O0oooo0Oo00 :
  oo0oOo = oo0oOo + 1
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  iI1 = Ii11iii11I
  IIIII ( '[COLOR green]LIST[/COLOR][COLOR blue] ' + str ( oo0oOo ) + '[/COLOR]' , iI1 , 12 , iiiii , O0O0OO0O0O0 )
  if 40 - 40: oOOOo0o0O - i11iIiiIii / I11iii11IIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 35 - 35: I11iii11IIi - ooOoO0o % II . iII111i % I11iii11IIi
def I1i1Iiiii ( url ) :
 if 94 - 94: II * I11iii11IIi / o00O0oo / I11iii11IIi
 OOooooO0Oo = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 if 87 - 87: o00O0oo . OOO0O
 for Ii11iii11I in O0oooo0Oo00 :
  I11II1i = re . compile ( 'title="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  O00oO = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  IIIII ( '[COLOR dodgerblue]' + I11II1i + '[/COLOR]' , url , 12 , O00oO , O0O0OO0O0O0 )
  if 75 - 75: oOOOo0o0O + OOO0o0o + II * i1 % i1I1Ii1iI1ii . o0ooo
 try :
  oO = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( OOooooO0Oo ) [ 0 ]
  IIIII ( '[COLOR yellow]Next Page -->[/COLOR]' , oO , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 31 - 31: o0oOoO00o + i11iIiiIii + o00O0oo * oOOOo0o0O
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 28 - 28: I11i * o00O0oo - o0oOoO00o % Ii1I * I11iii11IIi - i11iIiiIii
def IIII11 ( url ) :
 if 38 - 38: II - i1I1Ii1iI1ii + Ii1I / OOO0o0o % o00O0oo
 OOooooO0Oo = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( OOooooO0Oo )
 for Ii11iii11I in O0oooo0Oo00 :
  try :
   I11II1i = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii11iii11I ) [ 0 ]
  except :
   I11II1i = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Ii11iii11I ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  IIIII ( '[COLOR dodgerblue]' + I11II1i + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 57 - 57: o0o / oOOOo0o0O
def Ii1I1Ii ( url ) :
 if 69 - 69: ooOoO0o / II . OOO0O * I1ii % I11iii11IIi - II
 OOooooO0Oo = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( OOooooO0Oo )
 i1i = 0
 for Ii11iii11I in O0oooo0Oo00 :
  try :
   I11II1i = re . compile ( 'title="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
   O00oO = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  except : i1i = 1
  if 56 - 56: oo00 % I11i - ooOoO0o
  if i1i == 0 :
   IIIII ( '[COLOR dodgerblue]' + I11II1i + '[/COLOR]' , url , 12 , O00oO , O0O0OO0O0O0 )
  i1i = 0
  if 100 - 100: I11iii11IIi - I11i % i1I1Ii1iI1ii * o0oOoO00o + ooOoO0o
 try :
  oO = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( OOooooO0Oo ) [ 0 ]
  IIIII ( '[COLOR yellow]Next Page -->[/COLOR]' , oO , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 88 - 88: iII111i - o0o * I11i * iII111i . iII111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 33 - 33: I1ii + o0ooo * i1I1Ii1iI1ii / Ii1I - ooOoO0o
def O0oO ( url ) :
 if 73 - 73: oo00 * i11iIiiIii % i1I1Ii1iI1ii . oo00
 OOOOo0 = datetime . date . today ( )
 IiiiIIiIi1 = datetime . datetime . strftime ( OOOOo0 , '%A %d %B %Y' )
 if 74 - 74: Ii1I * oo00 + OOO0o0o / IiII / I1Ii111 . o00O0oo
 OOOO0OOoO0O0 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( IiiiIIiIi1 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 OOOO0OOoO0O0 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 62 - 62: iII111i * ooOoO0o
 OOooooO0Oo = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( OOooooO0Oo )
 i1i = 0
 oo0oOo = 0
 for Ii11iii11I in O0oooo0Oo00 :
  try :
   oOOOoo0O0oO = re . compile ( 'title="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
   try :
    iIII1I111III = re . compile ( '<p>(.+?)</p>' ) . findall ( Ii11iii11I ) [ 0 ]
   except : iIII1I111III = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Ii11iii11I ) [ 0 ]
   O00oO = re . compile ( '<img src="(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  except : i1i = 1
  if 20 - 20: II . I1Ii111 % o0oOoO00o * Ii1I
  if i1i == 0 :
   if 'vs' in oOOOoo0O0oO :
    I11II1i = '[COLOR dodgerblue]' + oOOOoo0O0oO + ' - ' + '[/COLOR][COLOR green]' + iIII1I111III + '[/COLOR]'
    oo0oOo = oo0oOo + 1
    OOOO0OOoO0O0 ( I11II1i , url , 206 , O00oO , O0O0OO0O0O0 , '' )
  i1i = 0
  if 98 - 98: ooOoO0o % I11iii11IIi * iII111i
 if oo0oOo == 0 :
  II1 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 51 - 51: Ii1I . OOO0o0o / i1I1Ii1iI1ii + II
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 33 - 33: oOOOo0o0O . I1Ii111 % o0ooo + II
def oO00O000oO0 ( name , url , iconimage ) :
 if 79 - 79: i1 - iII111i - i1I1Ii1iI1ii - Ii1I * o0oOoO00o
 OOooooO0Oo = Ii1iIIIi1ii ( url )
 Iii = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( OOooooO0Oo ) [ 0 ]
 if 16 - 16: I11iii11IIi + OOO0O * I11i % IiII . ooOoO0o
 if not "http" in Iii :
  Iii = Iii . replace ( "//" , "" )
  url = "http://" + Iii
 else :
  url = Iii
  if 67 - 67: iII111i / ooOoO0o * I11iii11IIi + i1
 OooOo0ooo = url
 if 71 - 71: I1ii + I11iii11IIi
 iI1111ii1I = Ii1iIIIi1ii ( url )
 Iii = re . compile ( "atob(.+?)," ) . findall ( iI1111ii1I ) [ 0 ]
 Iii = Iii . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( Iii )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + OooOo0ooo + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 o00oooO0Oo ( name , url , iconimage )
 if 45 - 45: IiII + II
def OOO ( url ) :
 if 25 - 25: i1I1Ii1iI1ii - o0o . Ii1I % i11iIiiIii % oo00
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 93 - 93: OOO0O * iII111i + oOOOo0o0O
  if '<display>eWVz</display>' in Ii11iii11I :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii11iii11I ) [ 0 ]
   O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
   O0Oo000ooO00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
   I11II1i = base64 . b64decode ( I11II1i )
   url = base64 . b64decode ( url )
   O00oO = base64 . b64decode ( O00oO )
   O0Oo000ooO00 = base64 . b64decode ( O0Oo000ooO00 )
   IIIII ( I11II1i , url , 220 , O00oO , O0Oo000ooO00 , '' )
   if 33 - 33: I11i * II - I1ii % I1ii
def I11I ( url ) :
 if 50 - 50: I1ii * i11iIiiIii * Ii1I - I1Ii111 * II * OOO0o0o
 OOooooO0Oo = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 if 94 - 94: iII111i + iII111i . I1Ii111 + i1 / oo00 % I11iii11IIi
 for Ii11iii11I in O0oooo0Oo00 :
  I11II1i = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Ii11iii11I ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Ii11iii11I ) [ 0 ]
  try :
   I1Ii1iiiiii1 = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Ii11iii11I ) [ 0 ]
  except : I1Ii1iiiiii1 = "SD"
  I1Ii1iiiiii1 = '[COLOR yellow]' + I1Ii1iiiiii1 + '[/COLOR]'
  O00oO = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Ii11iii11I ) [ 0 ]
  I11II1i = I11II1i . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 96 - 96: i11iIiiIii % o0oOoO00o
  OOOO0OOoO0O0 ( '[COLOR mediumpurple]' + I11II1i + '[/COLOR] - ' + I1Ii1iiiiii1 , url , 212 , O00oO , O0O0OO0O0O0 , '' )
  if 70 - 70: Ii1I
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( OOooooO0Oo ) [ 0 ]
  i11ii1iI = 'http://www.fmovies.se/' + url
  IIIII ( "Next Page -->" , i11ii1iI , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 22 - 22: iII111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 75 - 75: II + II + IiII - IiII
def OOooOOOooO ( url ) :
 if 12 - 12: I11i - II
 OOooooO0Oo = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 if 81 - 81: OOO0o0o - OOO0o0o . o0ooo
 if 73 - 73: i1 % i11iIiiIii - ooOoO0o
def Ii1iI111II1I1 ( url ) :
 if 91 - 91: o0oOoO00o % o0oOoO00o - ooOoO0o
 if "iptvembed" in url :
  OOooooO0Oo = Ii1iIIIi1ii ( url )
  O0oooo0Oo00 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( OOooooO0Oo )
  for Ii11iii11I in O0oooo0Oo00 :
   Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
   Ii11iii11I = Ii11iii11I . replace ( '</pre>' , '' )
   url = Ii11iii11I
   if 18 - 18: i1 - i11iIiiIii / I1Ii111 . o0oOoO00o
 if "sourcetv" in url :
  OOooooO0Oo = Ii1iIIIi1ii ( url )
  O0oooo0Oo00 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( OOooooO0Oo )
  for Ii11iii11I in O0oooo0Oo00 :
   Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
   Ii11iii11I = Ii11iii11I . replace ( '</pre>' , '' )
   url = Ii11iii11I
   if 55 - 55: IiII % I1Ii111 + i1 * Ii1I
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 o0ooooO0o0O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 iiIi11iI1iii = [ ]
 for oo000 , o0000oO , url in o0ooooO0o0O :
  iI1i111I1Ii = { "params" : oo000 , "display_name" : o0000oO , "url" : url }
  iiIi11iI1iii . append ( iI1i111I1Ii )
 list = [ ]
 for i11i1ii1I in iiIi11iI1iii :
  iI1i111I1Ii = { "display_name" : i11i1ii1I [ "display_name" ] , "url" : i11i1ii1I [ "url" ] }
  o0ooooO0o0O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11i1ii1I [ "params" ] )
  for o0OO0o0o00o , oOo0 in o0ooooO0o0O :
   iI1i111I1Ii [ o0OO0o0o00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oOo0 . strip ( )
  list . append ( iI1i111I1Ii )
  if 56 - 56: II + I1Ii111 + OOO0o0o - oOOOo0o0O . OOO0o0o
 OOOooo = 0
 for i11i1ii1I in list :
  OOOooo = 1
  I11II1i = OooO0OO ( i11i1ii1I [ "display_name" ] )
  url = OooO0OO ( i11i1ii1I [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   OOOO0OOoO0O0 ( '[COLOR mediumpurple]' + I11II1i + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   IIIII ( '[COLOR mediumpurple]' + I11II1i + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 69 - 69: oOOOo0o0O % i1I1Ii1iI1ii
 if OOOooo == 0 :
  OOOO0OOoO0O0 ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 50 - 50: iII111i % i1
def IIii1111 ( url ) :
 if 42 - 42: i1 / II . i1I1Ii1iI1ii + i1I1Ii1iI1ii % OOO0o0o + i11iIiiIii
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 56 - 56: II
  I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
  I1 = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii11iii11I ) [ 0 ]
  O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
  O0Oo000ooO00 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii11iii11I ) [ 0 ]
  url = I11II1i + '!' + I1 + '!' + O00oO
  IIIII ( '[COLOR blue]' + I11II1i + '[/COLOR]' , url , 20 , O00oO , O0Oo000ooO00 )
  if 68 - 68: Ii1I * Ii1I . II / I1Ii111 % o00O0oo
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 38 - 38: oOOOo0o0O - o0oOoO00o / o0ooo
def OoOOoooOO0O ( url ) :
 if 86 - 86: II
 OOOOo0 = datetime . date . today ( )
 IiiiIIiIi1 = datetime . datetime . strftime ( OOOOo0 , '%A %d %B %Y' )
 if 5 - 5: OOO0O * OOO0o0o
 OOOO0OOoO0O0 ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( IiiiIIiIi1 ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 OOOO0OOoO0O0 ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 5 - 5: I1ii
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 O0O0O0OoOO = url
 O0oooo0Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0O00o0OOO0 )
 for Ii11iii11I in O0oooo0Oo00 :
  if 90 - 90: I1ii . oOOOo0o0O / I11iii11IIi - i1
  Ii11Ii1I = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii11iii11I )
  if len ( Ii11Ii1I ) == 1 :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii11iii11I ) [ 0 ]
   O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
   url = I11II1i + "!" + url + "!" + O00oO
   I11II1i = '[COLOR mediumpurple]' + I11II1i + '[/COLOR]'
   IIIII ( I11II1i , url , 20 , O00oO , O00oO )
   if 40 - 40: iII111i
   if 25 - 25: OOO0O + I11iii11IIi / oOOOo0o0O . II % I11i * o0o
  elif len ( Ii11Ii1I ) > 1 :
   I11II1i = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii11iii11I ) [ 0 ]
   O00oO = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii11iii11I ) [ 0 ]
   url = O0O0O0OoOO + "!" + I11II1i + "!" + O00oO
   I11II1i = '[COLOR mediumpurple]' + I11II1i + '[/COLOR]'
   IIIII ( I11II1i , url , 22 , O00oO , O00oO )
   if 84 - 84: oOOOo0o0O % I11iii11IIi + i11iIiiIii
   if 28 - 28: o00O0oo + o0o * o0oOoO00o % i1I1Ii1iI1ii . i1 % I11i
   if 16 - 16: i1 - Ii1I / ooOoO0o . I1Ii111 + Ii1I
   if 19 - 19: o0o - o00O0oo . I11i
   if 60 - 60: I1Ii111 + o00O0oo
   if 9 - 9: oOOOo0o0O * iII111i - Ii1I + OOO0o0o / o0o . o0o
   if 49 - 49: I1Ii111
   if 25 - 25: iII111i - ooOoO0o . ooOoO0o * i1I1Ii1iI1ii
   if 81 - 81: o0ooo + OOO0O
   if 98 - 98: ooOoO0o
   if 95 - 95: oOOOo0o0O / oOOOo0o0O
   if 30 - 30: oo00 + o00O0oo / o00O0oo % oo00 . oo00
   if 55 - 55: oOOOo0o0O - i1 + I1Ii111 + o0ooo % I11iii11IIi
def iiI11i1II ( name , url , iconimage ) :
 if 51 - 51: II % o00O0oo % II * I11i - o0oOoO00o % o00O0oo
 try :
  url , o0O00OooOOOOO , iconimage = url . split ( '!' )
 except :
  II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 40 - 40: II - i11iIiiIii + o0o . Ii1I * I1ii
 iiIII1i = [ ]
 if 31 - 31: o0ooo . o0oOoO00o - oOOOo0o0O . iII111i / iII111i
 O0O00o0OOO0 = Ii1iIIIi1ii ( url )
 ooooo = re . compile ( '<title>' + re . escape ( o0O00OooOOOOO ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0O00o0OOO0 ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( ooooo ) [ 0 ]
 Ii11Ii1I = re . compile ( '<search>(.+?)</search>' ) . findall ( ooooo )
 for II1I in Ii11Ii1I :
  iiIII1i . append ( II1I )
  if 56 - 56: o0o / i1I1Ii1iI1ii / i11iIiiIii + iII111i - o00O0oo - i1
 O00ooooo00 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 O00ooooo00 . update ( 0 )
 if 21 - 21: I11i % OOO0O . ooOoO0o / I1Ii111 + OOO0O
 OOOO0O00o = 0
 if 62 - 62: Ii1I
 i1II = [ ]
 iI1I = [ ]
 OooOoOo = [ ]
 O00ooooo00 . update ( 0 )
 OOooooO0Oo = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 for Ii11iii11I in O0oooo0Oo00 :
  if OOOO0O00o < 100 :
   O00ooooo00 . update ( OOOO0O00o )
   OOOO0O00o = OOOO0O00o + 10
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  url = Ii11iii11I
  url = url . replace ( '#AAASTREAM:' , '#A:' )
  url = url . replace ( '#EXTINF:' , '#A:' )
  o0ooooO0o0O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
  iiIi11iI1iii = [ ]
  for oo000 , o0000oO , url in o0ooooO0o0O :
   iI1i111I1Ii = { "params" : oo000 , "display_name" : o0000oO , "url" : url }
   iiIi11iI1iii . append ( iI1i111I1Ii )
  III1I1Iii1iiI = [ ]
  for i11i1ii1I in iiIi11iI1iii :
   iI1i111I1Ii = { "display_name" : i11i1ii1I [ "display_name" ] , "url" : i11i1ii1I [ "url" ] }
   o0ooooO0o0O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11i1ii1I [ "params" ] )
   for o0OO0o0o00o , oOo0 in o0ooooO0o0O :
    iI1i111I1Ii [ o0OO0o0o00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oOo0 . strip ( )
   III1I1Iii1iiI . append ( iI1i111I1Ii )
   if 17 - 17: I11iii11IIi % Ii1I - Ii1I
  for i11i1ii1I in III1I1Iii1iiI :
   name = OooO0OO ( i11i1ii1I [ "display_name" ] )
   url = OooO0OO ( i11i1ii1I [ "url" ] )
   url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   i1II . append ( name )
   iI1I . append ( url )
   if "hd" in name . lower ( ) :
    OooOoOo . append ( "1" )
   else :
    OooOoOo . append ( "0" )
   O0o0O0 = list ( zip ( OooOoOo , i1II , iI1I ) )
 Ii1II1I11i1 = sorted ( O0o0O0 , key = lambda OoooooOoo : int ( OoooooOoo [ 0 ] ) , reverse = True )
 oOoooooOoO = sorted ( iiIII1i )
 if 33 - 33: I1Ii111 / oOOOo0o0O * I11i % I11iii11IIi * I1ii
 IIiI = 0
 if 100 - 100: OOO0O . i1 / I11iii11IIi % OOO0o0o % I1Ii111 - o0o
 O00ooooo00 . update ( 100 )
 if 46 - 46: I11i * I1Ii111 - o00O0oo * oOOOo0o0O
 OOOO0OOoO0O0 ( '                    [COLOR yellow][I]LINKS FOR ' + o0O00OooOOOOO . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 OOOO0OOoO0O0 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 33 - 33: I11iii11IIi
 if 74 - 74: o0oOoO00o + I11i + IiII - IiII + I1Ii111
 for I1 in oOoooooOoO :
  if 83 - 83: oo00 - ooOoO0o + o0oOoO00o
  OOOO0OOoO0O0 ( '                                  [COLOR mediumpurple][I]' + I1 . upper ( ) + ' LINKS[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 5 - 5: I11iii11IIi
  iIi1i1iIi1iI = I1 . split ( ' ' )
  if 26 - 26: iII111i * ooOoO0o + o0oOoO00o
  for IiIii1i111 , name , url in Ii1II1I11i1 :
   if 43 - 43: I11i
   Ii1 = 0
   if 14 - 14: Ii1I % Ii1I * i11iIiiIii - o0o - i1
   for o00oo0 in iIi1i1iIi1iI :
    if 59 - 59: ooOoO0o * I1Ii111 . I11i
    if not o00oo0 . lower ( ) in name . lower ( ) :
     Ii1 = 1
     if 56 - 56: I11iii11IIi - o0ooo % ooOoO0o - II
   if Ii1 == 0 :
    IIiI = IIiI + 1
    if "hd" in name . lower ( ) :
     OOOO0OOoO0O0 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( IIiI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     OOOO0OOoO0O0 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( IIiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 51 - 51: I11i / oOOOo0o0O * Ii1I + oo00 + II
  if IIiI == 0 :
   OOOO0OOoO0O0 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 98 - 98: Ii1I * oo00 * o0oOoO00o + oOOOo0o0O % i11iIiiIii % I11i
  iIi1i1iIi1iI = ""
  if 27 - 27: I11i
 O00ooooo00 . close ( )
 if 79 - 79: II - i1 + II . i1I1Ii1iI1ii
def ii1III11 ( name , url , iconimage ) :
 if 7 - 7: o0ooo % I11i . OOO0o0o + ooOoO0o - i1
 O00ooooo00 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 O00ooooo00 . update ( 0 )
 if 75 - 75: i1
 OOOO0O00o = 0
 try :
  o0O00OooOOOOO , I1 , iconimage = url . split ( '!' )
 except :
  try :
   I1 , iconimage = url . split ( '!' )
   o0O00OooOOOOO = I1
  except :
   II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 71 - 71: oOOOo0o0O
 Ooo0o00o0o = 0
 if 7 - 7: I11i - o00O0oo + oo00 + I1Ii111 + Ii1I
 if "all" in name . lower ( ) :
  I1 = I1 . replace ( 'all' , '' ) . replace ( 'ALL' , '' ) . replace ( 'All' , '' )
  o0O00OooOOOOO = o0O00OooOOOOO . replace ( 'all' , '' ) . replace ( 'ALL' , '' ) . replace ( 'All' , '' )
  Ooo0o00o0o = 1
  if 58 - 58: II / OOO0O . OOO0o0o / iII111i + I1ii
 i1II = [ ]
 iI1I = [ ]
 OooOoOo = [ ]
 O00ooooo00 . update ( 0 )
 OOooooO0Oo = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 for Ii11iii11I in O0oooo0Oo00 :
  if OOOO0O00o < 100 :
   O00ooooo00 . update ( OOOO0O00o )
   OOOO0O00o = OOOO0O00o + 10
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  url = Ii11iii11I
  url = url . replace ( '#AAASTREAM:' , '#A:' )
  url = url . replace ( '#EXTINF:' , '#A:' )
  o0ooooO0o0O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
  iiIi11iI1iii = [ ]
  for oo000 , o0000oO , url in o0ooooO0o0O :
   iI1i111I1Ii = { "params" : oo000 , "display_name" : o0000oO , "url" : url }
   iiIi11iI1iii . append ( iI1i111I1Ii )
  III1I1Iii1iiI = [ ]
  for i11i1ii1I in iiIi11iI1iii :
   iI1i111I1Ii = { "display_name" : i11i1ii1I [ "display_name" ] , "url" : i11i1ii1I [ "url" ] }
   o0ooooO0o0O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11i1ii1I [ "params" ] )
   for o0OO0o0o00o , oOo0 in o0ooooO0o0O :
    iI1i111I1Ii [ o0OO0o0o00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oOo0 . strip ( )
   III1I1Iii1iiI . append ( iI1i111I1Ii )
   if 86 - 86: i1 * ooOoO0o + i1 + I1Ii111
  for i11i1ii1I in III1I1Iii1iiI :
   name = OooO0OO ( i11i1ii1I [ "display_name" ] )
   url = OooO0OO ( i11i1ii1I [ "url" ] )
   url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   i1II . append ( name )
   iI1I . append ( url )
   if "hd" in name . lower ( ) :
    OooOoOo . append ( "1" )
   else :
    OooOoOo . append ( "0" )
   O0o0O0 = list ( zip ( OooOoOo , i1II , iI1I ) )
 Ii1II1I11i1 = sorted ( O0o0O0 , key = lambda OoooooOoo : int ( OoooooOoo [ 0 ] ) , reverse = True )
 if 8 - 8: I1ii - o0ooo / oOOOo0o0O
 IIiI = 0
 if 96 - 96: OOO0o0o
 O00ooooo00 . update ( 100 )
 if 29 - 29: oo00 / IiII . ooOoO0o - OOO0o0o - OOO0o0o - I11iii11IIi
 OOOO0OOoO0O0 ( '                                [COLOR yellow][I]LINKS FOR ' + o0O00OooOOOOO . upper ( ) + '[/I][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 OOOO0OOoO0O0 ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 iIi1i1iIi1iI = I1 . split ( ' ' )
 for IiIii1i111 , name , url in Ii1II1I11i1 :
  if Ooo0o00o0o == 1 :
   IiiIiI111iI = name
   if 85 - 85: II . OOO0o0o / oOOOo0o0O . I11i % I1ii
  Ii1 = 0
  if 90 - 90: o00O0oo % I11i * Ii1I . o0ooo
  for o00oo0 in iIi1i1iIi1iI :
   if 8 - 8: oOOOo0o0O + I1Ii111 / o0ooo / i1
   if not o00oo0 . lower ( ) in name . lower ( ) :
    Ii1 = 1
    if 74 - 74: I11i / IiII
  if Ii1 == 0 :
   IIiI = IIiI + 1
   if Ooo0o00o0o == 1 :
    if "hd" in name . lower ( ) :
     OOOO0OOoO0O0 ( '                                          [COLOR blue] ' + str ( IiiIiI111iI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     OOOO0OOoO0O0 ( '                                          [COLOR blue] ' + str ( IiiIiI111iI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     OOOO0OOoO0O0 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( IIiI ) + '[/COLOR] - [COLOR red]HD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     OOOO0OOoO0O0 ( '                                             [COLOR green]LINK[/COLOR][COLOR blue] ' + str ( IIiI ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 78 - 78: iII111i . o0o + oOOOo0o0O - IiII
 if IIiI == 0 :
  OOOO0OOoO0O0 ( '                                      [COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 31 - 31: iII111i . o0oOoO00o
 O00ooooo00 . close ( )
 if 83 - 83: o0ooo . I11i / o00O0oo / o0oOoO00o - I1Ii111
def oO0oO0 ( term ) :
 if 14 - 14: o0ooo
 Ooo = [ ]
 OOOOo = [ ]
 if 99 - 99: o0ooo
 OOooooO0Oo = Ii1iIIIi1ii ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0oooo0Oo00 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOooooO0Oo )
 for Ii11iii11I in O0oooo0Oo00 :
  Ii11iii11I = Ii11iii11I . replace ( '<br />' , '\n' )
  iI1 = Ii11iii11I
  if 38 - 38: oo00 - o0ooo / I11i . I1ii
  iI1 = iI1 . replace ( '#AAASTREAM:' , '#A:' )
  iI1 = iI1 . replace ( '#EXTINF:' , '#A:' )
  o0ooooO0o0O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( iI1 )
  iiIi11iI1iii = [ ]
  for oo000 , o0000oO , iI1 in o0ooooO0o0O :
   iI1i111I1Ii = { "params" : oo000 , "display_name" : o0000oO , "url" : iI1 }
   iiIi11iI1iii . append ( iI1i111I1Ii )
  list = [ ]
  for i11i1ii1I in iiIi11iI1iii :
   iI1i111I1Ii = { "display_name" : i11i1ii1I [ "display_name" ] , "url" : i11i1ii1I [ "url" ] }
   o0ooooO0o0O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11i1ii1I [ "params" ] )
   for o0OO0o0o00o , oOo0 in o0ooooO0o0O :
    iI1i111I1Ii [ o0OO0o0o00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oOo0 . strip ( )
   list . append ( iI1i111I1Ii )
   if 45 - 45: I1ii
  for i11i1ii1I in list :
   I11II1i = OooO0OO ( i11i1ii1I [ "display_name" ] )
   iI1 = OooO0OO ( i11i1ii1I [ "url" ] )
   iI1 = iI1 . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in I11II1i . lower ( ) :
    Ooo . append ( iI1 )
    OOOOo . append ( I11II1i )
    if 83 - 83: OOO0o0o . iII111i
 II1 = xbmcgui . Dialog ( )
 IIII = II1 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , OOOOo )
 if IIII < 0 :
  quit ( )
  if 58 - 58: i11iIiiIii + iII111i % iII111i / OOO0O / i11iIiiIii
 iI1 = Ooo [ IIII ]
 I11II1i = OOOOo [ IIII ]
 o00oooO0Oo ( I11II1i , iI1 , iiiii )
 if 62 - 62: o0o / oo00
def ii1 ( name , url , iconimage ) :
 if 53 - 53: I11iii11IIi % I11iii11IIi * II + OOO0o0o
 list = Oooo00 ( url )
 for i11i1ii1I in list :
  name = OooO0OO ( i11i1ii1I [ "display_name" ] )
  url = OooO0OO ( i11i1ii1I [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  OOOO0OOoO0O0 ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 6 - 6: I11iii11IIi - oOOOo0o0O * o0oOoO00o . o0ooo / I11i * oOOOo0o0O
def Oooo00 ( url ) :
 if 22 - 22: o00O0oo % o0ooo * oo00 / o0oOoO00o % i11iIiiIii * i1
 Oo00OoOo = ii1ii111 ( url )
 Oo00OoOo = Oo00OoOo . replace ( '#AAASTREAM:' , '#A:' )
 Oo00OoOo = Oo00OoOo . replace ( '#EXTINF:' , '#A:' )
 o0ooooO0o0O = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( Oo00OoOo )
 iiIi11iI1iii = [ ]
 for oo000 , o0000oO , url in o0ooooO0o0O :
  iI1i111I1Ii = { "params" : oo000 , "display_name" : o0000oO , "url" : url }
  iiIi11iI1iii . append ( iI1i111I1Ii )
 list = [ ]
 for i11i1ii1I in iiIi11iI1iii :
  iI1i111I1Ii = { "display_name" : i11i1ii1I [ "display_name" ] , "url" : i11i1ii1I [ "url" ] }
  o0ooooO0o0O = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( i11i1ii1I [ "params" ] )
  for o0OO0o0o00o , oOo0 in o0ooooO0o0O :
   iI1i111I1Ii [ o0OO0o0o00o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oOo0 . strip ( )
  list . append ( iI1i111I1Ii )
  if 33 - 33: oo00
 return list
 if 92 - 92: OOO0O * o00O0oo * o00O0oo * ooOoO0o . Ii1I
def I1Ii1111iIi ( ) :
 if 31 - 31: i1 . I1ii * oOOOo0o0O + i11iIiiIii * i1I1Ii1iI1ii
 iIi1i1iIi1iI = ''
 OO0ooo0o0O0Oooooo = xbmc . Keyboard ( iIi1i1iIi1iI , 'Enter Search Term' )
 OO0ooo0o0O0Oooooo . doModal ( )
 if OO0ooo0o0O0Oooooo . isConfirmed ( ) :
  iIi1i1iIi1iI = OO0ooo0o0O0Oooooo . getText ( )
  if len ( iIi1i1iIi1iI ) > 1 :
   iI1 = iIi1i1iIi1iI + "!" + iiiii
   ii1III11 ( "all " + iIi1i1iIi1iI , iI1 , iiiii )
  else : quit ( )
  if 1 - 1: oOOOo0o0O % OOO0o0o * o00O0oo
def o0O0oo0 ( name , url , iconimage ) :
 if 30 - 30: I11i * iII111i
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 38 - 38: OOO0O - oo00 . OOO0o0o - I1ii . iII111i
  if 89 - 89: Ii1I
  if 21 - 21: i1 % i1
  if 27 - 27: i11iIiiIii / oo00
  if 84 - 84: o00O0oo
def iIiiiii1i ( name ) :
 if 40 - 40: I11i - iII111i - OOO0O
 OOOooo = 0
 if 37 - 37: OOO0o0o / I1Ii111 / I11i
 try :
  Ii1iIIIi1ii ( "http://www.google.com" )
 except :
  II1 . ok ( Oo0Ooo , '[COLOR red]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/COLOR]' )
  sys . exit ( 0 )
  if 76 - 76: ooOoO0o . oOOOo0o0O - oo00 - o0ooo * o0o
 try :
  O00ooooo00 . create ( Oo0Ooo , "Checking for repository updates" , '' , 'Please Wait...' )
  O00ooooo00 . update ( 0 )
  IIiI = open ( IIi1IiiiI1Ii ) . read ( )
  iI11iiiI1II = IIiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  O0oooo0Oo00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iI11iiiI1II ) )
  for Ii11iii11I in O0oooo0Oo00 :
   O00ooooo00 . update ( 25 )
   oOo00Oo00O = float ( Ii11iii11I ) + 0.01
   iI1 = oO00oOo + str ( oOo00Oo00O ) + '.zip'
   OOooooO0Oo = Ii1iIIIi1ii ( iI1 )
   if "Not Found" not in OOooooO0Oo :
    OOOooo = 1
    O00ooooo00 . update ( 75 )
    oOOoo00O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( oOOoo00O0O ) :
     os . makedirs ( oOOoo00O0O )
    O0Oo00O = os . path . join ( oOOoo00O0O , 'repoupdate.zip' )
    try : os . remove ( O0Oo00O )
    except : pass
    O00ooooo00 . update ( 100 )
    O00ooooo00 . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( iI1 , O0Oo00O , O00ooooo00 )
    OOo0o000oO = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    O00ooooo00 . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( O0Oo00O , OOo0o000oO , O00ooooo00 )
    try : os . remove ( O0Oo00O )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    II1 . ok ( Oo0Ooo , "ECHO repository was updated to " + str ( oOo00Oo00O ) + ', you may need to restart the addon for changes to take effect' )
    if 99 - 99: i1I1Ii1iI1ii * I1Ii111 * I1ii
  O00ooooo00 . update ( 75 , "Checking for addon updates" )
  IIiI = open ( I1IiiI ) . read ( )
  iI11iiiI1II = IIiI . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
  O0oooo0Oo00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iI11iiiI1II ) )
  for Ii11iii11I in O0oooo0Oo00 :
   oOo00Oo00O = float ( Ii11iii11I ) + 0.01
   iI1 = I11i11Ii + str ( oOo00Oo00O ) + '.zip'
   OOooooO0Oo = Ii1iIIIi1ii ( iI1 )
   if "Not Found" not in OOooooO0Oo :
    OOOooo = 1
    O00ooooo00 . update ( 75 )
    oOOoo00O0O = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( oOOoo00O0O ) :
     os . makedirs ( oOOoo00O0O )
    O0Oo00O = os . path . join ( oOOoo00O0O , 'wizupdate.zip' )
    try : os . remove ( O0Oo00O )
    except : pass
    O00ooooo00 . update ( 100 )
    O00ooooo00 . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    import downloader
    downloader . download ( iI1 , O0Oo00O , O00ooooo00 )
    OOo0o000oO = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    O00ooooo00 . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    import extract
    extract . all ( O0Oo00O , OOo0o000oO , O00ooooo00 )
    try : os . remove ( O0Oo00O )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    O00ooooo00 . update ( 100 )
    O00ooooo00 . close
    II1 . ok ( Oo0Ooo , "Sportie was updated to " + str ( oOo00Oo00O ) + ', you may need to restart the addon for changes to take effect' )
 except :
  II1 . ok ( Oo0Ooo , 'Sorry! We encountered an error whilst checking for updates. You can make Kodi force check the repository for updates as an alternative if you wish.' )
  quit ( )
  if 92 - 92: o00O0oo
 if O00ooooo00 . iscanceled ( ) :
  O00ooooo00 . close ( )
 else :
  if OOOooo == 0 :
   if not name == "no dialog" :
    II1 . ok ( Oo0Ooo , "There are no updates at this time." )
    quit ( )
    if 40 - 40: OOO0o0o / OOO0O
def o00oooO0Oo ( name , url , iconimage ) :
 if 79 - 79: o0o - Ii1I + I11iii11IIi - I1ii
 try :
  if not 'http' in url : url = 'http://' + url
 except :
  II1 . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 93 - 93: I1Ii111 . ooOoO0o - o00O0oo + OOO0o0o
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 61 - 61: I1Ii111
 Ii1ii111i1 = url
 i1i1i1I = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 i1i1i1I . setPath ( Ii1ii111i1 )
 xbmc . Player ( ) . play ( Ii1ii111i1 , i1i1i1I , False )
 if 83 - 83: i1I1Ii1iI1ii + iII111i
def Ii1iIIIi1ii ( url ) :
 if 22 - 22: I11iii11IIi % o0ooo * iII111i - II / Ii1I
 Oo = urllib2 . Request ( url )
 Oo . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 Oo00OoOo = urllib2 . urlopen ( Oo )
 O0O00o0OOO0 = Oo00OoOo . read ( )
 Oo00OoOo . close ( )
 O0O00o0OOO0 = O0O00o0OOO0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return O0O00o0OOO0
 if 84 - 84: OOO0o0o / i1 * o0ooo / i1I1Ii1iI1ii - i11iIiiIii . o00O0oo
def ii1ii111 ( url ) :
 if 60 - 60: oo00 * ooOoO0o
 Oo = urllib2 . Request ( url )
 Oo . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 Oo00OoOo = urllib2 . urlopen ( Oo )
 O0O00o0OOO0 = Oo00OoOo . read ( )
 Oo00OoOo . close ( )
 return O0O00o0OOO0
 if 17 - 17: o0oOoO00o % o00O0oo / oo00 . OOO0O * o0oOoO00o - I1Ii111
def OooO0OO ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 41 - 41: I11iii11IIi
 if 77 - 77: I1ii
 if 65 - 65: I1Ii111 . ooOoO0o % i1I1Ii1iI1ii * o0o
 if 38 - 38: OOO0o0o / o0ooo % o00O0oo
 if 11 - 11: o0ooo - i1I1Ii1iI1ii + I1Ii111 - Ii1I
def I1i11ii11 ( ) :
 if 81 - 81: o0oOoO00o - i1 % oOOOo0o0O - o0o / o00O0oo
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 4 - 4: iII111i - IiII % I11iii11IIi - o0oOoO00o * II
 if os . path . exists ( OOOo0 ) == True :
  for Ooooo00o0OoO , oooo0O0O0o0 , Ooo0oo in os . walk ( OOOo0 ) :
   IIi11IIiIii1 = 0
   IIi11IIiIii1 += len ( Ooo0oo )
   if IIi11IIiIii1 > 0 :
    for I1iIII1 in Ooo0oo :
     try :
      if ( I1iIII1 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( Ooooo00o0OoO , I1iIII1 ) )
     except :
      pass
    for iIii in oooo0O0O0o0 :
     try :
      shutil . rmtree ( os . path . join ( Ooooo00o0OoO , iIii ) )
     except :
      pass
      if 84 - 84: i1I1Ii1iI1ii % IiII
   else :
    pass
    if 70 - 70: o00O0oo . iII111i - o0ooo
 if os . path . exists ( Oooo000o ) == True :
  for Ooooo00o0OoO , oooo0O0O0o0 , Ooo0oo in os . walk ( Oooo000o ) :
   IIi11IIiIii1 = 0
   IIi11IIiIii1 += len ( Ooo0oo )
   if IIi11IIiIii1 > 0 :
    for I1iIII1 in Ooo0oo :
     try :
      if ( I1iIII1 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( Ooooo00o0OoO , I1iIII1 ) )
     except :
      pass
    for iIii in oooo0O0O0o0 :
     try :
      shutil . rmtree ( os . path . join ( Ooooo00o0OoO , iIii ) )
     except :
      pass
      if 30 - 30: oo00 % ooOoO0o
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  O0Oo00 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 41 - 41: Ii1I % i1
  for Ooooo00o0OoO , oooo0O0O0o0 , Ooo0oo in os . walk ( O0Oo00 ) :
   IIi11IIiIii1 = 0
   IIi11IIiIii1 += len ( Ooo0oo )
   if 59 - 59: o0oOoO00o + i11iIiiIii
   if IIi11IIiIii1 > 0 :
    for I1iIII1 in Ooo0oo :
     os . unlink ( os . path . join ( Ooooo00o0OoO , I1iIII1 ) )
    for iIii in oooo0O0O0o0 :
     shutil . rmtree ( os . path . join ( Ooooo00o0OoO , iIii ) )
     if 88 - 88: i11iIiiIii - oOOOo0o0O
   else :
    pass
  O0iIi1IiII = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 27 - 27: o0ooo . i1 . Ii1I . Ii1I
  for Ooooo00o0OoO , oooo0O0O0o0 , Ooo0oo in os . walk ( O0iIi1IiII ) :
   IIi11IIiIii1 = 0
   IIi11IIiIii1 += len ( Ooo0oo )
   if 20 - 20: II / IiII
   if IIi11IIiIii1 > 0 :
    for I1iIII1 in Ooo0oo :
     os . unlink ( os . path . join ( Ooooo00o0OoO , I1iIII1 ) )
    for iIii in oooo0O0O0o0 :
     shutil . rmtree ( os . path . join ( Ooooo00o0OoO , iIii ) )
     if 71 - 71: OOO0o0o . IiII
   else :
    pass
    if 94 - 94: o0oOoO00o . I1ii
 I111I11 = OoOooOOOO ( )
 if 84 - 84: I11i . i1 - I1Ii111 . oOOOo0o0O / I1Ii111
 for iii1 in I111I11 :
  I1i = xbmc . translatePath ( iii1 . path )
  if os . path . exists ( I1i ) == True :
   for Ooooo00o0OoO , oooo0O0O0o0 , Ooo0oo in os . walk ( I1i ) :
    IIi11IIiIii1 = 0
    IIi11IIiIii1 += len ( Ooo0oo )
    if IIi11IIiIii1 > 0 :
     for I1iIII1 in Ooo0oo :
      os . unlink ( os . path . join ( Ooooo00o0OoO , I1iIII1 ) )
     for iIii in oooo0O0O0o0 :
      shutil . rmtree ( os . path . join ( Ooooo00o0OoO , iIii ) )
      if 86 - 86: o00O0oo / i1I1Ii1iI1ii + I11i * o0ooo
    else :
     pass
     if 19 - 19: I1Ii111 * OOO0O + I11iii11IIi
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 II1 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 65 - 65: o0oOoO00o . I1ii . o0o . o0ooo - o0oOoO00o
def ii111i ( ) :
 oooo00 = [ ]
 O00OO0oO = sys . argv [ 2 ]
 if len ( O00OO0oO ) >= 2 :
  oo000 = sys . argv [ 2 ]
  iI1I1iIi11 = oo000 . replace ( '?' , '' )
  if ( oo000 [ len ( oo000 ) - 1 ] == '/' ) :
   oo000 = oo000 [ 0 : len ( oo000 ) - 2 ]
  oo0ooOO = iI1I1iIi11 . split ( '&' )
  oooo00 = { }
  for oo0oOo in range ( len ( oo0ooOO ) ) :
   iI1IiIIiIIi = { }
   iI1IiIIiIIi = oo0ooOO [ oo0oOo ] . split ( '=' )
   if ( len ( iI1IiIIiIIi ) ) == 2 :
    oooo00 [ iI1IiIIiIIi [ 0 ] ] = iI1IiIIiIIi [ 1 ]
 return oooo00
 if 10 - 10: ooOoO0o - IiII - oOOOo0o0O % o00O0oo
def IIIII ( name , url , mode , iconimage , fanart , description = '' ) :
 if 6 - 6: oo00 + i1I1Ii1iI1ii
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 Ii1iI11iI1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 i11 = True
 i1i1i1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1i1i1I . setProperty ( "fanart_Image" , fanart )
 i1i1i1I . setProperty ( "icon_Image" , iconimage )
 i11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1iI11iI1 , listitem = i1i1i1I , isFolder = True )
 return i11
 if 11 - 11: I1ii / OOO0o0o + i1 % Ii1I
def OOOO0OOoO0O0 ( name , url , mode , iconimage , fanart , description = '' ) :
 if 42 - 42: oo00 * OOO0o0o % oOOOo0o0O - OOO0o0o . i11iIiiIii - I1ii
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 Ii1iI11iI1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 i11 = True
 i1i1i1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1i1i1I . setProperty ( "fanart_Image" , fanart )
 i1i1i1I . setProperty ( "icon_Image" , iconimage )
 i11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1iI11iI1 , listitem = i1i1i1I , isFolder = False )
 return i11
 if 84 - 84: I1ii - oo00 / i1
oo000 = ii111i ( ) ; iI1 = None ; I11II1i = None ; i1II111i1 = None ; oO0 = None ; O00oO = None ; O0Oo000ooO00 = None
try : oO0 = urllib . unquote_plus ( oo000 [ "site" ] )
except : pass
try : iI1 = urllib . unquote_plus ( oo000 [ "url" ] )
except : pass
try : I11II1i = urllib . unquote_plus ( oo000 [ "name" ] )
except : pass
try : i1II111i1 = int ( oo000 [ "mode" ] )
except : pass
try : O00oO = urllib . unquote_plus ( oo000 [ "iconimage" ] )
except : pass
try : O0Oo000ooO00 = urllib . unquote_plus ( oo000 [ "fanart" ] )
except : pass
if 75 - 75: OOO0O % i1
if i1II111i1 == None or iI1 == None or len ( iI1 ) < 1 : oOoO ( )
elif i1II111i1 == 1 : OO00o ( I11II1i , iI1 )
elif i1II111i1 == 2 : o00oooO0Oo ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 3 : iIIiIi1iIII1 ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 4 : PLAYSD ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 8 : OOooOoooOoOo ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 9 : iIiiiii1i ( I11II1i )
elif i1II111i1 == 10 : ii1 ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 11 : O00 ( )
elif i1II111i1 == 12 : Ii1iI111II1I1 ( iI1 )
elif i1II111i1 == 19 : IIii1111 ( iI1 )
elif i1II111i1 == 20 : ii1III11 ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 21 : OoOOoooOO0O ( iI1 )
elif i1II111i1 == 22 : iiI11i1II ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 30 : OO ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 100 : I1Ii1111iIi ( )
elif i1II111i1 == 500 : I1i11ii11 ( )
elif i1II111i1 == 201 : O0O ( )
elif i1II111i1 == 202 : I1i1Iiiii ( iI1 )
elif i1II111i1 == 203 : IIII11 ( iI1 )
elif i1II111i1 == 204 : Ii1I1Ii ( iI1 )
elif i1II111i1 == 205 : O0oO ( iI1 )
elif i1II111i1 == 206 : oO00O000oO0 ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 210 : OOO ( iI1 )
elif i1II111i1 == 220 : I11I ( iI1 )
elif i1II111i1 == 221 : OOooOOOooO ( I11II1i , iI1 , O00oO )
elif i1II111i1 == 800 : o0O0oo0 ( I11II1i , iI1 , O00oO )
if 94 - 94: i1I1Ii1iI1ii / ooOoO0o / oOOOo0o0O % o0oOoO00o
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )