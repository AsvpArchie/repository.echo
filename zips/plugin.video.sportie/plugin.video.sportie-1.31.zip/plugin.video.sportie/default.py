import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys
import base64 , time
from resources . lib . modules import plugintools
from resources . lib . modules import regex
from resources . lib . modules import checker
import datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.sportie'
Oo0Ooo = '[COLOR mediumpurple]SPORTIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'settings.xml' ) )
II1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluX21lbnUueG1s' )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I11i11Ii = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
oO00oOo = xbmc . translatePath ( 'special://home/addons/program.plexus' )
OOOo0 = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uc3BvcnRpZS9wbHVnaW4udmlkZW8uc3BvcnRpZS0=' )
Oooo000o = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
IiIi11iIIi1Ii = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
Oo0O = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/script.video.F4mProxy' ) )
Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.SportsDevil' ) )
o0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
IiiIII111iI = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
IiII = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files' ) )
iI1Ii11111iIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3uchecker.xml' ) )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamecheck.xml' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/m3unamereplace.xml' ) )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvWnNnVUVUMlI=' )
OOo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdFNIZUs1azM=' )
Ii1IIii11 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvRVRGdXZYVkE=' )
if 55 - 55: i1111 - i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
oO000OoOoo00o = "true"
iiiI11 = "false"
OOooO = "false"
try :
 oO000OoOoo00o = plugintools . get_setting ( "scrape1" )
 iiiI11 = plugintools . get_setting ( "scrape2" )
 OOooO = plugintools . get_setting ( "scrape3" )
except :
 oO000OoOoo00o = "true"
 iiiI11 = "false"
 OOooO = "false"
 if 58 - 58: i11iiII + OooooO0oOO + oOo0 / oo0Ooo0
I1I11I1I1I = IiiIII111iI + '|SPLIT|' + o0O
checker . check ( I1I11I1I1I )
if 90 - 90: i1IIiiiii + i1iIIIiI1I - OoO000 % OooOoO0Oo + iiIIiIiIi
if not os . path . exists ( IiII ) :
 os . makedirs ( IiII )
 if 38 - 38: i1IIiiiii / I11i1i11i1I
if not os . path . isfile ( i1i1II ) :
 OooO0 = open ( i1i1II , 'w' )
 if 35 - 35: oOo0 % OooOoO0Oo % i11iIiiIii / i111I
if not os . path . isfile ( iI1Ii11111iIi ) :
 OooO0 = open ( iI1Ii11111iIi , 'w' )
 if 13 - 13: II1Ii1iI1i - i1IIiiiii % OooooO0oOO / ooO0oo0oO0 % i1iIIIiI1I
if not os . path . isfile ( O0oo0OO0 ) :
 OooO0 = open ( O0oo0OO0 , 'w' )
 if 97 - 97: i11iIiiIii
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 32 - 32: I11i1i11i1I * oooO0oo0oOOOO % OooooO0oOO % i1IIiiiii . OoO000
class o0OOOOO00o0O0 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 71 - 71: iiIIiIiIi % i1iIIIiI1I / oo0ooO0oOOOOo
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 49 - 49: i1111 % i1iIIIiI1I * oooO0oo0oOOOO
oOOo0oo = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 80 - 80: oo0Ooo0 * i11iIiiIii / OooOoO0Oo
class I11II1i :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 23 - 23: i11iiII / oo0ooO0oOOOOo + oo0Ooo0 + oo0Ooo0 / i1111
  if 26 - 26: i111I
  if 12 - 12: i111I % OOO0O / iiIIiIiIi % oo0ooO0oOOOOo
  if 29 - 29: i111I
def iI ( ) :
 I1i1I1II = 5
 i1 = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 IiIiiI = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 31 - 31: i1IIiiiii . i1IIiiiii - oo0ooO0oOOOOo / oo + iiIIiIiIi * i1IIi11111i
 O0ooOooooO = [ ]
 if 60 - 60: oo0Ooo0 / oo0Ooo0
 for I1II1III11iii in range ( I1i1I1II ) :
  O0ooOooooO . append ( I11II1i ( i1 [ I1II1III11iii ] , IiIiiI [ I1II1III11iii ] ) )
  if 75 - 75: ooO0oo0oO0 / oOo0 % oo0ooO0oOOOOo * OOO0O
 return O0ooOooooO
 if 9 - 9: oo
def i11 ( ) :
 if 58 - 58: oOo0 * i11iIiiIii / OOO0O % OooOoO0Oo - i11iiII / OooooO0oOO
 ii11i1 = IIIii1II1II ( OOo )
 if len ( ii11i1 ) > 1 :
  i1I1iI = i1i1II
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 83 - 83: i11iiII / iiIIiIiIi
 ii11i1 = IIIii1II1II ( iiI1iIiI )
 if len ( ii11i1 ) > 1 :
  i1I1iI = iI1Ii11111iIi
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 49 - 49: oo0ooO0oOOOOo
 ii11i1 = IIIii1II1II ( Ii1IIii11 )
 if len ( ii11i1 ) > 1 :
  i1I1iI = O0oo0OO0
  oo0OooOOo0 = open ( i1I1iI )
  o0OO00oO = oo0OooOOo0 . read ( )
  if o0OO00oO == ii11i1 : pass
  else :
   I11i1I1I = open ( i1I1iI , "w" )
   I11i1I1I . write ( ii11i1 )
   I11i1I1I . close ( )
   if 35 - 35: OOO0O - i111I / i11iiII % II1Ii1iI1i
 o00OO00OoO = OOOO0OOoO0O0 ( II1 )
 O0Oo000ooO00 = II1
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 62 - 62: ooO0oo0oO0 * OOO0O
  if '<search>display</search>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo ( i1OOO , II1 , 100 , iiiii , O0O0OO0O0O0 , '' )
   if 58 - 58: i1111 * oOo0 * i11iiII / oOo0
  elif '<arenavision>display</arenavision>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   if os . path . exists ( oO00oOo ) : Oo0oOOo ( i1OOO , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : oO0o0OOOO ( '[COLOR darkgray]' + i1OOO + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 68 - 68: i1iIIIiI1I - OooOoO0Oo - i1IIi11111i - i11iiII + oo0Ooo0
   if 10 - 10: i111I % ooO0oo0oO0
  elif '<vip>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo ( i1OOO , 'none' , 24 , iiiii , O0O0OO0O0O0 )
   if 54 - 54: OooOoO0Oo - i1111 % OOO0O % oo0Ooo0 % ooO0oo0oO0 + iiIIiIiIi
  elif '<divider>null</divider>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( i1OOO , II1 , 999 , iiiii , O0O0OO0O0O0 )
   if 15 - 15: oo0Ooo0 * iiIIiIiIi * I11i1i11i1I % i11iIiiIii % OOO0O - oOo0
   if 68 - 68: OooOoO0Oo % II1Ii1iI1i . OoO000 . i11iiII
   if 92 - 92: i1iIIIiI1I . OooOoO0Oo
   if 31 - 31: OooOoO0Oo . OOO0O / oooO0oo0oOOOO
   if 89 - 89: OOO0O
   if 68 - 68: oo * i111I % oooO0oo0oOOOO + oo + iiIIiIiIi
  elif '<m3ulists>display</m3ulists>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   Oo0oOOo ( i1OOO , II1 , 11 , iiiii , O0O0OO0O0O0 )
   if 4 - 4: iiIIiIiIi + oooO0oo0oOOOO * oOo0
   if 55 - 55: I11i1i11i1I + ooO0oo0oO0 / OOO0O * OooooO0oOO - i11iIiiIii - i1IIiiiii
   if 25 - 25: i11iiII
   if 7 - 7: II1Ii1iI1i / i1IIi11111i * OooOoO0Oo . OoO000 . ooO0oo0oO0
   if 13 - 13: oOo0 / i11iIiiIii
   if 2 - 2: i1IIi11111i / oooO0oo0oOOOO / oo0ooO0oOOOOo % OOO0O % i1IIiiiii
   if 52 - 52: oo0ooO0oOOOOo
   if 95 - 95: i1IIiiiii
   if 87 - 87: iiIIiIiIi + OOO0O . oOo0 + OOO0O
   if 91 - 91: oooO0oo0oOOOO
   if 61 - 61: i1111
   if 64 - 64: iiIIiIiIi / OOO0O - oooO0oo0oOOOO - oo0Ooo0
   if 86 - 86: oo0Ooo0 % OOO0O / i1IIi11111i / OOO0O
   if 42 - 42: oo
   if 67 - 67: OooOoO0Oo . i1iIIIiI1I . oooO0oo0oOOOO
   if 10 - 10: i11iiII % i11iiII - ooO0oo0oO0 / oOo0 + i1IIiiiii
   if 87 - 87: OooooO0oOO * i11iiII + oOo0 / ooO0oo0oO0 / i1iIIIiI1I
   if 37 - 37: i1iIIIiI1I - iiIIiIiIi * OooooO0oOO % i11iIiiIii - OooOoO0Oo
   if 83 - 83: oo0Ooo0 / i1IIi11111i
   if 34 - 34: OoO000
   if 57 - 57: OooooO0oOO . oo0Ooo0 . II1Ii1iI1i
   if 42 - 42: oo0Ooo0 + i11iiII % oooO0oo0oOOOO
  elif '<sportsdevil>' in Ii1iIiII1ii1 :
   i1iIIIi1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    i1iI11i1ii11 = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    OOooo0O00o = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    oOOoOooOo = OOooo0O00o
    O000oo = "/"
    if not oOOoOooOo . endswith ( O000oo ) :
     IIi1I11I1II = oOOoOooOo + "/"
    else :
     IIi1I11I1II = oOOoOooOo
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( i1OOO ) + '%26url=' + i1iI11i1ii11
    i1iI11i1ii11 = o00OO00OoO + '%26referer=' + IIi1I11I1II
    oO0o0OOOO ( i1OOO , i1iI11i1ii11 , 4 , iI1iIIiiii , OooOoooOo )
   elif len ( i1iIIIi1i ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    oO0o0OOOO ( i1OOO , O0Oo000ooO00 + 'NOTPLAY' , 8 , iI1iIIiiii , OooOoooOo )
  elif '<plexus>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OooOoooOo = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : oO0o0OOOO ( i1OOO , O0Oo000ooO00 + 'NOTPLAY' , 7 , iI1iIIiiii , OooOoooOo )
   else : oO0o0OOOO ( '[COLOR darkgray]' + i1OOO + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 46 - 46: i1iIIIiI1I
  elif '<rutubeplaylist>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OooOoooOo = O0O0OO0O0O0
   Oo0oOOo ( i1OOO , O0Oo000ooO00 , 90 , iI1iIIiiii , OooOoooOo )
  elif '<folder>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for i1OOO , i1iI11i1ii11 , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    Oo0oOOo ( i1OOO , i1iI11i1ii11 , 1 , iI1iIIiiii , OooOoooOo )
  elif '<m3u>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for i1OOO , i1iI11i1ii11 , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    Oo0oOOo ( i1OOO , i1iI11i1ii11 , 10 , iI1iIIiiii , OooOoooOo )
  else :
   i1iIIIi1i = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
    i1I = len ( oO0 )
    for i1OOO , i1iI11i1ii11 , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
     oO0o0OOOO ( i1OOO , i1iI11i1ii11 , 2 , iI1iIIiiii , OooOoooOo )
   elif len ( i1iIIIi1i ) > 1 :
    i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    oO0o0OOOO ( i1OOO , II1 , 3 , iI1iIIiiii , OooOoooOo )
    if 72 - 72: II1Ii1iI1i / oo + i111I - I11i1i11i1I
 iI1Iii = open ( IIi1IiiiI1Ii ) . read ( )
 oO00OOoO00 = iI1Iii . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 oO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( oO00OOoO00 ) )
 for Ii1iIiII1ii1 in oO0 :
  IiI111111IIII = float ( Ii1iIiII1ii1 )
 iI1Iii = open ( I11i11Ii ) . read ( )
 oO00OOoO00 = iI1Iii . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 oO0 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( oO00OOoO00 ) )
 for Ii1iIiII1ii1 in oO0 :
  i1Ii = float ( Ii1iIiII1ii1 )
  if 14 - 14: i1iIIIiI1I
 oO0o0OOOO ( '[COLOR mediumpurple][B]MATCH CENTER[/B][/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]LIVE SCORES[/B][/COLOR]' , II1 , 80 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[B][COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '[COLOR yellow]REFRESH MENU ITEMS[/COLOR]' , II1 , 500 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '###################################################' , II1 , 9 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( "[COLOR dodgerblue]Addon Version:[/COLOR] [COLOR white]" + str ( IiI111111IIII ) + "[/COLOR]" , 'url' , 999 , iiiii , OooOoooOo , '' )
 oO0o0OOOO ( "[COLOR dodgerblue]Repository Version:[/COLOR] [COLOR white]" + str ( i1Ii ) + "[/COLOR]" , 'url' , 999 , iiiii , OooOoooOo , '' )
 if 11 - 11: OoO000 * i1IIi11111i . ooO0oo0oO0 % i111I + i1iIIIiI1I
 OOO = oo0OOo0 ( )
 if 47 - 47: OooOoO0Oo + OOO0O * I11i1i11i1I / iiIIiIiIi - i1iIIIiI1I % ooO0oo0oO0
 if OOO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 26 - 26: i11iiII * i1iIIIiI1I . i1111 * i1IIiiiii
def II1iiiIi1 ( name , url ) :
 if 38 - 38: OooOoO0Oo
 hash = [ ]
 O0Oo000ooO00 = url
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 if 84 - 84: ooO0oo0oO0 % i1iIIIiI1I / ooO0oo0oO0 % oo0Ooo0
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 45 - 45: oooO0oo0oOOOO
  if '<search>' in Ii1iIiII1ii1 :
   if 26 - 26: oo0Ooo0 - ooO0oo0oO0 - i1IIi11111i / oo . OOO0O % ooO0oo0oO0
   i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = name + "!" + url + "!" + iI1iIIiiii
    name = '[COLOR white]' + name + '[/COLOR]'
    Oo0oOOo ( name , url , 20 , iI1iIIiiii , iI1iIIiiii )
    if 91 - 91: oo0ooO0oOOOOo . ooO0oo0oO0 / OooooO0oOO + II1Ii1iI1i
   elif len ( i1iIIIi1i ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = O0Oo000ooO00 + "!" + name + "!" + iI1iIIiiii
    name = '[COLOR white]' + name + '[/COLOR]'
    Oo0oOOo ( name , url , 22 , iI1iIIiiii , iI1iIIiiii )
    if 42 - 42: iiIIiIiIi . oo0ooO0oOOOOo . iiIIiIiIi - i11iiII
  elif '<arenavision>display</arenavision>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   if os . path . exists ( oO00oOo ) : Oo0oOOo ( name , II1 , 95 , iiiii , O0O0OO0O0O0 , '' )
   else : oO0o0OOOO ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 40 - 40: iiIIiIiIi - i11iIiiIii / i1IIiiiii
  elif '<regex>' in Ii1iIiII1ii1 :
   I11iiI1i1 = re . compile ( '(<regex>.+?</regex>)' , re . MULTILINE | re . DOTALL ) . findall ( Ii1iIiII1ii1 )
   I11iiI1i1 = '' . join ( I11iiI1i1 )
   I1i1Iiiii = re . compile ( '(<listrepeat>.+?</listrepeat>)' , re . MULTILINE | re . DOTALL ) . findall ( I11iiI1i1 )
   I11iiI1i1 = urllib . quote_plus ( I11iiI1i1 )
   if 94 - 94: oo0ooO0oOOOOo * i1IIiiiii / I11i1i11i1I / i1IIiiiii
   oO0O0OO0O = hashlib . md5 ( )
   for OO in I11iiI1i1 : oO0O0OO0O . update ( str ( OO ) )
   oO0O0OO0O = str ( oO0O0OO0O . hexdigest ( ) )
   if 83 - 83: oooO0oo0oOOOO / i1IIi11111i - oo - oOo0
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' )
   Ii1iIiII1ii1 = re . sub ( '<regex>.+?</regex>' , '' , Ii1iIiII1ii1 )
   Ii1iIiII1ii1 = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , Ii1iIiII1ii1 )
   Ii1iIiII1ii1 = re . sub ( '<link></link>' , '' , Ii1iIiII1ii1 )
   if 36 - 36: OoO000
   name = re . sub ( '<meta>.+?</meta>' , '' , Ii1iIiII1ii1 )
   try : name = re . findall ( '<title>(.+?)</title>' , name ) [ 0 ]
   except : name = re . findall ( '<name>(.+?)</name>' , name ) [ 0 ]
   if 36 - 36: iiIIiIiIi / oooO0oo0oOOOO * I11i1i11i1I - oOo0 % ooO0oo0oO0 * OooooO0oOO
   try : o0 = re . findall ( '<date>(.+?)</date>' , Ii1iIiII1ii1 ) [ 0 ]
   except : o0 = ''
   if re . search ( r'\d+' , o0 ) : name += ' [COLOR red] Updated %s[/COLOR]' % o0
   if 37 - 37: OooooO0oOO - OooOoO0Oo % I11i1i11i1I
   try : OOOoo0OO = re . findall ( '<thumbnail>(.+?)</thumbnail>' , Ii1iIiII1ii1 ) [ 0 ]
   except : OOOoo0OO = iiiii
   if 57 - 57: oo / iiIIiIiIi
   try : Ii1I1Ii = re . findall ( '<fanart>(.+?)</fanart>' , Ii1iIiII1ii1 ) [ 0 ]
   except : Ii1I1Ii = O0O0OO0O0O0
   if 69 - 69: i1IIi11111i / oo0ooO0oOOOOo . OoO000 * OooOoO0Oo % i1IIiiiii - oo0ooO0oOOOOo
   try : i1i = re . findall ( '<meta>(.+?)</meta>' , Ii1iIiII1ii1 ) [ 0 ]
   except : i1i = '0'
   if 56 - 56: i11iiII % oooO0oo0oOOOO - i1IIi11111i
   try : url = re . findall ( '<link>(.+?)</link>' , Ii1iIiII1ii1 ) [ 0 ]
   except : url = '0'
   url = url . replace ( '>search<' , '><preset>search</preset>%s<' % i1i )
   url = '<preset>search</preset>%s' % i1i if url == 'search' else url
   url = url . replace ( '>searchsd<' , '><preset>searchsd</preset>%s<' % i1i )
   url = '<preset>searchsd</preset>%s' % i1i if url == 'searchsd' else url
   url = re . sub ( '<sublink></sublink>|<sublink\s+name=(?:\'|\").*?(?:\'|\")></sublink>' , '' , url )
   if 100 - 100: i1IIiiiii - oooO0oo0oOOOO % OooooO0oOO * oOo0 + i1IIi11111i
   if not I11iiI1i1 == '' :
    hash . append ( { 'regex' : oO0O0OO0O , 'response' : I11iiI1i1 } )
    url += '|regex=%s' % I11iiI1i1
    if 88 - 88: i111I - oo * oooO0oo0oOOOO * i111I . i111I
   oO0o0OOOO ( name , url , 30 , OOOoo0OO , Ii1I1Ii )
   if 33 - 33: OooOoO0Oo + i1iIIIiI1I * OooooO0oOO / ooO0oo0oO0 - i1IIi11111i
  elif '<sportsdevil>' in Ii1iIiII1ii1 :
   i1iIIIi1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    url = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OOooo0O00o = re . compile ( '<referer>(.+?)</referer>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OOooo0O00o = "None"
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OooOoooOo = O0O0OO0O0O0
    oOOoOooOo = OOooo0O00o
    O000oo = "/"
    if not oOOoOooOo . endswith ( O000oo ) :
     IIi1I11I1II = oOOoOooOo + "/"
    else :
     IIi1I11I1II = oOOoOooOo
    o00OO00OoO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url=' + url
    url = o00OO00OoO + '%26referer=' + IIi1I11I1II
    oO0o0OOOO ( name , url , 2 , iI1iIIiiii , OooOoooOo )
    if 54 - 54: OooOoO0Oo / oOo0 . OooooO0oOO % i1iIIIiI1I
   elif len ( i1iIIIi1i ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OooOoooOo = O0O0OO0O0O0
    oO0o0OOOO ( name , O0Oo000ooO00 + 'NOTPLAY' , 8 , iI1iIIiiii , OooOoooOo )
    if 57 - 57: i11iIiiIii . i11iiII - i1IIiiiii - OooooO0oOO + OOO0O
  elif '<plexus>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OooOoooOo = O0O0OO0O0O0
   if os . path . exists ( oO00oOo ) : oO0o0OOOO ( name , O0Oo000ooO00 + 'NOTPLAY' , 7 , iI1iIIiiii , OooOoooOo )
   else : oO0o0OOOO ( '[COLOR darkgray]' + name + ' - INSTALL PLEXUS TO USE.[/COLOR]' , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 63 - 63: OOO0O * i1iIIIiI1I
  elif '<rutubeplaylist>' in Ii1iIiII1ii1 :
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : OooOoooOo = O0O0OO0O0O0
   Oo0oOOo ( name , O0Oo000ooO00 , 90 , iI1iIIiiii , OooOoooOo )
   if 69 - 69: oooO0oo0oOOOO . oo
  elif '<folder>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?folder>(.+?)</folder>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    Oo0oOOo ( name , url , 1 , iI1iIIiiii , OooOoooOo )
    if 49 - 49: i1IIi11111i - oo0Ooo0
  elif '<m3u>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?m3u>(.+?)</m3u>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    Oo0oOOo ( name , url , 10 , iI1iIIiiii , OooOoooOo )
    if 74 - 74: ooO0oo0oO0 * i11iiII + OOO0O / II1Ii1iI1i / i1111 . I11i1i11i1I
  elif '<rutube>' in Ii1iIiII1ii1 :
   IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?rutube>(.+?)</rutube>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
   for name , url , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
    O0Oo000ooO00 = 'https://rutube.ru/play/embed/' + url + '?wmode=opaque&fakeFullscreen=1'
    Oo0oOOo ( name , O0Oo000ooO00 , 2 , iI1iIIiiii , OooOoooOo )
  else :
   i1iIIIi1i = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 )
   if len ( i1iIIIi1i ) == 1 :
    IIIII11I1IiI = re . compile ( '<title>(.+?)</title>.+?link>(.+?)</link>.+?thumbnail>(.+?)</thumbnail>.+?fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 )
    i1I = len ( oO0 )
    for name , url , iI1iIIiiii , OooOoooOo in IIIII11I1IiI :
     oO0o0OOOO ( name , url , 2 , iI1iIIiiii , OooOoooOo )
   elif len ( i1iIIIi1i ) > 1 :
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : OooOoooOo = O0O0OO0O0O0
    oO0o0OOOO ( name , O0Oo000ooO00 , 3 , iI1iIIiiii , OooOoooOo )
    if 62 - 62: i111I * i1IIi11111i
 OOO = oo0OOo0 ( )
 if 58 - 58: OOO0O % oo0ooO0oOOOOo
 if OOO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 50 - 50: OooOoO0Oo . oo0ooO0oOOOOo
def ooO0OO ( name , url , iconimage ) :
 O000OOO = [ ]
 II = [ ]
 o0o0O0O00oOOo = [ ]
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iIIIiIi = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iIIIiIi ) [ 0 ]
 i1iIIIi1i = re . compile ( '<link>(.+?)</link>' ) . findall ( iIIIiIi )
 OO = 1
 for OO0O0 in i1iIIIi1i :
  I11I11 = OO0O0
  if '(' in OO0O0 :
   OO0O0 = OO0O0 . split ( '(' ) [ 0 ]
   o000O0O = str ( I11I11 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   O000OOO . append ( OO0O0 )
   II . append ( o000O0O )
  else :
   O000OOO . append ( OO0O0 )
   II . append ( 'Link ' + str ( OO ) )
  OO = OO + 1
 name = '[COLOR red]' + name + '[/COLOR]'
 O00ooooo00 = xbmcgui . Dialog ( )
 I1i1i1iii = O00ooooo00 . select ( name , II )
 if I1i1i1iii < 0 :
  quit ( )
 else :
  url = O000OOO [ I1i1i1iii ]
  print url
  if 16 - 16: i1IIiiiii + OoO000 * oooO0oo0oOOOO % II1Ii1iI1i . i1IIi11111i
 url = O000OOO [ I1i1i1iii ]
 name = II [ I1i1i1iii ]
 Oo0OO ( name , url , iiiii )
 if 78 - 78: oOo0 - i111I - i11iiII / iiIIiIiIi / i1111
def iiI11ii1I1 ( name , url , iconimage ) :
 if 82 - 82: i1111 % oo0Ooo0 / oo + OOO0O / oo0ooO0oOOOOo / OooOoO0Oo
 O000OOO = [ ]
 II = [ ]
 o0o0O0O00oOOo = [ ]
 oOo0OOoO0 = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iIIIiIi = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 i1iIIIi1i = re . compile ( '<plexus>(.+?)</plexus>' ) . findall ( iIIIiIi )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iIIIiIi ) [ 0 ]
 if 11 - 11: i11iiII . oo * OoO000 * i111I + iiIIiIiIi
 IiII111i1i11 = "plugin://program.plexus/?url="
 i111iIi1i1II1 = "&mode=1&name=acestream+"
 OO = 0
 if 86 - 86: ooO0oo0oO0 / OOO0O . i1111
 for OO0O0 in i1iIIIi1i :
  OO = OO + 1
  if 19 - 19: i11iiII % i111I % OoO000 * oo0ooO0oOOOOo % oooO0oo0oOOOO
  I11I11 = OO0O0
  if '(' in OO0O0 :
   OO0O0 = OO0O0 . split ( '(' ) [ 0 ]
   o000O0O = str ( I11I11 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   O000OOO . append ( OO0O0 )
   II . append ( o000O0O )
   oOo0OOoO0 . append ( 'Stream ' + str ( OO ) )
  else :
   O000OOO . append ( OO0O0 )
   II . append ( 'Link ' + str ( OO ) )
   o000O0O = name
   if 67 - 67: i1IIi11111i . II1Ii1iI1i
   if 27 - 27: iiIIiIiIi % i1IIi11111i
 if OO > 1 :
  O00ooooo00 = xbmcgui . Dialog ( )
  I1i1i1iii = O00ooooo00 . select ( name , II )
  if I1i1i1iii < 0 :
   quit ( )
  else :
   o0oooOO00 = O000OOO [ I1i1i1iii ]
   if not 'acestream://' in o0oooOO00 :
    o0oooOO00 = 'acestream://' + o0oooOO00
   url = IiII111i1i11 + o0oooOO00 + i111iIi1i1II1 + II [ I1i1i1iii ]
   name = II [ I1i1i1iii ]
 else :
  o0oooOO00 = OO0O0
  if not 'acestream://' in o0oooOO00 :
   o0oooOO00 = 'acestream://' + o0oooOO00
  url = IiII111i1i11 + o0oooOO00 + i111iIi1i1II1 + o000O0O
  name = o000O0O
  if 32 - 32: OooOoO0Oo
 Oo0OO ( name , url , iiiii )
 if 30 - 30: ooO0oo0oO0 / oo0Ooo0 . oo - oo0ooO0oOOOOo
def Iii11iI1i ( name , url , iconimage ) :
 if 57 - 57: oo0ooO0oOOOOo
 O000OOO = [ ]
 II = [ ]
 o0o0O0O00oOOo = [ ]
 oOo0OOoO0 = [ ]
 url = url . replace ( 'NOTPLAY' , '' )
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iIIIiIi = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 i1iIIIi1i = re . compile ( '<sportsdevil>(.+?)</sportsdevil>' ) . findall ( iIIIiIi )
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iIIIiIi ) [ 0 ]
 if 51 - 51: i1IIi11111i . ooO0oo0oO0 - i11iiII / oooO0oo0oOOOO
 OOOoO00 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26title=' + str ( name ) + '%26url='
 if 40 - 40: i11iiII % i1IIi11111i . iiIIiIiIi . oooO0oo0oOOOO * OooOoO0Oo
 OO = 1
 if 4 - 4: i1IIiiiii % OooooO0oOO * oo
 for OO0O0 in i1iIIIi1i :
  I11I11 = OO0O0
  if '(' in OO0O0 :
   OO0O0 = OO0O0 . split ( '(' ) [ 0 ]
   o000O0O = str ( I11I11 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   O000OOO . append ( OO0O0 )
   II . append ( o000O0O )
   oOo0OOoO0 . append ( 'Stream ' + str ( OO ) )
  else :
   O000OOO . append ( OO0O0 )
   II . append ( 'Link ' + str ( OO ) )
   if 100 - 100: OooOoO0Oo * oOo0 + oOo0
  OO = OO + 1
  if 54 - 54: i111I + oo0ooO0oOOOOo - II1Ii1iI1i % i11iIiiIii
 name = '[COLOR red]' + name + '[/COLOR]'
 if 3 - 3: oo0ooO0oOOOOo % oo0ooO0oOOOOo
 O00ooooo00 = xbmcgui . Dialog ( )
 I1i1i1iii = O00ooooo00 . select ( name , II )
 if I1i1i1iii < 0 :
  quit ( )
 else :
  oOOoOooOo = II [ I1i1i1iii ]
  O000oo = "/"
  if not oOOoOooOo . endswith ( O000oo ) :
   IIi1I11I1II = oOOoOooOo + "/"
  else :
   IIi1I11I1II = oOOoOooOo
  url = OOOoO00 + O000OOO [ I1i1i1iii ] + "%26referer=" + IIi1I11I1II
  if 83 - 83: i1111 + OooOoO0Oo
 name = II [ I1i1i1iii ]
 Oo0OO ( name , url , iiiii )
 if 73 - 73: i1iIIIiI1I
def IiiiiI1i1Iii ( name , url , iconimage ) :
 if 87 - 87: oo0ooO0oOOOOo
 IiI1iiiIii = [ ]
 I1III1111iIi = [ ]
 if 38 - 38: i1iIIIiI1I + oo0Ooo0 / OooOoO0Oo % iiIIiIiIi - i11iiII
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iIIIiIi = re . compile ( '<title>' + re . escape ( name ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 i1iIIIi1i = re . compile ( '<rutubeplaylist>(.+?)</rutubeplaylist>' ) . findall ( iIIIiIi )
 if 14 - 14: OooooO0oOO / OooOoO0Oo
 for OO0O0 in i1iIIIi1i :
  I11I11 = OO0O0
  if '(' in OO0O0 :
   OO0O0 = OO0O0 . split ( '(' ) [ 0 ]
   o000O0O = str ( I11I11 . split ( '(' ) [ 1 ] . replace ( ')' , '' ) )
   IiI1iiiIii . append ( o000O0O )
   I1III1111iIi . append ( OO0O0 )
   ooo0O0o00O = list ( zip ( IiI1iiiIii , I1III1111iIi ) )
   if 48 - 48: iiIIiIiIi / OooOoO0Oo . ooO0oo0oO0 * OOO0O * OooooO0oOO / II1Ii1iI1i
 OOOOoOOo0O0 = sorted ( ooo0O0o00O )
 if 92 - 92: i11iiII + ooO0oo0oO0 / i1111
 for OooO0OO , url in OOOOoOOo0O0 :
  o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   o0OO0o0oOOO0O = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
   if OooO0OO . lower ( ) == "all" :
    o0OO0o0oOOO0O = o0OO0o0oOOO0O . replace ( '.' , ' ' )
    oO0o0OOOO ( o0OO0o0oOOO0O , url , 2 , iconimage , iconimage , '' )
   elif OooO0OO . lower ( ) in o0OO0o0oOOO0O . lower ( ) :
    o0OO0o0oOOO0O = o0OO0o0oOOO0O . replace ( '.' , ' ' )
    oO0o0OOOO ( o0OO0o0oOOO0O , url , 2 , iconimage , iconimage , '' )
    if 49 - 49: i11iiII . oo0ooO0oOOOOo . i1111
 try :
  oO0 = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( o0OOo0o0O0O )
  o000ooooO0o = str ( oO0 )
  iI1i11 = re . compile ( 'href="(.+?)"' ) . findall ( o000ooooO0o ) [ 1 ]
  url = iI1i11 + "|SPLIT|" + OooO0OO
  Oo0oOOo ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 66 - 66: oooO0oo0oOOOO % i11iiII + i11iIiiIii . OOO0O / i1IIiiiii + i11iiII
def ooo00Ooo ( name , url , iconimage ) :
 if 93 - 93: i11iIiiIii - i1IIi11111i * i11iiII * oo0Ooo0 % oooO0oo0oOOOO + i111I
 url , OooO0OO = url . split ( "|SPLIT|" )
 if 25 - 25: OoO000 + i1IIiiiii / iiIIiIiIi . oo0ooO0oOOOOo % oooO0oo0oOOOO * oo
 o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<article id="(.+?)</article>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Ii1iIiII1ii1 in oO0 :
  o0OO0o0oOOO0O = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="preview-link" href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  iconimage = re . compile ( 'https://pic.rutube.ru(.+?)size' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  iconimage = "https://pic.rutube.ru" + iconimage + "size=l"
  if OooO0OO . lower ( ) == "all" :
   o0OO0o0oOOO0O = o0OO0o0oOOO0O . replace ( '.' , ' ' )
   oO0o0OOOO ( o0OO0o0oOOO0O , url , 2 , iconimage , iconimage , '' )
  elif OooO0OO . lower ( ) in o0OO0o0oOOO0O . lower ( ) :
   o0OO0o0oOOO0O = o0OO0o0oOOO0O . replace ( '.' , ' ' )
   oO0o0OOOO ( o0OO0o0oOOO0O , url , 2 , iconimage , iconimage , '' )
   if 84 - 84: iiIIiIiIi % i1IIiiiii + i11iIiiIii
 try :
  oO0 = re . compile ( '<a class="paginator-item active(.+?)</html>' ) . findall ( o0OOo0o0O0O )
  o000ooooO0o = str ( oO0 )
  iI1i11 = re . compile ( 'href="(.+?)"' ) . findall ( o000ooooO0o ) [ 1 ]
  url = iI1i11 + "|SPLIT|" + OooO0OO
  Oo0oOOo ( "[COLOR mediumpurple][B]Next Page -->[/B][/COLOR]" , url , 91 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 28 - 28: I11i1i11i1I + oo * oOo0 % OooooO0oOO . oo0Ooo0 % oooO0oo0oOOOO
def I1iiiiIii ( name , url , iconimage ) :
 if 19 - 19: oo - I11i1i11i1I . oooO0oo0oOOOO
 oo0OooOOo0 , I1II1III11iii = re . findall ( '(.+?)\|regex=(.+?)$' , url ) [ 0 ]
 oo0OooOOo0 += urllib . unquote_plus ( I1II1III11iii )
 url = regex . resolve ( oo0OooOOo0 )
 if 60 - 60: i1111 + I11i1i11i1I
 Oo0OO ( name , url , iconimage )
 if 9 - 9: iiIIiIiIi * i111I - ooO0oo0oO0 + OOO0O / oo . oo
def iiIIi ( ) :
 if 11 - 11: i1IIi11111i * OooooO0oOO
 oO0o0OOOO ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( "################################################################" , II1 , 999 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]1[/COLOR]' , II1 , 201 , iiiii , O0O0OO0O0O0 )
 Oo0oOOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]2[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv' ) , 202 , iiiii , O0O0OO0O0O0 )
 Oo0oOOo ( '[COLOR blue]Sportie [/COLOR][COLOR blue]Source [/COLOR][COLOR mediumpurple]3[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 if 81 - 81: i1iIIIiI1I + OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 98 - 98: i1IIi11111i
def o00o0 ( ) :
 if 50 - 50: I11i1i11i1I / I11i1i11i1I % i11iiII . i11iiII
 Oo0oOOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]EVENTS[/COLOR][/B]" , II1 , 25 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( "[B][COLOR dodgerblue]VIP [/COLOR][COLOR mediumpurple]CHANNELS[/COLOR][/B]" , 'http://echocoder.com/private/addons/sportie/vip/channels.xml' , 19 , iiiii , O0O0OO0O0O0 , '' )
 if 55 - 55: iiIIiIiIi - oo0Ooo0 + i1111 + i1iIIIiI1I % i1IIiiiii
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 41 - 41: II1Ii1iI1i - oo0Ooo0 - i1IIiiiii
def III11I1 ( ) :
 if 36 - 36: OooooO0oOO - i1IIiiiii . I11i1i11i1I - i11iIiiIii - oOo0 * I11i1i11i1I
 Oo0oOOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- ON UK TELEVISION[/COLOR][/B]" , II1 , 23 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( "[B][COLOR dodgerblue]EVENTS [/COLOR][COLOR mediumpurple]- AROUND THE WORLD[/COLOR][/B]" , 'http://www.hesgoal.com/league/11/Football_News' , 205 , iiiii , O0O0OO0O0O0 , '' )
 if 76 - 76: i11iIiiIii + oo0ooO0oOOOOo / i11iiII - oo - i1IIiiiii + i11iiII
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 51 - 51: ooO0oo0oO0 . iiIIiIiIi + ooO0oo0oO0
def oOoOO ( ) :
 if 44 - 44: i1IIi11111i / ooO0oo0oO0 % OooooO0oOO * i111I % iiIIiIiIi
 OO = 0
 o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Ii1iIiII1ii1 in oO0 :
  OO = OO + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1iI11i1ii11 = Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( OO ) + '[/COLOR]' , i1iI11i1ii11 , 12 , iiiii , O0O0OO0O0O0 )
  if 25 - 25: i11iiII . iiIIiIiIi
 o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Ii1iIiII1ii1 in oO0 :
  OO = OO + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1iI11i1ii11 = Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( OO ) + '[/COLOR]' , i1iI11i1ii11 , 12 , iiiii , O0O0OO0O0O0 )
  if 24 - 24: OooooO0oOO / i11iIiiIii + OooooO0oOO
 o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Ii1iIiII1ii1 in oO0 :
  OO = OO + 1
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1iI11i1ii11 = Ii1iIiII1ii1
  Oo0oOOo ( '[COLOR blue]LIST[/COLOR][COLOR blue] ' + str ( OO ) + '[/COLOR]' , i1iI11i1ii11 , 12 , iiiii , O0O0OO0O0O0 )
  if 20 - 20: oo0Ooo0 + i1IIiiiii / oooO0oo0oOOOO % ooO0oo0oO0
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 88 - 88: OOO0O / i1111
def OOOOO0O00 ( url ) :
 if 30 - 30: ooO0oo0oO0 . i1IIi11111i . oOo0 / oo0ooO0oOOOOo
 o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 if 42 - 42: I11i1i11i1I
 for Ii1iIiII1ii1 in oO0 :
  i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  iI1iIIiiii = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , iI1iIIiiii , O0O0OO0O0O0 )
  if 19 - 19: OooooO0oOO % i11iiII * ooO0oo0oO0 + i1IIi11111i
 try :
  iii11I = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( o0OOo0o0O0O ) [ 0 ]
  Oo0oOOo ( '[COLOR yellow]Next Page -->[/COLOR]' , iii11I , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 50 - 50: i1iIIIiI1I + oooO0oo0oOOOO + i1IIiiiii . i1111 / oo0ooO0oOOOOo
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 17 - 17: i1IIiiiii % ooO0oo0oO0 - ooO0oo0oO0
def O0o0O0 ( ) :
 if 11 - 11: i1111 % oo * i1iIIIiI1I + iiIIiIiIi + i1IIiiiii
 o0OOo0o0O0O = OOOO0OOoO0O0 ( 'http://arenavision.in/schedule' )
 oO0 = re . compile ( '<tr><td class="auto-style3"(.+?)</tr>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 if 24 - 24: I11i1i11i1I - OooooO0oOO % ooO0oo0oO0 . II1Ii1iI1i / oooO0oo0oOOOO
 for Ii1iIiII1ii1 in oO0 :
  try :
   o0 = re . compile ( '190px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   time = re . compile ( '182px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   ii1ii111 = re . compile ( '188px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   I111i1i1111 = re . compile ( '685px">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   IIII1 = re . compile ( '317px">(.+?) ' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   i1iI11i1ii11 = I111i1i1111 + '|SPLIT|' + IIII1
   oO0o0OOOO ( '[COLOR blue][B]' + I111i1i1111 + '[/B][/COLOR] - [COLOR white]' + o0 + ' | [COLOR orangered][B]' + time + '[/B][/COLOR] | ' + ii1ii111 + '[/COLOR]' , i1iI11i1ii11 , 97 , iiiii , O0O0OO0O0O0 )
  except : pass
 OOO = oo0OOo0 ( )
 if 10 - 10: OooOoO0Oo / iiIIiIiIi + i11iIiiIii / i1IIiiiii
 if OOO == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 74 - 74: oOo0 + oooO0oo0oOOOO + II1Ii1iI1i - II1Ii1iI1i + i1111
def oOOO0oo0 ( name , url , iconimage ) :
 if 46 - 46: OoO000
 name , url = url . split ( '|SPLIT|' )
 if 45 - 45: iiIIiIiIi
 IIi = "null"
 ooO0oOo0o = "null"
 if 66 - 66: OOO0O . II1Ii1iI1i . i11iIiiIii % i1iIIIiI1I % iiIIiIiIi
 if "-" in url :
  IIi , ooO0oOo0o = url . split ( '-' )
  if 43 - 43: oooO0oo0oOOOO
  Ii1 = O00ooooo00 . select ( "[COLOR red]Please select an stream[/COLOR]" , [ '[COLOR white]Link 1[/COLOR]' , '[COLOR white]Link 2[/COLOR]' ] )
  if 14 - 14: ooO0oo0oO0 % ooO0oo0oO0 * i11iIiiIii - oo - oo0Ooo0
  if Ii1 == 0 : url = 'http://arenavision.in/av' + IIi
  elif Ii1 == 1 : url = 'http://arenavision.in/av' + ooO0oOo0o
  else : quit ( )
  if 63 - 63: oo
 else : url = 'http://arenavision.in/av' + url
 if 69 - 69: ooO0oo0oO0 . i11iiII % iiIIiIiIi + ooO0oo0oO0 / oooO0oo0oOOOO / i11iiII
 O00OoOO0oo0 ( name , url , iconimage )
 if 96 - 96: OOO0O . oo0ooO0oOOOOo - iiIIiIiIi
 if 99 - 99: OoO000 . I11i1i11i1I - i1IIiiiii % i1IIiiiii * oooO0oo0oOOOO . i1111
def O00OoOO0oo0 ( name , url , iconimage ) :
 if 4 - 4: i1IIiiiii
 try :
  o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( 'this.loadPlayer(.+?),' , re . DOTALL ) . findall ( o0OOo0o0O0O ) [ 0 ]
  url = oO0 . replace ( '(' , '' ) . replace ( ')' , '' ) . replace ( '"' , '' ) . replace ( ' ' , '' )
  if 51 - 51: oo - oooO0oo0oOOOO % OooooO0oOO - i1111
  O0Oo000ooO00 = 'plugin://program.plexus/?url=acestream://' + str ( url ) + '&mode=1&name=acestream+' + str ( name )
  if 31 - 31: i1iIIIiI1I / I11i1i11i1I - i1iIIIiI1I - oOo0
  Oo0OO ( name , O0Oo000ooO00 , iconimage )
 except : quit ( )
 if 7 - 7: i1iIIIiI1I % oooO0oo0oOOOO . OOO0O + i1IIi11111i - oo0Ooo0
def o0o0O00oo0 ( url ) :
 if 27 - 27: i11iIiiIii % i1111 % oo0Ooo0 . oooO0oo0oOOOO - I11i1i11i1I + OOO0O
 o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Ii1iIiII1ii1 in oO0 :
  try :
   i1OOO = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except :
   i1OOO = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 57 - 57: ooO0oo0oO0 / oo0Ooo0 - II1Ii1iI1i
def ooOOo00O00Oo ( url ) :
 if 42 - 42: oooO0oo0oOOOO / oo0ooO0oOOOOo + i111I * iiIIiIiIi % iiIIiIiIi
 o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 i1iIi = 0
 for Ii1iIiII1ii1 in oO0 :
  try :
   i1OOO = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<img.+?src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : i1iIi = 1
  if 21 - 21: OooooO0oOO / i11iiII + i1IIiiiii + i111I
  if i1iIi == 0 :
   Oo0oOOo ( '[COLOR dodgerblue]' + i1OOO + '[/COLOR]' , url , 12 , iI1iIIiiii , O0O0OO0O0O0 )
  i1iIi = 0
  if 91 - 91: i11iIiiIii / II1Ii1iI1i + i1iIIIiI1I + iiIIiIiIi * i11iIiiIii
 try :
  iii11I = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( o0OOo0o0O0O ) [ 0 ]
  Oo0oOOo ( '[COLOR yellow]Next Page -->[/COLOR]' , iii11I , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 66 - 66: ooO0oo0oO0 % II1Ii1iI1i - oooO0oo0oOOOO + oo0Ooo0 * OooOoO0Oo . OoO000
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 52 - 52: iiIIiIiIi + oooO0oo0oOOOO . i1iIIIiI1I . i11iiII . oo
def oo000 ( url ) :
 if 32 - 32: II1Ii1iI1i . i1IIiiiii
 oOO = datetime . date . today ( )
 Oooo = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 16 - 16: oOo0 % i1iIIIiI1I . oooO0oo0oOOOO / I11i1i11i1I / oo0ooO0oOOOOo
 oO0o0OOOO ( '[COLOR dodgerblue]           EVENTS FOR ' + str ( Oooo ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 68 - 68: i11iIiiIii * oo
 o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="file browse_file">(.+?)<p class="played">' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 i1iIi = 0
 OO = 0
 for Ii1iIiII1ii1 in oO0 :
  try :
   o0OO0o0oOOO0O = re . compile ( 'title="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   try :
    II1i = re . compile ( '<p>(.+?)</p>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   except : II1i = "Unknown"
   url = re . compile ( '<a href="(.+?)">' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<img src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : i1iIi = 1
  if 2 - 2: ooO0oo0oO0 * I11i1i11i1I % OooooO0oOO - i1111 - i1iIIIiI1I
  if i1iIi == 0 :
   if 'vs' in o0OO0o0oOOO0O :
    i1OOO = '[COLOR dodgerblue]' + o0OO0o0oOOO0O + ' - ' + '[/COLOR][COLOR blue]' + II1i + '[/COLOR]'
    OO = OO + 1
    oO0o0OOOO ( i1OOO , url , 206 , iI1iIIiiii , O0O0OO0O0O0 , '' )
  i1iIi = 0
  if 3 - 3: OooOoO0Oo
 if OO == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR yellow]We could not find any live games at this time.[/COLOR]" , "[COLOR yellow]Please try again later.[/COLOR]" )
  quit ( )
  if 45 - 45: OooOoO0Oo
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 83 - 83: OOO0O . i111I
def Oo0ooo ( name , url , iconimage ) :
 if 28 - 28: OooooO0oOO . i1111 / i11iiII + i1111 . i111I . OoO000
 o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
 O000OOO0OOo = re . compile ( '<iframe.+?src="(.+?)"' ) . findall ( o0OOo0o0O0O ) [ 0 ]
 if 32 - 32: i1IIiiiii * oooO0oo0oOOOO
 if not "http" in O000OOO0OOo :
  O000OOO0OOo = O000OOO0OOo . replace ( "//" , "" )
  url = "http://" + O000OOO0OOo
 else :
  url = O000OOO0OOo
  if 100 - 100: iiIIiIiIi % ooO0oo0oO0 * i1111 - i1iIIIiI1I
 oo00O00oO000o = url
 if 71 - 71: i11iiII - iiIIiIiIi / OOO0O * OOO0O / II1Ii1iI1i . II1Ii1iI1i
 ooo000ooO0000 = OOOO0OOoO0O0 ( url )
 O000OOO0OOo = re . compile ( "atob(.+?)," ) . findall ( ooo000ooO0000 ) [ 0 ]
 O000OOO0OOo = O000OOO0OOo . replace ( "('" , "" ) . replace ( "')" , "" )
 url = base64 . b64decode ( O000OOO0OOo )
 url = url + '|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36&Referer=' + oo00O00oO000o + '&Host=91.121.222.160:1935&X-Requested-With=ShockwaveFlash/24.0.0.186'
 Oo0OO ( name , url , iconimage )
 if 97 - 97: I11i1i11i1I * i1IIi11111i . ooO0oo0oO0
def I1Ii1111iIi ( url ) :
 if 31 - 31: oo0Ooo0 . OooOoO0Oo * iiIIiIiIi + i11iIiiIii * OooooO0oOO
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 93 - 93: i11iiII / ooO0oo0oO0 * II1Ii1iI1i % i111I * oooO0oo0oOOOO * oo0Ooo0
  if '<display>eWVz</display>' in Ii1iIiII1ii1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<link>(.+?)</link>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   OooOoooOo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   i1OOO = base64 . b64decode ( i1OOO )
   url = base64 . b64decode ( url )
   iI1iIIiiii = base64 . b64decode ( iI1iIIiiii )
   OooOoooOo = base64 . b64decode ( OooOoooOo )
   Oo0oOOo ( i1OOO , url , 220 , iI1iIIiiii , OooOoooOo , '' )
   if 64 - 64: i1111 + oooO0oo0oOOOO / ooO0oo0oO0 / I11i1i11i1I . iiIIiIiIi % OoO000
def iiI1I1ii ( url ) :
 if 85 - 85: iiIIiIiIi / oooO0oo0oOOOO
 o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 if 18 - 18: oo0ooO0oOOOOo % oooO0oo0oOOOO * i11iiII
 for Ii1iIiII1ii1 in oO0 :
  i1OOO = re . compile ( '<a class="name" href=".+?">(.+?)</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  url = re . compile ( '<a class="name" href="(.+?)">.+?</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   o0Iii = re . compile ( '<div class="quality">(.+?)</div>.+?</a' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : o0Iii = "SD"
  o0Iii = '[COLOR yellow]' + o0Iii + '[/COLOR]'
  iI1iIIiiii = re . compile ( '<img src=".+?url=(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  i1OOO = i1OOO . replace ( 'UFC ' , '' )
  url = 'http://www.fmovies.se' + url
  if 19 - 19: oo0Ooo0 % i1111 / i11iIiiIii / i1iIIIiI1I - i111I
  oO0o0OOOO ( '[COLOR mediumpurple]' + i1OOO + '[/COLOR] - ' + o0Iii , url , 212 , iI1iIIiiii , O0O0OO0O0O0 , '' )
  if 37 - 37: oOo0 / i111I - i11iIiiIii
 try :
  url = re . compile ( '<a href="([^"]*)" rel="next"' ) . findall ( o0OOo0o0O0O ) [ 0 ]
  iI1i11 = 'http://www.fmovies.se/' + url
  Oo0oOOo ( "Next Page -->" , iI1i11 , 220 , iiiii , O0O0OO0O0O0 , '' )
 except : pass
 if 18 - 18: i1iIIIiI1I . i1IIi11111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 40 - 40: oooO0oo0oOOOO - i111I - OoO000
def iIiii ( url ) :
 if 76 - 76: i1IIi11111i . iiIIiIiIi - i11iiII - i1iIIIiI1I * oo
 o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="col-lg-3 col-md-4 col-sm-6 col-xs1-8 col-xs-12">(.+?)</div> </div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 if 54 - 54: OoO000 + oooO0oo0oOOOO + oo0Ooo0 * OooOoO0Oo - oOo0 % OooooO0oOO
 if 13 - 13: iiIIiIiIi / i1iIIIiI1I * oo . oo * iiIIiIiIi
def O00oO ( url ) :
 if 40 - 40: OOO0O / OoO000
 if "iptvembed" in url :
  o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = Ii1iIiII1ii1
   if 79 - 79: oo - ooO0oo0oO0 + i1IIiiiii - OooOoO0Oo
 if "sourcetv" in url :
  o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
  oO0 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '</pre>' , '' )
   url = Ii1iIiII1ii1
   if 93 - 93: i1111 . i1IIi11111i - I11i1i11i1I + OOO0O
 url = url . replace ( '#AAASTREAM:' , '#A:' )
 url = url . replace ( '#EXTINF:' , '#A:' )
 ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
 o000 = [ ]
 for IiI1i , oO0oOOoo00000 , url in ooO0o :
  oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : url }
  o000 . append ( oOo00 )
 list = [ ]
 for IIII1 in o000 :
  oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
  ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
  for i1iI11i1IIi , ii1IIi111 in ooO0o :
   oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
  list . append ( oOo00 )
  if 29 - 29: i11iiII . OoO000 * OooooO0oOO
 oo00o0 = 0
 for IIII1 in list :
  oo00o0 = 1
  i1OOO = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
  url = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not ".m3u8" in url :
   oO0o0OOOO ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  else :
   Oo0oOOo ( '[COLOR white]' + i1OOO + '[/COLOR]' , url , 10 , iiiii , O0O0OO0O0O0 , '' )
   if 85 - 85: OooooO0oOO - ooO0oo0oO0 / oooO0oo0oOOOO
 if oo00o0 == 0 :
  oO0o0OOOO ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 99 - 99: i1111 * OoO000 % ooO0oo0oO0 / i1IIiiiii
def OOO00O0oOOo ( url ) :
 if 71 - 71: oo0Ooo0 / oo0ooO0oOOOOo / OooOoO0Oo % oOo0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = url
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 51 - 51: OoO000 * oooO0oo0oOOOO / i1111 . i1IIiiiii % oOo0 / i1IIi11111i
  i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
  if len ( i1iIIIi1i ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + iI1iIIiiii
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 20 , iI1iIIiiii , iI1iIIiiii )
   if 9 - 9: i1IIi11111i % i1IIi11111i % i1111
  elif len ( i1iIIIi1i ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = O0Oo000ooO00 + "!" + i1OOO + "!" + iI1iIIiiii
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 22 , iI1iIIiiii , iI1iIIiiii )
   if 30 - 30: OoO000 + OooOoO0Oo - OoO000 . OoO000 - i1111 + oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 86 - 86: II1Ii1iI1i
def IIi11IIiIii1 ( url ) :
 if 17 - 17: i1IIiiiii + OooooO0oOO . oo - I11i1i11i1I * i11iIiiIii
 oOO = datetime . date . today ( )
 Oooo = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 20 - 20: i1IIi11111i . i111I % oOo0
 oO0o0OOOO ( '[COLOR dodgerblue]EVENTS FOR ' + str ( Oooo ) . upper ( ) + '[/COLOR]' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '##############################################' , url , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 63 - 63: i1IIi11111i % ooO0oo0oO0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 O0Oo000ooO00 = url
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00OO00OoO )
 for Ii1iIiII1ii1 in oO0 :
  if 39 - 39: i1iIIIiI1I / i1111 / i11iiII % i1IIi11111i
  i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 )
  if len ( i1iIIIi1i ) == 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = i1OOO + "!" + url + "!" + iI1iIIiiii
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 20 , iI1iIIiiii , iI1iIIiiii )
   if 89 - 89: OooOoO0Oo + i111I + OooOoO0Oo * II1Ii1iI1i + ooO0oo0oO0 % oo0Ooo0
  elif len ( i1iIIIi1i ) > 1 :
   i1OOO = re . compile ( '<title>(.+?)</title>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1iIIiiii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   url = O0Oo000ooO00 + "!" + i1OOO + "!" + iI1iIIiiii
   i1OOO = '[COLOR white]' + i1OOO + '[/COLOR]'
   Oo0oOOo ( i1OOO , url , 22 , iI1iIIiiii , iI1iIIiiii )
   if 59 - 59: oOo0 + i11iIiiIii
def oo0OOo0O ( ) :
 if 39 - 39: i111I + OooooO0oOO % oOo0 / oOo0
 oOO = datetime . date . today ( )
 Oooo = datetime . datetime . strftime ( oOO , '%A %d %B %Y' )
 if 27 - 27: i1iIIIiI1I . oo0Ooo0 . ooO0oo0oO0 . ooO0oo0oO0
 oO0o0OOOO ( '[COLOR dodgerblue]EVENTS FOR ' + str ( Oooo ) . upper ( ) + '[/COLOR]' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 oO0o0OOOO ( '##############################################' , '' , 20 , iiiii , O0O0OO0O0O0 , "" )
 if 20 - 20: oo0ooO0oOOOOo / II1Ii1iI1i
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.oddschecker.com/tv-sports-calendar' )
 oO0 = re . compile ( '<div id="agenda-content">(.+?)<table id="calendar">' ) . findall ( o00OO00OoO )
 o000ooooO0o = str ( oO0 )
 oO = re . compile ( '<div class="eventTop">(.+?)</div></div></div>' ) . findall ( o000ooooO0o )
 for Ii1iIiII1ii1 in oO :
  try :
   if not '<span class="button no-arrow blink in-play">In Play</span>' in Ii1iIiII1ii1 :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    o0OO0o0oOOO0O = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    iI1iIIiiii = re . compile ( 'src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    time = re . compile ( '<span itemprop="startDate" content=".+?">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     Ii111 = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
     Ii111 = oO0i1iI ( Ii111 )
    except : Ii111 = "null"
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + o0OO0o0oOOO0O + '[/COLOR] - [COLOR orange]' + time + '[/COLOR]'
    i1OOO = ii ( i1OOO )
    i1iI11i1ii11 = o0OO0o0oOOO0O + "!" + Ii111 . lower ( ) + "!" + iI1iIIiiii
    Oo0oOOo ( i1OOO , i1iI11i1ii11 , 20 , iI1iIIiiii , 'http://imgur.com/5T0EbBv.jpg' )
   else :
    type = re . compile ( '<span itemprop="name">(.+?)</span>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    o0OO0o0oOOO0O = re . compile ( 'href=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    try :
     Ii111 = re . compile ( 'src=".+?" alt="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    except : Ii111 = "null"
    iI1iIIiiii = re . compile ( 'src="(.+?)"' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    i1OOO = '[COLOR dodgerblue]' + type + '[/COLOR] | [COLOR mediumpurple]' + o0OO0o0oOOO0O + '[/COLOR] - [COLOR red]In Play[/COLOR]'
    i1OOO = ii ( i1OOO )
    i1iI11i1ii11 = o0OO0o0oOOO0O + "!" + Ii111 . lower ( ) + "!" + iI1iIIiiii
    Oo0oOOo ( i1OOO , i1iI11i1ii11 , 20 , iI1iIIiiii , 'http://imgur.com/5T0EbBv.jpg' )
  except : pass
  if 81 - 81: oooO0oo0oOOOO % i1IIiiiii
def IiIII1i1i ( name , url , iconimage ) :
 if 41 - 41: I11i1i11i1I / i1IIiiiii * i1IIiiiii - oOo0 . OooOoO0Oo . i111I
 try :
  url , I1iIIi111i1 , iconimage = url . split ( '!' )
 except :
  O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 12 - 12: i1111 . oo0Ooo0 / oOo0
 O00OO0oO = [ ]
 if 25 - 25: I11i1i11i1I % i11iiII * iiIIiIiIi
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 iIIIiIi = re . compile ( '<title>' + re . escape ( I1iIIi111i1 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( o00OO00OoO ) [ 0 ]
 iconimage = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iIIIiIi ) [ 0 ]
 i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( iIIIiIi )
 for OO0O0 in i1iIIIi1i :
  O00OO0oO . append ( OO0O0 )
  if 6 - 6: i1iIIIiI1I . OoO000 * OOO0O . II1Ii1iI1i
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 98 - 98: II1Ii1iI1i
 oO0O = 0
 if 86 - 86: OOO0O . ooO0oo0oO0 - oo
 oOOI11I = [ ]
 iIIII1i = [ ]
 o00oO0 = [ ]
 I1IiiI . update ( 0 )
 i11I1II = 0
 if 79 - 79: oo . i1iIIIiI1I * i1IIiiiii - oOo0 + iiIIiIiIi
 if oO000OoOoo00o == "true" :
  i11I1II = 1
  o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   if oO0O < 100 :
    I1IiiI . update ( oO0O )
    oO0O = oO0O + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o000 = [ ]
   for IiI1i , oO0oOOoo00000 , url in ooO0o :
    oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : url }
    o000 . append ( oOo00 )
   ii11II1i = [ ]
   for IIII1 in o000 :
    oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for i1iI11i1IIi , ii1IIi111 in ooO0o :
     oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
    ii11II1i . append ( oOo00 )
    if 58 - 58: I11i1i11i1I . OoO000 - I11i1i11i1I - OooOoO0Oo * i1IIiiiii
   for IIII1 in ii11II1i :
    name = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
    url = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOI11I . append ( name )
    iIIII1i . append ( url )
    if "hd" in name . lower ( ) :
     o00oO0 . append ( "1" )
    else :
     o00oO0 . append ( "0" )
    ooo0O0o00O = list ( zip ( o00oO0 , oOOI11I , iIIII1i ) )
    if 28 - 28: OOO0O * oo . oo0Ooo0 % oo0Ooo0 / oo0Ooo0 * OooOoO0Oo
 if iiiI11 == "true" :
  i11I1II = 1
  o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   if oO0O < 100 :
    I1IiiI . update ( oO0O )
    oO0O = oO0O + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o000 = [ ]
   for IiI1i , oO0oOOoo00000 , url in ooO0o :
    oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : url }
    o000 . append ( oOo00 )
   ii11II1i = [ ]
   for IIII1 in o000 :
    oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for i1iI11i1IIi , ii1IIi111 in ooO0o :
     oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
    ii11II1i . append ( oOo00 )
    if 64 - 64: i1111 - i1IIi11111i
   for IIII1 in ii11II1i :
    name = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
    url = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOI11I . append ( name )
    iIIII1i . append ( url )
    if "hd" in name . lower ( ) :
     o00oO0 . append ( "1" )
    else :
     o00oO0 . append ( "0" )
    ooo0O0o00O = list ( zip ( o00oO0 , oOOI11I , iIIII1i ) )
    if 68 - 68: iiIIiIiIi - oOo0 - ooO0oo0oO0 / OOO0O + oOo0 - oo
 if OOooO == "true" :
  i11I1II = 1
  o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   if oO0O < 100 :
    I1IiiI . update ( oO0O )
    oO0O = oO0O + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o000 = [ ]
   for IiI1i , oO0oOOoo00000 , url in ooO0o :
    oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : url }
    o000 . append ( oOo00 )
   ii11II1i = [ ]
   for IIII1 in o000 :
    oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for i1iI11i1IIi , ii1IIi111 in ooO0o :
     oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
    ii11II1i . append ( oOo00 )
    if 75 - 75: i1iIIIiI1I / oo0ooO0oOOOOo % ooO0oo0oO0 . i111I % i111I % i1111
   for IIII1 in ii11II1i :
    name = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
    url = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOI11I . append ( name )
    iIIII1i . append ( url )
    if "hd" in name . lower ( ) :
     o00oO0 . append ( "1" )
    else :
     o00oO0 . append ( "0" )
    ooo0O0o00O = list ( zip ( o00oO0 , oOOI11I , iIIII1i ) )
    if 26 - 26: i1111 % i11iIiiIii % ooO0oo0oO0 % oo0Ooo0 * oo0Ooo0 * i11iiII
 if i11I1II == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 24 - 24: i1111 % OooOoO0Oo - iiIIiIiIi + i1IIi11111i * i11iiII
 OOOOoOOo0O0 = sorted ( ooo0O0o00O , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 i11111I1I = sorted ( O00OO0oO )
 if 61 - 61: i1111 * oOo0 / i111I / I11i1i11i1I - oo
 iI1Iii = 0
 if 56 - 56: i11iiII
 I1IiiI . update ( 100 )
 if 26 - 26: i111I % i111I
 oO0o0OOOO ( '[COLOR dodgerblue][B]LINKS FOR ' + I1iIIi111i1 . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 if 33 - 33: OooOoO0Oo
 if 62 - 62: i11iiII + i1IIiiiii + II1Ii1iI1i / i111I
 for Ii111 in i11111I1I :
  if 7 - 7: oo0ooO0oOOOOo + II1Ii1iI1i . i1IIi11111i / I11i1i11i1I
  oO0o0OOOO ( '[COLOR orangered][B]' + Ii111 . upper ( ) + ' LINKS[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 22 - 22: iiIIiIiIi - iiIIiIiIi % oOo0 . OooOoO0Oo + OooooO0oOO
  o000ooooO0o = Ii111 . split ( ' ' )
  if 63 - 63: i1IIi11111i % OooOoO0Oo * oo0ooO0oOOOOo + OooOoO0Oo / I11i1i11i1I % i1iIIIiI1I
  for iiI1i1Iii111 , name , url in OOOOoOOo0O0 :
   if 43 - 43: oo0ooO0oOOOOo
   OO00oOooo0O = 0
   if 58 - 58: I11i1i11i1I / OooooO0oOO
   for iIII1I1i1i in o000ooooO0o :
    if 79 - 79: i1IIiiiii . oo
    if not iIII1I1i1i . lower ( ) in name . lower ( ) :
     OO00oOooo0O = 1
     if 40 - 40: oo0ooO0oOOOOo + I11i1i11i1I . oo0ooO0oOOOOo % iiIIiIiIi
   if OO00oOooo0O == 0 :
    iI1Iii = iI1Iii + 1
    if "hd" in name . lower ( ) :
     oO0o0OOOO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iI1Iii ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO0o0OOOO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iI1Iii ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 15 - 15: i1IIiiiii * I11i1i11i1I % i11iiII * ooO0oo0oO0 - i11iIiiIii
  if iI1Iii == 0 :
   oO0o0OOOO ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
   if 60 - 60: i1IIi11111i * OooOoO0Oo % oo + OooooO0oOO
  o000ooooO0o = ""
  if 52 - 52: II1Ii1iI1i
 I1IiiI . close ( )
 if 84 - 84: i1IIiiiii / OoO000
def OOOooo0OooOoO ( name , url , iconimage ) :
 if 91 - 91: OooooO0oOO + i1IIi11111i
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 59 - 59: i1IIi11111i + i11iIiiIii + II1Ii1iI1i / oo0Ooo0
 oO0O = 0
 try :
  I1iIIi111i1 , Ii111 , iconimage = url . split ( '!' )
 except :
  try :
   Ii111 , iconimage = url . split ( '!' )
   I1iIIi111i1 = Ii111
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 44 - 44: oo0Ooo0 . OOO0O * i1IIi11111i + i111I - i1iIIIiI1I - OoO000
 I1iii = 0
 if 51 - 51: i11iiII
 if "all " in name . lower ( ) :
  Ii111 = Ii111 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  I1iIIi111i1 = I1iIIi111i1 . replace ( 'all ' , '' ) . replace ( 'ALL ' , '' ) . replace ( 'All ' , '' )
  I1iii = 1
  if 41 - 41: i11iiII * iiIIiIiIi - i1IIiiiii + I11i1i11i1I
 oOOI11I = [ ]
 iIIII1i = [ ]
 o00oO0 = [ ]
 I1IiiI . update ( 0 )
 i11I1II = 0
 if oO000OoOoo00o == "true" :
  i11I1II = 1
  o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   if oO0O < 100 :
    I1IiiI . update ( oO0O )
    oO0O = oO0O + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o000 = [ ]
   for IiI1i , oO0oOOoo00000 , url in ooO0o :
    oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : url }
    o000 . append ( oOo00 )
   ii11II1i = [ ]
   for IIII1 in o000 :
    oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for i1iI11i1IIi , ii1IIi111 in ooO0o :
     oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
    ii11II1i . append ( oOo00 )
    if 23 - 23: i1111 % oo0ooO0oOOOOo + oo0ooO0oOOOOo + i1iIIIiI1I - i1iIIIiI1I
   for IIII1 in ii11II1i :
    name = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
    url = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOI11I . append ( name )
    iIIII1i . append ( url )
    if "hd" in name . lower ( ) :
     o00oO0 . append ( "1" )
    else :
     o00oO0 . append ( "0" )
    ooo0O0o00O = list ( zip ( o00oO0 , oOOI11I , iIIII1i ) )
    if 62 - 62: oo0ooO0oOOOOo
 if iiiI11 == "true" :
  i11I1II = 1
  o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   if oO0O < 100 :
    I1IiiI . update ( oO0O )
    oO0O = oO0O + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o000 = [ ]
   for IiI1i , oO0oOOoo00000 , url in ooO0o :
    oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : url }
    o000 . append ( oOo00 )
   ii11II1i = [ ]
   for IIII1 in o000 :
    oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for i1iI11i1IIi , ii1IIi111 in ooO0o :
     oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
    ii11II1i . append ( oOo00 )
    if 45 - 45: oOo0 * iiIIiIiIi
   for IIII1 in ii11II1i :
    name = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
    url = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOI11I . append ( name )
    iIIII1i . append ( url )
    if "hd" in name . lower ( ) :
     o00oO0 . append ( "1" )
    else :
     o00oO0 . append ( "0" )
    ooo0O0o00O = list ( zip ( o00oO0 , oOOI11I , iIIII1i ) )
    if 74 - 74: II1Ii1iI1i + oooO0oo0oOOOO + I11i1i11i1I
 if OOooO == "true" :
  i11I1II = 1
  o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
  oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
  for Ii1iIiII1ii1 in oO0 :
   if oO0O < 100 :
    I1IiiI . update ( oO0O )
    oO0O = oO0O + 3
   Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
   url = Ii1iIiII1ii1
   url = url . replace ( '#AAASTREAM:' , '#A:' )
   url = url . replace ( '#EXTINF:' , '#A:' )
   ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
   o000 = [ ]
   for IiI1i , oO0oOOoo00000 , url in ooO0o :
    oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : url }
    o000 . append ( oOo00 )
   ii11II1i = [ ]
   for IIII1 in o000 :
    oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
    ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
    for i1iI11i1IIi , ii1IIi111 in ooO0o :
     oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
    ii11II1i . append ( oOo00 )
    if 5 - 5: I11i1i11i1I * OOO0O
   for IIII1 in ii11II1i :
    name = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
    url = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
    url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    oOOI11I . append ( name )
    iIIII1i . append ( url )
    if "hd" in name . lower ( ) :
     o00oO0 . append ( "1" )
    else :
     o00oO0 . append ( "0" )
    ooo0O0o00O = list ( zip ( o00oO0 , oOOI11I , iIIII1i ) )
    if 46 - 46: iiIIiIiIi
 if i11I1II == 0 :
  O00ooooo00 . ok ( Oo0Ooo , "Error, no scrapers are enabled. Please enable some scrapers in the addon settings." )
  quit ( )
  if 33 - 33: i1iIIIiI1I - i1111 * i111I - I11i1i11i1I - oOo0
 OOOOoOOo0O0 = sorted ( ooo0O0o00O , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 if 84 - 84: OooOoO0Oo + I11i1i11i1I - OOO0O * OOO0O
 iI1Iii = 0
 if 61 - 61: i111I . OooooO0oOO . i111I / I11i1i11i1I
 I1IiiI . update ( 100 )
 if 72 - 72: II1Ii1iI1i
 oO0o0OOOO ( '[COLOR dodgerblue][B]LINKS FOR ' + I1iIIi111i1 . upper ( ) + '[/B][/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( '================================================================' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
 o000ooooO0o = Ii111 . split ( ' ' )
 for iiI1i1Iii111 , name , url in OOOOoOOo0O0 :
  if I1iii == 1 :
   OOoo0oo = name
   if 58 - 58: OooooO0oOO
  OO00oOooo0O = 0
  if 4 - 4: i1111 . iiIIiIiIi / i11iiII - i11iIiiIii
  for iIII1I1i1i in o000ooooO0o :
   if 72 - 72: oooO0oo0oOOOO / iiIIiIiIi + i111I * i1iIIIiI1I
   if not iIII1I1i1i . lower ( ) in name . lower ( ) :
    OO00oOooo0O = 1
    if 61 - 61: i111I % i1111 - i1IIi11111i % i11iiII + II1Ii1iI1i
  if OO00oOooo0O == 0 :
   iI1Iii = iI1Iii + 1
   if I1iii == 1 :
    if "hd" in name . lower ( ) :
     oO0o0OOOO ( '[COLOR blue] ' + str ( OOoo0oo ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO0o0OOOO ( '[COLOR blue] ' + str ( OOoo0oo ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
   else :
    if "hd" in name . lower ( ) :
     oO0o0OOOO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iI1Iii ) + '[/COLOR] - [COLOR yellow][B]HD[/B][/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
    else :
     oO0o0OOOO ( '[COLOR blue]LINK[/COLOR][COLOR blue] ' + str ( iI1Iii ) + '[/COLOR] - [COLOR white]SD[/COLOR]' , url , 2 , iconimage , O0O0OO0O0O0 , '' )
     if 39 - 39: II1Ii1iI1i
 if iI1Iii == 0 :
  oO0o0OOOO ( '[COLOR white]NO LINKS FOUND[/COLOR]' , url , 999 , iconimage , O0O0OO0O0O0 , '' )
  if 86 - 86: ooO0oo0oO0 + OOO0O . i11iIiiIii - i1IIiiiii
 I1IiiI . close ( )
 if 51 - 51: OOO0O
def I11IIIiIi11 ( term ) :
 if 39 - 39: i1IIiiiii % oooO0oo0oOOOO % OOO0O . II1Ii1iI1i
 O000OOO = [ ]
 II = [ ]
 if 86 - 86: oo * i111I
 o0OOo0o0O0O = OOOO0OOoO0O0 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 oO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( o0OOo0o0O0O )
 for Ii1iIiII1ii1 in oO0 :
  Ii1iIiII1ii1 = Ii1iIiII1ii1 . replace ( '<br />' , '\n' )
  i1iI11i1ii11 = Ii1iIiII1ii1
  if 71 - 71: ooO0oo0oO0 - oOo0 . i1IIi11111i % i111I + oOo0
  i1iI11i1ii11 = i1iI11i1ii11 . replace ( '#AAASTREAM:' , '#A:' )
  i1iI11i1ii11 = i1iI11i1ii11 . replace ( '#EXTINF:' , '#A:' )
  ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i1iI11i1ii11 )
  o000 = [ ]
  for IiI1i , oO0oOOoo00000 , i1iI11i1ii11 in ooO0o :
   oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : i1iI11i1ii11 }
   o000 . append ( oOo00 )
  list = [ ]
  for IIII1 in o000 :
   oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
   ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
   for i1iI11i1IIi , ii1IIi111 in ooO0o :
    oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
   list . append ( oOo00 )
   if 26 - 26: I11i1i11i1I + oOo0 / oo % OOO0O % i11iiII + i1111
  for IIII1 in list :
   i1OOO = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
   i1iI11i1ii11 = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
   i1iI11i1ii11 = i1iI11i1ii11 . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if term . lower ( ) in i1OOO . lower ( ) :
    O000OOO . append ( i1iI11i1ii11 )
    II . append ( i1OOO )
    if 31 - 31: oo0Ooo0 % oOo0 * oo0Ooo0
 O00ooooo00 = xbmcgui . Dialog ( )
 I1i1i1iii = O00ooooo00 . select ( '[COLOR yellow]Search Term: [I]' + term + '[/I][/COLOR]' , II )
 if I1i1i1iii < 0 :
  quit ( )
  if 45 - 45: II1Ii1iI1i . i1IIi11111i + oOo0 - i111I % iiIIiIiIi
 i1iI11i1ii11 = O000OOO [ I1i1i1iii ]
 i1OOO = II [ I1i1i1iii ]
 Oo0OO ( i1OOO , i1iI11i1ii11 , iiiii )
 if 1 - 1: ooO0oo0oO0
def ooi1II1I ( name , url , iconimage ) :
 if 95 - 95: oo - oOo0 / i1111 % i11iiII . oo0ooO0oOOOOo
 list = iii1IIII1iii11I ( url )
 if 97 - 97: i111I - OooOoO0Oo
 oooo00 = 0
 OooO0 = open ( iI1Ii11111iIi , mode = 'r' ) ; OO00O000OOO = OooO0 . read ( ) ; OooO0 . close ( )
 OO00O000OOO = OO00O000OOO . replace ( '\n' , '' )
 oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( OO00O000OOO )
 oo00o0 = 0
 for Ii1iIiII1ii1 in oO0 :
  if 3 - 3: oooO0oo0oOOOO
  Ooo0Oo0oo0 = re . compile ( '<url>(.+?)</url>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  if 83 - 83: OooOoO0Oo
  if url == Ooo0Oo0oo0 :
   oooo00 = 1
   if 48 - 48: i1111 * oOo0 * OooOoO0Oo
 for IIII1 in list :
  name = OooOOOOoO00OoOO ( IIII1 [ "display_name" ] )
  url = OooOOOOoO00OoOO ( IIII1 [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if oooo00 == 1 :
   if 50 - 50: OoO000 % II1Ii1iI1i
   OooO0 = open ( i1i1II , mode = 'r' ) ; OO00O000OOO = OooO0 . read ( ) ; OooO0 . close ( )
   OO00O000OOO = OO00O000OOO . replace ( '\n' , '' )
   oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( OO00O000OOO )
   for Ii1iIiII1ii1 in oO0 :
    if 21 - 21: i111I - ooO0oo0oO0
    OO0OoOOO0 = re . compile ( '<name>(.+?)</name>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
    if 90 - 90: iiIIiIiIi + i1111 * i11iiII / i1IIiiiii . oo0ooO0oOOOOo + oo0ooO0oOOOOo
    I11I = OO0OoOOO0 . replace ( ' ' , '' )
    oOoO = name . replace ( ' ' , '' )
    if I11I . lower ( ) in oOoO . lower ( ) :
     if 26 - 26: OOO0O / I11i1i11i1I - II1Ii1iI1i + oo0Ooo0
     OooO0 = open ( O0oo0OO0 , mode = 'r' ) ; OO00O000OOO = OooO0 . read ( ) ; OooO0 . close ( )
     OO00O000OOO = OO00O000OOO . replace ( '\n' , '' )
     oO0 = re . compile ( '<item>(.+?)</item>' ) . findall ( OO00O000OOO )
     for Ii1iIiII1ii1 in oO0 :
      if 38 - 38: i111I / i11iiII . oooO0oo0oOOOO / II1Ii1iI1i / I11i1i11i1I + ooO0oo0oO0
      ooO00O00oOO = re . compile ( '<replace>(.+?)</replace>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
      if 40 - 40: i1iIIIiI1I . OooooO0oOO + i1IIi11111i + i11iiII + OooOoO0Oo
      name = name . lower ( ) . replace ( ooO00O00oOO , '' )
      if 26 - 26: ooO0oo0oO0
     oO0o0OOOO ( '[COLOR white]' + name . upper ( ) + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
     if 87 - 87: i11iiII / i111I - I11i1i11i1I % OOO0O % OoO000 % I11i1i11i1I
  else : oO0o0OOOO ( '[COLOR white]' + name + '[/COLOR]' , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 29 - 29: i111I . i1IIi11111i % i11iiII - i1iIIIiI1I
def iii1IIII1iii11I ( url ) :
 if 8 - 8: II1Ii1iI1i
 iIiI1 = IIIii1II1II ( url )
 iIiI1 = iIiI1 . replace ( '#AAASTREAM:' , '#A:' )
 iIiI1 = iIiI1 . replace ( '#EXTINF:' , '#A:' )
 ooO0o = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( iIiI1 )
 o000 = [ ]
 for IiI1i , oO0oOOoo00000 , url in ooO0o :
  oOo00 = { "params" : IiI1i , "display_name" : oO0oOOoo00000 , "url" : url }
  o000 . append ( oOo00 )
 list = [ ]
 for IIII1 in o000 :
  oOo00 = { "display_name" : IIII1 [ "display_name" ] , "url" : IIII1 [ "url" ] }
  ooO0o = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIII1 [ "params" ] )
  for i1iI11i1IIi , ii1IIi111 in ooO0o :
   oOo00 [ i1iI11i1IIi . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1IIi111 . strip ( )
  list . append ( oOo00 )
  if 37 - 37: oo * i11iIiiIii / oOo0 % OooOoO0Oo
 return list
 if 71 - 71: i111I
 if 11 - 11: OoO000
def o0oooO ( ) :
 if 89 - 89: i1111 / OooooO0oOO
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]OVERVIEW PER FIXTURE[/B][/COLOR]' , II1 , 70 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]PREDICTIONS[/B][/COLOR]' , II1 , 40 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]ODDS CHECKER[/B][/COLOR]' , II1 , 50 , iiiii , O0O0OO0O0O0 , "" )
 Oo0oOOo ( '[COLOR mediumpurple][B]SPORTIE[/COLOR] [COLOR blue]FORM GUIDE[/B][/COLOR]' , II1 , 60 , iiiii , O0O0OO0O0O0 , "" )
 if 14 - 14: oOo0 . i1IIi11111i * iiIIiIiIi + i1111 - iiIIiIiIi + oOo0
def IIIIIiII1 ( name , url , iconimage ) :
 if 45 - 45: i1IIi11111i / i1iIIIiI1I . i1iIIIiI1I
 i1oO = datetime . datetime . now ( )
 iIIi1IIi = i1oO . day
 if 43 - 43: OooOoO0Oo % i1iIIIiI1I
 o0O0ooOOoO = iIIi1IIi
 if 19 - 19: i11iIiiIii
 oo0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOOII1i11i1iIi11 = datetime . datetime . strftime ( oo0 , '%A - %d %B %Y' )
 oo0O0oO0O0O = 'http://www.predictz.com/predictions/'
 if 69 - 69: OooooO0oOO / i11iIiiIii
 OOo00 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 iiiii1ii1 = datetime . datetime . strftime ( OOo00 , '%A - %d %B %Y' )
 IiiiI1 = datetime . datetime . strftime ( OOo00 , '%d' )
 OOOo0OOo0Oo0OOo0 = 'http://www.predictz.com/predictions/tomorrow/'
 if 19 - 19: oo0Ooo0 + i1111
 OooooOoO = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 i1oOOOOOOOoO = datetime . datetime . strftime ( OooooOoO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 I1 = datetime . datetime . strftime ( OooooOoO , '%y%m%d' )
 IIiI = 'http://www.predictz.com/predictions/20' + str ( I1 )
 if 84 - 84: oo0Ooo0 - I11i1i11i1I / oooO0oo0oOOOO - OooOoO0Oo
 ii1iI1II11ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 i1i1IiIiIi1Ii = datetime . datetime . strftime ( ii1iI1II11ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oO0ooOO = datetime . datetime . strftime ( ii1iI1II11ii , '%y%m%d' )
 IIi1iI1 = 'http://www.predictz.com/predictions/20' + str ( oO0ooOO )
 if 44 - 44: i11iiII - i1IIiiiii / i1111 * oo * I11i1i11i1I
 OO0ooo0o0 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 oO0ooOoO = datetime . datetime . strftime ( OO0ooo0o0 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO0000o00O = datetime . datetime . strftime ( OO0ooo0o0 , '%y%m%d' )
 O0Ooo = 'http://www.predictz.com/predictions/20' + str ( ooO0000o00O )
 if 78 - 78: oo % OoO000 * II1Ii1iI1i
 if 66 - 66: i1IIiiiii . i1IIi11111i + oo0ooO0oOOOOo . ooO0oo0oO0
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOOII1i11i1iIi11 ) + '[/B][/COLOR]' , oo0O0oO0O0O , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iiiii1ii1 ) + '[/B][/COLOR]' , OOOo0OOo0Oo0OOo0 , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1oOOOOOOOoO ) , IIiI , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1i1IiIiIi1Ii ) , IIi1iI1 , 41 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oO0ooOoO ) , O0Ooo , 41 , iiiii , O0O0OO0O0O0 , '' )
 if 51 - 51: oo0Ooo0 . I11i1i11i1I
def IiiIiiIi ( name , url , iconimage ) :
 if 40 - 40: oo0ooO0oOOOOo
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 o000ooooO0o = str ( oO0 )
 oO = re . compile ( '<tr(.+?)</tr>' ) . findall ( o000ooooO0o )
 for Ii1iIiII1ii1 in oO :
  try :
   II1i = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR red][B]' + II1i + ' Predictions[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OO0o0oOOO0O = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oOOo0oo0o0o0 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   o0OO0o0oOOO0O = iIii1 ( o0OO0o0oOOO0O )
   oOOo0oo0o0o0 = iIii1 ( oOOo0oo0o0o0 )
   oO0o0OOOO ( '[COLOR orange][B]Prediction - [/COLOR][COLOR dodgerblue]' + oOOo0oo0o0o0 + ' [/B][/COLOR]| [COLOR mediumpurple]' + o0OO0o0oOOO0O + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 62 - 62: ooO0oo0oO0 + i1iIIIiI1I . I11i1i11i1I / OoO000 % oooO0oo0oOOOO . OooOoO0Oo
def Oo0oOooOoOo ( name , url , iconimage ) :
 if 49 - 49: oOo0 . i11iiII . i11iIiiIii - i1111 / i1IIiiiii
 i1oO = datetime . datetime . now ( )
 iIIi1IIi = i1oO . day
 if 62 - 62: oOo0
 o0O0ooOOoO = iIIi1IIi
 if 1 - 1: OoO000 / OoO000 - i11iIiiIii
 oo0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOOII1i11i1iIi11 = datetime . datetime . strftime ( oo0 , '%A - %d %B %Y' )
 oo0O0oO0O0O = 'http://www.predictz.com/predictions/'
 if 87 - 87: I11i1i11i1I / oooO0oo0oOOOO * OoO000 / oo0ooO0oOOOOo
 OOo00 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 iiiii1ii1 = datetime . datetime . strftime ( OOo00 , '%A - %d %B %Y' )
 IiiiI1 = datetime . datetime . strftime ( OOo00 , '%d' )
 OOOo0OOo0Oo0OOo0 = 'http://www.predictz.com/predictions/tomorrow/'
 if 19 - 19: OooOoO0Oo + II1Ii1iI1i . i1IIi11111i - I11i1i11i1I
 OooooOoO = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 i1oOOOOOOOoO = datetime . datetime . strftime ( OooooOoO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 I1 = datetime . datetime . strftime ( OooooOoO , '%y%m%d' )
 IIiI = 'http://www.predictz.com/predictions/20' + str ( I1 )
 if 16 - 16: OooooO0oOO + iiIIiIiIi / oo0ooO0oOOOOo
 ii1iI1II11ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 i1i1IiIiIi1Ii = datetime . datetime . strftime ( ii1iI1II11ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oO0ooOO = datetime . datetime . strftime ( ii1iI1II11ii , '%y%m%d' )
 IIi1iI1 = 'http://www.predictz.com/predictions/20' + str ( oO0ooOO )
 if 82 - 82: OoO000 * i11iIiiIii % i1111 - i111I
 OO0ooo0o0 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 oO0ooOoO = datetime . datetime . strftime ( OO0ooo0o0 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO0000o00O = datetime . datetime . strftime ( OO0ooo0o0 , '%y%m%d' )
 O0Ooo = 'http://www.predictz.com/predictions/20' + str ( ooO0000o00O )
 if 90 - 90: I11i1i11i1I . OooooO0oOO * II1Ii1iI1i - II1Ii1iI1i
 if 16 - 16: i1IIi11111i * II1Ii1iI1i - oo0ooO0oOOOOo . OoO000 % oo0Ooo0 / oo0ooO0oOOOOo
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOOII1i11i1iIi11 ) + '[/B][/COLOR]' , oo0O0oO0O0O , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iiiii1ii1 ) + '[/B][/COLOR]' , OOOo0OOo0Oo0OOo0 , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1oOOOOOOOoO ) , IIiI , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1i1IiIiIi1Ii ) , IIi1iI1 , 51 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oO0ooOoO ) , O0Ooo , 51 , iiiii , O0O0OO0O0O0 , '' )
 if 14 - 14: ooO0oo0oO0 * OooOoO0Oo * i11iiII / ooO0oo0oO0 * OoO000 / oo0Ooo0
def OOO000 ( name , url , iconimage ) :
 if 28 - 28: i111I . OooooO0oOO % i11iiII / II1Ii1iI1i / oOo0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 o000ooooO0o = str ( oO0 )
 oO = re . compile ( '<tr(.+?)</tr>' ) . findall ( o000ooooO0o )
 for Ii1iIiII1ii1 in oO :
  try :
   II1i = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR red][B]' + II1i + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OO0o0oOOO0O = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   III1I1I = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   i1i111i1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   OoOoOo0 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   o0OO0o0oOOO0O = iIii1 ( o0OO0o0oOOO0O )
   oO0o0OOOO ( '[COLOR mediumpurple][B]' + o0OO0o0oOOO0O + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]Home Win[/COLOR][COLOR dodgerblue] (' + III1I1I + ')[/COLOR][COLOR orange]  -  Draw[/COLOR][COLOR dodgerblue] (' + i1i111i1 + ')[/COLOR][COLOR orange]  -  Away Win[/COLOR][COLOR dodgerblue] (' + OoOoOo0 + ')[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 39 - 39: oo0Ooo0 - i11iiII
def OOO0o0OO0OO ( name , url , iconimage ) :
 if 64 - 64: i1111
 i1oO = datetime . datetime . now ( )
 iIIi1IIi = i1oO . day
 if 40 - 40: OOO0O % oo
 o0O0ooOOoO = iIIi1IIi
 if 62 - 62: oo0ooO0oOOOOo
 oo0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOOII1i11i1iIi11 = datetime . datetime . strftime ( oo0 , '%A - %d %B %Y' )
 oo0O0oO0O0O = 'http://www.predictz.com/predictions/'
 if 15 - 15: oo0Ooo0 + i1IIiiiii . oOo0 * oo . OOO0O
 OOo00 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 iiiii1ii1 = datetime . datetime . strftime ( OOo00 , '%A - %d %B %Y' )
 IiiiI1 = datetime . datetime . strftime ( OOo00 , '%d' )
 OOOo0OOo0Oo0OOo0 = 'http://www.predictz.com/predictions/tomorrow/'
 if 18 - 18: II1Ii1iI1i % i1111 + OooOoO0Oo % i1IIiiiii
 OooooOoO = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 i1oOOOOOOOoO = datetime . datetime . strftime ( OooooOoO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 I1 = datetime . datetime . strftime ( OooooOoO , '%y%m%d' )
 IIiI = 'http://www.predictz.com/predictions/20' + str ( I1 )
 if 72 - 72: ooO0oo0oO0
 ii1iI1II11ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 i1i1IiIiIi1Ii = datetime . datetime . strftime ( ii1iI1II11ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oO0ooOO = datetime . datetime . strftime ( ii1iI1II11ii , '%y%m%d' )
 IIi1iI1 = 'http://www.predictz.com/predictions/20' + str ( oO0ooOO )
 if 45 - 45: I11i1i11i1I - oo0ooO0oOOOOo % OooOoO0Oo
 OO0ooo0o0 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 oO0ooOoO = datetime . datetime . strftime ( OO0ooo0o0 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO0000o00O = datetime . datetime . strftime ( OO0ooo0o0 , '%y%m%d' )
 O0Ooo = 'http://www.predictz.com/predictions/20' + str ( ooO0000o00O )
 if 38 - 38: OooOoO0Oo % oOo0 - i111I
 if 87 - 87: oo % i1IIi11111i
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOOII1i11i1iIi11 ) + '[/B][/COLOR]' , oo0O0oO0O0O , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iiiii1ii1 ) + '[/B][/COLOR]' , OOOo0OOo0Oo0OOo0 , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1oOOOOOOOoO ) , IIiI , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1i1IiIiIi1Ii ) , IIi1iI1 , 61 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oO0ooOoO ) , O0Ooo , 61 , iiiii , O0O0OO0O0O0 , '' )
 if 77 - 77: ooO0oo0oO0 - II1Ii1iI1i . OooooO0oOO
def iIi1iIIIiIiI ( name , url , iconimage ) :
 if 62 - 62: i11iIiiIii % oOo0 . OoO000 . oOo0
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 o000ooooO0o = str ( oO0 )
 oO = re . compile ( '<tr(.+?)</tr>' ) . findall ( o000ooooO0o )
 for Ii1iIiII1ii1 in oO :
  try :
   II1i = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR red][B]' + II1i + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OO0o0oOOO0O = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1Iii , oO00OOoO00 = o0OO0o0oOOO0O . split ( ' v ' )
   ooOo0O0O0oOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iIiIIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   III1I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   I1I111iIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 3 ]
   OoOOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 4 ]
   I1iiIi111I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 5 ]
   Iiii1iIii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 6 ]
   oOoooO000O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 7 ]
   III1I11i1iIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 8 ]
   OO0oo0O0OOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 9 ]
   if 76 - 76: i11iIiiIii / OOO0O + OOO0O / II1Ii1iI1i * i1IIi11111i
   if ooOo0O0O0oOO0 == "W" :
    ooOo0O0O0oOO0 = '[COLOR lime]W[/COLOR]'
   elif ooOo0O0O0oOO0 == "D" :
    ooOo0O0O0oOO0 = '[COLOR yellow]D[/COLOR]'
   else : ooOo0O0O0oOO0 = '[COLOR red]L[/COLOR]'
   if 12 - 12: OooOoO0Oo % i11iIiiIii + oo0ooO0oOOOOo + OooOoO0Oo / oo0Ooo0
   if iIiIIi == "W" :
    iIiIIi = '[COLOR lime]W[/COLOR]'
   elif iIiIIi == "D" :
    iIiIIi = '[COLOR yellow]D[/COLOR]'
   else : iIiIIi = '[COLOR red]L[/COLOR]'
   if 53 - 53: OoO000 . OooOoO0Oo % ooO0oo0oO0 % OOO0O % oo0Ooo0
   if III1I == "W" :
    III1I = '[COLOR lime]W[/COLOR]'
   elif III1I == "D" :
    III1I = '[COLOR yellow]D[/COLOR]'
   else : III1I = '[COLOR red]L[/COLOR]'
   if 53 - 53: OooOoO0Oo
   if I1I111iIi == "W" :
    I1I111iIi = '[COLOR lime]W[/COLOR]'
   elif I1I111iIi == "D" :
    I1I111iIi = '[COLOR yellow]D[/COLOR]'
   else : I1I111iIi = '[COLOR red]L[/COLOR]'
   if 69 - 69: OOO0O . oo0ooO0oOOOOo . i1IIi11111i - i11iiII
   if OoOOOO == "W" :
    OoOOOO = '[COLOR lime]W[/COLOR]'
   elif OoOOOO == "D" :
    OoOOOO = '[COLOR yellow]D[/COLOR]'
   else : OoOOOO = '[COLOR red]L[/COLOR]'
   if 32 - 32: i111I / i1IIi11111i / ooO0oo0oO0 + i1111 . OooooO0oOO . oo0ooO0oOOOOo
   if I1iiIi111I == "W" :
    I1iiIi111I = '[COLOR lime]W[/COLOR]'
   elif I1iiIi111I == "D" :
    I1iiIi111I = '[COLOR yellow]D[/COLOR]'
   else : I1iiIi111I = '[COLOR red]L[/COLOR]'
   if 21 - 21: ooO0oo0oO0 / i1111 % II1Ii1iI1i
   if Iiii1iIii == "W" :
    Iiii1iIii = '[COLOR lime]W[/COLOR]'
   elif Iiii1iIii == "D" :
    Iiii1iIii = '[COLOR yellow]D[/COLOR]'
   else : Iiii1iIii = '[COLOR red]L[/COLOR]'
   if 8 - 8: oo + OOO0O . ooO0oo0oO0 % oooO0oo0oOOOO
   if oOoooO000O == "W" :
    oOoooO000O = '[COLOR lime]W[/COLOR]'
   elif oOoooO000O == "D" :
    oOoooO000O = '[COLOR yellow]D[/COLOR]'
   else : oOoooO000O = '[COLOR red]L[/COLOR]'
   if 43 - 43: i11iiII - i1iIIIiI1I
   if III1I11i1iIi == "W" :
    III1I11i1iIi = '[COLOR lime]W[/COLOR]'
   elif III1I11i1iIi == "D" :
    III1I11i1iIi = '[COLOR yellow]D[/COLOR]'
   else : III1I11i1iIi = '[COLOR red]L[/COLOR]'
   if 70 - 70: i1iIIIiI1I / oOo0 % iiIIiIiIi - i1IIiiiii
   if OO0oo0O0OOO0 == "W" :
    OO0oo0O0OOO0 = '[COLOR lime]W[/COLOR]'
   elif OO0oo0O0OOO0 == "D" :
    OO0oo0O0OOO0 = '[COLOR yellow]D[/COLOR]'
   else : OO0oo0O0OOO0 = '[COLOR red]L[/COLOR]'
   if 47 - 47: i1iIIIiI1I
   iI1Iii = iIii1 ( iI1Iii )
   oO00OOoO00 = iIii1 ( oO00OOoO00 )
   oO0o0OOOO ( '[COLOR mediumpurple][B]' + iI1Iii + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[B]' + ooOo0O0O0oOO0 + '  ' + iIiIIi + '  ' + III1I + '  ' + I1I111iIi + '  ' + OoOOOO + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR mediumpurple][B]' + oO00OOoO00 + ' Form Guide[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[B]' + I1iiIi111I + '  ' + Iiii1iIii + '  ' + oOoooO000O + '  ' + III1I11i1iIi + '  ' + OO0oo0O0OOO0 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  if 92 - 92: oOo0 + OOO0O % II1Ii1iI1i
def I1I1I11Ii ( name , url , iconimage ) :
 if 48 - 48: i111I + OooooO0oOO % ooO0oo0oO0
 i1oO = datetime . datetime . now ( )
 iIIi1IIi = i1oO . day
 if 11 - 11: i1IIi11111i % i1IIiiiii - oo - OooooO0oOO + oo0ooO0oOOOOo
 o0O0ooOOoO = iIIi1IIi
 if 98 - 98: i1iIIIiI1I + i1IIiiiii - oo
 oo0 = datetime . date . today ( ) + datetime . timedelta ( days = 0 )
 oOOII1i11i1iIi11 = datetime . datetime . strftime ( oo0 , '%A - %d %B %Y' )
 oo0O0oO0O0O = 'http://www.predictz.com/predictions/'
 if 79 - 79: oOo0 / OooOoO0Oo . OOO0O - i11iiII
 OOo00 = datetime . date . today ( ) + datetime . timedelta ( days = 1 )
 iiiii1ii1 = datetime . datetime . strftime ( OOo00 , '%A - %d %B %Y' )
 IiiiI1 = datetime . datetime . strftime ( OOo00 , '%d' )
 OOOo0OOo0Oo0OOo0 = 'http://www.predictz.com/predictions/tomorrow/'
 if 47 - 47: i111I % oooO0oo0oOOOO * i1iIIIiI1I . i1IIiiiii
 OooooOoO = datetime . date . today ( ) + datetime . timedelta ( days = 2 )
 i1oOOOOOOOoO = datetime . datetime . strftime ( OooooOoO , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 I1 = datetime . datetime . strftime ( OooooOoO , '%y%m%d' )
 IIiI = 'http://www.predictz.com/predictions/20' + str ( I1 )
 if 38 - 38: oooO0oo0oOOOO - OoO000 % OooOoO0Oo
 ii1iI1II11ii = datetime . date . today ( ) + datetime . timedelta ( days = 3 )
 i1i1IiIiIi1Ii = datetime . datetime . strftime ( ii1iI1II11ii , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 oO0ooOO = datetime . datetime . strftime ( ii1iI1II11ii , '%y%m%d' )
 IIi1iI1 = 'http://www.predictz.com/predictions/20' + str ( oO0ooOO )
 if 64 - 64: ooO0oo0oO0
 OO0ooo0o0 = datetime . date . today ( ) + datetime . timedelta ( days = 4 )
 oO0ooOoO = datetime . datetime . strftime ( OO0ooo0o0 , '[COLOR mediumpurple][B]%A [/COLOR]- [COLOR dodgerblue]%d %B %Y[/B][/COLOR]' )
 ooO0000o00O = datetime . datetime . strftime ( OO0ooo0o0 , '%y%m%d' )
 O0Ooo = 'http://www.predictz.com/predictions/20' + str ( ooO0000o00O )
 if 15 - 15: i11iiII + oOo0 / i11iiII / OooOoO0Oo
 if 31 - 31: iiIIiIiIi + oooO0oo0oOOOO + iiIIiIiIi . ooO0oo0oO0 + I11i1i11i1I / oo0ooO0oOOOOo
 Oo0oOOo ( '[COLOR mediumpurple][B]TODAY' + '[/B][/COLOR] - [COLOR blue][B]' + str ( oOOII1i11i1iIi11 ) + '[/B][/COLOR]' , oo0O0oO0O0O , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( '[COLOR mediumpurple][B]TOMORROW' + '[/B][/COLOR] - [COLOR blue][B]' + str ( iiiii1ii1 ) + '[/B][/COLOR]' , OOOo0OOo0Oo0OOo0 , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1oOOOOOOOoO ) , IIiI , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( i1i1IiIiIi1Ii ) , IIi1iI1 , 71 , iiiii , O0O0OO0O0O0 , '' )
 Oo0oOOo ( str ( oO0ooOoO ) , O0Ooo , 71 , iiiii , O0O0OO0O0O0 , '' )
 if 6 - 6: I11i1i11i1I % OoO000 * oo0Ooo0 / i1IIi11111i + I11i1i11i1I
def IIiI11i11 ( name , url , iconimage ) :
 if 14 - 14: i11iIiiIii
 o00OO00OoO = OOOO0OOoO0O0 ( url )
 oO0 = re . compile ( '<div class="scrolltable">(.+?)<div id="footerwrapper">' ) . findall ( o00OO00OoO )
 o000ooooO0o = str ( oO0 )
 oO = re . compile ( '<tr(.+?)</tr>' ) . findall ( o000ooooO0o )
 for Ii1iIiII1ii1 in oO :
  try :
   II1i = re . compile ( '<a href="[^"]*">(.+?) Predictions</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR red][B]' + II1i + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  except : pass
  try :
   o0OO0o0oOOO0O = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iI1Iii , oO00OOoO00 = o0OO0o0oOOO0O . split ( ' v ' )
   if 73 - 73: iiIIiIiIi + OooooO0oOO . oo
   oOOo0oo0o0o0 = re . compile ( '<div class="score">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   III1I1I = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   i1i111i1 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   OoOoOo0 = re . compile ( 'title=".+?" rel="external nofollow">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   ooOo0O0O0oOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
   iIiIIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 1 ]
   III1I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 2 ]
   I1I111iIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 3 ]
   OoOOOO = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 4 ]
   I1iiIi111I = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 5 ]
   Iiii1iIii = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 6 ]
   oOoooO000O = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 7 ]
   III1I11i1iIi = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 8 ]
   OO0oo0O0OOO0 = re . compile ( '<div class="last5.+?">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 9 ]
   if 46 - 46: oo - oo0ooO0oOOOOo / OOO0O - i111I + OooooO0oOO
   if ooOo0O0O0oOO0 == "W" :
    ooOo0O0O0oOO0 = '[COLOR lime]W[/COLOR]'
   elif ooOo0O0O0oOO0 == "D" :
    ooOo0O0O0oOO0 = '[COLOR yellow]D[/COLOR]'
   else : ooOo0O0O0oOO0 = '[COLOR red]L[/COLOR]'
   if 58 - 58: oo0ooO0oOOOOo / oo0ooO0oOOOOo + iiIIiIiIi + oo0Ooo0 - OOO0O . oOo0
   if iIiIIi == "W" :
    iIiIIi = '[COLOR lime]W[/COLOR]'
   elif iIiIIi == "D" :
    iIiIIi = '[COLOR yellow]D[/COLOR]'
   else : iIiIIi = '[COLOR red]L[/COLOR]'
   if 15 - 15: iiIIiIiIi * OOO0O % OoO000 . OOO0O . oo0Ooo0
   if III1I == "W" :
    III1I = '[COLOR lime]W[/COLOR]'
   elif III1I == "D" :
    III1I = '[COLOR yellow]D[/COLOR]'
   else : III1I = '[COLOR red]L[/COLOR]'
   if 97 - 97: OooooO0oOO
   if I1I111iIi == "W" :
    I1I111iIi = '[COLOR lime]W[/COLOR]'
   elif I1I111iIi == "D" :
    I1I111iIi = '[COLOR yellow]D[/COLOR]'
   else : I1I111iIi = '[COLOR red]L[/COLOR]'
   if 80 - 80: i1IIi11111i . i1IIiiiii
   if OoOOOO == "W" :
    OoOOOO = '[COLOR lime]W[/COLOR]'
   elif OoOOOO == "D" :
    OoOOOO = '[COLOR yellow]D[/COLOR]'
   else : OoOOOO = '[COLOR red]L[/COLOR]'
   if 47 - 47: oo0Ooo0 + iiIIiIiIi + i1111 % i11iIiiIii
   if I1iiIi111I == "W" :
    I1iiIi111I = '[COLOR lime]W[/COLOR]'
   elif I1iiIi111I == "D" :
    I1iiIi111I = '[COLOR yellow]D[/COLOR]'
   else : I1iiIi111I = '[COLOR red]L[/COLOR]'
   if 93 - 93: i11iiII % OOO0O . oooO0oo0oOOOO / i1iIIIiI1I * OooooO0oOO
   if Iiii1iIii == "W" :
    Iiii1iIii = '[COLOR lime]W[/COLOR]'
   elif Iiii1iIii == "D" :
    Iiii1iIii = '[COLOR yellow]D[/COLOR]'
   else : Iiii1iIii = '[COLOR red]L[/COLOR]'
   if 29 - 29: oo0ooO0oOOOOo
   if oOoooO000O == "W" :
    oOoooO000O = '[COLOR lime]W[/COLOR]'
   elif oOoooO000O == "D" :
    oOoooO000O = '[COLOR yellow]D[/COLOR]'
   else : oOoooO000O = '[COLOR red]L[/COLOR]'
   if 86 - 86: i1111 . OoO000
   if III1I11i1iIi == "W" :
    III1I11i1iIi = '[COLOR lime]W[/COLOR]'
   elif III1I11i1iIi == "D" :
    III1I11i1iIi = '[COLOR yellow]D[/COLOR]'
   else : III1I11i1iIi = '[COLOR red]L[/COLOR]'
   if 2 - 2: i111I
   if OO0oo0O0OOO0 == "W" :
    OO0oo0O0OOO0 = '[COLOR lime]W[/COLOR]'
   elif OO0oo0O0OOO0 == "D" :
    OO0oo0O0OOO0 = '[COLOR yellow]D[/COLOR]'
   else : OO0oo0O0OOO0 = '[COLOR red]L[/COLOR]'
   if 60 - 60: oo
   iI1Iii = iIii1 ( iI1Iii )
   oO00OOoO00 = iIii1 ( oO00OOoO00 )
   o0OO0o0oOOO0O = iIii1 ( o0OO0o0oOOO0O )
   oOOo0oo0o0o0 = iIii1 ( oOOo0oo0o0o0 )
   oO0o0OOOO ( '[COLOR blue][B]' + o0OO0o0oOOO0O + '[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]Prediction - [/COLOR][COLOR dodgerblue][B]' + oOOo0oo0o0o0 + ' [/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]' + iI1Iii + ' Form: - [/COLOR][B]' + ooOo0O0O0oOO0 + '  ' + iIiIIi + '  ' + III1I + '  ' + I1I111iIi + '  ' + OoOOOO + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]' + oO00OOoO00 + ' Form - [/COLOR][B]' + I1iiIi111I + '  ' + Iiii1iIii + '  ' + oOoooO000O + '  ' + III1I11i1iIi + '  ' + OO0oo0O0OOO0 + '[/B]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]' + iI1Iii + ' Win[/COLOR][COLOR dodgerblue][B] (' + III1I1I + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]Draw[/COLOR][COLOR dodgerblue][B] (' + i1i111i1 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '[COLOR orange]' + oO00OOoO00 + ' Win[/COLOR][COLOR dodgerblue][B] (' + OoOoOo0 + ')[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   oO0o0OOOO ( '#############################################' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
   if 81 - 81: OOO0O % i1IIiiiii
  except : pass
  if 87 - 87: ooO0oo0oO0 . i111I * OOO0O
def OOOo ( name , url , iconimage ) :
 if 74 - 74: i1IIiiiii - i111I . I11i1i11i1I
 III1Ii1i1I1 = [ ]
 O0 = [ ]
 O00OooO = [ ]
 I1IiI1iI11 = [ ]
 iIi = [ ]
 if 29 - 29: oooO0oo0oOOOO . OooOoO0Oo
 o00OO00OoO = OOOO0OOoO0O0 ( 'http://www.livescores.com' )
 oO0 = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( o00OO00OoO )
 o000ooooO0o = str ( oO0 )
 oO = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( o000ooooO0o )
 for Ii1iIiII1ii1 in oO :
  OO0o0oO0O000o = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  I1iI11iii = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   oOOo0oo0o0o0 = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except :
   oOOo0oo0o0o0 = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( Ii1iIiII1ii1 ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 78 - 78: oooO0oo0oOOOO / i1111 * oo
  if "minute" in time . lower ( ) :
   iIi . append ( '3' )
  elif "ht" in time . lower ( ) :
   iIi . append ( '3' )
  elif "ft" in time . lower ( ) :
   iIi . append ( '2' )
  else : iIi . append ( '1' )
  if 50 - 50: i111I - ooO0oo0oO0 + II1Ii1iI1i % OooOoO0Oo - ooO0oo0oO0 % oooO0oo0oOOOO
  III1Ii1i1I1 . append ( OO0o0oO0O000o )
  O0 . append ( I1iI11iii )
  O00OooO . append ( oOOo0oo0o0o0 )
  I1IiI1iI11 . append ( time )
  ooo0O0o00O = list ( zip ( iIi , III1Ii1i1I1 , O0 , O00OooO , I1IiI1iI11 ) )
  if 58 - 58: OoO000 + ooO0oo0oO0
 oO0o0OOOO ( '[COLOR dodgerblue][B]The scores will update every 10 seconds.[/B][/COLOR]' , 'url' , 998 , iiiii , O0O0OO0O0O0 , '' )
 oO0o0OOOO ( '[COLOR darkgray]######################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 65 - 65: i1111 - OooOoO0Oo % oo0ooO0oOOOOo - OOO0O * i1iIIIiI1I + i1IIiiiii
 OOOOoOOo0O0 = sorted ( ooo0O0o00O , key = lambda I1II1III11iii : int ( I1II1III11iii [ 0 ] ) , reverse = True )
 O0o0O0OO0o = 0
 OOOoOo = 0
 OOoO0oo0O = 0
 for iiI1I1iio00 , IiI1iiII1i1i , i1IiI , o0o0O00 , oOo000OOooO0O in OOOOoOOo0O0 :
  if iiI1I1iio00 == "3" :
   if O0o0O0OO0o == 0 :
    oO0o0OOOO ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    O0o0O0OO0o = 1
  elif iiI1I1iio00 == "2" :
   if OOOoOo == 0 :
    oO0o0OOOO ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    OOOoOo = 1
  elif iiI1I1iio00 == "1" :
   if OOoO0oo0O == 0 :
    oO0o0OOOO ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
    OOoO0oo0O = 1
  oOo000OOooO0O = oOo000OOooO0O . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  o0o0O00 = o0o0O00 . replace ( " " , "" )
  oO0o0OOOO ( '[COLOR red][B]' + oOo000OOooO0O + "[/B][/COLOR]- [COLOR blue]" + o0o0O00 + "[/COLOR] | [COLOR white]" + IiI1iiII1i1i + "vs" + i1IiI + '[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 , '' )
  if 44 - 44: oooO0oo0oOOOO . OooooO0oOO * i11iIiiIii % i11iIiiIii + oooO0oo0oOOOO / oOo0
def o00oOOO0Ooo ( ) :
 if 50 - 50: i1IIiiiii - i11iIiiIii + ooO0oo0oO0 / oooO0oo0oOOOO - i1IIiiiii + oo0ooO0oOOOOo
 o000ooooO0o = ''
 Iii111Ii1 = xbmc . Keyboard ( o000ooooO0o , 'Enter Search Term' )
 Iii111Ii1 . doModal ( )
 if Iii111Ii1 . isConfirmed ( ) :
  o000ooooO0o = Iii111Ii1 . getText ( )
  if len ( o000ooooO0o ) > 1 :
   i1iI11i1ii11 = o000ooooO0o + "!" + iiiii
   OOOooo0OooOoO ( "all " + o000ooooO0o , i1iI11i1ii11 , iiiii )
  else : quit ( )
  if 5 - 5: oo / i1iIIIiI1I + i11iIiiIii % oo0Ooo0
def oOo00Ooo0o0 ( name , url , iconimage ) :
 if 33 - 33: oo0Ooo0
 if url == "f4mtester" :
  xbmc . executebuiltin ( "RunAddon(plugin.video.f4mTester)" )
  quit ( )
 elif url == "f4mproxy" :
  xbmc . executebuiltin ( "RunAddon(script.video.F4mProxy)" )
  quit ( )
 else :
  xbmc . executebuiltin ( 'ActivateWindow(10025,"plugin://plugin.video.SportsDevil")' )
  quit ( )
  if 87 - 87: OOO0O / OoO000 + ooO0oo0oO0
def ii ( text ) :
 if 93 - 93: ooO0oo0oO0 + OooooO0oOO % iiIIiIiIi
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 21 - 21: oOo0
 return text
 if 6 - 6: OoO000
def iIii1 ( text ) :
 if 46 - 46: OoO000 + OooooO0oOO
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , ' ' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&nbsp;' , "" )
 if 79 - 79: i111I - OoO000 * OoO000 . OOO0O
 return text
 if 100 - 100: i1111 * oo0Ooo0 % i1IIi11111i / i11iiII
def oO0i1iI ( text ) :
 if 90 - 90: i11iiII . iiIIiIiIi . OOO0O . i1IIiiiii
 text = str ( text )
 text = text . replace ( 'ATR' , 'at the races' )
 text = text . replace ( 'British Eurosport' , 'eurosport' )
 text = text . replace ( 'Sky Sports' , 'sky sports' )
 text = text . replace ( 'sky sport ' , 'sky sports ' )
 text = text . replace ( 'skysports ' , 'sky sports ' )
 text = text . replace ( 'skysport ' , 'sky sports ' )
 text = text . replace ( 'RP Greyhound TV' , 'greyhound' )
 if 4 - 4: i1IIiiiii + OOO0O % i11iiII / i11iIiiIii
 return text
 if 74 - 74: i1111 . oooO0oo0oOOOO - i1IIi11111i + OoO000 % i11iIiiIii % OOO0O
def Oo0OO ( name , url , iconimage ) :
 if 78 - 78: i1IIiiiii + OOO0O + OoO000 - OoO000 . i11iIiiIii / oo
 I1IiiI . create ( Oo0Ooo , "[COLOR blue]Opening link...[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I1IiiI . update ( 0 )
 if 27 - 27: i1IIiiiii - oooO0oo0oOOOO % oo0Ooo0 * OooOoO0Oo . OoO000 % ooO0oo0oO0
 if "pl_type=user" in url :
  o0OOo0o0O0O = OOOO0OOoO0O0 ( url )
  url = re . compile ( '<meta property="og:video:iframe" content="(.+?)">' ) . findall ( o0OOo0o0O0O ) [ 0 ]
  if 37 - 37: i111I + oooO0oo0oOOOO - II1Ii1iI1i % iiIIiIiIi
 if not "plugin" in url :
  try :
   if not 'http' in url : url = 'http://' + url
  except :
   O00ooooo00 . ok ( Oo0Ooo , "[COLOR blue]Sorry there was a problem playing this link.[/COLOR]" , "[COLOR blue]Sportie has plenty of content to choose from :-D[/COLOR]" )
   quit ( )
   if 24 - 24: OOO0O
 name = name . replace ( '  ' , '' )
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
 else : url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
 if 94 - 94: II1Ii1iI1i * II1Ii1iI1i % i1111 + oOo0
 import urlresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  iIIi11 = urlresolver . HostedMediaFile ( url ) . resolve ( )
  o0000o0Oo = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  o0000o0Oo . setPath ( iIIi11 )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( iIIi11 , o0000o0Oo , False )
  quit ( )
 else :
  iIIi11 = url
  o0000o0Oo = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
  o0000o0Oo . setPath ( iIIi11 )
  I1IiiI . close ( )
  xbmc . Player ( ) . play ( iIIi11 , o0000o0Oo , False )
  quit ( )
  if 90 - 90: ooO0oo0oO0 * i1111
def oo0OOo0 ( ) :
 if 70 - 70: oo0ooO0oOOOOo * i1111 - iiIIiIiIi
 oOOoo0 = xbmc . getInfoLabel ( "System.BuildVersion" )
 IIIIiI11I = float ( oOOoo0 [ : 4 ] )
 if IIIIiI11I >= 11.0 and IIIIiI11I <= 11.9 :
  iiiI11iIIi1 = 'Eden'
 elif IIIIiI11I >= 12.0 and IIIIiI11I <= 12.9 :
  iiiI11iIIi1 = 'Frodo'
 elif IIIIiI11I >= 13.0 and IIIIiI11I <= 13.9 :
  iiiI11iIIi1 = 'Gotham'
 elif IIIIiI11I >= 14.0 and IIIIiI11I <= 14.9 :
  iiiI11iIIi1 = 'Helix'
 elif IIIIiI11I >= 15.0 and IIIIiI11I <= 15.9 :
  iiiI11iIIi1 = 'Isengard'
 elif IIIIiI11I >= 16.0 and IIIIiI11I <= 16.9 :
  iiiI11iIIi1 = 'Jarvis'
 elif IIIIiI11I >= 17.0 and IIIIiI11I <= 17.9 :
  iiiI11iIIi1 = 'Krypton'
 else : iiiI11iIIi1 = "Decline"
 if 72 - 72: i1iIIIiI1I * oOo0
 return iiiI11iIIi1
 if 67 - 67: II1Ii1iI1i
def OOOO0OOoO0O0 ( url ) :
 if 5 - 5: i1111 . i111I
 oOOOo = urllib2 . Request ( url )
 oOOOo . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 iIiI1 = urllib2 . urlopen ( oOOOo )
 o00OO00OoO = iIiI1 . read ( )
 iIiI1 . close ( )
 o00OO00OoO = o00OO00OoO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return o00OO00OoO
 if 31 - 31: OOO0O + OOO0O . i11iIiiIii / iiIIiIiIi % oo0Ooo0 / OOO0O
def IIIii1II1II ( url ) :
 if 29 - 29: i11iiII * i11iiII . oo * oo0Ooo0 % ooO0oo0oO0 * i11iiII
 oOOOo = urllib2 . Request ( url )
 oOOOo . add_header ( 'User-Agent' , base64 . b64decode ( b'VGhlV2l6YXJkSXNIZXJl' ) )
 iIiI1 = urllib2 . urlopen ( oOOOo )
 o00OO00OoO = iIiI1 . read ( )
 iIiI1 . close ( )
 return o00OO00OoO
 if 31 - 31: oo * oooO0oo0oOOOO . OooooO0oOO
def OooOOOOoO00OoOO ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 59 - 59: i1111 * i11iIiiIii
 if 54 - 54: oooO0oo0oOOOO % i111I - i1IIi11111i
 if 61 - 61: I11i1i11i1I * OoO000 . I11i1i11i1I + I11i1i11i1I / OoO000 * oooO0oo0oOOOO
 if 73 - 73: i1iIIIiI1I * i1iIIIiI1I / iiIIiIiIi
 if 43 - 43: i11iiII . II1Ii1iI1i . OoO000 + oooO0oo0oOOOO * i1IIiiiii * oooO0oo0oOOOO
def II11ii ( ) :
 if 39 - 39: i1iIIIiI1I . i1IIi11111i * OOO0O - i11iIiiIii
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 1 - 1: i1iIIIiI1I * OOO0O
 if os . path . exists ( IiIi11iIIi1Ii ) == True :
  for OO0ooo0 , II1II1iI , Ooo in os . walk ( IiIi11iIIi1Ii ) :
   ooO = 0
   ooO += len ( Ooo )
   if ooO > 0 :
    for OooO0 in Ooo :
     try :
      if ( OooO0 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( OO0ooo0 , OooO0 ) )
     except :
      pass
    for oO0O0 in II1II1iI :
     try :
      shutil . rmtree ( os . path . join ( OO0ooo0 , oO0O0 ) )
     except :
      pass
      if 19 - 19: i1IIiiiii
   else :
    pass
    if 55 - 55: oOo0 % oOo0 / oooO0oo0oOOOO % i1iIIIiI1I - oo0ooO0oOOOOo . I11i1i11i1I
 if os . path . exists ( Oo0O ) == True :
  for OO0ooo0 , II1II1iI , Ooo in os . walk ( Oo0O ) :
   ooO = 0
   ooO += len ( Ooo )
   if ooO > 0 :
    for OooO0 in Ooo :
     try :
      if ( OooO0 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( OO0ooo0 , OooO0 ) )
     except :
      pass
    for oO0O0 in II1II1iI :
     try :
      shutil . rmtree ( os . path . join ( OO0ooo0 , oO0O0 ) )
     except :
      pass
      if 49 - 49: ooO0oo0oO0 * II1Ii1iI1i . i111I
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  OOOO0oOo00O = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 32 - 32: OoO000 % i1IIiiiii - i1IIi11111i
  for OO0ooo0 , II1II1iI , Ooo in os . walk ( OOOO0oOo00O ) :
   ooO = 0
   ooO += len ( Ooo )
   if 71 - 71: i1iIIIiI1I
   if ooO > 0 :
    for OooO0 in Ooo :
     os . unlink ( os . path . join ( OO0ooo0 , OooO0 ) )
    for oO0O0 in II1II1iI :
     shutil . rmtree ( os . path . join ( OO0ooo0 , oO0O0 ) )
     if 23 - 23: II1Ii1iI1i . ooO0oo0oO0 . oOo0 . oooO0oo0oOOOO % i1IIiiiii % i11iIiiIii
   else :
    pass
  Iiiii111 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 93 - 93: i111I * I11i1i11i1I
  for OO0ooo0 , II1II1iI , Ooo in os . walk ( Iiiii111 ) :
   ooO = 0
   ooO += len ( Ooo )
   if 10 - 10: OooOoO0Oo * i111I + oo0Ooo0 - i11iiII / i11iiII . i11iIiiIii
   if ooO > 0 :
    for OooO0 in Ooo :
     os . unlink ( os . path . join ( OO0ooo0 , OooO0 ) )
    for oO0O0 in II1II1iI :
     shutil . rmtree ( os . path . join ( OO0ooo0 , oO0O0 ) )
     if 22 - 22: OooOoO0Oo / oo0ooO0oOOOOo
   else :
    pass
    if 98 - 98: II1Ii1iI1i
 O0ooOooooO = iI ( )
 if 51 - 51: i11iiII + iiIIiIiIi + I11i1i11i1I / II1Ii1iI1i + II1Ii1iI1i
 for Iii in O0ooOooooO :
  OooooOo0 = xbmc . translatePath ( Iii . path )
  if os . path . exists ( OooooOo0 ) == True :
   for OO0ooo0 , II1II1iI , Ooo in os . walk ( OooooOo0 ) :
    ooO = 0
    ooO += len ( Ooo )
    if ooO > 0 :
     for OooO0 in Ooo :
      os . unlink ( os . path . join ( OO0ooo0 , OooO0 ) )
     for oO0O0 in II1II1iI :
      shutil . rmtree ( os . path . join ( OO0ooo0 , oO0O0 ) )
      if 45 - 45: OoO000 / oooO0oo0oOOOO / OOO0O * oOo0
    else :
     pass
     if 18 - 18: ooO0oo0oO0 + oOo0 + ooO0oo0oO0 . i11iiII + OooOoO0Oo . iiIIiIiIi
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 O00ooooo00 . ok ( Oo0Ooo , "The Sportie menu has been reloaded." )
 if 7 - 7: i11iiII + ooO0oo0oO0 * oo0Ooo0 * oo0Ooo0 / i1111 - i1IIiiiii
def oOOOo0o ( ) :
 iiiii11I1 = [ ]
 Ii1OOOo = sys . argv [ 2 ]
 if len ( Ii1OOOo ) >= 2 :
  IiI1i = sys . argv [ 2 ]
  I1iI1IiI = IiI1i . replace ( '?' , '' )
  if ( IiI1i [ len ( IiI1i ) - 1 ] == '/' ) :
   IiI1i = IiI1i [ 0 : len ( IiI1i ) - 2 ]
  i1i1Ii1I = I1iI1IiI . split ( '&' )
  iiiii11I1 = { }
  for OO in range ( len ( i1i1Ii1I ) ) :
   I1II1III1 = { }
   I1II1III1 = i1i1Ii1I [ OO ] . split ( '=' )
   if ( len ( I1II1III1 ) ) == 2 :
    iiiii11I1 [ I1II1III1 [ 0 ] ] = I1II1III1 [ 1 ]
 return iiiii11I1
 if 62 - 62: i1IIi11111i * i11iIiiIii . i1iIIIiI1I
def Oo0oOOo ( name , url , mode , iconimage , fanart , description = '' ) :
 if 35 - 35: OoO000 . oooO0oo0oOOOO + I11i1i11i1I + oOo0 + II1Ii1iI1i
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 OooOooO0O0o0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OOO0o0 = True
 o0000o0Oo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 o0000o0Oo . setProperty ( "fanart_Image" , fanart )
 o0000o0Oo . setProperty ( "icon_Image" , iconimage )
 OOO0o0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OooOooO0O0o0 , listitem = o0000o0Oo , isFolder = True )
 return OOO0o0
 if 34 - 34: i1IIi11111i % I11i1i11i1I - OOO0O + i1iIIIiI1I
def oO0o0OOOO ( name , url , mode , iconimage , fanart , description = '' ) :
 if 79 - 79: i1111 - iiIIiIiIi . II1Ii1iI1i + oooO0oo0oOOOO % oooO0oo0oOOOO * i1IIi11111i
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 OooOooO0O0o0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 OOO0o0 = True
 o0000o0Oo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 o0000o0Oo . setProperty ( "fanart_Image" , fanart )
 o0000o0Oo . setProperty ( "icon_Image" , iconimage )
 OOO0o0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OooOooO0O0o0 , listitem = o0000o0Oo , isFolder = False )
 return OOO0o0
 if 7 - 7: II1Ii1iI1i + oOo0 % i1iIIIiI1I / oo0ooO0oOOOOo + II1Ii1iI1i
IiI1i = oOOOo0o ( ) ; i1iI11i1ii11 = None ; i1OOO = None ; I1ii11I = None ; II1II1IIII = None ; iI1iIIiiii = None ; OooOoooOo = None
try : II1II1IIII = urllib . unquote_plus ( IiI1i [ "site" ] )
except : pass
try : i1iI11i1ii11 = urllib . unquote_plus ( IiI1i [ "url" ] )
except : pass
try : i1OOO = urllib . unquote_plus ( IiI1i [ "name" ] )
except : pass
try : I1ii11I = int ( IiI1i [ "mode" ] )
except : pass
try : iI1iIIiiii = urllib . unquote_plus ( IiI1i [ "iconimage" ] )
except : pass
try : OooOoooOo = urllib . unquote_plus ( IiI1i [ "fanart" ] )
except : pass
if 37 - 37: i111I
if I1ii11I == None or i1iI11i1ii11 == None or len ( i1iI11i1ii11 ) < 1 : i11 ( )
elif I1ii11I == 1 : II1iiiIi1 ( i1OOO , i1iI11i1ii11 )
elif I1ii11I == 2 : Oo0OO ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 3 : ooO0OO ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 4 : PLAYSD ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 7 : iiI11ii1I1 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 8 : Iii11iI1i ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 9 : AUTO_UPDATER ( i1OOO )
elif I1ii11I == 10 : ooi1II1I ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 11 : iiIIi ( )
elif I1ii11I == 12 : O00oO ( i1iI11i1ii11 )
elif I1ii11I == 19 : OOO00O0oOOo ( i1iI11i1ii11 )
elif I1ii11I == 20 : OOOooo0OooOoO ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 21 : IIi11IIiIii1 ( i1iI11i1ii11 )
elif I1ii11I == 22 : IiIII1i1i ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 23 : oo0OOo0O ( )
elif I1ii11I == 24 : o00o0 ( )
elif I1ii11I == 25 : III11I1 ( )
elif I1ii11I == 26 : o0oooO ( )
elif I1ii11I == 30 : I1iiiiIii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 40 : IIIIIiII1 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 41 : IiiIiiIi ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 50 : Oo0oOooOoOo ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 51 : OOO000 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 60 : OOO0o0OO0OO ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 61 : iIi1iIIIiIiI ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 70 : I1I1I11Ii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 71 : IIiI11i11 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 80 : OOOo ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 90 : IiiiiI1i1Iii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 91 : ooo00Ooo ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 95 : O0o0O0 ( )
elif I1ii11I == 96 : O00OoOO0oo0 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 97 : oOOO0oo0 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 100 : o00oOOO0Ooo ( )
elif I1ii11I == 500 : II11ii ( )
elif I1ii11I == 201 : oOoOO ( )
elif I1ii11I == 202 : OOOOO0O00 ( i1iI11i1ii11 )
elif I1ii11I == 203 : o0o0O00oo0 ( i1iI11i1ii11 )
elif I1ii11I == 204 : ooOOo00O00Oo ( i1iI11i1ii11 )
elif I1ii11I == 205 : oo000 ( i1iI11i1ii11 )
elif I1ii11I == 206 : Oo0ooo ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 210 : I1Ii1111iIi ( i1iI11i1ii11 )
elif I1ii11I == 220 : iiI1I1ii ( i1iI11i1ii11 )
elif I1ii11I == 221 : iIiii ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 800 : oOo00Ooo0o0 ( i1OOO , i1iI11i1ii11 , iI1iIIiiii )
elif I1ii11I == 998 : xbmc . executebuiltin ( "Container.Refresh" )
if 69 - 69: i1IIi11111i + i1iIIIiI1I
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
if I1ii11I == 80 :
 xbmc . sleep ( 10000 )
 xbmc . executebuiltin ( 'Container.Refresh' )