import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , urlresolver , liveresolver
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echoplayer'
Oo0Ooo = '[COLOR yellowgreen]ECHO Player[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmcgui . Dialog ( )
II1 = xbmcgui . DialogProgress ( )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'history.xml' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home' ) )
if 65 - 65: i1iIi11iIIi1I
def Oo ( ) :
 if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11i / Ii1I
 if not os . path . exists ( I1IiiI ) :
  os . makedirs ( I1IiiI )
  if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 if not os . path . isfile ( O00ooooo00 ) :
  O0oOO0o0 = open ( O00ooooo00 , 'w' )
  O0oOO0o0 . write ( '#START OF FILE#' )
  O0oOO0o0 . close ( )
  if 9 - 9: o0o - OOO0o0o
 Ii1iI ( '[COLOR yellowgreen]Play URL.............[/COLOR]' , 'none' , 1 , iiiii , O0O0OO0O0O0 )
 Ii1iI ( '[COLOR yellowgreen]Play Local File.............[/COLOR]' , 'none' , 4 , iiiii , O0O0OO0O0O0 )
 OoI1Ii11I1Ii1i ( '[COLOR dodgerblue]Supported: TS, M3U, M3U8, MP4, AVI, MKV, MP3 and MORE![/COLOR]' , 'none' , 999 , iiiii , O0O0OO0O0O0 )
 OoI1Ii11I1Ii1i ( '[COLOR white]################HISTORY###################[/COLOR]' , 'none' , 999 , iiiii , O0O0OO0O0O0 )
 OoI1Ii11I1Ii1i ( '[COLOR red]Clear History[/COLOR]' , 'none' , 3 , iiiii , O0O0OO0O0O0 )
 if 67 - 67: iiI1iIiI . ooo0Oo0 * i1OOooo0000ooo - oo00000o0 % O0o0o00o0Oo0 / ii1IiI1i
 O0oOO0o0 = open ( O00ooooo00 , mode = 'r' ) ; i11iI = O0oOO0o0 . read ( ) ; O0oOO0o0 . close ( )
 i11iI = i11iI . replace ( '\n' , '' )
 I1i1i1ii = re . compile ( '<link>(.+?)</link>' ) . findall ( i11iI )
 for IIIII in I1i1i1ii :
  OoI1Ii11I1Ii1i ( '[COLOR powderblue]' + IIIII + '[/COLOR]' , IIIII , 1 , iiiii , O0O0OO0O0O0 )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 26 - 26: oo00000o0 . OOO0o0o - o0o % i1iIi11iIIi1I + o0o
def i1iiIIiiI111 ( ) :
 if 62 - 62: i11iIiiIii - OOooOOo
 IIIII = ooo0OO . browse ( 1 , Oo0Ooo , 'files' , '' , False , False , I11i11Ii )
 if 43 - 43: IiII - ii1IiI1i + oo00000o0 + iiI1iIiI
 if '.m3u' in IIIII :
  if not 'm3u8' in IIIII :
   iII111ii ( IIIII )
  else :
   i1iIIi1 ( IIIII , IIIII , iiiii )
 else :
  i1iIIi1 ( IIIII , IIIII , iiiii )
  if 50 - 50: i11iIiiIii - iiI1iIiI
def oo0Ooo0 ( ) :
 if 46 - 46: O0o0o00o0Oo0 % O0o0o00o0Oo0 - o00O0oo * I1Ii111 % ooo0Oo0
 if os . path . isfile ( O00ooooo00 ) :
  OOooO0OOoo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to clear all stored history?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[B][COLOR red]NO[/COLOR][/B]' )
  if OOooO0OOoo == 1 :
   os . remove ( O00ooooo00 )
   O0oOO0o0 = open ( O00ooooo00 , 'w' )
   O0oOO0o0 . write ( '#START OF FILE#' )
   O0oOO0o0 . close ( )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 29 - 29: I1Ii111 / o0
def IiIIIiI1I1 ( url ) :
 if 86 - 86: i11iIiiIii + iiI1iIiI + O0o0o00o0Oo0 * OOO0o0o + I1Ii111
 if url == "none" :
  if 61 - 61: iII111i / i11iIiiIii
  IiIiIi = ''
  II = xbmc . Keyboard ( IiIiIi , 'Enter The URL To Play' )
  II . doModal ( )
  if II . isConfirmed ( ) :
   IiIiIi = II . getText ( ) . replace ( ' ' , '' )
   if not ( IiIiIi == "" ) or ( IiIiIi == " " ) :
    iI = 0
    iI11iiiI1II = [ 'http' , 'rmtp' , 'plugin' ]
    if 79 - 79: oo00000o0 % i11iIiiIii / o0 . o0o
    for type in iI11iiiI1II :
     if type in IiIiIi :
      iI = 1
      if 57 - 57: iiI1iIiI % i1
    if not iI == 1 :
     ooo0OO . ok ( Oo0Ooo , "Unsupported URL or File Type detected." )
     quit ( )
    else : url = IiIiIi
   else : quit ( )
   if 61 - 61: ooo0Oo0 . o0 * I11i . O0o0o00o0Oo0 % Ii1I
 if '.m3u' in url :
  if not 'm3u8' in url :
   iII111ii ( url )
  else :
   i1iIIi1 ( oOo00Oo00O , url , iI11i1I1 )
 else :
  i1iIIi1 ( oOo00Oo00O , url , iI11i1I1 )
  if 71 - 71: O0o0o00o0Oo0 % ooo0Oo0 / I1Ii111
def iII111ii ( url ) :
 if 49 - 49: OOooOOo % ooo0Oo0 * i1iIi11iIIi1I
 oOOo0oo = url
 list = o0oo0o0O00OO ( url )
 if 80 - 80: ii1IiI1i
 oOOO0o0o = open ( O00ooooo00 ) . read ( )
 iiI1 = oOOO0o0o . replace ( '<link>' + url + '</link>' , '' )
 O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
 O0oOO0o0 . write ( str ( iiI1 ) )
 O0oOO0o0 . close ( )
 oOOO0o0o = open ( O00ooooo00 ) . read ( )
 iiI1 = oOOO0o0o . replace ( '#START OF FILE#' , '#START OF FILE#\n<link>' + url + '</link>' )
 O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
 O0oOO0o0 . write ( str ( iiI1 ) )
 O0oOO0o0 . close ( )
 if 19 - 19: OOO0o0o + O0o0o00o0Oo0
 for ooo in list :
  oOo00Oo00O = ii1I1i1I ( ooo [ "display_name" ] )
  url = ii1I1i1I ( ooo [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  OOoo0O0 = url . split ( '.' ) [ - 1 ]
  try :
   OOoo0O0 = OOoo0O0 . split ( '?' ) [ 0 ]
  except : pass
  try :
   OOoo0O0 = OOoo0O0 . split ( '%' ) [ 0 ]
  except : pass
  OoI1Ii11I1Ii1i ( '[COLOR yellowgreen]' + OOoo0O0 . upper ( ) + '[/COLOR] - ' + oOo00Oo00O , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 41 - 41: o00O0oo
def o0oo0o0O00OO ( url ) :
 if 6 - 6: ooOoO0o
 if not 'http' in url :
  I1I = open ( url ) . read ( )
 else :
  try :
   I1I = oOO00oOO ( url )
  except :
   ooo0OO . ok ( Oo0Ooo , "There was an error opening the url. Please try another link." )
   quit ( )
 I1I = I1I . replace ( '#AAASTREAM:' , '#A:' )
 I1I = I1I . replace ( '#EXTINF:' , '#A:' )
 OoOo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( I1I )
 iIo00O = [ ]
 for OOO0OOO00oo , Iii111II , url in OoOo :
  iiii11I = { "params" : OOO0OOO00oo , "display_name" : Iii111II , "url" : url }
  iIo00O . append ( iiii11I )
 list = [ ]
 for ooo in iIo00O :
  iiii11I = { "display_name" : ooo [ "display_name" ] , "url" : ooo [ "url" ] }
  OoOo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooo [ "params" ] )
  for Ooo0OO0oOO , ii11i1 in OoOo :
   iiii11I [ Ooo0OO0oOO . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii11i1 . strip ( )
  list . append ( iiii11I )
  if 29 - 29: ooOoO0o % I11i + O0o0o00o0Oo0 / I1Ii111 + o0o * I1Ii111
 return list
 if 42 - 42: iiI1iIiI + o00O0oo
def ii1I1i1I ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 76 - 76: oo00000o0 - iII111i
def i1iIIi1 ( name , url , iconimage ) :
 if 70 - 70: O0o0o00o0Oo0
 II1 . create ( Oo0Ooo , "Opening......." , "Please Wait..." )
 if "m3u8" in url :
  oOOO0o0o = open ( O00ooooo00 ) . read ( )
  iiI1 = oOOO0o0o . replace ( '<link>' + url + '</link>' , '' )
  O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
  O0oOO0o0 . write ( str ( iiI1 ) )
  O0oOO0o0 . close ( )
  oOOO0o0o = open ( O00ooooo00 ) . read ( )
  iiI1 = oOOO0o0o . replace ( '#START OF FILE#' , '#START OF FILE#\n<link>' + url + '</link>' )
  O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
  O0oOO0o0 . write ( str ( iiI1 ) )
  O0oOO0o0 . close ( )
 elif not "m3u" in url :
  oOOO0o0o = open ( O00ooooo00 ) . read ( )
  iiI1 = oOOO0o0o . replace ( '<link>' + url + '</link>' , '' )
  O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
  O0oOO0o0 . write ( str ( iiI1 ) )
  O0oOO0o0 . close ( )
  oOOO0o0o = open ( O00ooooo00 ) . read ( )
  iiI1 = oOOO0o0o . replace ( '#START OF FILE#' , '#START OF FILE#\n<link>' + url + '</link>' )
  O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
  O0oOO0o0 . write ( str ( iiI1 ) )
  O0oOO0o0 . close ( )
  if 61 - 61: ooOoO0o . ooOoO0o
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url
  elif '.mpegts' in url :
   url = url . replace ( '.mpegts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url
   if 10 - 10: IiII * ooo0Oo0 . OOO0o0o + OOooOOo - O0o0o00o0Oo0 * ii1IiI1i
 if "plugin://" in url :
  if not os . path . exists ( IIi1IiiiI1Ii ) :
   ooo0OO . ok ( '[COLOR red]F4M TESTER NOT INSTALLED![/COLOR]' , "This link requires F4M Tester be installed. Please install F4M from the Shani Repo at http://fusion.tvaddons.ag" )
   quit ( )
   if 56 - 56: I1Ii111 * i1OOooo0000ooo * OOooOOo
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  oO0ooO0OoOOOO = urlresolver . HostedMediaFile ( url ) . resolve ( )
  i1Ii = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  i1Ii . setPath ( oO0ooO0OoOOOO )
  II1 . close ( )
  xbmc . executebuiltin ( "Container.Refresh" )
  xbmc . Player ( ) . play ( oO0ooO0OoOOOO , i1Ii , False )
  quit ( )
 elif liveresolver . isValid ( url ) == True :
  oO0ooO0OoOOOO = liveresolver . resolve ( url )
  i1Ii = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  i1Ii . setPath ( oO0ooO0OoOOOO )
  II1 . close ( )
  xbmc . executebuiltin ( "Container.Refresh" )
  xbmc . Player ( ) . play ( oO0ooO0OoOOOO , i1Ii , False )
  quit ( )
 else :
  if 'http' in url :
   url = url + '|User-Agent=Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30'
  i1Ii = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  II1 . close ( )
  xbmc . executebuiltin ( "Container.Refresh" )
  xbmc . Player ( ) . play ( url , i1Ii , False )
  quit ( )
  if 78 - 78: OOO0o0o
def oOO00oOO ( url ) :
 if 71 - 71: o0o + O0o0o00o0Oo0 % i11iIiiIii + ooOoO0o - i1OOooo0000ooo
 oO0OOoO0 = urllib2 . Request ( url )
 oO0OOoO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 I1I = urllib2 . urlopen ( oO0OOoO0 )
 I111Ii111 = I1I . read ( )
 I1I . close ( )
 return I111Ii111
 if 4 - 4: o00O0oo
def OoI1Ii11I1Ii1i ( name , url , mode , iconimage , fanart , description = '' ) :
 if 93 - 93: iII111i % o00O0oo . iII111i * oo00000o0 % iiI1iIiI . OOooOOo
 i1Ii = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 i1Ii . setProperty ( 'fanart_image' , fanart )
 iI1ii1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart )
 oooo000 = True
 oooo000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1ii1Ii , listitem = i1Ii , isFolder = False )
 return oooo000
 if 16 - 16: ooOoO0o + iII111i - OOooOOo
def Ii1iI ( name , url , mode , iconimage , fanart , description = '' ) :
 iI1ii1Ii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 oooo000 = True
 i1Ii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1Ii . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 i1Ii . setProperty ( 'fanart_image' , fanart )
 oooo000 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1ii1Ii , listitem = i1Ii , isFolder = True )
 return oooo000
 if 85 - 85: IiII + ii1IiI1i
def Oo0OoO00oOO0o ( ) :
 OOO00O = [ ]
 OOoOO0oo0ooO = sys . argv [ 2 ]
 if len ( OOoOO0oo0ooO ) >= 2 :
  OOO0OOO00oo = sys . argv [ 2 ]
  O0o0O00Oo0o0 = OOO0OOO00oo . replace ( '?' , '' )
  if ( OOO0OOO00oo [ len ( OOO0OOO00oo ) - 1 ] == '/' ) :
   OOO0OOO00oo = OOO0OOO00oo [ 0 : len ( OOO0OOO00oo ) - 2 ]
  O00O0oOO00O00 = O0o0O00Oo0o0 . split ( '&' )
  OOO00O = { }
  for i1Oo00 in range ( len ( O00O0oOO00O00 ) ) :
   i1i = { }
   i1i = O00O0oOO00O00 [ i1Oo00 ] . split ( '=' )
   if ( len ( i1i ) ) == 2 :
    OOO00O [ i1i [ 0 ] ] = i1i [ 1 ]
    if 50 - 50: i1OOooo0000ooo
 return OOO00O
 if 14 - 14: OOO0o0o % iII111i * OOO0o0o
OOO0OOO00oo = Oo0OoO00oOO0o ( ) ; IIIII = None ; oOo00Oo00O = None ; iII = None ; oO00o0 = None ; iI11i1I1 = None
try : oO00o0 = urllib . unquote_plus ( OOO0OOO00oo [ "site" ] )
except : pass
try : IIIII = urllib . unquote_plus ( OOO0OOO00oo [ "url" ] )
except : pass
try : oOo00Oo00O = urllib . unquote_plus ( OOO0OOO00oo [ "name" ] )
except : pass
try : iII = int ( OOO0OOO00oo [ "mode" ] )
except : pass
try : iI11i1I1 = urllib . unquote_plus ( OOO0OOO00oo [ "iconimage" ] )
except : pass
try : O0O0OO0O0O0 = urllib . unquote_plus ( OOO0OOO00oo [ "fanart" ] )
except : pass
if 55 - 55: Ii1I + o0 / IiII * o00O0oo - i11iIiiIii - iiI1iIiI
if iII == None or IIIII == None or len ( IIIII ) < 1 : Oo ( )
elif iII == 1 : IiIIIiI1I1 ( IIIII )
elif iII == 2 : i1iIIi1 ( oOo00Oo00O , IIIII , iI11i1I1 )
elif iII == 3 : oo0Ooo0 ( )
elif iII == 4 : i1iiIIiiI111 ( )
if 25 - 25: ooOoO0o
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )