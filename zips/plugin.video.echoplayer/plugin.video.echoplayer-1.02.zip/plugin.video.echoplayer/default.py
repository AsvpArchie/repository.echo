import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , urlresolver , liveresolver
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echoplayer'
Oo0Ooo = '[COLOR yellowgreen]ECHO Player[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmcgui . Dialog ( )
II1 = xbmcgui . DialogProgress ( )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'history.xml' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home' ) )
if 65 - 65: i1iIi11iIIi1I
def Oo ( ) :
 if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11i / Ii1I
 if not os . path . exists ( I1IiiI ) :
  os . makedirs ( I1IiiI )
  if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 if not os . path . isfile ( O00ooooo00 ) :
  O0oOO0o0 = open ( O00ooooo00 , 'w' )
  O0oOO0o0 . write ( '#START OF FILE#' )
  O0oOO0o0 . close ( )
  if 9 - 9: o0o - OOO0o0o
 Ii1iI ( '[COLOR yellowgreen]Play URL.............[/COLOR]' , 'none' , 1 , iiiii , O0O0OO0O0O0 )
 Ii1iI ( '[COLOR yellowgreen]Play Local File.............[/COLOR]' , 'none' , 4 , iiiii , O0O0OO0O0O0 )
 OoI1Ii11I1Ii1i ( '[COLOR dodgerblue]Supported: TS, M3U, M3U8, MP4, AVI, MKV, MP3 and MORE![/COLOR]' , 'none' , 999 , iiiii , O0O0OO0O0O0 )
 OoI1Ii11I1Ii1i ( '[COLOR white]################HISTORY###################[/COLOR]' , 'none' , 999 , iiiii , O0O0OO0O0O0 )
 OoI1Ii11I1Ii1i ( '[COLOR red]Clear History[/COLOR]' , 'none' , 3 , iiiii , O0O0OO0O0O0 )
 if 67 - 67: iiI1iIiI . ooo0Oo0 * i1OOooo0000ooo - oo00000o0 % O0o0o00o0Oo0 / ii1IiI1i
 O0oOO0o0 = open ( O00ooooo00 , mode = 'r' ) ; i11iI = O0oOO0o0 . read ( ) ; O0oOO0o0 . close ( )
 i11iI = i11iI . replace ( '\n' , '' )
 I1i1i1ii = re . compile ( '<link>(.+?)</link>' ) . findall ( i11iI )
 for IIIII in I1i1i1ii :
  OoI1Ii11I1Ii1i ( '[COLOR powderblue]' + IIIII + '[/COLOR]' , IIIII , 1 , iiiii , O0O0OO0O0O0 )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 26 - 26: oo00000o0 . OOO0o0o - o0o % i1iIi11iIIi1I + o0o
def i1iiIIiiI111 ( ) :
 if 62 - 62: i11iIiiIii - OOooOOo
 IIIII = ooo0OO . browse ( 1 , Oo0Ooo , 'files' , '' , False , False , I11i11Ii )
 if 43 - 43: IiII - ii1IiI1i + oo00000o0 + iiI1iIiI
 if '.m3u' in IIIII :
  if not 'm3u8' in IIIII :
   iII111ii ( IIIII )
  else :
   i1iIIi1 ( IIIII , IIIII , iiiii )
 else :
  i1iIIi1 ( IIIII , IIIII , iiiii )
  if 50 - 50: i11iIiiIii - iiI1iIiI
def oo0Ooo0 ( ) :
 if 46 - 46: O0o0o00o0Oo0 % O0o0o00o0Oo0 - o00O0oo * I1Ii111 % ooo0Oo0
 if os . path . isfile ( O00ooooo00 ) :
  OOooO0OOoo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to clear all stored history?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[B][COLOR red]NO[/COLOR][/B]' )
  if OOooO0OOoo == 1 :
   os . remove ( O00ooooo00 )
   O0oOO0o0 = open ( O00ooooo00 , 'w' )
   O0oOO0o0 . write ( '#START OF FILE#' )
   O0oOO0o0 . close ( )
 xbmc . executebuiltin ( "Container.Refresh" )
 if 29 - 29: I1Ii111 / o0
def IiIIIiI1I1 ( url ) :
 if 86 - 86: i11iIiiIii + iiI1iIiI + O0o0o00o0Oo0 * OOO0o0o + I1Ii111
 if url == "none" :
  if 61 - 61: iII111i / i11iIiiIii
  IiIiIi = ''
  II = xbmc . Keyboard ( IiIiIi , 'Enter The URL To Play' )
  II . doModal ( )
  if II . isConfirmed ( ) :
   IiIiIi = II . getText ( ) . replace ( ' ' , '' )
   if not ( IiIiIi == "" ) or ( IiIiIi == " " ) :
    if not ( 'http://' ) or ( 'https://' ) in IiIiIi :
     url = "http://" + IiIiIi
    else : url = IiIiIi
   else : quit ( )
   if 14 - 14: Ii1I . I11i / iiI1iIiI
 if '.m3u' in url :
  if not 'm3u8' in url :
   iII111ii ( url )
  else :
   i1iIIi1 ( IiiiI1II1I1 , url , oo )
 else :
  i1iIIi1 ( IiiiI1II1I1 , url , oo )
  if 13 - 13: ii1IiI1i - iiI1iIiI % o00O0oo / o0 % ooo0Oo0
def iII111ii ( url ) :
 if 97 - 97: i11iIiiIii
 II1i1Ii11Ii11 = url
 list = iII11i ( url )
 if 97 - 97: OOO0o0o % OOO0o0o + OOooOOo * ooo0Oo0
 o0o00o0 = open ( O00ooooo00 ) . read ( )
 iIi1ii1I1 = o0o00o0 . replace ( '<link>' + url + '</link>' , '' )
 O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
 O0oOO0o0 . write ( str ( iIi1ii1I1 ) )
 O0oOO0o0 . close ( )
 o0o00o0 = open ( O00ooooo00 ) . read ( )
 iIi1ii1I1 = o0o00o0 . replace ( '#START OF FILE#' , '#START OF FILE#\n<link>' + url + '</link>' )
 O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
 O0oOO0o0 . write ( str ( iIi1ii1I1 ) )
 O0oOO0o0 . close ( )
 if 71 - 71: oo00000o0 . i1iIi11iIIi1I
 for o0OO0oo0oOO in list :
  IiiiI1II1I1 = oo0oooooO0 ( o0OO0oo0oOO [ "display_name" ] )
  url = oo0oooooO0 ( o0OO0oo0oOO [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  i11Iiii = url . split ( '.' ) [ - 1 ]
  try :
   i11Iiii = i11Iiii . split ( '?' ) [ 0 ]
  except : pass
  try :
   i11Iiii = i11Iiii . split ( '%' ) [ 0 ]
  except : pass
  OoI1Ii11I1Ii1i ( '[COLOR yellowgreen]' + i11Iiii . upper ( ) + '[/COLOR] - ' + IiiiI1II1I1 , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 23 - 23: I1Ii111 . OOooOOo
def iII11i ( url ) :
 if 98 - 98: o0 % IiII * ooOoO0o * IiII
 if not 'http' in url :
  i1IiIiiI = open ( url ) . read ( )
 else :
  try :
   i1IiIiiI = I1I ( url )
  except :
   ooo0OO . ok ( Oo0Ooo , "There was an error opening the url. Please try another link." )
   quit ( )
 i1IiIiiI = i1IiIiiI . replace ( '#AAASTREAM:' , '#A:' )
 i1IiIiiI = i1IiIiiI . replace ( '#EXTINF:' , '#A:' )
 oOO00oOO = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i1IiIiiI )
 OoOo = [ ]
 for iI , o00O , url in oOO00oOO :
  OOO0OOO00oo = { "params" : iI , "display_name" : o00O , "url" : url }
  OoOo . append ( OOO0OOO00oo )
 list = [ ]
 for o0OO0oo0oOO in OoOo :
  OOO0OOO00oo = { "display_name" : o0OO0oo0oOO [ "display_name" ] , "url" : o0OO0oo0oOO [ "url" ] }
  oOO00oOO = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0OO0oo0oOO [ "params" ] )
  for Iii111II , iiii11I in oOO00oOO :
   OOO0OOO00oo [ Iii111II . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iiii11I . strip ( )
  list . append ( OOO0OOO00oo )
  if 96 - 96: OOooOOo % iiI1iIiI . o0o + i1 * o00O0oo - IiII
 return list
 if 10 - 10: o0o / I11i * o0o
def oo0oooooO0 ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 29 - 29: ooOoO0o % I11i + O0o0o00o0Oo0 / I1Ii111 + o0o * I1Ii111
def i1iIIi1 ( name , url , iconimage ) :
 if 42 - 42: iiI1iIiI + o00O0oo
 II1 . create ( Oo0Ooo , "Opening......." , "Please Wait..." )
 if "m3u8" in url :
  o0o00o0 = open ( O00ooooo00 ) . read ( )
  iIi1ii1I1 = o0o00o0 . replace ( '<link>' + url + '</link>' , '' )
  O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
  O0oOO0o0 . write ( str ( iIi1ii1I1 ) )
  O0oOO0o0 . close ( )
  o0o00o0 = open ( O00ooooo00 ) . read ( )
  iIi1ii1I1 = o0o00o0 . replace ( '#START OF FILE#' , '#START OF FILE#\n<link>' + url + '</link>' )
  O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
  O0oOO0o0 . write ( str ( iIi1ii1I1 ) )
  O0oOO0o0 . close ( )
 elif not "m3u" in url :
  o0o00o0 = open ( O00ooooo00 ) . read ( )
  iIi1ii1I1 = o0o00o0 . replace ( '<link>' + url + '</link>' , '' )
  O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
  O0oOO0o0 . write ( str ( iIi1ii1I1 ) )
  O0oOO0o0 . close ( )
  o0o00o0 = open ( O00ooooo00 ) . read ( )
  iIi1ii1I1 = o0o00o0 . replace ( '#START OF FILE#' , '#START OF FILE#\n<link>' + url + '</link>' )
  O0oOO0o0 = open ( O00ooooo00 , mode = 'w' )
  O0oOO0o0 . write ( str ( iIi1ii1I1 ) )
  O0oOO0o0 . close ( )
  if 76 - 76: oo00000o0 - iII111i
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url
  elif '.mpegts' in url :
   url = url . replace ( '.mpegts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url
   if 70 - 70: O0o0o00o0Oo0
 if "plugin://" in url :
  if not os . path . exists ( IIi1IiiiI1Ii ) :
   ooo0OO . ok ( '[COLOR red]F4M TESTER NOT INSTALLED![/COLOR]' , "This link requires F4M Tester be installed. Please install F4M from the Shani Repo at http://fusion.tvaddons.ag" )
   quit ( )
   if 61 - 61: ooOoO0o . ooOoO0o
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  IIi1I1Ii11iI = urlresolver . HostedMediaFile ( url ) . resolve ( )
  I11i1I1I = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  I11i1I1I . setPath ( IIi1I1Ii11iI )
  II1 . close ( )
  xbmc . Player ( ) . play ( IIi1I1Ii11iI , I11i1I1I , False )
 elif liveresolver . isValid ( url ) == True :
  IIi1I1Ii11iI = liveresolver . resolve ( url )
  I11i1I1I = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  I11i1I1I . setPath ( IIi1I1Ii11iI )
  II1 . close ( )
  xbmc . Player ( ) . play ( IIi1I1Ii11iI , I11i1I1I , False )
 else :
  if 'http' in url :
   url = url + '|User-Agent=Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30'
  I11i1I1I = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  II1 . close ( )
  xbmc . Player ( ) . play ( url , I11i1I1I , False )
  if 83 - 83: ooOoO0o / O0o0o00o0Oo0
def I1I ( url ) :
 if 49 - 49: I1Ii111
 IIii1Ii1 = urllib2 . Request ( url )
 IIii1Ii1 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 i1IiIiiI = urllib2 . urlopen ( IIii1Ii1 )
 I1II11IiII = i1IiIiiI . read ( )
 i1IiIiiI . close ( )
 return I1II11IiII
 if 87 - 87: I1Ii111 + OOO0o0o + o0o + IiII . I11i * o0o
def OoI1Ii11I1Ii1i ( name , url , mode , iconimage , fanart , description = '' ) :
 if 65 - 65: i1OOooo0000ooo * I11i + iiI1iIiI % i11iIiiIii * o00O0oo . oo00000o0
 I11i1I1I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I11i1I1I . setProperty ( 'fanart_image' , fanart )
 OoO0O00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart )
 IIiII = True
 IIiII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoO0O00 , listitem = I11i1I1I , isFolder = False )
 return IIiII
 if 80 - 80: i1OOooo0000ooo . o00O0oo
def Ii1iI ( name , url , mode , iconimage , fanart , description = '' ) :
 OoO0O00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 IIiII = True
 I11i1I1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 I11i1I1I . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 I11i1I1I . setProperty ( 'fanart_image' , fanart )
 IIiII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoO0O00 , listitem = I11i1I1I , isFolder = True )
 return IIiII
 if 25 - 25: IiII . OOooOOo / ooo0Oo0 . o0o * iII111i . I11i
def Oo0oOOo ( ) :
 Oo0OoO00oOO0o = [ ]
 OOO00O = sys . argv [ 2 ]
 if len ( OOO00O ) >= 2 :
  iI = sys . argv [ 2 ]
  OOoOO0oo0ooO = iI . replace ( '?' , '' )
  if ( iI [ len ( iI ) - 1 ] == '/' ) :
   iI = iI [ 0 : len ( iI ) - 2 ]
  O0o0O00Oo0o0 = OOoOO0oo0ooO . split ( '&' )
  Oo0OoO00oOO0o = { }
  for O00O0oOO00O00 in range ( len ( O0o0O00Oo0o0 ) ) :
   i1Oo00 = { }
   i1Oo00 = O0o0O00Oo0o0 [ O00O0oOO00O00 ] . split ( '=' )
   if ( len ( i1Oo00 ) ) == 2 :
    Oo0OoO00oOO0o [ i1Oo00 [ 0 ] ] = i1Oo00 [ 1 ]
    if 31 - 31: oo00000o0 . IiII / i1iIi11iIIi1I
 return Oo0OoO00oOO0o
 if 89 - 89: IiII
iI = Oo0oOOo ( ) ; IIIII = None ; IiiiI1II1I1 = None ; OO0oOoOO0oOO0 = None ; oO0OOoo0OO = None ; oo = None
try : oO0OOoo0OO = urllib . unquote_plus ( iI [ "site" ] )
except : pass
try : IIIII = urllib . unquote_plus ( iI [ "url" ] )
except : pass
try : IiiiI1II1I1 = urllib . unquote_plus ( iI [ "name" ] )
except : pass
try : OO0oOoOO0oOO0 = int ( iI [ "mode" ] )
except : pass
try : oo = urllib . unquote_plus ( iI [ "iconimage" ] )
except : pass
try : O0O0OO0O0O0 = urllib . unquote_plus ( iI [ "fanart" ] )
except : pass
if 65 - 65: iiI1iIiI . o0 / i1iIi11iIIi1I - iiI1iIiI
if OO0oOoOO0oOO0 == None or IIIII == None or len ( IIIII ) < 1 : Oo ( )
elif OO0oOoOO0oOO0 == 1 : IiIIIiI1I1 ( IIIII )
elif OO0oOoOO0oOO0 == 2 : i1iIIi1 ( IiiiI1II1I1 , IIIII , oo )
elif OO0oOoOO0oOO0 == 3 : oo0Ooo0 ( )
elif OO0oOoOO0oOO0 == 4 : i1iiIIiiI111 ( )
if 21 - 21: I11i * o0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )