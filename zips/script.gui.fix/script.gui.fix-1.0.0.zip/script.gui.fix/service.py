# modules
import xbmc
import xbmcaddon
import xbmcgui
import skinSwitch
import time

# addon info
AddonTitle="GUISETTINGS CRASH Fix"
startup = xbmcaddon.Addon(id='script.gui.fix').getSetting('service_enable')
skintxt = xbmcaddon.Addon(id='script.gui.fix').getSetting('select_skin')
forceskin = xbmcaddon.Addon(id='script.gui.fix').getSetting('force_skin')
skin        =  xbmc.getSkinDir()
if skintxt != "Select Skin":
    skinname = xbmcaddon.Addon(id=skintxt).getAddonInfo('name')
else:
    pass
#Swap Skin
def skinswapfix():
    if skintxt == "Aeon Nox 5":
        skinner = "skin.aeon.nox.5"
    elif skintxt == "Aeon Nox 5: Silvo":
        skinner = "skin.aeon.nox.silvo"
    elif skintxt == "Cinema":
        skinner = "cinema"
    elif skintxt == "Aeon Nox 5: Mine":
        skinner = "skin.aeon.nox.silvomod"
    elif skintxt == "Top Cat":
        skinner = "topcat"
    elif skintxt == "Amber":
        skinner = "skin.amber"
    elif skintxt == "Angry Birds Movie":
        skinner = "skin.angry.birds"
    elif skintxt == "Black Glass Nova":
        skinner = "skin.blackglassnova"
    elif skintxt == "BlueBlack":
        skinner = "blueblack"
    elif skintxt == "BOX":
        skinner = "skin.box"
    elif skintxt == "Celtic":
        skinner = "celtic"
    elif skintxt == "Chelsea":
        skinner = "Chelsea"
    elif skintxt == "Chroma":
        skinner = "skin.chroma"
    elif skintxt == "Cirrus Extended":
        skinner = "skin.cirrus.extended"
    elif skintxt == "Classic Steampunked":
        skinner = "skin.classic.steampunked"
    elif skintxt == "Enrique":
        skinner = "skin.eunique"
    elif skintxt == "Fire and Ice":
        skinner = "skin.fandi"
    elif skintxt == "Frozen":
        skinner = "Frozen"
    elif skintxt == "Jambos":
        skinner = "Jambos"
    elif skintxt == "Killmarnock FC":
        skinner = "Killmarnock"
    elif skintxt == "Liverpool FC":
        skinner = "Liverpool"
    elif skintxt == "ManU":
        skinner = "ManU"
    elif skintxt == "US Marines":
        skinner = "Marines"
    elif skintxt == "Chop Socky":
        skinner = "skin.MartialArts"
    elif skintxt == "Metropolis":
        skinner = "skin.metropolis"
    elif skintxt == "Mimic":
        skinner = "skin.mimic"
    elif skintxt == "Minions":
        skinner = "minions"
    elif skintxt == "Nebula":
        skinner = "skin.nebula"
    elif skintxt == "Newcastle UTD":
        skinner = "NUFC"
    elif skintxt == "Paradise":
        skinner = "skin.paradise"
    elif skintxt == "Phenomenal":
        skinner = "skin.phenomenal"
    elif skintxt == "Rangers":
        skinner = "rangers"
    elif skintxt == "Rapier":
        skinner = "skin.rapier"
    elif skintxt == "reFocus":
        skinner = "skin.refocus"
    elif skintxt == "Revolve":
        skinner = "skin.revolve"
    elif skintxt == "Sky":
        skinner = "skin.sky"
    elif skintxt == "Spurs":
        skinner = "Spurs"
    elif skintxt == "Star Wars VII":
        skinner = "skin.star.wars"
    elif skintxt == "Star Wars":
        skinner = "Star Wars"
    elif skintxt == "Super Mario Galaxy":
        skinner = "skin.super.mario.jarvis"
    elif skintxt == "The Godfather":
        skinner = "skin.thegodfather"
    elif skintxt == "Titan":
        skinner = "skin.titan"
    elif skintxt == "Transparency!":
        skinner = "skin.transparency"
    elif skintxt == "tvOS-X - Jarvis":
        skinner = "skin.tvOS-X-jarvis"
    elif skintxt == "Unity":
        skinner = "skin.unity"
    elif skintxt == "Winter Wonderland":
        skinner = "skin.winter.wonderland"
    elif skintxt == "Xperience1080":
        skinner = "skin.xperience1080"
    elif skintxt == "Xredium":
        skinner = "skin.xredium"
    elif skintxt == "StarTrek":
        skinner = "StarTrek"
    elif skintxt == "re-Touched":
        skinner = "skin.re-touched"
    elif skintxt == "Xonfluence":
        skinner = "skin.xonfluence"
    else:
        skinner = skintxt
    skin        =  xbmc.getSkinDir()
    KODIV       =  float(xbmc.getInfoLabel("System.BuildVersion")[:4])
    skinswapped = 0

    #SWITCH THE SKIN IF THE CURRENT SKIN IS NOT CONFLUENCE
    if skin not in [skinner]:
        choice = xbmcgui.Dialog().ok(AddonTitle, '[COLOR red][B]YOUR NOT USING THE [COLOR white]'+skinname.upper()+'[/COLOR] SKIN!!![/B][/COLOR]','[COLOR red][B]PRESS OK TO ATTEMPT TO AUTO SWITCH[/B][/COLOR]')
        if choice == 0:
            pass
        skin = skinner if KODIV >= 17 else skinner
        skinSwitch.swapSkins(skin)
        skinswapped = 1
        time.sleep(1)
    
        #IF A SKIN SWAP HAS HAPPENED CHECK IF AN OK DIALOG (CONFLUENCE INFO SCREEN) IS PRESENT, PRESS OK IF IT IS PRESENT
        if skinswapped == 1:
            if not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Select)" )
        
        #IF THERE IS NOT A YES NO DIALOG (THE SCREEN ASKING YOU TO SWITCH TO CONFLUENCE) THEN SLEEP UNTIL IT APPEARS
        if skinswapped == 1:
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                time.sleep(1)
        
        #WHILE THE YES NO DIALOG IS PRESENT PRESS LEFT AND THEN SELECT TO CONFIRM THE SWITCH TO CONFLUENCE.
        if skinswapped == 1:
            while xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Left)" )
                xbmc.executebuiltin( "Action(Select)" )
                time.sleep(1)
        
        skin         =  xbmc.getSkinDir()

    #CHECK IF THE SKIN IS NOT CONFLUENCE
    if skin not in [skinner]:
        skinSwitch.swapSkins(skin)
        skinswapped = 1
        time.sleep(1)
    
    #IF A SKIN SWAP HAS HAPPENED CHECK IF AN OK DIALOG (CONFLUENCE INFO SCREEN) IS PRESENT, PRESS OK IF IT IS PRESENT
        if skinswapped == 1:
            if not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Select)" )
        
        #IF THERE IS NOT A YES NO DIALOG (THE SCREEN ASKING YOU TO SWITCH TO CONFLUENCE) THEN SLEEP UNTIL IT APPEARS
        if skinswapped == 1:
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                time.sleep(1)
        
        #WHILE THE YES NO DIALOG IS PRESENT PRESS LEFT AND THEN SELECT TO CONFIRM THE SWITCH TO CONFLUENCE.
        if skinswapped == 1:
            while xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                #xbmc.executebuiltin( "Action(Left)" )
                xbmc.executebuiltin( "Action(Select)" )
                time.sleep(1)
        
        skin         =  xbmc.getSkinDir()

    #CHECK IF THE SKIN IS NOT CONFLUENCE
    if skin not in [skinner]:
        skinSwitch.swapSkins(skin)
        skinswapped = 1
        time.sleep(1)
    
        #IF A SKIN SWAP HAS HAPPENED CHECK IF AN OK DIALOG (CONFLUENCE INFO SCREEN) IS PRESENT, PRESS OK IF IT IS PRESENT
        if skinswapped == 1:
            if not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Select)" )
        
        #IF THERE IS NOT A YES NO DIALOG (THE SCREEN ASKING YOU TO SWITCH TO CONFLUENCE) THEN SLEEP UNTIL IT APPEARS
        if skinswapped == 1:
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                time.sleep(1)
        
        #WHILE THE YES NO DIALOG IS PRESENT PRESS LEFT AND THEN SELECT TO CONFIRM THE SWITCH TO CONFLUENCE.
        if skinswapped == 1:
            while xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Down)" )
                xbmc.executebuiltin( "Action(Select)" )
                time.sleep(1)
        
        skin         =  xbmc.getSkinDir()

        #CHECK IF THE SKIN IS NOT CONFLUENCE
    if skin not in [skinner]:
        skinSwitch.swapSkins(skin)
        skinswapped = 1
        time.sleep(1)
    
        #IF A SKIN SWAP HAS HAPPENED CHECK IF AN OK DIALOG (CONFLUENCE INFO SCREEN) IS PRESENT, PRESS OK IF IT IS PRESENT
        if skinswapped == 1:
            if not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Select)" )
        
        #IF THERE IS NOT A YES NO DIALOG (THE SCREEN ASKING YOU TO SWITCH TO CONFLUENCE) THEN SLEEP UNTIL IT APPEARS
        if skinswapped == 1:
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                time.sleep(1)
        
        #WHILE THE YES NO DIALOG IS PRESENT PRESS LEFT AND THEN SELECT TO CONFIRM THE SWITCH TO CONFLUENCE.
        if skinswapped == 1:
            while xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Right)" )
                xbmc.executebuiltin( "Action(Select)" )
                time.sleep(1)
        
        skin         =  xbmc.getSkinDir()

        #CHECK IF THE SKIN IS NOT CONFLUENCE
    if skin not in [skinner]:
        skinSwitch.swapSkins(skin)
        skinswapped = 1
        time.sleep(1)
    
        #IF A SKIN SWAP HAS HAPPENED CHECK IF AN OK DIALOG (CONFLUENCE INFO SCREEN) IS PRESENT, PRESS OK IF IT IS PRESENT
        if skinswapped == 1:
            if not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Select)" )
        
        #IF THERE IS NOT A YES NO DIALOG (THE SCREEN ASKING YOU TO SWITCH TO CONFLUENCE) THEN SLEEP UNTIL IT APPEARS
        if skinswapped == 1:
            while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                time.sleep(1)
        
        #WHILE THE YES NO DIALOG IS PRESENT PRESS LEFT AND THEN SELECT TO CONFIRM THE SWITCH TO CONFLUENCE.
        if skinswapped == 1:
            while xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
                xbmc.executebuiltin( "Action(Up)" )
                xbmc.executebuiltin( "Action(Select)" )
                time.sleep(1)
        
        skin         =  xbmc.getSkinDir()
    if skin not in [skinner]:
        choice = xbmcgui.Dialog().yesno(AddonTitle, '[COLOR red][B]ERROR: AUTOSWITCH WAS NOT SUCCESFUL[/B][/COLOR]','[COLOR green][B]YES TO MANUALLY SWITCH TO '+ skinname.upper() + '[/B][/COLOR]','[COLOR red][B]NO AND ATTEMPT THE AUTO SWITCH AGAIN[/B][/COLOR]', yeslabel='[B][COLOR green]YES[/COLOR][/B]',nolabel='[B][COLOR red]NO[/COLOR][/B]')
        if choice == 1:
            xbmc.executebuiltin("ActivateWindow(appearancesettings)")
            return
        else:
            skinswapfix()
            #sys.exit(1)    
##############################    END    #########################################
if startup == "true":
    if skintxt == "Select Skin":
        choice = xbmcgui.Dialog().yesno(AddonTitle, '[COLOR red][B]YOU HAVE NOT SETUP THIS FEATURE[/B][/COLOR]','[COLOR green][B]PRESS SETUP[/B][/COLOR][COLOR red][B] OR DISABLE[/B][/COLOR]',yeslabel='[B][COLOR green]SETUP[/COLOR][/B]',nolabel='[B][COLOR red]DISABLE[/COLOR][/B]')
        if choice:
            xbmcaddon.Addon(id='script.gui.fix').openSettings()
        else:
            xbmcaddon.Addon(id='script.gui.fix').setSetting('service_enable','false')
    else:
        if xbmcaddon.Addon(id=skintxt):
            if forceskin == "false":
                if skin == "skin.confluence":
                    skinswapfix()
                else:
                    pass
            else:
                skinswapfix()

        else:
            xbmc.executebuiltin('Notification(GUISETTINGS CRASH Fix,SKIN IS NOT INSTALLED,4000)')
else:
    pass