import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
from resources . lib . modules import checker
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.FMG'
Oo0Ooo = '[COLOR orangered]FIND MY GAME[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( 'special://home/addons/' + OO0o )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pl.png' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/cleaner.xml' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/supported_addons.xml' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/notice.txt' ) )
if 39 - 39: O0 - ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
Ii1I = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
IiiIII111iI = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
IiII = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uRk1HL3BsdWdpbi52aWRlby5GTUct' )
iI1Ii11111iIi = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
i1i1II = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
O0oo0OO0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
if 6 - 6: oooO0oo0oOOOO - ooO0oo0oO0 - i111I * II1Ii1iI1i
iiI1iIiI = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
OOo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdmFZS3NkRmI=' )
Ii1IIii11 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvTlBKU0Q1amQ=' )
Oooo0000 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdXFTRGpHbXY=' )
i11 = xbmcgui . Dialog ( )
I11 = xbmcgui . DialogProgress ( )
Oo0o0000o0o0 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
oOo0oooo00o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
if 65 - 65: O0o * i1iIIII * I1
O0OoOoo00o = O0oo0OO0 + '|SPLIT|' + i1i1II
checker . check ( O0OoOoo00o )
if 31 - 31: i111IiI + iIIIiI11 . iII111ii
i1iIIi1 = xbmc . getInfoLabel ( "System.BuildVersion" )
ii11iIi1I = float ( i1iIIi1 [ : 4 ] )
if ii11iIi1I >= 11.0 and ii11iIi1I <= 11.9 :
 iI111I11I1I1 = 'Eden'
if ii11iIi1I >= 12.0 and ii11iIi1I <= 12.9 :
 iI111I11I1I1 = 'Frodo'
if ii11iIi1I >= 13.0 and ii11iIi1I <= 13.9 :
 iI111I11I1I1 = 'Gotham'
if ii11iIi1I >= 14.0 and ii11iIi1I <= 14.9 :
 iI111I11I1I1 = 'Helix'
if ii11iIi1I >= 15.0 and ii11iIi1I <= 15.9 :
 iI111I11I1I1 = 'Isengard'
if ii11iIi1I >= 16.0 and ii11iIi1I <= 16.9 :
 iI111I11I1I1 = 'Jarvis'
if ii11iIi1I >= 17.0 and ii11iIi1I <= 17.9 :
 iI111I11I1I1 = 'Krypton'
 if 55 - 55: iI1I % iiiIi - OO / ooO0oo0oO0 - ooO0oo0oO0 / iiiIi
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 59 - 59: iIIIiI11 * i11iIiiIii + iIIIiI11 + OO * ooO0oo0oO0
class OooOoO0Oo ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 47 - 47: i1iIIII
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 3 - 3: i11iIiiIii - ooOO00oOo - i111I
ii1I = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 76 - 76: O0 / II1Ii1iI1i . iiiiIi11i * iIIIiI11 - I1
class Oooo :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 67 - 67: I1 / oOo0O0Ooo % i111IiI - ooOO00oOo
  if 82 - 82: i11iIiiIii . I1 / oooO0oo0oOOOO * O0 % i1iIIII % ooOO00oOo
  if 78 - 78: ooOO00oOo - iIIIiI11 * ooO0oo0oO0 + II1Ii1iI1i + iII111ii + iII111ii
  if 11 - 11: iII111ii - ooO0oo0oO0 % OO % iII111ii / i111I - ooO0oo0oO0
def o0o0oOOOo0oo ( ) :
 o0oo0o0O00OO = 5
 o0oO = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 I1i1iii = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 20 - 20: II1Ii1iI1i
 oO00 = [ ]
 if 53 - 53: oOo0O0Ooo . Ooo00oOo00o
 for ii1I1i1I in range ( o0oo0o0O00OO ) :
  oO00 . append ( Oooo ( o0oO [ ii1I1i1I ] , I1i1iii [ ii1I1i1I ] ) )
  if 88 - 88: ooO0oo0oO0 + O0 / i111I * iII111ii
 return oO00
 if 41 - 41: i1iIIII
def ii1i1I1i ( ) :
 if 53 - 53: iI1I + iiiiIi11i * i1iIIII
 if not os . path . isfile ( I1IiiI ) :
  OooOooooOOoo0 = open ( I1IiiI , 'w' )
  if 71 - 71: iiiIi % i1iIIII % I1
 if not os . path . isfile ( IIi1IiiiI1Ii ) :
  OooOooooOOoo0 = open ( IIi1IiiiI1Ii , 'w' )
  if 94 - 94: i1iIIII - iII111ii * O0
 if not os . path . isfile ( O00ooooo00 ) :
  OooOooooOOoo0 = open ( O00ooooo00 , 'w' )
  if 17 - 17: O0o % oOoO0oo0OOOo
 I1IIiiIiii = O000oo0O ( Ii1IIii11 )
 if len ( I1IIiiIiii ) > 1 :
  OOOO = IIi1IiiiI1Ii
  i11i1 = open ( OOOO )
  IIIii1II1II = i11i1 . read ( )
  if IIIii1II1II == I1IIiiIiii : pass
  else :
   i1I1iI ( '[B][COLOR white]Find My Game Notice[/COLOR][/B]' , I1IIiiIiii )
   oo0OooOOo0 = open ( OOOO , "w" )
   oo0OooOOo0 . write ( I1IIiiIiii )
   oo0OooOOo0 . close ( )
   if 92 - 92: iII111ii . i111IiI + II1Ii1iI1i
 IiII1I11i1I1I = O000oo0O ( OOo )
 if len ( IiII1I11i1I1I ) > 1 :
  OOOO = I1IiiI
  i11i1 = open ( OOOO )
  IIIii1II1II = i11i1 . read ( )
  if IIIii1II1II == IiII1I11i1I1I : pass
  else :
   oo0OooOOo0 = open ( OOOO , "w" )
   oo0OooOOo0 . write ( IiII1I11i1I1I )
   oo0OooOOo0 . close ( )
   if 83 - 83: O0o / OO
 IiII1I11i1I1I = O000oo0O ( Oooo0000 )
 if len ( IiII1I11i1I1I ) > 1 :
  OOOO = O00ooooo00
  i11i1 = open ( OOOO )
  IIIii1II1II = i11i1 . read ( )
  if IIIii1II1II == IiII1I11i1I1I : pass
  else :
   oo0OooOOo0 = open ( OOOO , "w" )
   oo0OooOOo0 . write ( IiII1I11i1I1I )
   oo0OooOOo0 . close ( )
   if 49 - 49: II1Ii1iI1i
 IIii1Ii1 = datetime . date . today ( )
 I1II11IiII = datetime . datetime . strftime ( IIii1Ii1 , '%A %d %B %Y' )
 if 87 - 87: II1Ii1iI1i + i111IiI + I1 + i111I . iiiiIi11i * I1
 O0Oo000ooO00 ( '[COLOR orangered][B]EVENTS FOR ' + str ( I1II11IiII ) . upper ( ) + '[/B][/COLOR]' , '' , 999 , iiiii , ooo0OO )
 O0Oo000ooO00 ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 oO0 ( '[COLOR dodgerblue][B]Live Scores of Todays Games[/B][/COLOR]' , 'url' , 7 , iiiii , ooo0OO )
 if 45 - 45: i11iIiiIii * oOoO0oo0OOOo % ooOO00oOo + O0o - iIIIiI11
 iIi1iIiii111 = datetime . datetime . now ( )
 iIIIi1 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2RheXMv' )
 iiII1i1 = iIi1iIiii111 . day
 if 66 - 66: I1 - i111IiI
 I1i1III = iiII1i1
 if 63 - 63: I1 % i1iIIII * i1iIIII * ooO0oo0oO0 / O0o
 iIIIi1 = iIIIi1 + str ( I1i1III ) + '.xml'
 if 74 - 74: oOoO0oo0OOOo
 oO0Oo0O00Oo0o0 = iIIIi1
 O00O0oOO00O00 = i1 ( iIIIi1 )
 Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O00O0oOO00O00 )
 if 31 - 31: iiiIi . i111I / O0
 for o000O0o in Oo00 :
  if 42 - 42: i111I
  II = re . compile ( '<title>(.+?)</title>' ) . findall ( o000O0o ) [ 0 ]
  iIIIi1 = oO0Oo0O00Oo0o0 + "!" + II
  try :
   II , time = II . split ( ' - ' )
   II = '[B][COLOR white]' + II + '[/COLOR] - [COLOR orangered]' + time + '[/B][/COLOR]'
  except :
   II = '[B][COLOR white]' + II + '[/B][/COLOR]'
  oO0 ( II , iIIIi1 , 2 , II1 , ooo0OO )
  if 45 - 45: O0 * II1Ii1iI1i % oooO0oo0oOOOO * oOo0O0Ooo + iII111ii . i111I
 O0Oo000ooO00 ( '[COLOR orangered]Refresh List of Games[/COLOR]' , 'url' , 6 , iiiii , ooo0OO )
 O0Oo000ooO00 ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 oO0 ( '[COLOR orangered]FMG Supported Addons[/COLOR]' , 'url' , 4 , iiiii , ooo0OO )
 O0Oo000ooO00 ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @EchoCoder[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 O0Oo000ooO00 ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @blue_builds[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 if 67 - 67: i11iIiiIii - Ooo00oOo00o % O0o . O0
 o0oo = open ( Ii1I ) . read ( )
 oooooOoo0ooo = o0oo . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( oooooOoo0ooo ) )
 for o000O0o in Oo00 :
  I1I1IiI1 = float ( o000O0o )
 o0oo = open ( IiiIII111iI ) . read ( )
 oooooOoo0ooo = o0oo . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 Oo00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( oooooOoo0ooo ) )
 for o000O0o in Oo00 :
  III1iII1I1ii = float ( o000O0o )
  if 61 - 61: oOoO0oo0OOOo
 O0Oo000ooO00 ( "[COLOR orangered]Addon Version:[/COLOR] [COLOR white]" + str ( I1I1IiI1 ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 O0Oo000ooO00 ( "[COLOR orangered]Repository Version:[/COLOR] [COLOR white]" + str ( III1iII1I1ii ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 if 64 - 64: OO / i111I - O0 - i111IiI
 if iI111I11I1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif iI111I11I1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 86 - 86: i111IiI % i111I / iiiiIi11i / i111I
def iIIi1i1 ( name , url , iconimage ) :
 if 10 - 10: i111IiI
 try :
  url , OOooOO000 = url . split ( '!' )
 except :
  i11 . ok ( Oo0Ooo , "[COLOR white]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 97 - 97: O0o + I1 / ooOO00oOo / iII111ii
 I1111IIi = [ ]
 if 93 - 93: oOo0O0Ooo / iiiiIi11i % i11iIiiIii + O0o * ooO0oo0oO0
 O00O0oOO00O00 = i1 ( url )
 I1iI11Ii = re . compile ( '<title>' + re . escape ( OOooOO000 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O00O0oOO00O00 ) [ 0 ]
 i1iIIIi1i = re . compile ( '<search>(.+?)</search>' ) . findall ( I1iI11Ii )
 for iI1iIIiiii in i1iIIIi1i :
  I1111IIi . append ( iI1iIIiiii )
  if 26 - 26: i111IiI . oOo0O0Ooo
 I11 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 I11 . update ( 0 )
 if 39 - 39: iII111ii - O0 % i11iIiiIii * iiiIi . iI1I
 OOooo0O00o = [ ]
 oOOoOooOo = [ ]
 O000oo = [ ]
 I11 . update ( 0 )
 if 20 - 20: I1 % iIIIiI11 / iIIIiI11 + iIIIiI11
 III1IiiI = O000oo0O ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9uc19zdHJlYW1zLmluaQ==' ) )
 if 31 - 31: II1Ii1iI1i . iiiiIi11i
 III1IiiI = III1IiiI . replace ( '\r' , '' )
 III1IiiI = III1IiiI . split ( '\n' )
 for ii11IIII11I in III1IiiI :
  if 81 - 81: i111I / O0 . iI1I . iiiiIi11i
  try :
   o0oo = ii11IIII11I . split ( '=' ) [ 0 ]
   oooooOoo0ooo = str ( o0oo )
   OoOO = oooooOoo0ooo + '='
   ooOOO0 = str ( ii11IIII11I )
   o0o = ooOOO0 . replace ( OoOO , '' )
   oooooOoo0ooo = oooooOoo0ooo . strip ( )
   o0o = o0o . strip ( )
   OooOooooOOoo0 = "Live Stream"
   OOooo0O00o . append ( oooooOoo0ooo )
   oOOoOooOo . append ( o0o )
   O000oo . append ( OooOooooOOoo0 )
   O0OOoO00OO0o = list ( zip ( OOooo0O00o , oOOoOooOo , O000oo ) )
  except : pass
  if 38 - 38: I1 % i111IiI % II1Ii1iI1i % ooO0oo0oO0 - oooO0oo0oOOOO
 III1IiiI = O000oo0O ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9ucy5pbmk=' ) )
 if 37 - 37: iiiIi / i111I
 III1IiiI = III1IiiI . replace ( '\r' , '' )
 III1IiiI = III1IiiI . split ( '\n' )
 for ii11IIII11I in III1IiiI :
  if 23 - 23: O0
  try :
   o0oo = ii11IIII11I . split ( '=' ) [ 0 ]
   oooooOoo0ooo = str ( o0oo )
   OoOO = oooooOoo0ooo + '='
   ooOOO0 = str ( ii11IIII11I )
   o0o = ooOOO0 . replace ( OoOO , '' )
   oooooOoo0ooo = oooooOoo0ooo . strip ( )
   o0o = o0o . strip ( )
   OooOooooOOoo0 = "Channel Stream"
   OOooo0O00o . append ( oooooOoo0ooo )
   oOOoOooOo . append ( o0o )
   O000oo . append ( OooOooooOOoo0 )
   O0OOoO00OO0o = list ( zip ( OOooo0O00o , oOOoOooOo , O000oo ) )
  except : pass
  if 85 - 85: iIIIiI11
 III1IiiI = O000oo0O ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9uc19wYWlkLmluaQ==' ) )
 if 84 - 84: iiiiIi11i . ooOO00oOo % oOo0O0Ooo + iIIIiI11 % oOo0O0Ooo % ooO0oo0oO0
 III1IiiI = III1IiiI . replace ( '\r' , '' )
 III1IiiI = III1IiiI . split ( '\n' )
 for ii11IIII11I in III1IiiI :
  if 42 - 42: ooO0oo0oO0 / i111IiI / II1Ii1iI1i + iII111ii / i111I
  try :
   o0oo = ii11IIII11I . split ( '=' ) [ 0 ]
   oooooOoo0ooo = str ( o0oo )
   OoOO = oooooOoo0ooo + '='
   ooOOO0 = str ( ii11IIII11I )
   o0o = ooOOO0 . replace ( OoOO , '' )
   oooooOoo0ooo = oooooOoo0ooo . strip ( )
   o0o = o0o . strip ( )
   oooooOoo0ooo = "|PAID|" + oooooOoo0ooo
   OooOooooOOoo0 = "Paid Stream"
   OOooo0O00o . append ( oooooOoo0ooo )
   oOOoOooOo . append ( o0o )
   O000oo . append ( OooOooooOOoo0 )
   O0OOoO00OO0o = list ( zip ( OOooo0O00o , oOOoOooOo , O000oo ) )
  except : pass
  if 84 - 84: OO * oOoO0oo0OOOo + oooO0oo0oOOOO
 O0ooO0Oo00o = sorted ( O0OOoO00OO0o )
 ooO0oOOooOo0 = sorted ( I1111IIi )
 if 38 - 38: iiiIi
 I11 . update ( 100 )
 if 84 - 84: ooOO00oOo % iII111ii / ooOO00oOo % i111IiI
 ii = [ ]
 OOooooO0Oo = [ ]
 OOiIiIIi1 = [ ]
 I1IIII1i = [ ]
 I1I11i = [ ]
 Ii1I1I1i1Ii = 0
 i1Oo0oO00o = 0
 for i11I1II1I11i in ooO0oOOooOo0 :
  if 61 - 61: iiiiIi11i - I1 . i1iIIII / I1 + oooO0oo0oOOOO
  I1i11i = i11I1II1I11i . split ( ' ' )
  if 64 - 64: I1 % ooOO00oOo * i1iIIII
  for name , url , o0 in O0ooO0Oo00o :
   iI11I1II = name
   name = name . replace ( "|PAID|" , "" )
   name = Ii1IIiI1i ( name )
   if i11I1II1I11i . lower ( ) in name . lower ( ) :
    Ii1I1I1i1Ii = Ii1I1I1i1Ii + 1
    try :
     o0O = name
     o0oo = url . split ( "in://" ) [ 1 ]
     oooooOoo0ooo = o0oo . split ( "/" ) [ 0 ]
     o00 = xbmc . translatePath ( 'special://home/addons/' + oooooOoo0ooo )
     if 32 - 32: II1Ii1iI1i . iI1I * i111IiI
     if os . path . exists ( o00 ) :
      i1Oo0oO00o = i1Oo0oO00o + 1
      iconimage = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oooooOoo0ooo , 'icon.png' ) )
      OOooo0oOO0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oooooOoo0ooo , 'fanart.jpg' ) )
      if "|PAID|" in iI11I1II :
       ii . append ( "3" )
       name = o00O0 ( oooooOoo0ooo )
       name = name + " - Subscription Addon"
       oOO0O00Oo0O0o = "[COLOR dodgerblue][B]" + name + '[/B][/COLOR] - [COLOR orangered]' + o0 + "[/COLOR]"
      else :
       ii . append ( "2" )
       name = o00O0 ( oooooOoo0ooo )
       oOO0O00Oo0O0o = "[COLOR white][B]" + name + '[/B][/COLOR] - [COLOR orangered]' + o0 + "[/COLOR]"
      OOooooO0Oo . append ( oOO0O00Oo0O0o )
      OOiIiIIi1 . append ( url )
      I1IIII1i . append ( iconimage )
      I1I11i . append ( OOooo0oOO0O )
     else :
      if "|PAID|" in iI11I1II :
       ii . append ( "0" )
       name = o00O0 ( oooooOoo0ooo )
       name = name + " - Subscription Addon"
      else :
       ii . append ( "1" )
       name = o00O0 ( oooooOoo0ooo )
      oOO0O00Oo0O0o = '[COLOR darkgray]' + name + ' - ' + o0 + ' | Addon Not Installed[/COLOR]'
      OOooooO0Oo . append ( oOO0O00Oo0O0o )
      OOiIiIIi1 . append ( url )
      I1IIII1i . append ( iiiii )
      I1I11i . append ( ooo0OO )
     ii1 = list ( zip ( ii , OOooooO0Oo , OOiIiIIi1 , I1IIII1i , I1I11i ) )
    except : pass
  I1i11i = ""
  if 35 - 35: iII111ii * i1iIIII / ooOO00oOo - II1Ii1iI1i / oOo0O0Ooo - iiiIi
 II1I1iiIII = [ ]
 if 77 - 77: i111I - oOoO0oo0OOOo - OO
 IiiiIIiIi1 = 0
 if 74 - 74: ooOO00oOo * O0o + i111I / Ooo00oOo00o / oOoO0oo0OOOo . oooO0oo0oOOOO
 O0Oo000ooO00 ( "[COLOR orangered][B]We found " + str ( Ii1I1I1i1Ii ) + " links, you have the addons to play " + str ( i1Oo0oO00o ) + " of those links.[/B][/COLOR]" , "url" , 999 , iiiii , ooo0OO )
 O0Oo000ooO00 ( "########################################################" , "url" , 999 , iiiii , ooo0OO )
 if 62 - 62: oOo0O0Ooo * iiiiIi11i
 try :
  oOOOoo0O0oO = sorted ( ii1 , key = lambda ii1I1i1I : int ( ii1I1i1I [ 0 ] ) , reverse = True )
  oOOOoo0O0oO = sorted ( oOOOoo0O0oO , reverse = True )
  for iIII1I111III , name , url , iconimage , OOooo0oOO0O in oOOOoo0O0oO :
   if 20 - 20: II1Ii1iI1i . oOoO0oo0OOOo % I1 * ooOO00oOo
   IiiiIIiIi1 = IiiiIIiIi1 + 1
   II1I1iiIII . append ( url )
   if "NOT INSTALLED" not in name . upper ( ) :
    O0Oo000ooO00 ( "[COLOR lightblue][B]Link " + str ( IiiiIIiIi1 ) + ": [/B][/COLOR]" + name , url , 3 , iconimage , OOooo0oOO0O )
   else :
    O0Oo000ooO00 ( name , url , 999 , iconimage , OOooo0oOO0O )
    if 98 - 98: iiiiIi11i % iIIIiI11 * oOo0O0Ooo
  I11 . close ( )
 except :
  I11 . close ( )
  i11 . ok ( Oo0Ooo , "Sorry, no links were found." )
  quit ( )
  if 51 - 51: ooOO00oOo . i111I / i1iIIII + II1Ii1iI1i
 if iI111I11I1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif iI111I11I1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 33 - 33: OO . oOoO0oo0OOOo % iII111ii + II1Ii1iI1i
def o00O0 ( string ) :
 if 71 - 71: oooO0oo0oOOOO % I1
 OooOooooOOoo0 = open ( I1IiiI , mode = 'r' ) ; O00oO000O0O = OooOooooOOoo0 . read ( ) ; OooOooooOOoo0 . close ( )
 O00oO000O0O = O00oO000O0O . replace ( '\n' , '' )
 Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O00oO000O0O )
 I1i1i1iii = 0
 for o000O0o in Oo00 :
  if 16 - 16: iIIIiI11 + iI1I * O0 % Ooo00oOo00o . iiiiIi11i
  Oo0OO = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( o000O0o ) [ 0 ]
  O0OooOo0o = re . compile ( '<name>(.+?)</name>' ) . findall ( o000O0o ) [ 0 ]
  if 29 - 29: iiiiIi11i % iiiiIi11i
  if string == Oo0OO :
   I1i1i1iii = 1
   II = O0OooOo0o
   if 94 - 94: ooOO00oOo / oooO0oo0oOOOO % iII111ii * iII111ii * oOoO0oo0OOOo
 if I1i1i1iii == 0 :
  II = string
  if 29 - 29: ooO0oo0oO0 + i111I / II1Ii1iI1i / I1 * ooOO00oOo
 return II
 if 62 - 62: I1 / i1iIIII - ooO0oo0oO0 . i111IiI
def IIo0Oo0oO0oOO00 ( name , url , iconimage ) :
 if 92 - 92: oOo0O0Ooo * iiiIi
 o0000oO = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 o0000oO . setPath ( url )
 xbmc . Player ( ) . play ( url , o0000oO , False )
 quit ( )
 if 11 - 11: OO / i111I - iI1I * oOo0O0Ooo + oOo0O0Ooo . i111I
def Ii1IIiI1i ( string ) :
 if 26 - 26: iIIIiI11 % O0o
 OooOooooOOoo0 = open ( O00ooooo00 , mode = 'r' ) ; O00oO000O0O = OooOooooOOoo0 . read ( ) ; OooOooooOOoo0 . close ( )
 O00oO000O0O = O00oO000O0O . replace ( '\n' , '' )
 Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O00oO000O0O )
 for o000O0o in sorted ( Oo00 ) :
  o00Oo0oooooo = re . compile ( '<old>(.+?)</old>' ) . findall ( o000O0o ) [ 0 ]
  O0oO0 = re . compile ( '<new>(.+?)</new>' ) . findall ( o000O0o ) [ 0 ]
  if o00Oo0oooooo . lower ( ) in string . lower ( ) :
   string = string . replace ( o00Oo0oooooo , O0oO0 )
   if 7 - 7: iiiiIi11i
 return string
 if 41 - 41: i111IiI * ooOO00oOo / oOoO0oo0OOOo * i1iIIII
def i1I ( ) :
 if 42 - 42: II1Ii1iI1i + Ooo00oOo00o - iIIIiI11 / iI1I
 O0Oo000ooO00 ( "[COLOR white][B]FMG Supported Addons[/B][/COLOR]" , '' , 999 , iiiii , ooo0OO )
 O0Oo000ooO00 ( "#####################################" , '' , 999 , iiiii , ooo0OO )
 if 9 - 9: O0 % O0 - II1Ii1iI1i
 OoO = [ ]
 iiI1IIIi = [ ]
 II11IiIi11 = [ ]
 IIOOO0O00O0OOOO = [ ]
 oOOoOooOo = [ ]
 I1iiii1I = [ ]
 if 54 - 54: iiiiIi11i / iiiIi / ooOO00oOo % ooO0oo0oO0 % iIIIiI11
 OooOooooOOoo0 = open ( I1IiiI , mode = 'r' ) ; O00oO000O0O = OooOooooOOoo0 . read ( ) ; OooOooooOOoo0 . close ( )
 O00oO000O0O = O00oO000O0O . replace ( '\n' , '' )
 Oo00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O00oO000O0O )
 for o000O0o in sorted ( Oo00 ) :
  Oo0OO = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( o000O0o ) [ 0 ]
  O0OooOo0o = re . compile ( '<name>(.+?)</name>' ) . findall ( o000O0o ) [ 0 ]
  oooO = re . compile ( '<dev>(.+?)</dev>' ) . findall ( o000O0o ) [ 0 ]
  oOoo0oOo00 = re . compile ( '<source>(.+?)</source>' ) . findall ( o000O0o ) [ 0 ]
  iIIIi1 = O0OooOo0o + '|SPLIT|' + Oo0OO + '|SPLIT|' + oooO + '|SPLIT|' + oOoo0oOo00
  if 32 - 32: iiiiIi11i % ooOO00oOo / Ooo00oOo00o - iiiiIi11i
  o00 = xbmc . translatePath ( 'special://home/addons/' + Oo0OO )
  if os . path . exists ( o00 ) :
   if "|PAID|" in oooO :
    iIII1I111III = "3"
   else : iIII1I111III = "2"
  else :
   if not "|PAID|" in oooO :
    iIII1I111III = "1"
   else : iIII1I111III = "0"
  OoO . append ( Oo0OO )
  iiI1IIIi . append ( O0OooOo0o )
  II11IiIi11 . append ( oooO )
  IIOOO0O00O0OOOO . append ( oOoo0oOo00 )
  oOOoOooOo . append ( iIIIi1 )
  I1iiii1I . append ( iIII1I111III )
  O0OOoO00OO0o = list ( zip ( I1iiii1I , OoO , iiI1IIIi , II11IiIi11 , IIOOO0O00O0OOOO , oOOoOooOo ) )
  if 7 - 7: iiiIi * ooO0oo0oO0 - OO + I1 * iiiiIi11i % ooO0oo0oO0
 O0ooO0Oo00o = sorted ( O0OOoO00OO0o , key = lambda ii1I1i1I : int ( ii1I1i1I [ 0 ] ) , reverse = True )
 for iIII1I111III , Oo0OO , O0OooOo0o , oooO , iI1i111I1Ii , iIIIi1 in O0ooO0Oo00o :
  o00 = xbmc . translatePath ( 'special://home/addons/' + Oo0OO )
  if os . path . exists ( o00 ) :
   i11i1ii1I = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + Oo0OO , 'icon.png' ) )
   OOooo0oOO0O = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + Oo0OO , 'fanart.jpg' ) )
   if "|PAID|" in oooO :
    iIIIi1 = iIIIi1 + '|SPLIT|1|SPLIT|PAID'
    O0Oo000ooO00 ( "[COLOR dodgerblue][B]" + O0OooOo0o + " | PAID SUBSCRIPTION - INSTALLED [/B][/COLOR]" , iIIIi1 , 5 , i11i1ii1I , OOooo0oOO0O )
   else :
    iIIIi1 = iIIIi1 + '|SPLIT|1'
    O0Oo000ooO00 ( "[COLOR lightblue][B]" + O0OooOo0o + " - INSTALLED [/B][/COLOR]" , iIIIi1 , 5 , i11i1ii1I , OOooo0oOO0O )
  else :
   if "|PAID|" in oooO :
    iIIIi1 = iIIIi1 + '|SPLIT|0|SPLIT|PAID'
    O0Oo000ooO00 ( "[COLOR darkgray]" + O0OooOo0o + " | PAID SUBSCRIPTION - NOT INSTALLED [/COLOR]" , iIIIi1 , 5 , iiiii , ooo0OO )
   else :
    iIIIi1 = iIIIi1 + '|SPLIT|0'
    O0Oo000ooO00 ( "[COLOR darkgray]" + O0OooOo0o + " - NOT INSTALLED [/COLOR]" , iIIIi1 , 5 , iiiii , ooo0OO )
    if 88 - 88: i111IiI % O0o
 if iI111I11I1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif iI111I11I1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 48 - 48: OO / iiiIi . ooOO00oOo * i111I * i1iIIII / Ooo00oOo00o
def OOOOoOOo0O0 ( url ) :
 if 92 - 92: O0o + ooOO00oOo / oOoO0oo0OOOo
 OooO0OO = "null"
 try :
  II , url , oooO , iI1i111I1Ii , iIII1I111III , OooO0OO = url . split ( '|SPLIT|' )
 except :
  II , url , oooO , iI1i111I1Ii , iIII1I111III = url . split ( '|SPLIT|' )
  if 69 - 69: OO % i1iIIII
 if OooO0OO != "null" :
  oooO = oooO . replace ( "|PAID|" , "" )
  if 50 - 50: oOo0O0Ooo % i111IiI
 i11 . ok ( Oo0Ooo , "You can contact the developer of " + II + " on:" , "[COLOR orangered]" + oooO + "[/COLOR]" , "[B][COLOR blue]Install Source: " + iI1i111I1Ii + "[/COLOR][/B]" )
 if 49 - 49: i1iIIII - i11iIiiIii . iiiIi * iIIIiI11 % iII111ii + Ooo00oOo00o
 if iIII1I111III == "1" :
  oOO0OOOo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to launch ' + II + ' now?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if oOO0OOOo == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
 else :
  oOO0OOOo = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , "[B][COLOR blue]Install Source: " + iI1i111I1Ii + "[/COLOR][/B]" , '[COLOR white]' + II + ' is not installed. If the addon is available for download in any repository currently installed on your system we can attempt to install the addon. Would you like us to try and install ' + II + '?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if oOO0OOOo == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
   if 56 - 56: II1Ii1iI1i
def I1OooooO0oOOOO ( name , url , iconimage ) :
 if 100 - 100: iII111ii % I1
 OOO = [ ]
 iII1 = [ ]
 OOoIIii11Ii1i1I = [ ]
 Oooo0O = [ ]
 O000oo = [ ]
 if 90 - 90: ooOO00oOo % OO
 O00O0oOO00O00 = i1 ( 'http://www.livescores.com' )
 Oo00 = re . compile ( '<div class="cal">(.+?)<div id="fb-root">' ) . findall ( O00O0oOO00O00 )
 I1i11i = str ( Oo00 )
 OoO0O00O0oo0O = re . compile ( '<div class="min(.+?)data-esd="' ) . findall ( I1i11i )
 for o000O0o in OoO0O00O0oo0O :
  I1IiI11 = re . compile ( '<div class="ply tright name">(.+?)</div>' ) . findall ( o000O0o ) [ 0 ]
  iI1iiiiIii = re . compile ( '<div class="ply name">(.+?)<' ) . findall ( o000O0o ) [ 0 ]
  try :
   iIiIiIiI = re . compile ( 'class="scorelink">(.+?)</a>' ) . findall ( o000O0o ) [ 0 ]
  except :
   iIiIiIiI = re . compile ( '<div class="sco">(.+?)</div>' ) . findall ( o000O0o ) [ 0 ]
  try :
   time = re . compile ( '"><img src=".+?" alt="live"/>(.+?)</div>' ) . findall ( o000O0o ) [ 0 ]
  except : time = re . compile ( '">(.+?)</div>' ) . findall ( o000O0o ) [ 0 ]
  time = time . replace ( '&#x27;' , ' Minute' )
  if 30 - 30: iiiIi . OO * O0o
  if "minute" in time . lower ( ) :
   O000oo . append ( '3' )
  elif "ht" in time . lower ( ) :
   O000oo . append ( '3' )
  elif "ft" in time . lower ( ) :
   O000oo . append ( '2' )
  else : O000oo . append ( '1' )
  if 17 - 17: iiiiIi11i . O0 + ooO0oo0oO0
  OOO . append ( I1IiI11 )
  iII1 . append ( iI1iiiiIii )
  OOoIIii11Ii1i1I . append ( iIiIiIiI )
  Oooo0O . append ( time )
  O0OOoO00OO0o = list ( zip ( O000oo , OOO , iII1 , OOoIIii11Ii1i1I , Oooo0O ) )
  if 43 - 43: oOoO0oo0OOOo . i1iIIII / O0o
 O0ooO0Oo00o = sorted ( O0OOoO00OO0o , key = lambda ii1I1i1I : int ( ii1I1i1I [ 0 ] ) , reverse = True )
 i1iI1 = 0
 i11ii1ii11i = 0
 ooO0OoOO = 0
 for O0O0Oo00 , oOoO00o , oO00O0 , IIi1IIIi , O00Ooo in O0ooO0Oo00o :
  if O0O0Oo00 == "3" :
   if i1iI1 == 0 :
    O0Oo000ooO00 ( '[COLOR white][B]Live Now[/B][/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
    i1iI1 = 1
  elif O0O0Oo00 == "2" :
   if i11ii1ii11i == 0 :
    O0Oo000ooO00 ( '[COLOR white][B]Finished[/B][/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
    i11ii1ii11i = 1
  elif O0O0Oo00 == "1" :
   if ooO0OoOO == 0 :
    O0Oo000ooO00 ( '[COLOR white][B]Later Today[/B][/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
    ooO0OoOO = 1
  O00Ooo = O00Ooo . replace ( "'" , "" ) . replace ( ' Minute' , "'" )
  IIi1IIIi = IIi1IIIi . replace ( " " , "" )
  O0Oo000ooO00 ( '[COLOR red][B]' + O00Ooo + "[/B][/COLOR]- [COLOR blue]" + IIi1IIIi + "[/COLOR] | [COLOR white]" + oOoO00o + "vs" + oO00O0 + '[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
  if 52 - 52: O0o - oooO0oo0oOOOO + O0o % II1Ii1iI1i
def oO0 ( name , url , mode , iconimage , fanartimage ) :
 if 35 - 35: ooOO00oOo
 I1i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 iIII = True
 o0000oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 o0000oO . setProperty ( "fanart_Image" , fanartimage )
 o0000oO . setProperty ( "icon_Image" , iconimage )
 iIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1i , listitem = o0000oO , isFolder = True )
 return iIII
 if 70 - 70: iII111ii / ooOO00oOo
def O0Oo000ooO00 ( name , url , mode , iconimage , fanartimage ) :
 if 85 - 85: oOo0O0Ooo % Ooo00oOo00o * oOo0O0Ooo / O0o
 I1i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 iIII = True
 o0000oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 o0000oO . setProperty ( "fanart_Image" , fanartimage )
 o0000oO . setProperty ( "icon_Image" , iconimage )
 iIII = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1i , listitem = o0000oO , isFolder = False )
 return iIII
 if 96 - 96: oOo0O0Ooo + i1iIIII
def i1I1iI ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 iiII1i11i = xbmcgui . Window ( id )
 IiIi = 50
 while ( IiIi > 0 ) :
  try :
   xbmc . sleep ( 10 )
   IiIi -= 1
   iiII1i11i . getControl ( 1 ) . setLabel ( heading )
   iiII1i11i . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 87 - 87: O0o - O0o - iII111ii + i1iIIII
def i1 ( url ) :
 OOooo = urllib2 . Request ( url )
 OOooo . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 iIIiIiI1I1 = urllib2 . urlopen ( OOooo )
 O00O0oOO00O00 = iIIiIiI1I1 . read ( )
 iIIiIiI1I1 . close ( )
 O00O0oOO00O00 = O00O0oOO00O00 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return O00O0oOO00O00
 if 56 - 56: iiiiIi11i . O0 + oooO0oo0oOOOO
def O000oo0O ( url ) :
 OOooo = urllib2 . Request ( url )
 OOooo . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 iIIiIiI1I1 = urllib2 . urlopen ( OOooo )
 O00O0oOO00O00 = iIIiIiI1I1 . read ( )
 iIIiIiI1I1 . close ( )
 return O00O0oOO00O00
 if 1 - 1: iII111ii
 if 97 - 97: I1 + iII111ii + O0 + i11iIiiIii
 if 77 - 77: II1Ii1iI1i / oOo0O0Ooo
 if 46 - 46: II1Ii1iI1i % ooOO00oOo . iII111ii % iII111ii + i11iIiiIii
 if 72 - 72: ooOO00oOo * iIIIiI11 % OO / ooO0oo0oO0
def I11i1II ( ) :
 if 72 - 72: ooOO00oOo . Ooo00oOo00o / oooO0oo0oOOOO . oOoO0oo0OOOo
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 54 - 54: oOoO0oo0OOOo % oOoO0oo0OOOo
 if os . path . exists ( Oo0o0000o0o0 ) == True :
  for Oo00000o0o , O0OOoOOO0oO , I1ii11 in os . walk ( Oo0o0000o0o0 ) :
   oOoOoOoo0 = 0
   oOoOoOoo0 += len ( I1ii11 )
   if oOoOoOoo0 > 0 :
    for OooOooooOOoo0 in I1ii11 :
     try :
      if ( OooOooooOOoo0 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( Oo00000o0o , OooOooooOOoo0 ) )
     except :
      pass
    for ooOOO0 in O0OOoOOO0oO :
     try :
      shutil . rmtree ( os . path . join ( Oo00000o0o , ooOOO0 ) )
     except :
      pass
      if 34 - 34: i111I - I1 + O0 . iIIIiI11
   else :
    pass
    if 46 - 46: iI1I
 if os . path . exists ( oOo0oooo00o ) == True :
  for Oo00000o0o , O0OOoOOO0oO , I1ii11 in os . walk ( oOo0oooo00o ) :
   oOoOoOoo0 = 0
   oOoOoOoo0 += len ( I1ii11 )
   if oOoOoOoo0 > 0 :
    for OooOooooOOoo0 in I1ii11 :
     try :
      if ( OooOooooOOoo0 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( Oo00000o0o , OooOooooOOoo0 ) )
     except :
      pass
    for ooOOO0 in O0OOoOOO0oO :
     try :
      shutil . rmtree ( os . path . join ( Oo00000o0o , ooOOO0 ) )
     except :
      pass
      if 45 - 45: OO
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  IIi = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 94 - 94: oOoO0oo0OOOo - oooO0oo0oOOOO
  for Oo00000o0o , O0OOoOOO0oO , I1ii11 in os . walk ( IIi ) :
   oOoOoOoo0 = 0
   oOoOoOoo0 += len ( I1ii11 )
   if 91 - 91: oooO0oo0oOOOO
   if oOoOoOoo0 > 0 :
    for OooOooooOOoo0 in I1ii11 :
     os . unlink ( os . path . join ( Oo00000o0o , OooOooooOOoo0 ) )
    for ooOOO0 in O0OOoOOO0oO :
     shutil . rmtree ( os . path . join ( Oo00000o0o , ooOOO0 ) )
     if 31 - 31: I1 / i11iIiiIii % ooOO00oOo + I1 / i11iIiiIii
   else :
    pass
  OOooO0oo0o00o = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 100 - 100: II1Ii1iI1i
  for Oo00000o0o , O0OOoOOO0oO , I1ii11 in os . walk ( OOooO0oo0o00o ) :
   oOoOoOoo0 = 0
   oOoOoOoo0 += len ( I1ii11 )
   if 1 - 1: i111IiI + oOo0O0Ooo - I1 + iI1I
   if oOoOoOoo0 > 0 :
    for OooOooooOOoo0 in I1ii11 :
     os . unlink ( os . path . join ( Oo00000o0o , OooOooooOOoo0 ) )
    for ooOOO0 in O0OOoOOO0oO :
     shutil . rmtree ( os . path . join ( Oo00000o0o , ooOOO0 ) )
     if 9 - 9: iIIIiI11
   else :
    pass
    if 59 - 59: iiiiIi11i * oOoO0oo0OOOo . O0
 oO00 = o0o0oOOOo0oo ( )
 if 56 - 56: iIIIiI11 - iII111ii % iiiiIi11i - II1Ii1iI1i
 for Oo00O in oO00 :
  iI111i1II = xbmc . translatePath ( Oo00O . path )
  if os . path . exists ( iI111i1II ) == True :
   for Oo00000o0o , O0OOoOOO0oO , I1ii11 in os . walk ( iI111i1II ) :
    oOoOoOoo0 = 0
    oOoOoOoo0 += len ( I1ii11 )
    if oOoOoOoo0 > 0 :
     for OooOooooOOoo0 in I1ii11 :
      os . unlink ( os . path . join ( Oo00000o0o , OooOooooOOoo0 ) )
     for ooOOO0 in O0OOoOOO0oO :
      shutil . rmtree ( os . path . join ( Oo00000o0o , ooOOO0 ) )
      if 69 - 69: iIIIiI11 * O0 . i11iIiiIii / iIIIiI11 . II1Ii1iI1i
    else :
     pass
     if 63 - 63: i111IiI + II1Ii1iI1i . oOoO0oo0OOOo - iiiiIi11i
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 i11 . ok ( Oo0Ooo , "The FMG games list has been reloaded." )
 if 52 - 52: II1Ii1iI1i % oooO0oo0oOOOO
def Oo000ooOOO ( ) :
 Ii11i1I11i = [ ]
 I11i1 = sys . argv [ 2 ]
 if len ( I11i1 ) >= 2 :
  iIiIIIIIii = sys . argv [ 2 ]
  OOo0 = iIiIIIIIii . replace ( '?' , '' )
  if ( iIiIIIIIii [ len ( iIiIIIIIii ) - 1 ] == '/' ) :
   iIiIIIIIii = iIiIIIIIii [ 0 : len ( iIiIIIIIii ) - 2 ]
  ii11I1 = OOo0 . split ( '&' )
  Ii11i1I11i = { }
  for oO0oo in range ( len ( ii11I1 ) ) :
   Ii111iIi1iIi = { }
   Ii111iIi1iIi = ii11I1 [ oO0oo ] . split ( '=' )
   if ( len ( Ii111iIi1iIi ) ) == 2 :
    Ii11i1I11i [ Ii111iIi1iIi [ 0 ] ] = Ii111iIi1iIi [ 1 ]
    if 21 - 21: i1iIIII / O0o + iIIIiI11 + oOo0O0Ooo
 return Ii11i1I11i
 if 91 - 91: i11iIiiIii / Ooo00oOo00o + iII111ii + OO * i11iIiiIii
iIiIIIIIii = Oo000ooOOO ( ) ; II = None ; iIIIi1 = None ; OoOoOo00o0 = None ; i11i1ii1I = None ; OO0ooo0oOO = None
try : II = urllib . unquote_plus ( iIiIIIIIii [ "name" ] )
except : pass
try : iIIIi1 = urllib . unquote_plus ( iIiIIIIIii [ "url" ] )
except : pass
try : OoOoOo00o0 = int ( iIiIIIIIii [ "mode" ] )
except : pass
try : i11i1ii1I = urllib . unquote_plus ( iIiIIIIIii [ "iconimage" ] )
except : pass
try : OO0ooo0oOO = urllib . quote_plus ( iIiIIIIIii [ "fanartimage" ] )
except : pass
if 97 - 97: iiiiIi11i / iII111ii
if OoOoOo00o0 == None or iIIIi1 == None or len ( iIIIi1 ) < 1 : ii1i1I1i ( )
elif OoOoOo00o0 == 1 : Get_Content ( II , iIIIi1 , i11i1ii1I )
elif OoOoOo00o0 == 2 : iIIi1i1 ( II , iIIIi1 , i11i1ii1I )
elif OoOoOo00o0 == 3 : IIo0Oo0oO0oOO00 ( II , iIIIi1 , i11i1ii1I )
elif OoOoOo00o0 == 4 : i1I ( )
elif OoOoOo00o0 == 5 : OOOOoOOo0O0 ( iIIIi1 )
elif OoOoOo00o0 == 6 : I11i1II ( )
elif OoOoOo00o0 == 7 : I1OooooO0oOOOO ( II , iIIIi1 , i11i1ii1I )
if 71 - 71: oOoO0oo0OOOo / Ooo00oOo00o . O0o % oOo0O0Ooo . i111I
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )