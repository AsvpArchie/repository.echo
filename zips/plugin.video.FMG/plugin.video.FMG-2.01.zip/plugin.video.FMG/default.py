import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
import downloader
import extract
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.FMG'
Oo0Ooo = '[COLOR red]FIND MY GAME[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( 'special://home/addons/' + OO0o )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'supported_addons.xml' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'notice.txt' ) )
if 32 - 32: ooOoO + iIiiiI1IiI1I1 * IIiIiII11i * o0oOOo0O0Ooo
I1ii11iIi11i = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
I1IiI = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
o0OOO = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uRk1HL3BsdWdpbi52aWRlby5GTUct' )
iIiiiI = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
if 23 - 23: iii1II11ii * i11iII1iiI + iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
o0oO0 = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
oo00 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcveHJkU3pOVUM=' )
o00 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvaXF6Vmp3ZXc=' )
Oo0oO0ooo = xbmcgui . Dialog ( )
o0oOoO00o = xbmcgui . DialogProgress ( )
i1 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
oOOoo00O0O = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
if 15 - 15: I11iii11IIi
#######################################################################
#						Cache Functions
#######################################################################
if 93 - 93: O0 * O0o0o00o0Oo0 / i11iI / Oo0o0ooO0oOOO + I1 - O0OoOoo00o
class iiiI11 ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 91 - 91: oOOOO / i1iiIII111ii + o0oOOo0O0Ooo . oO0o0ooO0
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 85 - 85: ii1II11I1ii1I
oOoOo00oOo = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 96 - 96: o0oOOo0O0Ooo . oO0o0ooO0 * O0o0o00o0Oo0 % i1iiIII111ii
class OO0O0O00OooO :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 77 - 77: iii1II11ii - iii1II11ii . i11iII1iiI / iiIIIII1i1iI
  if 14 - 14: i11iI % ooOoO
  if 41 - 41: o0oOOo0O0Ooo + oOOOO + O0o0o00o0Oo0 - O0OoOoo00o
  if 77 - 77: iI1Ii11111iIi . O0OoOoo00o % i1iiIII111ii
def IIiiIiI1 ( ) :
 iiIiIIi = 5
 ooOoo0O = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 OooO0 = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 35 - 35: O0o0o00o0Oo0 % oOOOO % i11iIiiIii / IIiIiII11i
 Ii11iI1i = [ ]
 if 82 - 82: i11iIiiIii . O0o0o00o0Oo0 / iI1Ii11111iIi * ooOoO % O0 % iIiiiI1IiI1I1
 for Oo00OOOOO in range ( iiIiIIi ) :
  Ii11iI1i . append ( OO0O0O00OooO ( ooOoo0O [ Oo00OOOOO ] , OooO0 [ Oo00OOOOO ] ) )
  if 85 - 85: i1iiIII111ii . I1 - ii1II11I1ii1I % i1iiIII111ii % iii1II11ii
 return Ii11iI1i
 if 81 - 81: ii1II11I1ii1I + iii1II11ii % I1 * ooOoO
def oOOo0oo ( ) :
 if 80 - 80: i11iI * i11iIiiIii / oOOOO
 I11II1i = IIIII ( )
 if 75 - 75: iii1II11ii % iii1II11ii
 if not os . path . isfile ( II1 ) :
  iI1 = open ( II1 , 'w' )
  if 19 - 19: i11iI + i1iiIII111ii
 if not os . path . isfile ( O00ooooo00 ) :
  iI1 = open ( O00ooooo00 , 'w' )
  if 53 - 53: IIiIiII11i . o0oOOo0O0Ooo
 ii1I1i1I = OOoo0O0 ( o00 )
 if len ( ii1I1i1I ) > 1 :
  iiiIi1i1I = xbmc . translatePath ( os . path . join ( O0O0OO0O0O0 , 'notice.txt' ) )
  oOO00oOO = open ( iiiIi1i1I )
  OoOo = oOO00oOO . read ( )
  if OoOo == ii1I1i1I : pass
  else :
   iI ( '[B][COLOR green]Find My Game Notice[/COLOR][/B]' , ii1I1i1I )
   o00O = open ( iiiIi1i1I , "w" )
   o00O . write ( ii1I1i1I )
   o00O . close ( )
   if 69 - 69: O0 % oOOOO - iiIIIII1i1iI + oOOOO - ooOoO % IIiIiII11i
 Iii111II = OOoo0O0 ( oo00 )
 if len ( Iii111II ) > 1 :
  iiiIi1i1I = xbmc . translatePath ( os . path . join ( O0O0OO0O0O0 , 'supported_addons.xml' ) )
  oOO00oOO = open ( iiiIi1i1I )
  OoOo = oOO00oOO . read ( )
  if OoOo == Iii111II : pass
  else :
   o00O = open ( iiiIi1i1I , "w" )
   o00O . write ( Iii111II )
   o00O . close ( )
   if 9 - 9: ii1II11I1ii1I
 i11 = datetime . date . today ( )
 O0oo0OO0oOOOo = datetime . datetime . strftime ( i11 , '%A %d %B %Y' )
 if 35 - 35: O0OoOoo00o % i11iII1iiI
 o0OOoo0OO0OOO ( '[COLOR red][B]EVENTS FOR ' + str ( O0oo0OO0oOOOo ) . upper ( ) + '[/B][/COLOR]' , '' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 if 19 - 19: O0 % o0oOOo0O0Ooo % iiIIIII1i1iI
 oo0OooOOo0 = datetime . datetime . now ( )
 o0O = 'http://echocoder.com/private/addons/fmg/days/'
 O00oO = oo0OooOOo0 . day
 if 39 - 39: O0OoOoo00o - iii1II11ii * ii1II11I1ii1I % iiIIIII1i1iI * iii1II11ii % iii1II11ii
 OoOOOOO = O00oO
 if 33 - 33: I11iii11IIi % o0oOOo0O0Ooo
 o0O = o0O + str ( OoOOOOO ) + '.xml'
 if 78 - 78: i11iI
 OO00Oo = o0O
 O0OOO0OOoO0O = O00Oo000ooO0 ( o0O )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0OOO0OOoO0O )
 if 5 - 5: iI1Ii11111iIi / iiIIIII1i1iI . Oo0o0ooO0oOOO - ooOoO / O0OoOoo00o
 for ooOooo000oOO in OoO0O00 :
  if 59 - 59: iii1II11ii + IIiIiII11i * oO0o0ooO0 + o0oOOo0O0Ooo
  Oo0OoO00oOO0o = re . compile ( '<title>(.+?)</title>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0O = OO00Oo + "!" + Oo0OoO00oOO0o
  try :
   Oo0OoO00oOO0o , time = Oo0OoO00oOO0o . split ( ' - ' )
   Oo0OoO00oOO0o = '[B][COLOR green]' + Oo0OoO00oOO0o + '[/COLOR] - [COLOR red]' + time + '[/B][/COLOR]'
  except :
   Oo0OoO00oOO0o = '[B][COLOR green]' + Oo0OoO00oOO0o + '[/B][/COLOR]'
  OOO00O ( Oo0OoO00oOO0o , o0O , 2 , iiiii , ooo0OO )
  if 84 - 84: O0 * ii1II11I1ii1I / i11iI - ooOoO
 o0OOoo0OO0OOO ( '[COLOR red]Refresh List of Games[/COLOR]' , 'url' , 6 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 OOO00O ( '[COLOR red]FMG Supported Addons[/COLOR]' , 'url' , 4 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '[COLOR green]Twitter:[/COLOR][COLOR red] @EchoCoder[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '[COLOR green]Twitter:[/COLOR][COLOR red] @BlueBuilds[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 if 30 - 30: iIiiiI1IiI1I1 / i1iiIII111ii - oOOOO - iii1II11ii % I1
 IIi1i11111 = open ( I1ii11iIi11i ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  I1ii11iI = float ( ooOooo000oOO )
 IIi1i11111 = open ( I1IiI ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  IIi1i = float ( ooOooo000oOO )
  if 46 - 46: oOOOO % i11iI + ii1II11I1ii1I . oO0o0ooO0 . ii1II11I1ii1I
 o0OOoo0OO0OOO ( "[COLOR red]Addon Version:[/COLOR] [COLOR white]" + str ( I1ii11iI ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "[COLOR red]Repository Version:[/COLOR] [COLOR white]" + str ( IIi1i ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 if 96 - 96: iI1Ii11111iIi
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 45 - 45: ooOoO * iiIIIII1i1iI % iI1Ii11111iIi * IIiIiII11i + I1 . oO0o0ooO0
 if I11II1i == 1 :
  xbmc . executebuiltin ( 'Container.Refresh' )
  if 67 - 67: i11iIiiIii - o0oOOo0O0Ooo % I11iii11IIi . ooOoO
def o0oo ( name , url , iconimage ) :
 if 91 - 91: O0OoOoo00o
 try :
  url , iiIii = url . split ( '!' )
 except :
  Oo0oO0ooo . ok ( Oo0Ooo , "[COLOR green]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 79 - 79: IIiIiII11i / ooOoO
 OO0OoO0o00 = [ ]
 if 53 - 53: ooOoO * ii1II11I1ii1I + O0o0o00o0Oo0
 O0OOO0OOoO0O = O00Oo000ooO0 ( url )
 Ii = re . compile ( '<title>' + re . escape ( iiIii ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0OOO0OOoO0O ) [ 0 ]
 oOOo0 = re . compile ( '<search>(.+?)</search>' ) . findall ( Ii )
 for oo00O00oO in oOOo0 :
  OO0OoO0o00 . append ( oo00O00oO )
  if 23 - 23: ii1II11I1ii1I + ii1II11I1ii1I . O0o0o00o0Oo0
 o0oOoO00o . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 o0oOoO00o . update ( 0 )
 if 38 - 38: oOOOO
 Ii1 = [ ]
 OOooOO000 = [ ]
 o0oOoO00o . update ( 0 )
 OOoOoo = OOoo0O0 ( "http://echocoder.com/private/addons/fmg/addons.ini" )
 if 85 - 85: I11iii11IIi % I1 % i1iiIII111ii
 OOoOoo = OOoOoo . replace ( '\r' , '' )
 OOoOoo = OOoOoo . split ( '\n' )
 for Oo00oo0oO in OOoOoo :
  if 1 - 1: ii1II11I1ii1I - O0 . i11iI . ii1II11I1ii1I / iI1Ii11111iIi + i11iI
  try :
   IIi1i11111 = Oo00oo0oO . split ( '=' ) [ 0 ]
   ooOO00O00oo = str ( IIi1i11111 )
   Ooo = ooOO00O00oo + '='
   OOOOo = str ( Oo00oo0oO )
   oo0O0oO = OOOOo . replace ( Ooo , '' )
   ooOO00O00oo = ooOO00O00oo . strip ( )
   oo0O0oO = oo0O0oO . strip ( )
   Ii1 . append ( ooOO00O00oo )
   OOooOO000 . append ( oo0O0oO )
   ooooo = list ( zip ( Ii1 , OOooOO000 ) )
  except : pass
 II1I = sorted ( ooooo )
 O0i1II1Iiii1I11 = sorted ( OO0OoO0o00 )
 if 9 - 9: I11iii11IIi / iI1Ii11111iIi - i11iII1iiI / IIiIiII11i / iIiiiI1IiI1I1 - iiIIIII1i1iI
 o0oOoO00o . update ( 100 )
 if 91 - 91: I1 % o0oOOo0O0Ooo % iIiiiI1IiI1I1
 IIi1I11I1II = [ ]
 OooOoooOo = [ ]
 ii11IIII11I = [ ]
 OOooo = [ ]
 if 90 - 90: iiIIIII1i1iI % o0oOOo0O0Ooo / ii1II11I1ii1I
 for IIi in O0i1II1Iiii1I11 :
  if 41 - 41: Oo0o0ooO0oOOO - ooOoO - ooOoO
  oO00OOoO00 = IIi . split ( ' ' )
  if 40 - 40: i11iII1iiI * Oo0o0ooO0oOOO + O0o0o00o0Oo0 % I1
  for name , url in II1I :
   if IIi . lower ( ) in name . lower ( ) :
    try :
     OOOOOoo0 = name
     IIi1i11111 = url . split ( "in://" ) [ 1 ]
     ooOO00O00oo = IIi1i11111 . split ( "/" ) [ 0 ]
     ii1 = xbmc . translatePath ( 'special://home/addons/' + ooOO00O00oo )
     if 11 - 11: O0OoOoo00o * i11iII1iiI . iIiiiI1IiI1I1 % IIiIiII11i + I1
     if os . path . exists ( ii1 ) :
      iconimage = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + ooOO00O00oo , 'icon.png' ) )
      ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + ooOO00O00oo , 'fanart.jpg' ) )
      name = OOO ( ooOO00O00oo )
      oo0OOo0 = "[COLOR green][B]" + name + '[/B][/COLOR] - [COLOR red]' + OOOOOoo0 + "[/COLOR]"
      IIi1I11I1II . append ( oo0OOo0 )
      OooOoooOo . append ( url )
      ii11IIII11I . append ( iconimage )
      OOooo . append ( ooo0OO )
      I11IiI = list ( zip ( IIi1I11I1II , OooOoooOo , ii11IIII11I , OOooo ) )
    except : pass
  oO00OOoO00 = ""
  if 53 - 53: I1 % iii1II11ii . O0OoOoo00o - iIiiiI1IiI1I1 - O0OoOoo00o * iii1II11ii
 try :
  ooO0oOOooOo0 = sorted ( I11IiI )
  if 38 - 38: oOOOO
  for name , url , iconimage , ooo0OO in ooO0oOOooOo0 :
   o0OOoo0OO0OOO ( name , url , 3 , iconimage , ooo0OO )
  o0oOoO00o . close ( )
 except :
  o0oOoO00o . close ( )
  Oo0oO0ooo . ok ( Oo0Ooo , "Sorry, no links were found." )
  quit ( )
  if 84 - 84: iIiiiI1IiI1I1 % I1 / iIiiiI1IiI1I1 % i11iI
def OOO ( string ) :
 if 45 - 45: ooOoO
 iI1 = open ( II1 , mode = 'r' ) ; I1IiiiiI = iI1 . read ( ) ; iI1 . close ( )
 I1IiiiiI = I1IiiiiI . replace ( '\n' , '' )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiiiiI )
 o0OIiII = 0
 for ooOooo000oOO in OoO0O00 :
  if 25 - 25: ooOoO - ooOoO * iiIIIII1i1iI
  OOOO0oo0 = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( ooOooo000oOO ) [ 0 ]
  I11iiI1i1 = re . compile ( '<name>(.+?)</name>' ) . findall ( ooOooo000oOO ) [ 0 ]
  if 47 - 47: I1 - Oo0o0ooO0oOOO . iii1II11ii + IIiIiII11i . i11iIiiIii
  if string == OOOO0oo0 :
   o0OIiII = 1
   Oo0OoO00oOO0o = I11iiI1i1
   if 94 - 94: iiIIIII1i1iI * Oo0o0ooO0oOOO / iI1Ii11111iIi / Oo0o0ooO0oOOO
 if o0OIiII == 0 :
  Oo0OoO00oOO0o = string
  if 87 - 87: iI1Ii11111iIi . O0OoOoo00o
 return Oo0OoO00oOO0o
 if 75 - 75: i1iiIII111ii + oO0o0ooO0 + iiIIIII1i1iI * i11iI % O0 . I1
def oO ( name , url , iconimage ) :
 if 31 - 31: O0o0o00o0Oo0 + i11iIiiIii + iI1Ii11111iIi * i1iiIII111ii
 IiII111iI1ii1 = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 IiII111iI1ii1 . setPath ( url )
 xbmc . Player ( ) . play ( url , IiII111iI1ii1 , False )
 quit ( )
 if 37 - 37: O0 - oOOOO % iI1Ii11111iIi
def OOOoo0OO ( ) :
 if 57 - 57: ii1II11I1ii1I / i1iiIII111ii
 o0OOoo0OO0OOO ( "[COLOR white][B]FMG Supported Addons[/B][/COLOR]" , '' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "#####################################" , '' , 999 , iiiii , ooo0OO )
 if 29 - 29: iIiiiI1IiI1I1 + oO0o0ooO0 * ii1II11I1ii1I * O0o0o00o0Oo0 . i11iII1iiI * i11iII1iiI
 iI1 = open ( II1 , mode = 'r' ) ; I1IiiiiI = iI1 . read ( ) ; iI1 . close ( )
 I1IiiiiI = I1IiiiiI . replace ( '\n' , '' )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( I1IiiiiI )
 for ooOooo000oOO in OoO0O00 :
  OOOO0oo0 = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( ooOooo000oOO ) [ 0 ]
  I11iiI1i1 = re . compile ( '<name>(.+?)</name>' ) . findall ( ooOooo000oOO ) [ 0 ]
  if 7 - 7: O0OoOoo00o * oOOOO % Oo0o0ooO0oOOO - iiIIIII1i1iI
  ii1 = xbmc . translatePath ( 'special://home/addons/' + OOOO0oo0 )
  if 13 - 13: Oo0o0ooO0oOOO . i11iIiiIii
  if os . path . exists ( ii1 ) :
   oOOoo00O00o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OOOO0oo0 , 'icon.png' ) )
   O0O00Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OOOO0oo0 , 'fanart.jpg' ) )
   o0OOoo0OO0OOO ( "[COLOR green][B]" + I11iiI1i1 + " - INSTALLED [/B][/COLOR]" , OOOO0oo0 , 5 , oOOoo00O00o , O0O00Oo )
  else :
   o0OOoo0OO0OOO ( "[COLOR red]" + I11iiI1i1 + " - NOT INSTALLED [/COLOR]" , OOOO0oo0 , 5 , iiiii , ooo0OO )
   if 97 - 97: ooOoO * IIiIiII11i . IIiIiII11i
def IIIII ( ) :
 if 33 - 33: oOOOO + I1 * O0 / iIiiiI1IiI1I1 - i11iII1iiI
 O0oO = 0
 if 73 - 73: I11iii11IIi * i11iIiiIii % O0 . I11iii11IIi
 try :
  O00Oo000ooO0 ( "http://www.google.com" )
 except :
  Oo0oO0ooo . ok ( Oo0Ooo , '[COLOR red]Error: It appears you do not currently have an active internet connection. This will cause false positives in the test. Please try again with an active internet connection.[/COLOR]' )
  return
  if 66 - 66: O0 + O0 + i1iiIII111ii / I1 + O0o0o00o0Oo0
 o0oOoO00o . create ( Oo0Ooo , "Checking for repository updates" , '' , 'Please Wait...' )
 o0oOoO00o . update ( 0 )
 IIi1i11111 = open ( I1IiI ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  o0oOoO00o . update ( 25 )
  iIii1111iII = float ( ooOooo000oOO ) + 0.01
  o0O = iIiiiI + str ( iIii1111iII ) + '.zip'
  try :
   iiiiI = O00Oo000ooO0 ( o0O )
   if "Not Found" not in iiiiI :
    o0OIiII = 1
    o0oOoO00o . update ( 75 )
    oOoOo00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( oOoOo00oOo ) :
     os . makedirs ( oOoOo00oOo )
    oooOo0OOOoo0 = os . path . join ( oOoOo00oOo , 'repoupdate.zip' )
    try : os . remove ( oooOo0OOOoo0 )
    except : pass
    o0oOoO00o . update ( 100 )
    o0oOoO00o . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    downloader . download ( o0O , oooOo0OOOoo0 , o0oOoO00o )
    OOoO = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    o0oOoO00o . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    extract . all ( oooOo0OOOoo0 , OOoO , o0oOoO00o )
    try : os . remove ( oooOo0OOOoo0 )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    O0oO = 1
    Oo0oO0ooo . ok ( Oo0Ooo , "ECHO repository was updated to " + str ( iIii1111iII ) + ', you may need to restart the addon for changes to take effect' )
    time . sleep ( 2 )
  except : pass
  if 89 - 89: iiIIIII1i1iI + ii1II11I1ii1I * i11iI * Oo0o0ooO0oOOO
 o0oOoO00o . update ( 75 , "Checking for addon updates" )
 IIi1i11111 = open ( I1ii11iIi11i ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  iIii1111iII = float ( ooOooo000oOO ) + 0.01
  o0O = o0OOO + str ( iIii1111iII ) + '.zip'
  try :
   iiiiI = O00Oo000ooO0 ( o0O )
   if "Not Found" not in iiiiI :
    o0OIiII = 1
    o0oOoO00o . update ( 75 )
    oOoOo00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
    if not os . path . exists ( oOoOo00oOo ) :
     os . makedirs ( oOoOo00oOo )
    oooOo0OOOoo0 = os . path . join ( oOoOo00oOo , 'xxx_o_dus_update.zip' )
    try : os . remove ( oooOo0OOOoo0 )
    except : pass
    o0oOoO00o . update ( 100 )
    o0oOoO00o . update ( 0 , "" , "Downloading Update Please Wait" , "" )
    downloader . download ( o0O , oooOo0OOOoo0 , o0oOoO00o )
    OOoO = xbmc . translatePath ( os . path . join ( 'special://' , 'home/addons' ) )
    o0oOoO00o . update ( 0 , "" , "Extracting Update Please Wait" , "" )
    extract . all ( oooOo0OOOoo0 , OOoO , o0oOoO00o )
    try : os . remove ( oooOo0OOOoo0 )
    except : pass
    xbmc . executebuiltin ( "UpdateLocalAddons" )
    xbmc . executebuiltin ( "UpdateAddonRepos" )
    o0oOoO00o . update ( 100 )
    o0oOoO00o . close
    O0oO = 1
    Oo0oO0ooo . ok ( Oo0Ooo , "FMG was updated to " + str ( iIii1111iII ) + ', you may need to restart the addon for changes to take effect' )
    time . sleep ( 2 )
  except : pass
  if 37 - 37: IIiIiII11i - ooOoO - iiIIIII1i1iI
 if o0oOoO00o . iscanceled ( ) :
  o0oOoO00o . close ( )
  if 77 - 77: O0o0o00o0Oo0 * iIiiiI1IiI1I1
 return O0oO
 if 98 - 98: i11iII1iiI % Oo0o0ooO0oOOO * IIiIiII11i
def OOO00O ( name , url , mode , iconimage , fanartimage ) :
 if 51 - 51: iIiiiI1IiI1I1 . oO0o0ooO0 / O0 + iiIIIII1i1iI
 I11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 iI1i1I11I11 = True
 IiII111iI1ii1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 IiII111iI1ii1 . setProperty ( "fanart_Image" , fanartimage )
 IiII111iI1ii1 . setProperty ( "icon_Image" , iconimage )
 iI1i1I11I11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11 , listitem = IiII111iI1ii1 , isFolder = True )
 return iI1i1I11I11
 if 69 - 69: oO0o0ooO0
def o0OOoo0OO0OOO ( name , url , mode , iconimage , fanartimage ) :
 if 97 - 97: I11iii11IIi % I11iii11IIi % O0 / I1 - iIiiiI1IiI1I1
 I11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 iI1i1I11I11 = True
 IiII111iI1ii1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 IiII111iI1ii1 . setProperty ( "fanart_Image" , fanartimage )
 IiII111iI1ii1 . setProperty ( "icon_Image" , iconimage )
 iI1i1I11I11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11 , listitem = IiII111iI1ii1 , isFolder = False )
 return iI1i1I11I11
 if 69 - 69: oOOOO
def iI ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 ii1I1 = xbmcgui . Window ( id )
 OooooOOoo0 = 50
 while ( OooooOOoo0 > 0 ) :
  try :
   xbmc . sleep ( 10 )
   OooooOOoo0 -= 1
   ii1I1 . getControl ( 1 ) . setLabel ( heading )
   ii1I1 . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 35 - 35: i11iI % O0o0o00o0Oo0 - O0
def O00Oo000ooO0 ( url ) :
 ii1iii1i = urllib2 . Request ( url )
 ii1iii1i . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 Iii1I1111ii = urllib2 . urlopen ( ii1iii1i )
 O0OOO0OOoO0O = Iii1I1111ii . read ( )
 Iii1I1111ii . close ( )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return O0OOO0OOoO0O
 if 72 - 72: iii1II11ii + o0oOOo0O0Ooo + iiIIIII1i1iI
def OOoo0O0 ( url ) :
 ii1iii1i = urllib2 . Request ( url )
 ii1iii1i . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 Iii1I1111ii = urllib2 . urlopen ( ii1iii1i )
 O0OOO0OOoO0O = Iii1I1111ii . read ( )
 Iii1I1111ii . close ( )
 return O0OOO0OOoO0O
 if 94 - 94: O0 . o0oOOo0O0Ooo - iiIIIII1i1iI % ooOoO - ii1II11I1ii1I
 if 72 - 72: Oo0o0ooO0oOOO
 if 1 - 1: ii1II11I1ii1I * O0OoOoo00o * IIiIiII11i + i1iiIII111ii
 if 33 - 33: ooOoO * iiIIIII1i1iI - oOOOO % oOOOO
 if 18 - 18: oOOOO / iI1Ii11111iIi * oOOOO + oOOOO * i11iIiiIii * I11iii11IIi
def I1II1 ( ) :
 if 86 - 86: iIiiiI1IiI1I1 / oO0o0ooO0 . iii1II11ii
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 19 - 19: I11iii11IIi % IIiIiII11i % O0OoOoo00o * iiIIIII1i1iI % ooOoO
 if os . path . exists ( i1 ) == True :
  for ooo , i1i1iI1iiiI , Ooo0oOooo0 in os . walk ( i1 ) :
   oOOOoo00 = 0
   oOOOoo00 += len ( Ooo0oOooo0 )
   if oOOOoo00 > 0 :
    for iI1 in Ooo0oOooo0 :
     try :
      if ( iI1 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( ooo , iI1 ) )
     except :
      pass
    for OOOOo in i1i1iI1iiiI :
     try :
      shutil . rmtree ( os . path . join ( ooo , OOOOo ) )
     except :
      pass
      if 9 - 9: ooOoO % ooOoO - iiIIIII1i1iI
   else :
    pass
    if 51 - 51: i11iII1iiI . iIiiiI1IiI1I1 - I11iii11IIi / ooOoO
 if os . path . exists ( oOOoo00O0O ) == True :
  for ooo , i1i1iI1iiiI , Ooo0oOooo0 in os . walk ( oOOoo00O0O ) :
   oOOOoo00 = 0
   oOOOoo00 += len ( Ooo0oOooo0 )
   if oOOOoo00 > 0 :
    for iI1 in Ooo0oOooo0 :
     try :
      if ( iI1 . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( ooo , iI1 ) )
     except :
      pass
    for OOOOo in i1i1iI1iiiI :
     try :
      shutil . rmtree ( os . path . join ( ooo , OOOOo ) )
     except :
      pass
      if 52 - 52: iiIIIII1i1iI + ooOoO + I1 + iI1Ii11111iIi % I1
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  OO = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 7 - 7: ooOoO * i11iIiiIii * Oo0o0ooO0oOOO + i1iiIII111ii % ii1II11I1ii1I - i1iiIII111ii
  for ooo , i1i1iI1iiiI , Ooo0oOooo0 in os . walk ( OO ) :
   oOOOoo00 = 0
   oOOOoo00 += len ( Ooo0oOooo0 )
   if 39 - 39: iI1Ii11111iIi * O0o0o00o0Oo0 % O0o0o00o0Oo0 - IIiIiII11i + iiIIIII1i1iI - i11iI
   if oOOOoo00 > 0 :
    for iI1 in Ooo0oOooo0 :
     os . unlink ( os . path . join ( ooo , iI1 ) )
    for OOOOo in i1i1iI1iiiI :
     shutil . rmtree ( os . path . join ( ooo , OOOOo ) )
     if 23 - 23: i11iIiiIii
   else :
    pass
  II1iIi11 = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 12 - 12: Oo0o0ooO0oOOO + i11iIiiIii * iIiiiI1IiI1I1 / I11iii11IIi . i11iI
  for ooo , i1i1iI1iiiI , Ooo0oOooo0 in os . walk ( II1iIi11 ) :
   oOOOoo00 = 0
   oOOOoo00 += len ( Ooo0oOooo0 )
   if 5 - 5: o0oOOo0O0Ooo + O0OoOoo00o / iiIIIII1i1iI . I1 / i11iI
   if oOOOoo00 > 0 :
    for iI1 in Ooo0oOooo0 :
     os . unlink ( os . path . join ( ooo , iI1 ) )
    for OOOOo in i1i1iI1iiiI :
     shutil . rmtree ( os . path . join ( ooo , OOOOo ) )
     if 32 - 32: i11iII1iiI % iIiiiI1IiI1I1 / o0oOOo0O0Ooo - i11iII1iiI
   else :
    pass
    if 7 - 7: oOOOO * ii1II11I1ii1I - i1iiIII111ii + O0o0o00o0Oo0 * i11iII1iiI % ii1II11I1ii1I
 Ii11iI1i = IIiiIiI1 ( )
 if 15 - 15: oO0o0ooO0 % i11iII1iiI * i11iI
 for O0OoooO0 in Ii11iI1i :
  ooo0O0o00O = xbmc . translatePath ( O0OoooO0 . path )
  if os . path . exists ( ooo0O0o00O ) == True :
   for ooo , i1i1iI1iiiI , Ooo0oOooo0 in os . walk ( ooo0O0o00O ) :
    oOOOoo00 = 0
    oOOOoo00 += len ( Ooo0oOooo0 )
    if oOOOoo00 > 0 :
     for iI1 in Ooo0oOooo0 :
      os . unlink ( os . path . join ( ooo , iI1 ) )
     for OOOOo in i1i1iI1iiiI :
      shutil . rmtree ( os . path . join ( ooo , OOOOo ) )
      if 48 - 48: i1iiIII111ii / oOOOO . iIiiiI1IiI1I1 * oO0o0ooO0 * O0 / o0oOOo0O0Ooo
    else :
     pass
     if 92 - 92: iI1Ii11111iIi % iI1Ii11111iIi - iiIIIII1i1iI / oO0o0ooO0
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 Oo0oO0ooo . ok ( Oo0Ooo , "The FMG games list has been reloaded." )
 if 10 - 10: I1 + iI1Ii11111iIi * I11iii11IIi + iIiiiI1IiI1I1 / oOOOO / I11iii11IIi
def iI1II ( ) :
 o0OOo0o0O0O = [ ]
 o0 = sys . argv [ 2 ]
 if len ( o0 ) >= 2 :
  OO0o0oOOO0O = sys . argv [ 2 ]
  iII1i11 = OO0o0oOOO0O . replace ( '?' , '' )
  if ( OO0o0oOOO0O [ len ( OO0o0oOOO0O ) - 1 ] == '/' ) :
   OO0o0oOOO0O = OO0o0oOOO0O [ 0 : len ( OO0o0oOOO0O ) - 2 ]
  OooIiIIII1i11I = iII1i11 . split ( '&' )
  o0OOo0o0O0O = { }
  for OOOiII1 in range ( len ( OooIiIIII1i11I ) ) :
   OOo = { }
   OOo = OooIiIIII1i11I [ OOOiII1 ] . split ( '=' )
   if ( len ( OOo ) ) == 2 :
    o0OOo0o0O0O [ OOo [ 0 ] ] = OOo [ 1 ]
 return o0OOo0o0O0O
 if 22 - 22: oO0o0ooO0 * ooOoO . O0OoOoo00o * i11iIiiIii - i11iII1iiI * i1iiIII111ii
def iI1II ( ) :
 o0OOo0o0O0O = [ ]
 o0 = sys . argv [ 2 ]
 if len ( o0 ) >= 2 :
  OO0o0oOOO0O = sys . argv [ 2 ]
  iII1i11 = OO0o0oOOO0O . replace ( '?' , '' )
  if ( OO0o0oOOO0O [ len ( OO0o0oOOO0O ) - 1 ] == '/' ) :
   OO0o0oOOO0O = OO0o0oOOO0O [ 0 : len ( OO0o0oOOO0O ) - 2 ]
  OooIiIIII1i11I = iII1i11 . split ( '&' )
  o0OOo0o0O0O = { }
  for OOOiII1 in range ( len ( OooIiIIII1i11I ) ) :
   OOo = { }
   OOo = OooIiIIII1i11I [ OOOiII1 ] . split ( '=' )
   if ( len ( OOo ) ) == 2 :
    o0OOo0o0O0O [ OOo [ 0 ] ] = OOo [ 1 ]
    if 59 - 59: iI1Ii11111iIi % IIiIiII11i . I1 / O0OoOoo00o + i11iII1iiI
 return o0OOo0o0O0O
 if 76 - 76: i1iiIII111ii
OO0o0oOOO0O = iI1II ( ) ; Oo0OoO00oOO0o = None ; o0O = None ; OoO0O00O0oo0O = None ; oOOoo00O00o = None ; I1IiI11 = None
try : Oo0OoO00oOO0o = urllib . unquote_plus ( OO0o0oOOO0O [ "name" ] )
except : pass
try : o0O = urllib . unquote_plus ( OO0o0oOOO0O [ "url" ] )
except : pass
try : OoO0O00O0oo0O = int ( OO0o0oOOO0O [ "mode" ] )
except : pass
try : oOOoo00O00o = urllib . unquote_plus ( OO0o0oOOO0O [ "iconimage" ] )
except : pass
try : I1IiI11 = urllib . quote_plus ( OO0o0oOOO0O [ "fanartimage" ] )
except : pass
if 9 - 9: i11iI
if OoO0O00O0oo0O == None or o0O == None or len ( o0O ) < 1 : oOOo0oo ( )
elif OoO0O00O0oo0O == 1 : Get_Content ( Oo0OoO00oOO0o , o0O , oOOoo00O00o )
elif OoO0O00O0oo0O == 2 : o0oo ( Oo0OoO00oOO0o , o0O , oOOoo00O00o )
elif OoO0O00O0oo0O == 3 : oO ( Oo0OoO00oOO0o , o0O , oOOoo00O00o )
elif OoO0O00O0oo0O == 4 : OOOoo0OO ( )
elif OoO0O00O0oo0O == 5 : xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + o0O + ')' )
elif OoO0O00O0oo0O == 6 : I1II1 ( )
if 64 - 64: iIiiiI1IiI1I1 / i11iII1iiI . iii1II11ii + IIiIiII11i . ii1II11I1ii1I
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )