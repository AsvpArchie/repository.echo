import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.FMG'
Oo0Ooo = '[COLOR orangered]FIND MY GAME[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( 'special://home/addons/' + OO0o )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pl.png' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/supported_addons.xml' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/notice.txt' ) )
if 27 - 27: iIiiiI1IiI1I1 * IIiIiII11i * IiIIi1I1Iiii - Ooo00oOo00o
I1IiI = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
o0OOO = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
iIiiiI = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uRk1HL3BsdWdpbi52aWRlby5GTUct' )
Iii1ii1II11i = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
if 10 - 10: I1iII1iiII + I1Ii111 / OOo
i1i1II = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O0oo0OO0 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcveHJkU3pOVUM=' )
I1i1iiI1 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvaXF6Vmp3ZXc=' )
iiIIIII1i1iI = xbmcgui . Dialog ( )
o0oO0 = xbmcgui . DialogProgress ( )
oo00 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
o00 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * Ooo0 % oo00000o0
I11i1i11i1I = xbmc . getInfoLabel ( "System.BuildVersion" )
Iiii = float ( I11i1i11i1I [ : 4 ] )
if Iiii >= 11.0 and Iiii <= 11.9 :
 OOO0O = 'Eden'
if Iiii >= 12.0 and Iiii <= 12.9 :
 OOO0O = 'Frodo'
if Iiii >= 13.0 and Iiii <= 13.9 :
 OOO0O = 'Gotham'
if Iiii >= 14.0 and Iiii <= 14.9 :
 OOO0O = 'Helix'
if Iiii >= 15.0 and Iiii <= 15.9 :
 OOO0O = 'Isengard'
if Iiii >= 16.0 and Iiii <= 16.9 :
 OOO0O = 'Jarvis'
if Iiii >= 17.0 and Iiii <= 17.9 :
 OOO0O = 'Krypton'
 if 94 - 94: oooO0oOOOOo0o
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 93 - 93: OoOoo0 % iIiiI1 % OOooO % OOoO00o
class II111iiii ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 48 - 48: I1Ii . i11iIiiIii - OoOoo0 % II1ii . I1Ii / iIi1IIii11I
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 6 - 6: o0oOoO00o * iIiiI1
O00O0O0O0 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 75 - 75: Ooo00oOo00o / OoOoo0 - iIi1IIii11I
class oo :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 28 - 28: IIiIiII11i - Ooo00oOo00o
  if 70 - 70: II1ii . II1ii - II1ii / oo0 * oo00000o0
  if 86 - 86: i11iIiiIii + OoOoo0 + I1Ii * oooO0oOOOOo0o + iIi1IIii11I
  if 61 - 61: II1ii / i11iIiiIii
def IiIiIi ( ) :
 II = 5
 iI = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 iI11iiiI1II = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 79 - 79: OOoO00o % i11iIiiIii / IIiIiII11i . oo00000o0
 o0oO0o00oo = [ ]
 if 32 - 32: OOo * iIiiiI1IiI1I1 % Ooo0 % OoOoo0 . OOooO
 for o0OOOOO00o0O0 in range ( II ) :
  o0oO0o00oo . append ( oo ( iI [ o0OOOOO00o0O0 ] , iI11iiiI1II [ o0OOOOO00o0O0 ] ) )
  if 71 - 71: I1Ii % iIiiI1 / iIi1IIii11I
 return o0oO0o00oo
 if 49 - 49: I1iII1iiII % iIiiI1 * iIiiiI1IiI1I1
def oOOo0oo ( ) :
 if 80 - 80: oooO0oOOOOo0o * i11iIiiIii / OOoO00o
 if not os . path . isfile ( O00ooooo00 ) :
  I11II1i = open ( O00ooooo00 , 'w' )
  if 23 - 23: oo0 / iIi1IIii11I + oooO0oOOOOo0o + oooO0oOOOOo0o / I1iII1iiII
 if not os . path . isfile ( I1IiiI ) :
  I11II1i = open ( I1IiiI , 'w' )
  if 26 - 26: IiIIi1I1Iiii
 IiiI11Iiiii = ii1I1i1I ( I1i1iiI1 )
 if len ( IiiI11Iiiii ) > 1 :
  OOoo0O0 = I1IiiI
  iiiIi1i1I = open ( OOoo0O0 )
  oOO00oOO = iiiIi1i1I . read ( )
  if oOO00oOO == IiiI11Iiiii : pass
  else :
   OoOo ( '[B][COLOR white]Find My Game Notice[/COLOR][/B]' , IiiI11Iiiii )
   iIo00O = open ( OOoo0O0 , "w" )
   iIo00O . write ( IiiI11Iiiii )
   iIo00O . close ( )
   if 69 - 69: Ooo0 % OOoO00o - iIi1IIii11I + OOoO00o - iIiiiI1IiI1I1 % IiIIi1I1Iiii
 Iii111II = ii1I1i1I ( O0oo0OO0 )
 if len ( Iii111II ) > 1 :
  OOoo0O0 = O00ooooo00
  iiiIi1i1I = open ( OOoo0O0 )
  oOO00oOO = iiiIi1i1I . read ( )
  if oOO00oOO == Iii111II : pass
  else :
   iIo00O = open ( OOoo0O0 , "w" )
   iIo00O . write ( Iii111II )
   iIo00O . close ( )
   if 9 - 9: II1ii
 i11 = datetime . date . today ( )
 O0oo0OO0oOOOo = datetime . datetime . strftime ( i11 , '%A %d %B %Y' )
 if 35 - 35: OOooO % I1Ii111
 o0OOoo0OO0OOO ( '[COLOR orangered][B]EVENTS FOR ' + str ( O0oo0OO0oOOOo ) . upper ( ) + '[/B][/COLOR]' , '' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 if 19 - 19: Ooo0 % Ooo00oOo00o % iIi1IIii11I
 oo0OooOOo0 = datetime . datetime . now ( )
 o0O = 'http://echocoder.com/private/addons/fmg/days/'
 O00oO = oo0OooOOo0 . day
 if 39 - 39: OOooO - I1iII1iiII * II1ii % iIi1IIii11I * I1iII1iiII % I1iII1iiII
 OoOOOOO = O00oO
 if 33 - 33: oo0 % Ooo00oOo00o
 o0O = o0O + str ( OoOOOOO ) + '.xml'
 if 78 - 78: oooO0oOOOOo0o
 OO00Oo = o0O
 O0OOO0OOoO0O = O00Oo000ooO0 ( o0O )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0OOO0OOoO0O )
 if 5 - 5: OOo / iIi1IIii11I . OoOoo0 - iIiiiI1IiI1I1 / OOooO
 for ooOooo000oOO in OoO0O00 :
  if 59 - 59: I1iII1iiII + IiIIi1I1Iiii * o0oOoO00o + Ooo00oOo00o
  Oo0OoO00oOO0o = re . compile ( '<title>(.+?)</title>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0O = OO00Oo + "!" + Oo0OoO00oOO0o
  try :
   Oo0OoO00oOO0o , time = Oo0OoO00oOO0o . split ( ' - ' )
   Oo0OoO00oOO0o = '[B][COLOR white]' + Oo0OoO00oOO0o + '[/COLOR] - [COLOR orangered]' + time + '[/B][/COLOR]'
  except :
   Oo0OoO00oOO0o = '[B][COLOR white]' + Oo0OoO00oOO0o + '[/B][/COLOR]'
  OOO00O ( Oo0OoO00oOO0o , o0O , 2 , II1 , ooo0OO )
  if 84 - 84: Ooo0 * II1ii / oooO0oOOOOo0o - iIiiiI1IiI1I1
 o0OOoo0OO0OOO ( '[COLOR orangered]Refresh List of Games[/COLOR]' , 'url' , 6 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 OOO00O ( '[COLOR orangered]FMG Supported Addons[/COLOR]' , 'url' , 4 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @EchoCoder[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @blue_builds[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 if 30 - 30: IIiIiII11i / I1Ii - OOoO00o - I1iII1iiII % iIiiI1
 IIi1i11111 = open ( I1IiI ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  I1ii11iI = float ( ooOooo000oOO )
 IIi1i11111 = open ( o0OOO ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  IIi1i = float ( ooOooo000oOO )
  if 46 - 46: OOoO00o % oooO0oOOOOo0o + II1ii . o0oOoO00o . II1ii
 o0OOoo0OO0OOO ( "[COLOR orangered]Addon Version:[/COLOR] [COLOR white]" + str ( I1ii11iI ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "[COLOR orangered]Repository Version:[/COLOR] [COLOR white]" + str ( IIi1i ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 if 96 - 96: OOo
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 45 - 45: iIiiiI1IiI1I1 * iIi1IIii11I % OOo * IiIIi1I1Iiii + iIiiI1 . o0oOoO00o
def Oo0ooOo0o ( name , url , iconimage ) :
 if 22 - 22: IIiIiII11i / i11iIiiIii * IIiIiII11i * I1iII1iiII . oo00000o0 / i11iIiiIii
 try :
  url , IiiiOO0OoO0o00 = url . split ( '!' )
 except :
  iiIIIII1i1iI . ok ( Oo0Ooo , "[COLOR white]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 53 - 53: iIiiiI1IiI1I1 * II1ii + oo00000o0
 Ii = [ ]
 if 61 - 61: I1iII1iiII
 O0OOO0OOoO0O = O00Oo000ooO0 ( url )
 O0OOO = re . compile ( '<title>' + re . escape ( IiiiOO0OoO0o00 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0OOO0OOoO0O ) [ 0 ]
 II11iIiIIIiI = re . compile ( '<search>(.+?)</search>' ) . findall ( O0OOO )
 for o0o in II11iIiIIIiI :
  Ii . append ( o0o )
  if 84 - 84: iIiiiI1IiI1I1
 o0oO0 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 o0oO0 . update ( 0 )
 if 74 - 74: oo0 - I1Ii111 - OOo . OoOoo0 - OOooO
 OOOoOoo0O = [ ]
 O000OOo00oo = [ ]
 o0oO0 . update ( 0 )
 oo0OOo = ii1I1i1I ( "http://echocoder.com/private/addons/fmg/addons.ini" )
 if 64 - 64: oooO0oOOOOo0o
 oo0OOo = oo0OOo . replace ( '\r' , '' )
 oo0OOo = oo0OOo . split ( '\n' )
 for iI11Ii in oo0OOo :
  if 6 - 6: Ooo0
  try :
   IIi1i11111 = iI11Ii . split ( '=' ) [ 0 ]
   ooOO00O00oo = str ( IIi1i11111 )
   oOOo0oOo0 = ooOO00O00oo + '='
   IIooooo = str ( iI11Ii )
   II1I = IIooooo . replace ( oOOo0oOo0 , '' )
   ooOO00O00oo = ooOO00O00oo . strip ( )
   II1I = II1I . strip ( )
   OOOoOoo0O . append ( ooOO00O00oo )
   O000OOo00oo . append ( II1I )
   O0 = list ( zip ( OOOoOoo0O , O000OOo00oo ) )
  except : pass
 i1II1Iiii1I11 = sorted ( O0 )
 IIII = sorted ( Ii )
 if 32 - 32: IiIIi1I1Iiii / IIiIiII11i - iIi1IIii11I
 o0oO0 . update ( 100 )
 if 91 - 91: iIiiI1 % Ooo00oOo00o % IIiIiII11i
 IIi1I11I1II = [ ]
 OooOoooOo = [ ]
 ii11IIII11I = [ ]
 OOooo = [ ]
 oOooOOOoOo = [ ]
 if 41 - 41: OoOoo0 - iIiiiI1IiI1I1 - iIiiiI1IiI1I1
 for oO00OOoO00 in IIII :
  if 40 - 40: I1Ii111 * OoOoo0 + oo00000o0 % iIiiI1
  OOOOOoo0 = oO00OOoO00 . split ( ' ' )
  if 49 - 49: iIiiiI1IiI1I1 . iIiiI1
  for name , url in i1II1Iiii1I11 :
   if oO00OOoO00 . lower ( ) in name . lower ( ) :
    try :
     I1iI1iIi111i = name
     IIi1i11111 = url . split ( "in://" ) [ 1 ]
     ooOO00O00oo = IIi1i11111 . split ( "/" ) [ 0 ]
     iiIi1IIi1I = xbmc . translatePath ( 'special://home/addons/' + ooOO00O00oo )
     if 84 - 84: I1Ii * I1iII1iiII + OOo
     if os . path . exists ( iiIi1IIi1I ) :
      iconimage = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + ooOO00O00oo , 'icon.png' ) )
      O0ooO0Oo00o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + ooOO00O00oo , 'fanart.jpg' ) )
      name = ooO0oOOooOo0 ( ooOO00O00oo )
      i1I1ii11i1Iii = "[COLOR white][B]" + name + '[/B][/COLOR] - [COLOR orangered]' + I1iI1iIi111i + "[/COLOR]"
      IIi1I11I1II . append ( "1" )
      OooOoooOo . append ( i1I1ii11i1Iii )
      ii11IIII11I . append ( url )
      OOooo . append ( iconimage )
      oOooOOOoOo . append ( O0ooO0Oo00o )
     else :
      IIi1I11I1II . append ( "0" )
      name = ooO0oOOooOo0 ( ooOO00O00oo )
      i1I1ii11i1Iii = '[COLOR darkgray]' + name + ' - ' + I1iI1iIi111i + ' | Addon Not Installed[/COLOR]'
      OooOoooOo . append ( i1I1ii11i1Iii )
      ii11IIII11I . append ( url )
      OOooo . append ( iiiii )
      oOooOOOoOo . append ( ooo0OO )
     I1IiiiiI = list ( zip ( IIi1I11I1II , OooOoooOo , ii11IIII11I , OOooo , oOooOOOoOo ) )
    except : pass
  OOOOOoo0 = ""
  if 80 - 80: OOoO00o . i11iIiiIii - iIi1IIii11I
 try :
  iIiIIi1 = sorted ( I1IiiiiI , key = lambda o0OOOOO00o0O0 : int ( o0OOOOO00o0O0 [ 0 ] ) , reverse = True )
  iIiIIi1 = sorted ( iIiIIi1 , reverse = True )
  for I1IIII1i , name , url , iconimage , O0ooO0Oo00o in iIiIIi1 :
   o0OOoo0OO0OOO ( name , url , 3 , iconimage , O0ooO0Oo00o )
  o0oO0 . close ( )
 except :
  o0oO0 . close ( )
  iiIIIII1i1iI . ok ( Oo0Ooo , "Sorry, no links were found." )
  quit ( )
  if 2 - 2: oooO0oOOOOo0o + OoOoo0 - I1Ii111 % iIi1IIii11I . iIiiI1
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 18 - 18: oo00000o0 + iIiiI1 - OoOoo0 . I1iII1iiII + i11iIiiIii
def ooO0oOOooOo0 ( string ) :
 if 20 - 20: OOoO00o
 I11II1i = open ( O00ooooo00 , mode = 'r' ) ; Oo0oO00o = I11II1i . read ( ) ; I11II1i . close ( )
 Oo0oO00o = Oo0oO00o . replace ( '\n' , '' )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( Oo0oO00o )
 i11I1II1I11i = 0
 for ooOooo000oOO in OoO0O00 :
  if 61 - 61: I1Ii111 - oo00000o0 . Ooo0 / oo00000o0 + OOo
  I1i11i = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o00oO0oo0OO = re . compile ( '<name>(.+?)</name>' ) . findall ( ooOooo000oOO ) [ 0 ]
  if 57 - 57: OOoO00o % OoOoo0 + iIi1IIii11I - OOo
  if string == I1i11i :
   i11I1II1I11i = 1
   Oo0OoO00oOO0o = o00oO0oo0OO
   if 65 - 65: oooO0oOOOOo0o . o0oOoO00o
 if i11I1II1I11i == 0 :
  Oo0OoO00oOO0o = string
  if 39 - 39: I1iII1iiII / I1Ii + OOoO00o / o0oOoO00o
 return Oo0OoO00oOO0o
 if 13 - 13: OOooO + iIiiiI1IiI1I1 + iIiiI1 % I1Ii111 / iIi1IIii11I . OOooO
def OO0Oooo0oOO0O ( name , url , iconimage ) :
 if 62 - 62: I1Ii111
 O00o0OO0 = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 O00o0OO0 . setPath ( url )
 xbmc . Player ( ) . play ( url , O00o0OO0 , False )
 quit ( )
 if 35 - 35: Ooo0 % I1Ii / OOoO00o + IIiIiII11i . IiIIi1I1Iiii . I1Ii111
def o00oOOooOOo0o ( ) :
 if 66 - 66: iIiiI1 - iIiiI1 - i11iIiiIii . oo0 - oo00000o0
 o0OOoo0OO0OOO ( "[COLOR white][B]FMG Supported Addons[/B][/COLOR]" , '' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "#####################################" , '' , 999 , iiiii , ooo0OO )
 if 77 - 77: o0oOoO00o - I1iII1iiII - I1Ii
 IiiiIIiIi1 = [ ]
 OoOOoOooooOOo = [ ]
 oOo0O = [ ]
 O000OOo00oo = [ ]
 oo0O0 = [ ]
 if 22 - 22: o0oOoO00o . oo00000o0 * o0oOoO00o
 I11II1i = open ( O00ooooo00 , mode = 'r' ) ; Oo0oO00o = I11II1i . read ( ) ; I11II1i . close ( )
 Oo0oO00o = Oo0oO00o . replace ( '\n' , '' )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( Oo0oO00o )
 for ooOooo000oOO in sorted ( OoO0O00 ) :
  I1i11i = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o00oO0oo0OO = re . compile ( '<name>(.+?)</name>' ) . findall ( ooOooo000oOO ) [ 0 ]
  O000OOO = re . compile ( '<dev>(.+?)</dev>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0O = o00oO0oo0OO + '|SPLIT|' + I1i11i + '|SPLIT|' + O000OOO
  if 20 - 20: iIi1IIii11I . I1iII1iiII % oo00000o0 * IIiIiII11i
  iiIi1IIi1I = xbmc . translatePath ( 'special://home/addons/' + I1i11i )
  if os . path . exists ( iiIi1IIi1I ) :
   I1IIII1i = "1"
  else : I1IIII1i = "0"
  IiiiIIiIi1 . append ( I1i11i )
  OoOOoOooooOOo . append ( o00oO0oo0OO )
  oOo0O . append ( O000OOO )
  O000OOo00oo . append ( o0O )
  oo0O0 . append ( I1IIII1i )
  O0 = list ( zip ( oo0O0 , IiiiIIiIi1 , OoOOoOooooOOo , oOo0O , O000OOo00oo ) )
  if 98 - 98: I1Ii111 % OoOoo0 * IiIIi1I1Iiii
 i1II1Iiii1I11 = sorted ( O0 , key = lambda o0OOOOO00o0O0 : int ( o0OOOOO00o0O0 [ 0 ] ) , reverse = True )
 for I1IIII1i , I1i11i , o00oO0oo0OO , O000OOO , o0O in i1II1Iiii1I11 :
  iiIi1IIi1I = xbmc . translatePath ( 'special://home/addons/' + I1i11i )
  if os . path . exists ( iiIi1IIi1I ) :
   o0O = o0O + '|SPLIT|1'
   Oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + I1i11i , 'icon.png' ) )
   O0ooO0Oo00o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + I1i11i , 'fanart.jpg' ) )
   o0OOoo0OO0OOO ( "[COLOR white][B]" + o00oO0oo0OO + " - INSTALLED [/B][/COLOR]" , o0O , 5 , Oo , O0ooO0Oo00o )
  else :
   o0O = o0O + '|SPLIT|0'
   o0OOoo0OO0OOO ( "[COLOR darkgray]" + o00oO0oo0OO + " - NOT INSTALLED [/COLOR]" , o0O , 5 , iiiii , ooo0OO )
   if 34 - 34: Ooo0 + I1Ii111 - Ooo0
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 17 - 17: I1iII1iiII % iIiiI1 + oooO0oOOOOo0o - iIiiI1 / oo00000o0 + I1Ii
def O0oO000O0O ( url ) :
 if 18 - 18: iIiiI1 - oo00000o0 . OOoO00o . IIiIiII11i
 Oo0OoO00oOO0o , url , O000OOO , I1IIII1i = url . split ( '|SPLIT|' )
 if 2 - 2: oo00000o0 . II1ii
 iiIIIII1i1iI . ok ( Oo0Ooo , "You can contact the developer of " + Oo0OoO00oOO0o + " on:" , "[COLOR orangered]" + O000OOO + "[/COLOR]" )
 if 78 - 78: oooO0oOOOOo0o * IIiIiII11i . I1Ii111 / iIi1IIii11I - IiIIi1I1Iiii / OOoO00o
 if I1IIII1i == "1" :
  i1I1IiiIi1i = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to launch ' + Oo0OoO00oOO0o + ' now?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if i1I1IiiIi1i == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
 else :
  i1I1IiiIi1i = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]' + Oo0OoO00oOO0o + ' is not installed. If the addon is available for download in any repository currently installed on your system we can attempt to install the addon. Would you like us to try and install ' + Oo0OoO00oOO0o + '?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if i1I1IiiIi1i == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
   if 29 - 29: I1Ii111 % I1Ii111
def OOO00O ( name , url , mode , iconimage , fanartimage ) :
 if 94 - 94: IIiIiII11i / OOo % iIiiI1 * iIiiI1 * I1iII1iiII
 IIiIiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 OOO = True
 O00o0OO0 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 O00o0OO0 . setProperty ( "fanart_Image" , fanartimage )
 O00o0OO0 . setProperty ( "icon_Image" , iconimage )
 OOO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIiIiI , listitem = O00o0OO0 , isFolder = True )
 return OOO
 if 25 - 25: Ooo0 - II1ii . IIiIiII11i % i11iIiiIii % oo0
def o0OOoo0OO0OOO ( name , url , mode , iconimage , fanartimage ) :
 if 93 - 93: OOooO * IiIIi1I1Iiii + I1Ii
 IIiIiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 OOO = True
 O00o0OO0 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 O00o0OO0 . setProperty ( "fanart_Image" , fanartimage )
 O00o0OO0 . setProperty ( "icon_Image" , iconimage )
 OOO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIiIiI , listitem = O00o0OO0 , isFolder = False )
 return OOO
 if 33 - 33: iIiiiI1IiI1I1 * iIi1IIii11I - OOoO00o % OOoO00o
def OoOo ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 I11I = xbmcgui . Window ( id )
 I11iIi1i1II11 = 50
 while ( I11iIi1i1II11 > 0 ) :
  try :
   xbmc . sleep ( 10 )
   I11iIi1i1II11 -= 1
   I11I . getControl ( 1 ) . setLabel ( heading )
   I11I . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 47 - 47: IiIIi1I1Iiii . o0oOoO00o
def O00Oo000ooO0 ( url ) :
 i1I1i111Ii = urllib2 . Request ( url )
 i1I1i111Ii . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 ooo = urllib2 . urlopen ( i1I1i111Ii )
 O0OOO0OOoO0O = ooo . read ( )
 ooo . close ( )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return O0OOO0OOoO0O
 if 27 - 27: I1Ii % I1Ii111
def ii1I1i1I ( url ) :
 i1I1i111Ii = urllib2 . Request ( url )
 i1I1i111Ii . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 ooo = urllib2 . urlopen ( i1I1i111Ii )
 O0OOO0OOoO0O = ooo . read ( )
 ooo . close ( )
 return O0OOO0OOoO0O
 if 73 - 73: oo00000o0
 if 70 - 70: IIiIiII11i
 if 31 - 31: OOooO - I1Ii111 % IIiIiII11i
 if 92 - 92: Ooo00oOo00o - IIiIiII11i
 if 16 - 16: II1ii - o0oOoO00o - oo00000o0 - Ooo00oOo00o / OoOoo0
def o0oOoOO ( ) :
 if 58 - 58: I1Ii111
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 53 - 53: Ooo00oOo00o
 if os . path . exists ( oo00 ) == True :
  for o0OOOoO0 , o0OoOo00o0o , I1II1I11I1I in os . walk ( oo00 ) :
   OoOO0o = 0
   OoOO0o += len ( I1II1I11I1I )
   if OoOO0o > 0 :
    for I11II1i in I1II1I11I1I :
     try :
      if ( I11II1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o0OOOoO0 , I11II1i ) )
     except :
      pass
    for IIooooo in o0OoOo00o0o :
     try :
      shutil . rmtree ( os . path . join ( o0OOOoO0 , IIooooo ) )
     except :
      pass
      if 1 - 1: I1iII1iiII
   else :
    pass
    if 68 - 68: iIiiI1 - I1Ii111 / OOoO00o / oooO0oOOOOo0o
 if os . path . exists ( o00 ) == True :
  for o0OOOoO0 , o0OoOo00o0o , I1II1I11I1I in os . walk ( o00 ) :
   OoOO0o = 0
   OoOO0o += len ( I1II1I11I1I )
   if OoOO0o > 0 :
    for I11II1i in I1II1I11I1I :
     try :
      if ( I11II1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( o0OOOoO0 , I11II1i ) )
     except :
      pass
    for IIooooo in o0OoOo00o0o :
     try :
      shutil . rmtree ( os . path . join ( o0OOOoO0 , IIooooo ) )
     except :
      pass
      if 12 - 12: OoOoo0 + i11iIiiIii * IIiIiII11i / oo0 . oooO0oOOOOo0o
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  Iii1iI = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 29 - 29: I1Ii111 % oo00000o0 - I1Ii111 / oo00000o0 . Ooo00oOo00o
  for o0OOOoO0 , o0OoOo00o0o , I1II1I11I1I in os . walk ( Iii1iI ) :
   OoOO0o = 0
   OoOO0o += len ( I1II1I11I1I )
   if 31 - 31: OOoO00o
   if OoOO0o > 0 :
    for I11II1i in I1II1I11I1I :
     os . unlink ( os . path . join ( o0OOOoO0 , I11II1i ) )
    for IIooooo in o0OoOo00o0o :
     shutil . rmtree ( os . path . join ( o0OOOoO0 , IIooooo ) )
     if 88 - 88: II1ii - I1Ii + oo00000o0 * I1Ii111 % IIiIiII11i + OOo
   else :
    pass
  oo000O0OoooO = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 93 - 93: oooO0oOOOOo0o . I1iII1iiII / Ooo0 % IiIIi1I1Iiii * oooO0oOOOOo0o % oo0
  for o0OOOoO0 , o0OoOo00o0o , I1II1I11I1I in os . walk ( oo000O0OoooO ) :
   OoOO0o = 0
   OoOO0o += len ( I1II1I11I1I )
   if 48 - 48: I1Ii / OOoO00o . IIiIiII11i * o0oOoO00o * Ooo0 / Ooo00oOo00o
   if OoOO0o > 0 :
    for I11II1i in I1II1I11I1I :
     os . unlink ( os . path . join ( o0OOOoO0 , I11II1i ) )
    for IIooooo in o0OoOo00o0o :
     shutil . rmtree ( os . path . join ( o0OOOoO0 , IIooooo ) )
     if 92 - 92: OOo % OOo - iIi1IIii11I / o0oOoO00o
   else :
    pass
    if 10 - 10: iIiiI1 + OOo * oo0 + IIiIiII11i / OOoO00o / oo0
 o0oO0o00oo = IiIiIi ( )
 if 42 - 42: I1Ii111
 for II1i11I in o0oO0o00oo :
  ii1I1IIii11 = xbmc . translatePath ( II1i11I . path )
  if os . path . exists ( ii1I1IIii11 ) == True :
   for o0OOOoO0 , o0OoOo00o0o , I1II1I11I1I in os . walk ( ii1I1IIii11 ) :
    OoOO0o = 0
    OoOO0o += len ( I1II1I11I1I )
    if OoOO0o > 0 :
     for I11II1i in I1II1I11I1I :
      os . unlink ( os . path . join ( o0OOOoO0 , I11II1i ) )
     for IIooooo in o0OoOo00o0o :
      shutil . rmtree ( os . path . join ( o0OOOoO0 , IIooooo ) )
      if 67 - 67: iIiiI1 + oooO0oOOOOo0o / iIi1IIii11I . Ooo0 + oo00000o0
    else :
     pass
     if 62 - 62: i11iIiiIii + i11iIiiIii - iIi1IIii11I
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 iiIIIII1i1iI . ok ( Oo0Ooo , "The FMG games list has been reloaded." )
 if 28 - 28: iIiiI1 . iIiiI1 % IIiIiII11i * IIiIiII11i . iIi1IIii11I / iIiiI1
def iII1i1 ( ) :
 O0oOOoooOO0O = [ ]
 ooo00Ooo = sys . argv [ 2 ]
 if len ( ooo00Ooo ) >= 2 :
  Oo0o0O00 = sys . argv [ 2 ]
  ii1 = Oo0o0O00 . replace ( '?' , '' )
  if ( Oo0o0O00 [ len ( Oo0o0O00 ) - 1 ] == '/' ) :
   Oo0o0O00 = Oo0o0O00 [ 0 : len ( Oo0o0O00 ) - 2 ]
  I1i11 = ii1 . split ( '&' )
  O0oOOoooOO0O = { }
  for OO in range ( len ( I1i11 ) ) :
   o0O0oo0OO0O = { }
   o0O0oo0OO0O = I1i11 [ OO ] . split ( '=' )
   if ( len ( o0O0oo0OO0O ) ) == 2 :
    O0oOOoooOO0O [ o0O0oo0OO0O [ 0 ] ] = o0O0oo0OO0O [ 1 ]
    if 68 - 68: Ooo0 . oooO0oOOOOo0o % IiIIi1I1Iiii . oooO0oOOOOo0o
 return O0oOOoooOO0O
 if 64 - 64: IIiIiII11i / I1Ii111 . I1iII1iiII + IiIIi1I1Iiii . II1ii
Oo0o0O00 = iII1i1 ( ) ; Oo0OoO00oOO0o = None ; o0O = None ; oO = None ; Oo = None ; IIiIi = None
try : Oo0OoO00oOO0o = urllib . unquote_plus ( Oo0o0O00 [ "name" ] )
except : pass
try : o0O = urllib . unquote_plus ( Oo0o0O00 [ "url" ] )
except : pass
try : oO = int ( Oo0o0O00 [ "mode" ] )
except : pass
try : Oo = urllib . unquote_plus ( Oo0o0O00 [ "iconimage" ] )
except : pass
try : IIiIi = urllib . quote_plus ( Oo0o0O00 [ "fanartimage" ] )
except : pass
if 91 - 91: oo0 * OOo / I1Ii111 . iIiiiI1IiI1I1 + II1ii + o0oOoO00o
if oO == None or o0O == None or len ( o0O ) < 1 : oOOo0oo ( )
elif oO == 1 : Get_Content ( Oo0OoO00oOO0o , o0O , Oo )
elif oO == 2 : Oo0ooOo0o ( Oo0OoO00oOO0o , o0O , Oo )
elif oO == 3 : OO0Oooo0oOO0O ( Oo0OoO00oOO0o , o0O , Oo )
elif oO == 4 : o00oOOooOOo0o ( )
elif oO == 5 : O0oO000O0O ( o0O )
elif oO == 6 : o0oOoOO ( )
if 8 - 8: Ooo0 / oo0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )