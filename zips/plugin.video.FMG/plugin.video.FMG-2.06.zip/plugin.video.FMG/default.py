import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.FMG'
Oo0Ooo = '[COLOR orangered]FIND MY GAME[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( 'special://home/addons/' + OO0o )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pl.png' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/cleaner.xml' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/supported_addons.xml' ) )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/notice.txt' ) )
if 39 - 39: O0 - ooOO00oOo % oOo0O0Ooo * Ooo00oOo00o . oOoO0oo0OOOo + iiiiIi11i
Ii1I = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
IiiIII111iI = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
IiII = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uRk1HL3BsdWdpbi52aWRlby5GTUct' )
iI1Ii11111iIi = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
if 41 - 41: I1II1
Ooo0OO0oOO = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
oooO0oo0oOOOO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdmFZS3NkRmI=' )
O0oO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvTlBKU0Q1amQ=' )
o0oO0 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvdXFTRGpHbXY=' )
oo00 = xbmcgui . Dialog ( )
o00 = xbmcgui . DialogProgress ( )
Oo0oO0ooo = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
o0oOoO00o = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
if 43 - 43: O0OOo . II1Iiii1111i
i1IIi11111i = xbmc . getInfoLabel ( "System.BuildVersion" )
o000o0o00o0Oo = float ( i1IIi11111i [ : 4 ] )
if o000o0o00o0Oo >= 11.0 and o000o0o00o0Oo <= 11.9 :
 oo = 'Eden'
if o000o0o00o0Oo >= 12.0 and o000o0o00o0Oo <= 12.9 :
 oo = 'Frodo'
if o000o0o00o0Oo >= 13.0 and o000o0o00o0Oo <= 13.9 :
 oo = 'Gotham'
if o000o0o00o0Oo >= 14.0 and o000o0o00o0Oo <= 14.9 :
 oo = 'Helix'
if o000o0o00o0Oo >= 15.0 and o000o0o00o0Oo <= 15.9 :
 oo = 'Isengard'
if o000o0o00o0Oo >= 16.0 and o000o0o00o0Oo <= 16.9 :
 oo = 'Jarvis'
if o000o0o00o0Oo >= 17.0 and o000o0o00o0Oo <= 17.9 :
 oo = 'Krypton'
 if 33 - 33: I1I1i1 * oO0 / OOo0o0 / OOoOoo00oo - iI1 + OoOooOOOO
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 45 - 45: OoOO + I1iiiiI1iII
class IiIi11i ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 43 - 43: o0O0 * O00O0O0O0
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 75 - 75: Ooo00oOo00o / OoOooOOOO - I1I1i1
ooiii11iII = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 42 - 42: o0O0 + oO0
class OOoO000O0OO :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 23 - 23: i11iIiiIii + iiiiIi11i
  if 68 - 68: II1Iiii1111i . OOo0o0 . i11iIiiIii
  if 40 - 40: OOo0o0 . II1Iiii1111i . I1II1 . Ooo00oOo00o
  if 33 - 33: OoOooOOOO + oOoO0oo0OOOo % i11iIiiIii . O00O0O0O0 - iiiiIi11i
def O00oooo0O ( ) :
 IiI1i11iii1 = 5
 oo0Oo00Oo0 = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 oOOO00o = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 97 - 97: iI1 % iI1 + oOoO0oo0OOOo * OoOO
 o0o00o0 = [ ]
 if 25 - 25: I1II1 - I1iiiiI1iII . oOo0O0Ooo
 for I11ii1 in range ( IiI1i11iii1 ) :
  o0o00o0 . append ( OOoO000O0OO ( oo0Oo00Oo0 [ I11ii1 ] , oOOO00o [ I11ii1 ] ) )
  if 9 - 9: OoOooOOOO + OOo0o0 % OoOooOOOO + Ooo00oOo00o . OOoOoo00oo
 return o0o00o0
 if 31 - 31: I1I1i1 + iI1 + iI1 / oOoO0oo0OOOo
def iiI1 ( ) :
 if 19 - 19: iI1 + O00O0O0O0
 if not os . path . isfile ( I1IiiI ) :
  ooo = open ( I1IiiI , 'w' )
  if 18 - 18: I1I1i1
 if not os . path . isfile ( IIi1IiiiI1Ii ) :
  ooo = open ( IIi1IiiiI1Ii , 'w' )
  if 28 - 28: OOoOoo00oo - I1iiiiI1iII . I1iiiiI1iII + II1Iiii1111i - oOo0O0Ooo + O0
 if not os . path . isfile ( O00ooooo00 ) :
  ooo = open ( O00ooooo00 , 'w' )
  if 95 - 95: O0OOo % OOo0o0 . O0
 I1i1I = oOO00oOO ( O0oO )
 if len ( I1i1I ) > 1 :
  OoOo = IIi1IiiiI1Ii
  iI = open ( OoOo )
  o00O = iI . read ( )
  if o00O == I1i1I : pass
  else :
   OOO0OOO00oo ( '[B][COLOR white]Find My Game Notice[/COLOR][/B]' , I1i1I )
   Iii111II = open ( OoOo , "w" )
   Iii111II . write ( I1i1I )
   Iii111II . close ( )
   if 9 - 9: O0OOo
 i11 = oOO00oOO ( oooO0oo0oOOOO )
 if len ( i11 ) > 1 :
  OoOo = I1IiiI
  iI = open ( OoOo )
  o00O = iI . read ( )
  if o00O == i11 : pass
  else :
   Iii111II = open ( OoOo , "w" )
   Iii111II . write ( i11 )
   Iii111II . close ( )
   if 58 - 58: OOoOoo00oo * i11iIiiIii / II1Iiii1111i % o0O0 - oO0 / OOo0o0
 i11 = oOO00oOO ( o0oO0 )
 if len ( i11 ) > 1 :
  OoOo = O00ooooo00
  iI = open ( OoOo )
  o00O = iI . read ( )
  if o00O == i11 : pass
  else :
   Iii111II = open ( OoOo , "w" )
   Iii111II . write ( i11 )
   Iii111II . close ( )
   if 50 - 50: iiiiIi11i
 Ii1i11IIii1I = datetime . date . today ( )
 OOOoO0O0o = datetime . datetime . strftime ( Ii1i11IIii1I , '%A %d %B %Y' )
 if 55 - 55: OOoOoo00oo + O00O0O0O0 . Ooo00oOo00o - oO0 . O0 - O00O0O0O0
 o0O ( '[COLOR orangered][B]EVENTS FOR ' + str ( OOOoO0O0o ) . upper ( ) + '[/B][/COLOR]' , '' , 999 , iiiii , ooo0OO )
 o0O ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 if 72 - 72: OoOO / Ooo00oOo00o * I1II1 - o0O0
 Oo0O0O0ooO0O = datetime . datetime . now ( )
 IIIIii = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2RheXMv' )
 O0o0 = Oo0O0O0ooO0O . day
 if 71 - 71: OOoOoo00oo + O00O0O0O0 % i11iIiiIii + oO0 - I1iiiiI1iII
 oO0OOoO0 = O0o0
 if 34 - 34: I1iiiiI1iII - I1iiiiI1iII * iiiiIi11i + OoOooOOOO % I1iiiiI1iII
 IIIIii = IIIIii + str ( oO0OOoO0 ) + '.xml'
 if 4 - 4: OOo0o0
 OOoO0O00o0 = IIIIii
 iII = o0 ( IIIIii )
 ooOooo000oOO = re . compile ( '<item>(.+?)</item>' ) . findall ( iII )
 if 59 - 59: oOoO0oo0OOOo + oOo0O0Ooo * II1Iiii1111i + Ooo00oOo00o
 for Oo0OoO00oOO0o in ooOooo000oOO :
  if 80 - 80: OOo0o0 + OOoOoo00oo - OOoOoo00oo % OoOO
  OoOO0oo0o = re . compile ( '<title>(.+?)</title>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  IIIIii = OOoO0O00o0 + "!" + OoOO0oo0o
  try :
   OoOO0oo0o , time = OoOO0oo0o . split ( ' - ' )
   OoOO0oo0o = '[B][COLOR white]' + OoOO0oo0o + '[/COLOR] - [COLOR orangered]' + time + '[/B][/COLOR]'
  except :
   OoOO0oo0o = '[B][COLOR white]' + OoOO0oo0o + '[/B][/COLOR]'
  II11i1I11Ii1i ( OoOO0oo0o , IIIIii , 2 , II1 , ooo0OO )
  if 97 - 97: O00O0O0O0 % OoOO * OoOooOOOO + I1I1i1 . OOoOoo00oo + OOoOoo00oo
 o0O ( '[COLOR orangered]Refresh List of Games[/COLOR]' , 'url' , 6 , iiiii , ooo0OO )
 o0O ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 II11i1I11Ii1i ( '[COLOR orangered]FMG Supported Addons[/COLOR]' , 'url' , 4 , iiiii , ooo0OO )
 o0O ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @EchoCoder[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 o0O ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @blue_builds[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 if 59 - 59: ooOO00oOo * i11iIiiIii / oO0 * Ooo00oOo00o * O0
 OOo0o = open ( Ii1I ) . read ( )
 iiI111I1iIiI = OOo0o . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 ooOooo000oOO = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iiI111I1iIiI ) )
 for Oo0OoO00oOO0o in ooOooo000oOO :
  II = float ( Oo0OoO00oOO0o )
 OOo0o = open ( IiiIII111iI ) . read ( )
 iiI111I1iIiI = OOo0o . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 ooOooo000oOO = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( iiI111I1iIiI ) )
 for Oo0OoO00oOO0o in ooOooo000oOO :
  Ii1I1IIii1II = float ( Oo0OoO00oOO0o )
  if 65 - 65: OoOooOOOO . ooOO00oOo / O0 - OoOooOOOO
 o0O ( "[COLOR orangered]Addon Version:[/COLOR] [COLOR white]" + str ( II ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 o0O ( "[COLOR orangered]Repository Version:[/COLOR] [COLOR white]" + str ( Ii1I1IIii1II ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 if 21 - 21: iiiiIi11i * ooOO00oOo
 if oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 91 - 91: I1iiiiI1iII
def iiIii ( name , url , iconimage ) :
 if 79 - 79: oOo0O0Ooo / O0
 try :
  url , OO0OoO0o00 = url . split ( '!' )
 except :
  oo00 . ok ( Oo0Ooo , "[COLOR white]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 53 - 53: O0 * O0OOo + OOoOoo00oo
 Ii = [ ]
 if 61 - 61: oOoO0oo0OOOo
 iII = o0 ( url )
 O0OOO = re . compile ( '<title>' + re . escape ( OO0OoO0o00 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( iII ) [ 0 ]
 II11iIiIIIiI = re . compile ( '<search>(.+?)</search>' ) . findall ( O0OOO )
 for o0o in II11iIiIIIiI :
  Ii . append ( o0o )
  if 84 - 84: O0
 o00 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 o00 . update ( 0 )
 if 74 - 74: oO0 - iiiiIi11i - I1II1 . OoOooOOOO - I1iiiiI1iII
 OOOoOoo0O = [ ]
 O000OOo00oo = [ ]
 oo0OOo = [ ]
 o00 . update ( 0 )
 if 64 - 64: iI1
 iI11Ii = oOO00oOO ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9uc19zdHJlYW1zLmluaQ==' ) )
 if 6 - 6: OOo0o0
 iI11Ii = iI11Ii . replace ( '\r' , '' )
 iI11Ii = iI11Ii . split ( '\n' )
 for oOOo0oOo0 in iI11Ii :
  if 49 - 49: I1II1 . i11iIiiIii - Ooo00oOo00o / oOoO0oo0OOOo . iiiiIi11i
  try :
   OOo0o = oOOo0oOo0 . split ( '=' ) [ 0 ]
   iiI111I1iIiI = str ( OOo0o )
   II1I = iiI111I1iIiI + '='
   O0i1II1Iiii1I11 = str ( oOOo0oOo0 )
   IIII = O0i1II1Iiii1I11 . replace ( II1I , '' )
   iiI111I1iIiI = iiI111I1iIiI . strip ( )
   IIII = IIII . strip ( )
   ooo = "Live Stream"
   OOOoOoo0O . append ( iiI111I1iIiI )
   O000OOo00oo . append ( IIII )
   oo0OOo . append ( ooo )
   iiIiI = list ( zip ( OOOoOoo0O , O000OOo00oo , oo0OOo ) )
  except : pass
  if 91 - 91: OoOO % Ooo00oOo00o % ooOO00oOo
 iI11Ii = oOO00oOO ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9ucy5pbmk=' ) )
 if 20 - 20: OOoOoo00oo % OoOooOOOO / OoOooOOOO + OoOooOOOO
 iI11Ii = iI11Ii . replace ( '\r' , '' )
 iI11Ii = iI11Ii . split ( '\n' )
 for oOOo0oOo0 in iI11Ii :
  if 45 - 45: OOo0o0 - I1iiiiI1iII - oOo0O0Ooo - O0OOo . oOoO0oo0OOOo / O0
  try :
   OOo0o = oOOo0oOo0 . split ( '=' ) [ 0 ]
   iiI111I1iIiI = str ( OOo0o )
   II1I = iiI111I1iIiI + '='
   O0i1II1Iiii1I11 = str ( oOOo0oOo0 )
   IIII = O0i1II1Iiii1I11 . replace ( II1I , '' )
   iiI111I1iIiI = iiI111I1iIiI . strip ( )
   IIII = IIII . strip ( )
   ooo = "Channel Stream"
   OOOoOoo0O . append ( iiI111I1iIiI )
   O000OOo00oo . append ( IIII )
   oo0OOo . append ( ooo )
   iiIiI = list ( zip ( OOOoOoo0O , O000OOo00oo , oo0OOo ) )
  except : pass
  if 51 - 51: O0 + OoOO
 iI11Ii = oOO00oOO ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9uc19wYWlkLmluaQ==' ) )
 if 8 - 8: OOo0o0 * II1Iiii1111i - OoOooOOOO - O0OOo * OOoOoo00oo % iiiiIi11i
 iI11Ii = iI11Ii . replace ( '\r' , '' )
 iI11Ii = iI11Ii . split ( '\n' )
 for oOOo0oOo0 in iI11Ii :
  if 48 - 48: O0
  try :
   OOo0o = oOOo0oOo0 . split ( '=' ) [ 0 ]
   iiI111I1iIiI = str ( OOo0o )
   II1I = iiI111I1iIiI + '='
   O0i1II1Iiii1I11 = str ( oOOo0oOo0 )
   IIII = O0i1II1Iiii1I11 . replace ( II1I , '' )
   iiI111I1iIiI = iiI111I1iIiI . strip ( )
   IIII = IIII . strip ( )
   iiI111I1iIiI = "|PAID|" + iiI111I1iIiI
   ooo = "Paid Stream"
   OOOoOoo0O . append ( iiI111I1iIiI )
   O000OOo00oo . append ( IIII )
   oo0OOo . append ( ooo )
   iiIiI = list ( zip ( OOOoOoo0O , O000OOo00oo , oo0OOo ) )
  except : pass
  if 11 - 11: iI1 + oOo0O0Ooo - O0OOo / I1I1i1 + I1II1 . oOoO0oo0OOOo
 i1Iii1i1I = sorted ( iiIiI )
 OOoO00 = sorted ( Ii )
 if 40 - 40: iiiiIi11i * OoOooOOOO + OOoOoo00oo % OoOO
 o00 . update ( 100 )
 if 74 - 74: OOo0o0 - I1II1 + oOo0O0Ooo + o0O0 / II1Iiii1111i
 i1 = [ ]
 I1iI1iIi111i = [ ]
 iiIi1IIi1I = [ ]
 o0OoOO000ooO0 = [ ]
 o0o0o0oO0oOO = [ ]
 ii1Ii11I = 0
 o00o0 = 0
 for ii in OOoO00 :
  if 84 - 84: I1I1i1 % oOoO0oo0OOOo . i11iIiiIii / O0OOo
  o0OIiII = ii . split ( ' ' )
  if 25 - 25: O0 - O0 * I1I1i1
  for name , url , OOOO0oo0 in i1Iii1i1I :
   I11iiI1i1 = name
   name = name . replace ( "|PAID|" , "" )
   name = I1i1Iiiii ( name )
   if ii . lower ( ) in name . lower ( ) :
    ii1Ii11I = ii1Ii11I + 1
    try :
     OOo0oO00ooO00 = name
     OOo0o = url . split ( "in://" ) [ 1 ]
     iiI111I1iIiI = OOo0o . split ( "/" ) [ 0 ]
     oOO0O00oO0Ooo = xbmc . translatePath ( 'special://home/addons/' + iiI111I1iIiI )
     if 67 - 67: O0OOo - OOoOoo00oo
     if os . path . exists ( oOO0O00oO0Ooo ) :
      o00o0 = o00o0 + 1
      iconimage = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + iiI111I1iIiI , 'icon.png' ) )
      iI1i11iII111 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + iiI111I1iIiI , 'fanart.jpg' ) )
      if "|PAID|" in I11iiI1i1 :
       i1 . append ( "3" )
       name = Iii1IIII11I ( iiI111I1iIiI )
       name = name + " - Subscription Addon"
       OOOoo0OO = "[COLOR dodgerblue][B]" + name + '[/B][/COLOR] - [COLOR orangered]' + OOOO0oo0 + "[/COLOR]"
      else :
       i1 . append ( "2" )
       name = Iii1IIII11I ( iiI111I1iIiI )
       OOOoo0OO = "[COLOR white][B]" + name + '[/B][/COLOR] - [COLOR orangered]' + OOOO0oo0 + "[/COLOR]"
      I1iI1iIi111i . append ( OOOoo0OO )
      iiIi1IIi1I . append ( url )
      o0OoOO000ooO0 . append ( iconimage )
      o0o0o0oO0oOO . append ( iI1i11iII111 )
     else :
      if "|PAID|" in I11iiI1i1 :
       i1 . append ( "0" )
       name = Iii1IIII11I ( iiI111I1iIiI )
       name = name + " - Subscription Addon"
      else :
       i1 . append ( "1" )
       name = Iii1IIII11I ( iiI111I1iIiI )
      OOOoo0OO = '[COLOR darkgray]' + name + ' - ' + OOOO0oo0 + ' | Addon Not Installed[/COLOR]'
      I1iI1iIi111i . append ( OOOoo0OO )
      iiIi1IIi1I . append ( url )
      o0OoOO000ooO0 . append ( iiiii )
      o0o0o0oO0oOO . append ( ooo0OO )
     oO0o0 = list ( zip ( i1 , I1iI1iIi111i , iiIi1IIi1I , o0OoOO000ooO0 , o0o0o0oO0oOO ) )
    except : pass
  o0OIiII = ""
  if 50 - 50: I1iiiiI1iII
 Ii11iIi = [ ]
 if 55 - 55: iI1 * OOo0o0 * I1I1i1 % Ooo00oOo00o . OoOooOOOO . i11iIiiIii
 oOOoo00O00o = 0
 if 98 - 98: OOoOoo00oo + I1iiiiI1iII + OOo0o0 % oOo0O0Ooo
 o0O ( "[COLOR orangered][B]We found " + str ( ii1Ii11I ) + " links, you have the addons to play " + str ( o00o0 ) + " of those links.[/B][/COLOR]" , "url" , 999 , iiiii , ooo0OO )
 o0O ( "########################################################" , "url" , 999 , iiiii , ooo0OO )
 if 97 - 97: O0 * oOo0O0Ooo . oOo0O0Ooo
 try :
  I111iI = sorted ( oO0o0 , key = lambda I11ii1 : int ( I11ii1 [ 0 ] ) , reverse = True )
  I111iI = sorted ( I111iI , reverse = True )
  for oOOo0 , name , url , iconimage , iI1i11iII111 in I111iI :
   if 16 - 16: OOo0o0 % oO0 * i11iIiiIii % i11iIiiIii
   oOOoo00O00o = oOOoo00O00o + 1
   Ii11iIi . append ( url )
   if "NOT INSTALLED" not in name . upper ( ) :
    o0O ( "[COLOR lightblue][B]Link " + str ( oOOoo00O00o ) + ": [/B][/COLOR]" + name , url , 3 , iconimage , iI1i11iII111 )
   else :
    o0O ( name , url , 999 , iconimage , iI1i11iII111 )
    if 65 - 65: OoOooOOOO - OOo0o0 + OOo0o0 + oOoO0oo0OOOo
  o00 . close ( )
 except :
  o00 . close ( )
  oo00 . ok ( Oo0Ooo , "Sorry, no links were found." )
  quit ( )
  if 96 - 96: OOoOoo00oo % O0 / O0
 if oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 44 - 44: OOo0o0 / iI1 / iI1
def Iii1IIII11I ( string ) :
 if 87 - 87: I1II1 . iiiiIi11i - oOoO0oo0OOOo + O0 / I1II1 / OOo0o0
 ooo = open ( I1IiiI , mode = 'r' ) ; IiI = ooo . read ( ) ; ooo . close ( )
 IiI = IiI . replace ( '\n' , '' )
 ooOooo000oOO = re . compile ( '<item>(.+?)</item>' ) . findall ( IiI )
 IIIii1I = 0
 for Oo0OoO00oOO0o in ooOooo000oOO :
  if 97 - 97: O0 + II1Iiii1111i
  OO0O000 = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iiIiI1i1 = re . compile ( '<name>(.+?)</name>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  if 69 - 69: O00O0O0O0
  if string == OO0O000 :
   IIIii1I = 1
   OoOO0oo0o = iiIiI1i1
   if 40 - 40: o0O0 + oOo0O0Ooo % I1I1i1 - ooOO00oOo . iiiiIi11i
 if IIIii1I == 0 :
  OoOO0oo0o = string
  if 48 - 48: I1I1i1 - OOo0o0 / oOo0O0Ooo
 return OoOO0oo0o
 if 100 - 100: iiiiIi11i / I1I1i1 % oOoO0oo0OOOo % I1II1 % OOoOoo00oo
def O00oO000O0O ( name , url , iconimage ) :
 if 18 - 18: OoOO - OOoOoo00oo . o0O0 . ooOO00oOo
 i1I = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 i1I . setPath ( url )
 xbmc . Player ( ) . play ( url , i1I , False )
 quit ( )
 if 78 - 78: iI1 * ooOO00oOo . iiiiIi11i / I1I1i1 - oOo0O0Ooo / o0O0
def I1i1Iiiii ( string ) :
 if 35 - 35: iI1 % OOoOoo00oo - OOo0o0
 ooo = open ( O00ooooo00 , mode = 'r' ) ; IiI = ooo . read ( ) ; ooo . close ( )
 IiI = IiI . replace ( '\n' , '' )
 ooOooo000oOO = re . compile ( '<item>(.+?)</item>' ) . findall ( IiI )
 for Oo0OoO00oOO0o in sorted ( ooOooo000oOO ) :
  ii1iii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  Iii1I1111ii = re . compile ( '<new>(.+?)</new>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  if ii1iii1i . lower ( ) in string . lower ( ) :
   string = string . replace ( ii1iii1i , Iii1I1111ii )
   if 72 - 72: oOoO0oo0OOOo + Ooo00oOo00o + I1I1i1
 return string
 if 94 - 94: OOo0o0 . Ooo00oOo00o - I1I1i1 % O0 - O0OOo
def ooO0O00Oo0o ( ) :
 if 65 - 65: oO0 . iI1 - o0O0 * I1iiiiI1iII / o0O0 / O00O0O0O0
 o0O ( "[COLOR white][B]FMG Supported Addons[/B][/COLOR]" , '' , 999 , iiiii , ooo0OO )
 o0O ( "#####################################" , '' , 999 , iiiii , ooo0OO )
 if 40 - 40: O00O0O0O0 * I1iiiiI1iII * i11iIiiIii
 oo0OO00OoooOo = [ ]
 II1i111Ii1i = [ ]
 iii1 = [ ]
 ooO0oooOO0 = [ ]
 O000OOo00oo = [ ]
 o0ooo0 = [ ]
 if 61 - 61: II1Iiii1111i - OOoOoo00oo - Ooo00oOo00o
 ooo = open ( I1IiiI , mode = 'r' ) ; IiI = ooo . read ( ) ; ooo . close ( )
 IiI = IiI . replace ( '\n' , '' )
 ooOooo000oOO = re . compile ( '<item>(.+?)</item>' ) . findall ( IiI )
 for Oo0OoO00oOO0o in sorted ( ooOooo000oOO ) :
  OO0O000 = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  iiIiI1i1 = re . compile ( '<name>(.+?)</name>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  IiI1iIiIIIii = re . compile ( '<dev>(.+?)</dev>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  oOoO = re . compile ( '<source>(.+?)</source>' ) . findall ( Oo0OoO00oOO0o ) [ 0 ]
  IIIIii = iiIiI1i1 + '|SPLIT|' + OO0O000 + '|SPLIT|' + IiI1iIiIIIii + '|SPLIT|' + oOoO
  if 81 - 81: II1Iiii1111i - II1Iiii1111i . OoOO
  oOO0O00oO0Ooo = xbmc . translatePath ( 'special://home/addons/' + OO0O000 )
  if os . path . exists ( oOO0O00oO0Ooo ) :
   if "|PAID|" in IiI1iIiIIIii :
    oOOo0 = "3"
   else : oOOo0 = "2"
  else :
   if not "|PAID|" in IiI1iIiIIIii :
    oOOo0 = "1"
   else : oOOo0 = "0"
  oo0OO00OoooOo . append ( OO0O000 )
  II1i111Ii1i . append ( iiIiI1i1 )
  iii1 . append ( IiI1iIiIIIii )
  ooO0oooOO0 . append ( oOoO )
  O000OOo00oo . append ( IIIIii )
  o0ooo0 . append ( oOOo0 )
  iiIiI = list ( zip ( o0ooo0 , oo0OO00OoooOo , II1i111Ii1i , iii1 , ooO0oooOO0 , O000OOo00oo ) )
  if 73 - 73: iI1 % i11iIiiIii - iiiiIi11i
 i1Iii1i1I = sorted ( iiIiI , key = lambda I11ii1 : int ( I11ii1 [ 0 ] ) , reverse = True )
 for oOOo0 , OO0O000 , iiIiI1i1 , IiI1iIiIIIii , Ii1iI111II1I1 , IIIIii in i1Iii1i1I :
  oOO0O00oO0Ooo = xbmc . translatePath ( 'special://home/addons/' + OO0O000 )
  if os . path . exists ( oOO0O00oO0Ooo ) :
   oOOOOoOO0o = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0O000 , 'icon.png' ) )
   iI1i11iII111 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0O000 , 'fanart.jpg' ) )
   if "|PAID|" in IiI1iIiIIIii :
    IIIIii = IIIIii + '|SPLIT|1|SPLIT|PAID'
    o0O ( "[COLOR dodgerblue][B]" + iiIiI1i1 + " | PAID SUBSCRIPTION - INSTALLED [/B][/COLOR]" , IIIIii , 5 , oOOOOoOO0o , iI1i11iII111 )
   else :
    IIIIii = IIIIii + '|SPLIT|1'
    o0O ( "[COLOR lightblue][B]" + iiIiI1i1 + " - INSTALLED [/B][/COLOR]" , IIIIii , 5 , oOOOOoOO0o , iI1i11iII111 )
  else :
   if "|PAID|" in IiI1iIiIIIii :
    IIIIii = IIIIii + '|SPLIT|0|SPLIT|PAID'
    o0O ( "[COLOR darkgray]" + iiIiI1i1 + " | PAID SUBSCRIPTION - NOT INSTALLED [/COLOR]" , IIIIii , 5 , iiiii , ooo0OO )
   else :
    IIIIii = IIIIii + '|SPLIT|0'
    o0O ( "[COLOR darkgray]" + iiIiI1i1 + " - NOT INSTALLED [/COLOR]" , IIIIii , 5 , iiiii , ooo0OO )
    if 1 - 1: oOoO0oo0OOOo
 if oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 68 - 68: OoOO - iiiiIi11i / o0O0 / iI1
def I11iiii ( url ) :
 if 60 - 60: iI1 . Ooo00oOo00o + I1iiiiI1iII / I1I1i1 . oOoO0oo0OOOo
 OO0oo = "null"
 try :
  OoOO0oo0o , url , IiI1iIiIIIii , Ii1iI111II1I1 , oOOo0 , OO0oo = url . split ( '|SPLIT|' )
 except :
  OoOO0oo0o , url , IiI1iIiIIIii , Ii1iI111II1I1 , oOOo0 = url . split ( '|SPLIT|' )
  if 15 - 15: iiiiIi11i / o0O0 . o0O0 * OOo0o0
 if OO0oo != "null" :
  IiI1iIiIIIii = IiI1iIiIIIii . replace ( "|PAID|" , "" )
  if 43 - 43: o0O0 * OoOooOOOO % iiiiIi11i
 oo00 . ok ( Oo0Ooo , "You can contact the developer of " + OoOO0oo0o + " on:" , "[COLOR orangered]" + IiI1iIiIIIii + "[/COLOR]" , "[B][COLOR blue]Install Source: " + Ii1iI111II1I1 + "[/COLOR][/B]" )
 if 42 - 42: I1II1
 if oOOo0 == "1" :
  oo000O0OoooO = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to launch ' + OoOO0oo0o + ' now?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if oo000O0OoooO == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
 else :
  oo000O0OoooO = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , "[B][COLOR blue]Install Source: " + Ii1iI111II1I1 + "[/COLOR][/B]" , '[COLOR white]' + OoOO0oo0o + ' is not installed. If the addon is available for download in any repository currently installed on your system we can attempt to install the addon. Would you like us to try and install ' + OoOO0oo0o + '?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if oo000O0OoooO == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
   if 93 - 93: iI1 . oOoO0oo0OOOo / OOo0o0 % oOo0O0Ooo * iI1 % oO0
def II11i1I11Ii1i ( name , url , mode , iconimage , fanartimage ) :
 if 48 - 48: O00O0O0O0 / o0O0 . ooOO00oOo * II1Iiii1111i * OOo0o0 / Ooo00oOo00o
 OOOOoOOo0O0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 oOooo0 = True
 i1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1I . setProperty ( "fanart_Image" , fanartimage )
 i1I . setProperty ( "icon_Image" , iconimage )
 oOooo0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoOOo0O0 , listitem = i1I , isFolder = True )
 return oOooo0
 if 58 - 58: iiiiIi11i . OoOO + II1Iiii1111i
def o0O ( name , url , mode , iconimage , fanartimage ) :
 if 66 - 66: OoOO / OOo0o0 * oOo0O0Ooo + oOo0O0Ooo % iI1
 OOOOoOOo0O0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 oOooo0 = True
 i1I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 i1I . setProperty ( "fanart_Image" , fanartimage )
 i1I . setProperty ( "icon_Image" , iconimage )
 oOooo0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOOoOOo0O0 , listitem = i1I , isFolder = False )
 return oOooo0
 if 49 - 49: OOo0o0 - i11iIiiIii . o0O0 * OoOooOOOO % OoOO + Ooo00oOo00o
def OOO0OOO00oo ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 oOO0OOOo = xbmcgui . Window ( id )
 oo0o0000 = 50
 while ( oo0o0000 > 0 ) :
  try :
   xbmc . sleep ( 10 )
   oo0o0000 -= 1
   oOO0OOOo . getControl ( 1 ) . setLabel ( heading )
   oOO0OOOo . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 11 - 11: ooOO00oOo
def o0 ( url ) :
 IiIIII1i11I = urllib2 . Request ( url )
 IiIIII1i11I . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 OOO = urllib2 . urlopen ( IiIIII1i11I )
 iII = OOO . read ( )
 OOO . close ( )
 iII = iII . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return iII
 if 6 - 6: oOo0O0Ooo
def oOO00oOO ( url ) :
 IiIIII1i11I = urllib2 . Request ( url )
 IiIIII1i11I . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 OOO = urllib2 . urlopen ( IiIIII1i11I )
 iII = OOO . read ( )
 OOO . close ( )
 return iII
 if 50 - 50: oO0 % O0 * I1I1i1
 if 5 - 5: I1iiiiI1iII * II1Iiii1111i
 if 5 - 5: o0O0
 if 90 - 90: o0O0 . O00O0O0O0 / OoOooOOOO - iI1
 if 40 - 40: oOo0O0Ooo
def I1i1i1 ( ) :
 if 73 - 73: O0 * OoOO + OoOooOOOO + O00O0O0O0
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 40 - 40: oOoO0oo0OOOo . II1Iiii1111i * o0O0 + OOoOoo00oo + OOoOoo00oo
 if os . path . exists ( Oo0oO0ooo ) == True :
  for I1ii1I1iiii , iiI , oO in os . walk ( Oo0oO0ooo ) :
   IIiIi = 0
   IIiIi += len ( oO )
   if IIiIi > 0 :
    for ooo in oO :
     try :
      if ( ooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( I1ii1I1iiii , ooo ) )
     except :
      pass
    for O0i1II1Iiii1I11 in iiI :
     try :
      shutil . rmtree ( os . path . join ( I1ii1I1iiii , O0i1II1Iiii1I11 ) )
     except :
      pass
      if 91 - 91: oO0 * I1II1 / iiiiIi11i . O0 + O0OOo + II1Iiii1111i
   else :
    pass
    if 8 - 8: OOo0o0 / oO0
 if os . path . exists ( o0oOoO00o ) == True :
  for I1ii1I1iiii , iiI , oO in os . walk ( o0oOoO00o ) :
   IIiIi = 0
   IIiIi += len ( oO )
   if IIiIi > 0 :
    for ooo in oO :
     try :
      if ( ooo . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( I1ii1I1iiii , ooo ) )
     except :
      pass
    for O0i1II1Iiii1I11 in iiI :
     try :
      shutil . rmtree ( os . path . join ( I1ii1I1iiii , O0i1II1Iiii1I11 ) )
     except :
      pass
      if 20 - 20: iiiiIi11i
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  o0oO000oo = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 95 - 95: O00O0O0O0 / O00O0O0O0
  for I1ii1I1iiii , iiI , oO in os . walk ( o0oO000oo ) :
   IIiIi = 0
   IIiIi += len ( oO )
   if 30 - 30: oO0 + I1II1 / I1II1 % oO0 . oO0
   if IIiIi > 0 :
    for ooo in oO :
     os . unlink ( os . path . join ( I1ii1I1iiii , ooo ) )
    for O0i1II1Iiii1I11 in iiI :
     shutil . rmtree ( os . path . join ( I1ii1I1iiii , O0i1II1Iiii1I11 ) )
     if 55 - 55: O00O0O0O0 - iI1 + oOoO0oo0OOOo + OoOO % OoOooOOOO
   else :
    pass
  iiI11i1II = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 51 - 51: I1I1i1 % I1II1 % I1I1i1 * O0 - OOoOoo00oo % I1II1
  for I1ii1I1iiii , iiI , oO in os . walk ( iiI11i1II ) :
   IIiIi = 0
   IIiIi += len ( oO )
   if 65 - 65: O00O0O0O0
   if IIiIi > 0 :
    for ooo in oO :
     os . unlink ( os . path . join ( I1ii1I1iiii , ooo ) )
    for O0i1II1Iiii1I11 in iiI :
     shutil . rmtree ( os . path . join ( I1ii1I1iiii , O0i1II1Iiii1I11 ) )
     if 68 - 68: O00O0O0O0 % i11iIiiIii + oOoO0oo0OOOo
   else :
    pass
    if 52 - 52: oO0 - I1II1 + oO0 % I1I1i1
 o0o00o0 = O00oooo0O ( )
 if 35 - 35: ooOO00oOo
 for I1i in o0o00o0 :
  iIII = xbmc . translatePath ( I1i . path )
  if os . path . exists ( iIII ) == True :
   for I1ii1I1iiii , iiI , oO in os . walk ( iIII ) :
    IIiIi = 0
    IIiIi += len ( oO )
    if IIiIi > 0 :
     for ooo in oO :
      os . unlink ( os . path . join ( I1ii1I1iiii , ooo ) )
     for O0i1II1Iiii1I11 in iiI :
      shutil . rmtree ( os . path . join ( I1ii1I1iiii , O0i1II1Iiii1I11 ) )
      if 70 - 70: OoOO / ooOO00oOo
    else :
     pass
     if 85 - 85: oOo0O0Ooo % Ooo00oOo00o * oOo0O0Ooo / oO0
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 oo00 . ok ( Oo0Ooo , "The FMG games list has been reloaded." )
 if 96 - 96: oOo0O0Ooo + OOo0o0
def iiII1i11i ( ) :
 IiIi = [ ]
 OOOOO0O00 = sys . argv [ 2 ]
 if len ( OOOOO0O00 ) >= 2 :
  Iii = sys . argv [ 2 ]
  iIIiIiI1I1 = Iii . replace ( '?' , '' )
  if ( Iii [ len ( Iii ) - 1 ] == '/' ) :
   Iii = Iii [ 0 : len ( Iii ) - 2 ]
  ooO = iIIiIiI1I1 . split ( '&' )
  IiIi = { }
  for iiOO0O0Ooo in range ( len ( ooO ) ) :
   oOoO0 = { }
   oOoO0 = ooO [ iiOO0O0Ooo ] . split ( '=' )
   if ( len ( oOoO0 ) ) == 2 :
    IiIi [ oOoO0 [ 0 ] ] = oOoO0 [ 1 ]
    if 77 - 77: ooOO00oOo . OoOO % OoOO + i11iIiiIii
 return IiIi
 if 72 - 72: ooOO00oOo * OoOooOOOO % O00O0O0O0 / O0OOo
Iii = iiII1i11i ( ) ; OoOO0oo0o = None ; IIIIii = None ; I11i1II = None ; oOOOOoOO0o = None ; Ooo = None
try : OoOO0oo0o = urllib . unquote_plus ( Iii [ "name" ] )
except : pass
try : IIIIii = urllib . unquote_plus ( Iii [ "url" ] )
except : pass
try : I11i1II = int ( Iii [ "mode" ] )
except : pass
try : oOOOOoOO0o = urllib . unquote_plus ( Iii [ "iconimage" ] )
except : pass
try : Ooo = urllib . quote_plus ( Iii [ "fanartimage" ] )
except : pass
if 21 - 21: I1II1
if I11i1II == None or IIIIii == None or len ( IIIIii ) < 1 : iiI1 ( )
elif I11i1II == 1 : Get_Content ( OoOO0oo0o , IIIIii , oOOOOoOO0o )
elif I11i1II == 2 : iiIii ( OoOO0oo0o , IIIIii , oOOOOoOO0o )
elif I11i1II == 3 : O00oO000O0O ( OoOO0oo0o , IIIIii , oOOOOoOO0o )
elif I11i1II == 4 : ooO0O00Oo0o ( )
elif I11i1II == 5 : I11iiii ( IIIIii )
elif I11i1II == 6 : I1i1i1 ( )
if 29 - 29: iI1 / oOoO0oo0OOOo / O00O0O0O0 * OOoOoo00oo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )