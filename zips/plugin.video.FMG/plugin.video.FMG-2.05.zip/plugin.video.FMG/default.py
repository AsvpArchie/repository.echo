import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.FMG'
Oo0Ooo = '[COLOR orangered]FIND MY GAME[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( 'special://home/addons/' + OO0o )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pl.png' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/supported_addons.xml' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/notice.txt' ) )
if 27 - 27: iIiiiI1IiI1I1 * IIiIiII11i * IiIIi1I1Iiii - Ooo00oOo00o
I1IiI = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
o0OOO = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
iIiiiI = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uRk1HL3BsdWdpbi52aWRlby5GTUct' )
Iii1ii1II11i = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
if 10 - 10: I1iII1iiII + I1Ii111 / OOo
i1i1II = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O0oo0OO0 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcveHJkU3pOVUM=' )
I1i1iiI1 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvaXF6Vmp3ZXc=' )
iiIIIII1i1iI = xbmcgui . Dialog ( )
o0oO0 = xbmcgui . DialogProgress ( )
oo00 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
o00 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * Ooo0 % oo00000o0
I11i1i11i1I = xbmc . getInfoLabel ( "System.BuildVersion" )
Iiii = float ( I11i1i11i1I [ : 4 ] )
if Iiii >= 11.0 and Iiii <= 11.9 :
 OOO0O = 'Eden'
if Iiii >= 12.0 and Iiii <= 12.9 :
 OOO0O = 'Frodo'
if Iiii >= 13.0 and Iiii <= 13.9 :
 OOO0O = 'Gotham'
if Iiii >= 14.0 and Iiii <= 14.9 :
 OOO0O = 'Helix'
if Iiii >= 15.0 and Iiii <= 15.9 :
 OOO0O = 'Isengard'
if Iiii >= 16.0 and Iiii <= 16.9 :
 OOO0O = 'Jarvis'
if Iiii >= 17.0 and Iiii <= 17.9 :
 OOO0O = 'Krypton'
 if 94 - 94: oooO0oOOOOo0o
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 93 - 93: OoOoo0 % iIiiI1 % OOooO % OOoO00o
class II111iiii ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 48 - 48: I1Ii . i11iIiiIii - OoOoo0 % II1ii . I1Ii / iIi1IIii11I
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 6 - 6: o0oOoO00o * iIiiI1
O00O0O0O0 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 75 - 75: Ooo00oOo00o / OoOoo0 - iIi1IIii11I
class oo :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 28 - 28: IIiIiII11i - Ooo00oOo00o
  if 70 - 70: II1ii . II1ii - II1ii / oo0 * oo00000o0
  if 86 - 86: i11iIiiIii + OoOoo0 + I1Ii * oooO0oOOOOo0o + iIi1IIii11I
  if 61 - 61: II1ii / i11iIiiIii
def IiIiIi ( ) :
 II = 5
 iI = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 iI11iiiI1II = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 79 - 79: OOoO00o % i11iIiiIii / IIiIiII11i . oo00000o0
 o0oO0o00oo = [ ]
 if 32 - 32: OOo * iIiiiI1IiI1I1 % Ooo0 % OoOoo0 . OOooO
 for o0OOOOO00o0O0 in range ( II ) :
  o0oO0o00oo . append ( oo ( iI [ o0OOOOO00o0O0 ] , iI11iiiI1II [ o0OOOOO00o0O0 ] ) )
  if 71 - 71: I1Ii % iIiiI1 / iIi1IIii11I
 return o0oO0o00oo
 if 49 - 49: I1iII1iiII % iIiiI1 * iIiiiI1IiI1I1
def oOOo0oo ( ) :
 if 80 - 80: oooO0oOOOOo0o * i11iIiiIii / OOoO00o
 if not os . path . isfile ( O00ooooo00 ) :
  I11II1i = open ( O00ooooo00 , 'w' )
  if 23 - 23: oo0 / iIi1IIii11I + oooO0oOOOOo0o + oooO0oOOOOo0o / I1iII1iiII
 if not os . path . isfile ( I1IiiI ) :
  I11II1i = open ( I1IiiI , 'w' )
  if 26 - 26: IiIIi1I1Iiii
 IiiI11Iiiii = ii1I1i1I ( I1i1iiI1 )
 if len ( IiiI11Iiiii ) > 1 :
  OOoo0O0 = I1IiiI
  iiiIi1i1I = open ( OOoo0O0 )
  oOO00oOO = iiiIi1i1I . read ( )
  if oOO00oOO == IiiI11Iiiii : pass
  else :
   OoOo ( '[B][COLOR white]Find My Game Notice[/COLOR][/B]' , IiiI11Iiiii )
   iIo00O = open ( OOoo0O0 , "w" )
   iIo00O . write ( IiiI11Iiiii )
   iIo00O . close ( )
   if 69 - 69: Ooo0 % OOoO00o - iIi1IIii11I + OOoO00o - iIiiiI1IiI1I1 % IiIIi1I1Iiii
 Iii111II = ii1I1i1I ( O0oo0OO0 )
 if len ( Iii111II ) > 1 :
  OOoo0O0 = O00ooooo00
  iiiIi1i1I = open ( OOoo0O0 )
  oOO00oOO = iiiIi1i1I . read ( )
  if oOO00oOO == Iii111II : pass
  else :
   iIo00O = open ( OOoo0O0 , "w" )
   iIo00O . write ( Iii111II )
   iIo00O . close ( )
   if 9 - 9: II1ii
 i11 = datetime . date . today ( )
 O0oo0OO0oOOOo = datetime . datetime . strftime ( i11 , '%A %d %B %Y' )
 if 35 - 35: OOooO % I1Ii111
 o0OOoo0OO0OOO ( '[COLOR orangered][B]EVENTS FOR ' + str ( O0oo0OO0oOOOo ) . upper ( ) + '[/B][/COLOR]' , '' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 if 19 - 19: Ooo0 % Ooo00oOo00o % iIi1IIii11I
 oo0OooOOo0 = datetime . datetime . now ( )
 o0O = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2RheXMv' )
 O00oO = oo0OooOOo0 . day
 if 39 - 39: OOooO - I1iII1iiII * II1ii % iIi1IIii11I * I1iII1iiII % I1iII1iiII
 OoOOOOO = O00oO
 if 33 - 33: oo0 % Ooo00oOo00o
 o0O = o0O + str ( OoOOOOO ) + '.xml'
 if 78 - 78: oooO0oOOOOo0o
 OO00Oo = o0O
 O0OOO0OOoO0O = O00Oo000ooO0 ( o0O )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0OOO0OOoO0O )
 if 5 - 5: OOo / iIi1IIii11I . OoOoo0 - iIiiiI1IiI1I1 / OOooO
 for ooOooo000oOO in OoO0O00 :
  if 59 - 59: I1iII1iiII + IiIIi1I1Iiii * o0oOoO00o + Ooo00oOo00o
  Oo0OoO00oOO0o = re . compile ( '<title>(.+?)</title>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0O = OO00Oo + "!" + Oo0OoO00oOO0o
  try :
   Oo0OoO00oOO0o , time = Oo0OoO00oOO0o . split ( ' - ' )
   Oo0OoO00oOO0o = '[B][COLOR white]' + Oo0OoO00oOO0o + '[/COLOR] - [COLOR orangered]' + time + '[/B][/COLOR]'
  except :
   Oo0OoO00oOO0o = '[B][COLOR white]' + Oo0OoO00oOO0o + '[/B][/COLOR]'
  OOO00O ( Oo0OoO00oOO0o , o0O , 2 , II1 , ooo0OO )
  if 84 - 84: Ooo0 * II1ii / oooO0oOOOOo0o - iIiiiI1IiI1I1
 o0OOoo0OO0OOO ( '[COLOR orangered]Refresh List of Games[/COLOR]' , 'url' , 6 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 OOO00O ( '[COLOR orangered]FMG Supported Addons[/COLOR]' , 'url' , 4 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @EchoCoder[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @blue_builds[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 if 30 - 30: IIiIiII11i / I1Ii - OOoO00o - I1iII1iiII % iIiiI1
 IIi1i11111 = open ( I1IiI ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  I1ii11iI = float ( ooOooo000oOO )
 IIi1i11111 = open ( o0OOO ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  IIi1i = float ( ooOooo000oOO )
  if 46 - 46: OOoO00o % oooO0oOOOOo0o + II1ii . o0oOoO00o . II1ii
 o0OOoo0OO0OOO ( "[COLOR orangered]Addon Version:[/COLOR] [COLOR white]" + str ( I1ii11iI ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "[COLOR orangered]Repository Version:[/COLOR] [COLOR white]" + str ( IIi1i ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 if 96 - 96: OOo
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 45 - 45: iIiiiI1IiI1I1 * iIi1IIii11I % OOo * IiIIi1I1Iiii + iIiiI1 . o0oOoO00o
def Oo0ooOo0o ( name , url , iconimage ) :
 if 22 - 22: IIiIiII11i / i11iIiiIii * IIiIiII11i * I1iII1iiII . oo00000o0 / i11iIiiIii
 try :
  url , IiiiOO0OoO0o00 = url . split ( '!' )
 except :
  iiIIIII1i1iI . ok ( Oo0Ooo , "[COLOR white]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 53 - 53: iIiiiI1IiI1I1 * II1ii + oo00000o0
 Ii = [ ]
 if 61 - 61: I1iII1iiII
 O0OOO0OOoO0O = O00Oo000ooO0 ( url )
 O0OOO = re . compile ( '<title>' + re . escape ( IiiiOO0OoO0o00 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0OOO0OOoO0O ) [ 0 ]
 II11iIiIIIiI = re . compile ( '<search>(.+?)</search>' ) . findall ( O0OOO )
 for o0o in II11iIiIIIiI :
  Ii . append ( o0o )
  if 84 - 84: iIiiiI1IiI1I1
 o0oO0 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 o0oO0 . update ( 0 )
 if 74 - 74: oo0 - I1Ii111 - OOo . OoOoo0 - OOooO
 OOOoOoo0O = [ ]
 O000OOo00oo = [ ]
 oo0OOo = [ ]
 o0oO0 . update ( 0 )
 if 64 - 64: oooO0oOOOOo0o
 iI11Ii = ii1I1i1I ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9uc19zdHJlYW1zLmluaQ==' ) )
 if 6 - 6: Ooo0
 iI11Ii = iI11Ii . replace ( '\r' , '' )
 iI11Ii = iI11Ii . split ( '\n' )
 for oOOo0oOo0 in iI11Ii :
  if 49 - 49: OOo . i11iIiiIii - Ooo00oOo00o / I1iII1iiII . I1Ii111
  try :
   IIi1i11111 = oOOo0oOo0 . split ( '=' ) [ 0 ]
   ooOO00O00oo = str ( IIi1i11111 )
   II1I = ooOO00O00oo + '='
   O0 = str ( oOOo0oOo0 )
   i1II1Iiii1I11 = O0 . replace ( II1I , '' )
   ooOO00O00oo = ooOO00O00oo . strip ( )
   i1II1Iiii1I11 = i1II1Iiii1I11 . strip ( )
   I11II1i = "Live Stream"
   OOOoOoo0O . append ( ooOO00O00oo )
   O000OOo00oo . append ( i1II1Iiii1I11 )
   oo0OOo . append ( I11II1i )
   IIII = list ( zip ( OOOoOoo0O , O000OOo00oo , oo0OOo ) )
  except : pass
  if 32 - 32: IiIIi1I1Iiii / IIiIiII11i - iIi1IIii11I
 iI11Ii = ii1I1i1I ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9ucy5pbmk=' ) )
 if 91 - 91: iIiiI1 % Ooo00oOo00o % IIiIiII11i
 iI11Ii = iI11Ii . replace ( '\r' , '' )
 iI11Ii = iI11Ii . split ( '\n' )
 for oOOo0oOo0 in iI11Ii :
  if 20 - 20: oo00000o0 % OoOoo0 / OoOoo0 + OoOoo0
  try :
   IIi1i11111 = oOOo0oOo0 . split ( '=' ) [ 0 ]
   ooOO00O00oo = str ( IIi1i11111 )
   II1I = ooOO00O00oo + '='
   O0 = str ( oOOo0oOo0 )
   i1II1Iiii1I11 = O0 . replace ( II1I , '' )
   ooOO00O00oo = ooOO00O00oo . strip ( )
   i1II1Iiii1I11 = i1II1Iiii1I11 . strip ( )
   I11II1i = "Channel Stream"
   OOOoOoo0O . append ( ooOO00O00oo )
   O000OOo00oo . append ( i1II1Iiii1I11 )
   oo0OOo . append ( I11II1i )
   IIII = list ( zip ( OOOoOoo0O , O000OOo00oo , oo0OOo ) )
  except : pass
  if 45 - 45: Ooo0 - OOooO - IiIIi1I1Iiii - II1ii . I1iII1iiII / iIiiiI1IiI1I1
 iI11Ii = ii1I1i1I ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9uc19wYWlkLmluaQ==' ) )
 if 51 - 51: iIiiiI1IiI1I1 + iIiiI1
 iI11Ii = iI11Ii . replace ( '\r' , '' )
 iI11Ii = iI11Ii . split ( '\n' )
 for oOOo0oOo0 in iI11Ii :
  if 8 - 8: Ooo0 * o0oOoO00o - OoOoo0 - II1ii * oo00000o0 % I1Ii111
  try :
   IIi1i11111 = oOOo0oOo0 . split ( '=' ) [ 0 ]
   ooOO00O00oo = str ( IIi1i11111 )
   II1I = ooOO00O00oo + '='
   O0 = str ( oOOo0oOo0 )
   i1II1Iiii1I11 = O0 . replace ( II1I , '' )
   ooOO00O00oo = ooOO00O00oo . strip ( )
   i1II1Iiii1I11 = i1II1Iiii1I11 . strip ( )
   ooOO00O00oo = "|PAID|" + ooOO00O00oo
   I11II1i = "Paid Stream"
   OOOoOoo0O . append ( ooOO00O00oo )
   O000OOo00oo . append ( i1II1Iiii1I11 )
   oo0OOo . append ( I11II1i )
   IIII = list ( zip ( OOOoOoo0O , O000OOo00oo , oo0OOo ) )
  except : pass
  if 48 - 48: iIiiiI1IiI1I1
 I1IiiIIIi = sorted ( IIII )
 i1Iii1i1I = sorted ( Ii )
 if 91 - 91: oo0 + I1Ii111 . oo00000o0 * oo0 + I1Ii111 * OOo
 o0oO0 . update ( 100 )
 if 80 - 80: iIiiI1 % oo00000o0 % Ooo0 - OOo + OOo
 iIiii1i111iI1 = [ ]
 i11oO0oOo0 = [ ]
 I1I1I = [ ]
 OoOO000 = [ ]
 i1Ii11i1i = [ ]
 o0oOOoo = 0
 oOo00O0oo00o0 = 0
 for ii in i1Iii1i1I :
  if 84 - 84: iIi1IIii11I % I1iII1iiII . i11iIiiIii / II1ii
  o0OIiII = ii . split ( ' ' )
  if 25 - 25: iIiiiI1IiI1I1 - iIiiiI1IiI1I1 * iIi1IIii11I
  for name , url , OOOO0oo0 in I1IiiIIIi :
   I11iiI1i1 = name
   name = name . replace ( "|PAID|" , "" )
   if ii . lower ( ) in name . lower ( ) :
    o0oOOoo = o0oOOoo + 1
    try :
     I1i1Iiiii = name
     IIi1i11111 = url . split ( "in://" ) [ 1 ]
     ooOO00O00oo = IIi1i11111 . split ( "/" ) [ 0 ]
     OOo0oO00ooO00 = xbmc . translatePath ( 'special://home/addons/' + ooOO00O00oo )
     if 90 - 90: o0oOoO00o * OOoO00o + iIi1IIii11I
     if os . path . exists ( OOo0oO00ooO00 ) :
      oOo00O0oo00o0 = oOo00O0oo00o0 + 1
      iconimage = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + ooOO00O00oo , 'icon.png' ) )
      OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + ooOO00O00oo , 'fanart.jpg' ) )
      if "|PAID|" in I11iiI1i1 :
       iIiii1i111iI1 . append ( "3" )
       name = OoOoO ( ooOO00O00oo )
       name = name + " - Subscription Addon"
       Ii1I1i = "[COLOR dodgerblue][B]" + name + '[/B][/COLOR] - [COLOR orangered]' + OOOO0oo0 + "[/COLOR]"
      else :
       iIiii1i111iI1 . append ( "2" )
       name = OoOoO ( ooOO00O00oo )
       Ii1I1i = "[COLOR white][B]" + name + '[/B][/COLOR] - [COLOR orangered]' + OOOO0oo0 + "[/COLOR]"
      i11oO0oOo0 . append ( Ii1I1i )
      I1I1I . append ( url )
      OoOO000 . append ( iconimage )
      i1Ii11i1i . append ( OO )
     else :
      if "|PAID|" in I11iiI1i1 :
       iIiii1i111iI1 . append ( "0" )
       name = OoOoO ( ooOO00O00oo )
       name = name + " - Subscription Addon"
      else :
       iIiii1i111iI1 . append ( "1" )
       name = OoOoO ( ooOO00O00oo )
      Ii1I1i = '[COLOR darkgray]' + name + ' - ' + OOOO0oo0 + ' | Addon Not Installed[/COLOR]'
      i11oO0oOo0 . append ( Ii1I1i )
      I1I1I . append ( url )
      OoOO000 . append ( iiiii )
      i1Ii11i1i . append ( ooo0OO )
     OOI1iI1ii1II = list ( zip ( iIiii1i111iI1 , i11oO0oOo0 , I1I1I , OoOO000 , i1Ii11i1i ) )
    except : pass
  o0OIiII = ""
  if 57 - 57: OOoO00o % OoOoo0 + iIi1IIii11I - OOo
 o0OIiI1i = [ ]
 if 92 - 92: OOooO . OOooO + II1ii
 IiIiI1111I1I = 0
 if 13 - 13: OoOoo0 . i11iIiiIii
 o0OOoo0OO0OOO ( "[COLOR orangered][B]We found " + str ( o0oOOoo ) + " links, you have the addons to play " + str ( oOo00O0oo00o0 ) + " of those links.[/B][/COLOR]" , "url" , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "########################################################" , "url" , 999 , iiiii , ooo0OO )
 if 56 - 56: oo0 % iIiiiI1IiI1I1 - I1Ii111
 try :
  O00o0OO0 = sorted ( OOI1iI1ii1II , key = lambda o0OOOOO00o0O0 : int ( o0OOOOO00o0O0 [ 0 ] ) , reverse = True )
  O00o0OO0 = sorted ( O00o0OO0 , reverse = True )
  for IIi1I1iiiii , name , url , iconimage , OO in O00o0OO0 :
   if 71 - 71: OOooO * I1iII1iiII * Ooo0
   IiIiI1111I1I = IiIiI1111I1I + 1
   o0OIiI1i . append ( url )
   if "NOT INSTALLED" not in name . upper ( ) :
    o0OOoo0OO0OOO ( "[COLOR lightblue][B]Link " + str ( IiIiI1111I1I ) + ": [/B][/COLOR]" + name , url , 3 , iconimage , OO )
   else :
    o0OOoo0OO0OOO ( name , url , 999 , iconimage , OO )
    if 56 - 56: I1Ii111
  o0oO0 . close ( )
 except :
  o0oO0 . close ( )
  iiIIIII1i1iI . ok ( Oo0Ooo , "Sorry, no links were found." )
  quit ( )
  if 54 - 54: OOoO00o / oo00000o0 . Ooo0 % iIiiI1
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 57 - 57: i11iIiiIii . oo0 - OoOoo0 - Ooo0 + o0oOoO00o
def OoOoO ( string ) :
 if 63 - 63: o0oOoO00o * iIiiI1
 I11II1i = open ( O00ooooo00 , mode = 'r' ) ; ooiIi1 = I11II1i . read ( ) ; I11II1i . close ( )
 ooiIi1 = ooiIi1 . replace ( '\n' , '' )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( ooiIi1 )
 OoOOoOooooOOo = 0
 for ooOooo000oOO in OoO0O00 :
  if 87 - 87: I1Ii111
  oOOOoo0O0oO = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( ooOooo000oOO ) [ 0 ]
  iIII1I111III = re . compile ( '<name>(.+?)</name>' ) . findall ( ooOooo000oOO ) [ 0 ]
  if 20 - 20: iIi1IIii11I . I1iII1iiII % oo00000o0 * IIiIiII11i
  if string == oOOOoo0O0oO :
   OoOOoOooooOOo = 1
   Oo0OoO00oOO0o = iIII1I111III
   if 98 - 98: I1Ii111 % OoOoo0 * IiIIi1I1Iiii
 if OoOOoOooooOOo == 0 :
  Oo0OoO00oOO0o = string
  if 51 - 51: IIiIiII11i . o0oOoO00o / Ooo0 + iIi1IIii11I
 return Oo0OoO00oOO0o
 if 33 - 33: I1Ii . I1iII1iiII % iIiiI1 + iIi1IIii11I
def oO00O000oO0 ( name , url , iconimage ) :
 if 79 - 79: oooO0oOOOOo0o - IiIIi1I1Iiii - Ooo0 - IIiIiII11i * oo00000o0
 Iii = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 Iii . setPath ( url )
 xbmc . Player ( ) . play ( url , Iii , False )
 quit ( )
 if 16 - 16: OoOoo0 + OOooO * iIiiiI1IiI1I1 % Ooo00oOo00o . I1Ii111
def Oo0OO ( ) :
 if 78 - 78: oo00000o0 - IiIIi1I1Iiii - oo0 / I1Ii / I1iII1iiII
 o0OOoo0OO0OOO ( "[COLOR white][B]FMG Supported Addons[/B][/COLOR]" , '' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "#####################################" , '' , 999 , iiiii , ooo0OO )
 if 29 - 29: I1Ii111 % I1Ii111
 Oo0O0 = [ ]
 Ooo0OOoOoO0 = [ ]
 oOo0OOoO0 = [ ]
 O000OOo00oo = [ ]
 IIo0Oo0oO0oOO00 = [ ]
 if 92 - 92: IiIIi1I1Iiii * OOoO00o
 I11II1i = open ( O00ooooo00 , mode = 'r' ) ; ooiIi1 = I11II1i . read ( ) ; I11II1i . close ( )
 ooiIi1 = ooiIi1 . replace ( '\n' , '' )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( ooiIi1 )
 for ooOooo000oOO in sorted ( OoO0O00 ) :
  oOOOoo0O0oO = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( ooOooo000oOO ) [ 0 ]
  iIII1I111III = re . compile ( '<name>(.+?)</name>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0000oO = re . compile ( '<dev>(.+?)</dev>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0O = iIII1I111III + '|SPLIT|' + oOOOoo0O0oO + '|SPLIT|' + o0000oO
  if 11 - 11: I1Ii / o0oOoO00o - OOooO * IiIIi1I1Iiii + IiIIi1I1Iiii . o0oOoO00o
  OOo0oO00ooO00 = xbmc . translatePath ( 'special://home/addons/' + oOOOoo0O0oO )
  if os . path . exists ( OOo0oO00ooO00 ) :
   if "|PAID|" in o0000oO :
    IIi1I1iiiii = "3"
   else : IIi1I1iiiii = "2"
  else :
   if not "|PAID|" in o0000oO :
    IIi1I1iiiii = "1"
   else : IIi1I1iiiii = "0"
  Oo0O0 . append ( oOOOoo0O0oO )
  Ooo0OOoOoO0 . append ( iIII1I111III )
  oOo0OOoO0 . append ( o0000oO )
  O000OOo00oo . append ( o0O )
  IIo0Oo0oO0oOO00 . append ( IIi1I1iiiii )
  IIII = list ( zip ( IIo0Oo0oO0oOO00 , Oo0O0 , Ooo0OOoOoO0 , oOo0OOoO0 , O000OOo00oo ) )
  if 26 - 26: OoOoo0 % oo0
 I1IiiIIIi = sorted ( IIII , key = lambda o0OOOOO00o0O0 : int ( o0OOOOO00o0O0 [ 0 ] ) , reverse = True )
 for IIi1I1iiiii , oOOOoo0O0oO , iIII1I111III , o0000oO , o0O in I1IiiIIIi :
  OOo0oO00ooO00 = xbmc . translatePath ( 'special://home/addons/' + oOOOoo0O0oO )
  if os . path . exists ( OOo0oO00ooO00 ) :
   o00Oo0oooooo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oOOOoo0O0oO , 'icon.png' ) )
   OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + oOOOoo0O0oO , 'fanart.jpg' ) )
   if "|PAID|" in o0000oO :
    o0O = o0O + '|SPLIT|1|SPLIT|PAID'
    o0OOoo0OO0OOO ( "[COLOR dodgerblue][B]" + iIII1I111III + " | PAID SUBSCRIPTION - INSTALLED [/B][/COLOR]" , o0O , 5 , o00Oo0oooooo , OO )
   else :
    o0O = o0O + '|SPLIT|1'
    o0OOoo0OO0OOO ( "[COLOR lightblue][B]" + iIII1I111III + " - INSTALLED [/B][/COLOR]" , o0O , 5 , o00Oo0oooooo , OO )
  else :
   if "|PAID|" in o0000oO :
    o0O = o0O + '|SPLIT|0|SPLIT|PAID'
    o0OOoo0OO0OOO ( "[COLOR darkgray]" + iIII1I111III + " | PAID SUBSCRIPTION - NOT INSTALLED [/COLOR]" , o0O , 5 , iiiii , ooo0OO )
   else :
    o0O = o0O + '|SPLIT|0'
    o0OOoo0OO0OOO ( "[COLOR darkgray]" + iIII1I111III + " - NOT INSTALLED [/COLOR]" , o0O , 5 , iiiii , ooo0OO )
    if 76 - 76: oooO0oOOOOo0o / oo00000o0 . iIiiiI1IiI1I1 % I1Ii111 . iIi1IIii11I + OOooO
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 71 - 71: OOoO00o . I1iII1iiII
def oo0oOOOoo00 ( url ) :
 if 9 - 9: iIiiiI1IiI1I1 % iIiiiI1IiI1I1 - iIi1IIii11I
 OoO = "null"
 try :
  Oo0OoO00oOO0o , url , o0000oO , IIi1I1iiiii , OoO = url . split ( '|SPLIT|' )
 except :
  Oo0OoO00oOO0o , url , o0000oO , IIi1I1iiiii = url . split ( '|SPLIT|' )
  if 12 - 12: iIiiiI1IiI1I1 - iIi1IIii11I
 if OoO != "null" :
  o0000oO = o0000oO . replace ( "|PAID|" , "" )
  if 81 - 81: o0oOoO00o - o0oOoO00o . iIiiI1
 iiIIIII1i1iI . ok ( Oo0Ooo , "You can contact the developer of " + Oo0OoO00oOO0o + " on:" , "[COLOR orangered]" + o0000oO + "[/COLOR]" )
 if 73 - 73: oooO0oOOOOo0o % i11iIiiIii - I1Ii111
 if IIi1I1iiiii == "1" :
  Ii1iI111II1I1 = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to launch ' + Oo0OoO00oOO0o + ' now?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if Ii1iI111II1I1 == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
 else :
  Ii1iI111II1I1 = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]' + Oo0OoO00oOO0o + ' is not installed. If the addon is available for download in any repository currently installed on your system we can attempt to install the addon. Would you like us to try and install ' + Oo0OoO00oOO0o + '?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if Ii1iI111II1I1 == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
   if 91 - 91: oo00000o0 % oo00000o0 - I1Ii111
def OOO00O ( name , url , mode , iconimage , fanartimage ) :
 if 18 - 18: oooO0oOOOOo0o - i11iIiiIii / I1iII1iiII . oo00000o0
 OoOo00o0O00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 iiI = True
 Iii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 Iii . setProperty ( "fanart_Image" , fanartimage )
 Iii . setProperty ( "icon_Image" , iconimage )
 iiI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOo00o0O00 , listitem = Iii , isFolder = True )
 return iiI
 if 71 - 71: oooO0oOOOOo0o
def o0OOoo0OO0OOO ( name , url , mode , iconimage , fanartimage ) :
 if 41 - 41: OOooO / iIiiiI1IiI1I1
 OoOo00o0O00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 iiI = True
 Iii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 Iii . setProperty ( "fanart_Image" , fanartimage )
 Iii . setProperty ( "icon_Image" , iconimage )
 iiI = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OoOo00o0O00 , listitem = Iii , isFolder = False )
 return iiI
 if 51 - 51: oooO0oOOOOo0o % I1Ii111
def OoOo ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 OooOo = xbmcgui . Window ( id )
 i11III1111iIi = 50
 while ( i11III1111iIi > 0 ) :
  try :
   xbmc . sleep ( 10 )
   i11III1111iIi -= 1
   OooOo . getControl ( 1 ) . setLabel ( heading )
   OooOo . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 38 - 38: iIiiI1 + oooO0oOOOOo0o / OOoO00o % I1Ii - oo0
def O00Oo000ooO0 ( url ) :
 iI11 = urllib2 . Request ( url )
 iI11 . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 Ii1I = urllib2 . urlopen ( iI11 )
 O0OOO0OOoO0O = Ii1I . read ( )
 Ii1I . close ( )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return O0OOO0OOoO0O
 if 88 - 88: oooO0oOOOOo0o % oo0
def ii1I1i1I ( url ) :
 iI11 = urllib2 . Request ( url )
 iI11 . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 Ii1I = urllib2 . urlopen ( iI11 )
 O0OOO0OOoO0O = Ii1I . read ( )
 Ii1I . close ( )
 return O0OOO0OOoO0O
 if 48 - 48: I1Ii / OOoO00o . IIiIiII11i * o0oOoO00o * Ooo0 / Ooo00oOo00o
 if 92 - 92: OOo % OOo - iIi1IIii11I / o0oOoO00o
 if 10 - 10: iIiiI1 + OOo * oo0 + IIiIiII11i / OOoO00o / oo0
 if 42 - 42: I1Ii111
 if 38 - 38: oo00000o0 + I1iII1iiII % I1Ii % o0oOoO00o - OoOoo0 / IiIIi1I1Iiii
def oOOoo0000O0o0 ( ) :
 if 1 - 1: Ooo0 + Ooo0 % o0oOoO00o + i11iIiiIii
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 56 - 56: iIi1IIii11I
 if os . path . exists ( oo00 ) == True :
  for I1 , OooooO0oOOOO , o0O00oOOoo in os . walk ( oo00 ) :
   i1I1iIi = 0
   i1I1iIi += len ( o0O00oOOoo )
   if i1I1iIi > 0 :
    for I11II1i in o0O00oOOoo :
     try :
      if ( I11II1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( I1 , I11II1i ) )
     except :
      pass
    for O0 in OooooO0oOOOO :
     try :
      shutil . rmtree ( os . path . join ( I1 , O0 ) )
     except :
      pass
      if 22 - 22: o0oOoO00o * iIiiiI1IiI1I1 . OOooO * i11iIiiIii - I1Ii111 * I1Ii
   else :
    pass
    if 59 - 59: OOo % IiIIi1I1Iiii . iIiiI1 / OOooO + I1Ii111
 if os . path . exists ( o00 ) == True :
  for I1 , OooooO0oOOOO , o0O00oOOoo in os . walk ( o00 ) :
   i1I1iIi = 0
   i1I1iIi += len ( o0O00oOOoo )
   if i1I1iIi > 0 :
    for I11II1i in o0O00oOOoo :
     try :
      if ( I11II1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( I1 , I11II1i ) )
     except :
      pass
    for O0 in OooooO0oOOOO :
     try :
      shutil . rmtree ( os . path . join ( I1 , O0 ) )
     except :
      pass
      if 76 - 76: I1Ii
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  OoO0O00O0oo0O = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 36 - 36: oo00000o0 + iIiiiI1IiI1I1 - OoOoo0 - iIiiiI1IiI1I1 % oooO0oOOOOo0o . Ooo0
  for I1 , OooooO0oOOOO , o0O00oOOoo in os . walk ( OoO0O00O0oo0O ) :
   i1I1iIi = 0
   i1I1iIi += len ( o0O00oOOoo )
   if 74 - 74: i11iIiiIii . I1Ii111
   if i1I1iIi > 0 :
    for I11II1i in o0O00oOOoo :
     os . unlink ( os . path . join ( I1 , I11II1i ) )
    for O0 in OooooO0oOOOO :
     shutil . rmtree ( os . path . join ( I1 , O0 ) )
     if 36 - 36: IiIIi1I1Iiii . II1ii
   else :
    pass
  oO = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 10 - 10: OOo / OOo / OOoO00o . OOoO00o
  for I1 , OooooO0oOOOO , o0O00oOOoo in os . walk ( oO ) :
   i1I1iIi = 0
   i1I1iIi += len ( o0O00oOOoo )
   if 98 - 98: OOo / I1Ii111 . iIiiiI1IiI1I1 + II1ii
   if i1I1iIi > 0 :
    for I11II1i in o0O00oOOoo :
     os . unlink ( os . path . join ( I1 , I11II1i ) )
    for O0 in OooooO0oOOOO :
     shutil . rmtree ( os . path . join ( I1 , O0 ) )
     if 43 - 43: I1iII1iiII . Ooo0 / oo0
   else :
    pass
    if 20 - 20: I1Ii111
 o0oO0o00oo = IiIiIi ( )
 if 95 - 95: iIiiI1 - I1Ii111
 for I1ii1ii11i1I in o0oO0o00oo :
  o0OoOO = xbmc . translatePath ( I1ii1ii11i1I . path )
  if os . path . exists ( o0OoOO ) == True :
   for I1 , OooooO0oOOOO , o0O00oOOoo in os . walk ( o0OoOO ) :
    i1I1iIi = 0
    i1I1iIi += len ( o0O00oOOoo )
    if i1I1iIi > 0 :
     for I11II1i in o0O00oOOoo :
      os . unlink ( os . path . join ( I1 , I11II1i ) )
     for O0 in OooooO0oOOOO :
      shutil . rmtree ( os . path . join ( I1 , O0 ) )
      if 55 - 55: I1Ii - oooO0oOOOOo0o + I1iII1iiII + iIiiI1 % OoOoo0
    else :
     pass
     if 41 - 41: Ooo00oOo00o - oooO0oOOOOo0o - OoOoo0
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 iiIIIII1i1iI . ok ( Oo0Ooo , "The FMG games list has been reloaded." )
 if 8 - 8: II1ii + OOoO00o - iIi1IIii11I % OOo % iIi1IIii11I * Ooo0
def IIIi11I11 ( ) :
 iIIII = [ ]
 iIIIiiI1i1i = sys . argv [ 2 ]
 if len ( iIIIiiI1i1i ) >= 2 :
  iIII = sys . argv [ 2 ]
  o0o0O = iIII . replace ( '?' , '' )
  if ( iIII [ len ( iIII ) - 1 ] == '/' ) :
   iIII = iIII [ 0 : len ( iIII ) - 2 ]
  ooooO0oOoOOoO = o0o0O . split ( '&' )
  iIIII = { }
  for I1i11i in range ( len ( ooooO0oOoOOoO ) ) :
   IiIi = { }
   IiIi = ooooO0oOoOOoO [ I1i11i ] . split ( '=' )
   if ( len ( IiIi ) ) == 2 :
    iIIII [ IiIi [ 0 ] ] = IiIi [ 1 ]
    if 87 - 87: oo0 - oo0 - iIiiI1 + Ooo0
 return iIIII
 if 82 - 82: Ooo0 / IIiIiII11i . I1Ii111 . oo00000o0 / iIi1IIii11I
iIII = IIIi11I11 ( ) ; Oo0OoO00oOO0o = None ; o0O = None ; iiI1I1 = None ; o00Oo0oooooo = None ; ooO = None
try : Oo0OoO00oOO0o = urllib . unquote_plus ( iIII [ "name" ] )
except : pass
try : o0O = urllib . unquote_plus ( iIII [ "url" ] )
except : pass
try : iiI1I1 = int ( iIII [ "mode" ] )
except : pass
try : o00Oo0oooooo = urllib . unquote_plus ( iIII [ "iconimage" ] )
except : pass
try : ooO = urllib . quote_plus ( iIII [ "fanartimage" ] )
except : pass
if 6 - 6: IIiIiII11i . I1Ii % iIi1IIii11I
if iiI1I1 == None or o0O == None or len ( o0O ) < 1 : oOOo0oo ( )
elif iiI1I1 == 1 : Get_Content ( Oo0OoO00oOO0o , o0O , o00Oo0oooooo )
elif iiI1I1 == 2 : Oo0ooOo0o ( Oo0OoO00oOO0o , o0O , o00Oo0oooooo )
elif iiI1I1 == 3 : oO00O000oO0 ( Oo0OoO00oOO0o , o0O , o00Oo0oooooo )
elif iiI1I1 == 4 : Oo0OO ( )
elif iiI1I1 == 5 : oo0oOOOoo00 ( o0O )
elif iiI1I1 == 6 : oOOoo0000O0o0 ( )
if 50 - 50: iIiiI1 + iIiiiI1IiI1I1 + OoOoo0 . I1iII1iiII / iIi1IIii11I
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )