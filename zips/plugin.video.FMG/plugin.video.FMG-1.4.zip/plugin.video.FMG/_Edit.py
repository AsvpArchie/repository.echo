import xbmcaddon

MainBase = 'http://bluebuilds.esy.es/Wizard/FMG/home.txt'
addon = xbmcaddon.Addon('plugin.video.FMG')