import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , shutil
import base64 , time , datetime
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.FMG'
Oo0Ooo = '[COLOR orangered]FIND MY GAME[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( 'special://home/addons/' + OO0o )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/art/pl.png' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/supported_addons.xml' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/notice.txt' ) )
if 27 - 27: iIiiiI1IiI1I1 * IIiIiII11i * IiIIi1I1Iiii - Ooo00oOo00o
I1IiI = xbmc . translatePath ( 'special://home/addons/' + OO0o + '/addon.xml' )
o0OOO = xbmc . translatePath ( 'special://home/addons/repository.echo/addon.xml' )
iIiiiI = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9wbHVnaW4udmlkZW8uRk1HL3BsdWdpbi52aWRlby5GTUct' )
Iii1ii1II11i = base64 . b64decode ( b'aHR0cHM6Ly9naXRodWIuY29tL2VjaG9jb2RlcmtvZGkvcmVwb3NpdG9yeS5lY2hvL3Jhdy9tYXN0ZXIvemlwcy9yZXBvc2l0b3J5LmVjaG8vcmVwb3NpdG9yeS5lY2hvLQ==' )
if 10 - 10: I1iII1iiII + I1Ii111 / OOo
i1i1II = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvc3BvcnRpZS9tZW51cy9tYWluLnhtbA==' )
O0oo0OO0 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcveHJkU3pOVUM=' )
I1i1iiI1 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvaXF6Vmp3ZXc=' )
iiIIIII1i1iI = xbmcgui . Dialog ( )
o0oO0 = xbmcgui . DialogProgress ( )
oo00 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'cache' )
o00 = os . path . join ( xbmc . translatePath ( 'special://home' ) , 'temp' )
if 62 - 62: II1ii - o0oOoO00o . iIi1IIii11I + oo0 * Ooo0 % oo00000o0
I11i1i11i1I = xbmc . getInfoLabel ( "System.BuildVersion" )
Iiii = float ( I11i1i11i1I [ : 4 ] )
if Iiii >= 11.0 and Iiii <= 11.9 :
 OOO0O = 'Eden'
if Iiii >= 12.0 and Iiii <= 12.9 :
 OOO0O = 'Frodo'
if Iiii >= 13.0 and Iiii <= 13.9 :
 OOO0O = 'Gotham'
if Iiii >= 14.0 and Iiii <= 14.9 :
 OOO0O = 'Helix'
if Iiii >= 15.0 and Iiii <= 15.9 :
 OOO0O = 'Isengard'
if Iiii >= 16.0 and Iiii <= 16.9 :
 OOO0O = 'Jarvis'
if Iiii >= 17.0 and Iiii <= 17.9 :
 OOO0O = 'Krypton'
 if 94 - 94: oooO0oOOOOo0o
 #######################################################################
 #						Cache Functions
 #######################################################################
 if 93 - 93: OoOoo0 % iIiiI1 % OOooO % OOoO00o
class II111iiii ( xbmcgui . WindowXMLDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  xbmcgui . WindowXMLDialog . __init__ ( self )
  self . header = kwargs . get ( "header" )
  self . content = kwargs . get ( "content" )
  if 48 - 48: I1Ii . i11iIiiIii - OoOoo0 % II1ii . I1Ii / iIi1IIii11I
 def onInit ( self ) :
  self . getControl ( 1 ) . setLabel ( self . header )
  self . getControl ( 5 ) . setText ( self . content )
  if 6 - 6: o0oOoO00o * iIiiI1
O00O0O0O0 = xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) . decode ( "utf-8" )
if 75 - 75: Ooo00oOo00o / OoOoo0 - iIi1IIii11I
class oo :
 def __init__ ( self , namei , pathi ) :
  self . name = namei
  self . path = pathi
  if 28 - 28: IIiIiII11i - Ooo00oOo00o
  if 70 - 70: II1ii . II1ii - II1ii / oo0 * oo00000o0
  if 86 - 86: i11iIiiIii + OoOoo0 + I1Ii * oooO0oOOOOo0o + iIi1IIii11I
  if 61 - 61: II1ii / i11iIiiIii
def IiIiIi ( ) :
 II = 5
 iI = [ "WTF" , "4oD" , "BBC iPlayer" , "Simple Downloader" , "ITV" ]
 iI11iiiI1II = [ "special://profile/addon_data/plugin.video.whatthefurk/cache" , "special://profile/addon_data/plugin.video.4od/cache" ,
 "special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache" , "special://profile/addon_data/script.module.simple.downloader" ,
 "special://profile/addon_data/plugin.video.itv/Images" ]
 if 79 - 79: OOoO00o % i11iIiiIii / IIiIiII11i . oo00000o0
 o0oO0o00oo = [ ]
 if 32 - 32: OOo * iIiiiI1IiI1I1 % Ooo0 % OoOoo0 . OOooO
 for o0OOOOO00o0O0 in range ( II ) :
  o0oO0o00oo . append ( oo ( iI [ o0OOOOO00o0O0 ] , iI11iiiI1II [ o0OOOOO00o0O0 ] ) )
  if 71 - 71: I1Ii % iIiiI1 / iIi1IIii11I
 return o0oO0o00oo
 if 49 - 49: I1iII1iiII % iIiiI1 * iIiiiI1IiI1I1
def oOOo0oo ( ) :
 if 80 - 80: oooO0oOOOOo0o * i11iIiiIii / OOoO00o
 if not os . path . isfile ( O00ooooo00 ) :
  I11II1i = open ( O00ooooo00 , 'w' )
  if 23 - 23: oo0 / iIi1IIii11I + oooO0oOOOOo0o + oooO0oOOOOo0o / I1iII1iiII
 if not os . path . isfile ( I1IiiI ) :
  I11II1i = open ( I1IiiI , 'w' )
  if 26 - 26: IiIIi1I1Iiii
 IiiI11Iiiii = ii1I1i1I ( I1i1iiI1 )
 if len ( IiiI11Iiiii ) > 1 :
  OOoo0O0 = I1IiiI
  iiiIi1i1I = open ( OOoo0O0 )
  oOO00oOO = iiiIi1i1I . read ( )
  if oOO00oOO == IiiI11Iiiii : pass
  else :
   OoOo ( '[B][COLOR white]Find My Game Notice[/COLOR][/B]' , IiiI11Iiiii )
   iIo00O = open ( OOoo0O0 , "w" )
   iIo00O . write ( IiiI11Iiiii )
   iIo00O . close ( )
   if 69 - 69: Ooo0 % OOoO00o - iIi1IIii11I + OOoO00o - iIiiiI1IiI1I1 % IiIIi1I1Iiii
 Iii111II = ii1I1i1I ( O0oo0OO0 )
 if len ( Iii111II ) > 1 :
  OOoo0O0 = O00ooooo00
  iiiIi1i1I = open ( OOoo0O0 )
  oOO00oOO = iiiIi1i1I . read ( )
  if oOO00oOO == Iii111II : pass
  else :
   iIo00O = open ( OOoo0O0 , "w" )
   iIo00O . write ( Iii111II )
   iIo00O . close ( )
   if 9 - 9: II1ii
 i11 = datetime . date . today ( )
 O0oo0OO0oOOOo = datetime . datetime . strftime ( i11 , '%A %d %B %Y' )
 if 35 - 35: OOooO % I1Ii111
 o0OOoo0OO0OOO ( '[COLOR orangered][B]EVENTS FOR ' + str ( O0oo0OO0oOOOo ) . upper ( ) + '[/B][/COLOR]' , '' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 if 19 - 19: Ooo0 % Ooo00oOo00o % iIi1IIii11I
 oo0OooOOo0 = datetime . datetime . now ( )
 o0O = base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2RheXMv' )
 O00oO = oo0OooOOo0 . day
 if 39 - 39: OOooO - I1iII1iiII * II1ii % iIi1IIii11I * I1iII1iiII % I1iII1iiII
 OoOOOOO = O00oO
 if 33 - 33: oo0 % Ooo00oOo00o
 o0O = o0O + str ( OoOOOOO ) + '.xml'
 if 78 - 78: oooO0oOOOOo0o
 OO00Oo = o0O
 O0OOO0OOoO0O = O00Oo000ooO0 ( o0O )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( O0OOO0OOoO0O )
 if 5 - 5: OOo / iIi1IIii11I . OoOoo0 - iIiiiI1IiI1I1 / OOooO
 for ooOooo000oOO in OoO0O00 :
  if 59 - 59: I1iII1iiII + IiIIi1I1Iiii * o0oOoO00o + Ooo00oOo00o
  Oo0OoO00oOO0o = re . compile ( '<title>(.+?)</title>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0O = OO00Oo + "!" + Oo0OoO00oOO0o
  try :
   Oo0OoO00oOO0o , time = Oo0OoO00oOO0o . split ( ' - ' )
   Oo0OoO00oOO0o = '[B][COLOR white]' + Oo0OoO00oOO0o + '[/COLOR] - [COLOR orangered]' + time + '[/B][/COLOR]'
  except :
   Oo0OoO00oOO0o = '[B][COLOR white]' + Oo0OoO00oOO0o + '[/B][/COLOR]'
  OOO00O ( Oo0OoO00oOO0o , o0O , 2 , II1 , ooo0OO )
  if 84 - 84: Ooo0 * II1ii / oooO0oOOOOo0o - iIiiiI1IiI1I1
 o0OOoo0OO0OOO ( '[COLOR orangered]Refresh List of Games[/COLOR]' , 'url' , 6 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '##############################################' , '' , 999 , iiiii , ooo0OO )
 OOO00O ( '[COLOR orangered]FMG Supported Addons[/COLOR]' , 'url' , 4 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @EchoCoder[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( '[COLOR white]Twitter:[/COLOR][COLOR orangered] @blue_builds[/COLOR]' , 'url' , 999 , iiiii , ooo0OO )
 if 30 - 30: IIiIiII11i / I1Ii - OOoO00o - I1iII1iiII % iIiiI1
 IIi1i11111 = open ( I1IiI ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  I1ii11iI = float ( ooOooo000oOO )
 IIi1i11111 = open ( o0OOO ) . read ( )
 ooOO00O00oo = IIi1i11111 . replace ( '\n' , ' ' ) . replace ( '\r' , ' ' )
 OoO0O00 = re . compile ( 'name=".+?".+?version="(.+?)".+?provider-name=".+?">' ) . findall ( str ( ooOO00O00oo ) )
 for ooOooo000oOO in OoO0O00 :
  IIi1i = float ( ooOooo000oOO )
  if 46 - 46: OOoO00o % oooO0oOOOOo0o + II1ii . o0oOoO00o . II1ii
 o0OOoo0OO0OOO ( "[COLOR orangered]Addon Version:[/COLOR] [COLOR white]" + str ( I1ii11iI ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "[COLOR orangered]Repository Version:[/COLOR] [COLOR white]" + str ( IIi1i ) + "[/COLOR]" , 'url' , 999 , iiiii , ooo0OO )
 if 96 - 96: OOo
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 45 - 45: iIiiiI1IiI1I1 * iIi1IIii11I % OOo * IiIIi1I1Iiii + iIiiI1 . o0oOoO00o
def Oo0ooOo0o ( name , url , iconimage ) :
 if 22 - 22: IIiIiII11i / i11iIiiIii * IIiIiII11i * I1iII1iiII . oo00000o0 / i11iIiiIii
 try :
  url , IiiiOO0OoO0o00 = url . split ( '!' )
 except :
  iiIIIII1i1iI . ok ( Oo0Ooo , "[COLOR white]Sorry there was a problem processing your request.[/COLOR]" , "[COLOR blue]Sporie has plenty of content to choose from :-D[/COLOR]" )
  quit ( )
  if 53 - 53: iIiiiI1IiI1I1 * II1ii + oo00000o0
 Ii = [ ]
 if 61 - 61: I1iII1iiII
 O0OOO0OOoO0O = O00Oo000ooO0 ( url )
 O0OOO = re . compile ( '<title>' + re . escape ( IiiiOO0OoO0o00 ) + '</title>(.+?)</item>' , re . DOTALL ) . findall ( O0OOO0OOoO0O ) [ 0 ]
 II11iIiIIIiI = re . compile ( '<search>(.+?)</search>' ) . findall ( O0OOO )
 for o0o in II11iIiIIIiI :
  Ii . append ( o0o )
  if 84 - 84: iIiiiI1IiI1I1
 o0oO0 . create ( Oo0Ooo , "[COLOR blue]We are just getting the channel links for you.[/COLOR]" , '[COLOR yellow]Please wait...[/COLOR]' , '' )
 o0oO0 . update ( 0 )
 if 74 - 74: oo0 - I1Ii111 - OOo . OoOoo0 - OOooO
 OOOoOoo0O = [ ]
 O000OOo00oo = [ ]
 o0oO0 . update ( 0 )
 oo0OOo = ii1I1i1I ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9ucy5pbmk=' ) )
 if 64 - 64: oooO0oOOOOo0o
 oo0OOo = oo0OOo . replace ( '\r' , '' )
 oo0OOo = oo0OOo . split ( '\n' )
 for iI11Ii in oo0OOo :
  if 6 - 6: Ooo0
  try :
   IIi1i11111 = iI11Ii . split ( '=' ) [ 0 ]
   ooOO00O00oo = str ( IIi1i11111 )
   oOOo0oOo0 = ooOO00O00oo + '='
   IIooooo = str ( iI11Ii )
   II1I = IIooooo . replace ( oOOo0oOo0 , '' )
   ooOO00O00oo = ooOO00O00oo . strip ( )
   II1I = II1I . strip ( )
   OOOoOoo0O . append ( ooOO00O00oo )
   O000OOo00oo . append ( II1I )
   O0 = list ( zip ( OOOoOoo0O , O000OOo00oo ) )
  except : pass
  if 5 - 5: OOoO00o
 oo0OOo = ii1I1i1I ( base64 . decodestring ( 'aHR0cDovL2VjaG9jb2Rlci5jb20vcHJpdmF0ZS9hZGRvbnMvZm1nL2FkZG9uc19wYWlkLmluaQ==' ) )
 if 87 - 87: oooO0oOOOOo0o - IIiIiII11i + I1Ii111 . iIiiI1
 oo0OOo = oo0OOo . replace ( '\r' , '' )
 oo0OOo = oo0OOo . split ( '\n' )
 for iI11Ii in oo0OOo :
  if 62 - 62: iIiiiI1IiI1I1 * Ooo00oOo00o * iIi1IIii11I - I1Ii111 + I1Ii111
  try :
   IIi1i11111 = iI11Ii . split ( '=' ) [ 0 ]
   ooOO00O00oo = str ( IIi1i11111 )
   oOOo0oOo0 = ooOO00O00oo + '='
   IIooooo = str ( iI11Ii )
   II1I = IIooooo . replace ( oOOo0oOo0 , '' )
   ooOO00O00oo = ooOO00O00oo . strip ( )
   II1I = II1I . strip ( )
   OOOoOoo0O . append ( ooOO00O00oo )
   O000OOo00oo . append ( II1I )
   O0 = list ( zip ( OOOoOoo0O , O000OOo00oo ) )
  except : pass
  if 34 - 34: IIiIiII11i - iIi1IIii11I
 o00oooO0Oo = sorted ( O0 )
 o0O0OOO0Ooo = sorted ( Ii )
 if 45 - 45: iIiiiI1IiI1I1 / iIi1IIii11I
 o0oO0 . update ( 100 )
 if 32 - 32: iIiiI1 . OOooO . OOooO
 OO00O0O = [ ]
 iii = [ ]
 oOooOOOoOo = [ ]
 i1Iii1i1I = [ ]
 OOoO00 = [ ]
 if 40 - 40: I1Ii111 * OoOoo0 + oo00000o0 % iIiiI1
 for OOOOOoo0 in o0O0OOO0Ooo :
  if 49 - 49: iIiiiI1IiI1I1 . iIiiI1
  I1iI1iIi111i = OOOOOoo0 . split ( ' ' )
  if 44 - 44: Ooo00oOo00o % I1iII1iiII + oooO0oOOOOo0o
  for name , url in o00oooO0Oo :
   if OOOOOoo0 . lower ( ) in name . lower ( ) :
    try :
     I1I1I = name
     IIi1i11111 = url . split ( "in://" ) [ 1 ]
     ooOO00O00oo = IIi1i11111 . split ( "/" ) [ 0 ]
     OoOO000 = xbmc . translatePath ( 'special://home/addons/' + ooOO00O00oo )
     if 14 - 14: OOooO - oo0
     if os . path . exists ( OoOO000 ) :
      iconimage = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + ooOO00O00oo , 'icon.png' ) )
      Ii1i1iI1iIIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + ooOO00O00oo , 'fanart.jpg' ) )
      name = I1IiO0oo00o0O ( ooOO00O00oo )
      i1I1I = "[COLOR white][B]" + name + '[/B][/COLOR] - [COLOR orangered]' + I1I1I + "[/COLOR]"
      OO00O0O . append ( "1" )
      iii . append ( i1I1I )
      oOooOOOoOo . append ( url )
      i1Iii1i1I . append ( iconimage )
      OOoO00 . append ( Ii1i1iI1iIIi )
     else :
      OO00O0O . append ( "0" )
      name = I1IiO0oo00o0O ( ooOO00O00oo )
      i1I1I = '[COLOR darkgray]' + name + ' - ' + I1I1I + ' | Addon Not Installed[/COLOR]'
      iii . append ( i1I1I )
      oOooOOOoOo . append ( url )
      i1Iii1i1I . append ( iiiii )
      OOoO00 . append ( ooo0OO )
     iiI1I = list ( zip ( OO00O0O , iii , oOooOOOoOo , i1Iii1i1I , OOoO00 ) )
    except : pass
  I1iI1iIi111i = ""
  if 12 - 12: i11iIiiIii - Ooo00oOo00o - II1ii . Ooo00oOo00o - oo00000o0 + iIiiiI1IiI1I1
 oO0OOOO0 = [ ]
 if 26 - 26: OoOoo0
 try :
  I11iiI1i1 = sorted ( iiI1I , key = lambda o0OOOOO00o0O0 : int ( o0OOOOO00o0O0 [ 0 ] ) , reverse = True )
  I11iiI1i1 = sorted ( I11iiI1i1 , reverse = True )
  for I1i1Iiiii , name , url , iconimage , Ii1i1iI1iIIi in I11iiI1i1 :
   if url not in str ( oO0OOOO0 ) :
    oO0OOOO0 . append ( url )
    o0OOoo0OO0OOO ( name , url , 3 , iconimage , Ii1i1iI1iIIi )
    if 94 - 94: iIi1IIii11I * OoOoo0 / OOo / OoOoo0
  o0oO0 . close ( )
 except :
  o0oO0 . close ( )
  iiIIIII1i1iI . ok ( Oo0Ooo , "Sorry, no links were found." )
  quit ( )
  if 87 - 87: OOo . OOooO
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 75 - 75: I1Ii + o0oOoO00o + iIi1IIii11I * oooO0oOOOOo0o % Ooo0 . iIiiI1
def I1IiO0oo00o0O ( string ) :
 if 55 - 55: oo00000o0 . I1Ii111
 I11II1i = open ( O00ooooo00 , mode = 'r' ) ; oOo0O0o00o = I11II1i . read ( ) ; I11II1i . close ( )
 oOo0O0o00o = oOo0O0o00o . replace ( '\n' , '' )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( oOo0O0o00o )
 o00oO0oo0OO = 0
 for ooOooo000oOO in OoO0O00 :
  if 57 - 57: OOoO00o % OoOoo0 + iIi1IIii11I - OOo
  o0OIiI1i = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0Oo00 = re . compile ( '<name>(.+?)</name>' ) . findall ( ooOooo000oOO ) [ 0 ]
  if 32 - 32: iIi1IIii11I . OOooO * oooO0oOOOOo0o
  if string == o0OIiI1i :
   o00oO0oo0OO = 1
   Oo0OoO00oOO0o = o0Oo00
   if 93 - 93: iIi1IIii11I % Ooo00oOo00o . OoOoo0 . i11iIiiIii
 if o00oO0oo0OO == 0 :
  Oo0OoO00oOO0o = string
  if 56 - 56: oo0 % iIiiiI1IiI1I1 - I1Ii111
 return Oo0OoO00oOO0o
 if 100 - 100: OoOoo0 - iIiiiI1IiI1I1 % Ooo0 * oo00000o0 + I1Ii111
def Oo0O0oooo ( name , url , iconimage ) :
 if 33 - 33: OOoO00o + iIiiI1 * Ooo0 / IIiIiII11i - I1Ii111
 O0oO = xbmcgui . ListItem ( name , iconImage = iiiii , thumbnailImage = iiiii )
 O0oO . setPath ( url )
 xbmc . Player ( ) . play ( url , O0oO , False )
 quit ( )
 if 73 - 73: oo0 * i11iIiiIii % Ooo0 . oo0
def OOOOo0 ( ) :
 if 49 - 49: I1iII1iiII % iIiiiI1IiI1I1 . o0oOoO00o + Ooo0 / I1Ii111
 o0OOoo0OO0OOO ( "[COLOR white][B]FMG Supported Addons[/B][/COLOR]" , '' , 999 , iiiii , ooo0OO )
 o0OOoo0OO0OOO ( "#####################################" , '' , 999 , iiiii , ooo0OO )
 if 72 - 72: I1Ii * OOo . I1Ii111 - I1iII1iiII + Ooo00oOo00o
 iIi1ii = [ ]
 oOOOoo0O0oO = [ ]
 iIII1I111III = [ ]
 O000OOo00oo = [ ]
 IIo0o0O0O00oOOo = [ ]
 if 14 - 14: o0oOoO00o + Ooo0
 I11II1i = open ( O00ooooo00 , mode = 'r' ) ; oOo0O0o00o = I11II1i . read ( ) ; I11II1i . close ( )
 oOo0O0o00o = oOo0O0o00o . replace ( '\n' , '' )
 OoO0O00 = re . compile ( '<item>(.+?)</item>' ) . findall ( oOo0O0o00o )
 for ooOooo000oOO in sorted ( OoO0O00 ) :
  o0OIiI1i = re . compile ( '<plugin>(.+?)</plugin>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0Oo00 = re . compile ( '<name>(.+?)</name>' ) . findall ( ooOooo000oOO ) [ 0 ]
  oo00oO0O0 = re . compile ( '<dev>(.+?)</dev>' ) . findall ( ooOooo000oOO ) [ 0 ]
  o0O = o0Oo00 + '|SPLIT|' + o0OIiI1i + '|SPLIT|' + oo00oO0O0
  if 30 - 30: oo00000o0 + oo0 * oooO0oOOOOo0o % i11iIiiIii % o0oOoO00o
  OoOO000 = xbmc . translatePath ( 'special://home/addons/' + o0OIiI1i )
  if os . path . exists ( OoOO000 ) :
   I1i1Iiiii = "1"
  else : I1i1Iiiii = "0"
  iIi1ii . append ( o0OIiI1i )
  oOOOoo0O0oO . append ( o0Oo00 )
  iIII1I111III . append ( oo00oO0O0 )
  O000OOo00oo . append ( o0O )
  IIo0o0O0O00oOOo . append ( I1i1Iiiii )
  O0 = list ( zip ( IIo0o0O0O00oOOo , iIi1ii , oOOOoo0O0oO , iIII1I111III , O000OOo00oo ) )
  if 97 - 97: oo0 % oo0 % Ooo0 / iIiiI1 - IIiIiII11i
 o00oooO0Oo = sorted ( O0 , key = lambda o0OOOOO00o0O0 : int ( o0OOOOO00o0O0 [ 0 ] ) , reverse = True )
 for I1i1Iiiii , o0OIiI1i , o0Oo00 , oo00oO0O0 , o0O in o00oooO0Oo :
  OoOO000 = xbmc . translatePath ( 'special://home/addons/' + o0OIiI1i )
  if os . path . exists ( OoOO000 ) :
   o0O = o0O + '|SPLIT|1'
   ooooo0O0000oo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + o0OIiI1i , 'icon.png' ) )
   Ii1i1iI1iIIi = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + o0OIiI1i , 'fanart.jpg' ) )
   o0OOoo0OO0OOO ( "[COLOR white][B]" + o0Oo00 + " - INSTALLED [/B][/COLOR]" , o0O , 5 , ooooo0O0000oo , Ii1i1iI1iIIi )
  else :
   o0O = o0O + '|SPLIT|0'
   o0OOoo0OO0OOO ( "[COLOR darkgray]" + o0Oo00 + " - NOT INSTALLED [/COLOR]" , o0O , 5 , iiiii , ooo0OO )
   if 21 - 21: iIi1IIii11I - I1Ii111
 if OOO0O == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OOO0O == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 18 - 18: OOo + oooO0oOOOOo0o % oo00000o0 - IiIIi1I1Iiii - oo0 / Ooo00oOo00o
def oo0oO ( url ) :
 if 94 - 94: IIiIiII11i / OOo % iIiiI1 * iIiiI1 * I1iII1iiII
 Oo0OoO00oOO0o , url , oo00oO0O0 , I1i1Iiiii = url . split ( '|SPLIT|' )
 if 29 - 29: II1ii + o0oOoO00o / iIi1IIii11I / oo00000o0 * IIiIiII11i
 iiIIIII1i1iI . ok ( Oo0Ooo , "You can contact the developer of " + Oo0OoO00oOO0o + " on:" , "[COLOR orangered]" + oo00oO0O0 + "[/COLOR]" )
 if 62 - 62: oo00000o0 / Ooo0 - II1ii . oooO0oOOOOo0o
 if I1i1Iiiii == "1" :
  IIo0Oo0oO0oOO00 = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Would you like to launch ' + Oo0OoO00oOO0o + ' now?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if IIo0Oo0oO0oOO00 == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
 else :
  IIo0Oo0oO0oOO00 = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]' + Oo0OoO00oOO0o + ' is not installed. If the addon is available for download in any repository currently installed on your system we can attempt to install the addon. Would you like us to try and install ' + Oo0OoO00oOO0o + '?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR orangered]NO[/COLOR]' )
  if IIo0Oo0oO0oOO00 == 1 :
   xbmc . executebuiltin ( 'ActivateWindow(10025,plugin://' + url + ')' )
   if 92 - 92: IiIIi1I1Iiii * OOoO00o
def OOO00O ( name , url , mode , iconimage , fanartimage ) :
 if 100 - 100: OOoO00o + OOoO00o * OOooO
 I1i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 O00Oooo = True
 O0oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 O0oO . setProperty ( "fanart_Image" , fanartimage )
 O0oO . setProperty ( "icon_Image" , iconimage )
 O00Oooo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1i , listitem = O0oO , isFolder = True )
 return O00Oooo
 if 46 - 46: oooO0oOOOOo0o / OoOoo0
def o0OOoo0OO0OOO ( name , url , mode , iconimage , fanartimage ) :
 if 57 - 57: OOooO / iIiiI1 * iIiiiI1IiI1I1 - IiIIi1I1Iiii % IIiIiII11i
 I1i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 O00Oooo = True
 O0oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 O0oO . setProperty ( "fanart_Image" , fanartimage )
 O0oO . setProperty ( "icon_Image" , iconimage )
 O00Oooo = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1i , listitem = O0oO , isFolder = False )
 return O00Oooo
 if 33 - 33: Ooo00oOo00o / OoOoo0
def OoOo ( heading , text ) :
 id = 10147
 xbmc . executebuiltin ( 'ActivateWindow(%d)' % id )
 xbmc . sleep ( 500 )
 ooO0oooOO0 = xbmcgui . Window ( id )
 o0ooo0 = 50
 while ( o0ooo0 > 0 ) :
  try :
   xbmc . sleep ( 10 )
   o0ooo0 -= 1
   ooO0oooOO0 . getControl ( 1 ) . setLabel ( heading )
   ooO0oooOO0 . getControl ( 5 ) . setText ( text )
   return
  except :
   pass
   if 61 - 61: o0oOoO00o - oo00000o0 - Ooo00oOo00o
def O00Oo000ooO0 ( url ) :
 IiI1iIiIIIii = urllib2 . Request ( url )
 IiI1iIiIIIii . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 oOoO = urllib2 . urlopen ( IiI1iIiIIIii )
 O0OOO0OOoO0O = oOoO . read ( )
 oOoO . close ( )
 O0OOO0OOoO0O = O0OOO0OOoO0O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 return O0OOO0OOoO0O
 if 81 - 81: o0oOoO00o - o0oOoO00o . iIiiI1
def ii1I1i1I ( url ) :
 IiI1iIiIIIii = urllib2 . Request ( url )
 IiI1iIiIIIii . add_header ( 'User-Agent' , base64 . decodestring ( 'VGhlV2l6YXJkSXNIZXJl' ) )
 oOoO = urllib2 . urlopen ( IiI1iIiIIIii )
 O0OOO0OOoO0O = oOoO . read ( )
 oOoO . close ( )
 return O0OOO0OOoO0O
 if 73 - 73: oooO0oOOOOo0o % i11iIiiIii - I1Ii111
 if 7 - 7: iIiiiI1IiI1I1 * i11iIiiIii * OoOoo0 + I1Ii % II1ii - I1Ii
 if 39 - 39: OOo * oo00000o0 % oo00000o0 - IiIIi1I1Iiii + iIi1IIii11I - oooO0oOOOOo0o
 if 23 - 23: i11iIiiIii
 if 30 - 30: iIi1IIii11I - Ooo00oOo00o % I1iII1iiII + oooO0oOOOOo0o * IIiIiII11i
def o0ooooO0o0O ( ) :
 if 24 - 24: iIiiiI1IiI1I1 * iIi1IIii11I
 xbmc . executebuiltin ( "ActivateWindow(busydialog)" )
 if 29 - 29: I1Ii111 % oo00000o0 - I1Ii111 / oo00000o0 . Ooo00oOo00o
 if os . path . exists ( oo00 ) == True :
  for i11III1111iIi , I1i111I , Ooo in os . walk ( oo00 ) :
   Oo0oo0O0o00O = 0
   Oo0oo0O0o00O += len ( Ooo )
   if Oo0oo0O0o00O > 0 :
    for I11II1i in Ooo :
     try :
      if ( I11II1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( i11III1111iIi , I11II1i ) )
     except :
      pass
    for IIooooo in I1i111I :
     try :
      shutil . rmtree ( os . path . join ( i11III1111iIi , IIooooo ) )
     except :
      pass
      if 48 - 48: I1Ii / OOoO00o . IIiIiII11i * o0oOoO00o * Ooo0 / Ooo00oOo00o
   else :
    pass
    if 92 - 92: OOo % OOo - iIi1IIii11I / o0oOoO00o
 if os . path . exists ( o00 ) == True :
  for i11III1111iIi , I1i111I , Ooo in os . walk ( o00 ) :
   Oo0oo0O0o00O = 0
   Oo0oo0O0o00O += len ( Ooo )
   if Oo0oo0O0o00O > 0 :
    for I11II1i in Ooo :
     try :
      if ( I11II1i . endswith ( ".log" ) ) : continue
      os . unlink ( os . path . join ( i11III1111iIi , I11II1i ) )
     except :
      pass
    for IIooooo in I1i111I :
     try :
      shutil . rmtree ( os . path . join ( i11III1111iIi , IIooooo ) )
     except :
      pass
      if 10 - 10: iIiiI1 + OOo * oo0 + IIiIiII11i / OOoO00o / oo0
   else :
    pass
 if xbmc . getCondVisibility ( 'system.platform.ATV2' ) :
  iI1II = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'Other' )
  if 69 - 69: I1Ii % Ooo0
  for i11III1111iIi , I1i111I , Ooo in os . walk ( iI1II ) :
   Oo0oo0O0o00O = 0
   Oo0oo0O0o00O += len ( Ooo )
   if 50 - 50: IiIIi1I1Iiii % oooO0oOOOOo0o
   if Oo0oo0O0o00O > 0 :
    for I11II1i in Ooo :
     os . unlink ( os . path . join ( i11III1111iIi , I11II1i ) )
    for IIooooo in I1i111I :
     shutil . rmtree ( os . path . join ( i11III1111iIi , IIooooo ) )
     if 49 - 49: Ooo0 - i11iIiiIii . OOoO00o * OoOoo0 % iIiiI1 + Ooo00oOo00o
   else :
    pass
  oOO0OOOo = os . path . join ( '/private/var/mobile/Library/Caches/AppleTV/Video/' , 'LocalAndRental' )
  if 56 - 56: iIi1IIii11I
  for i11III1111iIi , I1i111I , Ooo in os . walk ( oOO0OOOo ) :
   Oo0oo0O0o00O = 0
   Oo0oo0O0o00O += len ( Ooo )
   if 28 - 28: iIiiI1 . iIiiI1 % IIiIiII11i * IIiIiII11i . iIi1IIii11I / iIiiI1
   if Oo0oo0O0o00O > 0 :
    for I11II1i in Ooo :
     os . unlink ( os . path . join ( i11III1111iIi , I11II1i ) )
    for IIooooo in I1i111I :
     shutil . rmtree ( os . path . join ( i11III1111iIi , IIooooo ) )
     if 27 - 27: II1ii + I1Ii - Ooo00oOo00o
   else :
    pass
    if 69 - 69: OOooO - iIiiiI1IiI1I1 % oo0 + i11iIiiIii . o0oOoO00o / II1ii
 o0oO0o00oo = IiIiIi ( )
 if 79 - 79: iIiiiI1IiI1I1 * i11iIiiIii - OOooO / OOooO
 for i1 in o0oO0o00oo :
  O0I11Iiii1I = xbmc . translatePath ( i1 . path )
  if os . path . exists ( O0I11Iiii1I ) == True :
   for i11III1111iIi , I1i111I , Ooo in os . walk ( O0I11Iiii1I ) :
    Oo0oo0O0o00O = 0
    Oo0oo0O0o00O += len ( Ooo )
    if Oo0oo0O0o00O > 0 :
     for I11II1i in Ooo :
      os . unlink ( os . path . join ( i11III1111iIi , I11II1i ) )
     for IIooooo in I1i111I :
      shutil . rmtree ( os . path . join ( i11III1111iIi , IIooooo ) )
      if 90 - 90: IIiIiII11i % I1Ii
    else :
     pass
     if 73 - 73: iIiiiI1IiI1I1 * iIiiI1 + OoOoo0 + I1Ii
 xbmc . executebuiltin ( "Dialog.Close(busydialog)" )
 xbmc . executebuiltin ( "Container.Refresh" )
 time . sleep ( 0.5 )
 iiIIIII1i1iI . ok ( Oo0Ooo , "The FMG games list has been reloaded." )
 if 40 - 40: I1iII1iiII . o0oOoO00o * OOoO00o + oo00000o0 + oo00000o0
def I1ii1I1iiii ( ) :
 iiI = [ ]
 oO = sys . argv [ 2 ]
 if len ( oO ) >= 2 :
  IIiIi = sys . argv [ 2 ]
  OOoOooOoOOOoo = IIiIi . replace ( '?' , '' )
  if ( IIiIi [ len ( IIiIi ) - 1 ] == '/' ) :
   IIiIi = IIiIi [ 0 : len ( IIiIi ) - 2 ]
  Iiii1iI1i = OOoOooOoOOOoo . split ( '&' )
  iiI = { }
  for I1ii1ii11i1I in range ( len ( Iiii1iI1i ) ) :
   o0OoOO = { }
   o0OoOO = Iiii1iI1i [ I1ii1ii11i1I ] . split ( '=' )
   if ( len ( o0OoOO ) ) == 2 :
    iiI [ o0OoOO [ 0 ] ] = o0OoOO [ 1 ]
    if 55 - 55: I1Ii - oooO0oOOOOo0o + I1iII1iiII + iIiiI1 % OoOoo0
 return iiI
 if 41 - 41: Ooo00oOo00o - oooO0oOOOOo0o - OoOoo0
IIiIi = I1ii1I1iiii ( ) ; Oo0OoO00oOO0o = None ; o0O = None ; III11I1 = None ; ooooo0O0000oo = None ; IIi1IIIi = None
try : Oo0OoO00oOO0o = urllib . unquote_plus ( IIiIi [ "name" ] )
except : pass
try : o0O = urllib . unquote_plus ( IIiIi [ "url" ] )
except : pass
try : III11I1 = int ( IIiIi [ "mode" ] )
except : pass
try : ooooo0O0000oo = urllib . unquote_plus ( IIiIi [ "iconimage" ] )
except : pass
try : IIi1IIIi = urllib . quote_plus ( IIiIi [ "fanartimage" ] )
except : pass
if 99 - 99: OoOoo0 + II1ii * I1iII1iiII . iIi1IIii11I - oo0
if III11I1 == None or o0O == None or len ( o0O ) < 1 : oOOo0oo ( )
elif III11I1 == 1 : Get_Content ( Oo0OoO00oOO0o , o0O , ooooo0O0000oo )
elif III11I1 == 2 : Oo0ooOo0o ( Oo0OoO00oOO0o , o0O , ooooo0O0000oo )
elif III11I1 == 3 : Oo0O0oooo ( Oo0OoO00oOO0o , o0O , ooooo0O0000oo )
elif III11I1 == 4 : OOOOo0 ( )
elif III11I1 == 5 : oo0oO ( o0O )
elif III11I1 == 6 : o0ooooO0o0O ( )
if 58 - 58: OoOoo0 + iIi1IIii11I - I1Ii111
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )