import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.teevie'
Oo0Ooo = '[COLOR mediumpurple]TEEVIE[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmcgui . Dialog ( )
II1 = xbmcgui . DialogProgress ( )
O00ooooo00 = base64 . b64decode ( b'aHR0cDovL2dvb2dsZS5jb20=' )
if 32 - 32: ooOoO + iIiiiI1IiI1I1 * IIiIiII11i * o0oOOo0O0Ooo
def I1ii11iIi11i ( ) :
 if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
 IiiIII111iI ( "[COLOR dodgerblue]These sources contain 1000's of IPTV links.[/COLOR]" , O00ooooo00 , 999 , iiiii , O0O0OO0O0O0 , '' )
 IiiIII111iI ( "[COLOR dodgerblue]Please browse to find hidden treasures![/COLOR]" , O00ooooo00 , 999 , iiiii , O0O0OO0O0O0 , '' )
 IiiIII111iI ( "################################################################" , O00ooooo00 , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
 Oo ( '[COLOR mediumpurple]Source 1[/COLOR]' , base64 . b64decode ( b'aHR0cDovL3NvdXJjZXR2LmluZm8=' ) , 203 , iiiii , O0O0OO0O0O0 )
 Oo ( '[COLOR mediumpurple]Source 2[/COLOR]' , O00ooooo00 , 201 , iiiii , O0O0OO0O0O0 )
 #addDir('[COLOR mediumpurple]Source 3[/COLOR]',base64.b64decode(b'aHR0cDovL3d3dy5pcHR2ZW1iZWQubmV0L2lwdHYv'),202,icon,fanarts)
 if 27 - 27: o00 * O0 - Ooo / IiIiI11iIi - O0OOo . ooOoO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 89 - 89: O0 - iIiiiI1IiI1I1 - OOooOOo . o00 * Ooo * o0oOOo0O0Ooo
def i1IIi11111i ( ) :
 if 74 - 74: O0 * Ooo
 oo00o0Oo0oo = 0
 i1iII1I1i1i1 = i1iIIII ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 I1 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
 for O0OoOoo00o in I1 :
  oo00o0Oo0oo = oo00o0Oo0oo + 1
  O0OoOoo00o = O0OoOoo00o . replace ( '<br />' , '\n' )
  iiiI11 = O0OoOoo00o
  Oo ( '[COLOR mediumpurple]LIST ' + str ( oo00o0Oo0oo ) + '[/COLOR]' , iiiI11 , 3 , iiiii , O0O0OO0O0O0 )
  if 91 - 91: O00oOoOoO0o0O / oO0o . O0oo0OO0 + I1i1iI1i
 i1iII1I1i1i1 = i1iIIII ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MTA=' ) )
 I1 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
 for O0OoOoo00o in I1 :
  oo00o0Oo0oo = oo00o0Oo0oo + 1
  O0OoOoo00o = O0OoOoo00o . replace ( '<br />' , '\n' )
  iiiI11 = O0OoOoo00o
  Oo ( '[COLOR mediumpurple]LIST ' + str ( oo00o0Oo0oo ) + '[/COLOR]' , iiiI11 , 3 , iiiii , O0O0OO0O0O0 )
  if 47 - 47: iii1I1I / o00 * IIiIiII11i
 i1iII1I1i1i1 = i1iIIII ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MjA=' ) )
 I1 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
 for O0OoOoo00o in I1 :
  oo00o0Oo0oo = oo00o0Oo0oo + 1
  O0OoOoo00o = O0OoOoo00o . replace ( '<br />' , '\n' )
  iiiI11 = O0OoOoo00o
  Oo ( '[COLOR mediumpurple]LIST ' + str ( oo00o0Oo0oo ) + '[/COLOR]' , iiiI11 , 3 , iiiii , O0O0OO0O0O0 )
  if 9 - 9: OOooOOo - o00 % o0oOOo0O0Ooo % IIiIiII11i
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 3 - 3: O0 + ooOoO
def I1Ii ( url ) :
 if 66 - 66: o00
 i1iII1I1i1i1 = i1iIIII ( url )
 I1 = re . compile ( '<div class="entry-content"(.+?)</div>' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
 if 78 - 78: Ii1I
 for O0OoOoo00o in I1 :
  Iii1I111 = re . compile ( 'title="(.+?)"' ) . findall ( O0OoOoo00o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( O0OoOoo00o ) [ 0 ]
  OO0O0O00OooO = re . compile ( '<img.+?src="(.+?)"' ) . findall ( O0OoOoo00o ) [ 0 ]
  Oo ( '[COLOR dodgerblue]' + Iii1I111 + '[/COLOR]' , url , 2 , OO0O0O00OooO , O0O0OO0O0O0 )
  if 77 - 77: oO0o - oO0o . OOooOOo / O00oOoOoO0o0O
 try :
  i1iIIIiI1I = re . compile ( "<link rel='next' href='(.+?)'" , re . DOTALL ) . findall ( i1iII1I1i1i1 ) [ 0 ]
  Oo ( '[COLOR yellow]Next Page -->[/COLOR]' , i1iIIIiI1I , 202 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 70 - 70: I11i % I11i . Ooo % Ii1I * O00oOoOoO0o0O % Oo0ooO0oo0oO
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 23 - 23: i11iIiiIii + OOooOOo
def oOo ( url ) :
 if 63 - 63: I11i
 i1iII1I1i1i1 = i1iIIII ( url )
 I1 = re . compile ( '<li class="cat-item cat-item(.+?)</li>' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
 for O0OoOoo00o in I1 :
  try :
   Iii1I111 = re . compile ( 'title=".+?">(.+?)</a>' ) . findall ( O0OoOoo00o ) [ 0 ]
  except :
   Iii1I111 = re . compile ( '<a href=".+?" >(.+?)</a>' ) . findall ( O0OoOoo00o ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"' ) . findall ( O0OoOoo00o ) [ 0 ]
  Oo ( '[COLOR dodgerblue]' + Iii1I111 + '[/COLOR]' , url , 204 , iiiii , O0O0OO0O0O0 )
  if 57 - 57: Oo0ooO0oo0oO
def iI ( url ) :
 if 22 - 22: I11i % o00
 i1iII1I1i1i1 = i1iIIII ( url )
 I1 = re . compile ( '<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
 oo = 0
 for O0OoOoo00o in I1 :
  try :
   Iii1I111 = re . compile ( 'title="(.+?)"' ) . findall ( O0OoOoo00o ) [ 0 ]
   url = re . compile ( '<a href="(.+?)"' ) . findall ( O0OoOoo00o ) [ 0 ]
   OO0O0O00OooO = re . compile ( '<img.+?src="(.+?)"' ) . findall ( O0OoOoo00o ) [ 0 ]
  except : oo = 1
  if 54 - 54: I1i1iI1i + I1i1iI1i % IiIiI11iIi % i11iIiiIii / iIiiiI1IiI1I1 . I1i1iI1i
  if oo == 0 :
   Oo ( '[COLOR dodgerblue]' + Iii1I111 + '[/COLOR]' , url , 2 , OO0O0O00OooO , O0O0OO0O0O0 )
  oo = 0
  if 57 - 57: o00 % IIiIiII11i
 try :
  i1iIIIiI1I = re . compile ( '<link rel="next" href="(.+?)" />' , re . DOTALL ) . findall ( i1iII1I1i1i1 ) [ 0 ]
  Oo ( '[COLOR yellow]Next Page -->[/COLOR]' , i1iIIIiI1I , 204 , iiiii , O0O0OO0O0O0 )
 except : pass
 if 61 - 61: O0 . iIiiiI1IiI1I1 * OOooOOo . O0OOo % I11i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 72 - 72: I1i1iI1i
 if 63 - 63: o00
def O00 ( name , url , iconimage ) :
 if 35 - 35: O00oOoOoO0o0O + O0 + O0
 try :
  i1iII1I1i1i1 = i1iIIII ( url )
  if 11 - 11: O0 - Ii1I % O0OOo % O0 / iii1I1I - Ii1I
  if "username" in i1iII1I1i1i1 :
   oo00o0Oo0oo = 1
   I1 = re . compile ( '<p>Copy the iptv stream and open in VLC(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
   o0o0oOOOo0oo = str ( I1 )
   o0oo0o0O00OO = re . compile ( 'http(.+?)br' , re . DOTALL ) . findall ( o0o0oOOOo0oo )
   oo = 0
   for O0OoOoo00o in o0oo0o0O00OO :
    try :
     url = re . compile ( '//(.+?)<' ) . findall ( O0OoOoo00o ) [ 0 ]
     url = url . replace ( '&amp;' , '&' )
     if "username" in url :
      o0oO = url . split ( 'username=' ) [ 1 ]
      I1i1iii = o0oO . split ( '&' ) [ 0 ]
     else : oo = 1
    except :
     oo = 1
     if 20 - 20: O00oOoOoO0o0O
    if oo == 0 :
     Oo ( "[COLOR yellow][I]" + str ( I1i1iii ) . upper ( ) + ' [/I][/COLOR]  - [COLOR mediumpurple]Thank you for this list![/COLOR]' , 'http://' + url , 3 , iconimage , O0O0OO0O0O0 )
    oo = 0
  else :
   oO00 ( name , url , iconimage )
 except :
  ooo0OO . ok ( Oo0Ooo , "There was an error connecting to the host. Please try again later." )
  quit ( )
  if 53 - 53: IIiIiII11i . o0oOOo0O0Ooo
def oO00 ( name , url , iconimage ) :
 if 18 - 18: O00oOoOoO0o0O
 try :
  if "iptvembed" in url :
   i1iII1I1i1i1 = i1iIIII ( url )
   I1 = re . compile ( '#EXTM3U<br />(.+?)<div></div>' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
   for O0OoOoo00o in I1 :
    O0OoOoo00o = O0OoOoo00o . replace ( '<br />' , '\n' )
    O0OoOoo00o = O0OoOoo00o . replace ( '</pre>' , '' )
    url = O0OoOoo00o
  elif "sourcetv" in url :
   i1iII1I1i1i1 = i1iIIII ( url )
   I1 = re . compile ( '<pre class="alt2"(.+?)<br class="clearer" />' , re . DOTALL ) . findall ( i1iII1I1i1i1 )
   for O0OoOoo00o in I1 :
    O0OoOoo00o = O0OoOoo00o . replace ( '<br />' , '\n' )
    O0OoOoo00o = O0OoOoo00o . replace ( '</pre>' , '' )
    url = O0OoOoo00o
  elif not " " in url :
   url = i1iIIII ( url )
  else : url = url
  if 28 - 28: I1i1iI1i - Ooo . Ooo + iii1I1I - IIiIiII11i + ooOoO
  url = url . replace ( '#AAASTREAM:' , '#A:' )
  url = url . replace ( '#EXTINF:' , '#A:' )
  oOoOooOo0o0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( url )
  OOOO = [ ]
  for OOO00 , iiiiiIIii , url in oOoOooOo0o0 :
   O000OO0 = { "params" : OOO00 , "display_name" : iiiiiIIii , "url" : url }
   OOOO . append ( O000OO0 )
  list = [ ]
  for I11iii1Ii in OOOO :
   O000OO0 = { "display_name" : I11iii1Ii [ "display_name" ] , "url" : I11iii1Ii [ "url" ] }
   oOoOooOo0o0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I11iii1Ii [ "params" ] )
   for I1IIiiIiii , O000oo0O in oOoOooOo0o0 :
    O000OO0 [ I1IIiiIiii . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O000oo0O . strip ( )
   list . append ( O000OO0 )
   OOOOi11i1 = 0
  for I11iii1Ii in list :
   OOOOi11i1 = 1
   name = IIIii1II1II ( I11iii1Ii [ "display_name" ] )
   url = IIIii1II1II ( I11iii1Ii [ "url" ] )
   url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if not ".m3u8" in url :
    IiiIII111iI ( '[COLOR mediumpurple]' + name + '[/COLOR]' , url , 4 , iconimage , O0O0OO0O0O0 , '' )
   if OOOOi11i1 == 0 :
    IiiIII111iI ( '[COLOR red]Sorry, No links found in this list.[/COLOR]' , url , 999 , iiiii , O0O0OO0O0O0 , '' )
 except :
  ooo0OO . ok ( Oo0Ooo , "There was an error gathering the list. Please try another." )
  quit ( )
  if 42 - 42: o00 + Oo0ooO0oo0oO
def IIIii1II1II ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 76 - 76: IiIiI11iIi - Ii1I
def oOooOOo00Oo0O ( name , url , iconimage ) :
 if 72 - 72: O0 / o0oOOo0O0Ooo * I11i - IiIiI11iIi
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url
   if 51 - 51: oO0o * Ii1I % O00oOoOoO0o0O * oO0o % O0oo0OO0 / O0OOo
 if "plugin://" in url :
  url = "PlayMedia(" + url + ")"
  xbmc . executebuiltin ( url )
  quit ( )
  if 49 - 49: O00oOoOoO0o0O
 IIii1Ii1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , IIii1Ii1 , False )
 if 5 - 5: O0 % I1i1iI1i + O0OOo % i11iIiiIii + O00oOoOoO0o0O
def i1iIIII ( url ) :
 if 60 - 60: Ii1I * iii1I1I - Ii1I % IIiIiII11i - O0OOo + OOooOOo
 O00Oo000ooO0 = urllib2 . Request ( url )
 O00Oo000ooO0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 OoO0O00 = urllib2 . urlopen ( O00Oo000ooO0 )
 IIiII = OoO0O00 . read ( )
 OoO0O00 . close ( )
 return IIiII
 if 80 - 80: Ooo . Oo0ooO0oo0oO
def IIi ( ) :
 i11iIIIIIi1 = [ ]
 iiII1i1 = sys . argv [ 2 ]
 if len ( iiII1i1 ) >= 2 :
  OOO00 = sys . argv [ 2 ]
  o00oOO0o = OOO00 . replace ( '?' , '' )
  if ( OOO00 [ len ( OOO00 ) - 1 ] == '/' ) :
   OOO00 = OOO00 [ 0 : len ( OOO00 ) - 2 ]
  OOO00O = o00oOO0o . split ( '&' )
  i11iIIIIIi1 = { }
  for oo00o0Oo0oo in range ( len ( OOO00O ) ) :
   OOoOO0oo0ooO = { }
   OOoOO0oo0ooO = OOO00O [ oo00o0Oo0oo ] . split ( '=' )
   if ( len ( OOoOO0oo0ooO ) ) == 2 :
    i11iIIIIIi1 [ OOoOO0oo0ooO [ 0 ] ] = OOoOO0oo0ooO [ 1 ]
 return i11iIIIIIi1
 if 98 - 98: O0 * O0 / O0 + II
def Oo ( name , url , mode , iconimage , fanart , description = '' ) :
 if 34 - 34: O0OOo
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I1111I1iII11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 Oooo0O0oo00oO = True
 IIii1Ii1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 IIii1Ii1 . setProperty ( "fanart_Image" , fanart )
 IIii1Ii1 . setProperty ( "icon_Image" , iconimage )
 Oooo0O0oo00oO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1111I1iII11 , listitem = IIii1Ii1 , isFolder = True )
 return Oooo0O0oo00oO
 if 14 - 14: iii1I1I / Ooo . iii1I1I . II % Ii1I * II
def IiiIII111iI ( name , url , mode , iconimage , fanart , description = '' ) :
 if 16 - 16: iii1I1I . O0OOo + i11iIiiIii
 if "imgur" in iconimage :
  if not ".jpg" in iconimage :
   if not ".png" in iconimage :
    iconimage = iconimage + ".jpg"
 if "imgur" in fanart :
  if not ".jpg" in fanart :
   if not ".png" in fanart :
    fanart = fanart + ".jpg"
 I1111I1iII11 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 Oooo0O0oo00oO = True
 IIii1Ii1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 IIii1Ii1 . setProperty ( "fanart_Image" , fanart )
 IIii1Ii1 . setProperty ( "icon_Image" , iconimage )
 Oooo0O0oo00oO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1111I1iII11 , listitem = IIii1Ii1 , isFolder = False )
 return Oooo0O0oo00oO
 if 38 - 38: Ooo * I1i1iI1i . O00oOoOoO0o0O
OOO00 = IIi ( ) ; iiiI11 = None ; Iii1I111 = None ; ooo0OOO0 = None ; ii1ii1ii = None ; OO0O0O00OooO = None ; oooooOoo0ooo = None
try : ii1ii1ii = urllib . unquote_plus ( OOO00 [ "site" ] )
except : pass
try : iiiI11 = urllib . unquote_plus ( OOO00 [ "url" ] )
except : pass
try : Iii1I111 = urllib . unquote_plus ( OOO00 [ "name" ] )
except : pass
try : ooo0OOO0 = int ( OOO00 [ "mode" ] )
except : pass
try : OO0O0O00OooO = urllib . unquote_plus ( OOO00 [ "iconimage" ] )
except : pass
try : oooooOoo0ooo = urllib . unquote_plus ( OOO00 [ "fanart" ] )
except : pass
if 6 - 6: II - o00 + iIiiiI1IiI1I1 - IiIiI11iIi - i11iIiiIii
if ooo0OOO0 == None or iiiI11 == None or len ( iiiI11 ) < 1 : I1ii11iIi11i ( )
elif ooo0OOO0 == 1 : SCRAPE ( iiiI11 )
elif ooo0OOO0 == 2 : O00 ( Iii1I111 , iiiI11 , OO0O0O00OooO )
elif ooo0OOO0 == 3 : oO00 ( Iii1I111 , iiiI11 , OO0O0O00OooO )
elif ooo0OOO0 == 4 : oOooOOo00Oo0O ( Iii1I111 , iiiI11 , OO0O0O00OooO )
elif ooo0OOO0 == 201 : i1IIi11111i ( )
elif ooo0OOO0 == 202 : I1Ii ( iiiI11 )
elif ooo0OOO0 == 203 : oOo ( iiiI11 )
elif ooo0OOO0 == 204 : iI ( iiiI11 )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )