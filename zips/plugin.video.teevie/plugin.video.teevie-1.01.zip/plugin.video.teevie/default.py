import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys
import base64
import requests
import time

addon_id            = 'plugin.video.teevie'
AddonTitle          = '[COLOR mediumpurple]TEEVIE[/COLOR]'
fanarts             = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
icon                = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
dialog              = xbmcgui.Dialog()
dp                  = xbmcgui.DialogProgress()
BASE                = base64.b64decode(b'aHR0cDovL3NvdXJjZXR2LmluZm8=')
cachePath           = os.path.join(xbmc.translatePath('special://home'), 'cache')
tempPath            = os.path.join(xbmc.translatePath('special://home'), 'temp')

#######################################################################
#						Cache Functions
#######################################################################

class Gui(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        xbmcgui.WindowXMLDialog.__init__(self)
        self.header = kwargs.get("header")
        self.content = kwargs.get("content")

    def onInit(self):
        self.getControl(1).setLabel(self.header)
        self.getControl(5).setText(self.content)

path   = xbmcaddon.Addon().getAddonInfo('path').decode("utf-8")

class cacheEntry:
    def __init__(self, namei, pathi):
        self.name = namei
        self.path = pathi	

#######################################################################
#						Maintenance Functions
#######################################################################
def setupCacheEntries():
    entries = 5 #make sure this refelcts the amount of entries you have
    dialogName = ["WTF", "4oD", "BBC iPlayer", "Simple Downloader", "ITV"]
    pathName = ["special://profile/addon_data/plugin.video.whatthefurk/cache", "special://profile/addon_data/plugin.video.4od/cache",
					"special://profile/addon_data/plugin.video.iplayer/iplayer_http_cache","special://profile/addon_data/script.module.simple.downloader",
                    "special://profile/addon_data/plugin.video.itv/Images"]
                    
    cacheEntries = []
    
    for x in range(entries):
        cacheEntries.append(cacheEntry(dialogName[x],pathName[x]))
    
    return cacheEntries
	
#######################################################################
#						Clear Cache
#######################################################################

def clearCache():

    xbmc.executebuiltin( "ActivateWindow(busydialog)" )
    
    if os.path.exists(cachePath)==True:    
        for root, dirs, files in os.walk(cachePath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                    for f in files:
                        try:
							if (f.endswith(".log")): continue
							os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
				
    if os.path.exists(tempPath)==True:    
        for root, dirs, files in os.walk(tempPath):
            file_count = 0
            file_count += len(files)
            if file_count > 0:
                    for f in files:
                        try:
                            if (f.endswith(".log")): continue
                            os.unlink(os.path.join(root, f))
                        except:
                            pass
                    for d in dirs:
                        try:
                            shutil.rmtree(os.path.join(root, d))
                        except:
                            pass
                        
            else:
                pass
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:                
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
            file_count = 0
            file_count += len(files)
        
            if file_count > 0:
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                        
            else:
                pass    
                
    cacheEntries = setupCacheEntries()
                                         
    for entry in cacheEntries:
        clear_cache_path = xbmc.translatePath(entry.path)
        if os.path.exists(clear_cache_path)==True:    
            for root, dirs, files in os.walk(clear_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                        for f in files:
                            os.unlink(os.path.join(root, f))
                        for d in dirs:
                            shutil.rmtree(os.path.join(root, d))
                            
                else:
                    pass
                
    xbmc.executebuiltin( "Dialog.Close(busydialog)" )
    xbmc.executebuiltin("Container.Refresh")
    time.sleep(0.5)
    dialog.ok(AddonTitle, "The Sportie menu has been reloaded.")

def GetMenu():

	i = 0
	result = open_url(BASE)
	match = re.compile('<li class="cat-item cat-item(.+?)</li>',re.DOTALL).findall(result)
	for item in match:
		try:
			name=re.compile('title=".+?">(.+?)</a>').findall(item)[0]         				
		except:
			name=re.compile('<a href=".+?" >(.+?)</a>').findall(item)[0]         				
		url=re.compile('<a href="(.+?)"').findall(item)[0]     
		if not "vlc stream" in name.lower():
			i = i + 1
			addDir('[COLOR mediumpurple]'+ name +'[/COLOR]',url,1,icon,fanarts)

	if i == 0:
		addLink('[COLOR red]We were unable to load the list.[/COLOR]',url,999,icon,fanarts)
		addLink('[COLOR red]The website may be down at the moment.[/COLOR]',url,999,icon,fanarts)
		addLink('[COLOR red]Please refresh the list below to try again.[/COLOR]',url,999,icon,fanarts)
		addLink('[COLOR yellow]Click to reload the menu list.[/COLOR]',url,900,icon,fanarts)

	xbmc.executebuiltin('Container.SetViewMode(50)')

def SCRAPE(url):

	result = open_url(url)
	
	match = re.compile('<div class="panel-wrapper">(.+?)<div class="article-excerpt-wrapper">',re.DOTALL).findall(result)
	fail = 0
	for item in match:
		try:
			name=re.compile('title="(.+?)"').findall(item)[0]        				         				
			url=re.compile('<a href="(.+?)"').findall(item)[0] 
			iconimage=re.compile('<img.+?src="(.+?)"').findall(item)[0]  
		except: fail = 1
		
		if fail == 0:
			addDir('[COLOR mediumpurple]'+ name +'[/COLOR]',url,2,iconimage,fanarts)
		fail = 0

	try:
		nexturl=re.compile('<link rel="next" href="(.+?)" />',re.DOTALL).findall(result)[0]         				
		addDir('[COLOR dodgerblue]Next Page -->[/COLOR]',nexturl,1,icon,fanarts)
	except: pass

	xbmc.executebuiltin('Container.SetViewMode(500)')

def FIND_OUT(name,url,iconimage):

	result = open_url(url)

	if "username" in result:
		i = 1
		match = re.compile('<p>Copy the iptv stream and open in VLC(.+?)<br class="clearer" />',re.DOTALL).findall(result)
		string = str(match)
		match2 = re.compile('http(.+?)br',re.DOTALL).findall(string)
		fail = 0
		for item in match2:
			try:
				url=re.compile('//(.+?)<').findall(item)[0] 
				url = url.replace('&amp;','&')
				if "username" in url:
					a = url.split('username=')[1]
					b = a.split('&')[0]
				else: fail = 1
			except: 
				fail = 1

			if fail == 0:
				addDir("[COLOR yellow][I]" + str(b).upper() + ' [/I][/COLOR]  - [COLOR mediumpurple]Thank you for this list![/COLOR]','http://'+url,3,iconimage,fanarts)
			fail = 0
	else:
		GENERATE_M3U8(name,url,iconimage)

def GENERATE_M3U8(name,url,iconimage):

	try:
		if not "sourcetv" in url:
			url = open_url(url)
		else:
			result = open_url(url)
			match = re.compile('<pre class="alt2"(.+?)<br class="clearer" />',re.DOTALL).findall(result)
			for item in match:
				item = item.replace('<br />','\n')
				item = item.replace('</pre>','')
				url = item

		url = url.replace('#AAASTREAM:','#A:')
		url = url.replace('#EXTINF:','#A:')
		matches=re.compile('^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$',re.I+re.M+re.U+re.S).findall(url)
		li = []
		for params, display_name, url in matches:
			item_data = {"params": params, "display_name": display_name, "url": url}
			li.append(item_data)
		list = []
		for channel in li:
			item_data = {"display_name": channel["display_name"], "url": channel["url"]}
			matches=re.compile(' (.+?)="(.+?)"',re.I+re.M+re.U+re.S).findall(channel["params"])
			for field, value in matches:
				item_data[field.strip().lower().replace('-', '_')] = value.strip()
			list.append(item_data)

		found = 0
		for channel in list:
			found = 1
			name = GetEncodeString(channel["display_name"])
			url = GetEncodeString(channel["url"])
			url = url.replace('\\r','').replace('\\t','').replace('\r','').replace('\t','').replace(' ','').replace('m3u8','m3u8')
			if not ".m3u8" in url:
				addLink('[COLOR mediumpurple]' + name + '[/COLOR]',url,4,iconimage,fanarts,'')

		if found == 0:
			addLink('[COLOR red]Sorry, No links found in this list.[/COLOR]',url,999,icon,fanarts,'')
	except: 
		dialog.ok(AddonTitle, "There was an error gathering the list. Please try another.")
		quit()

def GetEncodeString(str):
	try:
		import chardet
		str = str.decode(chardet.detect(str)["encoding"]).encode("utf-8")
	except:
		try:
			str = str.encode("utf-8")
		except:
			pass
	return str

def PLAYLINK(name,url,iconimage):

	name = name.replace('  ','')
	if not 'f4m'in url:
		if '.m3u8' in url:
			url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url+'&amp;iconImage='+icon	
		elif '.ts'in url:
			url = url.replace('.ts','.m3u8')
			url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url+'&amp;iconImage='+icon	
	else: url = url + '|User-Agent=Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'
	
	stream_url=url
	liz = xbmcgui.ListItem(name,iconImage=icon, thumbnailImage=icon)
	liz.setPath(stream_url)
	xbmc.Player ().play(stream_url, liz, False)

def open_url(url):

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]                    
        return param
	
def addDir(name,url,mode,iconimage,fanart,description=''):

	if "imgur" in iconimage:
		if not ".jpg" in iconimage:
			if not ".png" in iconimage:
				iconimage = iconimage + ".jpg"
	if "imgur" in fanart:
		if not ".jpg" in fanart:
			if not ".png" in fanart:
				fanart = fanart + ".jpg"
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setProperty( "fanart_Image", fanart )
	liz.setProperty( "icon_Image", iconimage )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

def addLink(name, url, mode, iconimage, fanart, description=''):

	if "imgur" in iconimage:
		if not ".jpg" in iconimage:
			if not ".png" in iconimage:
				iconimage = iconimage + ".jpg"
	if "imgur" in fanart:
		if not ".jpg" in fanart:
			if not ".png" in fanart:
				fanart = fanart + ".jpg"
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	liz.setProperty( "fanart_Image", fanart )
	liz.setProperty( "icon_Image", iconimage )
	#if "plugin://" in url:
	#	liz.setProperty("IsPlayable","false")
	#elif "NOTPLAY" in url:
	#	liz.setProperty("IsPlayable","false")
	#elif ".ts" in url:
	#	liz.setProperty("IsPlayable","false")
	#else: liz.setProperty("IsPlayable","true")
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	return ok

params=get_params(); url=None; name=None; mode=None; site=None; iconimage=None; fanart=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: fanart=urllib.unquote_plus(params["fanart"])
except: pass
 
if mode==None or url==None or len(url)<1: GetMenu()
elif mode==1:SCRAPE(url)
elif mode==2:FIND_OUT(name,url,iconimage)
elif mode==3:GENERATE_M3U8(name,url,iconimage)
elif mode==4:PLAYLINK(name,url,iconimage)
elif mode==900:clearCache()

xbmcplugin.endOfDirectory(int(sys.argv[1]))