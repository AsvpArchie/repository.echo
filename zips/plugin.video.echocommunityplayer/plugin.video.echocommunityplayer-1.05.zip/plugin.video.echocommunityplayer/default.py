import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64 , time , urlresolver , liveresolver
from urllib2 import urlopen
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echocommunityplayer'
Oo0Ooo = '[COLOR yellowgreen]ECHO Community Player[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmcgui . Dialog ( )
II1 = xbmcgui . DialogProgress ( )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
I1IiiI = base64 . b64decode ( b'aHR0cDovL2VjaG9jb2Rlci5jb20v' )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'controls.txt' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'disclaimer.txt' ) )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'agreed.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o ) )
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
def o0O ( ) :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 if not os . path . exists ( oO00oOo ) :
  O0oOO0o0 = open ( I11i11Ii , mode = 'r' ) ; i1ii1iIII = O0oOO0o0 . read ( ) ; O0oOO0o0 . close ( )
  Oo0oO0oo0oO00 ( "%s" % i1ii1iIII )
  i111I = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Do you agree to the terms and conditions of this addon?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR red]NO[/COLOR]' )
  if i111I == 1 :
   if not os . path . exists ( OOOo0 ) :
    os . makedirs ( OOOo0 )
   open ( oO00oOo , 'w' )
  else :
   sys . exit ( 0 )
   if 16 - 16: Oo0oO0ooo % IiIiI11iIi - O0OOo . O0Oooo00 . oo00 * I11
 if not os . path . exists ( OOOo0 ) :
  i111I = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , "[COLOR white]We can see that this is your first time using the addon. Would you like to enable the parental controls now?[/COLOR]" , "" , yeslabel = '[COLOR red]NO[/COLOR]' , nolabel = '[COLOR lime]YES[/COLOR]' )
  if i111I == 0 :
   Oo0o0000o0o0 ( )
  else :
   os . makedirs ( OOOo0 )
   if 86 - 86: iiiii11iII1 % O0o
 elif os . path . exists ( IIi1IiiiI1Ii ) :
  oO0 = IIIi1i1I ( heading = "Please Enter Your Password" )
  if ( not oO0 ) :
   ooo0OO . ok ( Oo0Ooo , "Sorry, no password was entered." )
   sys . exit ( 0 )
  OOoOoo00oo = oO0
  if 41 - 41: i11IiIiiIIIII / ooOoO0o / O0o
  oOO = open ( IIi1IiiiI1Ii , "r" )
  I1iiiiI1iII = re . compile ( r'<password>(.+?)</password>' )
  for IiIi11i in oOO :
   file = I1iiiiI1iII . findall ( IiIi11i )
   for iIii1I111I11I in file :
    OO00OooO0OO = base64 . b64decode ( iIii1I111I11I )
    if not OO00OooO0OO == OOoOoo00oo :
     if not iIii1I111I11I == OOoOoo00oo :
      ooo0OO . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      sys . exit ( 0 )
      if 28 - 28: Oo
 iii11iII ( '[COLOR yellowgreen]SUBMIT A LINK/LIST [/COLOR][COLOR white](M3U, TS, M3U8, MP4, MKV, MP3 etc)[/COLOR]' , I1IiiI , 3 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( '#########################################################################' , I1IiiI , 999 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( "[COLOR yellowgreen]TWITTER SUPPORT: [/COLOR][COLOR white]@ECHOCODER[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
 if not os . path . exists ( IIi1IiiiI1Ii ) :
  i1I111I ( "[COLOR yellowgreen]PARENTAL CONTROLS - [COLOR red]OFF[/COLOR][/COLOR]" , "url" , 11 , iiiii , O0O0OO0O0O0 , '' )
 else :
  i1I111I ( "[COLOR yellowgreen]PARENTAL CONTROLS - [COLOR lime]ON[/COLOR][/COLOR]" , "url" , 11 , iiiii , O0O0OO0O0O0 , '' )
  if 1 - 1: iiiii11iII1 % I1Ii111 * O0Oooo00
 iii11iII ( '#########################################################################' , I1IiiI , 999 , iiiii , O0O0OO0O0O0 , '' )
 i1I111I ( '[COLOR yellowgreen]VIEW ALL: [/COLOR][COLOR white]M3U LISTS[/COLOR]' , 'm3u' , 4 , iiiii , O0O0OO0O0O0 , '' )
 i1I111I ( '[COLOR yellowgreen]VIEW ALL: [/COLOR][COLOR white]DIRECT LINKS[/COLOR]' , 'direct' , 4 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( '##################LATEST ADDED########################' , I1IiiI , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 55 - 55: iIIIiiIIiiiIi / i11iIiiIii + O0OOo + I1Ii111
 if 17 - 17: IiIiI11iIi . IiII . Oo0oO0ooo
 IIi = I1IiiI + base64 . b64decode ( b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249cmVhZCZidWlsZD0=' ) + base64 . b64encode ( '[COLOR orangered][B]List[/B][/COLOR]' )
 O0oOO0o0 = urllib2 . urlopen ( IIi )
 i1I11 = O0oOO0o0 . read ( )
 O0oOO0o0 . close ( )
 if 26 - 26: i11iIiiIii
 OO0O00 = 0
 ii1 = o0oO0o00oo ( i1I11 )
 for II1i1Ii11Ii11 in ii1 :
  if OO0O00 < 10 :
   iII11i = II1i1Ii11Ii11 [ 'name' ]
   O0O00o0OOO0 = II1i1Ii11Ii11 [ 'review' ]
   Ii1iIIIi1ii = II1i1Ii11Ii11 [ 'date' ]
   if 80 - 80: O0Oooo00 * i11iIiiIii / O0o
   I11II1i = '[COLOR dodgerblue]' + iII11i + '[/COLOR] - [COLOR white]' + O0O00o0OOO0 + '[/COLOR] | [COLOR dodgerblue]' + Ii1iIIIi1ii + '[/COLOR]'
   if 23 - 23: Oo0oO0ooo / o00O0oo + O0Oooo00 + O0Oooo00 / Oo
   iii11iII ( I11II1i , O0O00o0OOO0 , 1 , iiiii , O0O0OO0O0O0 , '' )
   OO0O00 = OO0O00 + 1
   if 26 - 26: i1oOo0OoO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 12 - 12: i1oOo0OoO % ooOoO0o / i11IiIiiIIIII % o00O0oo
def iiii ( name , url , iconimage ) :
 if 54 - 54: Oo0oO0ooo * O0OOo
 I1IIIii = url
 if 95 - 95: I1Ii111 % IiIiI11iIi . i1
 if url == "m3u" :
  i1I111I ( '[COLOR yellowgreen]VIEWING ALL M3U LISTS[/COLOR]' , I1IiiI , 4 , iiiii , O0O0OO0O0O0 , '' )
 else :
  i1I111I ( '[COLOR yellowgreen]VIEWING ALL DIRECT LINKS[/COLOR]' , I1IiiI , 4 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( '#########################################################################' , I1IiiI , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 15 - 15: i11IiIiiIIIII / oo00 . oo00 - iIIIiiIIiiiIi
 IIi = I1IiiI + base64 . b64decode ( b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249cmVhZCZidWlsZD0=' ) + base64 . b64encode ( '[COLOR orangered][B]List[/B][/COLOR]' )
 O0oOO0o0 = urllib2 . urlopen ( IIi )
 i1I11 = O0oOO0o0 . read ( )
 O0oOO0o0 . close ( )
 if 53 - 53: iiiii11iII1 + iII111i * IiIiI11iIi
 ii1 = o0oO0o00oo ( i1I11 )
 for II1i1Ii11Ii11 in ii1 :
  name = II1i1Ii11Ii11 [ 'name' ]
  url = II1i1Ii11Ii11 [ 'review' ]
  Ii1iIIIi1ii = II1i1Ii11Ii11 [ 'date' ]
  if 61 - 61: iIIIiiIIiiiIi * O0OOo / i1oOo0OoO . i11iIiiIii . ooOoO0o
  I11II1i = '[COLOR dodgerblue]' + name + '[/COLOR] - [COLOR white]' + url + '[/COLOR] | [COLOR dodgerblue]' + Ii1iIIIi1ii + '[/COLOR]'
  if 60 - 60: O0Oooo00 / O0Oooo00
  if I1IIIii == "m3u" :
   if "m3u" in url :
    if not "m3u8" in url :
     iii11iII ( I11II1i , url , 1 , iiiii , O0O0OO0O0O0 , '' )
  else :
   if "m3u8" in url :
    iii11iII ( I11II1i , url , 1 , iiiii , O0O0OO0O0O0 , '' )
   elif not "m3u" in url :
    iii11iII ( I11II1i , url , 1 , iiiii , O0O0OO0O0O0 , '' )
    if 46 - 46: oo00 * O0OOo - I1Ii111 * IiIiI11iIi - O0o
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 83 - 83: i1oOo0OoO
def Iii111II ( name , url , iconimage ) :
 if 9 - 9: I1Ii111
 name = name . split ( '-' ) [ 0 ]
 if 'm3u' in url :
  if not 'm3u8' in url :
   i11 ( url )
  else :
   O0oo0OO0oOOOo ( name , url , iconimage )
 else :
  O0oo0OO0oOOOo ( name , url , iconimage )
  if 35 - 35: iiiii11iII1 % iII111i
def i11 ( url ) :
 if 70 - 70: I11 * Oo0oO0ooo
 list = i1II1 ( url )
 if 66 - 66: i1oOo0OoO + oo00 + oo00 - iIIIiiIIiiiIi
 for O0o0Ooo in list :
  iII11i = O00 ( O0o0Ooo [ "display_name" ] )
  url = O00 ( O0o0Ooo [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  iI1Ii11iII1 = url . split ( '.' ) [ - 1 ]
  try :
   iI1Ii11iII1 = iI1Ii11iII1 . split ( '?' ) [ 0 ]
  except : pass
  try :
   iI1Ii11iII1 = iI1Ii11iII1 . split ( '%' ) [ 0 ]
  except : pass
  iii11iII ( '[COLOR yellowgreen]' + iI1Ii11iII1 . upper ( ) + '[/COLOR] - ' + iII11i , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 51 - 51: Oo * I1Ii111 % o00O0oo * Oo % Oo0oO0ooo / i11IiIiiIIIII
def i1II1 ( url ) :
 if 49 - 49: o00O0oo
 if not 'http' in url :
  IIii1Ii1 = open ( url ) . read ( )
 else :
  try :
   IIii1Ii1 = I1II11IiII ( url )
  except :
   ooo0OO . ok ( Oo0Ooo , "There was an error connecting to the url. Please try another." )
   quit ( )
 IIii1Ii1 = IIii1Ii1 . replace ( '#AAASTREAM:' , '#A:' )
 IIii1Ii1 = IIii1Ii1 . replace ( '#EXTINF:' , '#A:' )
 OOO0OOo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IIii1Ii1 )
 I1I111 = [ ]
 for i11iiI111I , II11i1iIiII1 , url in OOO0OOo :
  iIi1iIiii111 = { "params" : i11iiI111I , "display_name" : II11i1iIiII1 , "url" : url }
  I1I111 . append ( iIi1iIiii111 )
 list = [ ]
 for O0o0Ooo in I1I111 :
  iIi1iIiii111 = { "display_name" : O0o0Ooo [ "display_name" ] , "url" : O0o0Ooo [ "url" ] }
  OOO0OOo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o0Ooo [ "params" ] )
  for iIIIi1 , iiII1i1 in OOO0OOo :
   iIi1iIiii111 [ iIIIi1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iiII1i1 . strip ( )
  list . append ( iIi1iIiii111 )
  if 66 - 66: O0OOo - O0Oooo00
 return list
 if 5 - 5: O0o + oo00 / IiII - IiIiI11iIi
def OO0O0OoOO0 ( name , url , iconimage ) :
 if 10 - 10: i1oOo0OoO % o0
 II1 . create ( Oo0Ooo , "Generating M3U Playlist." , "Please wait..." )
 II1 . update ( 0 )
 list = i1II1 ( url )
 if 54 - 54: O0o - Oo % ooOoO0o % O0Oooo00 % o0 + i11IiIiiIIIII
 I1111I1iII11 = xbmc . PlayList ( 1 )
 I1111I1iII11 . clear ( )
 if 59 - 59: o0 * i11iIiiIii / Oo0oO0ooo * iIIIiiIIiiiIi * i1
 for O0o0Ooo in list :
  name = O00 ( O0o0Ooo [ "display_name" ] )
  url = O00 ( O0o0Ooo [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if not 'f4m' in url :
   if '.m3u8' in url :
    url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
    OOo0o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
    OOo0o . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
    I1111I1iII11 . add ( url , OOo0o )
   elif '.ts' in url :
    url = url . replace ( '.ts' , '.m3u8' )
    url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
    OOo0o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
    OOo0o . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
    I1111I1iII11 . add ( url , OOo0o )
   elif '.mpegts' in url :
    url = url . replace ( '.mpegts' , '.m3u8' )
    url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
    OOo0o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
    OOo0o . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
    I1111I1iII11 . add ( url , OOo0o )
    if 50 - 50: iiiii11iII1
 II1 . close ( )
 xbmc . Player ( ) . play ( I1111I1iII11 , OOo0o , False )
 #quit()
 if 14 - 14: O0Oooo00 % I1Ii111 * O0Oooo00
def iII ( url ) :
 if 96 - 96: IiII
 if not 'http' in url :
  IIii1Ii1 = open ( url ) . read ( )
 else :
  IIii1Ii1 = I1II11IiII ( url )
 IIii1Ii1 = IIii1Ii1 . replace ( '#AAASTREAM:' , '#A:' )
 IIii1Ii1 = IIii1Ii1 . replace ( '#EXTINF:' , '#A:' )
 OOO0OOo = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( IIii1Ii1 )
 I1I111 = [ ]
 for i11iiI111I , II11i1iIiII1 , url in OOO0OOo :
  iIi1iIiii111 = { "params" : i11iiI111I , "display_name" : II11i1iIiII1 , "url" : url }
  I1I111 . append ( iIi1iIiii111 )
 list = [ ]
 for O0o0Ooo in I1I111 :
  iIi1iIiii111 = { "display_name" : O0o0Ooo [ "display_name" ] , "url" : O0o0Ooo [ "url" ] }
  OOO0OOo = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o0Ooo [ "params" ] )
  for iIIIi1 , iiII1i1 in OOO0OOo :
   iIi1iIiii111 [ iIIIi1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = iiII1i1 . strip ( )
  list . append ( iIi1iIiii111 )
  if 45 - 45: i1 * o00O0oo % IiII * i1oOo0OoO + I11 . ooOoO0o
 return list
 if 67 - 67: i11iIiiIii - iIIIiiIIiiiIi % Oo0oO0ooo . i1
def O00 ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 77 - 77: iiiii11iII1 / iII111i
def I1 ( ) :
 if 15 - 15: Oo
 Ii = "[COLOR orangered][B]List[/B][/COLOR]"
 ooo0O = ''
 oOoO0o00OO0 = ''
 i1I1ii = urlopen ( 'http://ip.42.pl/raw' ) . read ( )
 if 61 - 61: Oo
 try :
  O0OOO = xbmc . Keyboard ( ooo0O , 'Enter Your Link/List URL' )
  O0OOO . doModal ( )
  if 10 - 10: O0OOo * O0Oooo00 % ooOoO0o / iII111i / ooOoO0o
  if O0OOO . isConfirmed ( ) :
   ooo0O = O0OOO . getText ( )
   iIIi1i1 = xbmc . Keyboard ( oOoO0o00OO0 , 'Enter an identifier for the link' )
   iIIi1i1 . doModal ( )
   if 10 - 10: O0Oooo00
  if iIIi1i1 . isConfirmed ( ) :
   oOoO0o00OO0 = iIIi1i1 . getText ( )
   if 82 - 82: Oo0oO0ooo - o0 / O0OOo + oo00
  if ooo0O == "" :
   ooo0OO . ok ( Oo0Ooo , "[COLOR white]Sorry not a valid entry![/COLOR]" , "[COLOR white]Please try again.[/COLOR]" , '' )
   sys . exit ( 1 )
   if 87 - 87: IiIiI11iIi * Oo0oO0ooo + O0OOo / o0 / I11
  if oOoO0o00OO0 == "" :
   ooo0OO . ok ( Oo0Ooo , "[COLOR white]Sorry not a valid entry![/COLOR]" , "[COLOR white]Please try again.[/COLOR]" , '' )
   sys . exit ( 1 )
   if 37 - 37: I11 - i11IiIiiIIIII * IiIiI11iIi % i11iIiiIii - O0o
  if not 'http' in ooo0O :
   ooo0OO . ok ( Oo0Ooo , "[COLOR white]Sorry not a valid entry![/COLOR]" , "[COLOR white]Please include http:// or https:// at the start of the URL.[/COLOR]" , '' )
   sys . exit ( 1 )
   if 83 - 83: O0Oooo00 / iII111i
  IIi = I1IiiI + base64 . b64decode ( b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249YWRkJnRleHQ9' ) + base64 . b64encode ( ooo0O ) + base64 . b64decode ( b'Jm5hbWU9' ) + base64 . b64encode ( oOoO0o00OO0 ) + base64 . b64decode ( b'JmlwPQ==' ) + base64 . b64encode ( i1I1ii ) + base64 . b64decode ( b'JmJ1aWxkPQ==' ) + base64 . b64encode ( Ii )
  iIIiIi1iIII1 = urllib2 . urlopen ( IIi ) . read ( )
 except : sys . exit ( 1 )
 if 78 - 78: i1 . IiIiI11iIi . Oo % O0OOo
 ooo0OO . ok ( Oo0Ooo , "[COLOR white]Thank you for adding to the list. You have done your bit for the community![/COLOR]" )
 if 49 - 49: oo00 / I1Ii111 . Oo
 xbmc . executebuiltin ( "Container.Refresh" )
 if 68 - 68: i11iIiiIii % Oo0oO0ooo + i11iIiiIii
def iii ( text , pattern ) :
 if 1 - 1: IiII / o00O0oo % I11 * iiiii11iII1 . i11iIiiIii
 III1Iiii1I11 = ""
 try :
  IIII = re . findall ( pattern , text , flags = re . DOTALL )
  III1Iiii1I11 = IIII [ 0 ]
 except :
  III1Iiii1I11 = ""
  if 32 - 32: i1oOo0OoO / o0 - o00O0oo
 return III1Iiii1I11
 if 91 - 91: I11 % iIIIiiIIiiiIi % o0
def o0oO0o00oo ( data ) :
 if 20 - 20: O0OOo % oo00 / oo00 + oo00
 III1IiiI = "<item>(.*?)</item>"
 iI = re . findall ( III1IiiI , data , re . DOTALL )
 if 32 - 32: I11 . iiiii11iII1 . iiiii11iII1
 OO00O0O = [ ]
 for iiioOooOOOoOo in iI :
  II1i1Ii11Ii11 = { }
  II1i1Ii11Ii11 [ "name" ] = iii ( iiioOooOOOoOo , "<name>([^<]+)</name>" )
  II1i1Ii11Ii11 [ "date" ] = iii ( iiioOooOOOoOo , "<date>([^<]+)</date>" )
  II1i1Ii11Ii11 [ "review" ] = iii ( iiioOooOOOoOo , "<review>([^<]+)</review>" )
  if 41 - 41: oo00 - i1 - i1
  if II1i1Ii11Ii11 [ "name" ] != "" :
   OO00O0O . append ( II1i1Ii11Ii11 )
   if 68 - 68: O0OOo % O0o
 return OO00O0O
 if 88 - 88: o0 - i11IiIiiIIIII + O0OOo
def IiI111111IIII ( ) :
 if 37 - 37: O0o / ooOoO0o
 i1I1iI1iIi111i = 0
 if not os . path . exists ( IIi1IiiiI1Ii ) :
  i1I1iI1iIi111i = 1
  iii11iII ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
  iii11iII ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 12 , iiiii , O0O0OO0O0O0 , '' )
 else :
  oOO = open ( IIi1IiiiI1Ii , "r" )
  I1iiiiI1iII = re . compile ( r'<password>(.+?)</password>' )
  for IiIi11i in oOO :
   file = I1iiiiI1iII . findall ( IiIi11i )
   for iIii1I111I11I in file :
    OO00OooO0OO = base64 . b64decode ( iIii1I111I11I )
    i1I1iI1iIi111i = 1
    iii11iII ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
    iii11iII ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( OO00OooO0OO ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
    iii11iII ( "[COLOR lime]Change Password[/COLOR]" , "url" , 12 , iiiii , O0O0OO0O0O0 , '' )
    iii11iII ( "[COLOR red]Disable Password[/COLOR]" , "url" , 13 , iiiii , O0O0OO0O0O0 , '' )
    if 44 - 44: iIIIiiIIiiiIi % Oo + O0Oooo00
 if i1I1iI1iIi111i == 0 :
  iii11iII ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
  iii11iII ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 12 , iiiii , O0O0OO0O0O0 , '' )
  if 45 - 45: I11 / I11 + O0o + i11IiIiiIIIII
def Oo0o0000o0o0 ( ) :
 if 47 - 47: o00O0oo + i11IiIiiIIIII
 oO0 = IIIi1i1I ( heading = "Please Set Password" )
 if ( not oO0 ) :
  ooo0OO . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 OOoOoo00oo = oO0
 if 82 - 82: Oo . iiiii11iII1 - o0 - iiiii11iII1 * Oo
 oO0 = IIIi1i1I ( heading = "Please Confirm Your Password" )
 if ( not oO0 ) :
  ooo0OO . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 ooO0oOOooOo0 = oO0
 if 38 - 38: O0o
 if not os . path . exists ( IIi1IiiiI1Ii ) :
  if not os . path . exists ( OOOo0 ) :
   os . makedirs ( OOOo0 )
  open ( IIi1IiiiI1Ii , 'w' )
  if 84 - 84: o0 % I11 / o0 % O0Oooo00
  if OOoOoo00oo == ooO0oOOooOo0 :
   ii = base64 . b64encode ( OOoOoo00oo )
   O0oOO0o0 = open ( IIi1IiiiI1Ii , 'w' )
   O0oOO0o0 . write ( '<password>' + str ( ii ) + '</password>' )
   O0oOO0o0 . close ( )
   ooo0OO . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   ooo0OO . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( IIi1IiiiI1Ii )
  if 84 - 84: o00O0oo % Oo . i11iIiiIii / I1Ii111
  if OOoOoo00oo == ooO0oOOooOo0 :
   ii = base64 . b64encode ( OOoOoo00oo )
   O0oOO0o0 = open ( IIi1IiiiI1Ii , 'w' )
   O0oOO0o0 . write ( '<password>' + str ( ii ) + '</password>' )
   O0oOO0o0 . close ( )
   ooo0OO . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   ooo0OO . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 80 - 80: O0o . i11iIiiIii - o00O0oo
def iIiIIi1 ( ) :
 if 7 - 7: i11IiIiiIIIII - IiII - IiIiI11iIi + i11IiIiiIIIII
 try :
  os . remove ( IIi1IiiiI1Ii )
  ooo0OO . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  ooo0OO . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 26 - 26: oo00
def Oo0oO0oo0oO00 ( announce ) :
 class I11iiI1i1 ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( 'ECHO Community Player' )
   try : O0oOO0o0 = open ( announce ) ; I1i1Iiiii = O0oOO0o0 . read ( )
   except : I1i1Iiiii = announce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( I1i1Iiiii ) )
   return
 I11iiI1i1 ( )
 while xbmc . getCondVisibility ( 'Window.IsVisible(10147)' ) :
  time . sleep ( .5 )
  if 94 - 94: o00O0oo * oo00 / IiII / oo00
def IIIi1i1I ( default = "" , heading = "" , hidden = False ) :
 oO0O0OO0O = xbmc . Keyboard ( default , heading , hidden )
 if 81 - 81: IiIiI11iIi . o00O0oo % i1 / iII111i - IiIiI11iIi
 oO0O0OO0O . doModal ( )
 if ( oO0O0OO0O . isConfirmed ( ) ) :
  return unicode ( oO0O0OO0O . getText ( ) , "utf-8" )
 return default
 if 43 - 43: i11iIiiIii + IiII * Oo * O0o * i1
def O0oo0OO0oOOOo ( name , url , iconimage ) :
 if 64 - 64: O0OOo % o0 * IiIiI11iIi
 II1 . create ( Oo0Ooo , "Opening......." , "Please Wait..." )
 if 79 - 79: i1
 if not 'f4m' in url :
  if '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.mpegts' in url :
   url = url . replace ( '.mpegts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
   if 78 - 78: Oo0oO0ooo + O0OOo - O0o
 if "plugin://" in url :
  if not os . path . exists ( O00ooooo00 ) :
   ooo0OO . ok ( '[COLOR red]F4M TESTER NOT INSTALLED![/COLOR]' , "This link requires F4M Tester be installed. Please install F4M from the Shani Repo at http://fusion.tvaddons.ag" )
   quit ( )
   if 38 - 38: o00O0oo - IiIiI11iIi + o0 / ooOoO0o % IiII
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  oO0o0 = urlresolver . HostedMediaFile ( url ) . resolve ( )
  OOo0o = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  OOo0o . setPath ( oO0o0 )
  II1 . close ( )
  xbmc . Player ( ) . play ( oO0o0 , OOo0o , False )
 elif liveresolver . isValid ( url ) == True :
  oO0o0 = liveresolver . resolve ( url )
  OOo0o = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  OOo0o . setPath ( oO0o0 )
  II1 . close ( )
  xbmc . Player ( ) . play ( oO0o0 , OOo0o , False )
 else :
  if 'http' in url :
   url = url + '|User-Agent=Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30'
  OOo0o = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
  II1 . close ( )
  xbmc . Player ( ) . play ( url , OOo0o , False )
  if 50 - 50: iiiii11iII1
def I1II11IiII ( url ) :
 if 46 - 46: i1 + I11 % iII111i / o00O0oo . iiiii11iII1 * O0Oooo00
 OOooo0oOO0O = urllib2 . Request ( url )
 OOooo0oOO0O . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 IIii1Ii1 = urllib2 . urlopen ( OOooo0oOO0O )
 o00O0 = IIii1Ii1 . read ( )
 IIii1Ii1 . close ( )
 return o00O0
 if 83 - 83: i11IiIiiIIIII
def iii11iII ( name , url , mode , iconimage , fanart , description = '' ) :
 if 65 - 65: iII111i % oo00 * IiIiI11iIi
 OOo0o = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 OOo0o . setProperty ( 'fanart_image' , fanart )
 I1iiiii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart )
 o00oOOooOOo0o = True
 o00oOOooOOo0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1iiiii , listitem = OOo0o , isFolder = False )
 return o00oOOooOOo0o
 if 66 - 66: I11 - I11 - i11iIiiIii . Oo0oO0ooo - O0OOo
def i1I111I ( name , url , mode , iconimage , fanart , description = '' ) :
 I1iiiii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 o00oOOooOOo0o = True
 OOo0o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 OOo0o . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 OOo0o . setProperty ( 'fanart_image' , fanart )
 o00oOOooOOo0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1iiiii , listitem = OOo0o , isFolder = True )
 return o00oOOooOOo0o
 if 77 - 77: ooOoO0o - Oo - i11IiIiiIIIII
def IiiiIIiIi1 ( ) :
 OoOOoOooooOOo = [ ]
 oOo0O = sys . argv [ 2 ]
 if len ( oOo0O ) >= 2 :
  i11iiI111I = sys . argv [ 2 ]
  oo0O0 = i11iiI111I . replace ( '?' , '' )
  if ( i11iiI111I [ len ( i11iiI111I ) - 1 ] == '/' ) :
   i11iiI111I = i11iiI111I [ 0 : len ( i11iiI111I ) - 2 ]
  iIOO0O000 = oo0O0 . split ( '&' )
  OoOOoOooooOOo = { }
  for OO0O00 in range ( len ( iIOO0O000 ) ) :
   iiIiI1i1 = { }
   iiIiI1i1 = iIOO0O000 [ OO0O00 ] . split ( '=' )
   if ( len ( iiIiI1i1 ) ) == 2 :
    OoOOoOooooOOo [ iiIiI1i1 [ 0 ] ] = iiIiI1i1 [ 1 ]
    if 69 - 69: i11IiIiiIIIII
 return OoOOoOooooOOo
 if 40 - 40: O0o + i1oOo0OoO % o00O0oo - o0 . iII111i
i11iiI111I = IiiiIIiIi1 ( ) ; O0O00o0OOO0 = None ; iII11i = None ; iIiIi11iI = None ; Oo0O00O000 = None ; i11I1IiII1i1i = None
try : Oo0O00O000 = urllib . unquote_plus ( i11iiI111I [ "site" ] )
except : pass
try : O0O00o0OOO0 = urllib . unquote_plus ( i11iiI111I [ "url" ] )
except : pass
try : iII11i = urllib . unquote_plus ( i11iiI111I [ "name" ] )
except : pass
try : iIiIi11iI = int ( i11iiI111I [ "mode" ] )
except : pass
try : i11I1IiII1i1i = urllib . unquote_plus ( i11iiI111I [ "iconimage" ] )
except : pass
try : O0O0OO0O0O0 = urllib . unquote_plus ( i11iiI111I [ "fanart" ] )
except : pass
if 95 - 95: i11iIiiIii
if iIiIi11iI == None or O0O00o0OOO0 == None or len ( O0O00o0OOO0 ) < 1 : o0O ( )
elif iIiIi11iI == 1 : Iii111II ( iII11i , O0O00o0OOO0 , i11I1IiII1i1i )
elif iIiIi11iI == 2 : O0oo0OO0oOOOo ( iII11i , O0O00o0OOO0 , i11I1IiII1i1i )
elif iIiIi11iI == 3 : I1 ( )
elif iIiIi11iI == 4 : iiii ( iII11i , O0O00o0OOO0 , i11I1IiII1i1i )
elif iIiIi11iI == 11 : IiI111111IIII ( )
elif iIiIi11iI == 12 : Oo0o0000o0o0 ( )
elif iIiIi11iI == 13 : iIiIIi1 ( )
elif iIiIi11iI == 50 : OO0O0OoOO0 ( iII11i , O0O00o0OOO0 , i11I1IiII1i1i )
if 32 - 32: O0OOo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )