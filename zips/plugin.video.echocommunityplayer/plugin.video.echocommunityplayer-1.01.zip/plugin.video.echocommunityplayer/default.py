import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64 , time
from urllib2 import urlopen
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echocommunityplayer'
Oo0Ooo = '[COLOR yellowgreen]ECHO Community Player[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmcgui . Dialog ( )
II1 = xbmcgui . DialogProgress ( )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home/addons/plugin.video.f4mTester' ) )
I1IiiI = base64 . b64decode ( b'aHR0cDovL2VjaG9jb2Rlci5jb20v' )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'controls.txt' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'disclaimer.txt' ) )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'agreed.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o ) )
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
def o0O ( ) :
 if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
 if not os . path . exists ( oO00oOo ) :
  O0oOO0o0 = open ( I11i11Ii , mode = 'r' ) ; i1ii1iIII = O0oOO0o0 . read ( ) ; O0oOO0o0 . close ( )
  Oo0oO0oo0oO00 ( "%s" % i1ii1iIII )
  i111I = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , '[COLOR white]Do you agree to the terms and conditions of this addon?[/COLOR]' , '' , yeslabel = '[COLOR lime]YES[/COLOR]' , nolabel = '[COLOR red]NO[/COLOR]' )
  if i111I == 1 :
   if not os . path . exists ( OOOo0 ) :
    os . makedirs ( OOOo0 )
   open ( oO00oOo , 'w' )
  else :
   sys . exit ( 0 )
   if 16 - 16: Oo0oO0ooo % IiIiI11iIi - O0OOo . O0Oooo00 . oo00 * I11
 if not os . path . exists ( OOOo0 ) :
  i111I = xbmcgui . Dialog ( ) . yesno ( Oo0Ooo , "[COLOR white]We can see that this is your first time using the addon. Would you like to enable the parental controls now?[/COLOR]" , "" , yeslabel = '[COLOR red]NO[/COLOR]' , nolabel = '[COLOR lime]YES[/COLOR]' )
  if i111I == 0 :
   Oo0o0000o0o0 ( )
  else :
   os . makedirs ( OOOo0 )
   if 86 - 86: iiiii11iII1 % O0o
 elif os . path . exists ( IIi1IiiiI1Ii ) :
  oO0 = IIIi1i1I ( heading = "Please Enter Your Password" )
  if ( not oO0 ) :
   ooo0OO . ok ( Oo0Ooo , "Sorry, no password was entered." )
   sys . exit ( 0 )
  OOoOoo00oo = oO0
  if 41 - 41: i11IiIiiIIIII / ooOoO0o / O0o
  oOO = open ( IIi1IiiiI1Ii , "r" )
  I1iiiiI1iII = re . compile ( r'<password>(.+?)</password>' )
  for IiIi11i in oOO :
   file = I1iiiiI1iII . findall ( IiIi11i )
   for iIii1I111I11I in file :
    OO00OooO0OO = base64 . b64decode ( iIii1I111I11I )
    if not OO00OooO0OO == OOoOoo00oo :
     if not iIii1I111I11I == OOoOoo00oo :
      ooo0OO . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      sys . exit ( 0 )
      if 28 - 28: Oo
 iii11iII ( '[COLOR yellowgreen]SUBMIT A LINK/LIST [/COLOR][COLOR white](M3U, TS, M3U8, MP4, MKV, MP3 etc)[/COLOR]' , I1IiiI , 3 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( '#########################################################################' , I1IiiI , 999 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( "[COLOR yellowgreen]TWITTER SUPPORT: [/COLOR][COLOR white]@ECHOCODER[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
 if not os . path . exists ( IIi1IiiiI1Ii ) :
  i1I111I ( "[COLOR yellowgreen]PARENTAL CONTROLS - [COLOR red]OFF[/COLOR][/COLOR]" , "url" , 11 , iiiii , O0O0OO0O0O0 , '' )
 else :
  i1I111I ( "[COLOR yellowgreen]PARENTAL CONTROLS - [COLOR lime]ON[/COLOR][/COLOR]" , "url" , 11 , iiiii , O0O0OO0O0O0 , '' )
  if 1 - 1: iiiii11iII1 % I1Ii111 * O0Oooo00
 iii11iII ( '#########################################################################' , I1IiiI , 999 , iiiii , O0O0OO0O0O0 , '' )
 i1I111I ( '[COLOR yellowgreen]VIEW ALL: [/COLOR][COLOR white]M3U LISTS[/COLOR]' , 'm3u' , 4 , iiiii , O0O0OO0O0O0 , '' )
 i1I111I ( '[COLOR yellowgreen]VIEW ALL: [/COLOR][COLOR white]DIRECT LINKS[/COLOR]' , 'direct' , 4 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( '##################LATEST ADDED########################' , I1IiiI , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 55 - 55: iIIIiiIIiiiIi / i11iIiiIii + O0OOo + I1Ii111
 if 17 - 17: IiIiI11iIi . IiII . Oo0oO0ooo
 IIi = I1IiiI + base64 . b64decode ( b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249cmVhZCZidWlsZD0=' ) + base64 . b64encode ( '[COLOR orangered][B]List[/B][/COLOR]' )
 O0oOO0o0 = urllib2 . urlopen ( IIi )
 i1I11 = O0oOO0o0 . read ( )
 O0oOO0o0 . close ( )
 if 26 - 26: i11iIiiIii
 OO0O00 = 0
 ii1 = o0oO0o00oo ( i1I11 )
 for II1i1Ii11Ii11 in ii1 :
  if OO0O00 < 10 :
   iII11i = II1i1Ii11Ii11 [ 'name' ]
   O0O00o0OOO0 = II1i1Ii11Ii11 [ 'review' ]
   Ii1iIIIi1ii = II1i1Ii11Ii11 [ 'date' ]
   if 80 - 80: O0Oooo00 * i11iIiiIii / O0o
   I11II1i = '[COLOR dodgerblue]' + iII11i + '[/COLOR] - [COLOR white]' + O0O00o0OOO0 + '[/COLOR] | [COLOR dodgerblue]' + Ii1iIIIi1ii + '[/COLOR]'
   if 23 - 23: Oo0oO0ooo / o00O0oo + O0Oooo00 + O0Oooo00 / Oo
   i1I111I ( I11II1i , O0O00o0OOO0 , 1 , iiiii , O0O0OO0O0O0 , '' )
   OO0O00 = OO0O00 + 1
   if 26 - 26: i1oOo0OoO
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 12 - 12: i1oOo0OoO % ooOoO0o / i11IiIiiIIIII % o00O0oo
def iiii ( name , url , iconimage ) :
 if 54 - 54: Oo0oO0ooo * O0OOo
 I1IIIii = url
 if 95 - 95: I1Ii111 % IiIiI11iIi . i1
 if url == "m3u" :
  i1I111I ( '[COLOR yellowgreen]VIEWING ALL M3U LISTS[/COLOR]' , I1IiiI , 4 , iiiii , O0O0OO0O0O0 , '' )
 else :
  i1I111I ( '[COLOR yellowgreen]VIEWING ALL DIRECT LINKS[/COLOR]' , I1IiiI , 4 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( '#########################################################################' , I1IiiI , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 15 - 15: i11IiIiiIIIII / oo00 . oo00 - iIIIiiIIiiiIi
 IIi = I1IiiI + base64 . b64decode ( b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249cmVhZCZidWlsZD0=' ) + base64 . b64encode ( '[COLOR orangered][B]List[/B][/COLOR]' )
 O0oOO0o0 = urllib2 . urlopen ( IIi )
 i1I11 = O0oOO0o0 . read ( )
 O0oOO0o0 . close ( )
 if 53 - 53: iiiii11iII1 + iII111i * IiIiI11iIi
 ii1 = o0oO0o00oo ( i1I11 )
 for II1i1Ii11Ii11 in ii1 :
  name = II1i1Ii11Ii11 [ 'name' ]
  url = II1i1Ii11Ii11 [ 'review' ]
  Ii1iIIIi1ii = II1i1Ii11Ii11 [ 'date' ]
  if 61 - 61: iIIIiiIIiiiIi * O0OOo / i1oOo0OoO . i11iIiiIii . ooOoO0o
  I11II1i = '[COLOR dodgerblue]' + name + '[/COLOR] - [COLOR white]' + url + '[/COLOR] | [COLOR dodgerblue]' + Ii1iIIIi1ii + '[/COLOR]'
  if 60 - 60: O0Oooo00 / O0Oooo00
  if I1IIIii == "m3u" :
   if "m3u" in url :
    if not "m3u8" in url :
     i1I111I ( I11II1i , url , 1 , iiiii , O0O0OO0O0O0 , '' )
  else :
   if "m3u8" in url :
    iii11iII ( I11II1i , url , 1 , iiiii , O0O0OO0O0O0 , '' )
   elif not "m3u" in url :
    iii11iII ( I11II1i , url , 1 , iiiii , O0O0OO0O0O0 , '' )
    if 46 - 46: oo00 * O0OOo - I1Ii111 * IiIiI11iIi - O0o
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 83 - 83: i1oOo0OoO
def Iii111II ( name , url , iconimage ) :
 if 9 - 9: I1Ii111
 name = name . split ( '-' ) [ 0 ]
 if 'm3u' in url :
  if not 'm3u8' in url :
   i11 ( url )
  else :
   O0oo0OO0oOOOo ( name , url , iconimage )
 else :
  O0oo0OO0oOOOo ( name , url , iconimage )
  if 35 - 35: iiiii11iII1 % iII111i
def i11 ( url ) :
 if 70 - 70: I11 * Oo0oO0ooo
 list = i1II1 ( url )
 if 66 - 66: i1oOo0OoO + oo00 + oo00 - iIIIiiIIiiiIi
 iii11iII ( "[COLOR yellowgreen]Play The List[/COLOR]" , url , 2 , iiiii , O0O0OO0O0O0 , '' )
 iii11iII ( "###########################################" , url , 999 , iiiii , O0O0OO0O0O0 , '' )
 if 55 - 55: O0OOo + i11IiIiiIIIII . iIIIiiIIiiiIi - Oo0oO0ooo . i1 - i11IiIiiIIIII
 for o0OO00oO in list :
  iII11i = I11i1I1I ( o0OO00oO [ "display_name" ] )
  url = I11i1I1I ( o0OO00oO [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  oO0Oo = url . split ( '.' ) [ - 1 ]
  try :
   oO0Oo = oO0Oo . split ( '?' ) [ 0 ]
  except : pass
  try :
   oO0Oo = oO0Oo . split ( '%' ) [ 0 ]
  except : pass
  iii11iII ( '[COLOR yellowgreen]' + oO0Oo . upper ( ) + '[/COLOR] - ' + iII11i , url , 2 , iiiii , O0O0OO0O0O0 , '' )
  if 54 - 54: o00O0oo - iII111i + i1oOo0OoO
def i1II1 ( url ) :
 if 70 - 70: oo00 / O0Oooo00 . I11 % IiII
 if not 'http' in url :
  OOoOO00OOO0OO = open ( url ) . read ( )
 else :
  OOoOO00OOO0OO = iI1I111Ii111i ( url )
 OOoOO00OOO0OO = OOoOO00OOO0OO . replace ( '#AAASTREAM:' , '#A:' )
 OOoOO00OOO0OO = OOoOO00OOO0OO . replace ( '#EXTINF:' , '#A:' )
 I11IiI1I11i1i = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( OOoOO00OOO0OO )
 iI1ii1Ii = [ ]
 for oooo000 , iIIIi1 , url in I11IiI1I11i1i :
  iiII1i1 = { "params" : oooo000 , "display_name" : iIIIi1 , "url" : url }
  iI1ii1Ii . append ( iiII1i1 )
 list = [ ]
 for o0OO00oO in iI1ii1Ii :
  iiII1i1 = { "display_name" : o0OO00oO [ "display_name" ] , "url" : o0OO00oO [ "url" ] }
  I11IiI1I11i1i = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( o0OO00oO [ "params" ] )
  for o00oOO0o , OOO00O in I11IiI1I11i1i :
   iiII1i1 [ o00oOO0o . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = OOO00O . strip ( )
  list . append ( iiII1i1 )
  if 84 - 84: IiIiI11iIi * I1Ii111 / O0Oooo00 - i1
 return list
 if 30 - 30: o0 / i11IiIiiIIIII - O0o - Oo % I11
def I11i1I1I ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 49 - 49: iII111i % i11IiIiiIIIII . i11IiIiiIIIII . O0Oooo00 * i11IiIiiIIIII
def O0oOO0 ( ) :
 if 68 - 68: O0o % iIIIiiIIiiiIi . iiiii11iII1 . Oo0oO0ooo
 o0oo0oOo = "[COLOR orangered][B]List[/B][/COLOR]"
 o000O0o = ''
 iI1iII1 = ''
 oO0OOoo0OO = urlopen ( 'http://ip.42.pl/raw' ) . read ( )
 if 65 - 65: oo00 . o0 / i1 - oo00
 try :
  iii1i1iiiiIi = xbmc . Keyboard ( o000O0o , 'Enter Your Link/List URL' )
  iii1i1iiiiIi . doModal ( )
  if 2 - 2: iII111i / i1 / o00O0oo % ooOoO0o % oo00
  if iii1i1iiiiIi . isConfirmed ( ) :
   o000O0o = iii1i1iiiiIi . getText ( )
   o0o00OO0 = xbmc . Keyboard ( iI1iII1 , 'Enter an identifier for the link' )
   o0o00OO0 . doModal ( )
   if 7 - 7: O0OOo + O0o + i1
  if o0o00OO0 . isConfirmed ( ) :
   iI1iII1 = o0o00OO0 . getText ( )
   if 9 - 9: Oo . o00O0oo - i11IiIiiIIIII / o00O0oo
  if o000O0o == "" :
   ooo0OO . ok ( Oo0Ooo , "[COLOR white]Sorry not a valid entry![/COLOR]" , "[COLOR white]Please try again.[/COLOR]" , '' )
   sys . exit ( 1 )
   if 46 - 46: O0Oooo00 . O0OOo * O0Oooo00 % iIIIiiIIiiiIi
  if iI1iII1 == "" :
   ooo0OO . ok ( Oo0Ooo , "[COLOR white]Sorry not a valid entry![/COLOR]" , "[COLOR white]Please try again.[/COLOR]" , '' )
   sys . exit ( 1 )
   if 46 - 46: ooOoO0o + I1Ii111
  if not 'http' in o000O0o :
   ooo0OO . ok ( Oo0Ooo , "[COLOR white]Sorry not a valid entry![/COLOR]" , "[COLOR white]Please include http:// or https:// at the start of the URL.[/COLOR]" , '' )
   sys . exit ( 1 )
   if 10 - 10: IiII - O0o . i1
  IIi = I1IiiI + base64 . b64decode ( b'YXBpL2FwaV9jb21tdW5pdHlfcGxheWVyLnBocD9hY3Rpb249YWRkJnRleHQ9' ) + base64 . b64encode ( o000O0o ) + base64 . b64decode ( b'Jm5hbWU9' ) + base64 . b64encode ( iI1iII1 ) + base64 . b64decode ( b'JmlwPQ==' ) + base64 . b64encode ( oO0OOoo0OO ) + base64 . b64decode ( b'JmJ1aWxkPQ==' ) + base64 . b64encode ( o0oo0oOo )
  o00 = urllib2 . urlopen ( IIi ) . read ( )
 except : sys . exit ( 1 )
 if 56 - 56: iII111i - IiII . oo00 - iiiii11iII1
 ooo0OO . ok ( Oo0Ooo , "[COLOR white]Thank you for adding to the list. You have done your bit for the community![/COLOR]" )
 if 73 - 73: IiII - iIIIiiIIiiiIi - iIIIiiIIiiiIi - I11 . oo00 + Oo0oO0ooo
 xbmc . executebuiltin ( "Container.Refresh" )
 if 81 - 81: I11 * IiIiI11iIi - O0o . Oo % O0Oooo00 / iII111i
def iIIiIi1iIII1 ( text , pattern ) :
 if 78 - 78: i1 . IiIiI11iIi . Oo % O0OOo
 i1iIi = ""
 try :
  ooOOoooooo = re . findall ( pattern , text , flags = re . DOTALL )
  i1iIi = ooOOoooooo [ 0 ]
 except :
  i1iIi = ""
  if 1 - 1: IiII / o00O0oo % I11 * iiiii11iII1 . i11iIiiIii
 return i1iIi
 if 2 - 2: Oo0oO0ooo * O0Oooo00 - o0 + iII111i . IiIiI11iIi % I11
def o0oO0o00oo ( data ) :
 if 92 - 92: I11
 IIiIiiIi = "<item>(.*?)</item>"
 O000oo = re . findall ( IIiIiiIi , data , re . DOTALL )
 if 20 - 20: O0OOo % oo00 / oo00 + oo00
 III1IiiI = [ ]
 for iI in O000oo :
  II1i1Ii11Ii11 = { }
  II1i1Ii11Ii11 [ "name" ] = iIIiIi1iIII1 ( iI , "<name>([^<]+)</name>" )
  II1i1Ii11Ii11 [ "date" ] = iIIiIi1iIII1 ( iI , "<date>([^<]+)</date>" )
  II1i1Ii11Ii11 [ "review" ] = iIIiIi1iIII1 ( iI , "<review>([^<]+)</review>" )
  if 32 - 32: I11 . iiiii11iII1 . iiiii11iII1
  if II1i1Ii11Ii11 [ "name" ] != "" :
   III1IiiI . append ( II1i1Ii11Ii11 )
   if 62 - 62: Oo0oO0ooo + iiiii11iII1 % I11 + O0OOo
 return III1IiiI
 if 33 - 33: i1 . iiiii11iII1 . iII111i
def OoOO ( ) :
 if 53 - 53: IiII
 iI1Iii = 0
 if not os . path . exists ( IIi1IiiiI1Ii ) :
  iI1Iii = 1
  iii11iII ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
  iii11iII ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 12 , iiiii , O0O0OO0O0O0 , '' )
 else :
  oOO = open ( IIi1IiiiI1Ii , "r" )
  I1iiiiI1iII = re . compile ( r'<password>(.+?)</password>' )
  for IiIi11i in oOO :
   file = I1iiiiI1iII . findall ( IiIi11i )
   for iIii1I111I11I in file :
    OO00OooO0OO = base64 . b64decode ( iIii1I111I11I )
    iI1Iii = 1
    iii11iII ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
    iii11iII ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( OO00OooO0OO ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
    iii11iII ( "[COLOR lime]Change Password[/COLOR]" , "url" , 12 , iiiii , O0O0OO0O0O0 , '' )
    iii11iII ( "[COLOR red]Disable Password[/COLOR]" , "url" , 13 , iiiii , O0O0OO0O0O0 , '' )
    if 68 - 68: O0OOo % O0o
 if iI1Iii == 0 :
  iii11iII ( "[COLOR rose]PARENTAL CONTROLS - [/COLOR][COLOR red]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 , '' )
  iii11iII ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 12 , iiiii , O0O0OO0O0O0 , '' )
  if 88 - 88: o0 - i11IiIiiIIIII + O0OOo
def Oo0o0000o0o0 ( ) :
 if 40 - 40: iII111i * oo00 + O0OOo % I11
 oO0 = IIIi1i1I ( heading = "Please Set Password" )
 if ( not oO0 ) :
  ooo0OO . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 OOoOoo00oo = oO0
 if 74 - 74: IiIiI11iIi - IiII + i1oOo0OoO + O0o / ooOoO0o
 oO0 = IIIi1i1I ( heading = "Please Confirm Your Password" )
 if ( not oO0 ) :
  ooo0OO . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 i1I1iI1iIi111i = oO0
 if 44 - 44: iIIIiiIIiiiIi % Oo + O0Oooo00
 if not os . path . exists ( IIi1IiiiI1Ii ) :
  if not os . path . exists ( OOOo0 ) :
   os . makedirs ( OOOo0 )
  open ( IIi1IiiiI1Ii , 'w' )
  if 45 - 45: I11 / I11 + O0o + i11IiIiiIIIII
  if OOoOoo00oo == i1I1iI1iIi111i :
   iI111i = base64 . b64encode ( OOoOoo00oo )
   O0oOO0o0 = open ( IIi1IiiiI1Ii , 'w' )
   O0oOO0o0 . write ( '<password>' + str ( iI111i ) + '</password>' )
   O0oOO0o0 . close ( )
   ooo0OO . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   ooo0OO . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( IIi1IiiiI1Ii )
  if 26 - 26: Oo0oO0ooo * I11 . Oo * oo00
  if OOoOoo00oo == i1I1iI1iIi111i :
   iI111i = base64 . b64encode ( OOoOoo00oo )
   O0oOO0o0 = open ( IIi1IiiiI1Ii , 'w' )
   O0oOO0o0 . write ( '<password>' + str ( iI111i ) + '</password>' )
   O0oOO0o0 . close ( )
   ooo0OO . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   ooo0OO . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 28 - 28: I1Ii111 . iIIIiiIIiiiIi * iII111i + i1 . iIIIiiIIiiiIi - i11IiIiiIIIII
def i1I1ii11i1Iii ( ) :
 if 26 - 26: O0Oooo00 - o0 - iII111i / I1Ii111 . ooOoO0o % o0
 try :
  os . remove ( IIi1IiiiI1Ii )
  ooo0OO . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  ooo0OO . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 91 - 91: o00O0oo . o0 / IiIiI11iIi + iIIIiiIIiiiIi
def Oo0oO0oo0oO00 ( announce ) :
 class I1i ( ) :
  WINDOW = 10147
  CONTROL_LABEL = 1
  CONTROL_TEXTBOX = 5
  def __init__ ( self , * args , ** kwargs ) :
   xbmc . executebuiltin ( "ActivateWindow(%d)" % ( self . WINDOW , ) )
   self . win = xbmcgui . Window ( self . WINDOW )
   xbmc . sleep ( 500 )
   self . setControls ( )
  def setControls ( self ) :
   self . win . getControl ( self . CONTROL_LABEL ) . setLabel ( 'ECHO Community Player' )
   try : O0oOO0o0 = open ( announce ) ; OOOOO0oo0O0O0 = O0oOO0o0 . read ( )
   except : OOOOO0oo0O0O0 = announce
   self . win . getControl ( self . CONTROL_TEXTBOX ) . setText ( str ( OOOOO0oo0O0O0 ) )
   return
 I1i ( )
 while xbmc . getCondVisibility ( 'Window.IsVisible(10147)' ) :
  time . sleep ( .5 )
  if 74 - 74: o00O0oo . I11
def IIIi1i1I ( default = "" , heading = "" , hidden = False ) :
 I1I1i1I = xbmc . Keyboard ( default , heading , hidden )
 if 30 - 30: i1oOo0OoO
 I1I1i1I . doModal ( )
 if ( I1I1i1I . isConfirmed ( ) ) :
  return unicode ( I1I1i1I . getText ( ) , "utf-8" )
 return default
 if 5 - 5: i11IiIiiIIIII - Oo - i1oOo0OoO % oo00 + iII111i * o0
def O0oo0OO0oOOOo ( name , url , iconimage ) :
 if 37 - 37: iiiii11iII1 % i11IiIiiIIIII + ooOoO0o + o00O0oo * O0Oooo00 % i1
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
  elif '.mpegts' in url :
   url = url . replace ( '.mpegts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iiiii
   if 61 - 61: iII111i - O0OOo . IiIiI11iIi / O0OOo + IiII
 if "plugin://" in url :
  if not os . path . exists ( O00ooooo00 ) :
   ooo0OO . ok ( '[COLOR red]F4M TESTER NOT INSTALLED![/COLOR]' , "This link requires F4M Tester be installed. Please install F4M from the Shani Repo at http://fusion.tvaddons.ag" )
   quit ( )
   if 5 - 5: i11IiIiiIIIII + i11IiIiiIIIII / i1 * IiII - O0OOo % i11IiIiiIIIII
 if 'http' in url :
  url = url + '|User-Agent=Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30'
 Iii1IIII11I = xbmcgui . ListItem ( url , iconImage = iiiii , thumbnailImage = iiiii )
 xbmc . Player ( ) . play ( url , Iii1IIII11I , False )
 quit ( )
 if 77 - 77: IiII - iIIIiiIIiiiIi - O0Oooo00 . ooOoO0o
def iI1I111Ii111i ( url ) :
 if 39 - 39: Oo / i11IiIiiIIIII + O0o / ooOoO0o
 I1Ii11i = urllib2 . Request ( url )
 I1Ii11i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 OOoOO00OOO0OO = urllib2 . urlopen ( I1Ii11i )
 i1111I1I = OOoOO00OOO0OO . read ( )
 OOoOO00OOO0OO . close ( )
 return i1111I1I
 if 13 - 13: oo00 . i11iIiiIii
def iii11iII ( name , url , mode , iconimage , fanart , description = '' ) :
 if 56 - 56: Oo0oO0ooo % i1 - iII111i
 Iii1IIII11I = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 Iii1IIII11I . setProperty ( 'fanart_image' , fanart )
 O00o0OO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart )
 IIi1I1iiiii = True
 IIi1I1iiiii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O00o0OO0 , listitem = Iii1IIII11I , isFolder = False )
 return IIi1I1iiiii
 if 71 - 71: iiiii11iII1 * Oo * IiIiI11iIi
def i1I111I ( name , url , mode , iconimage , fanart , description = '' ) :
 O00o0OO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 IIi1I1iiiii = True
 Iii1IIII11I = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 Iii1IIII11I . setInfo ( type = "Video" , infoLabels = { "Title" : name , 'plot' : description } )
 Iii1IIII11I . setProperty ( 'fanart_image' , fanart )
 IIi1I1iiiii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O00o0OO0 , listitem = Iii1IIII11I , isFolder = True )
 return IIi1I1iiiii
 if 56 - 56: iII111i
def O0oO ( ) :
 OO0ooOOO0OOO = [ ]
 oO00oooOOoOo0 = sys . argv [ 2 ]
 if len ( oO00oooOOoOo0 ) >= 2 :
  oooo000 = sys . argv [ 2 ]
  OoOOoOooooOOo = oooo000 . replace ( '?' , '' )
  if ( oooo000 [ len ( oooo000 ) - 1 ] == '/' ) :
   oooo000 = oooo000 [ 0 : len ( oooo000 ) - 2 ]
  oOo0O = OoOOoOooooOOo . split ( '&' )
  OO0ooOOO0OOO = { }
  for OO0O00 in range ( len ( oOo0O ) ) :
   oo0O0 = { }
   oo0O0 = oOo0O [ OO0O00 ] . split ( '=' )
   if ( len ( oo0O0 ) ) == 2 :
    OO0ooOOO0OOO [ oo0O0 [ 0 ] ] = oo0O0 [ 1 ]
    if 22 - 22: ooOoO0o . O0OOo * ooOoO0o
 return OO0ooOOO0OOO
 if 54 - 54: iiiii11iII1 + oo00 % I1Ii111 + i1oOo0OoO - i1 - o00O0oo
oooo000 = O0oO ( ) ; O0O00o0OOO0 = None ; iII11i = None ; o0o0O0O00oOOo = None ; iIIIiIi = None ; OO0O0 = None
try : iIIIiIi = urllib . unquote_plus ( oooo000 [ "site" ] )
except : pass
try : O0O00o0OOO0 = urllib . unquote_plus ( oooo000 [ "url" ] )
except : pass
try : iII11i = urllib . unquote_plus ( oooo000 [ "name" ] )
except : pass
try : o0o0O0O00oOOo = int ( oooo000 [ "mode" ] )
except : pass
try : OO0O0 = urllib . unquote_plus ( oooo000 [ "iconimage" ] )
except : pass
try : O0O0OO0O0O0 = urllib . unquote_plus ( oooo000 [ "fanart" ] )
except : pass
if 30 - 30: O0OOo + Oo0oO0ooo * O0Oooo00 % i11iIiiIii % ooOoO0o
if o0o0O0O00oOOo == None or O0O00o0OOO0 == None or len ( O0O00o0OOO0 ) < 1 : o0O ( )
elif o0o0O0O00oOOo == 1 : Iii111II ( iII11i , O0O00o0OOO0 , OO0O0 )
elif o0o0O0O00oOOo == 2 : O0oo0OO0oOOOo ( iII11i , O0O00o0OOO0 , OO0O0 )
elif o0o0O0O00oOOo == 3 : O0oOO0 ( )
elif o0o0O0O00oOOo == 4 : iiii ( iII11i , O0O00o0OOO0 , OO0O0 )
elif o0o0O0O00oOOo == 11 : OoOO ( )
elif o0o0O0O00oOOo == 12 : Oo0o0000o0o0 ( )
elif o0o0O0O00oOOo == 13 : i1I1ii11i1Iii ( )
if 97 - 97: Oo0oO0ooo % Oo0oO0ooo % IiIiI11iIi / I11 - o0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )