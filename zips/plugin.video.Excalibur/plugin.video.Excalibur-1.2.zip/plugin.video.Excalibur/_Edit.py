import xbmcaddon

MainBase = 'http://bluebuilds.esy.es/EX/home.txt'
addon = xbmcaddon.Addon('plugin.video.Excalibur')