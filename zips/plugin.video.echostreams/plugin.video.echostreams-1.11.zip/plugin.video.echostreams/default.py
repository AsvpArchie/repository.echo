import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64 , shutil , time
from resources . lib . modules import checker
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' , OO0o ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( II1 , 'controls.txt' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'hd.txt' ) )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/m3u.xml' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/cleaner.xml' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/replacer.xml' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/blacklist.xml' ) )
if 91 - 91: Ii1I . OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
O0oO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
o0oO0 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
oo00 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
o00 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
Oo0oO0ooo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI=' )
if 56 - 56: ooO00oOoo - O0OOo
def II1Iiii1111i ( ) :
 if 25 - 25: OOo000
 O0 = OOOo0 + '|SPLIT|' + oO00oOo
 checker . check ( O0 )
 if 34 - 34: O0o00 % o0ooo / OOO0O / I1ii * oOOOo0o0O + OOoOoo00oo
 iiI11 ( "true" )
 if 91 - 91: oOOOO / i1iiIII111ii + iiIIi1IiIi11 . i1Ii
 I111I11 ( "[COLOR white]Welcome to ECHO Streams[/COLOR]" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 O0O00Ooo ( "################################################################" , O0oO , 6 , iiiii , O0O0OO0O0O0 )
 I111I11 ( "[COLOR white]Meet the team:[/COLOR]" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 I111I11 ( "[COLOR white]ECHO Coder: @EchoCoder(Twitter)[/COLOR]" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 I111I11 ( "[COLOR white]ECHO Blue: @Blue_Builds(Twitter)[/COLOR]" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 I111I11 ( "################################################################" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 O0O00Ooo ( "[COLOR dodgerblue][B]ENTER ADDON[/B][/COLOR]" , O0oO , 1 , iiiii , O0O0OO0O0O0 )
 I111I11 ( "################################################################" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 if not os . path . exists ( O00ooooo00 ) :
  O0O00Ooo ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  O0O00Ooo ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
  if 64 - 64: OOO0O - Ii1I / i1I1ii1II1iII / O0o00 / OoOO
 IiIIIiI1I1 = OoO000 ( )
 if 42 - 42: OOO0O - o0000oOoOoO0o / i11iIiiIii + I1ii + O0OOo
 if IiIIIiI1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IiIIIiI1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 17 - 17: OOO0O . ooO00oOoo . o0ooo
def IIi ( ) :
 if 38 - 38: OOoOoo00oo / ooO00oOoo
 iiI11 ( "name" , "true" )
 if 76 - 76: Ii1I / O0o00 . oooO0oo0oOOOO * OOoOoo00oo - I1ii
 O0O00Ooo ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 76 - 76: i11iIiiIii / OoOO . o0ooo % I1ii / OoOO0ooOOoo0O % OOO0O
 if os . path . exists ( I1IiiI ) :
  I111I11 ( '[COLOR white]Only Display HD Links - [COLOR lime][B]ON[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 else : I111I11 ( '[COLOR white]Only Display HD Links - [COLOR red][B]OFF[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 I111I11 ( '[COLOR white]Force Data Refresh[/COLOR]' , "false" , 8 , iiiii , O0O0OO0O0O0 )
 I111I11 ( '[COLOR darkgray]############################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 o0ooo00O0o0 = o0Oo00OOOOO ( O0oO )
 o0ooo00O0o0 = o0ooo00O0o0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 O0O = re . compile ( '<item>(.+?)</item>' ) . findall ( o0ooo00O0o0 )
 for O00o0OO in O0O :
  I11i1 = re . compile ( '<title>(.+?)</title>' ) . findall ( O00o0OO ) [ 0 ]
  iIi1ii1I1 = re . compile ( '<folder>(.+?)</folder>' ) . findall ( O00o0OO ) [ 0 ]
  o0 = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( O00o0OO ) [ 0 ]
  I11II1i = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( O00o0OO ) [ 0 ]
  if 23 - 23: o0ooo / O0o00 + oOOOo0o0O + oOOOo0o0O / i1I1ii1II1iII
  O0O00Ooo ( '[COLOR white]' + I11i1 + '[/COLOR]' , I11i1 , 2 , o0 , I11II1i )
  if 26 - 26: OoOO0ooOOoo0O
 IiIIIiI1I1 = OoO000 ( )
 if 12 - 12: OoOO0ooOOoo0O % OOo000 / i1Ii % O0o00
 if IiIIIiI1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IiIIIiI1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 29 - 29: OoOO0ooOOoo0O
def iI ( name , url , iconimage ) :
 if 28 - 28: I1ii - i1iiIII111ii . i1iiIII111ii + OOo000 - OoOO0ooOOoo0O + Ii1I
 I11i11Ii . create ( Oo0Ooo , "[COLOR dodgerblue]Getting the list of AWESOME streams![/COLOR]" , "[COLOR lime]We wont be long, we promise.[/COLOR]" )
 oOoOooOo0o0 = name
 if 61 - 61: O0o00 / O0OOo + i1Ii * OOO0O / OOO0O
 if "adult" in name . lower ( ) :
  OoOo ( )
 iIo00O = [ ]
 if 69 - 69: OOO0O % iiIIi1IiIi11 - O0o00 + iiIIi1IiIi11 - Ii1I % OoOO0ooOOoo0O
 if not "search" in name . lower ( ) :
  Iii111II = xbmc . translatePath ( os . path . join ( Oooo000o , url + ".xml" ) )
  iiii11I = open ( Iii111II )
  Ooo0OO0oOO = iiii11I . read ( )
  ii11i1 = re . compile ( '<term>(.+?)</term>' , re . DOTALL ) . findall ( Ooo0OO0oOO )
  for IIIii1II1II in ii11i1 :
   IIIii1II1II = IIIii1II1II . replace ( ' ' , '' )
   IIIii1II1II = IIIii1II1II . lower ( )
   iIo00O . append ( IIIii1II1II )
 else :
  IIIii1II1II = url
  IIIii1II1II = IIIii1II1II . replace ( ' ' , '' )
  IIIii1II1II = IIIii1II1II . lower ( )
  iIo00O . append ( url . lower ( ) )
  if 42 - 42: OOoOoo00oo + OOO0O
 o0O0o0Oo = [ ]
 Ii11Ii1I = [ ]
 O00oO = [ ]
 I11i1I1I = [ ]
 if 83 - 83: o0ooo / i1Ii
 iiii11I = open ( Oo0O )
 iIIIIii1 = iiii11I . read ( )
 oo000OO00Oo = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( iIIIIii1 )
 if 51 - 51: i1iiIII111ii * O0o00 + oOOOo0o0O + O0OOo
 iiii11I = open ( IiI )
 o0O0O00 = iiii11I . read ( )
 O0O = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( o0O0O00 )
 if 86 - 86: oOOOo0o0O / i1iiIII111ii % i11iIiiIii
 iiii11I = open ( ooOo )
 I11IiI1I11i1i = iiii11I . read ( )
 iI1ii1Ii = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( I11IiI1I11i1i )
 if 92 - 92: OOo000
 i1 = 0
 for IIIii1II1II in iI1ii1Ii :
  OOO = re . compile ( '<cat>(.+?)</cat>' ) . findall ( IIIii1II1II ) [ 0 ]
  if OOO . lower ( ) in oOoOooOo0o0 . lower ( ) :
   Oo0oOOo = OOO
   i1 = 1
 if i1 == 0 : Oo0oOOo = "null"
 if 58 - 58: i1I1ii1II1iII * I1ii * o0ooo / I1ii
 iiii11I = open ( IiIi11iIIi1Ii )
 O00o0OO = iiii11I . read ( )
 if 75 - 75: OOO0O
 I1III = O00o0OO
 I1III = I1III . replace ( '#AAASTREAM:' , '#A:' )
 I1III = I1III . replace ( '#EXTINF:' , '#A:' )
 OO0O0OoOO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( I1III )
 iiiI1I11i1 = [ ]
 for IIi1i11111 , ooOO00O00oo , url in OO0O0OoOO0 :
  I1ii11iI = { "params" : IIi1i11111 , "display_name" : ooOO00O00oo , "url" : url }
  iiiI1I11i1 . append ( I1ii11iI )
 IIi1i = [ ]
 for I1I1iIiII1 in iiiI1I11i1 :
  I1ii11iI = { "display_name" : I1I1iIiII1 [ "display_name" ] , "url" : I1I1iIiII1 [ "url" ] }
  OO0O0OoOO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1I1iIiII1 [ "params" ] )
  for i11i1I1 , ii1I in OO0O0OoOO0 :
   I1ii11iI [ i11i1I1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
  IIi1i . append ( I1ii11iI )
  if 67 - 67: i11iIiiIii - o0000oOoOoO0o % o0ooo . Ii1I
 for I1I1iIiII1 in IIi1i :
  name = o0oo ( I1I1iIiII1 [ "display_name" ] )
  url = o0oo ( I1I1iIiII1 [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if 91 - 91: i1iiIII111ii
  o0O0o0Oo . append ( name )
  Ii11Ii1I . append ( url )
  I11i1I1I = list ( zip ( o0O0o0Oo , Ii11Ii1I ) )
  if 15 - 15: i1I1ii1II1iII
 Ii = sorted ( I11i1I1I )
 ooo0O = sorted ( iIo00O )
 if 75 - 75: O0o00 % O0o00 . iiIIi1IiIi11
 III1iII1I1ii = [ ]
 oOOo0 = [ ]
 oo00O00oO = [ ]
 iIiIIIi = 0
 if 93 - 93: oOOOO
 if Oo0oOOo != 'null' :
  if 10 - 10: oOOOo0o0O
  OOooOO000 = re . compile ( '<cat>' + re . escape ( Oo0oOOo ) + '</cat>(.+?)</item>' , re . DOTALL ) . findall ( I11IiI1I11i1i ) [ 0 ]
  if 97 - 97: o0ooo + I1ii / OoOO / oOOOO
  ii11i1 = re . compile ( '<name>(.+?)</name>' ) . findall ( OOooOO000 )
  if 37 - 37: oOOOO - i1Ii * OOO0O % i11iIiiIii - iiIIi1IiIi11
  for o0oO in ooo0O :
   for name , url in Ii :
    IIiIi1iI = name . replace ( ' ' , '' )
    if 35 - 35: OOoOoo00oo % Ii1I - Ii1I
    if o0oO . lower ( ) in IIiIi1iI . lower ( ) :
     if url not in str ( oOOo0 ) :
      if 16 - 16: i1I1ii1II1iII % OOo000 - i1I1ii1II1iII + OOoOoo00oo
      for i1I1i in ii11i1 :
       if i1I1i in name . lower ( ) :
        iIiIIIi = 1
      if iIiIIIi == 0 :
       for O00o0OO in O0O :
        Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( O00o0OO ) [ 0 ]
        I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( O00o0OO ) [ 0 ]
        if I11i1ii1 . lower ( ) == "null" : I11i1ii1 = ""
        name = name . lower ( )
        Iiiii1i = Iiiii1i . lower ( )
        I11i1ii1 = I11i1ii1 . lower ( )
        name = name . replace ( Iiiii1i , I11i1ii1 )
       for O0Oooo0O in oo000OO00Oo :
        Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( O0Oooo0O ) [ 0 ]
        I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( O0Oooo0O ) [ 0 ]
        name = name . lower ( )
        Iiiii1i = Iiiii1i . lower ( )
        I11i1ii1 = I11i1ii1 . lower ( )
        name = name . replace ( Iiiii1i , I11i1ii1 )
        name = name . lstrip ( ' ' )
       III1iII1I1ii . append ( name )
       oOOo0 . append ( url )
       oo00O00oO = list ( zip ( III1iII1I1ii , oOOo0 ) )
      iIiIIIi = 0
 else :
  for o0oO in ooo0O :
   for name , url in Ii :
    IIiIi1iI = name . replace ( ' ' , '' )
    if 84 - 84: oOOOO . o0ooo / ooO00oOoo - oooO0oo0oOOOO / OoOO0ooOOoo0O / O0o00
    if o0oO . lower ( ) in IIiIi1iI . lower ( ) :
     if url not in str ( oOOo0 ) :
      if 12 - 12: oooO0oo0oOOOO * oOOOO % o0000oOoOoO0o % OoOO
      for O00o0OO in O0O :
       Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( O00o0OO ) [ 0 ]
       I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( O00o0OO ) [ 0 ]
       if I11i1ii1 . lower ( ) == "null" : I11i1ii1 = ""
       name = name . replace ( Iiiii1i , I11i1ii1 )
      for O0Oooo0O in oo000OO00Oo :
       Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( O0Oooo0O ) [ 0 ]
       I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( O0Oooo0O ) [ 0 ]
       name = name . replace ( Iiiii1i , I11i1ii1 )
      name = name . lstrip ( ' ' )
      III1iII1I1ii . append ( name )
      oOOo0 . append ( url )
      oo00O00oO = list ( zip ( III1iII1I1ii , oOOo0 ) )
      if 20 - 20: I1ii % OOoOoo00oo / OOoOoo00oo + OOoOoo00oo
      if 45 - 45: OOO0O - i1iiIII111ii - OoOO0ooOOoo0O - O0OOo . i1I1ii1II1iII / Ii1I
 oo0o00O = sorted ( oo00O00oO )
 if 51 - 51: OOoOoo00oo - O0OOo * oOOOO
 for name , url in oo0o00O :
  if 66 - 66: OoOO0ooOOoo0O + Ii1I
  I1IiiIIIi = name . title ( ) + '|SPLIT|' + url
  if 41 - 41: OOoOoo00oo - Ii1I - Ii1I
  if os . path . exists ( I1IiiI ) :
   if "hd" in name . lower ( ) :
    name = name . lower ( )
    name = name . replace ( 'hd' , '' )
    I111I11 ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , I1IiiIIIi , 3 , iiiii , O0O0OO0O0O0 )
  else :
   if "hd" in name . lower ( ) :
    name = name . lower ( )
    name = name . replace ( 'hd' , '' )
    I111I11 ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , I1IiiIIIi , 3 , iiiii , O0O0OO0O0O0 )
   else :
    I111I11 ( '[COLOR white]' + name . title ( ) + '[/COLOR]' , I1IiiIIIi , 3 , iiiii , O0O0OO0O0O0 )
    if 68 - 68: I1ii % iiIIi1IiIi11
 IiIIIiI1I1 = OoO000 ( )
 if 88 - 88: OoOO - i1Ii + I1ii
 if IiIIIiI1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IiIIIiI1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 40 - 40: oooO0oo0oOOOO * OOoOoo00oo + I1ii % oOOOO
def OOOOOoo0 ( ) :
 if 49 - 49: Ii1I . oOOOO
 oo000OO00Oo = ''
 I1iI1iIi111i = xbmc . Keyboard ( oo000OO00Oo , 'Enter Search Term' )
 I1iI1iIi111i . doModal ( )
 if I1iI1iIi111i . isConfirmed ( ) :
  oo000OO00Oo = I1iI1iIi111i . getText ( )
  if len ( oo000OO00Oo ) > 1 :
   if not oo000OO00Oo == base64 . b64decode ( 'Z2VuZXJhdGVpbmk=' ) :
    IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, incorrect password." )
    quit ( )
  else : quit ( )
  if 44 - 44: o0000oOoOoO0o % i1I1ii1II1iII + oOOOo0o0O
 o0ooo00O0o0 = o0Oo00OOOOO ( o0oO0 )
 ii11i1 = re . compile ( '<link>(.+?)</link>' ) . findall ( o0ooo00O0o0 )
 if 45 - 45: oOOOO / oOOOO + iiIIi1IiIi11 + i1Ii
 for O00o0OO in ii11i1 :
  O0O00Ooo ( O00o0OO , O00o0OO , 7 , iiiii , O0O0OO0O0O0 )
  if 47 - 47: O0o00 + i1Ii
 IiIIIiI1I1 = OoO000 ( )
 if 82 - 82: i1I1ii1II1iII . i1iiIII111ii - OoOO - i1iiIII111ii * i1I1ii1II1iII
 if IiIIIiI1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IiIIIiI1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 77 - 77: OoOO * O0OOo
def oOooOo0 ( url ) :
 if 38 - 38: iiIIi1IiIi11
 iIIIIii1 = o0Oo00OOOOO ( o00 )
 iIIIIii1 = iIIIIii1 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oo000OO00Oo = re . compile ( '<item>(.+?)</item>' ) . findall ( iIIIIii1 )
 if 84 - 84: OoOO % oOOOO / OoOO % oOOOo0o0O
 o0O0O00 = o0Oo00OOOOO ( oo00 )
 o0O0O00 = o0O0O00 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O0O = re . compile ( '<item>(.+?)</item>' ) . findall ( o0O0O00 )
 if 45 - 45: Ii1I
 I1III = o0Oo00OOOOO ( url )
 I1III = I1III . replace ( '#AAASTREAM:' , '#A:' )
 I1III = I1III . replace ( '#EXTINF:' , '#A:' )
 OO0O0OoOO0 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( I1III )
 iiiI1I11i1 = [ ]
 for IIi1i11111 , ooOO00O00oo , url in OO0O0OoOO0 :
  I1ii11iI = { "params" : IIi1i11111 , "display_name" : ooOO00O00oo , "url" : url }
  iiiI1I11i1 . append ( I1ii11iI )
 IIi1i = [ ]
 for I1I1iIiII1 in iiiI1I11i1 :
  I1ii11iI = { "display_name" : I1I1iIiII1 [ "display_name" ] , "url" : I1I1iIiII1 [ "url" ] }
  OO0O0OoOO0 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( I1I1iIiII1 [ "params" ] )
  for i11i1I1 , ii1I in OO0O0OoOO0 :
   I1ii11iI [ i11i1I1 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = ii1I . strip ( )
  IIi1i . append ( I1ii11iI )
  if 26 - 26: oOOOo0o0O - OoOO - oooO0oo0oOOOO / O0OOo . OOo000 % OoOO
 for I1I1iIiII1 in IIi1i :
  I11i1 = o0oo ( I1I1iIiII1 [ "display_name" ] )
  url = o0oo ( I1I1iIiII1 [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if 91 - 91: O0o00 . OoOO / OOO0O + o0000oOoOoO0o
  for O00o0OO in O0O :
   Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( O00o0OO ) [ 0 ]
   I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( O00o0OO ) [ 0 ]
   if I11i1ii1 . lower ( ) == "null" : I11i1ii1 = ""
   I11i1 = I11i1 . replace ( Iiiii1i , I11i1ii1 )
  for O0Oooo0O in oo000OO00Oo :
   Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( O0Oooo0O ) [ 0 ]
   I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( O0Oooo0O ) [ 0 ]
   I11i1 = I11i1 . replace ( Iiiii1i , I11i1ii1 )
  I11i1 = I11i1 . lstrip ( ' ' )
  if 42 - 42: i1Ii . O0o00 . i1Ii - o0ooo
  I111I11 ( I11i1 , url , 3 , iiiii , O0O0OO0O0O0 )
  if 40 - 40: i1Ii - i11iIiiIii / OOoOoo00oo
 I11i11Ii . close ( )
 if 35 - 35: OOoOoo00oo - oooO0oo0oOOOO % O0o00 . OoOO0ooOOoo0O % OOoOoo00oo
 IiIIIiI1I1 = OoO000 ( )
 if 47 - 47: oOOOO - OOoOoo00oo . i1I1ii1II1iII + OoOO0ooOOoo0O . i11iIiiIii
 if IiIIIiI1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IiIIIiI1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 94 - 94: O0o00 * OOoOoo00oo / ooO00oOoo / OOoOoo00oo
def iiI11 ( name , url ) :
 if 87 - 87: ooO00oOoo . i1iiIII111ii
 O0OO0O = 0
 if 81 - 81: OOO0O . O0o00 % Ii1I / oooO0oo0oOOOO - OOO0O
 if not os . path . exists ( Oooo000o ) :
  os . makedirs ( Oooo000o )
 if not os . path . isfile ( IiIi11iIIi1Ii ) :
  open ( IiIi11iIIi1Ii , 'w' )
  if 43 - 43: i11iIiiIii + ooO00oOoo * i1I1ii1II1iII * iiIIi1IiIi11 * Ii1I
 iiii11I = open ( IiIi11iIIi1Ii )
 o00oO0oo0OO = iiii11I . read ( )
 if 57 - 57: iiIIi1IiIi11 % OOoOoo00oo + O0o00 - ooO00oOoo
 if len ( o00oO0oo0OO ) == 0 :
  O0OO0O = 1
  if 65 - 65: oOOOo0o0O . OOo000
 if O0OO0O == 1 :
  I11i11Ii . create ( Oo0Ooo , "Getting files to make ECHO Streams AWESOME!" )
  if 39 - 39: i1I1ii1II1iII / i1Ii + iiIIi1IiIi11 / OOo000
  try :
   shutil . rmtree ( Oooo000o )
   os . makedirs ( Oooo000o )
  except : pass
  if 13 - 13: i1iiIII111ii + Ii1I + oOOOO % oooO0oo0oOOOO / O0o00 . i1iiIII111ii
  I11i11Ii . update ( 0 , "" , "[COLOR dodgerblue]Contacting ECHO Servers.[/COLOR]" )
  o0ooo00O0o0 = o0Oo00OOOOO ( O0oO )
  o0ooo00O0o0 = o0ooo00O0o0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
  O0O = re . compile ( '<item>(.+?)</item>' ) . findall ( o0ooo00O0o0 )
  OO0Oooo0oOO0O = len ( O0O )
  o00O0 = OO0Oooo0oOO0O + 4
  if 83 - 83: i1Ii
  oO00Oo0O0o = 100 * 1 / int ( o00O0 )
  I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U Cleaner file.[/COLOR]" , "[COLOR lime]File 1 of " + str ( o00O0 ) + "[/COLOR]" )
  file = o0Oo00OOOOO ( o00 )
  iiii11I = open ( Oo0O , "w" )
  iiii11I . write ( file )
  iiii11I . close ( )
  if 13 - 13: OoOO0ooOOoo0O
  oO00Oo0O0o = 100 * 2 / int ( o00O0 )
  I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U Replacer file.[/COLOR]" , "[COLOR lime]File 2 of " + str ( o00O0 ) + "[/COLOR]" )
  file = o0Oo00OOOOO ( oo00 )
  iiii11I = open ( IiI , "w" )
  iiii11I . write ( file )
  iiii11I . close ( )
  if 33 - 33: iiIIi1IiIi11 + oOOOO * OOO0O / OoOO - oooO0oo0oOOOO
  oO00Oo0O0o = 100 * 3 / int ( o00O0 )
  I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the Blacklist file.[/COLOR]" , "[COLOR lime]File 3 of " + str ( o00O0 ) + "[/COLOR]" )
  file = o0Oo00OOOOO ( Oo0oO0ooo )
  iiii11I = open ( ooOo , "w" )
  iiii11I . write ( file )
  iiii11I . close ( )
  if 54 - 54: iiIIi1IiIi11 / I1ii . OOO0O % oOOOO
  oO00Oo0O0o = 100 * 4 / int ( o00O0 )
  I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U files.[/COLOR]" , "[COLOR lime]File 4 of " + str ( o00O0 ) + "[/COLOR]" )
  Oo = O0OOOOo0O ( )
  iiii11I = open ( IiIi11iIIi1Ii , "w" )
  iiii11I . write ( Oo )
  iiii11I . close ( )
  if 81 - 81: Ii1I / O0OOo . o0000oOoOoO0o + oooO0oo0oOOOO - oOOOo0o0O
  OoOOoOooooOOo = 4
  if 87 - 87: oooO0oo0oOOOO
  for O00o0OO in O0O :
   OoOOoOooooOOo = OoOOoOooooOOo + 1
   oO00Oo0O0o = 100 * int ( OoOOoOooooOOo ) / int ( o00O0 )
   I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the menu files.[/COLOR]" , "[COLOR lime]File " + str ( OoOOoOooooOOo ) + " of " + str ( o00O0 ) + "[/COLOR]" )
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( O00o0OO ) [ 0 ]
   url = re . compile ( '<folder>(.+?)</folder>' ) . findall ( O00o0OO ) [ 0 ]
   if 58 - 58: OOo000 % O0o00
   file = o0Oo00OOOOO ( url )
   Iii111II = xbmc . translatePath ( os . path . join ( Oooo000o , name + ".xml" ) )
   if 50 - 50: iiIIi1IiIi11 . O0o00
   iiii11I = open ( Iii111II , "w" )
   iiii11I . write ( file )
   iiii11I . close ( )
   if 97 - 97: Ii1I + OOo000
  I11i11Ii . close ( )
  return
  if 89 - 89: O0o00 + O0OOo * oOOOo0o0O * OOoOoo00oo
 if url == "true" :
  if 37 - 37: OoOO0ooOOoo0O - Ii1I - O0o00
  o0o0O0O00oOOo = os . path . getmtime ( IiIi11iIIi1Ii )
  if 14 - 14: OOo000 + OOO0O
  oo00oO0O0 = time . time ( )
  if 30 - 30: I1ii + o0ooo * oOOOo0o0O % i11iIiiIii % OOo000
  OO0OoOO0o0o = oo00oO0O0 - 60 * 60
  if 95 - 95: i11iIiiIii
  if o0o0O0O00oOOo < OO0OoOO0o0o :
   if 32 - 32: I1ii
   I11i11Ii . create ( Oo0Ooo , "Getting files to make ECHO Streams AWESOME!" )
   if 42 - 42: i1iiIII111ii * Ii1I % o0000oOoOoO0o . I1ii / O0o00
   try :
    shutil . rmtree ( Oooo000o )
    os . makedirs ( Oooo000o )
   except : pass
   if 32 - 32: oooO0oo0oOOOO * ooO00oOoo
   I11i11Ii . update ( 0 , "" , "[COLOR dodgerblue]Contacting ECHO Servers.[/COLOR]" )
   o0ooo00O0o0 = o0Oo00OOOOO ( O0oO )
   o0ooo00O0o0 = o0ooo00O0o0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
   O0O = re . compile ( '<item>(.+?)</item>' ) . findall ( o0ooo00O0o0 )
   OO0Oooo0oOO0O = len ( O0O )
   o00O0 = OO0Oooo0oOO0O + 4
   if 78 - 78: I1ii - OoOO0ooOOoo0O - o0ooo / i1Ii / i1I1ii1II1iII
   oO00Oo0O0o = 100 * 1 / int ( o00O0 )
   I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U Cleaner file.[/COLOR]" , "[COLOR lime]File 1 of " + str ( o00O0 ) + "[/COLOR]" )
   file = o0Oo00OOOOO ( o00 )
   iiii11I = open ( Oo0O , "w" )
   iiii11I . write ( file )
   iiii11I . close ( )
   if 29 - 29: oooO0oo0oOOOO % oooO0oo0oOOOO
   oO00Oo0O0o = 100 * 2 / int ( o00O0 )
   I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U Replacer file.[/COLOR]" , "[COLOR lime]File 2 of " + str ( o00O0 ) + "[/COLOR]" )
   file = o0Oo00OOOOO ( oo00 )
   iiii11I = open ( IiI , "w" )
   iiii11I . write ( file )
   iiii11I . close ( )
   if 94 - 94: OoOO / ooO00oOoo % oOOOO * oOOOO * i1I1ii1II1iII
   oO00Oo0O0o = 100 * 3 / int ( o00O0 )
   I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the Blacklist file.[/COLOR]" , "[COLOR lime]File 3 of " + str ( o00O0 ) + "[/COLOR]" )
   file = o0Oo00OOOOO ( Oo0oO0ooo )
   iiii11I = open ( ooOo , "w" )
   iiii11I . write ( file )
   iiii11I . close ( )
   if 29 - 29: O0OOo + OOo000 / O0o00 / I1ii * OoOO
   oO00Oo0O0o = 100 * 4 / int ( o00O0 )
   I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U files.[/COLOR]" , "[COLOR lime]File 4 of " + str ( o00O0 ) + "[/COLOR]" )
   Oo = O0OOOOo0O ( )
   iiii11I = open ( IiIi11iIIi1Ii , "w" )
   iiii11I . write ( Oo )
   iiii11I . close ( )
   if 62 - 62: I1ii / OOO0O - O0OOo . oOOOo0o0O
   OoOOoOooooOOo = 4
   if 11 - 11: o0ooo . O0OOo * i1iiIII111ii * OoOO0ooOOoo0O + i1Ii
   for O00o0OO in O0O :
    OoOOoOooooOOo = OoOOoOooooOOo + 1
    oO00Oo0O0o = 100 * int ( OoOOoOooooOOo ) / int ( o00O0 )
    I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the menu files.[/COLOR]" , "[COLOR lime]File " + str ( OoOOoOooooOOo ) + " of " + str ( o00O0 ) + "[/COLOR]" )
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( O00o0OO ) [ 0 ]
    url = re . compile ( '<folder>(.+?)</folder>' ) . findall ( O00o0OO ) [ 0 ]
    if 33 - 33: Ii1I * O0o00 - iiIIi1IiIi11 % iiIIi1IiIi11
    file = o0Oo00OOOOO ( url )
    Iii111II = xbmc . translatePath ( os . path . join ( Oooo000o , name + ".xml" ) )
    if 18 - 18: iiIIi1IiIi11 / ooO00oOoo * iiIIi1IiIi11 + iiIIi1IiIi11 * i11iIiiIii * o0ooo
    iiii11I = open ( Iii111II , "w" )
    iiii11I . write ( file )
    iiii11I . close ( )
    if 11 - 11: i1Ii / OOo000 - i1iiIII111ii * OoOO0ooOOoo0O + OoOO0ooOOoo0O . OOo000
   I11i11Ii . close ( )
   return
 else :
  if 26 - 26: OOoOoo00oo % o0ooo
  I11i11Ii . create ( Oo0Ooo , "Getting files to make ECHO Streams AWESOME!" )
  if 76 - 76: i1iiIII111ii * oOOOO
  try :
   shutil . rmtree ( Oooo000o )
   os . makedirs ( Oooo000o )
  except : pass
  if 52 - 52: I1ii
  I11i11Ii . update ( 0 , "" , "[COLOR dodgerblue]Contacting ECHO Servers.[/COLOR]" )
  o0ooo00O0o0 = o0Oo00OOOOO ( O0oO )
  o0ooo00O0o0 = o0ooo00O0o0 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
  O0O = re . compile ( '<item>(.+?)</item>' ) . findall ( o0ooo00O0o0 )
  OO0Oooo0oOO0O = len ( O0O )
  o00O0 = OO0Oooo0oOO0O + 4
  if 19 - 19: oooO0oo0oOOOO
  oO00Oo0O0o = 100 * 1 / int ( o00O0 )
  I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U Cleaner file.[/COLOR]" , "[COLOR lime]File 1 of " + str ( o00O0 ) + "[/COLOR]" )
  file = o0Oo00OOOOO ( o00 )
  iiii11I = open ( Oo0O , "w" )
  iiii11I . write ( file )
  iiii11I . close ( )
  if 25 - 25: OOoOoo00oo / i1Ii
  oO00Oo0O0o = 100 * 2 / int ( o00O0 )
  I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U Replacer file.[/COLOR]" , "[COLOR lime]File 2 of " + str ( o00O0 ) + "[/COLOR]" )
  file = o0Oo00OOOOO ( oo00 )
  iiii11I = open ( IiI , "w" )
  iiii11I . write ( file )
  iiii11I . close ( )
  if 31 - 31: I1ii . Ii1I % oooO0oo0oOOOO . O0o00 + i1iiIII111ii
  oO00Oo0O0o = 100 * 3 / int ( o00O0 )
  I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the Blacklist file.[/COLOR]" , "[COLOR lime]File 3 of " + str ( o00O0 ) + "[/COLOR]" )
  file = o0Oo00OOOOO ( Oo0oO0ooo )
  iiii11I = open ( ooOo , "w" )
  iiii11I . write ( file )
  iiii11I . close ( )
  if 71 - 71: iiIIi1IiIi11 . i1I1ii1II1iII
  oO00Oo0O0o = 100 * 4 / int ( o00O0 )
  I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the M3U files.[/COLOR]" , "[COLOR lime]File 4 of " + str ( o00O0 ) + "[/COLOR]" )
  Oo = O0OOOOo0O ( )
  iiii11I = open ( IiIi11iIIi1Ii , "w" )
  iiii11I . write ( Oo )
  iiii11I . close ( )
  if 62 - 62: OoOO0ooOOoo0O . oOOOo0o0O
  OoOOoOooooOOo = 4
  if 61 - 61: OOo000 - I1ii - o0000oOoOoO0o
  for O00o0OO in O0O :
   OoOOoOooooOOo = OoOOoOooooOOo + 1
   oO00Oo0O0o = 100 * int ( OoOOoOooooOOo ) / int ( o00O0 )
   I11i11Ii . update ( oO00Oo0O0o , "" , "[COLOR dodgerblue]Downloading the menu files.[/COLOR]" , "[COLOR lime]File " + str ( OoOOoOooooOOo ) + " of " + str ( o00O0 ) + "[/COLOR]" )
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( O00o0OO ) [ 0 ]
   url = re . compile ( '<folder>(.+?)</folder>' ) . findall ( O00o0OO ) [ 0 ]
   if 25 - 25: Ii1I * oOOOo0o0O + o0ooo . O0o00 . O0o00
   file = o0Oo00OOOOO ( url )
   Iii111II = xbmc . translatePath ( os . path . join ( Oooo000o , name + ".xml" ) )
   if 58 - 58: oooO0oo0oOOOO
   iiii11I = open ( Iii111II , "w" )
   iiii11I . write ( file )
   iiii11I . close ( )
   if 53 - 53: o0000oOoOoO0o
  I11i11Ii . close ( )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "[COLOR white]All ECHO Streams files have been refreshed.[/COLOR]" , "[COLOR lime]All lists are now up-to-date.[/COLOR]" )
  if 59 - 59: O0o00
def O0OOOOo0O ( ) :
 if 81 - 81: OOo000 - OOo000 . oOOOO
 o0OoOo00o0o = open ( Oo0O )
 I1II1I11I1I = o0OoOo00o0o . read ( )
 OoOO0o = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( I1II1I11I1I )
 if 1 - 1: i1I1ii1II1iII
 O0oOo00o = open ( IiI )
 o0ooooO0o0O = O0oOo00o . read ( )
 iiIi11iI1iii = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( o0ooooO0o0O )
 if 67 - 67: Ii1I / iiIIi1IiIi11
 list = ""
 OOO0000oO = o0Oo00OOOOO ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0O = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( OOO0000oO )
 for O0Oooo0O in O0O :
  list = list + O0Oooo0O + "\n"
 list = list . replace ( "<br />" , "\n" )
 if 15 - 15: OOo000 % oooO0oo0oOOOO * oOOOo0o0O
 if 81 - 81: i1Ii - OoOO - o0000oOoOoO0o / iiIIi1IiIi11 - Ii1I * oOOOo0o0O
 if 20 - 20: OOO0O % i1iiIII111ii
 if 19 - 19: o0ooo % i1iiIII111ii + i1Ii / iiIIi1IiIi11 . i1Ii
 if 12 - 12: o0000oOoOoO0o + o0000oOoOoO0o - o0ooo * ooO00oOoo % ooO00oOoo - i1I1ii1II1iII
 if 52 - 52: i1Ii . oOOOO + iiIIi1IiIi11
 if 38 - 38: o0000oOoOoO0o - i1I1ii1II1iII . iiIIi1IiIi11
 if 58 - 58: oooO0oo0oOOOO . oOOOO + OOo000
 if 66 - 66: oOOOO / OOO0O * OoOO0ooOOoo0O + OoOO0ooOOoo0O % oOOOo0o0O
 if 49 - 49: OOO0O - i11iIiiIii . iiIIi1IiIi11 * OOoOoo00oo % oOOOO + o0000oOoOoO0o
 if 71 - 71: O0o00
 if 38 - 38: OOO0O % OOo000 + o0ooo . i11iIiiIii
 if 53 - 53: i11iIiiIii * oOOOO
 if 68 - 68: OoOO * OoOO . O0o00 / i1I1ii1II1iII % ooO00oOoo
 if 38 - 38: i1Ii - I1ii / oOOOO
 if 66 - 66: Ii1I % o0ooo + i11iIiiIii . OOo000 / OOoOoo00oo + o0ooo
 return list
 if 86 - 86: O0o00
def i1Iii11Ii1i1 ( ) :
 if 59 - 59: ooO00oOoo % OoOO0ooOOoo0O . oOOOO / i1iiIII111ii + oooO0oo0oOOOO
 OoOo ( )
 if 76 - 76: i1Ii
 oo000OO00Oo = ''
 I1iI1iIi111i = xbmc . Keyboard ( oo000OO00Oo , 'Enter Search Term' )
 I1iI1iIi111i . doModal ( )
 if I1iI1iIi111i . isConfirmed ( ) :
  oo000OO00Oo = I1iI1iIi111i . getText ( )
  if len ( oo000OO00Oo ) > 1 :
   iIi1ii1I1 = oo000OO00Oo
   iI ( "search" , iIi1ii1I1 , iiiii )
  else : quit ( )
  if 73 - 73: Ii1I * oOOOO + OOoOoo00oo + i1Ii
def Iio0O0Oo ( ) :
 if 62 - 62: Ii1I % oOOOo0o0O . oOOOo0o0O - OoOO / i11iIiiIii
 if not os . path . exists ( ooo0OO ) :
  try :
   os . makedirs ( ooo0OO )
  except : pass
 if os . path . exists ( I1IiiI ) :
  try :
   os . remove ( I1IiiI )
  except : pass
 else :
  try :
   open ( I1IiiI , 'w' )
  except : pass
  if 31 - 31: OoOO / O0OOo / o0ooo
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 41 - 41: ooO00oOoo
def OoOo ( ) :
 if 10 - 10: ooO00oOoo / ooO00oOoo / iiIIi1IiIi11 . iiIIi1IiIi11
 if os . path . exists ( O00ooooo00 ) :
  OOoo = iIIiiiI ( heading = "Please Enter Your Password" )
  if ( not OOoo ) :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  oo0 = OOoo
  if 34 - 34: oooO0oo0oOOOO % oOOOO + i1Ii * OoOO
  Ii11 = open ( O00ooooo00 , "r" )
  IIiI1Ii = re . compile ( r'<password>(.+?)</password>' )
  for O0O0O0Oo in Ii11 :
   file = IIiI1Ii . findall ( O0O0O0Oo )
   for OOOOoO00o0O in file :
    I1I1I1IIi1III = base64 . b64decode ( OOOOoO00o0O )
    if not I1I1I1IIi1III == oo0 :
     if not OOOOoO00o0O == oo0 :
      IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 5 - 5: ooO00oOoo % i1Ii % i11iIiiIii + O0o00 / o0ooo - o0ooo
def iIIIiiI1i1i ( ) :
 if 32 - 32: OOo000 / O0OOo + I1ii
 OoOo ( )
 if 32 - 32: OoOO % oOOOO
 i1 = 0
 if not os . path . exists ( O00ooooo00 ) :
  i1 = 1
  I111I11 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  I111I11 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  Ii11 = open ( O00ooooo00 , "r" )
  IIiI1Ii = re . compile ( r'<password>(.+?)</password>' )
  for O0O0O0Oo in Ii11 :
   file = IIiI1Ii . findall ( O0O0O0Oo )
   for OOOOoO00o0O in file :
    I1I1I1IIi1III = base64 . b64decode ( OOOOoO00o0O )
    i1 = 1
    I111I11 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    I111I11 ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( I1I1I1IIi1III ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    I111I11 ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    I111I11 ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 65 - 65: i1Ii . OoOO0ooOOoo0O / o0ooo . o0000oOoOoO0o * O0OOo
 if i1 == 0 :
  I111I11 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  I111I11 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 19 - 19: i11iIiiIii + OoOO0ooOOoo0O - ooO00oOoo - oOOOo0o0O
 IiIIIiI1I1 = OoO000 ( )
 if 21 - 21: Ii1I % i1iiIII111ii . oooO0oo0oOOOO / i1I1ii1II1iII + i1iiIII111ii
 if IiIIIiI1I1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif IiIIIiI1I1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 53 - 53: OOO0O - oooO0oo0oOOOO - OOO0O * oOOOO
def oooooo0OO ( ) :
 if 14 - 14: OOO0O / OOO0O % i1Ii
 OOoo = iIIiiiI ( heading = "Please Set Password" )
 if ( not OOoo ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 oo0 = OOoo
 if 56 - 56: oooO0oo0oOOOO . Ii1I + ooO00oOoo
 OOoo = iIIiiiI ( heading = "Please Confirm Your Password" )
 if ( not OOoo ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 i1II1I1Iii1 = OOoo
 if 30 - 30: OoOO0ooOOoo0O - OOo000
 if not os . path . exists ( O00ooooo00 ) :
  if not os . path . exists ( II1 ) :
   os . makedirs ( II1 )
  open ( O00ooooo00 , 'w' )
  if 75 - 75: OoOO - OOoOoo00oo . ooO00oOoo % i11iIiiIii % oOOOo0o0O
  if oo0 == i1II1I1Iii1 :
   O00 = base64 . b64encode ( oo0 )
   iiIi11iI1iii = open ( O00ooooo00 , 'w' )
   iiIi11iI1iii . write ( '<password>' + str ( O00 ) + '</password>' )
   iiIi11iI1iii . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( O00ooooo00 )
  if 30 - 30: oooO0oo0oOOOO + O0OOo % OOoOoo00oo * oOOOO / ooO00oOoo - oOOOo0o0O
  if oo0 == i1II1I1Iii1 :
   O00 = base64 . b64encode ( oo0 )
   iiIi11iI1iii = open ( O00ooooo00 , 'w' )
   iiIi11iI1iii . write ( '<password>' + str ( O00 ) + '</password>' )
   iiIi11iI1iii . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 64 - 64: OoOO
def iII1ii1 ( ) :
 if 99 - 99: i1Ii . iiIIi1IiIi11 % i1iiIII111ii * i1iiIII111ii . o0000oOoOoO0o
 try :
  os . remove ( O00ooooo00 )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 72 - 72: I1ii % o0ooo + O0OOo / OOO0O + i1iiIII111ii
def OoO000 ( ) :
 if 10 - 10: iiIIi1IiIi11 / i1Ii + i11iIiiIii / OOoOoo00oo
 OOOoOoO = xbmc . getInfoLabel ( "System.BuildVersion" )
 iIIIII1ii1I = float ( OOOoOoO [ : 4 ] )
 if iIIIII1ii1I >= 11.0 and iIIIII1ii1I <= 11.9 :
  Ii1i1iI = 'Eden'
 elif iIIIII1ii1I >= 12.0 and iIIIII1ii1I <= 12.9 :
  Ii1i1iI = 'Frodo'
 elif iIIIII1ii1I >= 13.0 and iIIIII1ii1I <= 13.9 :
  Ii1i1iI = 'Gotham'
 elif iIIIII1ii1I >= 14.0 and iIIIII1ii1I <= 14.9 :
  Ii1i1iI = 'Helix'
 elif iIIIII1ii1I >= 15.0 and iIIIII1ii1I <= 15.9 :
  Ii1i1iI = 'Isengard'
 elif iIIIII1ii1I >= 16.0 and iIIIII1ii1I <= 16.9 :
  Ii1i1iI = 'Jarvis'
 elif iIIIII1ii1I >= 17.0 and iIIIII1ii1I <= 17.9 :
  Ii1i1iI = 'Krypton'
 else : Ii1i1iI = "Decline"
 if 16 - 16: I1ii / ooO00oOoo / OoOO0ooOOoo0O * oooO0oo0oOOOO + o0000oOoOoO0o % I1ii
 return Ii1i1iI
 if 71 - 71: OOo000
def ii111IiiI1 ( name , url , iconimage ) :
 if 11 - 11: OoOO * OOoOoo00oo
 try :
  name , url = url . split ( '|SPLIT|' )
 except : pass
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 76 - 76: i1Ii
 II = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , II , False )
 if 45 - 45: OoOO0ooOOoo0O - I1ii + Ii1I * OOoOoo00oo . o0ooo
def o0oo ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 39 - 39: OoOO / Ii1I / OOO0O - OOoOoo00oo - oOOOO % I1ii
def o0Oo00OOOOO ( url ) :
 if 31 - 31: oOOOo0o0O - Ii1I / i1Ii * OOo000
 iI111i1II = urllib2 . Request ( url )
 iI111i1II . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 I1III = urllib2 . urlopen ( iI111i1II )
 o0ooo00O0o0 = I1III . read ( )
 I1III . close ( )
 return o0ooo00O0o0
 if 69 - 69: OOoOoo00oo * Ii1I . i11iIiiIii / OOoOoo00oo . O0o00
def iIIiiiI ( default = "" , heading = "" , hidden = False ) :
 I1iI1iIi111i = xbmc . Keyboard ( default , heading , hidden )
 if 63 - 63: oOOOo0o0O + O0o00 . i1I1ii1II1iII - oooO0oo0oOOOO
 I1iI1iIi111i . doModal ( )
 if ( I1iI1iIi111i . isConfirmed ( ) ) :
  return unicode ( I1iI1iIi111i . getText ( ) , "utf-8" )
 return default
 if 52 - 52: O0o00 % ooO00oOoo
def O0O00Ooo ( name , url , mode , iconimage , fanartimage ) :
 if 64 - 64: Ii1I % oOOOo0o0O % Ii1I * O0OOo . OOO0O + oooO0oo0oOOOO
 O00I11ii1i1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 ooo0OoOOOOO = True
 II = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 II . setProperty ( "fanart_Image" , fanartimage )
 II . setProperty ( "icon_Image" , iconimage )
 ooo0OoOOOOO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O00I11ii1i1 , listitem = II , isFolder = True )
 return ooo0OoOOOOO
 if 26 - 26: o0ooo
def I111I11 ( name , url , mode , iconimage , fanartimage ) :
 if 73 - 73: i11iIiiIii - i1iiIII111ii
 O00I11ii1i1 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 ooo0OoOOOOO = True
 II = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 II . setProperty ( "fanart_Image" , fanartimage )
 II . setProperty ( "icon_Image" , iconimage )
 ooo0OoOOOOO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = O00I11ii1i1 , listitem = II , isFolder = False )
 return ooo0OoOOOOO
 if 25 - 25: OoOO0ooOOoo0O + i1iiIII111ii * o0ooo
def OoO0ooO ( ) :
 O000 = [ ]
 i1iIi = sys . argv [ 2 ]
 if len ( i1iIi ) >= 2 :
  IIi1i11111 = sys . argv [ 2 ]
  IIIII = IIi1i11111 . replace ( '?' , '' )
  if ( IIi1i11111 [ len ( IIi1i11111 ) - 1 ] == '/' ) :
   IIi1i11111 = IIi1i11111 [ 0 : len ( IIi1i11111 ) - 2 ]
  o0ooOoO000oO = IIIII . split ( '&' )
  O000 = { }
  for OoOOoOooooOOo in range ( len ( o0ooOoO000oO ) ) :
   OOo = { }
   OOo = o0ooOoO000oO [ OoOOoOooooOOo ] . split ( '=' )
   if ( len ( OOo ) ) == 2 :
    O000 [ OOo [ 0 ] ] = OOo [ 1 ]
    if 50 - 50: i1Ii
 return O000
 if 72 - 72: iiIIi1IiIi11
IIi1i11111 = OoO0ooO ( ) ; I11i1 = None ; iIi1ii1I1 = None ; OO0ooo0oOO = None ; o0 = None ; oo000 = None
try : I11i1 = urllib . unquote_plus ( IIi1i11111 [ "name" ] )
except : pass
try : iIi1ii1I1 = urllib . unquote_plus ( IIi1i11111 [ "url" ] )
except : pass
try : OO0ooo0oOO = int ( IIi1i11111 [ "mode" ] )
except : pass
try : o0 = urllib . unquote_plus ( IIi1i11111 [ "iconimage" ] )
except : pass
try : oo000 = urllib . quote_plus ( IIi1i11111 [ "fanartimage" ] )
except : pass
if 32 - 32: o0000oOoOoO0o . OOoOoo00oo
if OO0ooo0oOO == None or iIi1ii1I1 == None or len ( iIi1ii1I1 ) < 1 : IIi ( )
elif OO0ooo0oOO == 1 : IIi ( )
elif OO0ooo0oOO == 2 : iI ( I11i1 , iIi1ii1I1 , o0 )
elif OO0ooo0oOO == 3 : ii111IiiI1 ( I11i1 , iIi1ii1I1 , o0 )
elif OO0ooo0oOO == 4 : i1Iii11Ii1i1 ( )
elif OO0ooo0oOO == 5 : Iio0O0Oo ( )
elif OO0ooo0oOO == 6 : OOOOOoo0 ( )
elif OO0ooo0oOO == 7 : oOooOo0 ( iIi1ii1I1 )
elif OO0ooo0oOO == 8 : iiI11 ( I11i1 , iIi1ii1I1 )
elif OO0ooo0oOO == 900 : iIIIiiI1i1i ( )
elif OO0ooo0oOO == 901 : oooooo0OO ( )
elif OO0ooo0oOO == 902 : iII1ii1 ( )
elif OO0ooo0oOO == 999 : quit ( )
if 59 - 59: OoOO0ooOOoo0O
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )