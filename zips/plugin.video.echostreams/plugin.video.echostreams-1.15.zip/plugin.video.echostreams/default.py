import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64
from resources . lib . modules import checker
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' , OO0o ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( II1 , 'controls.txt' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'hd.txt' ) )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
IiiIII111iI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
IiII = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
iI1Ii11111iIi = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
i1i1II = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI=' )
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( ) :
 if 43 - 43: O0OOo . II1Iiii1111i
 i1IIi11111i = OOOo0 + '|SPLIT|' + oO00oOo
 checker . check ( i1IIi11111i )
 if 74 - 74: Oo0o00o0Oo0 * ii11
 I1I1i1 ( "[COLOR white]Welcome to ECHO Streams[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 IiI1i ( "################################################################" , o0O , 6 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "[COLOR white]Meet the team:[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "[COLOR white]ECHO Coder: @EchoCoder(Twitter)[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "[COLOR white]ECHO Blue: @Blue_Builds(Twitter)[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 IiI1i ( "[COLOR dodgerblue][B]ENTER ADDON[/B][/COLOR]" , o0O , 1 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 if not os . path . exists ( O00ooooo00 ) :
  IiI1i ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  IiI1i ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
  if 61 - 61: oo0O000OoO + IiiIIiiI11 / oooOOOOO * i1iiIII111ii
 i1iIIi1 = ii11iIi1I ( )
 if 6 - 6: o00ooo0 * oo0O000OoO
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 67 - 67: i1iiIII111ii - O0OOo * o00 % o00 % Oo0o00o0Oo0 * o00ooo0
def i1IIiiiii ( ) :
 if 55 - 55: iIIIiiIIiiiIi
 IiI1i ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 70 - 70: I1i1iI1i . I1i1iI1i - I1i1iI1i / Oo0oO0ooo * II1Iiii1111i
 if os . path . exists ( I1IiiI ) :
  I1I1i1 ( '[COLOR white]Only Display HD Links - [COLOR lime][B]ON[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 else : I1I1i1 ( '[COLOR white]Only Display HD Links - [COLOR red][B]OFF[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( '[COLOR darkgray]############################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 OoO000 = IIiiIiI1 ( o0O )
 OoO000 = OoO000 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 iiIiIIi = re . compile ( '<item>(.+?)</item>' ) . findall ( OoO000 )
 for ooOoo0O in iiIiIIi :
  OooO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( ooOoo0O ) [ 0 ]
  II11iiii1Ii = re . compile ( '<folder>(.+?)</folder>' ) . findall ( ooOoo0O ) [ 0 ]
  OO0oOoo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( ooOoo0O ) [ 0 ]
  O0o0Oo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( ooOoo0O ) [ 0 ]
  if 78 - 78: o0 - ii11 * I1i1iI1i + o00 + oo0O000OoO + oo0O000OoO
  IiI1i ( '[COLOR white]' + OooO0 + '[/COLOR]' , II11iiii1Ii , 2 , OO0oOoo , O0o0Oo )
  if 11 - 11: oo0O000OoO - I1i1iI1i % i1iiIII111ii % oo0O000OoO / o00ooo0 - I1i1iI1i
 i1iIIi1 = ii11iIi1I ( )
 if 74 - 74: oo0O000OoO * i1
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 89 - 89: O0OOo + Oo0ooO0oo0oO
def Ii1I ( name , url , iconimage ) :
 if 89 - 89: i11iIiiIii / i1 * o00ooo0 % II1Iiii1111i % O0OOo
 Ii1 = name
 if 31 - 31: o00 + Oo0o00o0Oo0 + Oo0o00o0Oo0 / Oo
 if "adult" in name . lower ( ) :
  iiI1 ( )
 i11Iiii = [ ]
 if 23 - 23: o00 . Oo
 if not "search" in name . lower ( ) :
  OoO000 = IIiiIiI1 ( url )
  Oo0O0OOOoo = re . compile ( '<term>(.+?)</term>' ) . findall ( OoO000 )
  for oOoOooOo0o0 in Oo0O0OOOoo :
   oOoOooOo0o0 = oOoOooOo0o0 . replace ( ' ' , '' )
   oOoOooOo0o0 = oOoOooOo0o0 . lower ( )
   i11Iiii . append ( oOoOooOo0o0 )
 else :
  oOoOooOo0o0 = url
  oOoOooOo0o0 = oOoOooOo0o0 . replace ( ' ' , '' )
  oOoOooOo0o0 = oOoOooOo0o0 . lower ( )
  i11Iiii . append ( url . lower ( ) )
  if 61 - 61: o00 / I1i1iI1i + i1iiIII111ii * O0OOo / O0OOo
 I11i11Ii . create ( Oo0Ooo , "[COLOR white]We are just getting the channel links for you.[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
 I11i11Ii . update ( 0 )
 if 75 - 75: iIIIiiIIiiiIi / i1oOo0OoO - i1 / o00ooo0 . Oo - iIIIiiIIiiiIi
 O000OO0 = [ ]
 I11iii1Ii = [ ]
 I1IIiiIiii = [ ]
 O000oo0O = [ ]
 I11i11Ii . update ( 0 )
 if 66 - 66: Oo0oO0ooo / o00ooo0 - o0OO0 . II1Iiii1111i / o0OO0 * II1Iiii1111i
 IIIii1II1II = 0
 OoO000 = IIiiIiI1 ( IiiIII111iI )
 Oo0O0OOOoo = re . compile ( '<link>(.+?)</link>' ) . findall ( OoO000 )
 i1I1iI = len ( Oo0O0OOOoo )
 if 93 - 93: o0 % O0OOo * iIIIiiIIiiiIi
 Ii11Ii1I = IIiiIiI1 ( iI1Ii11111iIi )
 Ii11Ii1I = Ii11Ii1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( Ii11Ii1I )
 I11i1I1I = IIiiIiI1 ( i1i1II )
 I11i1I1I = I11i1I1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oO0Oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I11i1I1I )
 if 54 - 54: o00 - o0OO0 + i1oOo0OoO
 O0o0 = 0
 for oOoOooOo0o0 in oO0Oo :
  OO00Oo = re . compile ( '<cat>(.+?)</cat>' ) . findall ( oOoOooOo0o0 ) [ 0 ]
  if OO00Oo . lower ( ) in Ii1 . lower ( ) :
   O0OOO0OOoO0O = OO00Oo
   O0o0 = 1
 if O0o0 == 0 : O0OOO0OOoO0O = "null"
 if 70 - 70: IiiIIiiI11 * Oo0ooO0oo0oO * Oo0o00o0Oo0 / ii11
 IIIii1II1II = 0
 oO = IIiiIiI1 ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 iiIiIIi = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( oO )
 if 93 - 93: I1i1iI1i % O0OOo . I1i1iI1i * oooOOOOO % ii11 . Oo
 if 38 - 38: o00
 Oo0O = len ( iiIiIIi )
 if 25 - 25: o00ooo0 . Oo / oo0O000OoO . II1Iiii1111i * I1i1iI1i . o0OO0
 Oo0oOOo = i1I1iI + Oo0O
 for ooOoo0O in iiIiIIi :
  IIIii1II1II = IIIii1II1II + 1
  Oo0OoO00oOO0o = 100 * int ( IIIii1II1II ) / int ( Oo0oOOo )
  I11i11Ii . update ( Oo0OoO00oOO0o , '' , '[COLOR blue]Searching list ' + str ( IIIii1II1II ) + ' of ' + str ( Oo0oOOo ) + '[/COLOR]' )
  ooOoo0O = ooOoo0O . replace ( '<br />' , '\n' )
  OOO00O = ooOoo0O
  OOO00O = OOO00O . replace ( '#AAASTREAM:' , '#A:' )
  OOO00O = OOO00O . replace ( '#EXTINF:' , '#A:' )
  OOoOO0oo0ooO = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( OOO00O )
  O0o0O00Oo0o0 = [ ]
  for O00O0oOO00O00 , i1Oo00 , url in OOoOO0oo0ooO :
   i1i = { "params" : O00O0oOO00O00 , "display_name" : i1Oo00 , "url" : url }
   O0o0O00Oo0o0 . append ( i1i )
  iiI111I1iIiI = [ ]
  for II in O0o0O00Oo0o0 :
   i1i = { "display_name" : II [ "display_name" ] , "url" : II [ "url" ] }
   OOoOO0oo0ooO = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II [ "params" ] )
   for Ii1I1IIii1II , O0 in OOoOO0oo0ooO :
    i1i [ Ii1I1IIii1II . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0 . strip ( )
   iiI111I1iIiI . append ( i1i )
   if 25 - 25: Oo0oO0ooo
  for II in iiI111I1iIiI :
   name = Ii1i ( II [ "display_name" ] )
   url = Ii1i ( II [ "url" ] )
   url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if 15 - 15: IiiIIiiI11 . o0 . i1oOo0OoO / i11iIiiIii - ii11 . iIIIiiIIiiiIi
   O000OO0 . append ( name )
   I11iii1Ii . append ( url )
   O000oo0O = list ( zip ( O000OO0 , I11iii1Ii ) )
   if 33 - 33: Oo0o00o0Oo0 . o00
 for oOoO0o00OO0 in Oo0O0OOOoo :
  IIIii1II1II = IIIii1II1II + 1
  Oo0OoO00oOO0o = 100 * int ( IIIii1II1II ) / int ( Oo0oOOo )
  I11i11Ii . update ( Oo0OoO00oOO0o , '' , '[COLOR blue]Searching list ' + str ( IIIii1II1II ) + ' of ' + str ( Oo0oOOo ) + '[/COLOR]' )
  OOO00O = IIiiIiI1 ( oOoO0o00OO0 )
  OOO00O = OOO00O . replace ( '#AAASTREAM:' , '#A:' )
  OOO00O = OOO00O . replace ( '#EXTINF:' , '#A:' )
  OOoOO0oo0ooO = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( OOO00O )
  O0o0O00Oo0o0 = [ ]
  for O00O0oOO00O00 , i1Oo00 , url in OOoOO0oo0ooO :
   i1i = { "params" : O00O0oOO00O00 , "display_name" : i1Oo00 , "url" : url }
   O0o0O00Oo0o0 . append ( i1i )
  iiI111I1iIiI = [ ]
  for II in O0o0O00Oo0o0 :
   i1i = { "display_name" : II [ "display_name" ] , "url" : II [ "url" ] }
   OOoOO0oo0ooO = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II [ "params" ] )
   for Ii1I1IIii1II , O0 in OOoOO0oo0ooO :
    i1i [ Ii1I1IIii1II . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0 . strip ( )
   iiI111I1iIiI . append ( i1i )
   if 7 - 7: II1Iiii1111i + oooOOOOO + i1
  for II in iiI111I1iIiI :
   name = Ii1i ( II [ "display_name" ] )
   url = Ii1i ( II [ "url" ] )
   url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if 9 - 9: Oo . o00 - i1iiIII111ii / o00
   O000OO0 . append ( name )
   I11iii1Ii . append ( url )
   O000oo0O = list ( zip ( O000OO0 , I11iii1Ii ) )
   if 46 - 46: Oo0o00o0Oo0 . II1Iiii1111i * Oo0o00o0Oo0 % iIIIiiIIiiiIi
 iIIiII = sorted ( O000oo0O )
 ii1ii11IIIiiI = sorted ( i11Iiii )
 if 67 - 67: Oo0o00o0Oo0 * O0OOo * Oo0oO0ooo + II1Iiii1111i / iIIIiiIIiiiIi
 I1I111 = IIiiIiI1 ( IiII )
 I1I111 = I1I111 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 iiIiIIi = re . compile ( '<item>(.+?)</item>' ) . findall ( I1I111 )
 if 82 - 82: i11iIiiIii - oo0O000OoO * i1oOo0OoO / Oo0o00o0Oo0
 i1oOo = [ ]
 oOO00Oo = [ ]
 i1iIIIi1i = [ ]
 iI1iIIiiii = 0
 I11i11Ii . update ( 100 , '' , '[COLOR blue]Filtering results.[/COLOR]' )
 if 26 - 26: Oo0o00o0Oo0 . i1oOo0OoO
 if O0OOO0OOoO0O != 'null' :
  if 39 - 39: oo0O000OoO - i1 % i11iIiiIii * oooOOOOO . IiiIIiiI11
  OOooo0O00o = re . compile ( '<cat>' + re . escape ( O0OOO0OOoO0O ) + '</cat>(.+?)</item>' , re . DOTALL ) . findall ( I11i1I1I ) [ 0 ]
  if 85 - 85: o00 - Oo0ooO0oo0oO
  Oo0O0OOOoo = re . compile ( '<name>(.+?)</name>' ) . findall ( OOooo0O00o )
  if 32 - 32: i1oOo0OoO / o0 - o00
  for o00oooO0Oo in ii1ii11IIIiiI :
   for name , url in iIIiII :
    o0O0OOO0Ooo = name . replace ( ' ' , '' )
    if 45 - 45: i1 / o00
    if o00oooO0Oo . lower ( ) in o0O0OOO0Ooo . lower ( ) :
     if url not in str ( oOO00Oo ) :
      if 32 - 32: oo0O000OoO . IiiIIiiI11 . IiiIIiiI11
      for OO00O0O in Oo0O0OOOoo :
       if OO00O0O in name . lower ( ) :
        iI1iIIiiii = 1
      if iI1iIIiiii == 0 :
       for ooOoo0O in iiIiIIi :
        iii = re . compile ( '<old>(.+?)</old>' ) . findall ( ooOoo0O ) [ 0 ]
        oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( ooOoo0O ) [ 0 ]
        if oOooOOOoOo . lower ( ) == "null" : oOooOOOoOo = ""
        name = name . lower ( )
        iii = iii . lower ( )
        oOooOOOoOo = oOooOOOoOo . lower ( )
        name = name . replace ( iii , oOooOOOoOo )
       for i1Iii1i1I in O00oO :
        iii = re . compile ( '<old>(.+?)</old>' ) . findall ( i1Iii1i1I ) [ 0 ]
        oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( i1Iii1i1I ) [ 0 ]
        name = name . lower ( )
        iii = iii . lower ( )
        oOooOOOoOo = oOooOOOoOo . lower ( )
        name = name . replace ( iii , oOooOOOoOo )
        name = name . lstrip ( ' ' )
       i1oOo . append ( name )
       oOO00Oo . append ( url )
       i1iIIIi1i = list ( zip ( i1oOo , oOO00Oo ) )
      iI1iIIiiii = 0
 else :
  for o00oooO0Oo in ii1ii11IIIiiI :
   for name , url in iIIiII :
    o0O0OOO0Ooo = name . replace ( ' ' , '' )
    if 91 - 91: Oo0oO0ooo + o0OO0 . II1Iiii1111i * Oo0oO0ooo + o0OO0 * Oo0ooO0oo0oO
    if o00oooO0Oo . lower ( ) in o0O0OOO0Ooo . lower ( ) :
     if url not in str ( oOO00Oo ) :
      if 80 - 80: oo0O000OoO % II1Iiii1111i % O0OOo - Oo0ooO0oo0oO + Oo0ooO0oo0oO
      for ooOoo0O in iiIiIIi :
       iii = re . compile ( '<old>(.+?)</old>' ) . findall ( ooOoo0O ) [ 0 ]
       oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( ooOoo0O ) [ 0 ]
       if oOooOOOoOo . lower ( ) == "null" : oOooOOOoOo = ""
       name = name . replace ( iii , oOooOOOoOo )
      for i1Iii1i1I in O00oO :
       iii = re . compile ( '<old>(.+?)</old>' ) . findall ( i1Iii1i1I ) [ 0 ]
       oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( i1Iii1i1I ) [ 0 ]
       name = name . replace ( iii , oOooOOOoOo )
      name = name . lstrip ( ' ' )
      i1oOo . append ( name )
      oOO00Oo . append ( url )
      i1iIIIi1i = list ( zip ( i1oOo , oOO00Oo ) )
      if 19 - 19: o00ooo0 * iIIIiiIIiiiIi
      if 14 - 14: oo0O000OoO
 I1iI1iIi111i = sorted ( i1iIIIi1i )
 if 44 - 44: iIIIiiIIiiiIi % Oo + Oo0o00o0Oo0
 I11i11Ii . update ( 100 , '' , '[COLOR blue]Creating the list of results.[/COLOR]' )
 if 45 - 45: oo0O000OoO / oo0O000OoO + oooOOOOO + i1iiIII111ii
 for name , url in I1iI1iIi111i :
  if 47 - 47: o00 + i1iiIII111ii
  OoO = name . title ( ) + '|SPLIT|' + url
  if 88 - 88: oo0O000OoO . Oo * Oo % oooOOOOO
  if os . path . exists ( I1IiiI ) :
   if "hd" in name . lower ( ) :
    name = name . lower ( )
    name = name . replace ( 'hd' , '' )
    I1I1i1 ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , OoO , 3 , iiiii , O0O0OO0O0O0 )
  else :
   if "hd" in name . lower ( ) :
    name = name . lower ( )
    name = name . replace ( 'hd' , '' )
    I1I1i1 ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , OoO , 3 , iiiii , O0O0OO0O0O0 )
   else :
    I1I1i1 ( '[COLOR white]' + name . title ( ) + '[/COLOR]' , OoO , 3 , iiiii , O0O0OO0O0O0 )
    if 15 - 15: iIIIiiIIiiiIi * o0OO0 + i11iIiiIii
 if I11i11Ii . iscanceled ( ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The process was cancelled.' )
  I11i11Ii . close ( )
  quit ( )
 I11i11Ii . close ( )
 if 6 - 6: i1iiIII111ii / i11iIiiIii + oo0O000OoO * O0OOo
 i1iIIi1 = ii11iIi1I ( )
 if 80 - 80: Oo
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 83 - 83: Oo0o00o0Oo0 . i11iIiiIii + Oo . o00 * Oo0o00o0Oo0
def oooO0 ( ) :
 if 46 - 46: oooOOOOO
 O00oO = ''
 oooOOoOO = xbmc . Keyboard ( O00oO , 'Enter Search Term' )
 oooOOoOO . doModal ( )
 if oooOOoOO . isConfirmed ( ) :
  O00oO = oooOOoOO . getText ( )
  if len ( O00oO ) > 1 :
   if not O00oO == base64 . b64decode ( 'Z2VuZXJhdGVpbmk=' ) :
    IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, incorrect password." )
    quit ( )
  else : quit ( )
  if 9 - 9: o00 . i1iiIII111ii - Oo0ooO0oo0oO - O0OOo + Oo * i11iIiiIii
 OoO000 = IIiiIiI1 ( IiiIII111iI )
 Oo0O0OOOoo = re . compile ( '<link>(.+?)</link>' ) . findall ( OoO000 )
 if 79 - 79: O0OOo % Oo0o00o0Oo0 % o0OO0
 for ooOoo0O in Oo0O0OOOoo :
  IiI1i ( ooOoo0O , ooOoo0O , 7 , iiiii , O0O0OO0O0O0 )
  if 5 - 5: i1oOo0OoO % o00ooo0 % O0OOo % oo0O000OoO
 i1iIIi1 = ii11iIi1I ( )
 if 7 - 7: Oo + i1oOo0OoO . oooOOOOO . i1iiIII111ii - o00
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 26 - 26: Oo0ooO0oo0oO / IiiIIiiI11 % o0 / IiiIIiiI11 + Oo0o00o0Oo0
def oOO0O00oO0Ooo ( url ) :
 if 67 - 67: I1i1iI1i - II1Iiii1111i
 Ii11Ii1I = IIiiIiI1 ( iI1Ii11111iIi )
 Ii11Ii1I = Ii11Ii1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( Ii11Ii1I )
 if 36 - 36: IiiIIiiI11
 I1I111 = IIiiIiI1 ( IiII )
 I1I111 = I1I111 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 iiIiIIi = re . compile ( '<item>(.+?)</item>' ) . findall ( I1I111 )
 if 36 - 36: i1iiIII111ii / i1 * Oo0ooO0oo0oO - II1Iiii1111i % o0 * O0OOo
 OOO00O = IIiiIiI1 ( url )
 OOO00O = OOO00O . replace ( '#AAASTREAM:' , '#A:' )
 OOO00O = OOO00O . replace ( '#EXTINF:' , '#A:' )
 OOoOO0oo0ooO = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( OOO00O )
 O0o0O00Oo0o0 = [ ]
 for O00O0oOO00O00 , i1Oo00 , url in OOoOO0oo0ooO :
  i1i = { "params" : O00O0oOO00O00 , "display_name" : i1Oo00 , "url" : url }
  O0o0O00Oo0o0 . append ( i1i )
 iiI111I1iIiI = [ ]
 for II in O0o0O00Oo0o0 :
  i1i = { "display_name" : II [ "display_name" ] , "url" : II [ "url" ] }
  OOoOO0oo0ooO = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( II [ "params" ] )
  for Ii1I1IIii1II , O0 in OOoOO0oo0ooO :
   i1i [ Ii1I1IIii1II . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0 . strip ( )
  iiI111I1iIiI . append ( i1i )
  if 79 - 79: i1
 for II in iiI111I1iIiI :
  OooO0 = Ii1i ( II [ "display_name" ] )
  url = Ii1i ( II [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if 78 - 78: Oo0oO0ooo + II1Iiii1111i - oooOOOOO
  for ooOoo0O in iiIiIIi :
   iii = re . compile ( '<old>(.+?)</old>' ) . findall ( ooOoo0O ) [ 0 ]
   oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( ooOoo0O ) [ 0 ]
   if oOooOOOoOo . lower ( ) == "null" : oOooOOOoOo = ""
   OooO0 = OooO0 . replace ( iii , oOooOOOoOo )
  for i1Iii1i1I in O00oO :
   iii = re . compile ( '<old>(.+?)</old>' ) . findall ( i1Iii1i1I ) [ 0 ]
   oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( i1Iii1i1I ) [ 0 ]
   OooO0 = OooO0 . replace ( iii , oOooOOOoOo )
  OooO0 = OooO0 . lstrip ( ' ' )
  if 38 - 38: o00 - O0OOo + o0 / o00ooo0 % Oo0ooO0oo0oO
  I1I1i1 ( OooO0 , url , 3 , iiiii , O0O0OO0O0O0 )
  if 57 - 57: I1i1iI1i / i1iiIII111ii
 i1iIIi1 = ii11iIi1I ( )
 if 29 - 29: o0 + o00ooo0 * I1i1iI1i * II1Iiii1111i . o0OO0 * o0OO0
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 7 - 7: IiiIIiiI11 * oooOOOOO % ii11 - o00
def i1ioOOoo00O00o ( ) :
 if 98 - 98: II1Iiii1111i + IiiIIiiI11 + O0OOo % i1oOo0OoO
 iiI1 ( )
 if 97 - 97: i1 * i1oOo0OoO . i1oOo0OoO
 O00oO = ''
 oooOOoOO = xbmc . Keyboard ( O00oO , 'Enter Search Term' )
 oooOOoOO . doModal ( )
 if oooOOoOO . isConfirmed ( ) :
  O00oO = oooOOoOO . getText ( )
  if len ( O00oO ) > 1 :
   II11iiii1Ii = O00oO
   Ii1I ( "search" , II11iiii1Ii , iiiii )
  else : quit ( )
  if 33 - 33: oooOOOOO + oo0O000OoO * O0OOo / o0 - o0OO0
def O0oO ( ) :
 if 73 - 73: Oo0oO0ooo * i11iIiiIii % O0OOo . Oo0oO0ooo
 if not os . path . exists ( ooo0OO ) :
  try :
   os . makedirs ( ooo0OO )
  except : pass
 if os . path . exists ( I1IiiI ) :
  try :
   os . remove ( I1IiiI )
  except : pass
 else :
  try :
   open ( I1IiiI , 'w' )
  except : pass
  if 66 - 66: O0OOo + O0OOo + i1iiIII111ii / oo0O000OoO + II1Iiii1111i
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 30 - 30: i1
def iiI1 ( ) :
 if 44 - 44: O0OOo / Oo0o00o0Oo0 / Oo0o00o0Oo0
 if os . path . exists ( O00ooooo00 ) :
  OOO = iiiiI ( heading = "Please Enter Your Password" )
  if ( not OOO ) :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  oooOo0OOOoo0 = OOO
  if 51 - 51: Oo0ooO0oo0oO / o00ooo0 . II1Iiii1111i * o00 + I1i1iI1i * IiiIIiiI11
  OOOoOo = open ( O00ooooo00 , "r" )
  O00o0 = re . compile ( r'<password>(.+?)</password>' )
  for I11iII in OOOoOo :
   file = O00o0 . findall ( I11iII )
   for iIIII in file :
    I11 = base64 . b64decode ( iIIII )
    if not I11 == oooOo0OOOoo0 :
     if not iIIII == oooOo0OOOoo0 :
      IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 30 - 30: o00 % Oo % oo0O000OoO
def II111iI111I1I ( ) :
 if 18 - 18: oo0O000OoO - II1Iiii1111i . oooOOOOO . o0
 iiI1 ( )
 if 2 - 2: II1Iiii1111i . I1i1iI1i
 O0o0 = 0
 if not os . path . exists ( O00ooooo00 ) :
  O0o0 = 1
  I1I1i1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  I1I1i1 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  OOOoOo = open ( O00ooooo00 , "r" )
  O00o0 = re . compile ( r'<password>(.+?)</password>' )
  for I11iII in OOOoOo :
   file = O00o0 . findall ( I11iII )
   for iIIII in file :
    I11 = base64 . b64decode ( iIIII )
    O0o0 = 1
    I1I1i1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    I1I1i1 ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( I11 ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    I1I1i1 ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    I1I1i1 ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 78 - 78: Oo0o00o0Oo0 * o0 . o0OO0 / o00 - i1oOo0OoO / oooOOOOO
 if O0o0 == 0 :
  I1I1i1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  I1I1i1 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 35 - 35: Oo0o00o0Oo0 % II1Iiii1111i - O0OOo
 i1iIIi1 = ii11iIi1I ( )
 if 20 - 20: iIIIiiIIiiiIi - i1iiIII111ii
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 30 - 30: Oo0o00o0Oo0 / o0OO0
def Iii1I1111ii ( ) :
 if 72 - 72: Oo + iIIIiiIIiiiIi + o00
 OOO = iiiiI ( heading = "Please Set Password" )
 if ( not OOO ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 oooOo0OOOoo0 = OOO
 if 94 - 94: O0OOo . iIIIiiIIiiiIi - o00 % i1 - I1i1iI1i
 OOO = iiiiI ( heading = "Please Confirm Your Password" )
 if ( not OOO ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 ooO0O00Oo0o = OOO
 if 65 - 65: Oo0oO0ooo . Oo0o00o0Oo0 - oooOOOOO * IiiIIiiI11 / oooOOOOO / i1iiIII111ii
 if not os . path . exists ( O00ooooo00 ) :
  if not os . path . exists ( II1 ) :
   os . makedirs ( II1 )
  open ( O00ooooo00 , 'w' )
  if 40 - 40: i1iiIII111ii * IiiIIiiI11 * i11iIiiIii
  if oooOo0OOOoo0 == ooO0O00Oo0o :
   oo0OO00OoooOo = base64 . b64encode ( oooOo0OOOoo0 )
   II1i111Ii1i = open ( O00ooooo00 , 'w' )
   II1i111Ii1i . write ( '<password>' + str ( oo0OO00OoooOo ) + '</password>' )
   II1i111Ii1i . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( O00ooooo00 )
  if 15 - 15: Oo / iIIIiiIIiiiIi
  if oooOo0OOOoo0 == ooO0O00Oo0o :
   oo0OO00OoooOo = base64 . b64encode ( oooOo0OOOoo0 )
   II1i111Ii1i = open ( O00ooooo00 , 'w' )
   II1i111Ii1i . write ( '<password>' + str ( oo0OO00OoooOo ) + '</password>' )
   II1i111Ii1i . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 76 - 76: Oo0o00o0Oo0 / II1Iiii1111i . i1 % o0OO0 . o00 + IiiIIiiI11
def o0o ( ) :
 if 62 - 62: i1oOo0OoO . Oo0o00o0Oo0
 try :
  os . remove ( O00ooooo00 )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 61 - 61: o00ooo0 - II1Iiii1111i - iIIIiiIIiiiIi
def ii11iIi1I ( ) :
 if 25 - 25: i1 * Oo0o00o0Oo0 + Oo0oO0ooo . o00 . o00
 oOooO = xbmc . getInfoLabel ( "System.BuildVersion" )
 IIIIiI11I11 = float ( oOooO [ : 4 ] )
 if IIIIiI11I11 >= 11.0 and IIIIiI11I11 <= 11.9 :
  oo00o0 = 'Eden'
 elif IIIIiI11I11 >= 12.0 and IIIIiI11I11 <= 12.9 :
  oo00o0 = 'Frodo'
 elif IIIIiI11I11 >= 13.0 and IIIIiI11I11 <= 13.9 :
  oo00o0 = 'Gotham'
 elif IIIIiI11I11 >= 14.0 and IIIIiI11I11 <= 14.9 :
  oo00o0 = 'Helix'
 elif IIIIiI11I11 >= 15.0 and IIIIiI11I11 <= 15.9 :
  oo00o0 = 'Isengard'
 elif IIIIiI11I11 >= 16.0 and IIIIiI11I11 <= 16.9 :
  oo00o0 = 'Jarvis'
 elif IIIIiI11I11 >= 17.0 and IIIIiI11I11 <= 17.9 :
  oo00o0 = 'Krypton'
 else : oo00o0 = "Decline"
 if 4 - 4: ii11 % O0OOo * I1i1iI1i
 return oo00o0
 if 100 - 100: oooOOOOO * II1Iiii1111i + II1Iiii1111i
def OoOO0o ( name , url , iconimage ) :
 if 1 - 1: Oo
 try :
  name , url = url . split ( '|SPLIT|' )
 except : pass
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 68 - 68: oo0O000OoO - o0OO0 / oooOOOOO / Oo0o00o0Oo0
 I11iiii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , I11iiii , False )
 if 60 - 60: Oo0o00o0Oo0 . iIIIiiIIiiiIi + IiiIIiiI11 / o00 . Oo
def Ii1i ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 82 - 82: Oo0oO0ooo / o0OO0 % o0 / iIIIiiIIiiiIi - o0OO0
def IIiiIiI1 ( url ) :
 if 7 - 7: oooOOOOO * I1i1iI1i - i1iiIII111ii + II1Iiii1111i * o0OO0 % I1i1iI1i
 iI1i111I1Ii = urllib2 . Request ( url )
 iI1i111I1Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 OOO00O = urllib2 . urlopen ( iI1i111I1Ii )
 OoO000 = OOO00O . read ( )
 OOO00O . close ( )
 return OoO000
 if 25 - 25: oooOOOOO - oo0O000OoO
def iiiiI ( default = "" , heading = "" , hidden = False ) :
 oooOOoOO = xbmc . Keyboard ( default , heading , hidden )
 if 10 - 10: Oo / O0OOo % i1oOo0OoO * Oo0o00o0Oo0 % Oo0oO0ooo
 oooOOoOO . doModal ( )
 if ( oooOOoOO . isConfirmed ( ) ) :
  return unicode ( oooOOoOO . getText ( ) , "utf-8" )
 return default
 if 48 - 48: i1iiIII111ii / oooOOOOO . o0 * o00ooo0 * O0OOo / iIIIiiIIiiiIi
def IiI1i ( name , url , mode , iconimage , fanartimage ) :
 if 92 - 92: Oo0ooO0oo0oO % Oo0ooO0oo0oO - o00 / o00ooo0
 I11IIIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 iIIiiI1II1i11 = True
 I11iiii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 I11iiii . setProperty ( "fanart_Image" , fanartimage )
 I11iiii . setProperty ( "icon_Image" , iconimage )
 iIIiiI1II1i11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11IIIi , listitem = I11iiii , isFolder = True )
 return iIIiiI1II1i11
 if 65 - 65: ii11 / Oo0o00o0Oo0 / o00ooo0
def I1I1i1 ( name , url , mode , iconimage , fanartimage ) :
 if 92 - 92: i1 - oo0O000OoO . II1Iiii1111i * ii11
 I11IIIi = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 iIIiiI1II1i11 = True
 I11iiii = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 I11iiii . setProperty ( "fanart_Image" , fanartimage )
 I11iiii . setProperty ( "icon_Image" , iconimage )
 iIIiiI1II1i11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I11IIIi , listitem = I11iiii , isFolder = False )
 return iIIiiI1II1i11
 if 42 - 42: Oo0o00o0Oo0 / o00 . O0OOo + O0OOo % o00ooo0 + i11iIiiIii
def oo0o0000 ( ) :
 iiI = [ ]
 oOOO0o = sys . argv [ 2 ]
 if len ( oOOO0o ) >= 2 :
  O00O0oOO00O00 = sys . argv [ 2 ]
  O00oOOooo = O00O0oOO00O00 . replace ( '?' , '' )
  if ( O00O0oOO00O00 [ len ( O00O0oOO00O00 ) - 1 ] == '/' ) :
   O00O0oOO00O00 = O00O0oOO00O00 [ 0 : len ( O00O0oOO00O00 ) - 2 ]
  iI1iIii11Ii = O00oOOooo . split ( '&' )
  iiI = { }
  for IIIii1II1II in range ( len ( iI1iIii11Ii ) ) :
   IIi1i1I11Iii = { }
   IIi1i1I11Iii = iI1iIii11Ii [ IIIii1II1II ] . split ( '=' )
   if ( len ( IIi1i1I11Iii ) ) == 2 :
    iiI [ IIi1i1I11Iii [ 0 ] ] = IIi1i1I11Iii [ 1 ]
    if 25 - 25: IiiIIiiI11 + ii11 / i1iiIII111ii . o00 % i1 * I1i1iI1i
 return iiI
 if 84 - 84: i1iiIII111ii % ii11 + i11iIiiIii
O00O0oOO00O00 = oo0o0000 ( ) ; OooO0 = None ; II11iiii1Ii = None ; II1I1Ii = None ; OO0oOoo = None ; Ooo0O0oooo = None
try : OooO0 = urllib . unquote_plus ( O00O0oOO00O00 [ "name" ] )
except : pass
try : II11iiii1Ii = urllib . unquote_plus ( O00O0oOO00O00 [ "url" ] )
except : pass
try : II1I1Ii = int ( O00O0oOO00O00 [ "mode" ] )
except : pass
try : OO0oOoo = urllib . unquote_plus ( O00O0oOO00O00 [ "iconimage" ] )
except : pass
try : Ooo0O0oooo = urllib . quote_plus ( O00O0oOO00O00 [ "fanartimage" ] )
except : pass
if 36 - 36: i1oOo0OoO . I1i1iI1i
if II1I1Ii == None or II11iiii1Ii == None or len ( II11iiii1Ii ) < 1 : i1IIiiiii ( )
elif II1I1Ii == 1 : i1IIiiiii ( )
elif II1I1Ii == 2 : Ii1I ( OooO0 , II11iiii1Ii , OO0oOoo )
elif II1I1Ii == 3 : OoOO0o ( OooO0 , II11iiii1Ii , OO0oOoo )
elif II1I1Ii == 4 : i1ioOOoo00O00o ( )
elif II1I1Ii == 5 : O0oO ( )
elif II1I1Ii == 6 : oooO0 ( )
elif II1I1Ii == 7 : oOO0O00oO0Ooo ( II11iiii1Ii )
elif II1I1Ii == 900 : II111iI111I1I ( )
elif II1I1Ii == 901 : Iii1I1111ii ( )
elif II1I1Ii == 902 : o0o ( )
elif II1I1Ii == 999 : quit ( )
if 56 - 56: Oo0ooO0oo0oO . Oo0oO0ooo . o0OO0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )