import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64
from resources . lib . modules import checker
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' , OO0o ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( II1 , 'controls.txt' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'hd.txt' ) )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
IiiIII111iI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
IiII = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
iI1Ii11111iIi = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
i1i1II = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI=' )
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( ) :
 if 43 - 43: O0OOo . II1Iiii1111i
 i1IIi11111i = OOOo0 + '|SPLIT|' + oO00oOo
 checker . check ( i1IIi11111i )
 if 74 - 74: Oo0o00o0Oo0 * ii11
 I1I1i1 ( "[COLOR white]Welcome to ECHO Streams[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 IiI1i ( "################################################################" , o0O , 6 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "[COLOR white]Meet the team:[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "[COLOR white]ECHO Coder: @EchoCoder(Twitter)[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "[COLOR white]ECHO Blue: @Blue_Builds(Twitter)[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 IiI1i ( "[COLOR dodgerblue][B]ENTER ADDON[/B][/COLOR]" , o0O , 1 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 if not os . path . exists ( O00ooooo00 ) :
  IiI1i ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  IiI1i ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
  if 61 - 61: oo0O000OoO + IiiIIiiI11 / oooOOOOO * i1iiIII111ii
 i1iIIi1 = ii11iIi1I ( )
 if 6 - 6: o00ooo0 * oo0O000OoO
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 67 - 67: i1iiIII111ii - O0OOo * o00 % o00 % Oo0o00o0Oo0 * o00ooo0
def i1IIiiiii ( ) :
 if 55 - 55: iIIIiiIIiiiIi
 IiI1i ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 70 - 70: I1i1iI1i . I1i1iI1i - I1i1iI1i / Oo0oO0ooo * II1Iiii1111i
 if os . path . exists ( I1IiiI ) :
  I1I1i1 ( '[COLOR white]Only Display HD Links - [COLOR lime][B]ON[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 else : I1I1i1 ( '[COLOR white]Only Display HD Links - [COLOR red][B]OFF[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 I1I1i1 ( '[COLOR darkgray]############################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 OoO000 = IIiiIiI1 ( o0O )
 OoO000 = OoO000 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 iiIiIIi = re . compile ( '<item>(.+?)</item>' ) . findall ( OoO000 )
 for ooOoo0O in iiIiIIi :
  OooO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( ooOoo0O ) [ 0 ]
  II11iiii1Ii = re . compile ( '<folder>(.+?)</folder>' ) . findall ( ooOoo0O ) [ 0 ]
  OO0oOoo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( ooOoo0O ) [ 0 ]
  O0o0Oo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( ooOoo0O ) [ 0 ]
  if 78 - 78: o0 - ii11 * I1i1iI1i + o00 + oo0O000OoO + oo0O000OoO
  IiI1i ( '[COLOR white]' + OooO0 + '[/COLOR]' , II11iiii1Ii , 2 , OO0oOoo , O0o0Oo )
  if 11 - 11: oo0O000OoO - I1i1iI1i % i1iiIII111ii % oo0O000OoO / o00ooo0 - I1i1iI1i
 i1iIIi1 = ii11iIi1I ( )
 if 74 - 74: oo0O000OoO * i1
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 89 - 89: O0OOo + Oo0ooO0oo0oO
def Ii1I ( name , url , iconimage ) :
 if 89 - 89: i11iIiiIii / i1 * o00ooo0 % II1Iiii1111i % O0OOo
 Ii1 = name
 if 31 - 31: o00 + Oo0o00o0Oo0 + Oo0o00o0Oo0 / Oo
 if "adult" in name . lower ( ) :
  iiI1 ( )
 i11Iiii = [ ]
 if 23 - 23: o00 . Oo
 if not "search" in name . lower ( ) :
  OoO000 = IIiiIiI1 ( url )
  Oo0O0OOOoo = re . compile ( '<term>(.+?)</term>' ) . findall ( OoO000 )
  for oOoOooOo0o0 in Oo0O0OOOoo :
   oOoOooOo0o0 = oOoOooOo0o0 . replace ( ' ' , '' )
   oOoOooOo0o0 = oOoOooOo0o0 . lower ( )
   i11Iiii . append ( oOoOooOo0o0 )
 else :
  oOoOooOo0o0 = url
  oOoOooOo0o0 = oOoOooOo0o0 . replace ( ' ' , '' )
  oOoOooOo0o0 = oOoOooOo0o0 . lower ( )
  i11Iiii . append ( url . lower ( ) )
  if 61 - 61: o00 / I1i1iI1i + i1iiIII111ii * O0OOo / O0OOo
 I11i11Ii . create ( Oo0Ooo , "[COLOR white]We are just getting the channel links for you.[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
 I11i11Ii . update ( 0 )
 if 75 - 75: iIIIiiIIiiiIi / i1oOo0OoO - i1 / o00ooo0 . Oo - iIIIiiIIiiiIi
 O000OO0 = [ ]
 I11iii1Ii = [ ]
 I1IIiiIiii = [ ]
 O000oo0O = [ ]
 I11i11Ii . update ( 0 )
 if 66 - 66: Oo0oO0ooo / o00ooo0 - o0OO0 . II1Iiii1111i / o0OO0 * II1Iiii1111i
 IIIii1II1II = 0
 OoO000 = IIiiIiI1 ( IiiIII111iI )
 Oo0O0OOOoo = re . compile ( '<link>(.+?)</link>' ) . findall ( OoO000 )
 i1I1iI = len ( Oo0O0OOOoo )
 if 93 - 93: o0 % O0OOo * iIIIiiIIiiiIi
 Ii11Ii1I = IIiiIiI1 ( iI1Ii11111iIi )
 Ii11Ii1I = Ii11Ii1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O00oO = re . compile ( '<item>(.+?)</item>' ) . findall ( Ii11Ii1I )
 I11i1I1I = IIiiIiI1 ( i1i1II )
 I11i1I1I = I11i1I1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oO0Oo = re . compile ( '<item>(.+?)</item>' ) . findall ( I11i1I1I )
 if 54 - 54: o00 - o0OO0 + i1oOo0OoO
 O0o0 = 0
 for oOoOooOo0o0 in oO0Oo :
  OO00Oo = re . compile ( '<cat>(.+?)</cat>' ) . findall ( oOoOooOo0o0 ) [ 0 ]
  if OO00Oo . lower ( ) in Ii1 . lower ( ) :
   O0OOO0OOoO0O = OO00Oo
   O0o0 = 1
 if O0o0 == 0 : O0OOO0OOoO0O = "null"
 if 70 - 70: IiiIIiiI11 * Oo0ooO0oo0oO * Oo0o00o0Oo0 / ii11
 for oO in Oo0O0OOOoo :
  IIIii1II1II = IIIii1II1II + 1
  OOoO0O00o0 = 100 * int ( IIIii1II1II ) / int ( i1I1iI )
  I11i11Ii . update ( OOoO0O00o0 , '' , '[COLOR blue]Searching list ' + str ( IIIii1II1II ) + ' of ' + str ( i1I1iI ) + '[/COLOR]' )
  iII = IIiiIiI1 ( oO )
  iII = iII . replace ( '#AAASTREAM:' , '#A:' )
  iII = iII . replace ( '#EXTINF:' , '#A:' )
  o0ooOooo000oOO = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( iII )
  Oo0oOOo = [ ]
  for Oo0OoO00oOO0o , OOO00O , url in o0ooOooo000oOO :
   OOoOO0oo0ooO = { "params" : Oo0OoO00oOO0o , "display_name" : OOO00O , "url" : url }
   Oo0oOOo . append ( OOoOO0oo0ooO )
  O0o0O00Oo0o0 = [ ]
  for O00O0oOO00O00 in Oo0oOOo :
   OOoOO0oo0ooO = { "display_name" : O00O0oOO00O00 [ "display_name" ] , "url" : O00O0oOO00O00 [ "url" ] }
   o0ooOooo000oOO = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O00O0oOO00O00 [ "params" ] )
   for i1Oo00 , i1i in o0ooOooo000oOO :
    OOoOO0oo0ooO [ i1Oo00 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i1i . strip ( )
   O0o0O00Oo0o0 . append ( OOoOO0oo0ooO )
   if 50 - 50: IiiIIiiI11
  for O00O0oOO00O00 in O0o0O00Oo0o0 :
   name = i11I1iIiII ( O00O0oOO00O00 [ "display_name" ] )
   url = i11I1iIiII ( O00O0oOO00O00 [ "url" ] )
   url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if 96 - 96: Oo0ooO0oo0oO
   O000OO0 . append ( name )
   I11iii1Ii . append ( url )
   O000oo0O = list ( zip ( O000OO0 , I11iii1Ii ) )
   if 45 - 45: i1 * o00 % Oo0ooO0oo0oO * i1oOo0OoO + oo0O000OoO . o00ooo0
 Oo0ooOo0o = sorted ( O000oo0O )
 Ii1i1 = sorted ( i11Iiii )
 if 15 - 15: Oo
 Ii = IIiiIiI1 ( IiII )
 Ii = Ii . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 iiIiIIi = re . compile ( '<item>(.+?)</item>' ) . findall ( Ii )
 if 79 - 79: i1oOo0OoO / i1
 OO0OoO0o00 = [ ]
 ooOO0O0ooOooO = [ ]
 oOOOo00O00oOo = [ ]
 iiIIIi = 0
 I11i11Ii . update ( 100 , '' , '[COLOR blue]Filtering results.[/COLOR]' )
 if 93 - 93: oo0O000OoO
 if O0OOO0OOoO0O != 'null' :
  if 10 - 10: Oo0o00o0Oo0
  OOooOO000 = re . compile ( '<cat>' + re . escape ( O0OOO0OOoO0O ) + '</cat>(.+?)</item>' , re . DOTALL ) . findall ( I11i1I1I ) [ 0 ]
  if 97 - 97: Oo0oO0ooo + II1Iiii1111i / o0 / oo0O000OoO
  Oo0O0OOOoo = re . compile ( '<name>(.+?)</name>' ) . findall ( OOooOO000 )
  if 37 - 37: oo0O000OoO - i1iiIII111ii * O0OOo % i11iIiiIii - oooOOOOO
  for o0oO in Ii1i1 :
   for name , url in Oo0ooOo0o :
    IIiIi1iI = name . replace ( ' ' , '' )
    if 35 - 35: ii11 % i1 - i1
    if o0oO . lower ( ) in IIiIi1iI . lower ( ) :
     if url not in str ( ooOO0O0ooOooO ) :
      if 16 - 16: Oo % o00ooo0 - Oo + ii11
      for i1I1i in Oo0O0OOOoo :
       if i1I1i in name . lower ( ) :
        iiIIIi = 1
      if iiIIIi == 0 :
       for ooOoo0O in iiIiIIi :
        Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( ooOoo0O ) [ 0 ]
        I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( ooOoo0O ) [ 0 ]
        if I11i1ii1 . lower ( ) == "null" : I11i1ii1 = ""
        name = name . lower ( )
        Iiiii1i = Iiiii1i . lower ( )
        I11i1ii1 = I11i1ii1 . lower ( )
        name = name . replace ( Iiiii1i , I11i1ii1 )
       for O0Oooo0O in O00oO :
        Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( O0Oooo0O ) [ 0 ]
        I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( O0Oooo0O ) [ 0 ]
        name = name . lower ( )
        Iiiii1i = Iiiii1i . lower ( )
        I11i1ii1 = I11i1ii1 . lower ( )
        name = name . replace ( Iiiii1i , I11i1ii1 )
        name = name . lstrip ( ' ' )
       OO0OoO0o00 . append ( name )
       ooOO0O0ooOooO . append ( url )
       oOOOo00O00oOo = list ( zip ( OO0OoO0o00 , ooOO0O0ooOooO ) )
      iiIIIi = 0
 else :
  for o0oO in Ii1i1 :
   for name , url in Oo0ooOo0o :
    IIiIi1iI = name . replace ( ' ' , '' )
    if 84 - 84: oo0O000OoO . Oo0oO0ooo / Oo0ooO0oo0oO - o0OO0 / i1oOo0OoO / o00
    if o0oO . lower ( ) in IIiIi1iI . lower ( ) :
     if url not in str ( ooOO0O0ooOooO ) :
      if 12 - 12: o0OO0 * oo0O000OoO % iIIIiiIIiiiIi % o0
      for ooOoo0O in iiIiIIi :
       Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( ooOoo0O ) [ 0 ]
       I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( ooOoo0O ) [ 0 ]
       if I11i1ii1 . lower ( ) == "null" : I11i1ii1 = ""
       name = name . replace ( Iiiii1i , I11i1ii1 )
      for O0Oooo0O in O00oO :
       Iiiii1i = re . compile ( '<old>(.+?)</old>' ) . findall ( O0Oooo0O ) [ 0 ]
       I11i1ii1 = re . compile ( '<new>(.+?)</new>' ) . findall ( O0Oooo0O ) [ 0 ]
       name = name . replace ( Iiiii1i , I11i1ii1 )
      name = name . lstrip ( ' ' )
      OO0OoO0o00 . append ( name )
      ooOO0O0ooOooO . append ( url )
      oOOOo00O00oOo = list ( zip ( OO0OoO0o00 , ooOO0O0ooOooO ) )
      if 20 - 20: II1Iiii1111i % ii11 / ii11 + ii11
      if 45 - 45: O0OOo - IiiIIiiI11 - i1oOo0OoO - I1i1iI1i . Oo / i1
 oo0o00O = sorted ( oOOOo00O00oOo )
 if 51 - 51: ii11 - I1i1iI1i * oo0O000OoO
 I11i11Ii . update ( 100 , '' , '[COLOR blue]Creating the list of results.[/COLOR]' )
 if 66 - 66: i1oOo0OoO + i1
 for name , url in oo0o00O :
  if 11 - 11: Oo0o00o0Oo0 + i1oOo0OoO - I1i1iI1i / o00 + Oo0ooO0oo0oO . Oo
  i1Iii1i1I = name + '|SPLIT|' + url
  if 91 - 91: Oo0oO0ooo + o0OO0 . II1Iiii1111i * Oo0oO0ooo + o0OO0 * Oo0ooO0oo0oO
  if os . path . exists ( I1IiiI ) :
   if "hd" in name . lower ( ) :
    name = name . replace ( 'hd' , '' )
    I1I1i1 ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , i1Iii1i1I , 3 , iiiii , O0O0OO0O0O0 )
  else :
   if "hd" in name . lower ( ) :
    name = name . replace ( 'hd' , '' )
    I1I1i1 ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , i1Iii1i1I , 3 , iiiii , O0O0OO0O0O0 )
   else :
    I1I1i1 ( '[COLOR white]' + name . title ( ) + '[/COLOR]' , i1Iii1i1I , 3 , iiiii , O0O0OO0O0O0 )
    if 80 - 80: oo0O000OoO % II1Iiii1111i % O0OOo - Oo0ooO0oo0oO + Oo0ooO0oo0oO
 if I11i11Ii . iscanceled ( ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The download was cancelled.' )
  I11i11Ii . close ( )
  quit ( )
 I11i11Ii . close ( )
 if 19 - 19: o00ooo0 * iIIIiiIIiiiIi
 i1iIIi1 = ii11iIi1I ( )
 if 14 - 14: oo0O000OoO
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 11 - 11: IiiIIiiI11 * o0OO0 . o0 % i1oOo0OoO + oo0O000OoO
def OOO ( ) :
 if 68 - 68: Oo + Oo0o00o0Oo0
 O00oO = ''
 I1I1I = xbmc . Keyboard ( O00oO , 'Enter Search Term' )
 I1I1I . doModal ( )
 if I1I1I . isConfirmed ( ) :
  O00oO = I1I1I . getText ( )
  if len ( O00oO ) > 1 :
   if not O00oO == base64 . b64decode ( 'Z2VuZXJhdGVpbmk=' ) :
    IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, incorrect password." )
    quit ( )
  else : quit ( )
  if 95 - 95: Oo + o00 + oo0O000OoO * o0 % O0OOo / IiiIIiiI11
 OoO000 = IIiiIiI1 ( IiiIII111iI )
 Oo0O0OOOoo = re . compile ( '<link>(.+?)</link>' ) . findall ( OoO000 )
 if 56 - 56: oo0O000OoO
 for ooOoo0O in Oo0O0OOOoo :
  IiI1i ( ooOoo0O , ooOoo0O , 7 , iiiii , O0O0OO0O0O0 )
  if 86 - 86: Oo % oooOOOOO
 i1iIIi1 = ii11iIi1I ( )
 if 15 - 15: iIIIiiIIiiiIi * o0OO0 + i11iIiiIii
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 6 - 6: i1iiIII111ii / i11iIiiIii + oo0O000OoO * O0OOo
def o00o0 ( url ) :
 if 45 - 45: i1
 iII = IIiiIiI1 ( url )
 iII = iII . replace ( '#AAASTREAM:' , '#A:' )
 iII = iII . replace ( '#EXTINF:' , '#A:' )
 o0ooOooo000oOO = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( iII )
 Oo0oOOo = [ ]
 for Oo0OoO00oOO0o , OOO00O , url in o0ooOooo000oOO :
  OOoOO0oo0ooO = { "params" : Oo0OoO00oOO0o , "display_name" : OOO00O , "url" : url }
  Oo0oOOo . append ( OOoOO0oo0ooO )
 O0o0O00Oo0o0 = [ ]
 for O00O0oOO00O00 in Oo0oOOo :
  OOoOO0oo0ooO = { "display_name" : O00O0oOO00O00 [ "display_name" ] , "url" : O00O0oOO00O00 [ "url" ] }
  o0ooOooo000oOO = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O00O0oOO00O00 [ "params" ] )
 for i1Oo00 , i1i in o0ooOooo000oOO :
  OOoOO0oo0ooO [ i1Oo00 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = i1i . strip ( )
  O0o0O00Oo0o0 . append ( OOoOO0oo0ooO )
  if 26 - 26: Oo0o00o0Oo0 - o0 - o0OO0 / I1i1iI1i . o00ooo0 % o0
 for O00O0oOO00O00 in O0o0O00Oo0o0 :
  OooO0 = i11I1iIiII ( O00O0oOO00O00 [ "display_name" ] )
  url = i11I1iIiII ( O00O0oOO00O00 [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  I1I1i1 ( OooO0 , url , 3 , iiiii , O0O0OO0O0O0 )
  if 91 - 91: o00 . o0 / O0OOo + iIIIiiIIiiiIi
 i1iIIi1 = ii11iIi1I ( )
 if 42 - 42: i1iiIII111ii . o00 . i1iiIII111ii - Oo0oO0ooo
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 40 - 40: i1iiIII111ii - i11iIiiIii / ii11
def I11iiI1i1 ( ) :
 if 47 - 47: oo0O000OoO - ii11 . Oo + i1oOo0OoO . i11iIiiIii
 iiI1 ( )
 if 94 - 94: o00 * ii11 / Oo0ooO0oo0oO / ii11
 O00oO = ''
 I1I1I = xbmc . Keyboard ( O00oO , 'Enter Search Term' )
 I1I1I . doModal ( )
 if I1I1I . isConfirmed ( ) :
  O00oO = I1I1I . getText ( )
  if len ( O00oO ) > 1 :
   II11iiii1Ii = O00oO
   Ii1I ( "search" , II11iiii1Ii , iiiii )
  else : quit ( )
  if 87 - 87: Oo0ooO0oo0oO . IiiIIiiI11
def O0OO0O ( ) :
 if 81 - 81: O0OOo . o00 % i1 / o0OO0 - O0OOo
 if not os . path . exists ( ooo0OO ) :
  try :
   os . makedirs ( ooo0OO )
  except : pass
 if os . path . exists ( I1IiiI ) :
  try :
   os . remove ( I1IiiI )
  except : pass
 else :
  try :
   open ( I1IiiI , 'w' )
  except : pass
  if 43 - 43: i11iIiiIii + Oo0ooO0oo0oO * Oo * oooOOOOO * i1
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 64 - 64: II1Iiii1111i % o0 * O0OOo
def iiI1 ( ) :
 if 79 - 79: i1
 if os . path . exists ( O00ooooo00 ) :
  oOO00O = OOOoo0OO ( heading = "Please Enter Your Password" )
  if ( not oOO00O ) :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  oO0o0 = oOO00O
  if 50 - 50: IiiIIiiI11
  Ii11iIi = open ( O00ooooo00 , "r" )
  O00O0Oooo0oO = re . compile ( r'<password>(.+?)</password>' )
  for IIii11I1 in Ii11iIi :
   file = O00O0Oooo0oO . findall ( IIii11I1 )
   for oOO0O00Oo0O0o in file :
    ii1 = base64 . b64decode ( oOO0O00Oo0O0o )
    if not ii1 == oO0o0 :
     if not oOO0O00Oo0O0o == oO0o0 :
      IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 35 - 35: oo0O000OoO * O0OOo / o0 - o00 / i1oOo0OoO - oooOOOOO
def II1I1iiIII ( ) :
 if 77 - 77: o00ooo0 - Oo - i1iiIII111ii
 iiI1 ( )
 if 49 - 49: Oo % i1 . o00ooo0 + O0OOo / o0OO0
 O0o0 = 0
 if not os . path . exists ( O00ooooo00 ) :
  O0o0 = 1
  I1I1i1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  I1I1i1 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  Ii11iIi = open ( O00ooooo00 , "r" )
  O00O0Oooo0oO = re . compile ( r'<password>(.+?)</password>' )
  for IIii11I1 in Ii11iIi :
   file = O00O0Oooo0oO . findall ( IIii11I1 )
   for oOO0O00Oo0O0o in file :
    ii1 = base64 . b64decode ( oOO0O00Oo0O0o )
    O0o0 = 1
    I1I1i1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    I1I1i1 ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( ii1 ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    I1I1i1 ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    I1I1i1 ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 72 - 72: i1iiIII111ii * Oo0ooO0oo0oO . o0OO0 - Oo + iIIIiiIIiiiIi
 if O0o0 == 0 :
  I1I1i1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  I1I1i1 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 10 - 10: O0OOo + iIIIiiIIiiiIi
 i1iIIi1 = ii11iIi1I ( )
 if 87 - 87: o0OO0
 if i1iIIi1 == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif i1iIIi1 == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 58 - 58: o00ooo0 % o00
def i1OOoO ( ) :
 if 89 - 89: o00 + I1i1iI1i * Oo0o00o0Oo0 * ii11
 oOO00O = OOOoo0OO ( heading = "Please Set Password" )
 if ( not oOO00O ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 oO0o0 = oOO00O
 if 37 - 37: i1oOo0OoO - i1 - o00
 oOO00O = OOOoo0OO ( heading = "Please Confirm Your Password" )
 if ( not oOO00O ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 o0o0O0O00oOOo = oOO00O
 if 14 - 14: o00ooo0 + O0OOo
 if not os . path . exists ( O00ooooo00 ) :
  if not os . path . exists ( II1 ) :
   os . makedirs ( II1 )
  open ( O00ooooo00 , 'w' )
  if 52 - 52: i1oOo0OoO - i1iiIII111ii
  if oO0o0 == o0o0O0O00oOOo :
   o0O0o0 = base64 . b64encode ( oO0o0 )
   II111iI111I1I = open ( O00ooooo00 , 'w' )
   II111iI111I1I . write ( '<password>' + str ( o0O0o0 ) + '</password>' )
   II111iI111I1I . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( O00ooooo00 )
  if 18 - 18: oo0O000OoO - II1Iiii1111i . oooOOOOO . o0
  if oO0o0 == o0o0O0O00oOOo :
   o0O0o0 = base64 . b64encode ( oO0o0 )
   II111iI111I1I = open ( O00ooooo00 , 'w' )
   II111iI111I1I . write ( '<password>' + str ( o0O0o0 ) + '</password>' )
   II111iI111I1I . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 2 - 2: II1Iiii1111i . I1i1iI1i
def O0ooooOOoo0O ( ) :
 if 36 - 36: O0OOo % O0OOo % iIIIiiIIiiiIi / iIIIiiIIiiiIi - i1iiIII111ii
 try :
  os . remove ( O00ooooo00 )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 30 - 30: Oo0o00o0Oo0 / o0OO0
def ii11iIi1I ( ) :
 if 35 - 35: Oo % II1Iiii1111i . i1iiIII111ii + i1iiIII111ii % Oo % Oo
 ooOoO00 = xbmc . getInfoLabel ( "System.BuildVersion" )
 Ii1IIiI1i = float ( ooOoO00 [ : 4 ] )
 if Ii1IIiI1i >= 11.0 and Ii1IIiI1i <= 11.9 :
  o0O00Oo0 = 'Eden'
 elif Ii1IIiI1i >= 12.0 and Ii1IIiI1i <= 12.9 :
  o0O00Oo0 = 'Frodo'
 elif Ii1IIiI1i >= 13.0 and Ii1IIiI1i <= 13.9 :
  o0O00Oo0 = 'Gotham'
 elif Ii1IIiI1i >= 14.0 and Ii1IIiI1i <= 14.9 :
  o0O00Oo0 = 'Helix'
 elif Ii1IIiI1i >= 15.0 and Ii1IIiI1i <= 15.9 :
  o0O00Oo0 = 'Isengard'
 elif Ii1IIiI1i >= 16.0 and Ii1IIiI1i <= 16.9 :
  o0O00Oo0 = 'Jarvis'
 elif Ii1IIiI1i >= 17.0 and Ii1IIiI1i <= 17.9 :
  o0O00Oo0 = 'Krypton'
 else : o0O00Oo0 = "Decline"
 if 33 - 33: i1 * o00 - oooOOOOO % oooOOOOO
 return o0O00Oo0
 if 18 - 18: oooOOOOO / Oo0ooO0oo0oO * oooOOOOO + oooOOOOO * i11iIiiIii * Oo0oO0ooo
def I1II1 ( name , url , iconimage ) :
 if 86 - 86: o0 / o00ooo0 . Oo
 try :
  name , url = url . split ( '|SPLIT|' )
 except : pass
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 19 - 19: Oo0oO0ooo % i1oOo0OoO % IiiIIiiI11 * o00 % i1
 ooo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , ooo , False )
 if 27 - 27: i1iiIII111ii % o0OO0
def i11I1iIiII ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 73 - 73: II1Iiii1111i
def IIiiIiI1 ( url ) :
 if 70 - 70: o0
 i11ii1iI = urllib2 . Request ( url )
 i11ii1iI . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 iII = urllib2 . urlopen ( i11ii1iI )
 OoO000 = iII . read ( )
 iII . close ( )
 return OoO000
 if 22 - 22: i1oOo0OoO
def OOOoo0OO ( default = "" , heading = "" , hidden = False ) :
 I1I1I = xbmc . Keyboard ( default , heading , hidden )
 if 75 - 75: o00 + o00 + iIIIiiIIiiiIi - iIIIiiIIiiiIi
 I1I1I . doModal ( )
 if ( I1I1I . isConfirmed ( ) ) :
  return unicode ( I1I1I . getText ( ) , "utf-8" )
 return default
 if 76 - 76: I1i1iI1i . i1 % i1 - o00 - o0 - o0OO0
def IiI1i ( name , url , mode , iconimage , fanartimage ) :
 if 53 - 53: iIIIiiIIiiiIi
 o0OOOoO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 o0OoOo00o0o = True
 ooo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 ooo . setProperty ( "fanart_Image" , fanartimage )
 ooo . setProperty ( "icon_Image" , iconimage )
 o0OoOo00o0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0OOOoO0 , listitem = ooo , isFolder = True )
 return o0OoOo00o0o
 if 41 - 41: i1iiIII111ii % I1i1iI1i - Oo0ooO0oo0oO * oooOOOOO * Oo0ooO0oo0oO
def I1I1i1 ( name , url , mode , iconimage , fanartimage ) :
 if 69 - 69: II1Iiii1111i - i1oOo0OoO + o00 - Oo0o00o0Oo0
 o0OOOoO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 o0OoOo00o0o = True
 ooo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 ooo . setProperty ( "fanart_Image" , fanartimage )
 ooo . setProperty ( "icon_Image" , iconimage )
 o0OoOo00o0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0OOOoO0 , listitem = ooo , isFolder = False )
 return o0OoOo00o0o
 if 23 - 23: i11iIiiIii
def II1iIi11 ( ) :
 I11iiii = [ ]
 O0 = sys . argv [ 2 ]
 if len ( O0 ) >= 2 :
  Oo0OoO00oOO0o = sys . argv [ 2 ]
  i1iI = Oo0OoO00oOO0o . replace ( '?' , '' )
  if ( Oo0OoO00oOO0o [ len ( Oo0OoO00oOO0o ) - 1 ] == '/' ) :
   Oo0OoO00oOO0o = Oo0OoO00oOO0o [ 0 : len ( Oo0OoO00oOO0o ) - 2 ]
  IiI1iiiIii = i1iI . split ( '&' )
  I11iiii = { }
  for IIIii1II1II in range ( len ( IiI1iiiIii ) ) :
   I1III1111iIi = { }
   I1III1111iIi = IiI1iiiIii [ IIIii1II1II ] . split ( '=' )
   if ( len ( I1III1111iIi ) ) == 2 :
    I11iiii [ I1III1111iIi [ 0 ] ] = I1III1111iIi [ 1 ]
    if 38 - 38: oo0O000OoO + Oo0o00o0Oo0 / oooOOOOO % i1iiIII111ii - Oo0oO0ooo
 return I11iiii
 if 14 - 14: O0OOo / oooOOOOO
Oo0OoO00oOO0o = II1iIi11 ( ) ; OooO0 = None ; II11iiii1Ii = None ; ooo0O0o00O = None ; OO0oOoo = None ; I1i11 = None
try : OooO0 = urllib . unquote_plus ( Oo0OoO00oOO0o [ "name" ] )
except : pass
try : II11iiii1Ii = urllib . unquote_plus ( Oo0OoO00oOO0o [ "url" ] )
except : pass
try : ooo0O0o00O = int ( Oo0OoO00oOO0o [ "mode" ] )
except : pass
try : OO0oOoo = urllib . unquote_plus ( Oo0OoO00oOO0o [ "iconimage" ] )
except : pass
try : I1i11 = urllib . quote_plus ( Oo0OoO00oOO0o [ "fanartimage" ] )
except : pass
if 12 - 12: iIIIiiIIiiiIi + iIIIiiIIiiiIi - Oo0oO0ooo * Oo0ooO0oo0oO % Oo0ooO0oo0oO - Oo
if ooo0O0o00O == None or II11iiii1Ii == None or len ( II11iiii1Ii ) < 1 : o0oOoO00o ( )
elif ooo0O0o00O == 1 : i1IIiiiii ( )
elif ooo0O0o00O == 2 : Ii1I ( OooO0 , II11iiii1Ii , OO0oOoo )
elif ooo0O0o00O == 3 : I1II1 ( OooO0 , II11iiii1Ii , OO0oOoo )
elif ooo0O0o00O == 4 : I11iiI1i1 ( )
elif ooo0O0o00O == 5 : O0OO0O ( )
elif ooo0O0o00O == 6 : OOO ( )
elif ooo0O0o00O == 7 : o00o0 ( II11iiii1Ii )
elif ooo0O0o00O == 900 : II1I1iiIII ( )
elif ooo0O0o00O == 901 : i1OOoO ( )
elif ooo0O0o00O == 902 : O0ooooOOoo0O ( )
elif ooo0O0o00O == 999 : quit ( )
if 52 - 52: i1iiIII111ii . oo0O000OoO + oooOOOOO
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )