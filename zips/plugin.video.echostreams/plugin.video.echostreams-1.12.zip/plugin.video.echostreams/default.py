import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64 , shutil , time
from resources . lib . modules import checker
from resources . lib . modules import cache
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' , OO0o ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( II1 , 'controls.txt' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'hd.txt' ) )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/m3u.xml' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/cleaner.xml' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/replacer.xml' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/blacklist.xml' ) )
if 91 - 91: Ii1I . OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
O0oO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
o0oO0 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
oo00 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
o00 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
Oo0oO0ooo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI=' )
if 56 - 56: ooO00oOoo - O0OOo
cache . check ( )
if 8 - 8: Oooo0000 * i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
def oO000OoOoo00o ( ) :
 if 31 - 31: i111IiI + iIIIiI11 . iII111ii
 i1iIIi1 = OOOo0 + '|SPLIT|' + oO00oOo
 checker . check ( i1iIIi1 )
 if 50 - 50: IiIi1Iii1I1 - O00O0O0O0
 ooO0O ( "true" )
 if 63 - 63: i1I1ii1II1iII . i1I1ii1II1iII
 Ii1 ( "[COLOR white]Welcome to ECHO Streams[/COLOR]" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 oOOoO0 ( "################################################################" , O0oO , 6 , iiiii , O0O0OO0O0O0 )
 Ii1 ( "[COLOR white]Meet the team:[/COLOR]" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 Ii1 ( "[COLOR white]ECHO Coder: @EchoCoder(Twitter)[/COLOR]" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 Ii1 ( "[COLOR white]ECHO Blue: @Blue_Builds(Twitter)[/COLOR]" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 Ii1 ( "################################################################" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 oOOoO0 ( "[COLOR dodgerblue][B]ENTER ADDON[/B][/COLOR]" , O0oO , 1 , iiiii , O0O0OO0O0O0 )
 Ii1 ( "################################################################" , O0oO , 999 , iiiii , O0O0OO0O0O0 )
 if not os . path . exists ( O00ooooo00 ) :
  oOOoO0 ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  oOOoO0 ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
  if 59 - 59: i111IiI * i11iIiiIii + i111IiI + O00O0O0O0 * O0OOo
 OooOoO0Oo = iiIIiIiIi ( )
 if 38 - 38: i111IiI / ooO00oOoo
 if OooOoO0Oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OooOoO0Oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 76 - 76: Ii1I / i1IIi11111i . oooO0oo0oOOOO * i111IiI - OOO0O
def Oooo ( ) :
 if 67 - 67: OOO0O / OoOO0ooOOoo0O % oo0ooO0oOOOOo - OoOO
 ooO0O ( "name" , "true" )
 if 82 - 82: i11iIiiIii . OOO0O / ooO00oOoo * Ii1I % oo % OoOO
 oOOoO0 ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 78 - 78: OoOO - i111IiI * O0OOo + i1IIi11111i + iIIIiI11 + iIIIiI11
 if os . path . exists ( I1IiiI ) :
  Ii1 ( '[COLOR white]Only Display HD Links - [COLOR lime][B]ON[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 else : Ii1 ( '[COLOR white]Only Display HD Links - [COLOR red][B]OFF[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 Ii1 ( '[COLOR white]Force Data Refresh[/COLOR]' , "false" , 8 , iiiii , O0O0OO0O0O0 )
 Ii1 ( '[COLOR darkgray]############################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 I11I11i1I = ii11i1iIII ( O0oO )
 I11I11i1I = I11I11i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 Ii1IOo0o0 = re . compile ( '<item>(.+?)</item>' ) . findall ( I11I11i1I )
 for III1ii1iII in Ii1IOo0o0 :
  oo0oooooO0 = re . compile ( '<title>(.+?)</title>' ) . findall ( III1ii1iII ) [ 0 ]
  i11Iiii = re . compile ( '<folder>(.+?)</folder>' ) . findall ( III1ii1iII ) [ 0 ]
  iI = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( III1ii1iII ) [ 0 ]
  I1i1I1II = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( III1ii1iII ) [ 0 ]
  if 45 - 45: IiIi1Iii1I1 . Oooo0000
  oOOoO0 ( '[COLOR white]' + oo0oooooO0 + '[/COLOR]' , oo0oooooO0 , 2 , iI , I1i1I1II )
  if 83 - 83: oo . OoOO . I11i1i11i1I
 OooOoO0Oo = iiIIiIiIi ( )
 if 31 - 31: i111IiI . i111IiI - i1IIi11111i / O0OOo + O00O0O0O0 * oooO0oo0oOOOO
 if OooOoO0Oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OooOoO0Oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 63 - 63: IiIi1Iii1I1 % o0000oOoOoO0o / OoOO0ooOOoo0O - OoOO0ooOOoo0O
def iIii11I ( name , url , iconimage ) :
 if 69 - 69: oo % IiIi1Iii1I1 - i1IIi11111i + IiIi1Iii1I1 - Ii1I % OoOO0ooOOoo0O
 I11i11Ii . create ( Oo0Ooo , "[COLOR dodgerblue]Getting the list of AWESOME streams![/COLOR]" , "[COLOR lime]We wont be long, we promise.[/COLOR]" )
 Iii111II = name
 if 9 - 9: O0OOo
 if "adult" in name . lower ( ) :
  i11 ( )
 O0oo0OO0oOOOo = [ ]
 if 35 - 35: iII111ii % oooO0oo0oOOOO
 if not "search" in name . lower ( ) :
  o0OOoo0OO0OOO = xbmc . translatePath ( os . path . join ( Oooo000o , url + ".xml" ) )
  iI1iI1I1i1I = open ( o0OOoo0OO0OOO )
  iIi11Ii1 = iI1iI1I1i1I . read ( )
  Ii11iII1 = re . compile ( '<term>(.+?)</term>' , re . DOTALL ) . findall ( iIi11Ii1 )
  for Oo0O0O0ooO0O in Ii11iII1 :
   Oo0O0O0ooO0O = Oo0O0O0ooO0O . replace ( ' ' , '' )
   Oo0O0O0ooO0O = Oo0O0O0ooO0O . lower ( )
   O0oo0OO0oOOOo . append ( Oo0O0O0ooO0O )
 else :
  Oo0O0O0ooO0O = url
  Oo0O0O0ooO0O = Oo0O0O0ooO0O . replace ( ' ' , '' )
  Oo0O0O0ooO0O = Oo0O0O0ooO0O . lower ( )
  O0oo0OO0oOOOo . append ( url . lower ( ) )
  if 15 - 15: I11i1i11i1I + Oooo0000 - OoOO0ooOOoo0O / OOO0O
 oo000OO00Oo = [ ]
 O0OOO0OOoO0O = [ ]
 O00Oo000ooO0 = [ ]
 OoO0O00 = [ ]
 if 5 - 5: ooO00oOoo / i1IIi11111i . i111IiI - Ii1I / iII111ii
 iI1iI1I1i1I = open ( Oo0O )
 ooOooo000oOO = iI1iI1I1i1I . read ( )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( ooOooo000oOO )
 if 58 - 58: i1I1ii1II1iII * OOO0O * I11i1i11i1I / OOO0O
 iI1iI1I1i1I = open ( IiI )
 oO0o0OOOO = iI1iI1I1i1I . read ( )
 Ii1IOo0o0 = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( oO0o0OOOO )
 if 68 - 68: iIIIiI11 - IiIi1Iii1I1 - oooO0oo0oOOOO - I11i1i11i1I + oo0ooO0oOOOOo
 iI1iI1I1i1I = open ( ooOo )
 iiiI1I11i1 = iI1iI1I1i1I . read ( )
 IIi1i11111 = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( iiiI1I11i1 )
 if 81 - 81: i11iIiiIii % Oooo0000 - OOO0O
 O0ooo0O0oo0 = 0
 for Oo0O0O0ooO0O in IIi1i11111 :
  oo0oOo = re . compile ( '<cat>(.+?)</cat>' ) . findall ( Oo0O0O0ooO0O ) [ 0 ]
  if oo0oOo . lower ( ) in Iii111II . lower ( ) :
   o000O0o = oo0oOo
   O0ooo0O0oo0 = 1
 if O0ooo0O0oo0 == 0 : o000O0o = "null"
 if 42 - 42: Oooo0000
 iI1iI1I1i1I = open ( IiIi11iIIi1Ii )
 III1ii1iII = iI1iI1I1i1I . read ( )
 if 41 - 41: ooO00oOoo . O00O0O0O0 + Ii1I * i1IIi11111i % ooO00oOoo * ooO00oOoo
 iIIIIi1iiIi1 = III1ii1iII
 iIIIIi1iiIi1 = iIIIIi1iiIi1 . replace ( '#AAASTREAM:' , '#A:' )
 iIIIIi1iiIi1 = iIIIIi1iiIi1 . replace ( '#EXTINF:' , '#A:' )
 iii1i1iiiiIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( iIIIIi1iiIi1 )
 Iiii = [ ]
 for OO0OoO0o00 , ooOO0O0ooOooO , url in iii1i1iiiiIi :
  oOOOo00O00oOo = { "params" : OO0OoO0o00 , "display_name" : ooOO0O0ooOooO , "url" : url }
  Iiii . append ( oOOOo00O00oOo )
 iiIIIi = [ ]
 for ooo00OOOooO in Iiii :
  oOOOo00O00oOo = { "display_name" : ooo00OOOooO [ "display_name" ] , "url" : ooo00OOOooO [ "url" ] }
  iii1i1iiiiIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooo00OOOooO [ "params" ] )
  for O00OOOoOoo0O , O000OOo00oo in iii1i1iiiiIi :
   oOOOo00O00oOo [ O00OOOoOoo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O000OOo00oo . strip ( )
  iiIIIi . append ( oOOOo00O00oOo )
  if 71 - 71: i11iIiiIii + iII111ii
 for ooo00OOOooO in iiIIIi :
  name = oOo ( ooo00OOOooO [ "display_name" ] )
  url = oOo ( ooo00OOOooO [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if 75 - 75: oooO0oo0oOOOO + ooO00oOoo
  oo000OO00Oo . append ( name )
  O0OOO0OOoO0O . append ( url )
  OoO0O00 = list ( zip ( oo000OO00Oo , O0OOO0OOoO0O ) )
  if 73 - 73: Ii1I - OoOO0ooOOoo0O . OOO0O - OOO0O / Oooo0000
 iiIi1I1iIIi = sorted ( OoO0O00 )
 iii = sorted ( O0oo0OO0oOOOo )
 if 1 - 1: ooO00oOoo / i1IIi11111i % iIIIiI11 * iII111ii . i11iIiiIii
 III1Iiii1I11 = [ ]
 IIII = [ ]
 iiIiI = [ ]
 o00oooO0Oo = 0
 if 78 - 78: i111IiI % IiIi1Iii1I1 + I11i1i11i1I
 if o000O0o != 'null' :
  if 64 - 64: oo * Ii1I . oooO0oo0oOOOO + i1I1ii1II1iII
  IIi1i = re . compile ( '<cat>' + re . escape ( o000O0o ) + '</cat>(.+?)</item>' , re . DOTALL ) . findall ( iiiI1I11i1 ) [ 0 ]
  if 87 - 87: i1IIi11111i - I11i1i11i1I + iII111ii % iIIIiI11 + oooO0oo0oOOOO - Oooo0000
  Ii11iII1 = re . compile ( '<name>(.+?)</name>' ) . findall ( IIi1i )
  if 16 - 16: OoOO
  for oOooOOOoOo in iii :
   for name , url in iiIi1I1iIIi :
    i1Iii1i1I = name . replace ( ' ' , '' )
    if 91 - 91: I11i1i11i1I + oooO0oo0oOOOO . OOO0O * I11i1i11i1I + oooO0oo0oOOOO * ooO00oOoo
    if oOooOOOoOo . lower ( ) in i1Iii1i1I . lower ( ) :
     if url not in str ( IIII ) :
      if 80 - 80: iIIIiI11 % OOO0O % oo - ooO00oOoo + ooO00oOoo
      for iIiii1i111iI1 in Ii11iII1 :
       if iIiii1i111iI1 in name . lower ( ) :
        o00oooO0Oo = 1
      if o00oooO0Oo == 0 :
       for III1ii1iII in Ii1IOo0o0 :
        i11oO0oOo0 = re . compile ( '<old>(.+?)</old>' ) . findall ( III1ii1iII ) [ 0 ]
        I1I1I = re . compile ( '<new>(.+?)</new>' ) . findall ( III1ii1iII ) [ 0 ]
        if I1I1I . lower ( ) == "null" : I1I1I = ""
        name = name . lower ( )
        i11oO0oOo0 = i11oO0oOo0 . lower ( )
        I1I1I = I1I1I . lower ( )
        name = name . replace ( i11oO0oOo0 , I1I1I )
       for OoOO000 in Oo0oOOo :
        i11oO0oOo0 = re . compile ( '<old>(.+?)</old>' ) . findall ( OoOO000 ) [ 0 ]
        I1I1I = re . compile ( '<new>(.+?)</new>' ) . findall ( OoOO000 ) [ 0 ]
        name = name . lower ( )
        i11oO0oOo0 = i11oO0oOo0 . lower ( )
        I1I1I = I1I1I . lower ( )
        name = name . replace ( i11oO0oOo0 , I1I1I )
        name = name . lstrip ( ' ' )
       III1Iiii1I11 . append ( name )
       IIII . append ( url )
       iiIiI = list ( zip ( III1Iiii1I11 , IIII ) )
      o00oooO0Oo = 0
 else :
  for oOooOOOoOo in iii :
   for name , url in iiIi1I1iIIi :
    i1Iii1i1I = name . replace ( ' ' , '' )
    if 14 - 14: iII111ii - I11i1i11i1I
    if oOooOOOoOo . lower ( ) in i1Iii1i1I . lower ( ) :
     if url not in str ( IIII ) :
      if 11 - 11: i1I1ii1II1iII * i1I1ii1II1iII % OoOO * IiIi1Iii1I1 + Oooo0000 / oooO0oo0oOOOO
      for III1ii1iII in Ii1IOo0o0 :
       i11oO0oOo0 = re . compile ( '<old>(.+?)</old>' ) . findall ( III1ii1iII ) [ 0 ]
       I1I1I = re . compile ( '<new>(.+?)</new>' ) . findall ( III1ii1iII ) [ 0 ]
       if I1I1I . lower ( ) == "null" : I1I1I = ""
       name = name . replace ( i11oO0oOo0 , I1I1I )
      for OoOO000 in Oo0oOOo :
       i11oO0oOo0 = re . compile ( '<old>(.+?)</old>' ) . findall ( OoOO000 ) [ 0 ]
       I1I1I = re . compile ( '<new>(.+?)</new>' ) . findall ( OoOO000 ) [ 0 ]
       name = name . replace ( i11oO0oOo0 , I1I1I )
      name = name . lstrip ( ' ' )
      III1Iiii1I11 . append ( name )
      IIII . append ( url )
      iiIiI = list ( zip ( III1Iiii1I11 , IIII ) )
      if 3 - 3: i1IIi11111i
      if 24 - 24: i11iIiiIii + iIIIiI11 * i111IiI - i1I1ii1II1iII . OOO0O % OoOO
 ooI1IiiiiI = sorted ( iiIiI )
 if 80 - 80: IiIi1Iii1I1 . i11iIiiIii - i1IIi11111i
 for name , url in ooI1IiiiiI :
  if 25 - 25: O0OOo
  oOo0oO = name . title ( ) + '|SPLIT|' + url
  if 51 - 51: ooO00oOoo - oo + i1I1ii1II1iII * i111IiI . oo0ooO0oOOOOo + oo
  if os . path . exists ( I1IiiI ) :
   if "hd" in name . lower ( ) :
    name = name . lower ( )
    name = name . replace ( 'hd' , '' )
    Ii1 ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , oOo0oO , 3 , iiiii , O0O0OO0O0O0 )
  else :
   if "hd" in name . lower ( ) :
    name = name . lower ( )
    name = name . replace ( 'hd' , '' )
    Ii1 ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , oOo0oO , 3 , iiiii , O0O0OO0O0O0 )
   else :
    Ii1 ( '[COLOR white]' + name . title ( ) + '[/COLOR]' , oOo0oO , 3 , iiiii , O0O0OO0O0O0 )
    if 78 - 78: i11iIiiIii / iIIIiI11 - i111IiI / OOO0O + oo
 OooOoO0Oo = iiIIiIiIi ( )
 if 82 - 82: i111IiI
 if OooOoO0Oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OooOoO0Oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 46 - 46: OoOO0ooOOoo0O . i11iIiiIii
def OOo0oO00ooO00 ( ) :
 if 90 - 90: Oooo0000 * IiIi1Iii1I1 + i1IIi11111i
 Oo0oOOo = ''
 OO = xbmc . Keyboard ( Oo0oOOo , 'Enter Search Term' )
 OO . doModal ( )
 if OO . isConfirmed ( ) :
  Oo0oOOo = OO . getText ( )
  if len ( Oo0oOOo ) > 1 :
   if not Oo0oOOo == base64 . b64decode ( 'Z2VuZXJhdGVpbmk=' ) :
    IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, incorrect password." )
    quit ( )
  else : quit ( )
  if 83 - 83: Ii1I / oooO0oo0oOOOO - O0OOo - OOO0O
 I11I11i1I = ii11i1iIII ( o0oO0 )
 Ii11iII1 = re . compile ( '<link>(.+?)</link>' ) . findall ( I11I11i1I )
 if 36 - 36: iII111ii
 for III1ii1iII in Ii11iII1 :
  oOOoO0 ( III1ii1iII , III1ii1iII , 7 , iiiii , O0O0OO0O0O0 )
  if 36 - 36: O00O0O0O0 / Ii1I * ooO00oOoo - OOO0O % OoOO * oo
 OooOoO0Oo = iiIIiIiIi ( )
 if 79 - 79: Ii1I
 if OooOoO0Oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OooOoO0Oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 78 - 78: I11i1i11i1I + OOO0O - IiIi1Iii1I1
def IIIIii1I ( url ) :
 if 39 - 39: i1I1ii1II1iII / O00O0O0O0 + IiIi1Iii1I1 / Oooo0000
 ooOooo000oOO = ii11i1iIII ( o00 )
 ooOooo000oOO = ooOooo000oOO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 Oo0oOOo = re . compile ( '<item>(.+?)</item>' ) . findall ( ooOooo000oOO )
 if 13 - 13: iII111ii + Ii1I + iIIIiI11 % oooO0oo0oOOOO / i1IIi11111i . iII111ii
 oO0o0OOOO = ii11i1iIII ( oo00 )
 oO0o0OOOO = oO0o0OOOO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 Ii1IOo0o0 = re . compile ( '<item>(.+?)</item>' ) . findall ( oO0o0OOOO )
 if 86 - 86: oo * i1IIi11111i % o0000oOoOoO0o . i111IiI . i11iIiiIii
 iIIIIi1iiIi1 = ii11i1iIII ( url )
 iIIIIi1iiIi1 = iIIIIi1iiIi1 . replace ( '#AAASTREAM:' , '#A:' )
 iIIIIi1iiIi1 = iIIIIi1iiIi1 . replace ( '#EXTINF:' , '#A:' )
 iii1i1iiiiIi = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( iIIIIi1iiIi1 )
 Iiii = [ ]
 for OO0OoO0o00 , ooOO0O0ooOooO , url in iii1i1iiiiIi :
  oOOOo00O00oOo = { "params" : OO0OoO0o00 , "display_name" : ooOO0O0ooOooO , "url" : url }
  Iiii . append ( oOOOo00O00oOo )
 iiIIIi = [ ]
 for ooo00OOOooO in Iiii :
  oOOOo00O00oOo = { "display_name" : ooo00OOOooO [ "display_name" ] , "url" : ooo00OOOooO [ "url" ] }
  iii1i1iiiiIi = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( ooo00OOOooO [ "params" ] )
  for O00OOOoOoo0O , O000OOo00oo in iii1i1iiiiIi :
   oOOOo00O00oOo [ O00OOOoOoo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O000OOo00oo . strip ( )
  iiIIIi . append ( oOOOo00O00oOo )
  if 56 - 56: I11i1i11i1I % Ii1I - oooO0oo0oOOOO
 for ooo00OOOooO in iiIIIi :
  oo0oooooO0 = oOo ( ooo00OOOooO [ "display_name" ] )
  url = oOo ( ooo00OOOooO [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if 100 - 100: i111IiI - Ii1I % oo * OOO0O + oooO0oo0oOOOO
  for III1ii1iII in Ii1IOo0o0 :
   i11oO0oOo0 = re . compile ( '<old>(.+?)</old>' ) . findall ( III1ii1iII ) [ 0 ]
   I1I1I = re . compile ( '<new>(.+?)</new>' ) . findall ( III1ii1iII ) [ 0 ]
   if I1I1I . lower ( ) == "null" : I1I1I = ""
   oo0oooooO0 = oo0oooooO0 . replace ( i11oO0oOo0 , I1I1I )
  for OoOO000 in Oo0oOOo :
   i11oO0oOo0 = re . compile ( '<old>(.+?)</old>' ) . findall ( OoOO000 ) [ 0 ]
   I1I1I = re . compile ( '<new>(.+?)</new>' ) . findall ( OoOO000 ) [ 0 ]
   oo0oooooO0 = oo0oooooO0 . replace ( i11oO0oOo0 , I1I1I )
  oo0oooooO0 = oo0oooooO0 . lstrip ( ' ' )
  if 88 - 88: OoOO0ooOOoo0O - O0OOo * Ii1I * OoOO0ooOOoo0O . OoOO0ooOOoo0O
  Ii1 ( oo0oooooO0 , url , 3 , iiiii , O0O0OO0O0O0 )
  if 33 - 33: IiIi1Iii1I1 + iIIIiI11 * oo / OoOO - oooO0oo0oOOOO
 I11i11Ii . close ( )
 if 54 - 54: IiIi1Iii1I1 / OOO0O . oo % iIIIiI11
 OooOoO0Oo = iiIIiIiIi ( )
 if 57 - 57: i11iIiiIii . I11i1i11i1I - i111IiI - oo + Oooo0000
 if OooOoO0Oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OooOoO0Oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 63 - 63: Oooo0000 * iIIIiI11
def ooO0O ( name , url ) :
 if 69 - 69: Ii1I . O0OOo
 ii1111iII = 0
 if 32 - 32: o0000oOoOoO0o / i1I1ii1II1iII . ooO00oOoo
 if not os . path . exists ( Oooo000o ) :
  os . makedirs ( Oooo000o )
 if not os . path . isfile ( IiIi11iIIi1Ii ) :
  open ( IiIi11iIIi1Ii , 'w' )
  if 62 - 62: OoOO0ooOOoo0O * oooO0oo0oOOOO
 iI1iI1I1i1I = open ( IiIi11iIIi1Ii )
 oOOOoo0O0oO = iI1iI1I1i1I . read ( )
 if 6 - 6: OOO0O * i1IIi11111i + iIIIiI11
 if len ( oOOOoo0O0oO ) == 0 :
  ii1111iII = 1
  if 44 - 44: i111IiI % O0OOo + OoOO0ooOOoo0O - Ii1I - i111IiI - i1I1ii1II1iII
 if ii1111iII == 1 :
  I11i11Ii . create ( Oo0Ooo , "Getting files to make ECHO Streams AWESOME!" )
  if 99 - 99: O00O0O0O0 . i111IiI + IiIi1Iii1I1 + OoOO0ooOOoo0O % i1IIi11111i
  try :
   shutil . rmtree ( Oooo000o )
   os . makedirs ( Oooo000o )
  except : pass
  if 51 - 51: OoOO
  I11i11Ii . update ( 0 , "" , "[COLOR dodgerblue]Contacting ECHO Servers.[/COLOR]" )
  I11I11i1I = ii11i1iIII ( O0oO )
  I11I11i1I = I11I11i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
  Ii1IOo0o0 = re . compile ( '<item>(.+?)</item>' ) . findall ( I11I11i1I )
  iIIiIi1 = len ( Ii1IOo0o0 )
  o0O0o0 = iIIiIi1 + 4
  if 37 - 37: I11i1i11i1I * oo0ooO0oOOOOo % i11iIiiIii % O00O0O0O0 + i111IiI
  OOoOO0o0o0 = 100 * 1 / int ( o0O0o0 )
  I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U Cleaner file.[/COLOR]" , "[COLOR lime]File 1 of " + str ( o0O0o0 ) + "[/COLOR]" )
  file = ii11i1iIII ( o00 )
  iI1iI1I1i1I = open ( Oo0O , "w" )
  iI1iI1I1i1I . write ( file )
  iI1iI1I1i1I . close ( )
  if 11 - 11: oooO0oo0oOOOO
  OOoOO0o0o0 = 100 * 2 / int ( o0O0o0 )
  I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U Replacer file.[/COLOR]" , "[COLOR lime]File 2 of " + str ( o0O0o0 ) + "[/COLOR]" )
  file = ii11i1iIII ( oo00 )
  iI1iI1I1i1I = open ( IiI , "w" )
  iI1iI1I1i1I . write ( file )
  iI1iI1I1i1I . close ( )
  if 16 - 16: i111IiI + iII111ii * Ii1I % o0000oOoOoO0o . oooO0oo0oOOOO
  OOoOO0o0o0 = 100 * 3 / int ( o0O0o0 )
  I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the Blacklist file.[/COLOR]" , "[COLOR lime]File 3 of " + str ( o0O0o0 ) + "[/COLOR]" )
  file = ii11i1iIII ( Oo0oO0ooo )
  iI1iI1I1i1I = open ( ooOo , "w" )
  iI1iI1I1i1I . write ( file )
  iI1iI1I1i1I . close ( )
  if 67 - 67: OoOO0ooOOoo0O / oooO0oo0oOOOO * i111IiI + oo0ooO0oOOOOo
  OOoOO0o0o0 = 100 * 4 / int ( o0O0o0 )
  I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U files.[/COLOR]" , "[COLOR lime]File 4 of " + str ( o0O0o0 ) + "[/COLOR]" )
  OooOo0ooo = o00oo0 ( )
  iI1iI1I1i1I = open ( IiIi11iIIi1Ii , "w" )
  iI1iI1I1i1I . write ( OooOo0ooo )
  iI1iI1I1i1I . close ( )
  if 38 - 38: O00O0O0O0 % i1I1ii1II1iII % oo0ooO0oOOOOo / O0OOo + Oooo0000 / o0000oOoOoO0o
  OoOOo0OOoO = 4
  if 72 - 72: i111IiI
  for III1ii1iII in Ii1IOo0o0 :
   OoOOo0OOoO = OoOOo0OOoO + 1
   OOoOO0o0o0 = 100 * int ( OoOOo0OOoO ) / int ( o0O0o0 )
   I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the menu files.[/COLOR]" , "[COLOR lime]File " + str ( OoOOo0OOoO ) + " of " + str ( o0O0o0 ) + "[/COLOR]" )
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( III1ii1iII ) [ 0 ]
   url = re . compile ( '<folder>(.+?)</folder>' ) . findall ( III1ii1iII ) [ 0 ]
   if 1 - 1: O0OOo * iII111ii * OoOO0ooOOoo0O + O00O0O0O0
   file = ii11i1iIII ( url )
   o0OOoo0OO0OOO = xbmc . translatePath ( os . path . join ( Oooo000o , name + ".xml" ) )
   if 33 - 33: Ii1I * i1IIi11111i - IiIi1Iii1I1 % IiIi1Iii1I1
   iI1iI1I1i1I = open ( o0OOoo0OO0OOO , "w" )
   iI1iI1I1i1I . write ( file )
   iI1iI1I1i1I . close ( )
   if 18 - 18: IiIi1Iii1I1 / ooO00oOoo * IiIi1Iii1I1 + IiIi1Iii1I1 * i11iIiiIii * I11i1i11i1I
  I11i11Ii . close ( )
  return
  if 11 - 11: O00O0O0O0 / Oooo0000 - iII111ii * OoOO0ooOOoo0O + OoOO0ooOOoo0O . Oooo0000
 if url == "true" :
  if 26 - 26: i111IiI % I11i1i11i1I
  o00Oo0oooooo = os . path . getmtime ( IiIi11iIIi1Ii )
  if 76 - 76: oo0ooO0oOOOOo / OOO0O . Ii1I % oooO0oo0oOOOO . i1IIi11111i + iII111ii
  o0o = time . time ( )
  if 62 - 62: OoOO0ooOOoo0O . oo0ooO0oOOOOo
  oOOOoo00 = o0o - 60 * 60
  if 9 - 9: Ii1I % Ii1I - i1IIi11111i
  if o00Oo0oooooo < oOOOoo00 :
   if 51 - 51: oooO0oo0oOOOO . OoOO - I11i1i11i1I / Ii1I
   I11i11Ii . create ( Oo0Ooo , "Getting files to make ECHO Streams AWESOME!" )
   if 52 - 52: i1IIi11111i + Ii1I + iIIIiI11 + ooO00oOoo % iIIIiI11
   try :
    shutil . rmtree ( Oooo000o )
    os . makedirs ( Oooo000o )
   except : pass
   if 75 - 75: oooO0oo0oOOOO . O00O0O0O0 . Ii1I * IiIi1Iii1I1
   I11i11Ii . update ( 0 , "" , "[COLOR dodgerblue]Contacting ECHO Servers.[/COLOR]" )
   I11I11i1I = ii11i1iIII ( O0oO )
   I11I11i1I = I11I11i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
   Ii1IOo0o0 = re . compile ( '<item>(.+?)</item>' ) . findall ( I11I11i1I )
   iIIiIi1 = len ( Ii1IOo0o0 )
   o0O0o0 = iIIiIi1 + 4
   if 4 - 4: i111IiI % oo * O0OOo
   OOoOO0o0o0 = 100 * 1 / int ( o0O0o0 )
   I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U Cleaner file.[/COLOR]" , "[COLOR lime]File 1 of " + str ( o0O0o0 ) + "[/COLOR]" )
   file = ii11i1iIII ( o00 )
   iI1iI1I1i1I = open ( Oo0O , "w" )
   iI1iI1I1i1I . write ( file )
   iI1iI1I1i1I . close ( )
   if 100 - 100: IiIi1Iii1I1 * OOO0O + OOO0O
   OOoOO0o0o0 = 100 * 2 / int ( o0O0o0 )
   I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U Replacer file.[/COLOR]" , "[COLOR lime]File 2 of " + str ( o0O0o0 ) + "[/COLOR]" )
   file = ii11i1iIII ( oo00 )
   iI1iI1I1i1I = open ( IiI , "w" )
   iI1iI1I1i1I . write ( file )
   iI1iI1I1i1I . close ( )
   if 54 - 54: OoOO0ooOOoo0O + i1IIi11111i - o0000oOoOoO0o % i11iIiiIii
   OOoOO0o0o0 = 100 * 3 / int ( o0O0o0 )
   I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the Blacklist file.[/COLOR]" , "[COLOR lime]File 3 of " + str ( o0O0o0 ) + "[/COLOR]" )
   file = ii11i1iIII ( Oo0oO0ooo )
   iI1iI1I1i1I = open ( ooOo , "w" )
   iI1iI1I1i1I . write ( file )
   iI1iI1I1i1I . close ( )
   if 3 - 3: i1IIi11111i % i1IIi11111i
   OOoOO0o0o0 = 100 * 4 / int ( o0O0o0 )
   I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U files.[/COLOR]" , "[COLOR lime]File 4 of " + str ( o0O0o0 ) + "[/COLOR]" )
   OooOo0ooo = o00oo0 ( )
   iI1iI1I1i1I = open ( IiIi11iIIi1Ii , "w" )
   iI1iI1I1i1I . write ( OooOo0ooo )
   iI1iI1I1i1I . close ( )
   if 83 - 83: i1I1ii1II1iII + IiIi1Iii1I1
   OoOOo0OOoO = 4
   if 73 - 73: iIIIiI11
   for III1ii1iII in Ii1IOo0o0 :
    OoOOo0OOoO = OoOOo0OOoO + 1
    OOoOO0o0o0 = 100 * int ( OoOOo0OOoO ) / int ( o0O0o0 )
    I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the menu files.[/COLOR]" , "[COLOR lime]File " + str ( OoOOo0OOoO ) + " of " + str ( o0O0o0 ) + "[/COLOR]" )
    name = re . compile ( '<title>(.+?)</title>' ) . findall ( III1ii1iII ) [ 0 ]
    url = re . compile ( '<folder>(.+?)</folder>' ) . findall ( III1ii1iII ) [ 0 ]
    if 42 - 42: i11iIiiIii * OoOO / I11i1i11i1I . i11iIiiIii % oo0ooO0oOOOOo
    file = ii11i1iIII ( url )
    o0OOoo0OO0OOO = xbmc . translatePath ( os . path . join ( Oooo000o , name + ".xml" ) )
    if 41 - 41: iII111ii / Ii1I
    iI1iI1I1i1I = open ( o0OOoo0OO0OOO , "w" )
    iI1iI1I1i1I . write ( file )
    iI1iI1I1i1I . close ( )
    if 51 - 51: oo0ooO0oOOOOo % oooO0oo0oOOOO
   I11i11Ii . close ( )
   return
 else :
  if 60 - 60: oooO0oo0oOOOO / OOO0O . oooO0oo0oOOOO / IiIi1Iii1I1 . iII111ii
  I11i11Ii . create ( Oo0Ooo , "Getting files to make ECHO Streams AWESOME!" )
  if 92 - 92: Oooo0000 + IiIi1Iii1I1 * i111IiI % oooO0oo0oOOOO
  try :
   shutil . rmtree ( Oooo000o )
   os . makedirs ( Oooo000o )
  except : pass
  if 42 - 42: ooO00oOoo
  I11i11Ii . update ( 0 , "" , "[COLOR dodgerblue]Contacting ECHO Servers.[/COLOR]" )
  I11I11i1I = ii11i1iIII ( O0oO )
  I11I11i1I = I11I11i1I . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
  Ii1IOo0o0 = re . compile ( '<item>(.+?)</item>' ) . findall ( I11I11i1I )
  iIIiIi1 = len ( Ii1IOo0o0 )
  o0O0o0 = iIIiIi1 + 4
  if 76 - 76: oooO0oo0oOOOO * iIIIiI11 % IiIi1Iii1I1
  OOoOO0o0o0 = 100 * 1 / int ( o0O0o0 )
  I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U Cleaner file.[/COLOR]" , "[COLOR lime]File 1 of " + str ( o0O0o0 ) + "[/COLOR]" )
  file = ii11i1iIII ( o00 )
  iI1iI1I1i1I = open ( Oo0O , "w" )
  iI1iI1I1i1I . write ( file )
  iI1iI1I1i1I . close ( )
  if 57 - 57: OoOO - o0000oOoOoO0o / IiIi1Iii1I1 - Ii1I * OoOO0ooOOoo0O % i1I1ii1II1iII
  OOoOO0o0o0 = 100 * 2 / int ( o0O0o0 )
  I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U Replacer file.[/COLOR]" , "[COLOR lime]File 2 of " + str ( o0O0o0 ) + "[/COLOR]" )
  file = ii11i1iIII ( oo00 )
  iI1iI1I1i1I = open ( IiI , "w" )
  iI1iI1I1i1I . write ( file )
  iI1iI1I1i1I . close ( )
  if 68 - 68: OoOO0ooOOoo0O * oo0ooO0oOOOOo % Oooo0000 - iII111ii
  OOoOO0o0o0 = 100 * 3 / int ( o0O0o0 )
  I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the Blacklist file.[/COLOR]" , "[COLOR lime]File 3 of " + str ( o0O0o0 ) + "[/COLOR]" )
  file = ii11i1iIII ( Oo0oO0ooo )
  iI1iI1I1i1I = open ( ooOo , "w" )
  iI1iI1I1i1I . write ( file )
  iI1iI1I1i1I . close ( )
  if 34 - 34: IiIi1Iii1I1 . OoOO * Oooo0000 * oo / IiIi1Iii1I1 / I11i1i11i1I
  OOoOO0o0o0 = 100 * 4 / int ( o0O0o0 )
  I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the M3U files.[/COLOR]" , "[COLOR lime]File 4 of " + str ( o0O0o0 ) + "[/COLOR]" )
  OooOo0ooo = o00oo0 ( )
  iI1iI1I1i1I = open ( IiIi11iIIi1Ii , "w" )
  iI1iI1I1i1I . write ( OooOo0ooo )
  iI1iI1I1i1I . close ( )
  if 78 - 78: ooO00oOoo - i1IIi11111i / Oooo0000
  OoOOo0OOoO = 4
  if 10 - 10: iIIIiI11 + ooO00oOoo * I11i1i11i1I + OoOO / IiIi1Iii1I1 / I11i1i11i1I
  for III1ii1iII in Ii1IOo0o0 :
   OoOOo0OOoO = OoOOo0OOoO + 1
   OOoOO0o0o0 = 100 * int ( OoOOo0OOoO ) / int ( o0O0o0 )
   I11i11Ii . update ( OOoOO0o0o0 , "" , "[COLOR dodgerblue]Downloading the menu files.[/COLOR]" , "[COLOR lime]File " + str ( OoOOo0OOoO ) + " of " + str ( o0O0o0 ) + "[/COLOR]" )
   name = re . compile ( '<title>(.+?)</title>' ) . findall ( III1ii1iII ) [ 0 ]
   url = re . compile ( '<folder>(.+?)</folder>' ) . findall ( III1ii1iII ) [ 0 ]
   if 42 - 42: oooO0oo0oOOOO
   file = ii11i1iIII ( url )
   o0OOoo0OO0OOO = xbmc . translatePath ( os . path . join ( Oooo000o , name + ".xml" ) )
   if 38 - 38: OOO0O + i1I1ii1II1iII % O00O0O0O0 % Oooo0000 - i111IiI / OoOO0ooOOoo0O
   iI1iI1I1i1I = open ( o0OOoo0OO0OOO , "w" )
   iI1iI1I1i1I . write ( file )
   iI1iI1I1i1I . close ( )
   if 73 - 73: i1IIi11111i * Ii1I - i11iIiiIii
  I11i11Ii . close ( )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "[COLOR white]All ECHO Streams files have been refreshed.[/COLOR]" , "[COLOR lime]All lists are now up-to-date.[/COLOR]" )
  if 85 - 85: i111IiI % iIIIiI11 + oo0ooO0oOOOOo / i1IIi11111i . oo + OOO0O
def o00oo0 ( ) :
 if 62 - 62: i11iIiiIii + i11iIiiIii - i1IIi11111i
 I1 = open ( Oo0O )
 OooooO0oOOOO = I1 . read ( )
 o0O00oOOoo = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( OooooO0oOOOO )
 if 18 - 18: i111IiI + iII111ii - Ii1I
 o00O = open ( IiI )
 i1Ii1i1I11Iii = o00O . read ( )
 I1i1i1 = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( i1Ii1i1I11Iii )
 if 73 - 73: Ii1I * iIIIiI11 + i111IiI + O00O0O0O0
 list = ""
 Ii = ii11i1iIII ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 Ii1IOo0o0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( Ii )
 for OoOO000 in Ii1IOo0o0 :
  list = list + OoOO000 + "\n"
 list = list . replace ( "<br />" , "\n" )
 if 100 - 100: IiIi1Iii1I1 + OOO0O + OOO0O
 if 9 - 9: oo0ooO0oOOOOo % OoOO0ooOOoo0O . oo % oo0ooO0oOOOOo
 if 32 - 32: i11iIiiIii
 if 31 - 31: OoOO / O0OOo / I11i1i11i1I
 if 41 - 41: ooO00oOoo
 if 10 - 10: ooO00oOoo / ooO00oOoo / IiIi1Iii1I1 . IiIi1Iii1I1
 if 98 - 98: ooO00oOoo / oooO0oo0oOOOO . Ii1I + O0OOo
 if 43 - 43: i1I1ii1II1iII . oo / I11i1i11i1I
 if 20 - 20: oooO0oo0oOOOO
 if 95 - 95: iIIIiI11 - oooO0oo0oOOOO
 if 34 - 34: O00O0O0O0 * oooO0oo0oOOOO . o0000oOoOoO0o * O00O0O0O0 / O00O0O0O0
 if 30 - 30: I11i1i11i1I + ooO00oOoo / ooO00oOoo % I11i1i11i1I . I11i1i11i1I
 if 55 - 55: O00O0O0O0 - oo0ooO0oOOOOo + i1I1ii1II1iII + iIIIiI11 % i111IiI
 if 41 - 41: o0000oOoOoO0o - oo0ooO0oOOOOo - i111IiI
 if 8 - 8: O0OOo + IiIi1Iii1I1 - i1IIi11111i % ooO00oOoo % i1IIi11111i * oo
 if 9 - 9: ooO00oOoo - i11iIiiIii - OOO0O * i111IiI + O00O0O0O0
 return list
 if 44 - 44: i1I1ii1II1iII
def OOOO0OOO ( ) :
 if 3 - 3: O0OOo
 i11 ( )
 if 97 - 97: IiIi1Iii1I1
 Oo0oOOo = ''
 OO = xbmc . Keyboard ( Oo0oOOo , 'Enter Search Term' )
 OO . doModal ( )
 if OO . isConfirmed ( ) :
  Oo0oOOo = OO . getText ( )
  if len ( Oo0oOOo ) > 1 :
   i11Iiii = Oo0oOOo
   iIii11I ( "search" , i11Iiii , iiiii )
  else : quit ( )
  if 15 - 15: o0000oOoOoO0o + Oooo0000
def iii1i1I1i1 ( ) :
 if 25 - 25: I11i1i11i1I . O00O0O0O0
 if not os . path . exists ( ooo0OO ) :
  try :
   os . makedirs ( ooo0OO )
  except : pass
 if os . path . exists ( I1IiiI ) :
  try :
   os . remove ( I1IiiI )
  except : pass
 else :
  try :
   open ( I1IiiI , 'w' )
  except : pass
  if 24 - 24: oo / i11iIiiIii + oo
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 20 - 20: oo0ooO0oOOOOo + i111IiI / Ii1I % OoOO
def i11 ( ) :
 if 88 - 88: Oooo0000 / i1I1ii1II1iII
 if os . path . exists ( O00ooooo00 ) :
  OOOOO0O00 = Iii ( heading = "Please Enter Your Password" )
  if ( not OOOOO0O00 ) :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  iIIiIiI1I1 = OOOOO0O00
  if 56 - 56: oooO0oo0oOOOO . Ii1I + ooO00oOoo
  i1II1I1Iii1 = open ( O00ooooo00 , "r" )
  iiI11Iii = re . compile ( r'<password>(.+?)</password>' )
  for O0o0O0 in i1II1I1Iii1 :
   file = iiI11Iii . findall ( O0o0O0 )
   for Ii1II1I11i1 in file :
    oOoooooOoO = base64 . b64decode ( Ii1II1I11i1 )
    if not oOoooooOoO == iIIiIiI1I1 :
     if not Ii1II1I11i1 == iIIiIiI1I1 :
      IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 33 - 33: i1I1ii1II1iII / O00O0O0O0 * Ii1I % i111IiI * IiIi1Iii1I1
def O0o ( ) :
 if 72 - 72: OOO0O % I11i1i11i1I + O0OOo / oo + iII111ii
 i11 ( )
 if 10 - 10: IiIi1Iii1I1 / O00O0O0O0 + i11iIiiIii / i111IiI
 O0ooo0O0oo0 = 0
 if not os . path . exists ( O00ooooo00 ) :
  O0ooo0O0oo0 = 1
  Ii1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  Ii1 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  i1II1I1Iii1 = open ( O00ooooo00 , "r" )
  iiI11Iii = re . compile ( r'<password>(.+?)</password>' )
  for O0o0O0 in i1II1I1Iii1 :
   file = iiI11Iii . findall ( O0o0O0 )
   for Ii1II1I11i1 in file :
    oOoooooOoO = base64 . b64decode ( Ii1II1I11i1 )
    O0ooo0O0oo0 = 1
    Ii1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    Ii1 ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( oOoooooOoO ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    Ii1 ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    Ii1 ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 74 - 74: OOO0O + Ii1I + o0000oOoOoO0o - o0000oOoOoO0o + i1I1ii1II1iII
 if O0ooo0O0oo0 == 0 :
  Ii1 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  Ii1 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 83 - 83: I11i1i11i1I - oooO0oo0oOOOO + OOO0O
 OooOoO0Oo = iiIIiIiIi ( )
 if 5 - 5: i111IiI
 if OooOoO0Oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif OooOoO0Oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 46 - 46: iII111ii
def ii1iIi1iIiI1i ( ) :
 if 40 - 40: o0000oOoOoO0o % OOO0O
 OOOOO0O00 = Iii ( heading = "Please Set Password" )
 if ( not OOOOO0O00 ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 iIIiIiI1I1 = OOOOO0O00
 if 71 - 71: Oooo0000
 OOOOO0O00 = Iii ( heading = "Please Confirm Your Password" )
 if ( not OOOOO0O00 ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 ii111IiiI1 = OOOOO0O00
 if 11 - 11: OoOO * i111IiI
 if not os . path . exists ( O00ooooo00 ) :
  if not os . path . exists ( II1 ) :
   os . makedirs ( II1 )
  open ( O00ooooo00 , 'w' )
  if 76 - 76: O00O0O0O0
  if iIIiIiI1I1 == ii111IiiI1 :
   II = base64 . b64encode ( iIIiIiI1I1 )
   I1i1i1 = open ( O00ooooo00 , 'w' )
   I1i1i1 . write ( '<password>' + str ( II ) + '</password>' )
   I1i1i1 . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( O00ooooo00 )
  if 45 - 45: OoOO0ooOOoo0O - OOO0O + Ii1I * i111IiI . I11i1i11i1I
  if iIIiIiI1I1 == ii111IiiI1 :
   II = base64 . b64encode ( iIIiIiI1I1 )
   I1i1i1 = open ( O00ooooo00 , 'w' )
   I1i1i1 . write ( '<password>' + str ( II ) + '</password>' )
   I1i1i1 . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 39 - 39: OoOO / Ii1I / oo - i111IiI - iIIIiI11 % OOO0O
def I1ii11Ii ( ) :
 if 50 - 50: O00O0O0O0 - IiIi1Iii1I1 * iII111ii . I11i1i11i1I
 try :
  os . remove ( O00ooooo00 )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 37 - 37: O00O0O0O0 % i11iIiiIii % i1I1ii1II1iII . Ii1I . i111IiI
def iiIIiIiIi ( ) :
 if 51 - 51: O0OOo - Ii1I % oo - i1I1ii1II1iII
 I1II = xbmc . getInfoLabel ( "System.BuildVersion" )
 Oo000ooOOO = float ( I1II [ : 4 ] )
 if Oo000ooOOO >= 11.0 and Oo000ooOOO <= 11.9 :
  Ii11i1I11i = 'Eden'
 elif Oo000ooOOO >= 12.0 and Oo000ooOOO <= 12.9 :
  Ii11i1I11i = 'Frodo'
 elif Oo000ooOOO >= 13.0 and Oo000ooOOO <= 13.9 :
  Ii11i1I11i = 'Gotham'
 elif Oo000ooOOO >= 14.0 and Oo000ooOOO <= 14.9 :
  Ii11i1I11i = 'Helix'
 elif Oo000ooOOO >= 15.0 and Oo000ooOOO <= 15.9 :
  Ii11i1I11i = 'Isengard'
 elif Oo000ooOOO >= 16.0 and Oo000ooOOO <= 16.9 :
  Ii11i1I11i = 'Jarvis'
 elif Oo000ooOOO >= 17.0 and Oo000ooOOO <= 17.9 :
  Ii11i1I11i = 'Krypton'
 else : Ii11i1I11i = "Decline"
 if 13 - 13: iII111ii / i11iIiiIii % i1I1ii1II1iII % oo0ooO0oOOOOo . I11i1i11i1I
 return Ii11i1I11i
 if 8 - 8: Oooo0000 + ooO00oOoo - i1I1ii1II1iII
def IiIi1iIIi1 ( name , url , iconimage ) :
 if 86 - 86: oo0ooO0oOOOOo * oooO0oo0oOOOO + oo0ooO0oOOOOo + i1I1ii1II1iII
 try :
  name , url = url . split ( '|SPLIT|' )
 except : pass
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 8 - 8: IiIi1Iii1I1 - iIIIiI11 / O00O0O0O0
 oo0oOoo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , oo0oOoo , False )
 if 57 - 57: Oooo0000 - I11i1i11i1I
def oOo ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 50 - 50: IiIi1Iii1I1 / o0000oOoOoO0o % O0OOo . oooO0oo0oOOOO / iIIIiI11
def ii11i1iIII ( url ) :
 if 88 - 88: OOO0O . oo0ooO0oOOOOo * i1IIi11111i . Oooo0000 / O00O0O0O0 . oo0ooO0oOOOOo
 II1I1iii1iII = urllib2 . Request ( url )
 II1I1iii1iII . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 iIIIIi1iiIi1 = urllib2 . urlopen ( II1I1iii1iII )
 I11I11i1I = iIIIIi1iiIi1 . read ( )
 iIIIIi1iiIi1 . close ( )
 return I11I11i1I
 if 97 - 97: oooO0oo0oOOOO / iIIIiI11
def Iii ( default = "" , heading = "" , hidden = False ) :
 OO = xbmc . Keyboard ( default , heading , hidden )
 if 71 - 71: i1I1ii1II1iII / o0000oOoOoO0o . I11i1i11i1I % OoOO0ooOOoo0O . Oooo0000
 OO . doModal ( )
 if ( OO . isConfirmed ( ) ) :
  return unicode ( OO . getText ( ) , "utf-8" )
 return default
 if 41 - 41: o0000oOoOoO0o * i1I1ii1II1iII / OoOO0ooOOoo0O . OOO0O
def oOOoO0 ( name , url , mode , iconimage , fanartimage ) :
 if 83 - 83: iIIIiI11 . Ii1I / ooO00oOoo / OOO0O - i1I1ii1II1iII
 oO0oO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 i1i1IIIIi1i = True
 oo0oOoo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oo0oOoo . setProperty ( "fanart_Image" , fanartimage )
 oo0oOoo . setProperty ( "icon_Image" , iconimage )
 i1i1IIIIi1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO0oO0 , listitem = oo0oOoo , isFolder = True )
 return i1i1IIIIi1i
 if 7 - 7: OoOO + iIIIiI11 * i11iIiiIii / OoOO0ooOOoo0O + iIIIiI11 - ooO00oOoo
def Ii1 ( name , url , mode , iconimage , fanartimage ) :
 if 3 - 3: o0000oOoOoO0o / i1I1ii1II1iII / i11iIiiIii * o0000oOoOoO0o - i1I1ii1II1iII
 oO0oO0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 i1i1IIIIi1i = True
 oo0oOoo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oo0oOoo . setProperty ( "fanart_Image" , fanartimage )
 oo0oOoo . setProperty ( "icon_Image" , iconimage )
 i1i1IIIIi1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oO0oO0 , listitem = oo0oOoo , isFolder = False )
 return i1i1IIIIi1i
 if 42 - 42: i1I1ii1II1iII . OoOO0ooOOoo0O . i1IIi11111i * oo
def O0OOO0OOooo00 ( ) :
 I111iIi1 = [ ]
 oo00O00oO000o = sys . argv [ 2 ]
 if len ( oo00O00oO000o ) >= 2 :
  OO0OoO0o00 = sys . argv [ 2 ]
  OOo00OoO = OO0OoO0o00 . replace ( '?' , '' )
  if ( OO0OoO0o00 [ len ( OO0OoO0o00 ) - 1 ] == '/' ) :
   OO0OoO0o00 = OO0OoO0o00 [ 0 : len ( OO0OoO0o00 ) - 2 ]
  iIi1 = OOo00OoO . split ( '&' )
  I111iIi1 = { }
  for OoOOo0OOoO in range ( len ( iIi1 ) ) :
   i11iiI1111 = { }
   i11iiI1111 = iIi1 [ OoOOo0OOoO ] . split ( '=' )
   if ( len ( i11iiI1111 ) ) == 2 :
    I111iIi1 [ i11iiI1111 [ 0 ] ] = i11iiI1111 [ 1 ]
    if 97 - 97: ooO00oOoo * oooO0oo0oOOOO . OoOO
 return I111iIi1
 if 16 - 16: O00O0O0O0 % OoOO0ooOOoo0O - OOO0O * i111IiI * I11i1i11i1I / OoOO0ooOOoo0O
OO0OoO0o00 = O0OOO0OOooo00 ( ) ; oo0oooooO0 = None ; i11Iiii = None ; I11 = None ; iI = None ; o0oO00oO0o0o0 = None
try : oo0oooooO0 = urllib . unquote_plus ( OO0OoO0o00 [ "name" ] )
except : pass
try : i11Iiii = urllib . unquote_plus ( OO0OoO0o00 [ "url" ] )
except : pass
try : I11 = int ( OO0OoO0o00 [ "mode" ] )
except : pass
try : iI = urllib . unquote_plus ( OO0OoO0o00 [ "iconimage" ] )
except : pass
try : o0oO00oO0o0o0 = urllib . quote_plus ( OO0OoO0o00 [ "fanartimage" ] )
except : pass
if 17 - 17: oo0ooO0oOOOOo . iII111ii - i1I1ii1II1iII + Ii1I / OoOO / i11iIiiIii
if I11 == None or i11Iiii == None or len ( i11Iiii ) < 1 : Oooo ( )
elif I11 == 1 : Oooo ( )
elif I11 == 2 : iIii11I ( oo0oooooO0 , i11Iiii , iI )
elif I11 == 3 : IiIi1iIIi1 ( oo0oooooO0 , i11Iiii , iI )
elif I11 == 4 : OOOO0OOO ( )
elif I11 == 5 : iii1i1I1i1 ( )
elif I11 == 6 : OOo0oO00ooO00 ( )
elif I11 == 7 : IIIIii1I ( i11Iiii )
elif I11 == 8 : ooO0O ( oo0oooooO0 , i11Iiii )
elif I11 == 900 : O0o ( )
elif I11 == 901 : ii1iIi1iIiI1i ( )
elif I11 == 902 : I1ii11Ii ( )
elif I11 == 999 : quit ( )
if 39 - 39: iII111ii * ooO00oOoo + OoOO - iII111ii + OOO0O
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )