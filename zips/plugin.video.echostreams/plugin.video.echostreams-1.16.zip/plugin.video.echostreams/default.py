import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64 , shutil , time
from resources . lib . modules import checker
from resources . lib . modules import cache
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' , OO0o ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( II1 , 'controls.txt' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'hd.txt' ) )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
Oooo000o = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp' ) )
IiIi11iIIi1Ii = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/m3u.xml' ) )
Oo0O = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/cleaner.xml' ) )
IiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/replacer.xml' ) )
ooOo = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'temp/blacklist.xml' ) )
if 91 - 91: Ii1I . OoOO + OoOO0ooOOoo0O + o0000oOoOoO0o * i1I1ii1II1iII % oooO0oo0oOOOO
O0oO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
o0oO0 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
oo00 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
o00 = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
Oo0oO0ooo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI=' )
if 56 - 56: ooO00oOoo - O0OOo
cache . check ( )
if 8 - 8: Oooo0000 * i1IIi11111i / I11i1i11i1I % oo / OOO0O / oo0ooO0oOOOOo
def oO000OoOoo00o ( ) :
 if 31 - 31: i111IiI + iIIIiI11 . iII111ii
 i1iIIi1 ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 50 - 50: IiIi1Iii1I1 - O00O0O0O0
 ooO0O ( '[COLOR darkgray]############################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 if 63 - 63: i1I1ii1II1iII . i1I1ii1II1iII
 if os . path . exists ( I1IiiI ) :
  ooO0O ( '[COLOR white]Only Display HD Links - [COLOR lime][B]ON[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 else : ooO0O ( '[COLOR white]Only Display HD Links - [COLOR red][B]OFF[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 if 32 - 32: o0000oOoOoO0o . oo0ooO0oOOOOo % O0OOo . i1IIi11111i
 if not os . path . exists ( O00ooooo00 ) :
  i1iIIi1 ( "[COLOR white]Parental Controls - [COLOR red][B]OFF[/B][/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  i1iIIi1 ( "[COLOR white]Parental Controls - [COLOR lime][B]ON[/B][/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
  if 42 - 42: IiIi1Iii1I1 + I11i1i11i1I
 ooO0O ( '[COLOR darkgray]############################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 if 70 - 70: ooO00oOoo % ooO00oOoo . iII111ii % O0OOo * i1IIi11111i % oo
 iiI1IiI = II ( O0oO )
 iiI1IiI = iiI1IiI . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 ooOoOoo0O = re . compile ( '<item>(.+?)</item>' ) . findall ( iiI1IiI )
 for OooO0 in ooOoOoo0O :
  II11iiii1Ii = re . compile ( '<title>(.+?)</title>' ) . findall ( OooO0 ) [ 0 ]
  OO0oOoo = re . compile ( '<folder>(.+?)</folder>' ) . findall ( OooO0 ) [ 0 ]
  O0o0Oo = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( OooO0 ) [ 0 ]
  Oo00OOOOO = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( OooO0 ) [ 0 ]
  if 85 - 85: O00O0O0O0 . iIIIiI11 - O0OOo % O00O0O0O0 % i1I1ii1II1iII
  i1iIIi1 ( '[COLOR white]' + II11iiii1Ii + '[/COLOR]' , OO0oOoo , 2 , O0o0Oo , Oo00OOOOO )
  if 81 - 81: O0OOo + i1I1ii1II1iII % iIIIiI11 * Ii1I
 oOOo0oo = o0oo0o0O00OO ( )
 if 80 - 80: o0000oOoOoO0o
 if oOOo0oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oOOo0oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 70 - 70: Oooo0000 - i1IIi11111i
def I1iii ( name , url , iconimage ) :
 if 20 - 20: i1IIi11111i
 I11i11Ii . create ( Oo0Ooo , "[COLOR dodgerblue]Getting the list of AWESOME streams![/COLOR]" , "[COLOR lime]We wont be long, we promise.[/COLOR]" )
 oO00 = name
 if 53 - 53: OoOO0ooOOoo0O . o0000oOoOoO0o
 if "adult" in name . lower ( ) :
  ii1I1i1I ( )
 OOoo0O0 = [ ]
 if 41 - 41: oo
 ii1i1I1i = 0
 if 53 - 53: iII111ii + oooO0oo0oOOOO * oo
 if not "search" in name . lower ( ) :
  OooOooooOOoo0 = II ( url )
  o00OO0OOO0 = re . compile ( '<term>(.+?)</term>' , re . DOTALL ) . findall ( OooOooooOOoo0 )
  for oo0 in o00OO0OOO0 :
   oo0 = oo0 . replace ( ' ' , '' )
   oo0 = oo0 . lower ( )
   OOoo0O0 . append ( oo0 )
 else :
  oo0 = url
  oo0 = oo0 . lower ( )
  try :
   o00OooOooo = oo0 . split ( ' ' )
   for oo0 in o00OooOooo :
    OOoo0O0 . append ( oo0 )
    ii1i1I1i = 1
  except :
   OOoo0O0 . append ( url . lower ( ) )
   ii1i1I1i = 0
   if 97 - 97: O00O0O0O0 - OOO0O * i11iIiiIii / Oooo0000 % IiIi1Iii1I1 - OoOO0ooOOoo0O
   if 59 - 59: Ii1I + oooO0oo0oOOOO + iII111ii % oooO0oo0oOOOO
 o0OOoo0OO0OOO = [ ]
 iI1iI1I1i1I = [ ]
 iIi11Ii1 = [ ]
 Ii11iII1 = [ ]
 if 51 - 51: i1I1ii1II1iII * O0OOo % i1IIi11111i * i1I1ii1II1iII % I11i1i11i1I / O00O0O0O0
 iIIIIii1 = II ( oo00 )
 ooOoOoo0O = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( iIIIIii1 )
 if 58 - 58: i11iIiiIii % oo0ooO0oOOOOo
 OO00Oo = II ( o00 )
 O0OOO0OOoO0O = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( OO00Oo )
 if 70 - 70: iII111ii * ooO00oOoo * oo0ooO0oOOOOo / i111IiI
 oO = II ( Oo0oO0ooo )
 OOoO0O00o0 = re . compile ( '<item>(.+?)</item>' , re . DOTALL ) . findall ( oO )
 if 30 - 30: i1IIi11111i . i111IiI - OoOO0ooOOoo0O
 Ii1iIiii1 = 0
 for oo0 in OOoO0O00o0 :
  OOO = re . compile ( '<cat>(.+?)</cat>' ) . findall ( oo0 ) [ 0 ]
  if OOO . lower ( ) in oO00 . lower ( ) :
   Oo0oOOo = OOO
   Ii1iIiii1 = 1
 if Ii1iIiii1 == 0 : Oo0oOOo = "null"
 if 58 - 58: i1I1ii1II1iII * OOO0O * I11i1i11i1I / OOO0O
 oO0o0OOOO = II ( base64 . b64decode ( b'aHR0cDovL2R2YnNhdC5ydS9zbWYvaW5kZXgucGhwP2FjdGlvbj1yZWNlbnQ7c3RhcnQ9MA==' ) )
 O0O0OoOO0 = re . compile ( '#EXTM3U(.+?)</div>' , re . DOTALL ) . findall ( oO0o0OOOO )
 I11i11Ii . update ( 0 )
 iiiI1I11i1 = len ( O0O0OoOO0 )
 IIi1i11111 = 0
 for ooOO00O00oo in O0O0OoOO0 :
  IIi1i11111 = IIi1i11111 + 1
  I1ii11iI = 100 * int ( IIi1i11111 ) / int ( iiiI1I11i1 )
  I11i11Ii . update ( I1ii11iI , "" , "" , "[COLOR yellowgreen]Getting links from list " + str ( IIi1i11111 ) + " of " + str ( iiiI1I11i1 ) + "[/COLOR]" )
  ooOO00O00oo = ooOO00O00oo . replace ( '<br />' , '\n' ) . replace ( '<br/>' , '\n' )
  ooOO00O00oo = ooOO00O00oo . replace ( '#AAASTREAM:' , '#A:' )
  ooOO00O00oo = ooOO00O00oo . replace ( '#EXTINF:' , '#A:' )
  IIi1i = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( ooOO00O00oo )
 I1I1iIiII1 = [ ]
 for i11i1I1 , ii1I , url in IIi1i :
  Oo0ooOo0o = { "params" : i11i1I1 , "display_name" : ii1I , "url" : url }
  I1I1iIiII1 . append ( Oo0ooOo0o )
 Ii1i1 = [ ]
 for iiIii in I1I1iIiII1 :
  Oo0ooOo0o = { "display_name" : iiIii [ "display_name" ] , "url" : iiIii [ "url" ] }
  IIi1i = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIii [ "params" ] )
  for ooo0O , oOoO0o00OO0 in IIi1i :
   Oo0ooOo0o [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oOoO0o00OO0 . strip ( )
  Ii1i1 . append ( Oo0ooOo0o )
  if 7 - 7: OOO0O + IiIi1Iii1I1 + Ii1I
 for iiIii in Ii1i1 :
  name = Ii ( iiIii [ "display_name" ] )
  url = Ii ( iiIii [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if 64 - 64: O00O0O0O0 / Oooo0000 - Ii1I - oo0ooO0oOOOOo
  if ii1i1I1i == 1 :
   O0oOoOOOoOO = 0
   for ii1ii11IIIiiI in o00OooOooo :
    if not ii1ii11IIIiiI in name . lower ( ) :
     O0oOoOOOoOO = 1
   if O0oOoOOOoOO == 0 :
    o0OOoo0OO0OOO . append ( name )
    iI1iI1I1i1I . append ( url )
    Ii11iII1 = list ( zip ( o0OOoo0OO0OOO , iI1iI1I1i1I ) )
  else :
   o0OOoo0OO0OOO . append ( name )
   iI1iI1I1i1I . append ( url )
   Ii11iII1 = list ( zip ( o0OOoo0OO0OOO , iI1iI1I1i1I ) )
 O00OOOoOoo0O = sorted ( Ii11iII1 )
 O000OOo00oo = sorted ( OOoo0O0 )
 if 71 - 71: i11iIiiIii + iII111ii
 oOo = [ ]
 oOO00Oo = [ ]
 i1iIIIi1i = [ ]
 iI1iIIiiii = 0
 if 26 - 26: oo0ooO0oOOOOo . OoOO0ooOOoo0O
 if Oo0oOOo != 'null' :
  if 39 - 39: iIIIiI11 - Ii1I % i11iIiiIii * IiIi1Iii1I1 . iII111ii
  OOooo0O00o = re . compile ( '<cat>' + re . escape ( Oo0oOOo ) + '</cat>(.+?)</item>' , re . DOTALL ) . findall ( oO ) [ 0 ]
  if 85 - 85: i1IIi11111i - ooO00oOoo
  o00OO0OOO0 = re . compile ( '<name>(.+?)</name>' ) . findall ( OOooo0O00o )
  if 32 - 32: OoOO0ooOOoo0O / OoOO - i1IIi11111i
  for o00oooO0Oo in O000OOo00oo :
   for name , url in O00OOOoOoo0O :
    o0O0OOO0Ooo = name . replace ( ' ' , '' )
    if 45 - 45: Ii1I / i1IIi11111i
    if o00oooO0Oo . lower ( ) in o0O0OOO0Ooo . lower ( ) :
     if url not in str ( oOO00Oo ) :
      if 32 - 32: iIIIiI11 . iII111ii . iII111ii
      for OO00O0O in o00OO0OOO0 :
       if OO00O0O in name . lower ( ) :
        iI1iIIiiii = 1
      if iI1iIIiiii == 0 :
       for OooO0 in ooOoOoo0O :
        iii = re . compile ( '<old>(.+?)</old>' ) . findall ( OooO0 ) [ 0 ]
        oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( OooO0 ) [ 0 ]
        if oOooOOOoOo . lower ( ) == "null" : oOooOOOoOo = ""
        name = name . lower ( )
        iii = iii . lower ( )
        oOooOOOoOo = oOooOOOoOo . lower ( )
        name = name . replace ( iii , oOooOOOoOo )
       for i1Iii1i1I in O0OOO0OOoO0O :
        iii = re . compile ( '<old>(.+?)</old>' ) . findall ( i1Iii1i1I ) [ 0 ]
        oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( i1Iii1i1I ) [ 0 ]
        name = name . lower ( )
        iii = iii . lower ( )
        oOooOOOoOo = oOooOOOoOo . lower ( )
        name = name . replace ( iii , oOooOOOoOo )
        name = name . lstrip ( ' ' )
       oOo . append ( name )
       oOO00Oo . append ( url )
       i1iIIIi1i = list ( zip ( oOo , oOO00Oo ) )
      iI1iIIiiii = 0
 else :
  for o00oooO0Oo in O000OOo00oo :
   for name , url in O00OOOoOoo0O :
    o0O0OOO0Ooo = name . replace ( ' ' , '' )
    if 91 - 91: I11i1i11i1I + oooO0oo0oOOOO . OOO0O * I11i1i11i1I + oooO0oo0oOOOO * ooO00oOoo
    if o00oooO0Oo . lower ( ) in o0O0OOO0Ooo . lower ( ) :
     if url not in str ( oOO00Oo ) :
      if 80 - 80: iIIIiI11 % OOO0O % oo - ooO00oOoo + ooO00oOoo
      for OooO0 in ooOoOoo0O :
       iii = re . compile ( '<old>(.+?)</old>' ) . findall ( OooO0 ) [ 0 ]
       oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( OooO0 ) [ 0 ]
       if oOooOOOoOo . lower ( ) == "null" : oOooOOOoOo = ""
       name = name . replace ( iii , oOooOOOoOo )
      for i1Iii1i1I in O0OOO0OOoO0O :
       iii = re . compile ( '<old>(.+?)</old>' ) . findall ( i1Iii1i1I ) [ 0 ]
       oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( i1Iii1i1I ) [ 0 ]
       name = name . replace ( iii , oOooOOOoOo )
       if 19 - 19: Oooo0000 * o0000oOoOoO0o
      name = name . lstrip ( ' ' )
      oOo . append ( name )
      oOO00Oo . append ( url )
      i1iIIIi1i = list ( zip ( oOo , oOO00Oo ) )
      if 14 - 14: iIIIiI11
      if 11 - 11: iII111ii * oooO0oo0oOOOO . OoOO % OoOO0ooOOoo0O + iIIIiI11
 OOOoo0OOo0 = sorted ( i1iIIIi1i )
 if 47 - 47: IiIi1Iii1I1 + Oooo0000 * ooO00oOoo / O00O0O0O0 - iIIIiI11 % OoOO
 for name , url in OOOoo0OOo0 :
  if 26 - 26: I11i1i11i1I * iIIIiI11 . i1I1ii1II1iII * i111IiI
  II1iiiIi1 = name . title ( ) + '|SPLIT|' + url
  if 38 - 38: IiIi1Iii1I1
  if os . path . exists ( I1IiiI ) :
   if "hd" in name . lower ( ) :
    name = name . lower ( )
    name = name . replace ( 'hd' , '' )
    ooO0O ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , II1iiiIi1 , 3 , iiiii , O0O0OO0O0O0 )
  else :
   if "hd" in name . lower ( ) :
    name = name . lower ( )
    name = name . replace ( 'hd' , '' )
    ooO0O ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , II1iiiIi1 , 3 , iiiii , O0O0OO0O0O0 )
   else :
    ooO0O ( '[COLOR white]' + name . title ( ) + '[/COLOR]' , II1iiiIi1 , 3 , iiiii , O0O0OO0O0O0 )
    if 84 - 84: OoOO % iIIIiI11 / OoOO % oo0ooO0oOOOOo
 I11i11Ii . close ( )
 if 45 - 45: Ii1I
 oOOo0oo = o0oo0o0O00OO ( )
 if 26 - 26: oo0ooO0oOOOOo - OoOO - oooO0oo0oOOOO / O0OOo . Oooo0000 % OoOO
 if oOOo0oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oOOo0oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 91 - 91: i1IIi11111i . OoOO / oo + o0000oOoOoO0o
def I1i ( ) :
 if 53 - 53: I11i1i11i1I * Oooo0000 + O00O0O0O0 - i1I1ii1II1iII
 O0OOO0OOoO0O = ''
 I1I11i = xbmc . Keyboard ( O0OOO0OOoO0O , 'Enter Search Term' )
 I1I11i . doModal ( )
 if I1I11i . isConfirmed ( ) :
  O0OOO0OOoO0O = I1I11i . getText ( )
  if len ( O0OOO0OOoO0O ) > 1 :
   if not O0OOO0OOoO0O == base64 . b64decode ( 'Z2VuZXJhdGVpbmk=' ) :
    IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, incorrect password." )
    quit ( )
  else : quit ( )
  if 5 - 5: OoOO0ooOOoo0O % Oooo0000 % oo % iIIIiI11
 iiI1IiI = II ( o0oO0 )
 o00OO0OOO0 = re . compile ( '<link>(.+?)</link>' ) . findall ( iiI1IiI )
 if 7 - 7: i1I1ii1II1iII + OoOO0ooOOoo0O . IiIi1Iii1I1 . O00O0O0O0 - i1IIi11111i
 for OooO0 in o00OO0OOO0 :
  i1iIIi1 ( OooO0 , OooO0 , 7 , iiiii , O0O0OO0O0O0 )
  if 26 - 26: ooO00oOoo / iII111ii % OoOO / iII111ii + oo0ooO0oOOOOo
 oOOo0oo = o0oo0o0O00OO ( )
 if 90 - 90: Oooo0000 * IiIi1Iii1I1 + i1IIi11111i
 if oOOo0oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oOOo0oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 81 - 81: oo . i1IIi11111i % Ii1I / oooO0oo0oOOOO - oo
def Ii1I1i ( url ) :
 if 99 - 99: oo . iIIIiI11 + O00O0O0O0 % oo . i11iIiiIii % Ii1I
 OO00Oo = II ( o00 )
 OO00Oo = OO00Oo . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 O0OOO0OOoO0O = re . compile ( '<item>(.+?)</item>' ) . findall ( OO00Oo )
 if 78 - 78: I11i1i11i1I + OOO0O - IiIi1Iii1I1
 iIIIIii1 = II ( oo00 )
 iIIIIii1 = iIIIIii1 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 ooOoOoo0O = re . compile ( '<item>(.+?)</item>' ) . findall ( iIIIIii1 )
 if 38 - 38: i1IIi11111i - oo + OoOO / Oooo0000 % ooO00oOoo
 ooOO00O00oo = II ( url )
 ooOO00O00oo = ooOO00O00oo . replace ( '#AAASTREAM:' , '#A:' )
 ooOO00O00oo = ooOO00O00oo . replace ( '#EXTINF:' , '#A:' )
 IIi1i = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( ooOO00O00oo )
 I1I1iIiII1 = [ ]
 for i11i1I1 , ii1I , url in IIi1i :
  Oo0ooOo0o = { "params" : i11i1I1 , "display_name" : ii1I , "url" : url }
  I1I1iIiII1 . append ( Oo0ooOo0o )
 Ii1i1 = [ ]
 for iiIii in I1I1iIiII1 :
  Oo0ooOo0o = { "display_name" : iiIii [ "display_name" ] , "url" : iiIii [ "url" ] }
  IIi1i = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( iiIii [ "params" ] )
  for ooo0O , oOoO0o00OO0 in IIi1i :
   Oo0ooOo0o [ ooo0O . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = oOoO0o00OO0 . strip ( )
  Ii1i1 . append ( Oo0ooOo0o )
  if 57 - 57: O0OOo / O00O0O0O0
 for iiIii in Ii1i1 :
  II11iiii1Ii = Ii ( iiIii [ "display_name" ] )
  url = Ii ( iiIii [ "url" ] )
  url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  if 29 - 29: OoOO + Oooo0000 * O0OOo * OOO0O . oooO0oo0oOOOO * oooO0oo0oOOOO
  for OooO0 in ooOoOoo0O :
   iii = re . compile ( '<old>(.+?)</old>' ) . findall ( OooO0 ) [ 0 ]
   oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( OooO0 ) [ 0 ]
   if oOooOOOoOo . lower ( ) == "null" : oOooOOOoOo = ""
   II11iiii1Ii = II11iiii1Ii . replace ( iii , oOooOOOoOo )
  for i1Iii1i1I in O0OOO0OOoO0O :
   iii = re . compile ( '<old>(.+?)</old>' ) . findall ( i1Iii1i1I ) [ 0 ]
   oOooOOOoOo = re . compile ( '<new>(.+?)</new>' ) . findall ( i1Iii1i1I ) [ 0 ]
   II11iiii1Ii = II11iiii1Ii . replace ( iii , oOooOOOoOo )
  II11iiii1Ii = II11iiii1Ii . lstrip ( ' ' )
  if 7 - 7: iII111ii * IiIi1Iii1I1 % i111IiI - i1IIi11111i
  ooO0O ( II11iiii1Ii , url , 3 , iiiii , O0O0OO0O0O0 )
  if 13 - 13: i111IiI . i11iIiiIii
 I11i11Ii . close ( )
 if 56 - 56: I11i1i11i1I % Ii1I - oooO0oo0oOOOO
 oOOo0oo = o0oo0o0O00OO ( )
 if 100 - 100: i111IiI - Ii1I % oo * OOO0O + oooO0oo0oOOOO
 if oOOo0oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oOOo0oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 88 - 88: OoOO0ooOOoo0O - O0OOo * Ii1I * OoOO0ooOOoo0O . OoOO0ooOOoo0O
def I111iI ( ) :
 if 56 - 56: oooO0oo0oOOOO
 ii1I1i1I ( )
 if 54 - 54: IiIi1Iii1I1 / OOO0O . oo % iIIIiI11
 O0OOO0OOoO0O = ''
 I1I11i = xbmc . Keyboard ( O0OOO0OOoO0O , 'Enter Search Term' )
 I1I11i . doModal ( )
 if I1I11i . isConfirmed ( ) :
  O0OOO0OOoO0O = I1I11i . getText ( )
  if len ( O0OOO0OOoO0O ) > 1 :
   OO0oOoo = O0OOO0OOoO0O
   I1iii ( "search" , OO0oOoo , iiiii )
  else : quit ( )
  if 57 - 57: i11iIiiIii . I11i1i11i1I - i111IiI - oo + Oooo0000
def oO00oooOOoOo0 ( ) :
 if 74 - 74: OoOO * I11i1i11i1I + Oooo0000 / o0000oOoOoO0o / i1I1ii1II1iII . ooO00oOoo
 if not os . path . exists ( ooo0OO ) :
  try :
   os . makedirs ( ooo0OO )
  except : pass
 if os . path . exists ( I1IiiI ) :
  try :
   os . remove ( I1IiiI )
  except : pass
 else :
  try :
   open ( I1IiiI , 'w' )
  except : pass
  if 62 - 62: OoOO0ooOOoo0O * oooO0oo0oOOOO
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 58 - 58: Oooo0000 % i1IIi11111i
def ii1I1i1I ( ) :
 if 50 - 50: IiIi1Iii1I1 . i1IIi11111i
 if os . path . exists ( O00ooooo00 ) :
  ooO0OO = O000OOO ( heading = "Please Enter Your Password" )
  if ( not ooO0OO ) :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  IIo0o0O0O00oOOo = ooO0OO
  if 14 - 14: Oooo0000 + oo
  oo00oO0O0 = open ( O00ooooo00 , "r" )
  I11I11 = re . compile ( r'<password>(.+?)</password>' )
  for o000O0O in oo00oO0O0 :
   file = I11I11 . findall ( o000O0O )
   for I1i1i1iii in file :
    I1111i = base64 . b64decode ( I1i1i1iii )
    if not I1111i == IIo0o0O0O00oOOo :
     if not I1i1i1iii == IIo0o0O0O00oOOo :
      IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 14 - 14: OOO0O / i1IIi11111i
def iII11I1IiiIi ( ) :
 if 98 - 98: o0000oOoOoO0o / oo0ooO0oOOOOo
 ii1I1i1I ( )
 if 32 - 32: i111IiI * OoOO / OOO0O
 Ii1iIiii1 = 0
 if not os . path . exists ( O00ooooo00 ) :
  Ii1iIiii1 = 1
  ooO0O ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  ooO0O ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  oo00oO0O0 = open ( O00ooooo00 , "r" )
  I11I11 = re . compile ( r'<password>(.+?)</password>' )
  for o000O0O in oo00oO0O0 :
   file = I11I11 . findall ( o000O0O )
   for I1i1i1iii in file :
    I1111i = base64 . b64decode ( I1i1i1iii )
    Ii1iIiii1 = 1
    ooO0O ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    ooO0O ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( I1111i ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    ooO0O ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    ooO0O ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 38 - 38: O00O0O0O0 % i1I1ii1II1iII % oo0ooO0oOOOOo / O0OOo + Oooo0000 / o0000oOoOoO0o
 if Ii1iIiii1 == 0 :
  ooO0O ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  ooO0O ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 54 - 54: OoOO % I11i1i11i1I - OOO0O / oo - O0OOo . oo0ooO0oOOOOo
 oOOo0oo = o0oo0o0O00OO ( )
 if 11 - 11: I11i1i11i1I . O0OOo * iII111ii * OoOO0ooOOoo0O + O00O0O0O0
 if oOOo0oo == "Jarvis" :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 elif oOOo0oo == "Krypton" :
  xbmc . executebuiltin ( 'Container.SetViewMode(55)' )
 else : xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 33 - 33: Ii1I * i1IIi11111i - IiIi1Iii1I1 % IiIi1Iii1I1
def I11I ( ) :
 if 50 - 50: IiIi1Iii1I1 * i11iIiiIii * OoOO - i1I1ii1II1iII * i1IIi11111i * Oooo0000
 ooO0OO = O000OOO ( heading = "Please Set Password" )
 if ( not ooO0OO ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 IIo0o0O0O00oOOo = ooO0OO
 if 94 - 94: OoOO0ooOOoo0O + OoOO0ooOOoo0O . i1I1ii1II1iII + oo0ooO0oOOOOo / I11i1i11i1I % i111IiI
 ooO0OO = O000OOO ( heading = "Please Confirm Your Password" )
 if ( not ooO0OO ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 I1Ii1iiiiii1 = ooO0OO
 if 96 - 96: i11iIiiIii % OOO0O
 if not os . path . exists ( O00ooooo00 ) :
  if not os . path . exists ( II1 ) :
   os . makedirs ( II1 )
  open ( O00ooooo00 , 'w' )
  if 70 - 70: OoOO
  if IIo0o0O0O00oOOo == I1Ii1iiiiii1 :
   i11ii1iI = base64 . b64encode ( IIo0o0O0O00oOOo )
   i1I = open ( O00ooooo00 , 'w' )
   i1I . write ( '<password>' + str ( i11ii1iI ) + '</password>' )
   i1I . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( O00ooooo00 )
  if 42 - 42: i1IIi11111i + o0000oOoOoO0o - i111IiI / iII111ii
  if IIo0o0O0O00oOOo == I1Ii1iiiiii1 :
   i11ii1iI = base64 . b64encode ( IIo0o0O0O00oOOo )
   i1I = open ( O00ooooo00 , 'w' )
   i1I . write ( '<password>' + str ( i11ii1iI ) + '</password>' )
   i1I . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 9 - 9: Ii1I % Ii1I - i1IIi11111i
def OoO ( ) :
 if 12 - 12: Ii1I - i1IIi11111i
 try :
  os . remove ( O00ooooo00 )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 81 - 81: Oooo0000 - Oooo0000 . iIIIiI11
def o0oo0o0O00OO ( ) :
 if 73 - 73: oo0ooO0oOOOOo % i11iIiiIii - oooO0oo0oOOOO
 Ii1iI111II1I1 = xbmc . getInfoLabel ( "System.BuildVersion" )
 oOOOOoOO0o = float ( Ii1iI111II1I1 [ : 4 ] )
 if oOOOOoOO0o >= 11.0 and oOOOOoOO0o <= 11.9 :
  i1II1 = 'Eden'
 elif oOOOOoOO0o >= 12.0 and oOOOOoOO0o <= 12.9 :
  i1II1 = 'Frodo'
 elif oOOOOoOO0o >= 13.0 and oOOOOoOO0o <= 13.9 :
  i1II1 = 'Gotham'
 elif oOOOOoOO0o >= 14.0 and oOOOOoOO0o <= 14.9 :
  i1II1 = 'Helix'
 elif oOOOOoOO0o >= 15.0 and oOOOOoOO0o <= 15.9 :
  i1II1 = 'Isengard'
 elif oOOOOoOO0o >= 16.0 and oOOOOoOO0o <= 16.9 :
  i1II1 = 'Jarvis'
 elif oOOOOoOO0o >= 17.0 and oOOOOoOO0o <= 17.9 :
  i1II1 = 'Krypton'
 else : i1II1 = "Decline"
 if 25 - 25: IiIi1Iii1I1 / OoOO % iIIIiI11
 return i1II1
 if 42 - 42: i11iIiiIii * OoOO / I11i1i11i1I . i11iIiiIii % oo0ooO0oOOOOo
def i1iI ( name , url , iconimage ) :
 if 29 - 29: oooO0oo0oOOOO % OOO0O - oooO0oo0oOOOO / OOO0O . o0000oOoOoO0o
 try :
  name , url = url . split ( '|SPLIT|' )
 except : pass
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 31 - 31: IiIi1Iii1I1
 OOO0000oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , OOO0000oO , False )
 if 15 - 15: Oooo0000 % oooO0oo0oOOOO * oo0ooO0oOOOOo
def Ii ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 81 - 81: O00O0O0O0 - OoOO - o0000oOoOoO0o / IiIi1Iii1I1 - Ii1I * oo0ooO0oOOOOo
def II ( url ) :
 if 20 - 20: oo % iII111ii
 III1i1i11i = urllib2 . Request ( url )
 III1i1i11i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 ooOO00O00oo = urllib2 . urlopen ( III1i1i11i )
 iiI1IiI = ooOO00O00oo . read ( )
 ooOO00O00oo . close ( )
 return iiI1IiI
 if 100 - 100: oo / IiIi1Iii1I1 / I11i1i11i1I
def O000OOO ( default = "" , heading = "" , hidden = False ) :
 I1I11i = xbmc . Keyboard ( default , heading , hidden )
 if 78 - 78: ooO00oOoo - i1IIi11111i / Oooo0000
 I1I11i . doModal ( )
 if ( I1I11i . isConfirmed ( ) ) :
  return unicode ( I1I11i . getText ( ) , "utf-8" )
 return default
 if 10 - 10: iIIIiI11 + ooO00oOoo * I11i1i11i1I + OoOO / IiIi1Iii1I1 / I11i1i11i1I
def i1iIIi1 ( name , url , mode , iconimage , fanartimage ) :
 if 42 - 42: oooO0oo0oOOOO
 II1i11I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 ii1I1IIii11 = True
 OOO0000oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 OOO0000oO . setProperty ( "fanart_Image" , fanartimage )
 OOO0000oO . setProperty ( "icon_Image" , iconimage )
 ii1I1IIii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i11I , listitem = OOO0000oO , isFolder = True )
 return ii1I1IIii11
 if 67 - 67: iIIIiI11 + oo0ooO0oOOOOo / i1IIi11111i . oo + OOO0O
def ooO0O ( name , url , mode , iconimage , fanartimage ) :
 if 62 - 62: i11iIiiIii + i11iIiiIii - i1IIi11111i
 II1i11I = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 ii1I1IIii11 = True
 OOO0000oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 OOO0000oO . setProperty ( "fanart_Image" , fanartimage )
 OOO0000oO . setProperty ( "icon_Image" , iconimage )
 ii1I1IIii11 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = II1i11I , listitem = OOO0000oO , isFolder = False )
 return ii1I1IIii11
 if 28 - 28: iIIIiI11 . iIIIiI11 % OoOO * OoOO . i1IIi11111i / iIIIiI11
def iII1i1 ( ) :
 O0oOOoooOO0O = [ ]
 ooo00Ooo = sys . argv [ 2 ]
 if len ( ooo00Ooo ) >= 2 :
  i11i1I1 = sys . argv [ 2 ]
  Oo0o0O00 = i11i1I1 . replace ( '?' , '' )
  if ( i11i1I1 [ len ( i11i1I1 ) - 1 ] == '/' ) :
   i11i1I1 = i11i1I1 [ 0 : len ( i11i1I1 ) - 2 ]
  ii1 = Oo0o0O00 . split ( '&' )
  O0oOOoooOO0O = { }
  for I1i11 in range ( len ( ii1 ) ) :
   OO = { }
   OO = ii1 [ I1i11 ] . split ( '=' )
   if ( len ( OO ) ) == 2 :
    O0oOOoooOO0O [ OO [ 0 ] ] = OO [ 1 ]
    if 84 - 84: O00O0O0O0 % i111IiI + i11iIiiIii
 return O0oOOoooOO0O
 if 28 - 28: ooO00oOoo + O0OOo * OOO0O % oo . oo0ooO0oOOOOo % Ii1I
i11i1I1 = iII1i1 ( ) ; II11iiii1Ii = None ; OO0oOoo = None ; I1iiiiIii = None ; O0o0Oo = None ; iIiIiIiI = None
try : II11iiii1Ii = urllib . unquote_plus ( i11i1I1 [ "name" ] )
except : pass
try : OO0oOoo = urllib . unquote_plus ( i11i1I1 [ "url" ] )
except : pass
try : I1iiiiIii = int ( i11i1I1 [ "mode" ] )
except : pass
try : O0o0Oo = urllib . unquote_plus ( i11i1I1 [ "iconimage" ] )
except : pass
try : iIiIiIiI = urllib . quote_plus ( i11i1I1 [ "fanartimage" ] )
except : pass
if 30 - 30: IiIi1Iii1I1 . O00O0O0O0 * I11i1i11i1I
if I1iiiiIii == None or OO0oOoo == None or len ( OO0oOoo ) < 1 : oO000OoOoo00o ( )
elif I1iiiiIii == 1 : oO000OoOoo00o ( )
elif I1iiiiIii == 2 : I1iii ( II11iiii1Ii , OO0oOoo , O0o0Oo )
elif I1iiiiIii == 3 : i1iI ( II11iiii1Ii , OO0oOoo , O0o0Oo )
elif I1iiiiIii == 4 : I111iI ( )
elif I1iiiiIii == 5 : oO00oooOOoOo0 ( )
elif I1iiiiIii == 6 : I1i ( )
elif I1iiiiIii == 7 : Ii1I1i ( OO0oOoo )
elif I1iiiiIii == 8 : GET_M3U_DATA ( II11iiii1Ii , OO0oOoo )
elif I1iiiiIii == 900 : iII11I1IiiIi ( )
elif I1iiiiIii == 901 : I11I ( )
elif I1iiiiIii == 902 : OoO ( )
elif I1iiiiIii == 999 : quit ( )
if 17 - 17: oooO0oo0oOOOO . Ii1I + O0OOo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )