import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64
from resources . lib . modules import checker
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' , OO0o ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( II1 , 'controls.txt' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'hd.txt' ) )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
IiiIII111iI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
IiII = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
iI1Ii11111iIi = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
i1i1II = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI=' )
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( ) :
 if 43 - 43: O0OOo . II1Iiii1111i
 i1IIi11111i = OOOo0 + '|SPLIT|' + oO00oOo
 checker . check ( i1IIi11111i )
 if 74 - 74: Oo0o00o0Oo0 * ii11
 I1I1i1 ( )
 if 18 - 18: iiIIIIi1i1 / OOoOoo00oo - iI1 + OOooO % II1Iiii1111i - o00ooo0
 i11iiII ( "[COLOR white]Welcome to ECHO Streams[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "[COLOR white]Meet the team:[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "[COLOR white]ECHO Coder: @EchoCoder(Twitter)[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "[COLOR white]ECHO Blue: @Blue_Builds(Twitter)[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 I1iiiiI1iII ( "[COLOR dodgerblue][B]ENTER ADDON[/B][/COLOR]" , o0O , 1 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 if not os . path . exists ( O00ooooo00 ) :
  I1iiiiI1iII ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  I1iiiiI1iII ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 20 - 20: iIIIiiIIiiiIi + i11iIiiIii - ii11 % I1i1iI1i . i1oOo0OoO
def Ooo00O00O0O0O ( ) :
 if 90 - 90: Oo + O0OOo / o00 % Oo - i1
 I1iiiiI1iII ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 29 - 29: o00 / o0
 if os . path . exists ( I1IiiI ) :
  i11iiII ( '[COLOR white]Only Display HD Links - [COLOR lime][B]ON[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 else : i11iiII ( '[COLOR white]Only Display HD Links - [COLOR red][B]OFF[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 i11iiII ( '[COLOR darkgray]############################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 IiIIIiI1I1 = OoO000 ( o0O )
 IiIIIiI1I1 = IiIIIiI1I1 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 IIiiIiI1 = re . compile ( '<item>(.+?)</item>' ) . findall ( IiIIIiI1I1 )
 for iiIiIIi in IIiiIiI1 :
  ooOoo0O = re . compile ( '<title>(.+?)</title>' ) . findall ( iiIiIIi ) [ 0 ]
  OooO0 = re . compile ( '<folder>(.+?)</folder>' ) . findall ( iiIiIIi ) [ 0 ]
  II11iiii1Ii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iiIiIIi ) [ 0 ]
  OO0oOoo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( iiIiIIi ) [ 0 ]
  if 68 - 68: Oo0o00o0Oo0 + II1Iiii1111i . o0 - OOoOoo00oo % o0 - OOooO
  I1iiiiI1iII ( '[COLOR white]' + ooOoo0O + '[/COLOR]' , OooO0 , 2 , II11iiii1Ii , OO0oOoo )
  if 79 - 79: Oo0ooO0oo0oO + o0OO0 - iiIIIIi1i1
def oO00O00o0OOO0 ( name , url , iconimage ) :
 if 27 - 27: i1 % iIIIiiIIiiiIi * O0OOo + i11iIiiIii + i1oOo0OoO * iIIIiiIIiiiIi
 o0oo0o0O00OO = name
 if 80 - 80: iIIIiiIIiiiIi
 if "adult" in name . lower ( ) :
  I1I1i1 ( )
 oOOO0o0o = [ ]
 if 26 - 26: i1oOo0OoO
 if not "search" in name . lower ( ) :
  IiIIIiI1I1 = OoO000 ( url )
  IiiI11Iiiii = re . compile ( '<term>(.+?)</term>' ) . findall ( IiIIIiI1I1 )
  for ii1I1i1I in IiiI11Iiiii :
   ii1I1i1I = ii1I1i1I . replace ( ' ' , '' )
   ii1I1i1I = ii1I1i1I . lower ( )
   oOOO0o0o . append ( ii1I1i1I )
 else :
  ii1I1i1I = url
  ii1I1i1I = ii1I1i1I . replace ( ' ' , '' )
  ii1I1i1I = ii1I1i1I . lower ( )
  oOOO0o0o . append ( url . lower ( ) )
  if 88 - 88: I1i1iI1i + i1 / o00ooo0 * iiIIIIi1i1
 I11i11Ii . create ( Oo0Ooo , "[COLOR white]We are just getting the channel links for you.[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
 I11i11Ii . update ( 0 )
 if 41 - 41: O0OOo
 ii1i1I1i = [ ]
 o00oOO0 = [ ]
 oOoo = [ ]
 iIii11I = [ ]
 I11i11Ii . update ( 0 )
 if 69 - 69: O0OOo % iI1 - o00 + iI1 - i1 % i1oOo0OoO
 Iii111II = 0
 IiIIIiI1I1 = OoO000 ( IiiIII111iI )
 IiiI11Iiiii = re . compile ( '<link>(.+?)</link>' ) . findall ( IiIIIiI1I1 )
 iiii11I = len ( IiiI11Iiiii )
 if 96 - 96: Oo % ii11 . II1Iiii1111i + i1oOo0OoO * O0OOo - o00ooo0
 i11i1 = OoO000 ( iI1Ii11111iIi )
 i11i1 = i11i1 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 IIIii1II1II = re . compile ( '<item>(.+?)</item>' ) . findall ( i11i1 )
 i1I1iI = OoO000 ( i1i1II )
 i1I1iI = i1I1iI . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oo0OooOOo0 = re . compile ( '<item>(.+?)</item>' ) . findall ( i1I1iI )
 if 92 - 92: iiIIIIi1i1 . Oo0o00o0Oo0 + o00
 IiII1I11i1I1I = 0
 for ii1I1i1I in oo0OooOOo0 :
  oO0Oo = re . compile ( '<cat>(.+?)</cat>' ) . findall ( ii1I1i1I ) [ 0 ]
  if oO0Oo . lower ( ) in o0oo0o0O00OO . lower ( ) :
   oOOoo0Oo = oO0Oo
   IiII1I11i1I1I = 1
 if IiII1I11i1I1I == 0 : oOOoo0Oo = "null"
 if 78 - 78: Oo0o00o0Oo0
 for OO00Oo in IiiI11Iiiii :
  Iii111II = Iii111II + 1
  O0OOO0OOoO0O = 100 * int ( Iii111II ) / int ( iiii11I )
  I11i11Ii . update ( O0OOO0OOoO0O , '' , '[COLOR blue]Searching list ' + str ( Iii111II ) + ' of ' + str ( iiii11I ) + '[/COLOR]' )
  O00Oo000ooO0 = OoO000 ( OO00Oo )
  O00Oo000ooO0 = O00Oo000ooO0 . replace ( '#AAASTREAM:' , '#A:' )
  O00Oo000ooO0 = O00Oo000ooO0 . replace ( '#EXTINF:' , '#A:' )
  OoO0O00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O00Oo000ooO0 )
  IIiII = [ ]
  for o0ooOooo000oOO , Oo0oOOo , url in OoO0O00 :
   Oo0OoO00oOO0o = { "params" : o0ooOooo000oOO , "display_name" : Oo0oOOo , "url" : url }
   IIiII . append ( Oo0OoO00oOO0o )
  OOO00O = [ ]
  for OOoOO0oo0ooO in IIiII :
   Oo0OoO00oOO0o = { "display_name" : OOoOO0oo0ooO [ "display_name" ] , "url" : OOoOO0oo0ooO [ "url" ] }
   OoO0O00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( OOoOO0oo0ooO [ "params" ] )
   for O0o0O00Oo0o0 , O00O0oOO00O00 in OoO0O00 :
    Oo0OoO00oOO0o [ O0o0O00Oo0o0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O00O0oOO00O00 . strip ( )
   OOO00O . append ( Oo0OoO00oOO0o )
   if 11 - 11: OOoOoo00oo . Oo0oO0ooo
  for OOoOO0oo0ooO in OOO00O :
   name = o0oo0oOo ( OOoOO0oo0ooO [ "display_name" ] )
   url = o0oo0oOo ( OOoOO0oo0ooO [ "url" ] )
   url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if 89 - 89: o00ooo0
   ii1i1I1i . append ( name )
   o00oOO0 . append ( url )
   iIii11I = list ( zip ( ii1i1I1i , o00oOO0 ) )
   if 68 - 68: I1i1iI1i * i1oOo0OoO % i1 + I1i1iI1i + OOooO
 i11i1I1 = sorted ( iIii11I )
 ii1I = sorted ( oOOO0o0o )
 if 67 - 67: i11iIiiIii - iIIIiiIIiiiIi % Oo0oO0ooo . i1
 o0oo = OoO000 ( IiII )
 o0oo = o0oo . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 IIiiIiI1 = re . compile ( '<item>(.+?)</item>' ) . findall ( o0oo )
 if 91 - 91: OOoOoo00oo
 iiIii = [ ]
 ooo0O = [ ]
 oOoO0o00OO0 = [ ]
 i1I1ii = 0
 I11i11Ii . update ( 100 , '' , '[COLOR blue]Filtering results.[/COLOR]' )
 if 61 - 61: Oo
 if oOOoo0Oo != 'null' :
  if 64 - 64: OOooO / o00ooo0 - i1 - Oo0o00o0Oo0
  O0oOoOOOoOO = re . compile ( '<cat>' + re . escape ( oOOoo0Oo ) + '</cat>(.+?)</item>' , re . DOTALL ) . findall ( i1I1iI ) [ 0 ]
  if 38 - 38: iI1
  IiiI11Iiiii = re . compile ( '<name>(.+?)</name>' ) . findall ( O0oOoOOOoOO )
  if 7 - 7: i1 . iiIIIIi1i1 % Oo0oO0ooo - o0OO0 - o0
  for I111IIIiIii in ii1I :
   for name , url in i11i1I1 :
    oO0000OOo00 = name . replace ( ' ' , '' )
    if 27 - 27: o0OO0 % o0OO0
    if I111IIIiIii . lower ( ) in oO0000OOo00 . lower ( ) :
     if url not in str ( ooo0O ) :
      if 1 - 1: I1i1iI1i - O0OOo . Oo0o00o0Oo0 . I1i1iI1i / Oo0ooO0oo0oO + Oo0o00o0Oo0
      for Ooo in IiiI11Iiiii :
       if Ooo in name . lower ( ) :
        i1I1ii = 1
      if i1I1ii == 0 :
       for iiIiIIi in IIiiIiI1 :
        OOOOo = re . compile ( '<old>(.+?)</old>' ) . findall ( iiIiIIi ) [ 0 ]
        oo0O0oO = re . compile ( '<new>(.+?)</new>' ) . findall ( iiIiIIi ) [ 0 ]
        if oo0O0oO . lower ( ) == "null" : oo0O0oO = ""
        name = name . lower ( )
        OOOOo = OOOOo . lower ( )
        oo0O0oO = oo0O0oO . lower ( )
        name = name . replace ( OOOOo , oo0O0oO )
       for ooooo in IIIii1II1II :
        OOOOo = re . compile ( '<old>(.+?)</old>' ) . findall ( ooooo ) [ 0 ]
        oo0O0oO = re . compile ( '<new>(.+?)</new>' ) . findall ( ooooo ) [ 0 ]
        name = name . lower ( )
        OOOOo = OOOOo . lower ( )
        oo0O0oO = oo0O0oO . lower ( )
        name = name . replace ( OOOOo , oo0O0oO )
        name = name . lstrip ( ' ' )
       iiIii . append ( name )
       ooo0O . append ( url )
       oOoO0o00OO0 = list ( zip ( iiIii , ooo0O ) )
      i1I1ii = 0
 else :
  for I111IIIiIii in ii1I :
   for name , url in i11i1I1 :
    oO0000OOo00 = name . replace ( ' ' , '' )
    if 1 - 1: Oo0ooO0oo0oO / o00 % iiIIIIi1i1 * OOoOoo00oo . i11iIiiIii
    if I111IIIiIii . lower ( ) in oO0000OOo00 . lower ( ) :
     if url not in str ( ooo0O ) :
      if 2 - 2: Oo0oO0ooo * Oo0o00o0Oo0 - o0 + o0OO0 . O0OOo % iiIIIIi1i1
      for iiIiIIi in IIiiIiI1 :
       OOOOo = re . compile ( '<old>(.+?)</old>' ) . findall ( iiIiIIi ) [ 0 ]
       oo0O0oO = re . compile ( '<new>(.+?)</new>' ) . findall ( iiIiIIi ) [ 0 ]
       if oo0O0oO . lower ( ) == "null" : oo0O0oO = ""
       name = name . replace ( OOOOo , oo0O0oO )
      for ooooo in IIIii1II1II :
       OOOOo = re . compile ( '<old>(.+?)</old>' ) . findall ( ooooo ) [ 0 ]
       oo0O0oO = re . compile ( '<new>(.+?)</new>' ) . findall ( ooooo ) [ 0 ]
       name = name . replace ( OOOOo , oo0O0oO )
      name = name . lstrip ( ' ' )
      iiIii . append ( name )
      ooo0O . append ( url )
      oOoO0o00OO0 = list ( zip ( iiIii , ooo0O ) )
      if 92 - 92: iiIIIIi1i1
      if 25 - 25: Oo0ooO0oo0oO - o0OO0 / i1oOo0OoO / o00
 II111iiiI1Ii = sorted ( oOoO0o00OO0 )
 if 78 - 78: ii11 % iI1 + Oo0oO0ooo
 I11i11Ii . update ( 100 , '' , '[COLOR blue]Creating the list of results.[/COLOR]' )
 if 64 - 64: O0OOo * i1 . o0OO0 + Oo
 for name , url in II111iiiI1Ii :
  if 6 - 6: o00ooo0 / iiIIIIi1i1 . OOoOoo00oo . OOoOoo00oo
  OO00O0O = name + '|SPLIT|' + url
  if 33 - 33: i1 . OOoOoo00oo . o0OO0
  if os . path . exists ( I1IiiI ) :
   if "hd" in name . lower ( ) :
    name = name . replace ( 'hd' , '' )
    i11iiII ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , OO00O0O , 3 , iiiii , O0O0OO0O0O0 )
  else :
   if "hd" in name . lower ( ) :
    name = name . replace ( 'hd' , '' )
    i11iiII ( '[COLOR white]' + name . title ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , OO00O0O , 3 , iiiii , O0O0OO0O0O0 )
   else :
    i11iiII ( '[COLOR white]' + name . title ( ) + '[/COLOR]' , OO00O0O , 3 , iiiii , O0O0OO0O0O0 )
    if 72 - 72: iIIIiiIIiiiIi / I1i1iI1i + i1oOo0OoO - Oo0ooO0oo0oO
 if I11i11Ii . iscanceled ( ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The download was cancelled.' )
  I11i11Ii . close ( )
  quit ( )
 I11i11Ii . close ( )
 if 29 - 29: Oo0oO0ooo + O0OOo % i1
def I1I11 ( ) :
 if 34 - 34: o0OO0 . II1Iiii1111i * Oo0oO0ooo + iI1
 I1I1i1 ( )
 if 31 - 31: iiIIIIi1i1 % iiIIIIi1i1 % Oo0o00o0Oo0
 IIIii1II1II = ''
 OOOOoo0Oo = xbmc . Keyboard ( IIIii1II1II , 'Enter Search Term' )
 OOOOoo0Oo . doModal ( )
 if OOOOoo0Oo . isConfirmed ( ) :
  IIIii1II1II = OOOOoo0Oo . getText ( )
  if len ( IIIii1II1II ) > 1 :
   OooO0 = IIIii1II1II
   oO00O00o0OOO0 ( "search" , OooO0 , iiiii )
  else : quit ( )
  if 14 - 14: iiIIIIi1i1
def I1iI1iIi111i ( ) :
 if 44 - 44: iIIIiiIIiiiIi % Oo + Oo0o00o0Oo0
 if not os . path . exists ( ooo0OO ) :
  try :
   os . makedirs ( ooo0OO )
  except : pass
 if os . path . exists ( I1IiiI ) :
  try :
   os . remove ( I1IiiI )
  except : pass
 else :
  try :
   open ( I1IiiI , 'w' )
  except : pass
  if 45 - 45: iiIIIIi1i1 / iiIIIIi1i1 + iI1 + OOooO
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 47 - 47: o00 + OOooO
def I1I1i1 ( ) :
 if 82 - 82: Oo . OOoOoo00oo - o0 - OOoOoo00oo * Oo
 if os . path . exists ( O00ooooo00 ) :
  ooO0oOOooOo0 = i1I1ii11i1Iii ( heading = "Please Enter Your Password" )
  if ( not ooO0oOOooOo0 ) :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  I1IiiiiI = ooO0oOOooOo0
  if 80 - 80: iI1 . i11iIiiIii - o00
  iIiIIi1 = open ( O00ooooo00 , "r" )
  I1IIII1i = re . compile ( r'<password>(.+?)</password>' )
  for I1I11i in iIiIIi1 :
   file = I1IIII1i . findall ( I1I11i )
   for Ii1I1I1i1Ii in file :
    i1Oo0oO00o = base64 . b64decode ( Ii1I1I1i1Ii )
    if not i1Oo0oO00o == I1IiiiiI :
     if not Ii1I1I1i1Ii == I1IiiiiI :
      IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 13 - 13: Oo0o00o0Oo0 * Oo0ooO0oo0oO * OOooO
def iI11iI1IiiIiI ( ) :
 if 43 - 43: i11iIiiIii + Oo0ooO0oo0oO * Oo * iI1 * i1
 I1I1i1 ( )
 if 64 - 64: II1Iiii1111i % o0 * O0OOo
 IiII1I11i1I1I = 0
 if not os . path . exists ( O00ooooo00 ) :
  IiII1I11i1I1I = 1
  i11iiII ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  i11iiII ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  iIiIIi1 = open ( O00ooooo00 , "r" )
  I1IIII1i = re . compile ( r'<password>(.+?)</password>' )
  for I1I11i in iIiIIi1 :
   file = I1IIII1i . findall ( I1I11i )
   for Ii1I1I1i1Ii in file :
    i1Oo0oO00o = base64 . b64decode ( Ii1I1I1i1Ii )
    IiII1I11i1I1I = 1
    i11iiII ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    i11iiII ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( i1Oo0oO00o ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    i11iiII ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    i11iiII ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 79 - 79: i1
 if IiII1I11i1I1I == 0 :
  i11iiII ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  i11iiII ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 78 - 78: Oo0oO0ooo + II1Iiii1111i - iI1
def IIIIii1I ( ) :
 if 39 - 39: Oo / OOooO + iI1 / o00ooo0
 ooO0oOOooOo0 = i1I1ii11i1Iii ( heading = "Please Set Password" )
 if ( not ooO0oOOooOo0 ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 I1IiiiiI = ooO0oOOooOo0
 if 13 - 13: OOoOoo00oo + i1 + iiIIIIi1i1 % o0OO0 / o00 . OOoOoo00oo
 ooO0oOOooOo0 = i1I1ii11i1Iii ( heading = "Please Confirm Your Password" )
 if ( not ooO0oOOooOo0 ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 OO0Oooo0oOO0O = ooO0oOOooOo0
 if 62 - 62: o0OO0
 if not os . path . exists ( O00ooooo00 ) :
  if not os . path . exists ( II1 ) :
   os . makedirs ( II1 )
  open ( O00ooooo00 , 'w' )
  if 100 - 100: ii11 - i1 % O0OOo * II1Iiii1111i + o0OO0
  if I1IiiiiI == OO0Oooo0oOO0O :
   Oo0O0oooo = base64 . b64encode ( I1IiiiiI )
   I111iI = open ( O00ooooo00 , 'w' )
   I111iI . write ( '<password>' + str ( Oo0O0oooo ) + '</password>' )
   I111iI . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( O00ooooo00 )
  if 56 - 56: o0OO0
  if I1IiiiiI == OO0Oooo0oOO0O :
   Oo0O0oooo = base64 . b64encode ( I1IiiiiI )
   I111iI = open ( O00ooooo00 , 'w' )
   I111iI . write ( '<password>' + str ( Oo0O0oooo ) + '</password>' )
   I111iI . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 54 - 54: iI1 / II1Iiii1111i . O0OOo % iiIIIIi1i1
def OoO0OOOOo0O ( ) :
 if 81 - 81: i1 / I1i1iI1i . iIIIiiIIiiiIi + o0OO0 - Oo0o00o0Oo0
 try :
  os . remove ( O00ooooo00 )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 74 - 74: o0 * Oo0oO0ooo + o00ooo0 / iIIIiiIIiiiIi / Oo . Oo0ooO0oo0oO
def oooOo0OOOoo0 ( name , url , iconimage ) :
 if 51 - 51: Oo0ooO0oo0oO / o00ooo0 . II1Iiii1111i * o00 + I1i1iI1i * OOoOoo00oo
 name , url = url . split ( '|SPLIT|' )
 if 73 - 73: I1i1iI1i + i1oOo0OoO - i1 - ii11 - Oo
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 99 - 99: OOooO . ii11 + iI1 + i1oOo0OoO % o00
 ooO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , ooO , False )
 if 46 - 46: o0OO0 - i1oOo0OoO - Oo0o00o0Oo0 * Oo
def o0oo0oOo ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 34 - 34: Oo0o00o0Oo0 - iiIIIIi1i1 / II1Iiii1111i + Oo0oO0ooo * ii11
def OoO000 ( url ) :
 if 73 - 73: o00ooo0 . ii11 * Oo0oO0ooo % Oo0oO0ooo % i1oOo0OoO
 Oo0o0oooo0O0 = urllib2 . Request ( url )
 Oo0o0oooo0O0 . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 O00Oo000ooO0 = urllib2 . urlopen ( Oo0o0oooo0O0 )
 IiIIIiI1I1 = O00Oo000ooO0 . read ( )
 O00Oo000ooO0 . close ( )
 return IiIIIiI1I1
 if 93 - 93: i1 % iIIIiiIIiiiIi . II1Iiii1111i / o0OO0 - iI1 / o0OO0
def i1I1ii11i1Iii ( default = "" , heading = "" , hidden = False ) :
 OOOOoo0Oo = xbmc . Keyboard ( default , heading , hidden )
 if 36 - 36: O0OOo % O0OOo % iIIIiiIIiiiIi / iIIIiiIIiiiIi - OOooO
 OOOOoo0Oo . doModal ( )
 if ( OOOOoo0Oo . isConfirmed ( ) ) :
  return unicode ( OOOOoo0Oo . getText ( ) , "utf-8" )
 return default
 if 30 - 30: Oo0o00o0Oo0 / o0OO0
def I1iiiiI1iII ( name , url , mode , iconimage , fanartimage ) :
 if 35 - 35: Oo % II1Iiii1111i . OOooO + OOooO % Oo % Oo
 ooOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 Ii1IIiI1i = True
 ooO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 ooO . setProperty ( "fanart_Image" , fanartimage )
 ooO . setProperty ( "icon_Image" , iconimage )
 Ii1IIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOoO00 , listitem = ooO , isFolder = True )
 return Ii1IIiI1i
 if 78 - 78: Oo0oO0ooo
def i11iiII ( name , url , mode , iconimage , fanartimage ) :
 if 93 - 93: OOoOoo00oo * i1oOo0OoO + OOooO
 ooOoO00 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 Ii1IIiI1i = True
 ooO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 ooO . setProperty ( "fanart_Image" , fanartimage )
 ooO . setProperty ( "icon_Image" , iconimage )
 Ii1IIiI1i = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = ooOoO00 , listitem = ooO , isFolder = False )
 return Ii1IIiI1i
 if 33 - 33: i1 * o00 - iI1 % iI1
def I11I ( ) :
 I11iIi1i1II11 = [ ]
 iiI = sys . argv [ 2 ]
 if len ( iiI ) >= 2 :
  o0ooOooo000oOO = sys . argv [ 2 ]
  i1I1i111Ii = o0ooOooo000oOO . replace ( '?' , '' )
  if ( o0ooOooo000oOO [ len ( o0ooOooo000oOO ) - 1 ] == '/' ) :
   o0ooOooo000oOO = o0ooOooo000oOO [ 0 : len ( o0ooOooo000oOO ) - 2 ]
  ooo = i1I1i111Ii . split ( '&' )
  I11iIi1i1II11 = { }
  for Iii111II in range ( len ( ooo ) ) :
   i1i1iI1iiiI = { }
   i1i1iI1iiiI = ooo [ Iii111II ] . split ( '=' )
   if ( len ( i1i1iI1iiiI ) ) == 2 :
    I11iIi1i1II11 [ i1i1iI1iiiI [ 0 ] ] = i1i1iI1iiiI [ 1 ]
    if 51 - 51: o0OO0 % iI1 . O0OOo / o0 / Oo0o00o0Oo0 . O0OOo
 return I11iIi1i1II11
 if 42 - 42: o00 + iIIIiiIIiiiIi - ii11 / OOoOoo00oo
o0ooOooo000oOO = I11I ( ) ; ooOoo0O = None ; OooO0 = None ; iiIiIIIiiI = None ; II11iiii1Ii = None ; iiI1IIIi = None
try : ooOoo0O = urllib . unquote_plus ( o0ooOooo000oOO [ "name" ] )
except : pass
try : OooO0 = urllib . unquote_plus ( o0ooOooo000oOO [ "url" ] )
except : pass
try : iiIiIIIiiI = int ( o0ooOooo000oOO [ "mode" ] )
except : pass
try : II11iiii1Ii = urllib . unquote_plus ( o0ooOooo000oOO [ "iconimage" ] )
except : pass
try : iiI1IIIi = urllib . quote_plus ( o0ooOooo000oOO [ "fanartimage" ] )
except : pass
if 47 - 47: Oo0ooO0oo0oO % Oo0o00o0Oo0 % i11iIiiIii - i1 + OOooO
if iiIiIIIiiI == None or OooO0 == None or len ( OooO0 ) < 1 : o0oOoO00o ( )
elif iiIiIIIiiI == 1 : Ooo00O00O0O0O ( )
elif iiIiIIIiiI == 2 : oO00O00o0OOO0 ( ooOoo0O , OooO0 , II11iiii1Ii )
elif iiIiIIIiiI == 3 : oooOo0OOOoo0 ( ooOoo0O , OooO0 , II11iiii1Ii )
elif iiIiIIIiiI == 4 : I1I11 ( )
elif iiIiIIIiiI == 5 : I1iI1iIi111i ( )
elif iiIiIIIiiI == 900 : iI11iI1IiiIiI ( )
elif iiIiIIIiiI == 901 : IIIIii1I ( )
elif iiIiIIIiiI == 902 : OoO0OOOOo0O ( )
elif iiIiIIIiiI == 999 : quit ( )
if 94 - 94: iI1
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )