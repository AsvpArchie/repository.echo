import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64
from resources . lib . modules import checker
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
II1 = xbmc . translatePath ( os . path . join ( ooo0OO , 'controls.txt' ) )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
if 65 - 65: i1iIi11iIIi1I
Oo = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
I1ii11iIi11i = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
I1IiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
o0OOO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
iIiiiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI=' )
if 23 - 23: iii1II11ii * i11iII1iiI + iI1Ii11111iIi + ii1II11I1ii1I + oO0o0ooO0 - iiIIIII1i1iI
def o0oO0 ( ) :
 if 100 - 100: i11Ii11I1Ii1i
 Ooo = I11i11Ii + '|SPLIT|' + IIi1IiiiI1Ii
 checker . check ( Ooo )
 if 56 - 56: ooO00oOoo - O0OOo
 II1Iiii1111i ( )
 if 25 - 25: OOo000
 O0 ( "[COLOR white]Welcome to ECHO Streams[/COLOR]" , Oo , 999 , iiiii , O0O0OO0O0O0 )
 O0 ( "################################################################" , Oo , 999 , iiiii , O0O0OO0O0O0 )
 O0 ( "[COLOR white]Meet the team:[/COLOR]" , Oo , 999 , iiiii , O0O0OO0O0O0 )
 O0 ( "[COLOR white]ECHO Coder: @EchoCoder(Twitter)[/COLOR]" , Oo , 999 , iiiii , O0O0OO0O0O0 )
 O0 ( "[COLOR white]ECHO Blue: @Blue_Builds(Twitter)[/COLOR]" , Oo , 999 , iiiii , O0O0OO0O0O0 )
 O0 ( "################################################################" , Oo , 999 , iiiii , O0O0OO0O0O0 )
 I11i1i11i1I ( "[COLOR dodgerblue][B]ENTER ADDON[/B][/COLOR]" , Oo , 1 , iiiii , O0O0OO0O0O0 )
 O0 ( "################################################################" , Oo , 999 , iiiii , O0O0OO0O0O0 )
 if not os . path . exists ( II1 ) :
  I11i1i11i1I ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  I11i1i11i1I ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 31 - 31: i11iI / Oo0o0ooO0oOOO + I1 - OOoOoo00oo - iiI11
def OOooO ( ) :
 if 58 - 58: i11iiII + OooooO0oOO + oOo0 / OOoOoo00oo
 I11i1i11i1I ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 11 - 11: oOo0 / i1iIi11iIIi1I - iI1Ii11111iIi
 o00O00O0O0O = OooO0OO ( Oo )
 o00O00O0O0O = o00O00O0O0O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 iiiIi = re . compile ( '<item>(.+?)</item>' ) . findall ( o00O00O0O0O )
 for IiIIIiI1I1 in iiiIi :
  OoO000 = re . compile ( '<title>(.+?)</title>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
  IIiiIiI1 = re . compile ( '<folder>(.+?)</folder>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
  iiIiIIi = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
  ooOoo0O = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
  if 76 - 76: i1iIi11iIIi1I / O0OOo . oO0o0ooO0 * OOoOoo00oo - Oo0o0ooO0oOOO
  I11i1i11i1I ( '[COLOR white]' + OoO000 + '[/COLOR]' , IIiiIiI1 , 2 , iiIiIIi , ooOoo0O )
  if 76 - 76: i11iIiiIii / iii1II11ii . OOo000 % Oo0o0ooO0oOOO / i11iII1iiI % i11iI
def o0ooo00O0o0 ( name , url , iconimage ) :
 if 63 - 63: OOoOoo00oo
 O00 = name
 if 35 - 35: O0OOo + iiI11 + iiI11
 if "adult" in name . lower ( ) :
  II1Iiii1111i ( )
 I11I11i1I = [ ]
 if 49 - 49: ii1II11I1ii1I % iiI11 * i1iIi11iIIi1I
 if not "search" in name . lower ( ) :
  o00O00O0O0O = OooO0OO ( url )
  oOOo0oo = re . compile ( '<term>(.+?)</term>' ) . findall ( o00O00O0O0O )
  for o0oo0o0O00OO in oOOo0oo :
   o0oo0o0O00OO = o0oo0o0O00OO . replace ( ' ' , '' )
   o0oo0o0O00OO = o0oo0o0O00OO . lower ( )
   I11I11i1I . append ( o0oo0o0O00OO )
 else :
  o0oo0o0O00OO = url
  o0oo0o0O00OO = o0oo0o0O00OO . replace ( ' ' , '' )
  o0oo0o0O00OO = o0oo0o0O00OO . lower ( )
  I11I11i1I . append ( url . lower ( ) )
  if 80 - 80: iI1Ii11111iIi
 I1IiiI . create ( Oo0Ooo , "[COLOR white]We are just getting the channel links for you.[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
 I1IiiI . update ( 0 )
 if 70 - 70: ooO00oOoo - O0OOo
 I1iii = [ ]
 i1iiI11I = [ ]
 iiii = [ ]
 oO0o0O0OOOoo0 = [ ]
 I1IiiI . update ( 0 )
 if 48 - 48: i1iIi11iIIi1I + i1iIi11iIIi1I - OOo000 . oOo0 / iii1II11ii
 OoOOO00oOO0 = 0
 o00O00O0O0O = OooO0OO ( I1ii11iIi11i )
 oOOo0oo = re . compile ( '<link>(.+?)</link>' ) . findall ( o00O00O0O0O )
 oOoo = len ( oOOo0oo )
 if 8 - 8: ooO00oOoo
 o00O = OooO0OO ( o0OOO )
 o00O = o00O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 OOO0OOO00oo = re . compile ( '<item>(.+?)</item>' ) . findall ( o00O )
 if 31 - 31: ii1II11I1ii1I - Oo0o0ooO0oOOO . OooooO0oOO % ooO00oOoo - i1iIi11iIIi1I
 for iii11 in oOOo0oo :
  try :
   OoOOO00oOO0 = OoOOO00oOO0 + 1
   O0oo0OO0oOOOo = 100 * int ( OoOOO00oOO0 ) / int ( oOoo )
   I1IiiI . update ( O0oo0OO0oOOOo , '' , '[COLOR blue]Searching list ' + str ( OoOOO00oOO0 ) + ' of ' + str ( oOoo ) + '[/COLOR]' )
   i1i1i11IIi = OooO0OO ( iii11 )
   i1i1i11IIi = i1i1i11IIi . replace ( '#AAASTREAM:' , '#A:' )
   i1i1i11IIi = i1i1i11IIi . replace ( '#EXTINF:' , '#A:' )
   II1III = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i1i1i11IIi )
   iI1iI1I1i1I = [ ]
   for iIi11Ii1 , Ii11iII1 , url in II1III :
    Oo0O0O0ooO0O = { "params" : iIi11Ii1 , "display_name" : Ii11iII1 , "url" : url }
    iI1iI1I1i1I . append ( Oo0O0O0ooO0O )
   IIIIii = [ ]
   for O0o0 in iI1iI1I1i1I :
    Oo0O0O0ooO0O = { "display_name" : O0o0 [ "display_name" ] , "url" : O0o0 [ "url" ] }
    II1III = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o0 [ "params" ] )
    for OO00Oo , O0OOO0OOoO0O in II1III :
     Oo0O0O0ooO0O [ OO00Oo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OOO0OOoO0O . strip ( )
    IIIIii . append ( Oo0O0O0ooO0O )
    if 70 - 70: i11iiII * iiIIIII1i1iI * I1 / OOoOoo00oo
   for O0o0 in IIIIii :
    name = oO ( O0o0 [ "display_name" ] )
    url = oO ( O0o0 [ "url" ] )
    url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    if 93 - 93: i11Ii11I1Ii1i % i11iI . i11Ii11I1Ii1i * OooooO0oOO % OOoOoo00oo . ii1II11I1ii1I
    for IiIIIiI1I1 in OOO0OOO00oo :
     iI1ii1Ii = re . compile ( '<old>(.+?)</old>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
     oooo000 = re . compile ( '<new>(.+?)</new>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
     name = name . replace ( iI1ii1Ii , oooo000 )
     if 16 - 16: OOo000 + i11Ii11I1Ii1i - ii1II11I1ii1I
    I1iii . append ( name )
    i1iiI11I . append ( url )
    oO0o0O0OOOoo0 = list ( zip ( I1iii , i1iiI11I ) )
  except : pass
  if 85 - 85: ooO00oOoo + iI1Ii11111iIi
 Oo0OoO00oOO0o = sorted ( oO0o0O0OOOoo0 )
 OOO00O = sorted ( I11I11i1I )
 if 84 - 84: i11iI * i11Ii11I1Ii1i / I1 - i1iIi11iIIi1I
 IiI1 = OooO0OO ( I1IiI )
 IiI1 = IiI1 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 iiiIi = re . compile ( '<item>(.+?)</item>' ) . findall ( IiI1 )
 if 54 - 54: ii1II11I1ii1I % ooO00oOoo % I1 % iii1II11ii + iii1II11ii * oOo0
 O00O0oOO00O00 = [ ]
 i1 = [ ]
 Oo00 = [ ]
 if 31 - 31: OooooO0oOO . ooO00oOoo / i1iIi11iIIi1I
 I1IiiI . update ( 100 , '' , '[COLOR blue]Filtering results.[/COLOR]' )
 if 89 - 89: ooO00oOoo
 for OO0oOoOO0oOO0 in OOO00O :
  for name , url in Oo0OoO00oOO0o :
   oO0OOoo0OO = name . replace ( ' ' , '' )
   if 65 - 65: OOoOoo00oo . iii1II11ii / i1iIi11iIIi1I - OOoOoo00oo
   if OO0oOoOO0oOO0 . lower ( ) in oO0OOoo0OO . lower ( ) :
    if url not in str ( i1 ) :
     if 21 - 21: oO0o0ooO0 * iii1II11ii
     for IiIIIiI1I1 in iiiIi :
      iI1ii1Ii = re . compile ( '<old>(.+?)</old>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
      oooo000 = re . compile ( '<new>(.+?)</new>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
      if oooo000 . lower ( ) == "null" : oooo000 = ""
      name = name . replace ( iI1ii1Ii , oooo000 )
     name = name . lstrip ( ' ' )
     O00O0oOO00O00 . append ( name )
     i1 . append ( url )
     Oo00 = list ( zip ( O00O0oOO00O00 , i1 ) )
     if 91 - 91: i11iiII
 iiIii = sorted ( Oo00 )
 if 79 - 79: i11iII1iiI / i1iIi11iIIi1I
 I1IiiI . update ( 100 , '' , '[COLOR blue]Creating the list of results.[/COLOR]' )
 OO0OoO0o00 = 0
 o00O = OooO0OO ( iIiiiI )
 o00O = o00O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 ooOO0O0ooOooO = re . compile ( '<item>(.+?)</item>' ) . findall ( o00O )
 oOOOo00O00oOo = 0
 if 34 - 34: i1iIi11iIIi1I + Oo0o0ooO0oOOO + iiIIIII1i1iI
 for IiIIIiI1I1 in ooOO0O0ooOooO :
  I1i1IIIiiII1 = re . compile ( '<cat>(.+?)</cat>' ) . findall ( IiIIIiI1I1 ) [ 0 ]
  if I1i1IIIiiII1 . lower ( ) in O00 . lower ( ) :
   OOOOoOoo0O0O0 = I1i1IIIiiII1
   oOOOo00O00oOo = 1
 for name , url in iiIii :
  if 85 - 85: i11iI % i11iIiiIii - iiI11 * i11iII1iiI / oO0o0ooO0 % oO0o0ooO0
  IIiIi1iI = name + '|SPLIT|' + url
  if 35 - 35: OOoOoo00oo % i1iIi11iIIi1I - i1iIi11iIIi1I
  try :
   IiIIIi1iIi = re . compile ( '<cat>' + re . escape ( OOOOoOoo0O0O0 ) + '</cat>(.+?)</item>' , re . DOTALL ) . findall ( o00O ) [ 0 ]
   oOOo0oo = re . compile ( '<name>(.+?)</name>' ) . findall ( IiIIIi1iIi )
   if 68 - 68: i11iIiiIii % OOo000 + i11iIiiIii
   for IiIIIiI1I1 in oOOo0oo :
    if IiIIIiI1I1 . lower ( ) in name . lower ( ) :
     OO0OoO0o00 = 1
  except :
   OO0OoO0o00 = 0
   pass
  if OO0OoO0o00 == 0 :
   O0 ( '[COLOR white]' + name . capitalize ( ) + '[/COLOR]' , IIiIi1iI , 3 , iiiii , O0O0OO0O0O0 )
  OO0OoO0o00 = 0
  if 31 - 31: ii1II11I1ii1I . oO0o0ooO0
 if I1IiiI . iscanceled ( ) :
  O00ooooo00 . ok ( Oo0Ooo , 'The download was cancelled.' )
  I1IiiI . close ( )
  quit ( )
 I1IiiI . close ( )
 if 1 - 1: iiIIIII1i1iI / O0OOo % iiI11 * i11iiII . i11iIiiIii
def III1Iiii1I11 ( ) :
 if 9 - 9: OOo000 / iiIIIII1i1iI - oO0o0ooO0 / i11iII1iiI / iii1II11ii - O0OOo
 II1Iiii1111i ( )
 if 91 - 91: iiI11 % iI1Ii11111iIi % iii1II11ii
 OOO0OOO00oo = ''
 IIi1I11I1II = xbmc . Keyboard ( OOO0OOO00oo , 'Enter Search Term' )
 IIi1I11I1II . doModal ( )
 if IIi1I11I1II . isConfirmed ( ) :
  OOO0OOO00oo = IIi1I11I1II . getText ( )
  if len ( OOO0OOO00oo ) > 1 :
   IIiiIiI1 = OOO0OOO00oo
   o0ooo00O0o0 ( "search" , IIiiIiI1 , iiiii )
  else : quit ( )
  if 63 - 63: i11iII1iiI - i11Ii11I1Ii1i . ii1II11I1ii1I / O0OOo . ooO00oOoo / i1iIi11iIIi1I
def II1Iiii1111i ( ) :
 if 84 - 84: i11iiII
 if os . path . exists ( II1 ) :
  OOO00O0O = iii ( heading = "Please Enter Your Password" )
  if ( not OOO00O0O ) :
   O00ooooo00 . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  oOooOOOoOo = OOO00O0O
  if 41 - 41: OOoOoo00oo - i1iIi11iIIi1I - i1iIi11iIIi1I
  oO00OOoO00 = open ( II1 , "r" )
  IiI111111IIII = re . compile ( r'<password>(.+?)</password>' )
  for i1Ii in oO00OOoO00 :
   file = IiI111111IIII . findall ( i1Ii )
   for ii111iI1iIi1 in file :
    OOO = base64 . b64decode ( ii111iI1iIi1 )
    if not OOO == oOooOOOoOo :
     if not ii111iI1iIi1 == oOooOOOoOo :
      O00ooooo00 . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 68 - 68: ii1II11I1ii1I + I1
def I1I1I ( ) :
 if 95 - 95: ii1II11I1ii1I + O0OOo + iiI11 * iii1II11ii % i11iI / i11iiII
 II1Iiii1111i ( )
 if 56 - 56: iiI11
 oo0oO0oOOoo = 0
 if not os . path . exists ( II1 ) :
  oo0oO0oOOoo = 1
  O0 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  O0 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  oO00OOoO00 = open ( II1 , "r" )
  IiI111111IIII = re . compile ( r'<password>(.+?)</password>' )
  for i1Ii in oO00OOoO00 :
   file = IiI111111IIII . findall ( i1Ii )
   for ii111iI1iIi1 in file :
    OOO = base64 . b64decode ( ii111iI1iIi1 )
    oo0oO0oOOoo = 1
    O0 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    O0 ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( OOO ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    O0 ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    O0 ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 51 - 51: iiIIIII1i1iI * i11iIiiIii
 if oo0oO0oOOoo == 0 :
  O0 ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  O0 ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 94 - 94: OOoOoo00oo - ii1II11I1ii1I . Oo0o0ooO0oOOO % I1 . i11iIiiIii + i1iIi11iIIi1I
def I1IiiiiI ( ) :
 if 80 - 80: OooooO0oOO . i11iIiiIii - O0OOo
 OOO00O0O = iii ( heading = "Please Set Password" )
 if ( not OOO00O0O ) :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 oOooOOOoOo = OOO00O0O
 if 25 - 25: i11Ii11I1Ii1i
 OOO00O0O = iii ( heading = "Please Confirm Your Password" )
 if ( not OOO00O0O ) :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 oOo0oO = OOO00O0O
 if 51 - 51: iiIIIII1i1iI - i11iI + ii1II11I1ii1I * OOoOoo00oo . I1 + i11iI
 if not os . path . exists ( II1 ) :
  if not os . path . exists ( ooo0OO ) :
   os . makedirs ( ooo0OO )
  open ( II1 , 'w' )
  if 78 - 78: i11iIiiIii / iiI11 - OOoOoo00oo / Oo0o0ooO0oOOO + i11iI
  if oOooOOOoOo == oOo0oO :
   oOoooo0O0Oo = base64 . b64encode ( oOooOOOoOo )
   o00ooO = open ( II1 , 'w' )
   o00ooO . write ( '<password>' + str ( oOoooo0O0Oo ) + '</password>' )
   o00ooO . close ( )
   O00ooooo00 . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   O00ooooo00 . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( II1 )
  if 89 - 89: iiIIIII1i1iI * ooO00oOoo * OooooO0oOO + iiI11 - I1
  if oOooOOOoOo == oOo0oO :
   oOoooo0O0Oo = base64 . b64encode ( oOooOOOoOo )
   o00ooO = open ( II1 , 'w' )
   o00ooO . write ( '<password>' + str ( oOoooo0O0Oo ) + '</password>' )
   o00ooO . close ( )
   O00ooooo00 . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   O00ooooo00 . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 8 - 8: O0OOo % i1iIi11iIIi1I / oO0o0ooO0 - i11iI
def Ii1I1i ( ) :
 if 99 - 99: i11iI . iiI11 + oOo0 % i11iI . i11iIiiIii % i1iIi11iIIi1I
 try :
  os . remove ( II1 )
  O00ooooo00 . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  O00ooooo00 . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 78 - 78: OOo000 + Oo0o0ooO0oOOO - OooooO0oOO
def IIIIii1I ( name , url , iconimage ) :
 if 39 - 39: ii1II11I1ii1I / oOo0 + OooooO0oOO / ooO00oOoo
 name , url = url . split ( '|SPLIT|' )
 if 13 - 13: i11iiII + i1iIi11iIIi1I + iiI11 % oO0o0ooO0 / O0OOo . i11iiII
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 86 - 86: i11iI * O0OOo % iI1Ii11111iIi . OOoOoo00oo . i11iIiiIii
 oOOoo00O00o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , oOOoo00O00o , False )
 if 98 - 98: Oo0o0ooO0oOOO + i11iiII + i11iI % i11iII1iiI
def oO ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 97 - 97: i1iIi11iIIi1I * i11iII1iiI . i11iII1iiI
def OooO0OO ( url ) :
 if 33 - 33: OooooO0oOO + iiI11 * i11iI / iii1II11ii - oO0o0ooO0
 O0oO = urllib2 . Request ( url )
 O0oO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 i1i1i11IIi = urllib2 . urlopen ( O0oO )
 o00O00O0O0O = i1i1i11IIi . read ( )
 i1i1i11IIi . close ( )
 return o00O00O0O0O
 if 73 - 73: OOo000 * i11iIiiIii % i11iI . OOo000
def iii ( default = "" , heading = "" , hidden = False ) :
 IIi1I11I1II = xbmc . Keyboard ( default , heading , hidden )
 if 66 - 66: i11iI + i11iI + oOo0 / iiI11 + Oo0o0ooO0oOOO
 IIi1I11I1II . doModal ( )
 if ( IIi1I11I1II . isConfirmed ( ) ) :
  return unicode ( IIi1I11I1II . getText ( ) , "utf-8" )
 return default
 if 30 - 30: i1iIi11iIIi1I
def I11i1i11i1I ( name , url , mode , iconimage , fanartimage ) :
 if 44 - 44: i11iI / I1 / I1
 OOOiiiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 oooOo0OOOoo0 = True
 oOOoo00O00o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oOOoo00O00o . setProperty ( "fanart_Image" , fanartimage )
 oOOoo00O00o . setProperty ( "icon_Image" , iconimage )
 oooOo0OOOoo0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOiiiiI , listitem = oOOoo00O00o , isFolder = True )
 return oooOo0OOOoo0
 if 51 - 51: iiIIIII1i1iI / ooO00oOoo . Oo0o0ooO0oOOO * O0OOo + i11Ii11I1Ii1i * i11iiII
def O0 ( name , url , mode , iconimage , fanartimage ) :
 if 73 - 73: i11Ii11I1Ii1i + i11iII1iiI - i1iIi11iIIi1I - OOoOoo00oo - ii1II11I1ii1I
 OOOiiiiI = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 oooOo0OOOoo0 = True
 oOOoo00O00o = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oOOoo00O00o . setProperty ( "fanart_Image" , fanartimage )
 oOOoo00O00o . setProperty ( "icon_Image" , iconimage )
 oooOo0OOOoo0 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OOOiiiiI , listitem = oOOoo00O00o , isFolder = False )
 return oooOo0OOOoo0
 if 99 - 99: oOo0 . OOoOoo00oo + OooooO0oOO + i11iII1iiI % O0OOo
def ooO ( ) :
 IiIi11iI = [ ]
 Oo0O00O000 = sys . argv [ 2 ]
 if len ( Oo0O00O000 ) >= 2 :
  iIi11Ii1 = sys . argv [ 2 ]
  i11I1IiII1i1i = iIi11Ii1 . replace ( '?' , '' )
  if ( iIi11Ii1 [ len ( iIi11Ii1 ) - 1 ] == '/' ) :
   iIi11Ii1 = iIi11Ii1 [ 0 : len ( iIi11Ii1 ) - 2 ]
  oo = i11I1IiII1i1i . split ( '&' )
  IiIi11iI = { }
  for OoOOO00oOO0 in range ( len ( oo ) ) :
   I1111i = { }
   I1111i = oo [ OoOOO00oOO0 ] . split ( '=' )
   if ( len ( I1111i ) ) == 2 :
    IiIi11iI [ I1111i [ 0 ] ] = I1111i [ 1 ]
    if 14 - 14: Oo0o0ooO0oOOO / O0OOo
 return IiIi11iI
 if 32 - 32: oO0o0ooO0 * iiIIIII1i1iI
iIi11Ii1 = ooO ( ) ; OoO000 = None ; IIiiIiI1 = None ; O0OooOo0o = None ; iiIiIIi = None ; iiI11ii1I1 = None
try : OoO000 = urllib . unquote_plus ( iIi11Ii1 [ "name" ] )
except : pass
try : IIiiIiI1 = urllib . unquote_plus ( iIi11Ii1 [ "url" ] )
except : pass
try : O0OooOo0o = int ( iIi11Ii1 [ "mode" ] )
except : pass
try : iiIiIIi = urllib . unquote_plus ( iIi11Ii1 [ "iconimage" ] )
except : pass
try : iiI11ii1I1 = urllib . quote_plus ( iIi11Ii1 [ "fanartimage" ] )
except : pass
if 82 - 82: ii1II11I1ii1I % I1 / i11Ii11I1Ii1i + ooO00oOoo / O0OOo / OooooO0oOO
if O0OooOo0o == None or IIiiIiI1 == None or len ( IIiiIiI1 ) < 1 : o0oO0 ( )
elif O0OooOo0o == 1 : OOooO ( )
elif O0OooOo0o == 2 : o0ooo00O0o0 ( OoO000 , IIiiIiI1 , iiIiIIi )
elif O0OooOo0o == 3 : IIIIii1I ( OoO000 , IIiiIiI1 , iiIiIIi )
elif O0OooOo0o == 4 : III1Iiii1I11 ( )
elif O0OooOo0o == 900 : I1I1I ( )
elif O0OooOo0o == 901 : I1IiiiiI ( )
elif O0OooOo0o == 902 : Ii1I1i ( )
elif O0OooOo0o == 999 : quit ( )
if 70 - 70: i11iI
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )