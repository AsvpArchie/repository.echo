import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
II1 = xbmc . translatePath ( os . path . join ( ooo0OO , 'controls.txt' ) )
O00ooooo00 = xbmcgui . Dialog ( )
I1IiiI = xbmcgui . DialogProgress ( )
if 27 - 27: iIiiiI1IiI1I1 * IIiIiII11i * IiIIi1I1Iiii - Ooo00oOo00o
I1IiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
o0OOO = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
iIiiiI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
Iii1ii1II11i = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
iI111iI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI9' )
if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
def Oo ( ) :
 if 27 - 27: o00 * O0 - Ooo / IiIiI11iIi - O0OOo . II1Iiii1111i
 i1IIi11111i ( "[COLOR white]Welcome to ECHO Streams[/COLOR]" , I1IiI , 999 , iiiii , O0O0OO0O0O0 )
 i1IIi11111i ( "################################################################" , I1IiI , 999 , iiiii , O0O0OO0O0O0 )
 i1IIi11111i ( "[COLOR white]Meet the team:[/COLOR]" , I1IiI , 999 , iiiii , O0O0OO0O0O0 )
 i1IIi11111i ( "[COLOR white]ECHO Coder: @EchoCoder(Twitter)[/COLOR]" , I1IiI , 999 , iiiii , O0O0OO0O0O0 )
 i1IIi11111i ( "[COLOR white]ECHO Blue: @Blue_Builds(Twitter)[/COLOR]" , I1IiI , 999 , iiiii , O0O0OO0O0O0 )
 i1IIi11111i ( "################################################################" , I1IiI , 999 , iiiii , O0O0OO0O0O0 )
 o000o0o00o0Oo ( "[COLOR dodgerblue][B]ENTER ADDON[/B][/COLOR]" , I1IiI , 1 , iiiii , O0O0OO0O0O0 )
 i1IIi11111i ( "################################################################" , I1IiI , 999 , iiiii , O0O0OO0O0O0 )
 if not os . path . exists ( II1 ) :
  o000o0o00o0Oo ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  o000o0o00o0Oo ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 80 - 80: i1iII1I1i1i1 . i1iIIII
def I1 ( ) :
 if 54 - 54: oO % O00oOoOoO0o0O / IiIiI11iIi * O00oOoOoO0o0O / Oo0ooO0oo0oO
 o000o0o00o0Oo ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 41 - 41: Oo0ooO0oo0oO . i1iIIII
 OoOooOOOO = i11iiII ( I1IiI )
 OoOooOOOO = OoOooOOOO . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 I1iiiiI1iII = re . compile ( '<item>(.+?)</item>' ) . findall ( OoOooOOOO )
 for IiIi11i in I1iiiiI1iII :
  iIii1I111I11I = re . compile ( '<title>(.+?)</title>' ) . findall ( IiIi11i ) [ 0 ]
  OO00OooO0OO = re . compile ( '<folder>(.+?)</folder>' ) . findall ( IiIi11i ) [ 0 ]
  iiiIi = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( IiIi11i ) [ 0 ]
  IiIIIiI1I1 = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( IiIi11i ) [ 0 ]
  if 86 - 86: i11iIiiIii + O0OOo + oO * IiIiI11iIi + II
  o000o0o00o0Oo ( '[COLOR white]' + iIii1I111I11I + '[/COLOR]' , OO00OooO0OO , 2 , iiiIi , IiIIIiI1I1 )
  if 61 - 61: Oo0ooO0oo0oO / i11iIiiIii
def IiIiIi ( name , url , iconimage ) :
 if 40 - 40: O0 . I1i1iI1i . O0oo0OO0 . Ooo00oOo00o
 I11iii = name
 if 54 - 54: Ooo + Ooo % i1iIIII % i11iIiiIii / IIiIiII11i . Ooo
 if "adult" in name . lower ( ) :
  o0oO0o00oo ( )
 II1i1Ii11Ii11 = [ ]
 if 35 - 35: II + II1Iiii1111i + II1Iiii1111i
 if not "search" in name . lower ( ) :
  OoOooOOOO = i11iiII ( url )
  I11I11i1I = re . compile ( '<term>(.+?)</term>' ) . findall ( OoOooOOOO )
  for ii11i1iIII in I11I11i1I :
   ii11i1iIII = ii11i1iIII . replace ( ' ' , '' )
   ii11i1iIII = ii11i1iIII . lower ( )
   II1i1Ii11Ii11 . append ( ii11i1iIII )
 else :
  ii11i1iIII = url
  ii11i1iIII = ii11i1iIII . replace ( ' ' , '' )
  ii11i1iIII = ii11i1iIII . lower ( )
  II1i1Ii11Ii11 . append ( url . lower ( ) )
  if 3 - 3: Ooo00oOo00o / O00oOoOoO0o0O % IiIiI11iIi * i11iIiiIii / iIiiiI1IiI1I1 * IiIiI11iIi
 I1IiiI . create ( Oo0Ooo , "[COLOR white]We are just getting the channel links for you.[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
 I1IiiI . update ( 0 )
 if 49 - 49: O0 % O0OOo + Ooo00oOo00o . O00oOoOoO0o0O % o00
 I1i1iii = [ ]
 i1iiI11I = [ ]
 iiii = [ ]
 oO0o0O0OOOoo0 = [ ]
 I1IiiI . update ( 0 )
 if 48 - 48: iIiiiI1IiI1I1 + iIiiiI1IiI1I1 - o00 . oO / IIiIiII11i
 OoOOO00oOO0 = 0
 OoOooOOOO = i11iiII ( o0OOO )
 I11I11i1I = re . compile ( '<link>(.+?)</link>' ) . findall ( OoOooOOOO )
 oOoo = len ( I11I11i1I )
 if 8 - 8: I1i1iI1i
 o00O = i11iiII ( Iii1ii1II11i )
 o00O = o00O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 OOO0OOO00oo = re . compile ( '<item>(.+?)</item>' ) . findall ( o00O )
 if 31 - 31: iii1I1I - Ooo . i1iIIII % I1i1iI1i - iIiiiI1IiI1I1
 for iii11 in I11I11i1I :
  try :
   OoOOO00oOO0 = OoOOO00oOO0 + 1
   O0oo0OO0oOOOo = 100 * int ( OoOOO00oOO0 ) / int ( oOoo )
   I1IiiI . update ( O0oo0OO0oOOOo , '' , '[COLOR blue]Searching list ' + str ( OoOOO00oOO0 ) + ' of ' + str ( oOoo ) + '[/COLOR]' )
   i1i1i11IIi = i11iiII ( iii11 )
   i1i1i11IIi = i1i1i11IIi . replace ( '#AAASTREAM:' , '#A:' )
   i1i1i11IIi = i1i1i11IIi . replace ( '#EXTINF:' , '#A:' )
   II1III = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i1i1i11IIi )
   iI1iI1I1i1I = [ ]
   for iIi11Ii1 , Ii11iII1 , url in II1III :
    Oo0O0O0ooO0O = { "params" : iIi11Ii1 , "display_name" : Ii11iII1 , "url" : url }
    iI1iI1I1i1I . append ( Oo0O0O0ooO0O )
   IIIIii = [ ]
   for O0o0 in iI1iI1I1i1I :
    Oo0O0O0ooO0O = { "display_name" : O0o0 [ "display_name" ] , "url" : O0o0 [ "url" ] }
    II1III = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( O0o0 [ "params" ] )
    for OO00Oo , O0OOO0OOoO0O in II1III :
     Oo0O0O0ooO0O [ OO00Oo . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O0OOO0OOoO0O . strip ( )
    IIIIii . append ( Oo0O0O0ooO0O )
    if 70 - 70: i1iII1I1i1i1 * O0oo0OO0 * IiIiI11iIi / O0OOo
   for O0o0 in IIIIii :
    name = oOOOoO0O00o0 ( O0o0 [ "display_name" ] )
    url = oOOOoO0O00o0 ( O0o0 [ "url" ] )
    url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
    if 30 - 30: II . O0OOo - IiIIi1I1Iiii
    for IiIi11i in OOO0OOO00oo :
     Ii1iIiii1 = re . compile ( '<old>(.+?)</old>' ) . findall ( IiIi11i ) [ 0 ]
     OOO = re . compile ( '<new>(.+?)</new>' ) . findall ( IiIi11i ) [ 0 ]
     name = name . replace ( Ii1iIiii1 , OOO )
     if 59 - 59: iii1I1I + IiIIi1I1Iiii * I1i1iI1i + Ooo00oOo00o
    I1i1iii . append ( name )
    i1iiI11I . append ( url )
    oO0o0O0OOOoo0 = list ( zip ( I1i1iii , i1iiI11I ) )
  except : pass
  if 58 - 58: iii1I1I * Ooo * o00 / Ooo
 oO0o0OOOO = sorted ( oO0o0O0OOOoo0 )
 O0O0OoOO0 = sorted ( II1i1Ii11Ii11 )
 if 10 - 10: IiIIi1I1Iiii % IIiIiII11i
 O00o0O00 = i11iiII ( iIiiiI )
 O00o0O00 = O00o0O00 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 I1iiiiI1iII = re . compile ( '<item>(.+?)</item>' ) . findall ( O00o0O00 )
 if 34 - 34: oO
 I1111I1iII11 = [ ]
 Oooo0O0oo00oO = [ ]
 IIi1i = [ ]
 if 46 - 46: i1iIIII % IiIiI11iIi + Oo0ooO0oo0oO . I1i1iI1i . Oo0ooO0oo0oO
 I1IiiI . update ( 100 , '' , '[COLOR blue]Filtering results.[/COLOR]' )
 if 96 - 96: O0oo0OO0
 for Ii1I1IIii1II in O0O0OoOO0 :
  for name , url in oO0o0OOOO :
   O0ii1ii1ii = name . replace ( ' ' , '' )
   if 91 - 91: i1iII1I1i1i1
   if Ii1I1IIii1II . lower ( ) in O0ii1ii1ii . lower ( ) :
    if url not in str ( Oooo0O0oo00oO ) :
     if 15 - 15: iii1I1I
     for IiIi11i in I1iiiiI1iII :
      Ii1iIiii1 = re . compile ( '<old>(.+?)</old>' ) . findall ( IiIi11i ) [ 0 ]
      OOO = re . compile ( '<new>(.+?)</new>' ) . findall ( IiIi11i ) [ 0 ]
      if OOO . lower ( ) == "null" : OOO = ""
      name = name . replace ( Ii1iIiii1 , OOO )
     name = name . lstrip ( ' ' )
     I1111I1iII11 . append ( name )
     Oooo0O0oo00oO . append ( url )
     IIi1i = list ( zip ( I1111I1iII11 , Oooo0O0oo00oO ) )
     if 18 - 18: i11iIiiIii . Ooo00oOo00o % IiIIi1I1Iiii / iIiiiI1IiI1I1
 OO0OoO0o00 = sorted ( IIi1i )
 if 53 - 53: iIiiiI1IiI1I1 * Oo0ooO0oo0oO + Ooo
 I1IiiI . update ( 100 , '' , '[COLOR blue]Creating the list of results.[/COLOR]' )
 Ii = 0
 o00O = i11iiII ( iI111iI )
 o00O = o00O . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oOOo0 = re . compile ( '<item>(.+?)</item>' ) . findall ( o00O )
 for name , url in OO0OoO0o00 :
  if 54 - 54: iIiiiI1IiI1I1 - i1iII1I1i1i1 % Ooo
  OOoO = O0ii1ii1ii + '|SPLIT|' + url
  if 46 - 46: Oo0ooO0oo0oO . O0oo0OO0 - IiIIi1I1Iiii
  for IiIi11i in oOOo0 :
   ooo00OOOooO = re . compile ( '<cat>(.+?)</cat>' ) . findall ( IiIi11i ) [ 0 ]
   O00OOOoOoo0O = re . compile ( '<name>(.+?)</name>' ) . findall ( IiIi11i ) [ 0 ]
   if str ( ooo00OOOooO . lower ( ) ) in str ( I11iii . lower ( ) ) :
    if O00OOOoOoo0O . lower ( ) in name . lower ( ) :
     Ii = 1
  if Ii == 0 :
   i1IIi11111i ( '[COLOR white]' + name . capitalize ( ) + '[/COLOR]' , OOoO , 3 , iiiii , O0O0OO0O0O0 )
  Ii = 0
  if 77 - 77: II1Iiii1111i % II1Iiii1111i * O0 - i11iIiiIii
 if I1IiiI . iscanceled ( ) :
  O00ooooo00 . ok ( Oo0Ooo , 'The download was cancelled.' )
  I1IiiI . close ( )
  quit ( )
 I1IiiI . close ( )
 if 93 - 93: IiIIi1I1Iiii / O00oOoOoO0o0O % i11iIiiIii + o00 * Oo0ooO0oo0oO
def I1iI11Ii ( ) :
 if 6 - 6: O0
 OOO0OOO00oo = ''
 oOOo0oOo0 = xbmc . Keyboard ( OOO0OOO00oo , 'Enter Search Term' )
 oOOo0oOo0 . doModal ( )
 if oOOo0oOo0 . isConfirmed ( ) :
  OOO0OOO00oo = oOOo0oOo0 . getText ( )
  if len ( OOO0OOO00oo ) > 1 :
   OO00OooO0OO = OOO0OOO00oo
   IiIiIi ( "search" , OO00OooO0OO , iiiii )
  else : quit ( )
  if 49 - 49: O0oo0OO0 . i11iIiiIii - Ooo00oOo00o / iii1I1I . O00oOoOoO0o0O
def o0oO0o00oo ( ) :
 if 1 - 1: O0oo0OO0 / II % II1Iiii1111i * i1iII1I1i1i1 . i11iIiiIii
 if os . path . exists ( II1 ) :
  III1Iiii1I11 = IIII ( heading = "Please Enter Your Password" )
  if ( not III1Iiii1I11 ) :
   O00ooooo00 . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  iiIiI = III1Iiii1I11
  if 91 - 91: II1Iiii1111i % Ooo00oOo00o % IIiIiII11i
  IIi1I11I1II = open ( II1 , "r" )
  OooOoooOo = re . compile ( r'<password>(.+?)</password>' )
  for ii11IIII11I in IIi1I11I1II :
   file = OooOoooOo . findall ( ii11IIII11I )
   for OOooo in file :
    oOooOOOoOo = base64 . b64decode ( OOooo )
    if not oOooOOOoOo == iiIiI :
     if not OOooo == iiIiI :
      O00ooooo00 . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 41 - 41: O0OOo - iIiiiI1IiI1I1 - iIiiiI1IiI1I1
def oO00OOoO00 ( ) :
 if 40 - 40: O00oOoOoO0o0O * O0OOo + Ooo % II1Iiii1111i
 o0oO0o00oo ( )
 if 74 - 74: O0 - O0oo0OO0 + IiIIi1I1Iiii + i1iIIII / I1i1iI1i
 i1 = 0
 if not os . path . exists ( II1 ) :
  i1 = 1
  i1IIi11111i ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  i1IIi11111i ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  IIi1I11I1II = open ( II1 , "r" )
  OooOoooOo = re . compile ( r'<password>(.+?)</password>' )
  for ii11IIII11I in IIi1I11I1II :
   file = OooOoooOo . findall ( ii11IIII11I )
   for OOooo in file :
    oOooOOOoOo = base64 . b64decode ( OOooo )
    i1 = 1
    i1IIi11111i ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    i1IIi11111i ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( oOooOOOoOo ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    i1IIi11111i ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    i1IIi11111i ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 11 - 11: i1iII1I1i1i1 * O00oOoOoO0o0O . IIiIiII11i % IiIIi1I1Iiii + II1Iiii1111i
 if i1 == 0 :
  i1IIi11111i ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  i1IIi11111i ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 78 - 78: Oo0ooO0oo0oO . Ooo + Oo0ooO0oo0oO / IiIiI11iIi / Oo0ooO0oo0oO
def oO0O00OoOO0 ( ) :
 if 82 - 82: iii1I1I . i1iII1I1i1i1 - IIiIiII11i - i1iII1I1i1i1 * iii1I1I
 III1Iiii1I11 = IIII ( heading = "Please Set Password" )
 if ( not III1Iiii1I11 ) :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 iiIiI = III1Iiii1I11
 if 77 - 77: IIiIiII11i * Oo0ooO0oo0oO
 III1Iiii1I11 = IIII ( heading = "Please Confirm Your Password" )
 if ( not III1Iiii1I11 ) :
  O00ooooo00 . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 oOooOo0 = III1Iiii1I11
 if 38 - 38: i1iIIII
 if not os . path . exists ( II1 ) :
  if not os . path . exists ( ooo0OO ) :
   os . makedirs ( ooo0OO )
  open ( II1 , 'w' )
  if 84 - 84: IIiIiII11i % II1Iiii1111i / IIiIiII11i % IiIiI11iIi
  if iiIiI == oOooOo0 :
   ii = base64 . b64encode ( iiIiI )
   OOooooO0Oo = open ( II1 , 'w' )
   OOooooO0Oo . write ( '<password>' + str ( ii ) + '</password>' )
   OOooooO0Oo . close ( )
   O00ooooo00 . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   O00ooooo00 . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( II1 )
  if 91 - 91: II . IIiIiII11i / O0 + Ooo00oOo00o
  if iiIiI == oOooOo0 :
   ii = base64 . b64encode ( iiIiI )
   OOooooO0Oo = open ( II1 , 'w' )
   OOooooO0Oo . write ( '<password>' + str ( ii ) + '</password>' )
   OOooooO0Oo . close ( )
   O00ooooo00 . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   O00ooooo00 . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 42 - 42: oO . II . oO - o00
def i1ii1I1I1 ( ) :
 if 74 - 74: II . II1Iiii1111i
 try :
  os . remove ( II1 )
  O00ooooo00 . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  O00ooooo00 . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 18 - 18: Ooo + II1Iiii1111i - O0OOo . iii1I1I + i11iIiiIii
def iI1Ii1iI11iiI ( name , url , iconimage ) :
 if 89 - 89: O0oo0OO0 * I1i1iI1i * i1iIIII + II1Iiii1111i - IiIiI11iIi
 name , url = url . split ( '|SPLIT|' )
 if 8 - 8: II % iIiiiI1IiI1I1 / O00oOoOoO0o0O - O0
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = url . replace ( '.ts' , '.m3u8' )
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 43 - 43: i11iIiiIii + O0oo0OO0 * iii1I1I * i1iIIII * iIiiiI1IiI1I1
 o00oO0oo0OO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , o00oO0oo0OO , False )
 if 57 - 57: i1iIIII % O0OOo + II - O0oo0OO0
def oOOOoO0O00o0 ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 65 - 65: IiIiI11iIi . I1i1iI1i
def i11iiII ( url ) :
 if 39 - 39: iii1I1I / oO + i1iIIII / I1i1iI1i
 I1Ii11i = urllib2 . Request ( url )
 I1Ii11i . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 i1i1i11IIi = urllib2 . urlopen ( I1Ii11i )
 OoOooOOOO = i1i1i11IIi . read ( )
 i1i1i11IIi . close ( )
 return OoOooOOOO
 if 35 - 35: II
def IIII ( default = "" , heading = "" , hidden = False ) :
 oOOo0oOo0 = xbmc . Keyboard ( default , heading , hidden )
 if 90 - 90: i1iIIII % O0OOo - IIiIiII11i - IIiIiII11i / i11iIiiIii % o00
 oOOo0oOo0 . doModal ( )
 if ( oOOo0oOo0 . isConfirmed ( ) ) :
  return unicode ( oOOo0oOo0 . getText ( ) , "utf-8" )
 return default
 if 37 - 37: O0 - O00oOoOoO0o0O . IiIiI11iIi * O0OOo - II1Iiii1111i
def o000o0o00o0Oo ( name , url , mode , iconimage , fanartimage ) :
 if 8 - 8: Oo0ooO0oo0oO - O00oOoOoO0o0O % O0OOo * IiIIi1I1Iiii - Oo0ooO0oo0oO * i1iIIII
 iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 o00oOOooOOo0o = True
 o00oO0oo0OO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 o00oO0oo0OO . setProperty ( "fanart_Image" , fanartimage )
 o00oO0oo0OO . setProperty ( "icon_Image" , iconimage )
 o00oOOooOOo0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iii , listitem = o00oO0oo0OO , isFolder = True )
 return o00oOOooOOo0o
 if 66 - 66: II1Iiii1111i - II1Iiii1111i - i11iIiiIii . o00 - Ooo
def i1IIi11111i ( name , url , mode , iconimage , fanartimage ) :
 if 77 - 77: I1i1iI1i - iii1I1I - oO
 iii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 o00oOOooOOo0o = True
 o00oO0oo0OO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 o00oO0oo0OO . setProperty ( "fanart_Image" , fanartimage )
 o00oO0oo0OO . setProperty ( "icon_Image" , iconimage )
 o00oOOooOOo0o = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iii , listitem = o00oO0oo0OO , isFolder = False )
 return o00oOOooOOo0o
 if 49 - 49: iii1I1I % iIiiiI1IiI1I1 . I1i1iI1i + O0 / O00oOoOoO0o0O
def O0oOOoOooooO ( ) :
 oooOo0OOOoo0 = [ ]
 OOoOOO0O000 = sys . argv [ 2 ]
 if len ( OOoOOO0O000 ) >= 2 :
  iIi11Ii1 = sys . argv [ 2 ]
  iiIiI1i1 = iIi11Ii1 . replace ( '?' , '' )
  if ( iIi11Ii1 [ len ( iIi11Ii1 ) - 1 ] == '/' ) :
   iIi11Ii1 = iIi11Ii1 [ 0 : len ( iIi11Ii1 ) - 2 ]
  oO0O00oOOoooO = iiIiI1i1 . split ( '&' )
  oooOo0OOOoo0 = { }
  for OoOOO00oOO0 in range ( len ( oO0O00oOOoooO ) ) :
   IiIi11iI = { }
   IiIi11iI = oO0O00oOOoooO [ OoOOO00oOO0 ] . split ( '=' )
   if ( len ( IiIi11iI ) ) == 2 :
    oooOo0OOOoo0 [ IiIi11iI [ 0 ] ] = IiIi11iI [ 1 ]
    if 83 - 83: iii1I1I % O0oo0OO0 % oO % o00
 return oooOo0OOOoo0
 if 80 - 80: i11iIiiIii % oO + O0OOo % IiIiI11iIi - o00
iIi11Ii1 = O0oOOoOooooO ( ) ; iIii1I111I11I = None ; OO00OooO0OO = None ; I1i1i1iii = None ; iiiIi = None ; I1111i = None
try : iIii1I111I11I = urllib . unquote_plus ( iIi11Ii1 [ "name" ] )
except : pass
try : OO00OooO0OO = urllib . unquote_plus ( iIi11Ii1 [ "url" ] )
except : pass
try : I1i1i1iii = int ( iIi11Ii1 [ "mode" ] )
except : pass
try : iiiIi = urllib . unquote_plus ( iIi11Ii1 [ "iconimage" ] )
except : pass
try : I1111i = urllib . quote_plus ( iIi11Ii1 [ "fanartimage" ] )
except : pass
if 14 - 14: Ooo / II
if I1i1i1iii == None or OO00OooO0OO == None or len ( OO00OooO0OO ) < 1 : Oo ( )
elif I1i1i1iii == 1 : I1 ( )
elif I1i1i1iii == 2 : IiIiIi ( iIii1I111I11I , OO00OooO0OO , iiiIi )
elif I1i1i1iii == 3 : iI1Ii1iI11iiI ( iIii1I111I11I , OO00OooO0OO , iiiIi )
elif I1i1i1iii == 4 : I1iI11Ii ( )
elif I1i1i1iii == 900 : oO00OOoO00 ( )
elif I1i1i1iii == 901 : oO0O00OoOO0 ( )
elif I1i1i1iii == 902 : i1ii1I1I1 ( )
elif I1i1i1iii == 999 : quit ( )
if 32 - 32: O00oOoOoO0o0O * O0oo0OO0
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )