import xbmc , xbmcaddon , xbmcgui , xbmcplugin , urllib , urllib2 , os , re , sys , base64
from resources . lib . modules import checker
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.echostreams'
Oo0Ooo = '[COLOR white]ECHO Streams[/COLOR]'
O0O0OO0O0O0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'fanart.jpg' ) )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'icon.png' ) )
ooo0OO = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' , OO0o ) )
II1 = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'parental' ) )
O00ooooo00 = xbmc . translatePath ( os . path . join ( II1 , 'controls.txt' ) )
I1IiiI = xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data/' + OO0o , 'hd.txt' ) )
IIi1IiiiI1Ii = xbmcgui . Dialog ( )
I11i11Ii = xbmcgui . DialogProgress ( )
oO00oOo = xbmc . translatePath ( os . path . join ( 'special://home/addons/' + OO0o , 'resources/files/repository.txt' ) )
OOOo0 = xbmc . translatePath ( os . path . join ( 'special://home/addons/repository.echo' ) )
if 54 - 54: i1 - o0 * i1oOo0OoO * iIIIiiIIiiiIi % Oo
o0O = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvOXE4NDBaREU=' )
IiiIII111iI = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvcDdkSDVNSjY=' )
IiII = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvd3h6NnU5aFM=' )
iI1Ii11111iIi = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvUlBjQWJTaHc=' )
i1i1II = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvNFhZSDhSYnI=' )
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( ) :
 if 43 - 43: O0OOo . II1Iiii1111i
 i1IIi11111i = OOOo0 + '|SPLIT|' + oO00oOo
 checker . check ( i1IIi11111i )
 if 74 - 74: Oo0o00o0Oo0 * ii11
 I1I1i1 ( )
 if 18 - 18: iiIIIIi1i1 / OOoOoo00oo - iI1 + OOooO % II1Iiii1111i - o00ooo0
 i11iiII ( "[COLOR white]Welcome to ECHO Streams[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "[COLOR white]Meet the team:[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "[COLOR white]ECHO Coder: @EchoCoder(Twitter)[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "[COLOR white]ECHO Blue: @Blue_Builds(Twitter)[/COLOR]" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 I1iiiiI1iII ( "[COLOR dodgerblue][B]ENTER ADDON[/B][/COLOR]" , o0O , 1 , iiiii , O0O0OO0O0O0 )
 i11iiII ( "################################################################" , o0O , 999 , iiiii , O0O0OO0O0O0 )
 if not os . path . exists ( O00ooooo00 ) :
  I1iiiiI1iII ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]OFF[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 else :
  I1iiiiI1iII ( "[COLOR white]PARENTAL CONTROLS - [COLOR white]ON[/COLOR][/COLOR]" , "url" , 900 , iiiii , O0O0OO0O0O0 )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 20 - 20: iIIIiiIIiiiIi + i11iIiiIii - ii11 % I1i1iI1i . i1oOo0OoO
def Ooo00O00O0O0O ( ) :
 if 90 - 90: Oo + O0OOo / o00 % Oo - i1
 I1iiiiI1iII ( '[COLOR white]Search[/COLOR]' , 'url' , 4 , iiiii , O0O0OO0O0O0 )
 if 29 - 29: o00 / o0
 if os . path . exists ( I1IiiI ) :
  i11iiII ( '[COLOR white]Only Display HD Links - [COLOR lime][B]ON[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 else : i11iiII ( '[COLOR white]Only Display HD Links - [COLOR red][B]OFF[/B][/COLOR][/COLOR]' , 'url' , 5 , iiiii , O0O0OO0O0O0 )
 i11iiII ( '[COLOR darkgray]############################################[/COLOR]' , 'url' , 999 , iiiii , O0O0OO0O0O0 )
 IiIIIiI1I1 = OoO000 ( o0O )
 IiIIIiI1I1 = IiIIIiI1I1 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>null</thumbnail>' ) . replace ( '<fanart></fanart>' , '<fanart>null</fanart>' )
 IIiiIiI1 = re . compile ( '<item>(.+?)</item>' ) . findall ( IiIIIiI1I1 )
 for iiIiIIi in IIiiIiI1 :
  ooOoo0O = re . compile ( '<title>(.+?)</title>' ) . findall ( iiIiIIi ) [ 0 ]
  OooO0 = re . compile ( '<folder>(.+?)</folder>' ) . findall ( iiIiIIi ) [ 0 ]
  II11iiii1Ii = re . compile ( '<thumbnail>(.+?)</thumbnail>' ) . findall ( iiIiIIi ) [ 0 ]
  OO0oOoo = re . compile ( '<fanart>(.+?)</fanart>' ) . findall ( iiIiIIi ) [ 0 ]
  if 68 - 68: Oo0o00o0Oo0 + II1Iiii1111i . o0 - OOoOoo00oo % o0 - OOooO
  I1iiiiI1iII ( '[COLOR white]' + ooOoo0O + '[/COLOR]' , OooO0 , 2 , II11iiii1Ii , OO0oOoo )
  if 79 - 79: Oo0ooO0oo0oO + o0OO0 - iiIIIIi1i1
def oO00O00o0OOO0 ( name , url , iconimage ) :
 if 27 - 27: i1 % iIIIiiIIiiiIi * O0OOo + i11iIiiIii + i1oOo0OoO * iIIIiiIIiiiIi
 o0oo0o0O00OO = name
 if 80 - 80: iIIIiiIIiiiIi
 if "adult" in name . lower ( ) :
  I1I1i1 ( )
 oOOO0o0o = [ ]
 if 26 - 26: i1oOo0OoO
 if not "search" in name . lower ( ) :
  IiIIIiI1I1 = OoO000 ( url )
  IiiI11Iiiii = re . compile ( '<term>(.+?)</term>' ) . findall ( IiIIIiI1I1 )
  for ii1I1i1I in IiiI11Iiiii :
   ii1I1i1I = ii1I1i1I . replace ( ' ' , '' )
   ii1I1i1I = ii1I1i1I . lower ( )
   oOOO0o0o . append ( ii1I1i1I )
 else :
  ii1I1i1I = url
  ii1I1i1I = ii1I1i1I . replace ( ' ' , '' )
  ii1I1i1I = ii1I1i1I . lower ( )
  oOOO0o0o . append ( url . lower ( ) )
  if 88 - 88: I1i1iI1i + i1 / o00ooo0 * iiIIIIi1i1
 I11i11Ii . create ( Oo0Ooo , "[COLOR white]We are just getting the channel links for you.[/COLOR]" , '' , '[COLOR yellow]Please wait...[/COLOR]' )
 I11i11Ii . update ( 0 )
 if 41 - 41: O0OOo
 ii1i1I1i = [ ]
 o00oOO0 = [ ]
 oOoo = [ ]
 iIii11I = [ ]
 I11i11Ii . update ( 0 )
 if 69 - 69: O0OOo % iI1 - o00 + iI1 - i1 % i1oOo0OoO
 Iii111II = 0
 IiIIIiI1I1 = OoO000 ( IiiIII111iI )
 IiiI11Iiiii = re . compile ( '<link>(.+?)</link>' ) . findall ( IiIIIiI1I1 )
 iiii11I = len ( IiiI11Iiiii )
 if 96 - 96: Oo % ii11 . II1Iiii1111i + i1oOo0OoO * O0OOo - o00ooo0
 i11i1 = OoO000 ( iI1Ii11111iIi )
 i11i1 = i11i1 . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 IIIii1II1II = re . compile ( '<item>(.+?)</item>' ) . findall ( i11i1 )
 i1I1iI = OoO000 ( i1i1II )
 i1I1iI = i1I1iI . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 oo0OooOOo0 = re . compile ( '<item>(.+?)</item>' ) . findall ( i1I1iI )
 if 92 - 92: iiIIIIi1i1 . Oo0o00o0Oo0 + o00
 IiII1I11i1I1I = 0
 for ii1I1i1I in oo0OooOOo0 :
  oO0Oo = re . compile ( '<cat>(.+?)</cat>' ) . findall ( ii1I1i1I ) [ 0 ]
  if oO0Oo . lower ( ) in o0oo0o0O00OO . lower ( ) :
   oOOoo0Oo = oO0Oo
   IiII1I11i1I1I = 1
 if IiII1I11i1I1I == 0 : oOOoo0Oo = "null"
 if 78 - 78: Oo0o00o0Oo0
 for OO00Oo in IiiI11Iiiii :
  Iii111II = Iii111II + 1
  O0OOO0OOoO0O = 100 * int ( Iii111II ) / int ( iiii11I )
  I11i11Ii . update ( O0OOO0OOoO0O , '' , '[COLOR blue]Searching list ' + str ( Iii111II ) + ' of ' + str ( iiii11I ) + '[/COLOR]' )
  O00Oo000ooO0 = OoO000 ( OO00Oo )
  O00Oo000ooO0 = O00Oo000ooO0 . replace ( '#AAASTREAM:' , '#A:' )
  O00Oo000ooO0 = O00Oo000ooO0 . replace ( '#EXTINF:' , '#A:' )
  OoO0O00 = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( O00Oo000ooO0 )
  IIiII = [ ]
  for o0ooOooo000oOO , Oo0oOOo , url in OoO0O00 :
   Oo0OoO00oOO0o = { "params" : o0ooOooo000oOO , "display_name" : Oo0oOOo , "url" : url }
   IIiII . append ( Oo0OoO00oOO0o )
  OOO00O = [ ]
  for OOoOO0oo0ooO in IIiII :
   Oo0OoO00oOO0o = { "display_name" : OOoOO0oo0ooO [ "display_name" ] , "url" : OOoOO0oo0ooO [ "url" ] }
   OoO0O00 = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( OOoOO0oo0ooO [ "params" ] )
   for O0o0O00Oo0o0 , O00O0oOO00O00 in OoO0O00 :
    Oo0OoO00oOO0o [ O0o0O00Oo0o0 . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = O00O0oOO00O00 . strip ( )
   OOO00O . append ( Oo0OoO00oOO0o )
   if 11 - 11: OOoOoo00oo . Oo0oO0ooo
  for OOoOO0oo0ooO in OOO00O :
   name = o0oo0oOo ( OOoOO0oo0ooO [ "display_name" ] )
   url = o0oo0oOo ( OOoOO0oo0ooO [ "url" ] )
   url = url . replace ( '\\n' , '' ) . replace ( '\n' , '' ) . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
   if 89 - 89: o00ooo0
   ii1i1I1i . append ( name )
   o00oOO0 . append ( url )
   iIii11I = list ( zip ( ii1i1I1i , o00oOO0 ) )
   if 68 - 68: I1i1iI1i * i1oOo0OoO % i1 + I1i1iI1i + OOooO
 i11i1I1 = sorted ( iIii11I )
 ii1I = sorted ( oOOO0o0o )
 if 67 - 67: i11iIiiIii - iIIIiiIIiiiIi % Oo0oO0ooo . i1
 o0oo = OoO000 ( IiII )
 o0oo = o0oo . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '<fanart></fanart>' , '<fanart>x</fanart>' ) . replace ( '<thumbnail></thumbnail>' , '<thumbnail>x</thumbnail>' ) . replace ( '<utube>' , '<link>https://www.youtube.com/watch?v=' ) . replace ( '</utube>' , '</link>' )
 IIiiIiI1 = re . compile ( '<item>(.+?)</item>' ) . findall ( o0oo )
 if 91 - 91: OOoOoo00oo
 iiIii = [ ]
 ooo0O = [ ]
 oOoO0o00OO0 = [ ]
 if 7 - 7: II1Iiii1111i + iI1 + i1
 I11i11Ii . update ( 100 , '' , '[COLOR blue]Filtering results.[/COLOR]' )
 if 9 - 9: Oo . o00 - OOooO / o00
 if oOOoo0Oo != 'null' :
  if 46 - 46: Oo0o00o0Oo0 . II1Iiii1111i * Oo0o00o0Oo0 % iIIIiiIIiiiIi
  iIIiII = re . compile ( '<cat>' + re . escape ( oOOoo0Oo ) + '</cat>(.+?)</item>' , re . DOTALL ) . findall ( i1I1iI ) [ 0 ]
  IiiI11Iiiii = re . compile ( '<name>(.+?)</name>' ) . findall ( iIIiII )
  if 38 - 38: iI1
  for Ii1 in ii1I :
   for name , url in i11i1I1 :
    OOooOO000 = name . replace ( ' ' , '' )
    if 97 - 97: Oo0oO0ooo + II1Iiii1111i / o0 / iiIIIIi1i1
    if Ii1 . lower ( ) in OOooOO000 . lower ( ) :
     if url not in str ( ooo0O ) :
      if 37 - 37: iiIIIIi1i1 - OOooO * O0OOo % i11iIiiIii - iI1
      for o0oO in IiiI11Iiiii :
       if not o0oO . lower ( ) in name . lower ( ) :
        for iiIiIIi in IIiiIiI1 :
         IIiIi1iI = re . compile ( '<old>(.+?)</old>' ) . findall ( iiIiIIi ) [ 0 ]
         i1IiiiI1iI = re . compile ( '<new>(.+?)</new>' ) . findall ( iiIiIIi ) [ 0 ]
         if i1IiiiI1iI . lower ( ) == "null" : i1IiiiI1iI = ""
         name = name . lower ( )
         IIiIi1iI = IIiIi1iI . lower ( )
         i1IiiiI1iI = i1IiiiI1iI . lower ( )
         name = name . replace ( IIiIi1iI , i1IiiiI1iI )
        for i1iIi in IIIii1II1II :
         IIiIi1iI = re . compile ( '<old>(.+?)</old>' ) . findall ( i1iIi ) [ 0 ]
         i1IiiiI1iI = re . compile ( '<new>(.+?)</new>' ) . findall ( i1iIi ) [ 0 ]
         name = name . lower ( )
         IIiIi1iI = IIiIi1iI . lower ( )
         i1IiiiI1iI = i1IiiiI1iI . lower ( )
         name = name . replace ( IIiIi1iI , i1IiiiI1iI )
        name = name . lstrip ( ' ' )
        iiIii . append ( name )
        ooo0O . append ( url )
        oOoO0o00OO0 = list ( zip ( iiIii , ooo0O ) )
 else :
  for Ii1 in ii1I :
   for name , url in i11i1I1 :
    OOooOO000 = name . replace ( ' ' , '' )
    if 68 - 68: i11iIiiIii % Oo0oO0ooo + i11iIiiIii
    if Ii1 . lower ( ) in OOooOO000 . lower ( ) :
     if url not in str ( ooo0O ) :
      if 31 - 31: Oo . o0OO0
      for iiIiIIi in IIiiIiI1 :
       IIiIi1iI = re . compile ( '<old>(.+?)</old>' ) . findall ( iiIiIIi ) [ 0 ]
       i1IiiiI1iI = re . compile ( '<new>(.+?)</new>' ) . findall ( iiIiIIi ) [ 0 ]
       if i1IiiiI1iI . lower ( ) == "null" : i1IiiiI1iI = ""
       name = name . replace ( IIiIi1iI , i1IiiiI1iI )
      for i1iIi in IIIii1II1II :
       IIiIi1iI = re . compile ( '<old>(.+?)</old>' ) . findall ( i1iIi ) [ 0 ]
       i1IiiiI1iI = re . compile ( '<new>(.+?)</new>' ) . findall ( i1iIi ) [ 0 ]
       name = name . replace ( IIiIi1iI , i1IiiiI1iI )
      name = name . lstrip ( ' ' )
      iiIii . append ( name )
      ooo0O . append ( url )
      oOoO0o00OO0 = list ( zip ( iiIii , ooo0O ) )
      if 1 - 1: Oo0ooO0oo0oO / o00 % iiIIIIi1i1 * OOoOoo00oo . i11iIiiIii
      if 2 - 2: Oo0oO0ooo * Oo0o00o0Oo0 - o0 + o0OO0 . O0OOo % iiIIIIi1i1
 ooOOOoOooOoO = sorted ( oOoO0o00OO0 )
 if 91 - 91: iiIIIIi1i1 % iIIIiiIIiiiIi % o0
 I11i11Ii . update ( 100 , '' , '[COLOR blue]Creating the list of results.[/COLOR]' )
 if 20 - 20: II1Iiii1111i % ii11 / ii11 + ii11
 for name , url in ooOOOoOooOoO :
  if 45 - 45: O0OOo - OOoOoo00oo - i1oOo0OoO - I1i1iI1i . Oo / i1
  oo0o00O = name + '|SPLIT|' + url
  if 51 - 51: ii11 - I1i1iI1i * iiIIIIi1i1
  if os . path . exists ( I1IiiI ) :
   if "hd" in name . lower ( ) :
    name = name . replace ( 'hd' , '' )
    i11iiII ( '[COLOR white]' + name . capitalize ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , oo0o00O , 3 , iiiii , O0O0OO0O0O0 )
  else :
   if "hd" in name . lower ( ) :
    name = name . replace ( 'hd' , '' )
    i11iiII ( '[COLOR white]' + name . capitalize ( ) + ' [COLOR blue][B]HD[/B][/COLOR][/COLOR]' , oo0o00O , 3 , iiiii , O0O0OO0O0O0 )
   else :
    i11iiII ( '[COLOR white]' + name . capitalize ( ) + '[/COLOR]' , oo0o00O , 3 , iiiii , O0O0OO0O0O0 )
    if 66 - 66: i1oOo0OoO + i1
 if I11i11Ii . iscanceled ( ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The download was cancelled.' )
  I11i11Ii . close ( )
  quit ( )
 I11i11Ii . close ( )
 if 11 - 11: Oo0o00o0Oo0 + i1oOo0OoO - I1i1iI1i / o00 + Oo0ooO0oo0oO . Oo
def i1Iii1i1I ( ) :
 if 91 - 91: Oo0oO0ooo + o0OO0 . II1Iiii1111i * Oo0oO0ooo + o0OO0 * Oo0ooO0oo0oO
 I1I1i1 ( )
 if 80 - 80: iiIIIIi1i1 % II1Iiii1111i % O0OOo - Oo0ooO0oo0oO + Oo0ooO0oo0oO
 IIIii1II1II = ''
 iIiii1i111iI1 = xbmc . Keyboard ( IIIii1II1II , 'Enter Search Term' )
 iIiii1i111iI1 . doModal ( )
 if iIiii1i111iI1 . isConfirmed ( ) :
  IIIii1II1II = iIiii1i111iI1 . getText ( )
  if len ( IIIii1II1II ) > 1 :
   OooO0 = IIIii1II1II
   oO00O00o0OOO0 ( "search" , OooO0 , iiiii )
  else : quit ( )
  if 14 - 14: iiIIIIi1i1 . iiIIIIi1i1 % i1oOo0OoO
def iiIi1IIi1I ( ) :
 if 84 - 84: OOooO * Oo + Oo0ooO0oo0oO
 if not os . path . exists ( ooo0OO ) :
  try :
   os . makedirs ( ooo0OO )
  except : pass
 if os . path . exists ( I1IiiI ) :
  try :
   os . remove ( I1IiiI )
  except : pass
 else :
  try :
   open ( I1IiiI , 'w' )
  except : pass
  if 53 - 53: iiIIIIi1i1 % Oo . OOoOoo00oo - o0 - OOoOoo00oo * Oo
 xbmc . executebuiltin ( 'Container.Refresh' )
 if 77 - 77: o0 * I1i1iI1i
def I1I1i1 ( ) :
 if 95 - 95: o0OO0 + i11iIiiIii
 if os . path . exists ( O00ooooo00 ) :
  I1Ii = O0oo00o0O ( heading = "Please Enter Your Password" )
  if ( not I1Ii ) :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
   quit ( )
  i1I1I = I1Ii
  if 12 - 12: i11iIiiIii / I1i1iI1i
  o0OIiII = open ( O00ooooo00 , "r" )
  ii1iII1II = re . compile ( r'<password>(.+?)</password>' )
  for Iii1I1I11iiI1 in o0OIiII :
   file = ii1iII1II . findall ( Iii1I1I11iiI1 )
   for I1I1i1I in file :
    ii1IO0oO0 = base64 . b64decode ( I1I1i1I )
    if not ii1IO0oO0 == i1I1I :
     if not I1I1i1I == i1I1I :
      IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, the password you entered was incorrect." )
      quit ( )
      if 87 - 87: Oo0ooO0oo0oO . OOoOoo00oo
def O0OO0O ( ) :
 if 81 - 81: O0OOo . o00 % i1 / o0OO0 - O0OOo
 I1I1i1 ( )
 if 43 - 43: i11iIiiIii + Oo0ooO0oo0oO * Oo * iI1 * i1
 IiII1I11i1I1I = 0
 if not os . path . exists ( O00ooooo00 ) :
  IiII1I11i1I1I = 1
  i11iiII ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  i11iiII ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
 else :
  o0OIiII = open ( O00ooooo00 , "r" )
  ii1iII1II = re . compile ( r'<password>(.+?)</password>' )
  for Iii1I1I11iiI1 in o0OIiII :
   file = ii1iII1II . findall ( Iii1I1I11iiI1 )
   for I1I1i1I in file :
    ii1IO0oO0 = base64 . b64decode ( I1I1i1I )
    IiII1I11i1I1I = 1
    i11iiII ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR lime]ON[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    i11iiII ( "[COLOR white]Current Password - [/COLOR][COLOR orangered]" + str ( ii1IO0oO0 ) + "[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
    i11iiII ( "[COLOR lime]Change Password[/COLOR]" , "url" , 901 , iiiii , O0O0OO0O0O0 )
    i11iiII ( "[COLOR orangered]Disable Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
    if 64 - 64: II1Iiii1111i % o0 * O0OOo
 if IiII1I11i1I1I == 0 :
  i11iiII ( "[COLOR blue]PARENTAL CONTROLS - [/COLOR][COLOR orangered]OFF[/COLOR]" , "url" , 999 , iiiii , O0O0OO0O0O0 )
  i11iiII ( "[COLOR white]Setup Parental Password[/COLOR]" , "url" , 902 , iiiii , O0O0OO0O0O0 )
  if 79 - 79: i1
def oOO00O ( ) :
 if 77 - 77: Oo0ooO0oo0oO - iIIIiiIIiiiIi - Oo0o00o0Oo0 . o00ooo0
 I1Ii = O0oo00o0O ( heading = "Please Set Password" )
 if ( not I1Ii ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 i1I1I = I1Ii
 if 39 - 39: Oo / OOooO + iI1 / o00ooo0
 I1Ii = O0oo00o0O ( heading = "Please Confirm Your Password" )
 if ( not I1Ii ) :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , "Sorry, no password was entered." )
  sys . exit ( 0 )
 I1Ii11i = I1Ii
 if 35 - 35: o00
 if not os . path . exists ( O00ooooo00 ) :
  if not os . path . exists ( II1 ) :
   os . makedirs ( II1 )
  open ( O00ooooo00 , 'w' )
  if 90 - 90: iI1 % ii11 - o0 - o0 / i11iIiiIii % Oo0oO0ooo
  if i1I1I == I1Ii11i :
   IIii11I1 = base64 . b64encode ( i1I1I )
   oOO0O00Oo0O0o = open ( O00ooooo00 , 'w' )
   oOO0O00Oo0O0o . write ( '<password>' + str ( IIii11I1 ) + '</password>' )
   oOO0O00Oo0O0o . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
 else :
  os . remove ( O00ooooo00 )
  if 13 - 13: i1oOo0OoO
  if i1I1I == I1Ii11i :
   IIii11I1 = base64 . b64encode ( i1I1I )
   oOO0O00Oo0O0o = open ( O00ooooo00 , 'w' )
   oOO0O00Oo0O0o . write ( '<password>' + str ( IIii11I1 ) + '</password>' )
   oOO0O00Oo0O0o . close ( )
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Your password has been set and parental controls have been enabled.' )
   xbmc . executebuiltin ( "Container.Refresh" )
  else :
   IIi1IiiiI1Ii . ok ( Oo0Ooo , 'The passwords do not match, please try again.' )
   sys . exit ( 0 )
   if 33 - 33: iI1 + iiIIIIi1i1 * O0OOo / o0 - o0OO0
def O0oO ( ) :
 if 73 - 73: Oo0oO0ooo * i11iIiiIii % O0OOo . Oo0oO0ooo
 try :
  os . remove ( O00ooooo00 )
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'Parental controls have been disabled.' )
  xbmc . executebuiltin ( "Container.Refresh" )
 except :
  IIi1IiiiI1Ii . ok ( Oo0Ooo , 'There was an error disabling the parental controls.' )
  xbmc . executebuiltin ( "Container.Refresh" )
  if 66 - 66: O0OOo + O0OOo + OOooO / iiIIIIi1i1 + II1Iiii1111i
def iI ( name , url , iconimage ) :
 if 49 - 49: o0OO0 - Oo0o00o0Oo0
 name , url = url . split ( '|SPLIT|' )
 if 74 - 74: o0 * Oo0oO0ooo + o00ooo0 / iIIIiiIIiiiIi / Oo . Oo0ooO0oo0oO
 if not 'f4m' in url :
  if '.m3u8' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
  elif '.ts' in url :
   url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url + '&amp;iconImage=' + iconimage
   if 62 - 62: i1oOo0OoO * o0OO0
 oOOOoo0O0oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , oOOOoo0O0oO , False )
 if 6 - 6: II1Iiii1111i * o00 + iiIIIIi1i1
def o0oo0oOo ( str ) :
 try :
  import chardet
  str = str . decode ( chardet . detect ( str ) [ "encoding" ] ) . encode ( "utf-8" )
 except :
  try :
   str = str . encode ( "utf-8" )
  except :
   pass
 return str
 if 44 - 44: ii11 % I1i1iI1i + i1oOo0OoO - i1 - ii11 - Oo
def OoO000 ( url ) :
 if 99 - 99: OOooO . ii11 + iI1 + i1oOo0OoO % o00
 ooO = urllib2 . Request ( url )
 ooO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36' )
 O00Oo000ooO0 = urllib2 . urlopen ( ooO )
 IiIIIiI1I1 = O00Oo000ooO0 . read ( )
 O00Oo000ooO0 . close ( )
 return IiIIIiI1I1
 if 46 - 46: o0OO0 - i1oOo0OoO - Oo0o00o0Oo0 * Oo
def O0oo00o0O ( default = "" , heading = "" , hidden = False ) :
 iIiii1i111iI1 = xbmc . Keyboard ( default , heading , hidden )
 if 34 - 34: Oo0o00o0Oo0 - iiIIIIi1i1 / II1Iiii1111i + Oo0oO0ooo * ii11
 iIiii1i111iI1 . doModal ( )
 if ( iIiii1i111iI1 . isConfirmed ( ) ) :
  return unicode ( iIiii1i111iI1 . getText ( ) , "utf-8" )
 return default
 if 73 - 73: o00ooo0 . ii11 * Oo0oO0ooo % Oo0oO0ooo % i1oOo0OoO
def I1iiiiI1iII ( name , url , mode , iconimage , fanartimage ) :
 if 63 - 63: o0 * i11iIiiIii % o0 * i11iIiiIii
 iI1111iiii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 Oo0OO = True
 oOOOoo0O0oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oOOOoo0O0oO . setProperty ( "fanart_Image" , fanartimage )
 oOOOoo0O0oO . setProperty ( "icon_Image" , iconimage )
 Oo0OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1111iiii , listitem = oOOOoo0O0oO , isFolder = True )
 return Oo0OO
 if 78 - 78: II1Iiii1111i - i1oOo0OoO - Oo0oO0ooo / OOooO / Oo
def i11iiII ( name , url , mode , iconimage , fanartimage ) :
 if 29 - 29: o0OO0 % o0OO0
 iI1111iiii = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + iconimage + "&fanartimage=" + urllib . quote_plus ( fanartimage )
 Oo0OO = True
 oOOOoo0O0oO = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 oOOOoo0O0oO . setProperty ( "fanart_Image" , fanartimage )
 oOOOoo0O0oO . setProperty ( "icon_Image" , iconimage )
 Oo0OO = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = iI1111iiii , listitem = oOOOoo0O0oO , isFolder = False )
 return Oo0OO
 if 94 - 94: o0 / Oo0ooO0oo0oO % iiIIIIi1i1 * iiIIIIi1i1 * Oo
def IIiIiI ( ) :
 OOO = [ ]
 IIiI1i1i = sys . argv [ 2 ]
 if len ( IIiI1i1i ) >= 2 :
  o0ooOooo000oOO = sys . argv [ 2 ]
  O00Oo0 = o0ooOooo000oOO . replace ( '?' , '' )
  if ( o0ooOooo000oOO [ len ( o0ooOooo000oOO ) - 1 ] == '/' ) :
   o0ooOooo000oOO = o0ooOooo000oOO [ 0 : len ( o0ooOooo000oOO ) - 2 ]
  IiII111i1i11 = O00Oo0 . split ( '&' )
  OOO = { }
  for Iii111II in range ( len ( IiII111i1i11 ) ) :
   i111iIi1i1II1 = { }
   i111iIi1i1II1 = IiII111i1i11 [ Iii111II ] . split ( '=' )
   if ( len ( i111iIi1i1II1 ) ) == 2 :
    OOO [ i111iIi1i1II1 [ 0 ] ] = i111iIi1i1II1 [ 1 ]
    if 86 - 86: o0 / o00ooo0 . Oo
 return OOO
 if 19 - 19: Oo0oO0ooo % i1oOo0OoO % OOoOoo00oo * o00 % i1
o0ooOooo000oOO = IIiIiI ( ) ; ooOoo0O = None ; OooO0 = None ; ooo = None ; II11iiii1Ii = None ; i1i1iI1iiiI = None
try : ooOoo0O = urllib . unquote_plus ( o0ooOooo000oOO [ "name" ] )
except : pass
try : OooO0 = urllib . unquote_plus ( o0ooOooo000oOO [ "url" ] )
except : pass
try : ooo = int ( o0ooOooo000oOO [ "mode" ] )
except : pass
try : II11iiii1Ii = urllib . unquote_plus ( o0ooOooo000oOO [ "iconimage" ] )
except : pass
try : i1i1iI1iiiI = urllib . quote_plus ( o0ooOooo000oOO [ "fanartimage" ] )
except : pass
if 51 - 51: o0OO0 % iI1 . O0OOo / o0 / Oo0o00o0Oo0 . O0OOo
if ooo == None or OooO0 == None or len ( OooO0 ) < 1 : o0oOoO00o ( )
elif ooo == 1 : Ooo00O00O0O0O ( )
elif ooo == 2 : oO00O00o0OOO0 ( ooOoo0O , OooO0 , II11iiii1Ii )
elif ooo == 3 : iI ( ooOoo0O , OooO0 , II11iiii1Ii )
elif ooo == 4 : i1Iii1i1I ( )
elif ooo == 5 : iiIi1IIi1I ( )
elif ooo == 900 : O0OO0O ( )
elif ooo == 901 : oOO00O ( )
elif ooo == 902 : O0oO ( )
elif ooo == 999 : quit ( )
if 42 - 42: o00 + iIIIiiIIiiiIi - ii11 / OOoOoo00oo
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )